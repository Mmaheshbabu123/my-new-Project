import React, { Component } from 'react';
import { datasave } from '../_services/db_services';
import FolderComponent from '../_components/folderComponent/folderComponent';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { OCAlert } from '@opuscapita/react-alerts';
import {translate} from '../language';
import DocumenTranslation from '../Document/DocumentTitleTranslation';


const mandatory_fields = ['name', 'code'];

class Folder extends Component {
    constructor(props) {
        super(props)
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this)
        this.handleChangetag = this.handleChangetag.bind(this)
        this.handleChangeMultiStandard = this.handleChangeMultiStandard.bind(this)
        this.handleCancel = this.handleCancel.bind(this)
        this.handleSelect = this.handleSelect.bind(this)
        this.handleChangenum = this.handleChangenum.bind(this)
        this.updateSelected = this.updateSelected.bind(this);
        this.updateSelectedRights = this.updateSelectedRights.bind(this);
        this.handleActiveTab = this.handleActiveTab.bind(this);
        this.handleNotification = this.handleNotification.bind(this);
        this.handleNotificationSelect = this.handleNotificationSelect.bind(this);
        this.handleChangeMultiOwner = this.handleChangeMultiOwner.bind(this)
        this.handleFoldersData = this.handleFoldersData.bind(this);
        this.handleManualData = this.handleManualData.bind(this);
        this.handleParentData = this.handleParentData.bind(this);
        this.handleMakeEmpty = this.handleMakeEmpty.bind(this);
        this.handleTemplate = this.handleTemplate.bind(this);
        this.handleCopyData = this.handleCopyData.bind(this);
        this.updateFolder = this.props.updateFolder;
        this.filterArray = this.filterArray.bind(this);
        this.getUpdateCode = this.getUpdateCode.bind(this);
        this.handleMakeemptyDetails = this.handleMakeemptyDetails.bind(this);
        // this.handleChangeTransaltion = this.handleChangeTransaltion.bind(this);
        this.state = {
            credentials: this.props.credentials,
            name: '',
            active_tab: 1,
            review_period_days: '',
            review_warning_days: '',
            archive_period_days: '',
            review_period_type: 'days',
            review_warning_type: 'days',
            archive_period_type: 'days',
            historical_period_days: '',
            historical_period_type: '',
            revision_date_behaviour: '1',
            revison_date_behaviour_days: '',
            expiration_behaviour_days: '',
            expiration_behaviour_type: 'days',
            error_postion: '',
            submitted: false,
            layout_id: '',
            error: [],
            layouts: [],
            tags: [],
            standards: [],
            standard_options: [],
            tag_options: [],
            code: '',
            manuals: [],
            manual_id: '',
            parent_id: '',
            parent_type: '',
            key: 1,
            template: '<NR>',
            available_in_masterdata: 1,
            fundamental: 0,
            template_error: '',
            sample: '1',
            position: '1',
            tasks: [],
            items: [],
            types: [],
            selected: [],
            notifications: [],
            owner_options: [],
            owners: [],
            spaces: [],
            [window.tabs.approval_cycle]: [],
            [window.tabs.r_u_extra]: [],
            [window.tabs.r_u_default]: [],
            [window.tabs.notification]: [],
            [window.tabs.spaces]: [],
            folders_flag: 1,
            manaul_flag: 1,
            disableFields: false,
            title: 'Folder details',
            next_fol_id: '',
            next_template: '',
            next_position: '',
            next_code: '',
            table_of_contents: 1,
            t:props.t,
            corporate : 0,
            showtranslation : false,
            entity_type : 0,
            language_title : [],
        }
    }
    confirmPopup = () => {
      const {t} = this.state;
        confirmAlert({
            title: t('Confirm to submit'),
            message: t('Do you want to copy parent folder?'),
            buttons: [
                {
                    label: t('Yes'),
                    onClick: () => this.handleCopyData(this.props.credentials.parent_type)
                },
                {
                    label: t('No'),
                    onClick: () => this.handleFoldersData('create')
                }
            ]
        });
    };
    getUpdateCode(next_fol_id, next_template, next_position) {
        var next_position = this.getposition(next_position, next_fol_id);
        //next_template = (next_template!=null)?next_template:'';
        var combine = next_position;
        return combine;
    }
    /**
     * edit folders data
     */
    handleMakeEmpty(result, action) {

       this.props.credentials.manual_flag = 0;
        this.setState({
            [window.tabs.notification]: result.notifications,
            [window.tabs.r_u_default]: (result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
            [window.tabs.r_u_extra]: (result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
            [window.tabs.approval_cycle]: result.rights,
            [window.tabs.spaces]: result.spaces,
            notifications:result.notifications_behaviour,
            tags: result.tags,
            standards: result.standards,
            owners: result.owners,
            manuals:result.manuals,
            code: result.folder.code,
            name: result.folder.name,
            review_period_days: result.folder.review_period_days,
            review_warning_days: result.folder.review_warning_days,
            archive_period_days: result.folder.archive_period_days,
            review_period_type: result.folder.review_period_type,
            review_warning_type: result.folder.review_warning_type,
            archive_period_type: result.folder.archive_period_type,
            historical_period_days: result.folder.historical_period_days,
            historical_period_type: result.folder.historical_period_type,
            expiration_behaviour_days: result.folder.expiration_behaviour_days,
            expiration_behaviour_type: result.folder.expiration_behaviour_type,
            revision_date_behaviour: result.folder.revision_date_behaviour,
            available_in_masterdata: (result.folder.available_master_data !== null)?result.folder.available_master_data:0,
           table_of_contents: (result.folder.table_of_contents !== null)?result.folder.table_of_contents:0,
          //  table_of_contents: result.folder.table_of_contents,
            fundamental: (result.folder.fundamental !== null)?result.folder.fundamental:0,
            parent_id: result.folder.parent_id,
            parent_type: result.folder.parent_type,
            manual_id: result.folder.parent_id + '-' + result.folder.parent_type + '-' + result.folder.manual_id,
            template: result.folder.template_number,
            position: result.folder.position,
            sample: result.folder.sequence_number,
            layout_id: result.folder.layout_id,
            folders_flag: 0,
            error: '',
            disableFields: (action == 'view') ? true : false,
            corporate : (result.folder.corporate != undefined)?result.folder.corporate:0,
            language_title : [],
        });
    }
    /**
     * Copy the data from parent type folder or manual
     */
    handleCopyData(type) {

        //handleCopyData
        var url = '';
        if (type === 'folder') {
        //  window.GET_FOLDER_DETAILS + this.props.credentials.parent_id
            url = window.GET_FOLDER_DETAILS + this.props.credentials.parent_id;
            this.props.credentials.manual_flag = 0;
            datasave.service(url, "GET")
                .then(result => {
                    this.setState({
                        [window.tabs.notification]: result.notifications,
                        [window.tabs.r_u_default]: (result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
                        [window.tabs.r_u_extra]: (result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
                        [window.tabs.approval_cycle]: result.rights,
                        [window.tabs.spaces]: result.spaces,
                        notifications:result.notifications_behaviour,
                        tags: result.tags,
                        owners: result.owners,
                        standards: result.standards,
                        code: this.getUpdateCode(result.next_code[0].fol_next_id, result.next_code[0].template, result.next_code[0].position),
                        name: '',
                        //manuals:result.manuals,
                        parent_id: result.folder.parent_id,
                        parent_type: result.folder.parent_type,
                        manual_id: result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id,
                        review_period_days: result.folder.review_period_days,
                        review_warning_days: result.folder.review_warning_days,
                        archive_period_days: result.folder.archive_period_days,
                        review_period_type: result.folder.review_period_type,
                        review_warning_type: result.folder.review_warning_type,
                        archive_period_type: result.folder.archive_period_type,
                        available_in_masterdata: (result.folder.available_master_data !== null)?result.folder.available_master_data:0,
                        table_of_contents: (result.folder.table_of_contents !== null)?result.folder.table_of_contents:0,
                        fundamental: (result.folder.fundamental !== null)?result.folder.fundamental:0,
                        historical_period_days: result.folder.historical_period_days,
                        historical_period_type: result.folder.historical_period_type,
                        expiration_behaviour_days: result.folder.expiration_behaviour_days,
                        expiration_behaviour_type: result.folder.expiration_behaviour_type,
                        revision_date_behaviour: result.folder.revision_date_behaviour,
                        template: result.folder.template_number,
                        position: result.folder.position,
                        sample: result.folder.sequence_number,
                        layout_id: result.folder.layout_id,
                        submitted: false,
                        folders_flag: 0,
                        disableFields: false,
                        entity_type : 2,
                        language_title : [],
                    });

                });
        }
        else {
            url = window.GET_MANUAL + '/' + this.props.credentials.parent_id;
            this.props.credentials.manual_flag = 0;
            datasave.service(url, "GET")
                .then(result => {
                    this.setState({
                        [window.tabs.notification]: result.notifications,
                        [window.tabs.r_u_default]: (result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
                        [window.tabs.r_u_extra]: (result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
                        [window.tabs.approval_cycle]: result.rights,
                        [window.tabs.spaces]: result.spaces,
                        notifications:result.notifications_behaviour,
                        tags: result.tags,
                        standards: result.standards,
                        name: '',
                        owners: result.owners,
                        parent_id: result.folder.parent_id,
                        parent_type: result.folder.parent_type,
                        manual_id: result.folder.id + '-' + window.MANUAL_ENTITY + '-' + result.folder.id,
                        review_period_days: result.folder.review_period_days,
                        review_warning_days: result.folder.review_warning_days,
                        archive_period_days: result.folder.archive_period_days,
                        review_period_type: result.folder.review_period_type,
                        review_warning_type: result.folder.review_warning_type,
                        archive_period_type: result.folder.archive_period_type,
                        historical_period_days: result.folder.historical_period_days,
                        historical_period_type: result.folder.historical_period_type,
                        expiration_behaviour_days: result.folder.expiration_behaviour_days,
                        expiration_behaviour_type: result.folder.expiration_behaviour_type,
                        revision_date_behaviour: result.folder.revision_date_behaviour,
                        available_in_masterdata: (result.folder.available_master_data !== null)?result.folder.available_master_data:0,
                        table_of_contents:  (result.folder.table_of_contents !== null)?result.folder.table_of_contents:0,
                       //result.folder.table_of_contents,
                        fundamental: (result.folder.fundamental !== null)?result.folder.fundamental:0,
                        template: result.folder.template_number,
                        position: result.folder.position,
                        sample: result.folder.sequence_number,
                        layout_id: result.folder.layout_id,
                        submitted: false,
                        folders_flag: 0,
                        disableFields: false,
                        code: this.getUpdateCode(result.next_code[0].fol_next_id, result.next_code[0].template, result.next_code[0].position),
                        corporate : (result.folder.corporate != undefined)?result.folder.corporate:0,
                        entity_type :2,
                        language_title : [],
                    });
                    //     var next_position = this.getposition(this.state.next_position,this.state.next_fol_id);
                    //     var combine =this.state.next_template+next_position;
                    //    // this.state.next_code = combine;
                    //     this.setState({
                    //         next_code:combine,
                    //        // disableFields:true,
                    //     })
                    //this.props.credentials.manual_flag = 0;
                });
        }
    }
    /**
     * View folders,manuals
     */
    handleFoldersData(action) {

        //handleFoldersData
        var result = [];
        if (action == 'edit' || action == 'view') {
            var url = window.GET_FOLDER_DETAILS + this.props.credentials.parent_id;
            datasave.service(url, "GET")
                .then(result => {
                    this.handleMakeEmpty(result, action)
                });
        }
        else {
            if (this.props.credentials.parent_type == 'manual') {
                var url = window.GET_MANUAL + '/' + this.props.credentials.parent_id;
            }
            else {
                var url = window.GET_FOLDER_DETAILS + this.props.credentials.parent_id;
            }
            datasave.service(url, "GET")
                .then(result => {
                    var code = this.getUpdateCode(result.next_code[0].fol_next_id, result.next_code[0].template, result.next_code[0].position)
                    if (this.props.credentials.parent_type == 'manual') {
                        var manual_id = result.folder.id + '-' + window.MANUAL_ENTITY + '-' + result.folder.id;
                    }
                    else {
                        var manual_id = result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id;
                    }
                    result.folder = [];
                    result.standards = [];
                    result.tags = [];
                    result.spaces = [];
                    result.owners = [];
                    result.r_u = [];
                    result.r_u[1] = [];
                    result.notifications = [];
                    result.rights = [];
                    result.r_u[2] = [];
                    this.getNotifications();
                    this.setState({
                        [window.tabs.notification]: result.notifications,
                        [window.tabs.r_u_default]: result.r_u[1],
                        [window.tabs.r_u_extra]: result.r_u[2],
                        [window.tabs.approval_cycle]: result.rights,
                        [window.tabs.spaces]: result.spaces,
                        tags: result.tags,
                        standards: result.standards,
                        code: code,
                        owners:result.owners,
                        review_period_days: '',
                        review_warning_days: '',
                        archive_period_days: '',
                        review_period_type: 'days',
                        review_warning_type: 'days',
                        archive_period_type: 'days',
                        expiration_behaviour_type: 'days',
                        expiration_behaviour_days: '',
                        expiration_behaviour_type: 'days',
                        expiration_behaviour_days: '',
                        expiration_behaviour_type: 'days',
                        historical_period_days: '',
                        historical_period_type: '',
                        manual_id: manual_id,
                        name: '',
                        template: '<NR>',
                        position: '',
                        sample: '',
                        next_fol_id: '',
                        folders_flag: 0,
                        layout_id:0,
                        table_of_contents:1,
                        disableFields: false,
                        entity_type : 2,
                    });
                });
            this.props.credentials.manual_flag = 0;
        }
    }
    handleParentData() {
        //var url = window.GET_FOLDERS_IDS + '/' + this.props.credentials.manual_id;
        //handleParentData
        var url = window.GET_FOLDERS + '/' + this.props.credentials.manual_id + '/'+ this.props.credentials.parent_id;

        datasave.service(url, "GET")
            .then(result => {
                if (result.length > 0) {
                    if (this.state.manual_id === '') {
                        this.setState({

                            //manual_id: result[0].id + '-' + result[0].type + '-' + result[0].manual_id,
                             manuals: result
                        })

                    }
                    else {
                      this.setState({
                        //  manual_id: result[0].id + '-' + result[0].type + '-' + result[0].manual_id,
                           manuals: result
                      });
                    }
                    this.props.credentials.manual_flag = 0;
                }
            });
    }
    handleCancel(event) {
      this.props.cancelData();

     if(this.props.credentials.action == 'create') {
        if (this.props.credentials.parent_type === 'blanco') {
            this.props.cancelData();
        }
        if (this.props.credentials.parent_type === 'folder' || this.props.credentials.parent_type === 'manual') {
            this.props.cancelData();
        }
     }
     else{
        if (this.props.credentials.parent_type === 'folder') {
            this.handleMakeemptyDetails();
           this.handleFoldersData('edit');
        }
        if (this.props.credentials.parent_type === 'manual') {
            this.handleMakeemptyDetails();
            this.handleManualData('edit');
        }

     }


    }
    handleSelect(event) {
        const { name, value } = event.target;
        this.setState({
            [name]: !this.state[name],
        })
    }
    handleActiveTab(key) {
        this.setState({
            active_tab: key,
        });
    }
    getNotifications() {
        datasave.service(window.GET_INSERT_DOCUMENT_DETAILS,'GET','')
        .then(response => {
            this.setState({
                notifications : response.notifications,
            })
        })
        .catch(error => {
            this.setState({
               // errors: error.response.data.errors
            })
        })
    }
    componentDidMount() {

        // datasave.service(window.GET_INSERT_DOCUMENT_DETAILS,'GET','')
        // .then(response => {
        //     this.setState({
        //         notifications : response.notifications,
        //     })
        // })
        // .catch(error => {
        //     this.setState({
        //        // errors: error.response.data.errors
        //     })
        // })

        // var url = window.SHOW_LAYOUTS;
        // datasave.service(url, "GET")
        //     .then(result => {
        //         this.setState({
        //             layouts: result,
        //         })
        //     });
        var url = window.GET_STANDARDS;
        datasave.service(url, "GET")

            .then(result => {
                this.setState({
                   standard_options: result.standards,
                   layouts: result.layouts,
                   tag_options: result.tags,
                   owner_options: result.owners,
                })
            });

        // var url = window.GET_TAGS;
        // datasave.service(url, "GET")
        //     .then(result => {
        //         this.setState({
        //             tag_options: result,
        //         })
        //     });
        // var url = window.GET_ALLPESONS_JOBS;
        // datasave.service(url, "GET")
        //     .then(result => {
        //         this.setState({
        //             owner_options: result,
        //         })
        //     });
    }
     /**
     * Empty the data in folders or manauls
     */
    handleMakeemptyDetails(){

        var result = [];
        result.folder = [];
            result.standards = [];
            result.tags = [];
            result.spaces = [];
            result.r_u = [];
            result.r_u[1] = [];
            result.notifications = [];
            result.rights = [];
            result.r_u[2] = [];
            this.props.credentials.manual_flag = 0;
            this.setState({
                [window.tabs.notification]: result.notifications,
                [window.tabs.r_u_default]: result.r_u[1],
                [window.tabs.r_u_extra]: result.r_u[2],
                [window.tabs.approval_cycle]: result.rights,
                [window.tabs.spaces]: result.spaces,
                tags: result.tags,
                standards: result.standards,
                code: '',
                name: '',
                owners: [],
                review_period_days: '',
                review_warning_days: '',
                layout_id:0,
                archive_period_days: '',
                review_period_type: 'days',
                review_warning_type: 'days',
                archive_period_type: 'days',
                expiration_behaviour_days:'',
                expiration_behaviour_type: 'days',
                revision_date_behaviour:1,
                historical_period_days: '',
                historical_period_type: '',
                manual_id: '',
                template: '<NR>',
                position: '',
                sample: '',
                folders_flag: 0,
            });
    }
    /**
     * Empty the data in folders or manauls
     */
    handleManualData(action) {
        //handleManualData
        var result = [];
        if (action === 'edit' || action == 'view') {
            var url = window.GET_MANUAL + '/' + this.props.credentials.parent_id;
            datasave.service(url, "GET")
                .then(result => {
                    this.handleMakeEmpty(result, action)
                });
        }
        else {
            //handleManualData
            var url = window.GET_FOLDER_DETAILS + '-1';
            result.folder = [];
            result.standards = [];
            result.tags = [];
            result.spaces = [];
            result.r_u = [];
            result.r_u[1] = [];
            result.notifications = [];
            result.rights = [];
            result.r_u[2] = [];
            this.props.credentials.manual_flag = 0;
            this.setState({
                [window.tabs.notification]: result.notifications,
                [window.tabs.r_u_default]: result.r_u[1],
                [window.tabs.r_u_extra]: result.r_u[2],
                [window.tabs.approval_cycle]: result.rights,
                [window.tabs.spaces]: result.spaces,
                tags: result.tags,
                standards: result.standards,
                code: '',
                name: '',
                review_period_days: '',
                review_warning_days: '',
                archive_period_days: '',
                revision_date_behaviour:1,
                review_period_type: 'days',
                review_warning_type: 'days',
                archive_period_type: 'days',
                expiration_behaviour_type: 'days',
                historical_period_days: '',
                historical_period_type: '',
                manual_id: '',
                template: '<NR>',
                position: '',
                sample: '',
                folders_flag: 0,
            });

        }
    }
    formSave() {
      const {t} = this.state;
        const { history } = this.props;
        if (this.props.credentials.action === 'edit') {
            if (this.props.credentials.parent_type === 'folder') {
                var url = window.GET_FOLDER_DETAILS + this.props.credentials.parent_id;
                datasave.service(url, "PUT", this.state)
                    .then(result => {
                        if (result != 'Success') {
                            this.setState({
                                error: result.code,
                            })
                        } else {
                            this.setState({
                                disableFields: true,

                            });
                            this.updateFolder(this.props.credentials.manual_id);
                            OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION});

                        }
                    });
            }
            if (this.props.credentials.parent_type === 'manual') {
                var url = window.INSERT_MANUAL + '/' + this.props.credentials.parent_id;
                datasave.service(url, "PUT", this.state)
                    .then(result => {
                        if (result != 'Success') {
                            this.setState({
                                error: result.code,
                            })
                        }
                        else {
                            this.setState({
                                disableFields: true,
                            })
                            this.updateFolder(this.props.credentials.manual_id);
                            OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION});
                        }
                    });
            }
        } else {
            if (this.props.credentials.parent_type === 'blanco') {
                var url = window.INSERT_MANUAL;
                datasave.service(url, "POST", this.state)
                    .then(resultObj => {
                        if (resultObj.updatedObj === undefined) {
                            this.setState({
                                error: resultObj.code,
                            })
                        }
                        else {
                          this.setState({
                              disableFields: true,
                          })
                            this.updateFolder(resultObj.updatedObj.id);
                            // this.setState({
                            //     // next_fol_id:resultObj.updatedObj.next_code[0].fol_next_id,
                            //     // next_template:resultObj.updatedObj.next_code[0].template,
                            //     // next_position:resultObj.updatedObj.next_code[0].position,
                            //    // next_code :this.getUpdateCode(resultObj.updatedObj.next_code[0].fol_next_id,resultObj.updatedObj.next_code[0].template,resultObj.updatedObj.next_code[0].position)
                            // })
                            //     var next_position = this.getposition(this.state.next_position,this.state.next_fol_id);
                            //     var combine =this.state.next_template+next_position;
                            //    // this.state.next_code = combine;

                            OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION});
                        }
                    });
            }
            else {
                var url = window.INSERT_FOLDERS;
                datasave.service(url, "POST", this.state)
                    .then(resultObjFolder => {
                        if (resultObjFolder.updatedObjFolder === undefined) {
                            this.setState({
                                error: resultObjFolder,
                            })
                        }
                        else {
                            this.setState({
                                disableFields: true,
                                // next_code:this.getUpdateCode(resultObjFolder.updatedObjFolder.next_code[0].fol_next_id,resultObjFolder.updatedObjFolder.next_code[0].template,resultObjFolder.updatedObjFolder.next_code[0].position)
                            })
                            this.updateFolder(this.props.credentials.manual_id, 'F'+resultObjFolder.updatedObjFolder.id);
                            OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION});
                        }
                    });
            }
        }
        //     this.setState({
        //     disableFields:true,
        // })
    }
    handleSubmit = (event) => {
        var formvalid = true;
        this.setState({
            submitted: true,
        })
        for (var i = 0; i < mandatory_fields.length; i++) {
            if (this.state[mandatory_fields[i]].length === 0) {
                formvalid = false;
            }
        }
        if (formvalid)
            this.formSave();
    }
    handleTemplate(event) {
        var combine = '';
        if (event.target.value.includes('<NR>')) {
            combine = this.getTemplate(event.target.value);
            this.setState({
                template: event.target.value,
            })

            this.setState({
                sample: combine,
            })
        }
        else {
            combine = this.getTemplate('<NR>')
            this.setState({
                template: '<NR>',
                sample: combine,
            })
        }
    }
    handleChangenum(event) {
        const re = /^(?:[1-9]|0[1-9]|10)$/;
        var error = 1;
        var max_value = 'Maximum allowed upto range 10';
        if (event.target.value === '' || re.test(event.target.value)) {
            var seq = event.target.value;
            this.setState({ position: event.target.value })
            if (event.target.value === '') {
                event.target.value = '1';
            }
            this.state.sample = '1';
            this.setState({ error_postion: '' })
        }
        else {
            error = 0;
            this.setState({ error_postion: max_value })
        }
        if (error) {
            var s = this.getTemplate(this.state.template, event.target.value);
        }
        // var s = this.state.sample + "";
        // while (s.length < seq) {
        //     s = "0" + s;
        // }
        this.setState({ sample: s })
    }
    handleChange(event) {
      const { name, value } = event.target;
      if (name == 'code') {
          this.setState({ [name]: value, error: '' });
      }
        if (event.target === undefined) {
            const { value } = event;
            this.setState({ standards: event });
        } else {
            const { name, value } = event.target;
            this.setState({
                [name]: value,
                nameerror: '',
                type_error: '',
            });
        }
    }
    getTemplate(template, position = '') {
        var data = template;
        var s = this.getposition(position);
        var combine = template.replace('<NR>', s);
        return combine;
    }
    getposition(position = '', sample = 1) {
        var seq = (position) ? position : this.state.position;
        var s = sample + "";
        while (s.length < seq) {
            s = "0" + s;
        }
        return s;
    }
    handleChangetag(event) {
        if (event.target === undefined) {
            const { value } = event;

            this.setState({ tags: event });
        }
    }
    handleChangeMultiStandard(event) {
      if (event.target === undefined) {
          const { value } = event;
          this.setState({ standards: event });
      }
    }



    handleChangeMultiOwner(event) {
        this.setState({ owners: event });
    }
    updateSelected = (latestDropped, result, type, id = '') => {
        var array = [...this.state[type]]; // make a separate copy of the array
        if (result.type === 'remove') {
            var filterArray = array.filter(selected => (selected.id !== latestDropped.id));
        }

        if (result.type === 'remove') {
            this.setState({
                [type]: filterArray
            })
        }
        else {
            this.setState(prevState => ({
                [type]: [...prevState[type], latestDropped]
            }));
        }
    }
    handleNotificationSelect(data) {
        this.setState({
            notifications: data
        })
    }
    updateSelectedRights = (latestList) => {
        this.setState({
            [window.tabs.approval_cycle]: latestList,
        })
    }
    filterArray = (allList, selectedList) => {
        var pack_func = allList;
        Object.values(selectedList).map(
            function (item, key) {
                pack_func = pack_func.filter(selected => (selected.id !== item.id));
            }, this);

        return pack_func;
    }
    handleNotification = (latestDropped, result, type, id) => {
        var array = [];
        if (this.state[type] !== undefined && this.state[type].length > 0) {
            array = [...this.state[type]];
            var selectedArrayMatched = array.filter(selected => (selected.n_id === id));
            var selectedArrayUnmatched = array.filter(selected => (selected.n_id !== id));
        }
        if (result.type === 'remove' && array.length > 0) {
            var filterArrayObj = selectedArrayMatched.filter(selected => (selected.id !== latestDropped.id));
            Array.prototype.push.apply(selectedArrayUnmatched, filterArrayObj)
            this.setState({
                [type]: selectedArrayUnmatched,
            })
        } else {
            var obj = {};
            Object.keys(latestDropped).forEach(function (key) {
                obj[key] = latestDropped[key];
            })
            obj['n_id'] = id;
            this.setState(prevState => ({
                [type]: [...prevState[type], obj]
            }));
        }
    }
    handleChangeTransaltion () {
        this.setState({
            showtranslation:true,
        })
    }
    handleTranslationCancel (translatedstring) {
        this.setState({
          showtranslation:false,
          language_title : translatedstring
        })
      }
    render() {
      const {t} = this.state;
        // //this.props.credentials
        if (this.props.credentials.manual_flag) {
            this.handleParentData();
        }
        if (this.props.credentials.action === 'edit') {
            if (this.props.credentials.parent_type === 'folder') {
                if (this.props.credentials.manual_flag) {
                    this.setState({
                        entity_type : 2,
                    })
                    this.handleMakeemptyDetails()
                    this.handleFoldersData('edit');
                }
            }
            if (this.props.credentials.parent_type === 'manual') {
                if (this.props.credentials.manual_flag) {
                    this.setState({
                        entity_type : 1,
                    })
                    this.handleMakeemptyDetails()
                    this.handleManualData('edit');
                }
            }
        } else if (this.props.credentials.action === 'view') {
            if (this.props.credentials.manual_flag) {
                if (this.props.credentials.parent_type === 'folder') {
                    this.setState({
                        entity_type : 2,
                    })
                    this.handleMakeemptyDetails()
                    this.handleFoldersData('view');
                }
                if (this.props.credentials.parent_type === 'manual') {
                    this.setState({
                        entity_type : 1,
                    })
                    this.handleMakeemptyDetails()
                    this.handleManualData('view');
                }
            }
        }
        else {
            if (this.props.credentials.parent_type === 'blanco') {
                if (this.props.credentials.manual_flag) {
                    this.setState({
                        entity_type : 1,
                    })
                    this.getNotifications()
                    this.handleManualData('create');
                }
            }
            if (this.props.credentials.parent_type === 'folder' || this.props.credentials.parent_type === 'manual') {
                if (this.props.credentials.manual_flag) {

                    this.confirmPopup();
                    // var alert = window.confirm('Do yoy want copy the parent folder data');
                    // if (alert == true) {
                    //     this.handleCopyData(this.props.credentials.parent_type);
                    // }
                    // else {
                    //     this.handleFoldersData('create');
                    // }
                }
            }
        }

        return (
            <Can
                perform="Manual_management,R_manual,E_manual,R_folder,E_folder,V_DOC_rights,C_DOC_rights,V_R_U_rights,M_R_U,AIS_extra_R_U_rights,V_extra_R_U_rights,V_notification_rights,Change_notification_rights,R_space,E_space,D_space,Merge_and_update"
                yes={() => (
                    <>
                        <FolderComponent
                            handleChange={this.handleChange.bind(this)}
                            handleChangetag={this.handleChangetag.bind(this)}
                            handleChangeMultiStandard = {this.handleChangeMultiStandard.bind(this)}
                            handleChangeMultiOwner={this.handleChangeMultiOwner.bind(this)}
                            handleChangenum={this.handleChangenum.bind(this)}
                            handleSubmit={this.handleSubmit.bind(this)}
                            handleCancel={this.handleCancel.bind(this)}
                            handleSelect={this.handleSelect.bind(this)}
                            updateSelected={this.updateSelected.bind(this)}
                            filterArray={this.filterArray.bind(this)}
                            updateSelectedRights={this.updateSelectedRights.bind(this)}
                            handleNotificationSelect={this.handleNotificationSelect}
                            name={this.state.name}
                            error={this.state.error}
                            code={this.state.code}
                            submitted={this.state.submitted}
                            layouts={this.state.layouts}
                            review_period_days={this.state.review_period_days}
                            review_warning_days={this.state.review_warning_days}
                            archive_period_days={this.state.archive_period_days}
                            review_period_type={this.state.review_period_type}
                            review_warning_type={this.state.review_warning_type}
                            archive_period_type={this.state.archive_period_type}
                            historical_period_days={this.state.historical_period_days}
                            historical_period_type={this.state.historical_period_type}
                            expiration_behaviour_days={this.state.expiration_behaviour_days}
                            handleActiveTab={this.handleActiveTab}
                            options={this.state.options}
                            layout_id={this.state.layout_id}
                            key={this.state.key}
                            active_master={this.state.active_master}
                            template={this.state.template}
                            sample={this.state.sample}
                            position={this.state.position}
                            standard_options={this.state.standard_options}
                            standards={this.state.standards}
                            tags={this.state.tags}
                            tag_options={this.state.tag_options}
                            manuals={this.state.manuals}
                            manual_id={this.state.manual_id}
                            tasks={this.state.tasks}
                            types={this.state.types}
                            selected={this.state.selected}
                            items={this.state.items}
                            active_tab={this.state.active_tab}
                            details={this.state}
                            handleNotification={this.handleNotification}
                            notificationObject={this.state.notification}
                            object={this.state}
                            updatePropsRight={1}
                            credentials={this.props.credentials}
                            error_postion={this.state.error_postion}
                            title={this.state.title}
                            handleTemplate={this.handleTemplate}
                            handleprops= {this.props}
                            corporate = {this.state.corporate}
                            handleChangeTransaltion = {this.handleChangeTransaltion.bind(this)}

                        />
                        {this.state.showtranslation &&
                        <DocumenTranslation name={this.state.name} showtranslation={this.state.showtranslation} handleTranslationCancel={this.handleTranslationCancel.bind(this)} doc_id={this.props.credentials.parent_id} parent_type={this.props.credentials.parent_type} action={this.props.credentials.action} entity_type={this.state.entity_type}></DocumenTranslation>}
                    </>
                )}
                no={() =>
                    <AccessDeniedPage />
                }
            />
        );
    }
}
export default translate(Folder)
