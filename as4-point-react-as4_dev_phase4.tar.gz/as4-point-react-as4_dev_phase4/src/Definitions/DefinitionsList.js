import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import {translate} from '../language';

class DefinitionsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            tabs: {
                Active: 'Active definitions',
                Archived: 'Archived definitions'
            },
            definitions: {
                Active: [],
                Archived: [],
            },
            gettagsUrl: window.GET_Active_nd_Archive,
            changeDefinitionStatusUrl: window.CHANGE_STATUS,
            t:props.t
        }
        this.handle_activities = this.handle_activities.bind(this);
    }

    componentDidMount() {
        var url = this.state.gettagsUrl + window.definitions_table;
        datasave.service(url,'GET','')
        .then(response => {
            this.setState({
                definitions: response,
            })
        });

    }

    handle_activities(id,status, e) {
        var url = this.state.changeDefinitionStatusUrl + id;

        const details = {
            table: window.definitions_table,
            status: status ? 1 : 0
        }
        datasave.service(url,'PUT',details)
        .then(response => {
            if (response === 1) {
               window.location.reload()
            }
        })
        .catch(error => {
            this.setState({
                errors: error.response.data.errors
            })
        })

    }

    render () {
        const {tabs,t,definitions} = this.state
        var tabData = Object.keys(tabs).map(
            function (tab,value) {
                return (
                    <reactbootstrap.Tab eventKey={tab} title={t(tabs[tab])}>
                        <div className="card-body">
                            <form method = 'POST'>
                                <reactbootstrap.Table responsive>
                                    <thead>
                                        <tr>
                                            <th>{t('Definition')}</th>
                                            <th></th>
                                            <th>{t('Actions')}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {definitions[tab].map(
                                            function (definition) {
                                                return (
                                                    <tr>
                                                        <td>{definition.name}</td>
                                                        <td></td>
                                                        <td>
                                                            <Link
                                                                to ={`/definitions/${definition.id}`}
                                                                key={definition.id}
                                                                    >
                                                                {t('Edit')}
                                                            </Link>
                                                            <br></br>
                                                            <a href='#'
                                                                onClick = {this.handle_activities.bind(this,definition.id,!definition.status)}
                                                            >
                                                                {definition.status ? 'Make archive' : 'Make active'}
                                                            </a>
                                                        </td>
                                                    </tr>
                                                )
                                            }, this)
                                        }
                                    </tbody>
                                </reactbootstrap.Table>
                            </form>
                        </div>
                    </reactbootstrap.Tab>)
            }, this
        )

        return (
            <div className='container py-4'>
                <div className='row justify-content-center'>
                    <div className='col-md-8'>
                        <div className='card'>
                            <div className='card-header'>{t('All definitions')}</div>
                            <div className='card-body'></div>
                                <reactbootstrap.Tabs activeKey={this.state.key}  onSelect={this.handleSelect} id="controlled-tab-example">
                                    {tabData}
                                </reactbootstrap.Tabs>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

}

export default translate(DefinitionsList)
