  import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import {translate} from '../language';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import { persistor, store } from '../store';
import Pagination from 'react-bootstrap/Pagination'
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import CheckBox   from '../CheckBox';

class DEFINITIONS extends Component {
  constructor(props) {
    super(props)

    this.state = {
      getDefinitionDetails: window.SHOW_DEFINITION,
      definitionUpdateUrl: window.UPDATE_DEFINITION,
      name: '',
      description: '',
      available_in_masterdata: true,
      active_definition: true,
      submitted: false,
      loading: false,
      name_error: '',
      t:props.t,
      itemsUsedIn :[],
      PerPage:5,
      icurrentPage:1
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handlehide = this.handlehide.bind(this);

  }

  componentDidMount() {
    if (this.props.id) {
      const url = this.state.getDefinitionDetails + this.props.id;

      datasave.service(url, 'GET', '')
        .then(response => {
          this.setState({
            name: response[0]['name'],
            clonename : response[0]['name'],
            clonedescription : response[0]['description'],
            description: response[0]['description'],
            active_definition: response[0]['status'],
            available_in_masterdata: response[0]['available_in_masterdata'] == 1 ? true:false,
          })
        });
    }
  }
  componentDidUpdate(prevProps,prevState) {
    let tid  = this.props.id;
    if(tid !== '' && prevProps.id !== this.props.id &&tid !== undefined){

      const id = this.props.id;
      const url = this.state.getDefinitionDetails + this.props.id;
      datasave.service(url, 'GET', '')
        .then(response => {
          if(response[0].description !== null) {
          this.setState({
            name: response[0]['name'],
            clonename : response[0]['name'],
            description: response[0]['description'],
            clonedescription : response[0]['description'],
            active_definition: response[0]['status'],
            available_in_masterdata: response[0]['available_in_masterdata'],
            name_error:'',errors:'',
          });
        }
        else{
          this.setState({
            description:'',
            clonedescription : '',
            name: response[0]['name'],
            clonename : response[0]['name'],
            name_error:'',errors:'',
          });
        }
      });
    }
    if(tid===undefined && prevProps.id !== this.props.id){
      this.setState({
        name:'',
        description:'',
        name_error:'',errors:''
      });
    }

  }
  handleChange(event) {
    const { name, value } = event.target;
    this.setState({ [name]: value,name_error:'',});

  }
  handleCancel(event) {

    if (this.props.id) {
      this.props.updateComponent(1);
    } else {
      this.props.updateComponent(1);
    }
  }

  handleSubmit(event) {
      const definitionId = this.props.id;
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
    event.preventDefault();
    this.setState({ submitted: true });
    const details = {
      name: this.state.name,
      description: this.state.description,
      available_in_masterdata: this.state.available_in_masterdata,
      status: this.state.active_definition,
      modifyname : (this.state.name === this.state.clonename) ? false:true,
      modifydescription :(this.state.clonedescription === this.state.description) ? false:true,
      pid : person_id,
      clonename:this.state.clonename,
      clonedescription:this.state.description

    }
    if (this.props.id) {
      // const definitionId = this.props.id;
      {(this.state.clonename===this.state.name && this.state.clonedescription ===this.state.description) && this.props.updateComponent(1)}
      datasave.service(window.GetUsedInDocs_definations+this.props.id, 'GET',)
      .then(response => {
        if(response.length === 0){
          const url = this.state.definitionUpdateUrl + definitionId;
      datasave.service(url, 'PUT', details)
        .then(response => {
          if (response.name) {
            this.setState({
              // loading: 'disabled',
              name_error: response.name,
            })
          }
          else {
            this.props.created(this.state.name)
            this.props.updateComponent(1);
          }
        })
        }else{
        this.setState({
          show: true,itemsUsedIn:response
         })
        }
      })



    }

    else {
      datasave.service(window.INSERT_DEFINITION, 'POST', details)
        .then(response => {
          if (response.name) {
            this.setState({
              name_error: response.name
            })
          }
          else {

            this.props.created(this.state.name)
            this.props.updateComponent(1);
          }
        })
    }
  }
  handlePageClick(event){
    this.setState({
      icurrentPage: Number(event.target.id)
    });
  }
  handlehide(){
    this.setState({
      show:false
    })
  }

    handleExport(){
      const id = this.props.id;
      var url =window.EXPORT_DEFINATIONS;
      const details = {
        oldname:this.state.clonename,
        name: this.state.name,
        olddescription:this.state.clonedescription,
        description: this.state.description,
        id:id
      }
      datasave.service(url,'PUT',details).then(response =>{
        window.open(response);
        window.close();
      })
    }




      handlePopOk(){
        const definitionId = this.props.id;
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        const details = {
          name: this.state.name,
          description: this.state.description,
          available_in_masterdata: this.state.available_in_masterdata,
          status: this.state.active_definition,
          modifyname : (this.state.name === this.state.clonename) ? false:true,
          modifydescription :(this.state.clonedescription === this.state.description) ? false:true,
          pid : person_id,
          clonename:this.state.clonename,
          clonedescription:this.state.description
        }





        const url = this.state.definitionUpdateUrl + definitionId;
      datasave.service(url, 'PUT', details)
        .then(response => {
          if (response.name) {
            this.setState({
              // loading: 'disabled',
              name_error: response.name,
            })
          }
          else {
            this.props.created(this.state.name)
            this.props.updateComponent(1);
          }
        })
        .catch(error => {
          this.setState({
            errors: error.response.data.errors
          })
        })

      }
  render() {
    const { name, description,t, available_in_masterdata, submitted, loading, name_error,icurrentPage,itemsUsedIn, PerPage,clonedescription,clonename } = this.state;


    const indexOfLastitem = icurrentPage * PerPage;
    const indexOfFirstitem = indexOfLastitem - PerPage;
    const currentitems = itemsUsedIn.slice(indexOfFirstitem, indexOfLastitem);
    const data = currentitems.map(item => {
        return (
          <tr>
        <td>{item.d_code}</td>
       <td>{item.d_name}</td>
       {/* <td>{item.d_version}</td> */}
       {/* <td>{item.f_code}</td> */}
       <td>{item.f_name}</td>
       <td>{item.m_name}</td>
       </tr>
        )
    });


    const pageNumbers = [];
    if(itemsUsedIn.length > 5) {
        for (let i = 1; i <= Math.ceil(itemsUsedIn.length / PerPage); i++) {
        pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === icurrentPage}>
            {i}
        </Pagination.Item>);
    }
  }

    const popup = (
      <reactbootstrap.Modal
        size="lg"
        show={this.state.show}
        onHide={this.handlehide}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title">
        <reactbootstrap.Modal.Header closeButton>
              <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
              </reactbootstrap.Modal.Title>
              <reactbootstrap.Modal.Body>
              <reactbootstrap.Table striped bordered hover size="sm">
                <thead>
                <tr>
                  <th>{t('Document code')}</th>
                  <th>{t('Document name')}</th>
                  {/* <th>{t('Document version')}</th> */}
                  <th>{t('Folder name')}</th>
                  <th>{t('Manual name')}</th>
                </tr>
              </thead>
                {data}
              </reactbootstrap.Table>
              <Pagination   size="sm">{pageNumbers}</Pagination>
              <reactbootstrap.Table striped bordered hover size="sm">
              <thead>
                {clonename!== name &&
                  <tr>
                  <th className ="taghead" style ={{width: '30%'}}>{t('Previous name')}</th>
                  <td>{clonename}</td>
                  </tr>
                }
                  {clonename!== name &&
                  <tr>
                  <th className ="taghead" style ={{width: '30%'}}>{t('Updated name')}</th>
                  <td>{name}</td>
                  </tr>}
                  {clonedescription !== description &&
                  <tr>
                  <th className ="taghead" style ={{width: '30%'}}>{t('Previous description')}</th>
                  <td>{clonedescription}</td>
                  </tr>
                  }{clonedescription !== description &&
                  <tr>
                  <th className ="taghead" style ={{width: '30%'}}>{t('Updated description')}</th>
                  <td>{description}</td>
                  </tr>
                  }
                </thead>
                </reactbootstrap.Table>
              </reactbootstrap.Modal.Body>
            </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={() => this.handlehide()}>{t('Cancel')}</reactbootstrap.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
          <reactbootstrap.Button onClick={() => this.handlePopOk()}>{t('Edit')}</reactbootstrap.Button>
           &nbsp;&nbsp; &nbsp;&nbsp;
         <reactbootstrap.Button onClick={() => this.handleExport()}>{t('Export')}</reactbootstrap.Button>
      </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
    );

    return (
      <Can
      perform = "E_definitions"
      yes = {() => (
      <div className='container' >
        <div className='row justify-content-center' >
          <div className='col-md-12' >
            <div className='card' >
              <div className='card-header' > {t('Create definition')} </div>
              <div className='card-body' >
                <reactbootstrap.Container className="p-1">
                  <reactbootstrap.Form onSubmit={this.handleSubmit}>
                    <reactbootstrap.FormGroup>
                      <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
                      <div className=" input-overall-sec ">
                        <reactbootstrap.InputGroup className="">
                        <div className="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Name')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                          </div>
                          <div class="col-md-8 input-padd">
                          <reactbootstrap.FormControl
                            name="name"
                            autoFocus
                            placeholder={t("Definition")}
                            aria-label="Definition"
                            aria-describedby="basic-addon1"
                            value={name}
                            onChange={this.handleChange}
                            className="input_sw "
                          />
                           <div style={{ color: 'red'  }} className="error-block mt-2">{name_error}</div>
                          </div>
                        </reactbootstrap.InputGroup>

                      </div>
                      </div>
                    </reactbootstrap.FormGroup>
                    <reactbootstrap.FormGroup>
                    <div className=" input-overall-sec ">
                    <reactbootstrap.InputGroup className="">
                    <div className="col-md-4">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Description')}:</reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                      </div>
                      <div class="col-md-8 input-padd">
                      <reactbootstrap.FormControl
                        style={{ height: '200px' }}
                        as="textarea" rows="3"
                        name="description"
                        placeholder={this.props.placeholder}
                        value={description}
                        id="description"
                        onChange={this.handleChange}
                        className="input_sw "
                      />
                      </div>
                      </reactbootstrap.InputGroup>
                      </div>
                    </reactbootstrap.FormGroup>
                    <div className="ml-4 mt-2">
                    <reactbootstrap.Form.Group>
                      <CheckBox
                            name={t("Available in master data")}
                            tick={available_in_masterdata}
                            style={{ paddingLeft: '0px' }}
                            onCheck={e => this.setState({ available_in_masterdata: !available_in_masterdata })}
                            value={'Available in master data'}
                        />
                    </reactbootstrap.Form.Group>
                    </div>
                    <FormGroup>

                    <div style={{float: 'right'}} className="organisation_list mt-3">
                      <a   onClick={this.handleCancel} >{t('Cancel')}</a>
                      &nbsp;&nbsp;&nbsp;
                        <reactbootstrap.Button style={{fontSize: '14px'}}  type="submit" className="btn btn-primary" disabled={loading}>{t('Save')}</reactbootstrap.Button>
                      </div>
                      {popup}
                    </FormGroup>
                  </reactbootstrap.Form>
                </reactbootstrap.Container>
              </div>
            </div>
          </div>
        </div>
      </div>
      )}
      no = {() =>
        <AccessDeniedPage/>
      }
    />
    );
  }
}
export default translate(DEFINITIONS)
