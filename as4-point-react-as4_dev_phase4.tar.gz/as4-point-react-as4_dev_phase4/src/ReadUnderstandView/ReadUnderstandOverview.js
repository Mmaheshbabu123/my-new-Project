import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap'
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
import CheckBox from '../CheckBox.js';
import './ReadUnderstandOverview.css';
import { persistor, store } from '../store';
import { OCAlert } from '@opuscapita/react-alerts';
class ReadUnderstandOverview extends Component {
  constructor(props) {
    super(props)
    this.state = {
      allTodos: [],
      completedTodos: [],
      inCompleteTodos: [],
      newTodos: [],
      conversation: [],
      alldetails: {},
      currentDetails: [],
      newInComplete: [],
      documentName: [],
      documentCode: [],
      documentVersion: [],
      folderName: [],
      folderCode: [],
      personName: [],
      selectedDocName: [],
      selectedDocCode: [],
      selectedDocVersion: [],
      selectedFoldName: [],
      selectedFoldCode: [],
      selectedPersName: [],
      selectedFundamental: [],
      selectedDueDate: [],
      filterObj: [],
      componentStatus: false,
      activeTab: 'newInComplete',
      selectedOpenDay: [],
      selectedDueDay: [],
      selectedManualName: [],
      t: props.t,
      emailCheckBox: [],
      sendMailStatus: false,
      popUpMsgStatus: false,
      msgError: '',
      msgData: '',
      newOpenFilter: { label: 'Both', value: window.RUBOTH }

    }
    this.handleFundCheck = this.handleFundCheck.bind(this);
    this.handleTabs = this.handleTabs.bind(this);
    this.constructExportData = this.constructExportData.bind(this);
    this.handleChangeMultiSelect = this.handleChangeMultiSelect.bind(this);

  }
  constructExportData(currentDetails, alldetails, conversation) {
    console.log(currentDetails[0]);
    console.log(alldetails);
    var data = {};
    data.alldetails = alldetails;
    data.currentDetails = currentDetails;
    data.conversation = conversation;
    datasave.service('/api/export-read-details', "POST", data)
      .then(response => {
        var a = document.createElement("a");
        a.setAttribute("type", "file");
        a.href = response.file;
        a.download = response.name;
        document.body.appendChild(a);
        a.click();
        a.remove();
      });

  }

  handleEmailCheckBox(checked, todoId) {
    let tempEmailCheck = this.state.emailCheckBox;
    let result = [];
    if (checked) {
      tempEmailCheck.push(todoId);
      this.handleCheckSetState('emailCheckBox', tempEmailCheck);
    } else {
      tempEmailCheck.map(id => {
        if (id != todoId) { result.push(id); }
      })
      this.handleCheckSetState('emailCheckBox', result);
    }
  }

  handleCheckSetState(name, value) {
    this.setState({
      [name]: value
    })
  }

  getListOfData() {
    let table = [];
    const { t } = this.state;
    if (this.state.componentStatus) {
      let tempVar = this.state.currentDetails;
      let details = this.state.alldetails;
      tempVar.map(key => {
        table.push(
          <div>
            <div className="card read-listofdata input_sw" >
              <p>{details[key]['person_name']}{' - '}{t('Received on:')}{details[key]['received_on']}</p>
              <p>{details[key]['document_code']}{' - '}{details[key]['document_name']}{' - '} {details[key]['document_version']}{' - '}{details[key]['folder_code']}{' - '}{details[key]['folder_name']}</p>
              <p>{details[key]['manual_name']}</p>
              <p>{(details[key]['fundamental']) ? 'Fundamental' : 'Not fundamental'}</p>
              <p>DD:{details[key]['due_date'] ? details[key]['due_date'] : '--/--/----'} - {details[key]['days_open']} {t('days open')}  -  {details[key]['due_days']} {t('days passed')}
              </p>
              <CheckBox
                tick={this.state.emailCheckBox.indexOf(details[key]['id']) != -1 ? true : false}
                style={{ paddingLeft: '0px' }}
                onCheck={(e) => this.handleEmailCheckBox(e.target.checked, details[key]['id'])}
              />
              {this.todoStatus(key, details)}
            </div>
          </div>
        )
      })
    }
    return table;
  }

  todoStatus(key, details) {
    const { t } = this.state;
    let table = [];
    if (details[key]['type'] == 1) {
      table.push(<div>
        {t('New')}
      </div>)
    } else if (details[key]['type'] == 2) {
      table.push(
        <div>
          <div>{t('Completed on:')} {details[key]['read_at']}</div>
          {/* {'Completed'} */}
        </div>
      )
    } else if (details[key]['type'] == 3) {
      table.push(
        <div>
          <div>
            {(this.state.completedTodos.indexOf(key) !== -1) ? <div>
              {t('Completed on: ')} {details[key]['read_at']}
              {/* <div>Completed</div> */}
            </div> : t('Open')}
          </div>
          <div style={{ height: '100px', 'overflow-x': 'auto', border: 'solid 1px grey' }}>
            {this.conversationLoop(key)}
          </div>
        </div>
      )
    }
    return table;
  }

  conversationLoop(key) {
    let table = [];
    let tempArr = this.state.conversation[key];
    const { t } = this.state;
    tempArr.map(key => {
      table.push(
        <div>
          <h5>{(key['comment_type'] == 2) ? t('comment') : t('feedback')}</h5>
          <p>{key['person_name']}</p>
          <p>{key['comment']}</p>
          <p>{t('Received on: ')}{key['received_on']}</p>
          <p>{(key['comment_type'] == 2) ? t('Commented at') : t('Feedback at')}{': '}{key['read_at']}</p>
          {(key['read_or_not'] == 1) ? <p>{t('Completed')}</p> : ''}
        </div>
      )
    })
    return table;
  }
  
  getSelectedActiveTabDetails = (activeTab, newOpenFilter) =>{
   const { inCompleteTodos, newTodos } = this.state;   
   if(activeTab === 'newInComplete'){
   return newOpenFilter['value'] !== window.RUBOTH ? (newOpenFilter['value'] ===  window.RUNEW ? newTodos : inCompleteTodos) : this.state[activeTab]; 
   }else{
   return this.state[activeTab];
   }
  }

  handleTabs(key) {
    // this.setState({
    //   currentDetails: this.state[key],
    //   activeTab: key,
    //   selectedOpenDay: [],
    //   selectedDueDay: [],
    //   selectedDocName: [],
    //   selectedDocCode: [],
    //   selectedDocVersion: [],
    //   selectedFoldName: [],
    //   selectedFoldCode: [],
    //   selectedPersName: [],
    //   selectedFundamental: [],
    //   selectedManualName: [],
    // })
	  
    this.handleFilter(this.state.filterObj, 'activeTab', key, this.getSelectedActiveTabDetails(key, this.state.newOpenFilter), {})

  }
  handleFundCheck(event, statename, name) {
    var filter1 = this.state.filterObj;
    var indexTemp = [];
    if (event.target.checked) {
      var checkObj = [{ value: 1, label: "", name: name, statename: statename }];
      filter1 = filter1.concat(checkObj);
      this.handleFilter(filter1, statename, checkObj,this.getSelectedActiveTabDetails(this.state.activeTab, this.state.newOpenFilter), {});
    } else {
      filter1.map((key, index) => {
        if (key['statename'] === statename) {
          indexTemp.push(index);
        }
      })
      filter1 = this.handleFilterAdd(filter1, indexTemp, []);
      this.handleFilter(filter1, statename, [], this.getSelectedActiveTabDetails(this.state.activeTab, this.state.newOpenFilter), {});
    }
  }

  handleChangeMultiSelect(event, name) {
    var filter1 = this.state.filterObj;
    let indexTemp = [];
    let filupdated = 0;
    let count = 0;
    let length = filter1.length;
    if (filter1.length > 0) {
      filter1.map((key, index) => {
        if (key['statename'] === name) {
          indexTemp.push(index);
        }
      })
      filter1 = this.handleFilterAdd(filter1, indexTemp, event);
      this.handleFilter(filter1, name, event, this.getSelectedActiveTabDetails(this.state.activeTab, this.state.newOpenFilter), {});
    } else {
      filter1 = filter1.concat(event);
      this.handleFilter(filter1, name, event, this.getSelectedActiveTabDetails(this.state.activeTab, this.state.newOpenFilter), {});
    }
  }

  handleFilterAdd(filter, indexTemp, event) {
    let tempArr = [];
    for (var i = 0; i < filter.length; i++) {
      if (indexTemp.indexOf(i) === -1) {
        tempArr.push(filter[i]);
      }
    }
    return tempArr.concat(event);
  }

  handleFilter(filter1, name, event, activeTabDetails, setObj) {
    var filterdup = filter1;
    if (filter1.length === 1) {
      var filterResult = [];
      filter1.map((key, index) => {
        filterResult = filterResult.concat(this.filterForDetails(key['name'], key['value']));
      })
      var activeDetails = activeTabDetails;//this.state[this.state.activeTab];
      let finalFilter = filterResult.filter(x => activeDetails.includes(x));
      this.handleSetState(name, event, 'filterObj', filterdup, 'currentDetails', finalFilter, setObj);
    } else if (filter1.length > 1) {
      var filterResult = [];
      filter1.map((key, index) => {
        filterResult = filterResult.concat(this.filterForDetails(key['name'], key['value']));
      })
      var activeDetails = activeTabDetails;//this.state[this.state.activeTab];
      var reqLength = this.countDuplicates(filter1);
      var duplicateResult = this.searchForDuplicates(filterResult, reqLength);
      let finalFilter = duplicateResult.filter(x => activeDetails.includes(x));
      this.handleSetState(name, event, 'filterObj', filterdup, 'currentDetails', finalFilter, setObj);
    } else {
      this.handleSetState(name, event, 'filterObj', filterdup, 'currentDetails', activeTabDetails, setObj);
    }
  }

  handleSetState(name1, value1, name2, value2, name3, value3, setObj) {
      setObj[name1] = value1;
      setObj[name2] = value2;
      setObj[name3] = value3;
    this.setState(setObj);
  }

  countDuplicates(filter) {
    var length = filter.length;
    var temp = [];
    for (var i = 0; i < length; i++) {
      temp.push(filter[i]['statename']);
    }
    temp = temp.filter(function (x, i, a) {
      return a.indexOf(x) == i;
    });
    return temp.length;
  }
  searchForDuplicates(data, reqLength) {
    var length = data.length;
    var temp = [];
    var count = 1;
    if (reqLength > 1) {
      for (var i = 0; i < length - 1; i++) {
        count = 1;
        for (var j = i + 1; j < length; j++) {

          if (data[i] === data[j]) {
            count++;
          }
        }
        if (reqLength === count) {
          temp.push(data[i]);
        }
      }
    } else {
      temp = data;
    }
    return temp;
  }

  handleOnChange(e, statename, name) {
    var filter1 = this.state.filterObj;
    var indexTemp = [];
    if (e.target.value !== '') {
      var checkObj = [{ value: e.target.value, label: "", name: name, statename: statename }];
      filter1.map((key, index) => {
        if (key['statename'] === statename) {
          indexTemp.push(index);
        }
      })
      filter1 = this.handleFilterAdd(filter1, indexTemp, []);
      filter1 = filter1.concat(checkObj);
      this.handleFilter(filter1, statename, checkObj, this.getSelectedActiveTabDetails(this.state.activeTab, this.state.newOpenFilter), {});
    } else {
      filter1.map((key, index) => {
        if (key['statename'] === statename) {
          indexTemp.push(index);
        }
      })
      filter1 = this.handleFilterAdd(filter1, indexTemp, []);
      this.handleFilter(filter1, statename, [], this.getSelectedActiveTabDetails(this.state.activeTab, this.state.newOpenFilter), {});
    }
  }
  ////////////////////
  // Examples
  ////////////////////


  countCurrentVsActive() {
    var {t} =this.state;
    var table = [];
    table.push(<div style={{ padding: '5px 0px' }}>
      {this.state.activeTab == 'newInComplete' ? t('New/Open') : t('Completed')}
      : {this.state.currentDetails.length}/{(this.getSelectedActiveTabDetails(this.state.activeTab, this.state.newOpenFilter)).length}
    </div>);
    // <div>New/Open:{this.state.newInComplete.length}
    //   Completed:{this.state.completedTodos.length}</div>
    return table;
  }

  filterForDetails(name, value) {
    var temp = [];
    var alldetails = this.state.alldetails;
    Object.keys(alldetails).forEach(function (key) {
      if (name == 'days_open' || name == 'due_days') {
        if (alldetails[key][name] >= parseInt(value)) {
          temp.push(key)
        }
      } else if (name == 'due_date') {
        console.log(key)
        if (alldetails[key][name] != '' && alldetails[key][name] != null) {
          var d1 = new Date(alldetails[key][name].split("-").reverse().join("-"));
          var d2 = new Date(value);
          if (d1.getTime() === d2.getTime()) {
            temp.push(key)
          }
        }
      } else {
        if (alldetails[key][name] === value) {
          temp.push(key)
        }
      }
    });
    return temp;
  }

  handleDisplayMsgPOpUp() {
    if (this.state.emailCheckBox.length > 0) {
      this.setState({
        popUpMsgStatus: true,
        sendMailStatus: true,
        msgError: '',
        msgData: ''
      })
    } else {
      alert('Please select todos to send mail');
    }
  }

  handleCloseMsgPopUp() {
    this.setState({
      popUpMsgStatus: false,
      sendMailStatus: false,
      msgError: '',
      msgData: ''
    })
  }
  handleMsgData(value) {
    this.setState({
      msgData: value,
    })
  }
  handleMsgPopSave() {
    if (this.state.msgData != '') {

      this.handleMailSend(this.state.emailCheckBox);
    } else {
      this.setState({
        msgError: 'Message is mandatory',
      })
    }

  }

  displayMsgPopUp() {
    const { t } = this.state;
    let table = [];
    if (this.state.sendMailStatus) {

      table.push(
        <div>
          <reactbootstrap.Modal show={this.state.popUpMsgStatus} onHide={(e) => { this.handleCloseMsgPopUp() }}>
            <reactbootstrap.Modal.Header closeButton>
              <reactbootstrap.Modal.Title>{t('Message box')}</reactbootstrap.Modal.Title>
            </reactbootstrap.Modal.Header>
            <reactbootstrap.Modal.Body>
              <label>
                {t('Message')} : <textarea placeholder="Enter your message" rows="4" cols="40" value={this.state.msgData} onChange={(e) => { this.handleMsgData(e.target.value) }} />
                <p style={{ color: 'red' }}>{this.state.msgError}</p>
              </label>
            </reactbootstrap.Modal.Body>
            <reactbootstrap.Modal.Footer>
              <reactbootstrap.Button variant="secondary" onClick={(e) => { this.handleMsgPopSave() }}>
                {t('Submit')}
              </reactbootstrap.Button>
              <reactbootstrap.Button variant="primary" onClick={(e) => { this.handleCloseMsgPopUp() }}>
                {t('Cancel')}
              </reactbootstrap.Button>
            </reactbootstrap.Modal.Footer>
          </reactbootstrap.Modal>
        </div>
      )

    }
    return table;
  }

  handleMailSend(todoIds) {
    const { t } = this.state;
    let Userdata = store.getState();

    let eventUser = Userdata.UserData.user_details.user_name;
    let eventPersonId = Userdata.UserData.user_details.person_id;
    let data = {
      readUnIds: todoIds,
      message: this.state.msgData,
      openOrComplete: this.state.activeTab == 'newInComplete' ? 1 : 0,
      event_user: eventUser,
      event_PersonId :eventPersonId,
    }
    datasave.service(window.READUN_MAIL_SEND, 'POST', data)
      .then(result => {
        if (result['status'] == 200) {
          OCAlert.alertSuccess(t('Mail sent successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
          this.setState({
            popUpMsgStatus: false,
            sendMailStatus: false,
            emailCheckBox: []
          })
        } else {
          OCAlert.alertError(t(result['Msg']), { timeOut: window.TIMEOUTNOTIFICATION });
          this.setState({
            popUpMsgStatus: false,
            sendMailStatus: false,
            emailCheckBox: []
          })
        }
      });
  }

  handleDeleteTodos() {
    const {t} = this.state;
    if(this.state.emailCheckBox.length > 0) {
      let data = {
        todo_ids :this.state.emailCheckBox,
      }
      datasave.service( window.DELETE_SELECTED_READUN_TODOS, 'POST', data)
          .then(result => {
            if(result.status === 'success'){
              OCAlert.alertSuccess(t('Deleted todos successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
              this.setState({emailCheckBox:[]});
              this.getReadUnDetails();
            }
          });
     }
     else {
      OCAlert.alertWarning(t('Please select todos to delete'), { timeOut: window.TIMEOUTNOTIFICATION });
     }
  }

  handleSingleSelectChange = (name, value) =>{
    this.handleFilter(this.state.filterObj, name, value, this.getSelectedActiveTabDetails(this.state.activeTab, value), {})
  }

  render() {
    const { t } = this.state;
    console.log('state');
console.log(this.state);
    if (this.state.componentStatus) {
      return (
        <div className='container-fluid  row col-md-12' >
          <div style={{ visibility: 'hidden' }} className="col-md-1"><p>{t('welcome')}</p></div>
          <div className="col-md-11 mt-4 mb-5 pl-0">
            <div className='row justify-content-center' >
              <div style={{ height: '475px', overflowY: 'auto', scrollbarWidth: 'thin' }} className='col-md-4 mr-4 readunderstand-folder'>
                <div>
                  {/* <label>  */}
                  <div style={{ display: 'flex', width: '50px', marginLeft: '-13px' }}  >
                    <CheckBox
                      value={this.state.selectedFundamental}
                      tick={(this.state.selectedFundamental.length > 0) ? true : false}
                      style={{ paddingLeft: '0px' }}
                      onCheck={(e) => this.handleFundCheck(e, "selectedFundamental", 'fundamental')}
                    />
                    <p style={{ margin: '0px', paddingTop: '10px' }}>{t('Fundamental')}</p>
                  </div>
                  <label>
                    {t('Amount of days open:')}
                  </label>
                  <div >
                    <input style={{ padding: '8px 10px', border: '1px solid lightgray' }} className="input_sw mb-3 col-md-12" type={'text'} value={this.state.selectedOpenDay.length > 0 ? this.state.selectedOpenDay['value'] : ''} onChange={(e) => this.handleOnChange(e, "selectedOpenDay", 'days_open')} >
                    </input>
                  </div>
                  <label>
                    {t('Amount of days passed due date:')}
                  </label>
                  <div >
                    <input style={{ padding: '8px 10px', border: '1px solid lightgray' }} className="input_sw mb-3 col-md-12" type={'text'} value={this.state.selectedDueDay.length > 0 ? this.state.selectedDueDay['value'] : ''} onChange={(e) => this.handleOnChange(e, "selectedDueDay", 'due_days')} >
                    </input>
                  </div>
                  <label>
                    {t('Due date:')}
                  </label>
                  <div >
                    <input style={{ padding: '8px 10px', border: '1px solid lightgray' }} className="input_sw mb-3 col-md-12" type={'date'} onChange={(e) => this.handleOnChange(e, "selectedDueDate", 'due_date')}>
                    </input>
                  </div>

                  {/* </label> */}
                </div>
                <label>
                  {t('Document code:')}
                </label>
                <div className="input_sw mb-3">
                  <MultiSelect
                    options={this.state.documentCode}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.selectedDocCode}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedDocCode")}
                  />
                </div>
                <label>
                  {t('Document name:')}
                </label>
                <div className="input_sw mb-3">
                  <MultiSelect
                    options={this.state.documentName}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.selectedDocName}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedDocName")}
                  />
                </div>

                <label>
                  {t('Document version:')}
                </label>
                <div className="input_sw mb-3">
                  <MultiSelect
                    options={this.state.documentVersion}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.selectedDocVersion}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedDocVersion")}
                  />
                </div>
                <label>
                  {t('Folder name:')}
                </label>
                <div className="input_sw mb-3">
                  <MultiSelect
                    options={this.state.folderName}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.selectedFoldName}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedFoldName")}
                  />
                </div>
                <label>
                  {t('Folder code:')}
                </label>
                <div className="input_sw mb-3">
                  <MultiSelect
                    options={this.state.folderCode}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.selectedFoldCode}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedFoldCode")}
                  />
                </div>
                <label>
                  {t('Person name:')}
                </label>
                <div className="input_sw mb-3">
                  <MultiSelect
                    options={this.state.personName}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.selectedPersName}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedPersName")}
                  />
                </div>
                <label>
                  {t('Manual name:')}
                </label>
                <div className="input_sw mb-3">
                  <MultiSelect
                    options={this.state.manualName}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.selectedManualName}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedManualName")}
                  />
                </div>
              </div>
              <div className='col-md-7 card-body readunderstand-folder pt-2 pb-2' >
                <div>
                  <div className="">
                    <reactbootstrap.Tabs id='controlled-tab-example' activeKey={this.state.activeTab} onSelect={k => this.handleTabs(k)}>
                      <reactbootstrap.Tab eventKey="newInComplete" title={t("New/Open")}>
                      </reactbootstrap.Tab>
                      <reactbootstrap.Tab eventKey="completedTodos" title={t("Completed")}>
                      </reactbootstrap.Tab>
                    </reactbootstrap.Tabs>
                  </div>
                  {this.countCurrentVsActive()}
	      <div>
	      {this.state.activeTab === 'newInComplete' &&  <MultiSelect
      			options={window.OPTIONS_BOTH_NEW_OPEN}
      			standards={this.state.newOpenFilter}
      			isMulti={false}
     	 		style={{ width: "100%" }}
      			handleChange={(e) => this.handleSingleSelectChange('newOpenFilter', e)}
      		/>}	   
	      </div>
                  {/* <div>New/Open:{this.state.newInComplete.length} Completed:{this.state.completedTodos.length}</div> */}
                  <div className="read-listof-data">
                    {this.getListOfData()}
                  </div>
                </div>
                <reactbootstrap.Button className="mt-2 mr-3" onClick={() => this.constructExportData(this.state.currentDetails, this.state.alldetails, this.state.conversation)}>{t('Export XLS')}</reactbootstrap.Button>
                <reactbootstrap.Button className="mt-2 mr-3" onClick={(e) => this.handleDisplayMsgPOpUp()}>{t('Send Mail')}</reactbootstrap.Button>
                <reactbootstrap.Button className="mt-2" onClick={(e) => this.handleDeleteTodos()}>{t('Delete Todos')}</reactbootstrap.Button>
                {this.displayMsgPopUp()}
              </div>
            </div>
          </div>
        </div>
      )
    } else {
      return (
        <div className="col-md-12 row">
          <div style={{ visibility: 'hidden' }} className="col-md-1"><p>{t('welcome')}</p></div>
          <div style={{ marginLeft: '-0.5rem' }} className='col-md-11' >
            <h4>{t('Loading.....')}</h4>
          </div>
        </div>
      )

    }
  }

  componentDidMount() {
    this.getReadUnDetails();
  }

  getReadUnDetails(){
    datasave.service(window.GET_READ_DETAIL, 'GET')
      .then(response => {
        if (response) {
          let setObj = {
          };
        this.setState({
            allTodos: response['AllTodos'],
            completedTodos: response['CompletedTodos'],
            inCompleteTodos: response['InCompleteTodos'],
            newTodos: response['NewTodos'],
            conversation: response['Conversation'],
            alldetails: response['Details'],
            currentDetails: response['NewInComplete'],
            newInComplete: response['NewInComplete'],
            documentName: response['DocumentName'],
            documentCode: response['DocumentCode'],
            documentVersion: response['DocumentVersion'],
            folderName: response['FolderName'],
            folderCode: response['FolderCode'],
            personName: response['PersonName'],
            manualName: response['ManualName'],
            componentStatus: true
        }, function(){
        if(this.state.filterObj.length > 0){
        this.handleFilter(this.state.filterObj, '', [], this.getSelectedActiveTabDetails(this.state.activeTab, this.state.newOpenFilter), {});
        }
        })        
       }
      })

  }
}
export default translate(ReadUnderstandOverview);
