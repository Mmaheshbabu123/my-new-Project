import React, { Component } from 'react';
import { datasave } from './_services/db_services';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
// import DragnDrop from './DragnDrop'
import PJDGdragndrop from './PJDGdragndrop'
import * as reactbootstarp from 'react-bootstrap'
import Pagination from 'react-bootstrap/Pagination'
import {filterArray} from './_helpers/filter-array'
import Can from './_components/CanComponent/Can';
import {CanPermissions} from './_components/CanComponent/CanPermissions';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import { persistor, store } from './store';

import { translate } from './language';

class Jobs extends Component {
  constructor(props) {
    super(props)
    const details_tab_access = CanPermissions("E_job", "");
    this.state = {
      save: props.t('Save'),
      available_field_screen: true,
      active_job: true,
      submitted: false,
      loading: false,
      error: '',
      savevalue: 'true',
      name: '',
      description: '',
      abbrevation: '',
      groups: [],
      persons: [],
      departments: [],
      checked: true,
      status: 1,
      tasks: [],
      types: [],
      items: [],
      selected: [],
      tabs: [],
      active_tab: (details_tab_access) ? 1: window.MEMBER_OF,
      job_id: false,
      disableFields: false,
      oldname:'',
      show:false,
      jobdetails:[],
      currentPage: 1,
      todosPerPage: 5,
      pop:'',
      nodata:'',
      linked:'false',
      t:props.t,
      jobId: this.props.match!=undefined?this.props.match.params.id:0,
    }
    this.updateSelected = this.updateSelected.bind(this);
    this.handleActiveTab = this.handleActiveTab.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    // this.handleCheck = this.handleCheck.bind(this);
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.uniqueId !== this.props.uniqueId) {
      this.setState({
        name: '',
        description: '',
        abbrevation: '',
        selected: [],
      })
    }
  }

  componentDidMount() {
    const jobs_id = this.state.jobId;
    if(this.props.handleSelect!==undefined)
    this.props.handleSelect('/managemyorganisation/createjobs')
    this.setState({
      job_id: jobs_id,
    });
    if (this.state.jobId) {
      var url = window.GET_JOBS + '/' + jobs_id;
      datasave.service(url, "GET")
        .then(response => {
          // axios.get(process.env.REACT_APP_serverURL + `/api/jobs/${jobs_id}`).then(response => {
          this.setState({
            name: response['job_details'][0]['name'],
            oldname:response['job_details'][0]['name'],
            description: response['job_details'][0]['description'],
            abbrevation: response['job_details'][0]['abbrevation'],
            cloneabbrevation :response['job_details'][0]['abbrevation'],
            active_job: response['job_details'][0]['status'],
            available_field_screen: response['job_details'][0]['available_field_screen'],
            //status:response.data.job_details[0]['status'],
            tasks: response['jgd'],
            items: response['jgd'],
            types: response['types'],
            tabs: response['tabs'],
            selected: response['selected'],
          })
        })

    } else {
      // Get Groups, Departments, persons details
      var url = window.JOB_LINK;
      datasave.service(url, "GET")
        //axios.get(process.env.REACT_APP_serverURL + `/api/alljoblinkdetails`)
        .then(response => {
          this.setState({
            tasks: response['jgd'],
            items: response['jgd'],
            types: response['types'],
            tabs: response['tabs'],
            selected: [],
          })
        })
    }
  }
  componentWillMount(){
    if(this.state.jobId){
    var url = window.GET_LINKED_JOBS+ '/'+this.state.jobId;
    datasave.service(url,'GET',)
      .then(response => {
        if(response !== 0){
             this.setState({
               linked:'true'
             })
           }

        })
  }
}

  handleSubmit(event) {
    event.preventDefault()
    this.setState({ submitted: true });
    this.setState({
      savevalue: '',
      save: 'Please wait ...'
    })
    const { history } = this.props
    const details = {
      name: this.state.name,
      oldname:this.state.name,
      description: this.state.description,
      abbrevation: this.state.abbrevation,
      groups: this.state.groups,
      departments: this.state.departments,
      persons: this.state.persons,
      status: this.state.active_job,
      available_field_screen: this.state.available_field_screen,
      membersof: { ...this.state.selected },
    }
    if (this.state.jobId) {
      const jobsId = this.state.jobId;
      if (this.state.oldname === this.state.name) {
        this.handleOk();
      }
      else {
        const url1 = window.JOB_DETAILS + jobsId;
        datasave.service(url1,'GET')
        .then(response => {
          if(response.selected.length !== 0){
          this.setState({
            jobdetails: response.selected,
            show: true,
            currentpage:1,
            pop:true,
          })
        } else{
          this.setState({
          nodata:true,
          show:true,
          pop:true
        })
        }
        })
        /*this.setState({
          currentpage:1,
          pop:true,
        })*/
      }
    }
    else {
     var url = window.INSERT_JOBS;
     var method = 'POST';
     var  data = details;
      datasave.service(url, method, data)
        .then(result => {
          if (result.name) {
            this.setState({
              error: result.name
            })
          }
          else if (result === 1) {
            this.props.handlePageChange();
            // history.push('/managemyorganisation/managejobs')
            // if(this.props.handleSelect!==undefined)
            // this.props.handleSelect('/managemyorganisation/managejobs')
          }
        })
        .catch(error => {
          this.setState({
            errors: error.response.data.errors
          })
        })
    }
  }
 handleOk() {
  this.setState({ submitted: true });
    this.setState({
      savevalue: '',
      save: 'Please wait ...'
    })
    let Userdata = store.getState();
        const pid = Userdata.UserData.user_details.person_id;

    const { history } = this.props
    const details = {
      name: this.state.name,
      oldname:this.state.oldname,
      description: this.state.description,
      abbrevation: this.state.abbrevation,
      groups: this.state.groups,
      departments: this.state.departments,
      persons: this.state.persons,
      status: this.state.active_job,
      available_field_screen: this.state.available_field_screen,
      membersof: { ...this.state.selected },
      modifyname:this.state.name!== this.state.oldname ? 1:0,
      modifyabbrevation: this.state.cloneabbrevation !== this.state.abbrevation ? 1:0,
      cloneabbrevation :this.state.cloneabbrevation,
      pid : pid
    }

    if (this.state.jobId) {
      const jobsId = this.state.jobId;
      var url = window.INSERT_JOBS + '/' + jobsId;
      var method = 'PUT';
      var data = details;
      datasave.service(url, method, data)
        .then(result => {
          if (result.name) {
            this.setState({
              error: result.name
            })
          }
          else if (result === 1) {
            history.push('/managemyorganisation/managejobs')
            if(this.props.handleSelect!==undefined)
            this.props.handleSelect('/managemyorganisation/managejobs')

          }
        })
        .catch(error => {
          this.setState({
            errors: error.response.data.errors
          })
        })
    }
  }

  handleExport(){
    const jobsId = this.state.jobId;
    var url = window.EXPORT_JOBS +jobsId;
    var details ={
      name:this.state.name,
      oldname:this.state.oldname,
    }
    datasave.service(url,'PUT',details)
    .then( response =>{
      window.open(response);
      window.close();
    })
    this.setState({
      show:false,
    })
  }

  handleCancel(event) {
    const { history } = this.props
    if (this.state.jobId==0) {
      this.props.handlePageChange();
      // history.push('/managemyorganisation/managejobs');
      // if(this.props.handleSelect!==undefined)
      //   this.props.handleSelect('/managemyorganisation/managejobs')
    } else {
      history.push('/managemyorganisation/managejobs')
      if(this.props.handleSelect!==undefined)
      this.props.handleSelect('/managemyorganisation/managejobs')

    }

  }
  updateSelected = (latestDropped, result, type, id = '') => {
    var array = [...this.state['selected']]; // make a separate copy of the array
    if (result.type === 'remove') {
        var filterArray = array.filter(selected => (selected.id !== latestDropped.id));
    }
    if (result.type === 'remove') {
        this.setState({
            selected: filterArray,
        })
    }
    else {
        this.setState(prevState => ({
            selected: [...prevState['selected'], latestDropped]
        }));
    }
  }

  handleActiveTab(key) {
    this.setState({
      active_tab: key,
    });
  }

  handlehide = () => {
    this.setState({ show: false })
  }

  handlePopupCancel() {
    this.setState(
      { show: false }
    )
  }

  handlePageClick(event) {
    this.setState({
      currentPage: Number(event.target.id)
    });
  }

  render() {
    const dataLOU = CanPermissions("LOU", "");
    const details_tab_access = CanPermissions("E_job", "");
    let details_tab_disable = (details_tab_access) ? '' : 'disabled';
    const{jobdetails, currentPage, todosPerPage,t} =this.state;
    const indexOfLastTodo = currentPage * todosPerPage;
    const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
    const currentTodos = jobdetails.slice(indexOfFirstTodo, indexOfLastTodo);
    const pagerender = currentTodos.map(person => {
      return (
        <tr>
        <td>{person.name}</td>
        <td>{person.category}</td>
        </tr>
      )
    });
    const pageNumbers = [];
    if(this.state.jobdetails.length >5){
    for (let i = 1; i <= Math.ceil(this.state.jobdetails.length / todosPerPage); i++) {
      pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
        {i}
      </Pagination.Item>);
    }
  }
    const popup = (
      <reactbootstarp.Modal
          show={this.state.show}
          onHide={this.handlehide}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
          <reactbootstarp.Modal.Header closeButton>
              <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
              </reactbootstarp.Modal.Title>
              <reactbootstarp.Modal.Body col-md-12 pr-0>
                  <reactbootstarp.Table responsive striped bordered hover size="sm">
                      <thead>
                          <tr>
                          <td>{t('Name')}</td>
                          <td>{t('Category')}</td>
                          </tr>
                      </thead>
                      <tbody>
                      {this.state.nodata === true && <tr class =  "text-center"><span style = {{marginLeft:'20px'}} >{t('No records found')}</span></tr>}
                      {pagerender}
                      </tbody>
                  </reactbootstarp.Table>
                  <Pagination size="sm" style={{width: '410px', overflow: 'auto'}} >{pageNumbers}</Pagination>
                   <reactbootstarp.FormLabel>{t('Old name')}</reactbootstarp.FormLabel>
                   <reactbootstarp.Form.Control type="text" value = {this.state.oldname}/>
                   <reactbootstarp.FormLabel>{t('New name')}</reactbootstarp.FormLabel>
                   <reactbootstarp.Form.Control type="text" value = {this.state.name}/>
            </reactbootstarp.Modal.Body>
          </reactbootstarp.Modal.Header>
          <reactbootstarp.Modal.Footer>
              <reactbootstarp.Button onClick={() => this.handlePopupCancel()}>{t('Cancel')}</reactbootstarp.Button>
              &nbsp;&nbsp; &nbsp;&nbsp;
              <reactbootstarp.Button onClick={() => this.handleOk()}>{t('Save')}</reactbootstarp.Button>
              <reactbootstarp.Button onClick={() => this.handleExport()}>{t('Export')}</reactbootstarp.Button>
          </reactbootstarp.Modal.Footer>
      </reactbootstarp.Modal>
  );
    const { name, oldname,description, submitted, loading, available_field_screen, types, pop,tasks, active_job, error } = this.state;
    const { active_tab } = this.state;
    var selected;
    var pack_fun = this.state.tasks;
    const linkTabs = Object.values(this.state.tabs).map(
      function (itemlist, key) {
        if (itemlist === window.MEMBER_OF) {
          // selected = this.state.selected.filter(items => (items.category_id === window.job_memberof_one || items.category_id === window.job_memberof_two))
          pack_fun = filterArray(this.state.tasks,this.state.selected);
        }
        else if (itemlist === window.MEMBER) {
          // selected = this.state.selected.filter(items => (items.category_id === window.job_member_one))
          pack_fun = filterArray(this.state.tasks,this.state.selected);
        }
        // itemlist.charAt(0).toUpperCase() + itemlist.slice(1)
        let disabled = (dataLOU) ? '' : 'disabled';
        return (
          <reactbootstarp.Tab disabled = {disabled} eventKey={itemlist} title={t(itemlist)}>
            <Can
              perform = "LOU"
              yes = {() => (
              <PJDGdragndrop
                organisatioal_unit= {"Jobs"}
                itemlist={itemlist}
                details={this.state}
                types={this.state.types[itemlist]}
                tasks= {pack_fun}
                items={pack_fun}
                active_tab={this.state.active_tab}
                type={"common"}
                selected={this.state.selected}
                updateProps={1}
                {...this}
                uniqueId={this.props.uniqueId}
                updateSelectedChild={this.updateSelected} />
              )}
            />
          </reactbootstarp.Tab>
        )
      }, this);

    return (
      <div className="col-md-12 row">
      {this.state.jobId!=0 && <div style={{visibility: 'hidden'}} className="col-md-1"><p>welcome</p></div>}
      <div style={{}} className='col-md-11' >
        <Can
          perform="E_job,LOU"
          yes={() => (
          <div className='' >
            <div className='col-md-12 mt-0 mb-0 p-0' >
              <div className='card' >
                <div className='card-body' >
                  <Container className="">
                    <Form onSubmit={this.handleSubmit}>
                      <reactbootstarp.Tabs activeKey={active_tab} onSelect={this.handleActiveTab} id="controlled-tab-example">
                        <reactbootstarp.Tab disabled = {details_tab_disable} eventKey={1} title={t("Job details")}>
                          <FormGroup>
                            <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
                            <div className=" row input-overall-sec ">
                              <InputGroup className="">
                              <div className="col-md-4">
                                <InputGroup.Prepend>
                                  <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Name')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd">
                                <FormControl
                                  placeholder={t("Job name")}
                                  aria-label="Functionname"
                                  aria-describedby="basic-addon1"
                                  value={this.state.name}
                                  onChange={e => this.setState({ name: e.target.value })}
                                  className="input_sw"
                                />
                                <div style={{ color: 'red'}} className="error-block mt-2">{error}</div>
                                </div>
                              </InputGroup>

                            </div>
                            </div>
                          </FormGroup>
                          <FormGroup>
                          <div className=" row input-overall-sec ">
                          <div className="col-md-4">
                            <InputGroup.Prepend>
                              <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Description')}:</InputGroup>
                            </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                            <FormControl
                              style={{ height: '100px' }}
                              as="textarea" rows="3"
                              placeholder={this.props.placeholder !== undefined ? t(this.props.placeholder) : ''}
                              value={this.state.description}
                              onChange={e => this.setState({ description: e.target.value })}
                              className="input_sw"
                            />
                            </div>
                            </div>
                          </FormGroup>
                          <FormGroup>
                          <div className=" row input-overall-sec ">
                            <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Abbreviation')}:</InputGroup>
                              </InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd">
                              <FormControl
                                placeholder={t("Abbreviation")}
                                aria-label="UniqueKey"
                                aria-describedby="basic-addon1"
                                value={this.state.abbrevation}
                                onChange={e => this.setState({ abbrevation: e.target.value })}
                                className="input_sw"
                              />
                              </div>
                            </InputGroup>
                            </div>
                          </FormGroup>
                          <Form.Group>
                            <Form.Check
                              onChange={e => this.setState({ available_field_screen: !available_field_screen })}
                              name='available_in_master_data'
                              checked={available_field_screen}
                              label={t("Available in master data")}
                            />
                          </Form.Group>
                          {/* <Form.Group>
                            <Form.Check
                              onChange={e => this.setState({ active_job: !active_job })}
                              name='active_job'
                              checked={active_job}
                              label={t("Active job")}
                            />
                          </Form.Group> */}
                        </reactbootstarp.Tab>
                        {linkTabs}
                      </reactbootstarp.Tabs>
                      <FormGroup>
                      <div style={{ float: 'right' }} className="organisation_list">
                      <a onClick={this.handleCancel} > {t('Cancel')} </a>
                       &nbsp;&nbsp;&nbsp;
                      <Button type="submit" disabled={loading} color="primary">{t('Save')}</Button>
                     </div>
                     </FormGroup>
                      {/* {loading &&
                        <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                      } */}
                  </Form>
                  {this.state.pop && popup}
                </Container>
              </div>
              </div>
            </div>
          </div>
          )}
          no={ () =>
            <AccessDeniedPage/>
          }
        />
      </div>
      </div>
    );
  }

}

export default translate(Jobs)
