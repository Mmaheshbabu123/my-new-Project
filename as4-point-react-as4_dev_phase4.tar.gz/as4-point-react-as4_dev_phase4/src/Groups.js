import React, { Component } from 'react';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
// import DragnDrop from './DragnDrop'
import PJDGdragndrop from './PJDGdragndrop';
import * as reactbootstarp from 'react-bootstrap';
import Pagination from 'react-bootstrap/Pagination'
import { datasave } from './_services/db_services';
import {filterArray} from './_helpers/filter-array';
//import axios from 'axios'
import Can from './_components/CanComponent/Can';
import {CanPermissions} from './_components/CanComponent/CanPermissions';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import {translate} from './language';

class Groups extends Component {
  constructor(props) {
    super(props)
    const details_tab_access = CanPermissions("E_group", "");

    this.state = {
      save: props.t('Save'),
      loading: false,
      submitted: false,
      active_group: true,
      available_field_screen: true,
      name_error: '',
      savevalue: 'true',
      name: '',
      description: '',
      abbrevation: '',
      jobs: [],
      departments: [],
      checked: true,
      status: 1,
      tasks: [],
      types: [],
      items: [],
      tabs: [],
      selected: [],
      active_tab: (details_tab_access) ? 1: window.MEMBER,
      disableFields: false,
      oldname:'',
      groupdetails:[],
      show:false,
      currentPage: 1,
      todosPerPage: 5,
      pop:'',
      nopop:'',
      allow_dragndrop: 'false',
      linked:'false',
      t:props.t,
      nodata:'',
      groupID : this.props.match!=undefined?this.props.match.params.id:0,
    }
    this.updateSelected = this.updateSelected.bind(this);
    this.handleActiveTab = this.handleActiveTab.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCheck = this.handleCheck.bind(this)
  }
  handleCancel(event) {
    const { history } = this.props
    // if (this.props.match.params.id) {
      if(this.state.groupID ==0) {
        this.props.handlePageChange();
      }else{
        history.push('/managemyorganisation/managegroup')
        if(this.props.handleSelect!==undefined)
        this.props.handleSelect('/managemyorganisation/managegroup')
      }
    // } else {
    //   history.push('/managemyorganisation/managegroup')
    //   this.props.handleSelect('/managemyorganisation/managegroup')
    //
    // }
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.uniqueId !== this.props.uniqueId) {
      this.setState({
        name: '',
        description: '',
        abbrevation: '',
        selected: [],
      })
    }
  }

  componentDidMount() {
    const group_id = this.state.groupID;
    if(this.props.handleSelect!==undefined)
    this.props.handleSelect('/managemyorganisation/creategroup')
    if (this.state.groupID) {
      var url = window.GET_GROUPS + '/' + group_id;
      datasave.service(url, "GET")
        .then(response => {
          this.setState({
            name: response['group_details'][0]['name'],
            oldname: response['group_details'][0]['name'],
            //package_details :response.data,
            description: response['group_details'][0]['description'],
            abbrevation: response['group_details'][0]['abbrevation'],
            checked: response['group_details'][0]['status'],
            active_group: response['group_details'][0]['status'],
            available_field_screen: response['group_details'][0]['available_field_screen'],
            selected: response['selected'],
            items: response['jgd'],
            tasks: response['jgd'],
            types: response['types'],
            tabs: response['tabs'],
          })
        })

    }
    else {
      // Get Deparments, Jobs details
      var url = window.GROUPS_LINK;
      datasave.service(url, 'GET')
        .then(response => {
          this.setState({
            tasks: response['jgd'],
            items: response['jgd'],
            types: response['types'],
            tabs: response['tabs'],
            selected: [],
          })
        })
    }
  }
  componentWillMount (){
      if(this.state.groupID) {
        var url = window.GET_LINKED_GROUP + '/'+this.state.groupID;
        datasave.service(url, 'GET',)
          .then(response => {
                if(response !== 0){
                  this.setState({
                      linked: 'true',
                  })
                }
              })
      }
  }
  handleCheck(e) {
    this.setState({ checked: !this.state.checked });
    var msg;
    if (this.state.checked) {
      msg = "checked";
      this.state.status = 0
    } else {
      this.state.status = 1
    }
  }
  handleSubmit(event) {
    event.preventDefault()
    const {t} = this.state;
    this.setState({ submitted: true });
    this.setState({
      savevalue: '',
      save: t('Please wait ...')
    })
    const { history } = this.props
    const details = {
      name: this.state.name,
      oldname:this.state.name,
      description: this.state.description,
      abbrevation: this.state.abbrevation,
      jobs: this.state.jobs,
      departments: this.state.departments,
      status: this.state.active_group,
      available_field_screen: this.state.available_field_screen,
      membersof: { ...this.state.selected },
    }
    if (this.state.groupID) {
      const groupId = this.state.groupID;

      if (this.state.oldname == this.state.name) {
        this.handleOk()
      }
      else {
        const url1 = window.GROUP_DETAILS + groupId;
        datasave.service(url1, 'GET',details)
        .then(response => {
          if(response.selected.length !== 0){
          this.setState({
            groupdetails:response.selected,
            show:true,
            currentPage:1,
            pop:true,
          })
        }else{
          this.setState({
            nodata:true,
            show:true,
            pop:true
          })
        }
        })
      }
  }
  else{
    var url = window.GET_GROUPS;
    datasave.service(url, 'POST', details)
      //axios.put(process.env.REACT_APP_serverURL + `/api/groups/${groupsId}`, details)
      .then(response => {
        if (response.name) {
          this.setState({
            error: response.name
          })
        }
        else {
          this.props.handlePageChange();
          // history.push('/managemyorganisation/managegroup')
          // if(this.props.handleSelect!==undefined)
          // this.props.handleSelect('/managemyorganisation/managegroup')
        }
      })
      .catch(error => {
        this.setState({
          error: error.response.errors
        })
      })
  }
}
  handlehide = () => {
    this.setState({ show: false })
  }

  handlePopupCancel() {
    this.setState(
      { show: false }
    )
  }

  handleExport() {
    const groupId = this.state.groupID;
    var url = window.EXPORT_GROUPS + groupId;
    var details ={
      name: this.state.name,
      oldname:this.state.oldname
    }
    datasave.service(url,'PUT',details)
    .then(response =>{
      window.open(response);
      window.close();
    })
  }

  handleOk() {
    const {t} = this.state;
    this.setState({ submitted: true });
    this.setState({
      savevalue: '',
      save: t('Please wait')
    })
    const { history } = this.props
    const details = {
      name: this.state.name,
      oldname:this.state.name,
      description: this.state.description,
      abbrevation: this.state.abbrevation,
      jobs: this.state.jobs,
      departments: this.state.departments,
      status: this.state.active_group,
      available_field_screen: this.state.available_field_screen,
      membersof: { ...this.state.selected },
    }
    if (this.state.groupID) {
      const groupsId = this.state.groupID;
      var url = window.GET_GROUPS + '/' + groupsId;
      datasave.service(url, 'PUT', details)
        //axios.put(process.env.REACT_APP_serverURL + `/api/groups/${groupsId}`, details)
        .then(response => {
          if (response.name) {
            this.setState({
              error: response.name
            })
          }
          else {
            history.push('/managemyorganisation/managegroup')
            if(this.props.handleSelect!==undefined)
            this.props.handleSelect('/managemyorganisation/managegroup')
          }
        })
        .catch(error => {
          this.setState({
            error: error.response.errors
          })
        })
    }
  }

  handlePageClick(event) {
    this.setState({
      currentPage: Number(event.target.id)
    });
  }

  updateSelected = (latestDropped, result, type, id = '') => {
    var array = [...this.state['selected']]; // make a separate copy of the array
    if (result.type === 'remove') {
      var filterArray = array.filter(selected => (selected.id !== latestDropped.id));
    }
    if (result.type === 'remove') {
      this.setState({
          selected: filterArray,
      })
    }
    else {
      this.setState(prevState => ({
          selected: [...prevState['selected'], latestDropped],
      }));
    }
}

  handleActiveTab(key) {
    this.setState({
      active_tab: key,
    });
  }
  render() {
    const dataLOU = CanPermissions("LOU", "");
    const details_tab_access = CanPermissions("E_group", "");
    let details_tab_disable = (details_tab_access) ? '' : 'disabled';
    const{groupdetails, currentPage, todosPerPage,pop,t} =this.state;
    const indexOfLastTodo = currentPage * todosPerPage;
    const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
    const currentTodos = groupdetails.slice(indexOfFirstTodo, indexOfLastTodo);
    const pagerender = currentTodos.map(person => {
      return <tr>
      <td>{person.name}</td>
      <td>{person.category}</td>
      </tr>
    });
    const pageNumbers = [];
    if(this.state.groupdetails.length > 5){
    for (let i = 1; i <= Math.ceil(this.state.groupdetails.length / todosPerPage); i++) {
      pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
        {i}
      </Pagination.Item>);
    }
  }
    const popup = (
      <reactbootstarp.Modal
          show={this.state.show}
          onHide={this.handlehide}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
          <reactbootstarp.Modal.Header closeButton>
              <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
              </reactbootstarp.Modal.Title>
              <reactbootstarp.Modal.Body col-md-12 pr-0>
                  <reactbootstarp.Table responsive striped bordered hover size="sm">
                      <thead>
                          <tr>
                              <td>{t('Name')}</td>
                              <td>{t('Category')}</td>
                          </tr>
                      </thead>
                      <tbody>
                      {this.state.nodata === true &&<tr class =  "text-center"><span style = {{marginLeft:'20px'}} >{t('No records found')}</span></tr>}
                      {pagerender}
                      </tbody>
                  </reactbootstarp.Table>
                  <Pagination size="sm" style={{width: '410px', overflow: 'auto'}} >{pageNumbers}</Pagination>
                   <reactbootstarp.FormLabel>{t('Old name')}</reactbootstarp.FormLabel>
                    <reactbootstarp.Form.Control type="text" value = {this.state.oldname}/>
                   <reactbootstarp.FormLabel>{t('New name')}</reactbootstarp.FormLabel>
                   <reactbootstarp.Form.Control type="text" value = {this.state.name}/>
            </reactbootstarp.Modal.Body>
          </reactbootstarp.Modal.Header>
          <reactbootstarp.Modal.Footer>
              <reactbootstarp.Button onClick={() => this.handlePopupCancel()}>{t('Cancel')}</reactbootstarp.Button>
              &nbsp;&nbsp; &nbsp;&nbsp;
          <reactbootstarp.Button onClick={() => this.handleOk()}>{t('Save')}</reactbootstarp.Button>
          <reactbootstarp.Button onClick={() => this.handleExport()}>{t('Export')}</reactbootstarp.Button>

          </reactbootstarp.Modal.Footer>
      </reactbootstarp.Modal>
  );
    const { name,oldname, description, submitted, active_group, available_field_screen, loading, error , active_tab} = this.state;
    var pack_fun = this.state.tasks;

    const linkTabs = Object.values(this.state.tabs).map(
      function (itemlist, key) {
          pack_fun = filterArray(this.state.tasks,this.state.selected);
          let disabled = (dataLOU) ? '' : 'disabled';
          let tabTitle=itemlist.charAt(0).toUpperCase() + itemlist.slice(1);
          return (
              <reactbootstarp.Tab disabled = {disabled} eventKey={itemlist} title={t(tabTitle)}>
                 <Can
                  perform = "LOU"
                  yes = {() => (
                    <PJDGdragndrop
                      organisatioal_unit= {"Groups"}
                      itemlist={itemlist}
                      details={this.state}
                      types={this.state.types[itemlist]}
                      items={pack_fun}
                      tasks={pack_fun}
                      active_tab={this.state.active_tab}
                      type={"common"}
                      selected={this.state.selected}
                      {...this}
                      uniqueId={this.props.uniqueId}
                      updateSelectedChild={this.updateSelected}
                    />
                  )}
                />
              </reactbootstarp.Tab>
          )
      }, this);
    return (
      <div className=" row col-md-12">
      {this.state.groupID!=0&&<div style={{visibility: 'hidden'}} className="col-md-1"><p>welcome</p></div>}
      <div style={{}} className='col-md-11' >
        <Can
          perform="E_group,LOU"
          yes={() => (
          <div className='' >
            <div className='col-md-12 p-0 mt-0' >
              <div className='card' >
                {/* <div className='card-header' > {t('Create group')} </div> */}
                <div className='card-body' >
                  <Container className="">
                    <Form onSubmit={this.handleSubmit}>
                      <reactbootstarp.Tabs activeKey={active_tab} onSelect={this.handleActiveTab} id="controlled-tab-example">
                        <reactbootstarp.Tab disabled = {details_tab_disable} eventKey={1} title={t("Group details")}>
                          <FormGroup>
                            <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>

                            <div className=" row input-overall-sec ">
                            <InputGroup className="">
                            <div className="col-md-4">
                                <InputGroup.Prepend>
                                  <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Name')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd">
                                <FormControl
                                  placeholder={t("Group name")}
                                  aria-label="Functionname"
                                  aria-describedby="basic-addon1"
                                  value={this.state.name}
                                  onChange={e => this.setState({ name: e.target.value })}
                                  className="input_sw"
                                />
                                <div style={{ color: 'red', }} className="error-block  mt-2">{error}</div>
                                </div>
                              </InputGroup>

                            </div>
                            </div>
                          </FormGroup>
                          <FormGroup>
                          <div className=" row input-overall-sec ">
                          <div className="col-md-4">
                            <InputGroup.Prepend>
                              <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Description')}:</InputGroup>
                            </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                            <FormControl
                              style={{ height: '100px' }}
                              as="textarea" rows="3"
                              placeholder={this.props.placeholder}
                              value={this.state.description}
                              onChange={e => this.setState({ description: e.target.value })}
                              className="input_sw"
                            />
                            </div>
                            </div>
                          </FormGroup>
                          <FormGroup>
                            <div className=" row input-overall-sec ">

                            <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Abbreviation')}:</InputGroup>
                              </InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd">
                              <FormControl
                                placeholder={t("Abbreviation")}
                                aria-label="UniqueKey"
                                aria-describedby="basic-addon1"
                                value={this.state.abbrevation}
                                onChange={e => this.setState({ abbrevation: e.target.value })}
                                className="input_sw"
                              />
                              </div>
                            </InputGroup>
                            </div>
                          </FormGroup>
                          <Form.Group>
                            <Form.Check
                              onChange={e => this.setState({ available_field_screen: !available_field_screen })}
                              name='available_in_master_data'
                              checked={available_field_screen}
                              label={t("Available in master data")}
                            />
                          </Form.Group>
                          {/* <Form.Group>
                            <Form.Check
                              onChange={e => this.setState({ active_group: !active_group })}
                              name='active_group'
                              checked={active_group}
                              label={t("Active group")}
                            />
                          </Form.Group> */}
                        </reactbootstarp.Tab>
                        {linkTabs}
                      </reactbootstarp.Tabs>
                      <div style={{ float: 'right' }} className="organisation_list">
                      <a onClick={this.handleCancel} > {t('Cancel')} </a>
                      &nbsp;&nbsp;&nbsp;
                      <Button type="submit" disabled={loading} color="primary">{t('Save')}</Button>
                      {/* {loading &&
                            <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                          } */}


                          {this.state.pop && popup}
                          </div>
                    </Form>
                  </Container>
                </div>
              </div>
            </div>
          </div>
          )}
          no={ () =>
            <AccessDeniedPage/>
          }
        />
      </div>
      </div>
    );
  }

}
export default translate(Groups)
