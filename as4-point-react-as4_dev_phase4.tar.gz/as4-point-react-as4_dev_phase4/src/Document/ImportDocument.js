import React, { Component } from 'react';
import axios from 'axios';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from '../store';

const include_language_types = [4,5];

class ImportDocument extends Component {
    constructor(props) {
        super(props)
        this.state = {
            save: 'Save',
            credentials: this.props.credentials,
            file: '',
            file_details: '',
            showpopup: true,
            t: props.t,
            eventcancel: false,
            thruprops: true,
            error: '',
            manual_id : this.props.credentials.manual_id,
            language_id: 0,
        }
        this.handleChangeFile = this.handleChangeFile.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.cancelPopup = this.cancelPopup.bind(this);
        this.showPopup = this.showPopup.bind(this);

    }
    handleChangeFile(e) {
        const { t } = this.state;
        let Userdata = store.getState();
        let systemsettings = Userdata.UserData.systemsettings;
        let kilobytes = (e.target.files[0]['size'] / 1000).toFixed(1);
        let megabytes = kilobytes / 1024;
        let doc_type = this.state.credentials.doc_type;
        const name = e.target.files[0].name;
        const lastDot = name.lastIndexOf('.');

        const fileName = name.substring(0, lastDot);
        const ext = name.substring(lastDot + 1);
        const validateType = (doc_type === 5) ? true : window.DOC_TYPES_validate[doc_type].includes(ext);
        if (validateType === false) {
          OCAlert.alertError(t('Please upload only ' + window.DOC_TYPES[doc_type]), { timeOut: window.TIMEOUTNOTIFICATION });
          return false;
        }
        let sizeType = 4;
        let specifiedSize = 1024;
        console.log(doc_type);
        console.log(systemsettings);
        if (doc_type <= 3) {
          sizeType = systemsettings['18-1'] == undefined ? 4 : parseInt(systemsettings['18-1']);
          specifiedSize = systemsettings['17-1'] == undefined ? 1024 : parseInt(systemsettings['17-1']);
        }
        else if (doc_type > 3) {
          sizeType = systemsettings['20-1'] == undefined ? 4 : parseInt(systemsettings['20-1']);
          specifiedSize = systemsettings['19-1'] == undefined ? 1024 : parseInt(systemsettings['19-1']);
        }
        console.log(sizeType);
        console.log(specifiedSize);
        if (sizeType == 4 && kilobytes > specifiedSize || sizeType == 5 && megabytes > specifiedSize) {
            OCAlert.alertError(t('Size of a document is more than specified size in settings'), { timeOut: window.TIMEOUTNOTIFICATION });
        } else {
            this.setState({
                file_details: e.target.value,
                file: e.target.files[0],
            })
        }
    }
    handleSubmit() {
        const formData = new FormData();
        const { t } = this.state;
        const details = {
            file: this.state.file,
            language_id:this.state.language_id,
        }
        if (this.state.file === '') {
          OCAlert.alertError(t('Please upload file'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
        if ( include_language_types.includes(this.props.credentials.doc_type)  && this.state.language_id === 0 || this.state.language_id === '') {
          OCAlert.alertError(t('Please select language'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
        for (var key in details) {
            formData.append(key, details[key]);
        }
        document.getElementById("loding-icon").setAttribute("style", "display:block;");
        axios.post(window.backendURL + '/api/upload-document/' + this.props.credentials.doc_id + '/' + this.props.credentials.doc_type, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
            .then(response => {
                if (response.data) {
                    document.getElementById("loding-icon").setAttribute("style", "display:none;");
                    this.setState({ 'thruprops': false });
                    this.cancelPopup();
                    OCAlert.alertSuccess(t('Imported successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
                    this.props.actionEdit(this.props.credentials.doc_id, this.props.credentials.current_type, 'view', this.props.credentials.addtype,this.props.credentials.manual_id, '', '', this.props.credentials.access_details);
                }
            });
    }
    handleCancel(e) {
        this.cancelPopup();
    }
    cancelPopup() {
        this.props.cancelImport();
    }
    showPopup() {
        this.setState({ showpopup: true });
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.import !== this.props.import) {

            this.setState({
                showpopup: true,
                file_details: '',
            });
        }
    }

    render() {
        let accept = (this.props.credentials.doc_type !== undefined && this.props.credentials.doc_type !== '') ? window.DOC_TYPES[this.props.credentials.doc_type] : window.DOC_TYPES['default'];
        const { t, description, loading, updateImageUpload, use_existing_file_edit_img, memo_data, error, id } = this.state;
        return (
            <reactbootstrap.Modal show={this.state.showpopup} onHide={this.cancelPopup}>
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title>{t('Import document')}</reactbootstrap.Modal.Title>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Container className="p-5">
                    {/* <reactbootstrap.Form onSubmit={this.handleSubmit}> */}
                    <reactbootstrap.Modal.Body>
                        <reactbootstrap.FormGroup>
                            <reactbootstrap.InputGroup.Prepend>{t('Upload file')}</reactbootstrap.InputGroup.Prepend>
                            <input
                                id="file"
                                type="file"
                                name="file"
                                onChange={this.handleChangeFile}
                                value={this.state.file_details}
                                accept={accept} />

                        </reactbootstrap.FormGroup>
                        {  include_language_types.includes(this.props.credentials.doc_type) &&
                        <reactbootstrap.FormGroup>
                                <reactbootstrap.InputGroup className="">
                                        <reactbootstrap.InputGroup.Prepend>
                                          {t('Language')}
                                        </reactbootstrap.InputGroup.Prepend>
                                </reactbootstrap.InputGroup>
                                <reactbootstrap.Form.Control as="select" name="language_id"
                                    className="input_sw"
                                    value={this.state.language_id}
                                    onChange={e => this.setState({ language_id: e.target.value, loading: false })} >>
                                    <option id='0' value='0' >{t('Select')}</option>
                                    {JSON.parse(localStorage.getItem('App_language_data')).map(function(lang){
                                      return(
                                          <option id={lang.language} value = {lang.id}>{lang.language}</option>
                                      );
                                    },this)
                                  }
                                </reactbootstrap.Form.Control>
                        </reactbootstrap.FormGroup>
                      }
                    </reactbootstrap.Modal.Body>
                    <div style={{ color: 'red' }} className="error-block">{error}</div>
                    <reactbootstrap.Modal.Footer>
                        <reactbootstrap.Modal.Footer></reactbootstrap.Modal.Footer>
                        <reactbootstrap.Button type="submit" disabled={loading} onClick={this.handleSubmit} color="primary">{t('Save')}</reactbootstrap.Button>
                        {loading &&
                            <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                        }
                        &nbsp;&nbsp;&nbsp;
                          <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.handleCancel} >{t('Cancel')}</reactbootstrap.Button>
                    </reactbootstrap.Modal.Footer>
                    {/* </reactbootstrap.Form> */}
                </reactbootstrap.Container>
            </reactbootstrap.Modal>
        );
    }
}
export default translate(ImportDocument)
