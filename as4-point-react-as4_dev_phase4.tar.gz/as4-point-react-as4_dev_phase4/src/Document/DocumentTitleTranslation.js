import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { datasave } from '../_services/db_services';
import { data } from 'jquery';




class DocumentTitleTranslation extends Component {
    constructor(props) {
        super(props)
        this.state = {            
            show_sitepopup: this.props.showtranslation,
            t: props.t,
            language : [],
            language_id : '',
            translatedstring :{'nl':this.props.name},            
        }
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.cancelPopup = this.cancelPopup.bind(this);
        // this.showPopup = this.showPopup.bind(this);
    }
    componentDidMount(){
      console.log(this.props.action);
      
      datasave.service(window.GET_ALL_LANGUAGES, "GET")
      .then(result => {
        console.log(result);
        this.setState({
          language : result,
          language_id : result[0]['code_name'],
        })
      });
      const data={
        doc_id:this.props.doc_id,
        entity_type : this.props.entity_type,
      }
      // if(this.props.parent_type=='document') {
        datasave.service(window.FETCH_TITLE_TRANSLATION,'POST',data)
        .then(result=>{
          this.setState({
            translatedstring : result.length!=0?result:this.state.translatedstring,
          })
        })
      // }
    }
    handleSubmit() {
      console.log(this.props.entity_type);
      
      if(this.props.action!='create') {
        const data = {
          doc_id : this.props.doc_id,
          lang_code : this.state.language_id,
          language_title : this.state.translatedstring, 
          entity_type :    this.props.entity_type,
        }
        datasave.service(window.SAVE_TITLE_TRANSLATION, "POST",data)
        .then(result=>{
          if(result=='Success') {
          }
        })
      }
      this.cancelPopup();
    }
    handleCancel(e) {
      this.cancelPopup();
    }
    cancelPopup() {
      this.props.handleTranslationCancel(this.state.translatedstring);
    }
    
    handleClick(){
      this.setState({
        status : !this.state.status,
      })
      console.log(this.state.status);
    }

    getLangOptionItems() {
      let temp = [];
      if (this.state.language.length >= 1) {
        if (this.state.language) {
          temp = this.state.language.map((lang) => {
            return (<option id={lang.code_name} value={lang.code_name} >{lang.language}</option>)
          }
          );
          return temp;
        }
      }
    }
    handleChange (codename,e) {
      // this.setState({
      //   translatedstring:{[codename]:e.target.value}
      // })
      let strings = this.state.translatedstring;
      strings[codename] = e.target.value
      this.setState({
        translatedstring:strings
      })
    }
    render() {
      console.log(this.state.translatedstring);
        const { t } = this.state;
        return (
            <reactbootstrap.Modal show={this.state.show_sitepopup} onHide={this.cancelPopup}>
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title>{t('Translation')}</reactbootstrap.Modal.Title>
                </reactbootstrap.Modal.Header >
                <reactbootstrap.Container className="">
                    {/* <reactbootstrap.Form onSubmit={this.handleSubmit}> */}
                    <reactbootstrap.Modal.Body>
                      <>
                     {this.state.language.map((lang)=>{
                       return(
                        <reactbootstrap.FormGroup>
                       <div className=" input-overall-sec ">
                         <reactbootstrap.InputGroup className="">
                           <div className="col-md-4 ">
                             <reactbootstrap.InputGroup.Prepend>
                               <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{lang.language}:</reactbootstrap.InputGroup>
                             </reactbootstrap.InputGroup.Prepend>
                           </div>
                           <div class="col-md-8 input-padd input_sw">
                             <reactbootstrap.FormControl
                               id={lang.code_name}
                               name={lang.code_name}
                               placeholder={lang.language+' '+'string'}
                               onChange={this.handleChange.bind(this,lang.code_name)}
                               value={this.state.translatedstring[lang.code_name]}
                               className="input_sw"
                             />
                           </div>
                         </reactbootstrap.InputGroup>
                       </div>
                       </reactbootstrap.FormGroup>
                       )
                     })}
                     </> 
                    
                     {/* <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                  <reactbootstrap.InputGroup className="  ">
                    <div className="col-md-4">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Transalted string")}</reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div class="col-md-8 input-padd">
                      <reactbootstrap.FormControl
                        name="translatedstring"
                        placeholder="Translated string"
                        onChange={(e) => this.setState({ translatedstring: e.target.value })}
                        value={this.state.translatedstring}
                        className="input_sw"
                      />
                      
                    </div>
                  </reactbootstrap.InputGroup>
                </div>
              </reactbootstrap.FormGroup> */}
                    </reactbootstrap.Modal.Body>
                    <reactbootstrap.Modal.Footer style={{borderTop: '0px'}}>
                        <reactbootstrap.Modal.Footer style={{borderTop: '0px'}}></reactbootstrap.Modal.Footer>
                        <div style={{ float: 'right' }} className="organisation_list">
                        {/* <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.handleCancel} >{t('Cancel')}</reactbootstrap.Button> */}
                        <a onClick={this.handleCancel} > {t('Cancel')} </a>
                        
                        &nbsp;&nbsp;&nbsp;
                        <reactbootstrap.Button type="submit"  onClick={this.handleSubmit} color="primary">{t('Save')}</reactbootstrap.Button>

                   </div>
                    </reactbootstrap.Modal.Footer>
                    {/* </reactbootstrap.Form> */}
                </reactbootstrap.Container>
            </reactbootstrap.Modal>
        );
    }
}
export default translate(DocumentTitleTranslation)
