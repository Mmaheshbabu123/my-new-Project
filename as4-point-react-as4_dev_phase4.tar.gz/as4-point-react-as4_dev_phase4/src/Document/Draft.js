import React, { Component } from 'react';
import axios from 'axios';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';

class Draft extends Component {
    constructor(props) {
        super(props)
        this.state = {
            t: props.t,
            showpopup: this.props.showDraft,
        }
        this.cancelPopup = this.cancelPopup.bind(this);


    }
    cancelPopup(action) {
        this.props.draftStatus(action);
        this.setState({
            showpopup: false,
        })
    }




    componentDidUpdate(prevProps, prevState) {

    }

    render() {
        const { t } = this.state;
        return (
            <reactbootstrap.Modal  show={this.state.showpopup} onHide={this.cancelPopup.bind(this, 'no')}>
                <reactbootstrap.Modal.Header style={{padding: '10px'}} closeButton>
                    <reactbootstrap.Modal.Title>{t(' WARNING')}</reactbootstrap.Modal.Title>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Container className="">
                    {/* <reactbootstrap.Form onSubmit={this.handleSubmit}> */}
                    <reactbootstrap.Modal.Body>
                        <p> {t('Are you sure you want to leave this page without saving?')} </p>
                    </reactbootstrap.Modal.Body>
                    <reactbootstrap.Modal.Footer style={{ borderTop: '0px' }}>
                        <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.cancelPopup.bind(this, 'yes')} >{t('Yes')}</reactbootstrap.Button>

                        {/* <reactbootstrap.Modal.Footer style={{borderTop: '0px'}}></reactbootstrap.Modal.Footer> */}
                        <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.cancelPopup.bind(this, 'no')} >{t('No')}</reactbootstrap.Button>

                    </reactbootstrap.Modal.Footer>
                    {/* </reactbootstrap.Form> */}
                </reactbootstrap.Container>
            </reactbootstrap.Modal>
        );
    }
}
export default translate(Draft)
