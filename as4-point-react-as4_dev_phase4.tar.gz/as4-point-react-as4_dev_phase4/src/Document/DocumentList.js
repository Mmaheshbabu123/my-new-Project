import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import {translate} from '../language';

class DocumentList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            t:props.t,
        }
    }
    componentDidMount() {

    }
    render() {
        const { manuals,t } = this.state

        return (
            <div className='container py-4'>
                <div className='row justify-content-center'>
                    <div className='col-md-9'>
                        <div className='card'>
                            <div className='card-header'>{t('All manuals')}</div>
                            <div className='card-body'>
                                <reactbootstrap.Table responsive>
                                    <thead>
                                        <tr>
                                            <th>{t('Name of manuals')}</th>
                                            <th colspan="2">{t('Actions')}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {manuals.map(manualItem => (
                                            <tr>
                                                <td>{manualItem.name}</td>
                                                <td>
                                                    <Link
                                                        to={`/manual/${manualItem.id}`}
                                                        key={manualItem.id}
                                                    >
                                                        {t('Edit')}
                                                    </Link>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </reactbootstrap.Table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default translate(DocumentList)
