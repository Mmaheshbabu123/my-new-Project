import React, { Component } from 'react'
import { PrivateRoute } from '../_components/PrivateRoute'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import 'moment-timezone/builds/moment-timezone-with-data-2012-2022';
import moment from 'moment';
import timezone from 'moment-timezone'
import DocumentComponent from '../_components/documentComponents/documentComponent';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css';
import { connect } from "react-redux";
import { translate } from '../language';
import CommentType from '../_components/CommentType';
import Can from '../_components/CanComponent/Can';
import { CanPermissions } from '../_components/CanComponent/CanPermissions'
import { persistor, store } from '../store';
import { OCAlert } from '@opuscapita/react-alerts';
import axios from 'axios';
import DocumenTranslation from './DocumentTitleTranslation';
// var moment =require('moment');
const mandatory_fields = ['name', 'code', 'layout_id'];

class Document extends Component {
    constructor(props) {
        super(props)
        this.handleSubmit = this.handleSubmit.bind(this)
        this.handleChange = this.handleChange.bind(this)
        this.handleCancel = this.handleCancel.bind(this)
        this.handleSelect = this.handleSelect.bind(this)
        this.handleFile = this.handleFile.bind(this)
        this.handleChangenum = this.handleChangenum.bind(this)
        this.updateSelected = this.updateSelected.bind(this)
        this.handleActiveTab = this.handleActiveTab.bind(this)
        this.updateSelectedRights = this.updateSelectedRights.bind(this);
        this.handleChangeMultiBundle = this.handleChangeMultiBundle.bind(this)
        this.handleChangeMultiStandard = this.handleChangeMultiStandard.bind(this)
        this.handleChangeMultiTag = this.handleChangeMultiTag.bind(this)
        this.handleChangeMultiOwner = this.handleChangeMultiOwner.bind(this)
        this.handleNotification = this.handleNotification.bind(this);
        this.handleNotificationSelect = this.handleNotificationSelect.bind(this);
        this.handleDocumentdata = this.handleDocumentdata.bind(this);
        this.handleParentData = this.handleParentData.bind(this);
        this.copyParentData = this.copyParentData.bind(this);
        this.handleDocumentEmptyData = this.handleDocumentEmptyData.bind(this);
        this.handleDocumentCloneEmptyData = this.handleDocumentCloneEmptyData.bind(this);
        this.updateFolder = this.props.updateFolder;
        this.filterArray = this.filterArray.bind(this);
        this.handleCopyData = this.handleCopyData.bind(this);
        this.handleCopyDocument = this.handleCopyDocument.bind(this);
        this.getposition = this.getposition.bind(this);
        this.handlemaindocumentbundle = this.handlemaindocumentbundle.bind(this);
        this.getUpdateCode = this.getUpdateCode.bind(this);
        this.updateImageUpload = this.updateImageUpload.bind(this);
        this.handlehide = this.handlehide.bind(this)
        this.handleChangeFileUpload = this.handleChangeFileUpload.bind(this);
        this.removeFileUpload = this.removeFileUpload.bind(this);
        this.handleAddSpace = this.handleAddSpace.bind(this);
        this.disableAllTabs = this.disableAllTabs.bind(this);
        //this.approvalRightsPermissions = this.approvalRightsPermissions.bind(this);
        // this.renderSwitch = this.renderSwitch.bind(this);
        // this.handleCycle = this.handleCycle.bind(this);
        // this.handleGetCode = this.handleGetCode.bind(this);
        this.state = {
            get_insert_url: window.GET_INSERT_DOCUMENT_DETAILS,
            credentials: this.props.credentials,
            cancelPopup:this.props.cancelPopup,
            code: '',
            name: '',
            doc_use_existing_file: '',
            version: '001',
            status: 'New',
            submitted: false,
            parent_folder: '',
            layouts: [],
            layout_id: '',
            reason_of_change: '',
            reason_of_change_text: '',
            doc_types: [],
            doc_type_id: 1,
            cancel:0,
            showComment: false,
            reviewing_period_days_disabled: false,
            expiration_period_days_disabled: false,
            doc_details_disabled: false,
            show_whats_new_disabled: false,
            rev_details_disabled: false,
            revision_date_behaviour_disabled: false,
            to_review_date_disabled: false,
            communication_disabled: false,
            extra_tab_disabled: false,
            approvalcycle_disabled: false,
            due_date_disabled: false,
            default_tab_disabled: false,
            exp_his_disabled: false,
            roc: false,
            cr_webform_disabled:false,
            use_existing_file: '',
            use_existing_file_name: props.t('Choose file'),
            use_existing_file_edit_img: '',
            reason_of_expiration: '',
            reason_of_expiration_extra: '',
            index_doc: 1,
            export_format: 1,
            tags: [],
            standards: [],
            tag_options: [],
            standard_options: [],
            owner_options: [],
            owners: [],
            available_in_masterdata: 1,
            use_in_statistics: 1,
            show_in_whats_new: 1,
            table_of_contents: 1,
            bundle_revise_status:1,
            fundamental: 1,
            webform:1,
            code_error: '',
            name_error: '',
            doc_status: '',
            cycle_status: 3,
            version_error: '',
            // status_error : '',
            parent_folder_error: '',
            layout_error: '',
            type_error: '',
            doc_status_id: 1,
            current_status_id :1,
            use_existing_file_error: '',
            export_format_error: '',
            revision_date:  moment().format('YYYY-MM-DD'),
            to_revsion_date: '',
            to_revision_date: '',
            revision_date_behaviour: '1',
            publish_date: '',
            archive_period_days: '',
            archive_period_type: 'days',
            reviewing_period_days: '',
            reviewing_period_type: 'days',
            reviewing_warning_days: '',
            reviewing_warning_type: 'days',
            reviewing_date: '',
            expiration_period_days: '',
            expiration_period_type: 'days',
            revision_date_error: '',
            publish_date_error: '',
            reviewing_date_error: '',
            notifications: [],
            due_date_days: '',
            spaces: [],
            historical_date: '',
            type:'document',
            clone_credentials:'',
            expired_date: '',
            doc_id: '',
            Bundle_options: [],
            bundle_options_maindoc: [],
            bundles: [],
            selectedmaindocuments: [],       // here................
            spaces_types: [],
            tasks: [],
            items: [],
            types: [],
            selected: [],
            manuals: [],
            parent_id: '',
            active_tab: 1,
            [window.tabs.approval_cycle]: [],
            [window.tabs.r_u_extra]: [],
            [window.tabs.r_u_default]: [],
            [window.tabs.notification]: [],
            [window.tabs.spaces]: [],
            document_flag: [],
            disableFields: false,
            file_id: '',
            file_path: '',
            sucess: '',
            upload_valid: '',
            upload_error: '',
            due_date_disabled: false,
            t: props.t,
            namedata: [],
            codedata: [],
            combined: [],
            both: true,
            diable_ExpirationPeriod: false,
            defaultKeyForSpace : undefined,
            corporate : 0,
            showtranslation : false,
            language_title : [],
            entity_type : 3,
            roc_update:0,
            dataLoad:0,
        }

    }

    getNotifications() {
        datasave.service(window.GET_INSERT_DOCUMENT_DETAILS, 'GET', '')
            .then(response => {
                this.setState({
                    notifications: response.notifications,
                })
            })
            .catch(error => {
                this.setState({
                    // errors: error.response.data.errors
                })
            })
    }
    confirmPopup = () => {
        const { t } = this.state;
        let parent_type=this.props.credentials.parent_type;
        if (this.props.credentials.parent_type == 'document' || this.props.credentials.parent_type == 'webform') {
            var url = this.state.get_insert_url + '/' + this.props.credentials.parent_id;
            datasave.service(url, "GET")
                .then(result => {
                    this.setState({
                        code: this.getUpdateCode(result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position),
                      //  manual_id: result.document.parent_id + '-' + result.document.parent_type + '-' + result.document.manual_id,
                    })
                });
        }
        else {
            var url = window.GET_FOLDER_DETAILS + this.props.credentials.parent_id;
            datasave.service(url, "GET")
                .then(result => {
                    this.setState({
                        code: this.getUpdateCode(result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position),
                        manual_id: result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id,
                    })
                });
        }

        let message='';
        if(parent_type == 'document'){
          message=t('Do you want to copy parent document settings?')
        }
        else if (parent_type == 'folder') {
          message=t('Do you want to copy parent folder settings?')
        }
        confirmAlert({
            title: t('Document settings'),

            message: message,
            buttons: [
                {
                    label: this.props.t('Yes'),
                    onClick: () => this.handleCopyData()
                },
                {
                    label: this.props.t('No'),
                    onClick: () => this.handleDocumentCloneEmptyData()
                }
            ]
        });
    };
    copyParentData() {
        var url = window.GET_FOLDER_DETAILS + this.props.credentials.parent_id;
        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    // code: this.getUpdateCode(result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position),
                    manual_id: result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id,
                })
            });

    }
    updateImageUpload(response) {
        this.setState({
            sucess: window.FILE_UPLOAD_SUCCESS,
            edit_img: '',
            file_id: response.data.file_id[0],
            file_path: response.data.filepath,
            use_existing_file_name: response.data.filepath
        });

    }
    getUpdateCode(next_fol_id, next_template, next_position) {
        var next_position = this.getposition(next_position, next_fol_id, next_template);
        next_template = (next_template != null) ? next_template : '';
        var combine = next_position;
        return combine;
    }

    getposition(position = '', sample = 1, template) {
        var seq = (position) ? position : this.state.position;
        var s = sample + "";
        while (s.length < seq) {
            s = "0" + s;
        }
        template = template.replace('<NR>', s);
        return template;
    }
    /**
     * clone document from parent document
     */
    handleCopyDocument() {
        const { t } = this.state;
        var url = this.state.get_insert_url + '/' + this.props.credentials.parent_id;
        var clone_credentials = this.props.credentials;
        datasave.service(url, "GET")
            .then(result => {
                // var next_doc_id = result.next_code[0].doc_next_id;
                // var template = result.next_code[0].template;
                // var position = result.next_code[0].position;
                // var next_position = this.getposition(position, next_doc_id);
                // template = (template) ? template : '0';
                // var combine = template + next_position;
                var to_revision_date = this.handleChangeReviewdate(result.document.review_period_days,result.document.review_period_type);
                this.props.credentials.manual_flag = 0;
                var parent_type = this.props.credentials.parent_type;
                this.setState({
                    [window.tabs.notification]: result.notifications,
                    [window.tabs.r_u_default]: (result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
                    [window.tabs.r_u_extra]: (result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
                    [window.tabs.approval_cycle]: result.rights,
                    [window.tabs.spaces]: result.spaces,
                    notifications: result.notifications_behaviour,
                    tags: result.tags,
                    owners: result.owners,
                    type:parent_type,
                    clone_credentials :clone_credentials,
                    name: '',
                    export_format: 1,
                    standards: result.standards,
                    disableFields: false,
                    code: this.getUpdateCode(result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position),
                    parent_id: result.document.parent_id,
                    manual_id: result.document.parent_id + '-' + result.document.parent_type + '-' + result.document.manual_id,
                    parent_type: result.document.parent_type,
                    version: result.document.version,
                    //layout_id: result.document.layout_id,
                    layout_id: (result.document.layout_id == null) ? '' : result.document.layout_id,
                    layouts: result.layouts,
                    status: 'New',
                    doc_status_id: 1,
                    current_status_id:1,
                    version: '001',
                    sucess:'',
                    parent_id: result.document.parent_id,
                    reason_of_change: '',
                    reason_of_change_text: '',
                    doc_type_id: result.document.doc_type_id,
                    use_existing_file_name: (result.document.file_path == null) ? t('Choose file') : result.document.file_path,
                    use_existing_file_edit_img: (result.document.file_path !== null && result.document.doc_type_id >= 4) ? t('Click here to preview') : '',
                    file_path: result.document.file_path,
                    file_id:result.document.file_id,
                    bundles: result.selected_bundles,
                    selectedmaindocuments: (result.selected_bundles !== undefined) ? result.selected_bundles.filter(items => (items.main_document === 1)) : [],
                    bundle_options_maindoc: result.selected_bundles,
                    //doc_type_id :1,
                    //use_existing_file_name: (result.document.file_path == null) ? t('Choose file') : result.document.file_path,
                  //  use_existing_file_edit_img: (result.document.file_path !== null && result.document.doc_type_id >= 4) ? t('Click here preview') : '',
                  //  use_existing_file_name: t('Choose file'),
                  //  use_existing_file_edit_img: '',
                    reason_of_expiration: result.document.reason_of_expiration,
                    reason_of_expiration_extra: result.document.reason_of_expiration_extra,
                    index_doc: result.document.index_doc,
                    export_format: result.document.export_format,
                    use_in_statistics: (result.document.use_in_statistics !== null)?result.document.use_in_statistics:0,
                    show_in_whats_new: result.document.show_in_whats_new,
                    available_in_masterdata: (result.document.available_in_masterdata !== null)?result.document.available_in_masterdata:0,
                    table_of_contents: (result.document.table_of_contents !== null)?result.document.table_of_contents:0,
                    fundamental: (result.document.fundamental !== null)?result.document.fundamental:0,
                    webform:(result.document.webform !== null)?result.document.webform:0,
                    revision_date: moment().format('YYYY-MM-DD'),
                    revision_date_behaviour: result.document.revision_date_behaviour,
                    archive_period_days: result.document.archive_period_days,
                    archive_period_type: result.document.archive_period_type,
                    reviewing_period_days: result.document.review_period_days,
                    reviewing_period_type: result.document.review_period_type,
                    reviewing_warning_days: result.document.review_warning_days,
                    reviewing_warning_type: result.document.review_warning_type,
                    expiration_period_days: result.document.experiration_period_days,

                    expiration_period_type: result.document.experiration_period_type,
                    publish_date: '',
                    to_revision_date: to_revision_date,
                    reviewing_date: '',
                  //  expiration_period_days: '',
                  //  expiration_period_type: 'days',
                    due_date_days: '',
                    disableFields: false,
                    doc_details_disabled: false,
                    show_whats_new_disabled: false,
                    rev_details_disabled: false,
                    revision_date_behaviour_disabled: false,
                    to_review_date_disabled: false,
                    communication_disabled: false,
                    extra_tab_disabled: false,
                    approvalcycle_disabled: false,
                    due_date_disabled: false,
                    default_tab_disabled: false,
                    bundle_revise_status:1,
                    exp_his_disabled: false,
                    cr_webform_disabled:false,
                    corporate:result.document.corporate,
                    roc_update:0,
                    //use_existing_file_name: 'Choose file',
                })
                this.props.credentials.manual_flag = 0;
            });
    }
    /**
     * clone the document from parent folder
     */
    handleCopyData() {
        const { t } = this.state;

        const webform_permission = (CanPermissions('E_webform', '') && !CanPermissions('C_documents',''))?1:0;
        if (this.props.credentials.parent_type === 'document'||this.props.credentials.parent_type === 'webform') {
            this.handleCopyDocument();
        }
        else if (this.props.credentials.parent_type === 'folder') {
            var url = window.GET_FOLDER_DETAILS + this.props.credentials.parent_id;
            datasave.service(url, "GET")
                .then(result => {
                    // var next_doc_id = result.next_code[0].doc_next_id;
                    // var template = result.next_code[0].template;
                    // var position = result.next_code[0].position;
                    // var next_position = this.getposition(position, next_doc_id);
                    // : = (template) ? template : '0';
                    // var combine = template + next_position;
                    this.props.credentials.manual_flag = 0;
                    var to_revision_date = this.handleChangeReviewdate(result.folder.review_period_days,result.folder.review_period_type);
                    this.setState({
                        [window.tabs.notification]: result.notifications,
                        [window.tabs.r_u_default]: (result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
                        [window.tabs.r_u_extra]: (result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
                        [window.tabs.approval_cycle]: result.rights,
                        [window.tabs.spaces]: result.spaces,
                        notifications: result.notifications_behaviour,
                        tags: result.tags,
                        standards: result.standards,
                        bundles:[],
                        selectedmaindocuments:[],
                        bundle_options_maindoc:[],
                        export_format: 1,
                        index_doc: 1,
                        show_in_whats_new: 1,
                        webform:webform_permission,
                        name: '',
                        fundamental: 0,
                        status: 'New',
                        version: '001',
                        reason_of_change: '',
                        reason_of_change_text: '',
                        to_revision_date: to_revision_date,
                        //fundamental:result.folder.fundamental,
                        table_of_contents: (result.folder.table_of_contents !== null)?result.folder.table_of_contents:0,
                      //  result.folder.table_of_contents,
                        owners: result.owners,
                        disableFields: false,
                        due_date_disabled: false,
                        doc_status_id: 1,
                        current_status_id:1,
                        doc_type_id :1,
                        publish_date: '',
                        reviewing_date: '',
                      //  use_existing_file_edit_img: '',
                        use_existing_file_name: t('Choose file'),
                        use_existing_file_edit_img: '',
                        layout_id: (result.folder.layout_id == null) ? '' : result.folder.layout_id,
                        manual_id: result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id,
                        archive_period_days: result.folder.archive_period_days,
                        revision_date: moment().format('YYYY-MM-DD'),
                        due_date_days: '',
                        archive_period_type: result.folder.archive_period_type,
                        reviewing_period_days: result.folder.review_period_days,
                        reviewing_period_type: result.folder.review_period_type,
                        reviewing_warning_days: result.folder.review_warning_days,
                        reviewing_warning_type: result.folder.review_warning_type,
                        expiration_period_days: result.folder.expiration_behaviour_days,
                        expiration_period_type: result.folder.expiration_behaviour_type,
                        doc_details_disabled: false,
                        show_whats_new_disabled: false,
                        rev_details_disabled: false,
                        revision_date_behaviour_disabled: false,
                        to_review_date_disabled: false,
                        communication_disabled: false,
                        extra_tab_disabled: false,
                        approvalcycle_disabled: false,
                        due_date_disabled: false,
                        roc: false,
                        sucess:'',
                        bundle_revise_status:1,
                        default_tab_disabled: false,
                        reviewing_date_disabled: false,
                        exp_his_disabled: false,
                        cr_webform_disabled:webform_permission,
                        reviewing_period_days_disabled: false,
                        expiration_period_days_disabled: false,
                        language_title :[],
                      roc_update :0.
                        //code: this.getUpdateCode(result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position),
                    });

                });
        }
    }
    /**
     * Edit Document
     */
    handleDocumentdata(action,type = 1) {
        const { t } = this.state;
        var codedata = [];
        var namedata  = [];
        var combined = [];
        var current_date = moment().format('YYYY-MM-DD');
        // this.props.actionEdit(this.props.credentials.parent_id,this.props.credentials.parent_type,this.props.credentials.action,this.props.credentials.addtype,this.props.credentials.manual_id);
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        var url = this.state.get_insert_url + '/' + this.props.credentials.parent_id + '?pid=' + person_id;
        let url2 = window.GET_USED_DOC_FOR_DOC + '/' + this.props.credentials.parent_id;
        datasave.service(url, "GET")
            .then(  result => {
              if (action === "edit") {
                datasave.service(url2, 'GET').then(
                    response => {
                       codedata = response.code;
                       namedata  = response.name;
                       combined = response.all;
                    })
                  }

                this.props.credentials.manual_flag = 0;
                var status_id = result.document.docstatusId;
                if(result.document.docstatusId == 8){
                status_id = (result.document.publish_date <= current_date) ? 6:result.document.docstatusId;
                }
                this.setState({
                    [window.tabs.notification]: result.notifications,
                    [window.tabs.r_u_default]: (result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
                    [window.tabs.r_u_extra]: (result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
                    [window.tabs.approval_cycle]: result.rights,
                    [window.tabs.spaces]: result.spaces,
                    notifications: result.notifications_behaviour,
                    codedata: codedata,
                    namedata: namedata,
                    combined: combined,
                    tags: result.tags,
                    owners: result.owners,
                    standards: result.standards,
                    code: result.document.code,
                    clonecode: result.document.code,
                    pid: person_id,
                    name: result.document.name,
                    clonename: result.document.name,
                    parent_id: result.document.parent_id,
                    manual_id: result.document.parent_id + '-' + result.document.parent_type + '-' + result.document.manual_id,
                    parent_type: result.document.parent_type,
                    version: result.document.version,
                    layout_id: result.document.layout_id,
                    doc_id: result.document.id,
                    doc_status_id: status_id,
                    current_status_id:result.document.docstatusId,
                    due_date_disabled: (window.INITATE_CYCLE.includes(result.document.docstatusId.toString())) ? false : true,
                    layouts: result.layouts,
                    status: result.document.status,
                    parent_id: result.document.parent_id,
                    reason_of_change: result.document.reason_of_change,
                    reason_of_change_text: result.document.reason_of_change_text,
                    doc_type_id: result.document.doc_type_id,
                    use_existing_file_name: (result.document.file_path == null) ? t('Choose file') : result.document.file_path,
                    use_existing_file_edit_img: (result.document.file_path !== null && result.document.doc_type_id >= 4) ? t('Click here to preview') : '',
                    file_path: result.document.file_path,
                    file_id:result.document.file_id,
                    reason_of_expiration: result.document.reason_of_expiration,
                    reason_of_expiration_extra: result.document.reason_of_expiration_extra,
                    index_doc: result.document.index_doc,
                    export_format: result.document.export_format,
                    use_in_statistics: (result.document.use_in_statistics !== null)?result.document.use_in_statistics:0,
                    show_in_whats_new: result.document.show_in_whats_new,
                    available_in_masterdata: (result.document.available_in_masterdata !== null)?result.document.available_in_masterdata:0,
                    table_of_contents: (result.document.table_of_contents !== null)?result.document.table_of_contents:0,
                    revision_date: (result.document.revision_date !== null)?result.document.revision_date:moment().format('YYYY-MM-DD'),
                    revision_date_behaviour: result.document.revision_date_behaviour,
                    publish_date: result.document.publish_date,
                    to_revision_date: result.document.to_revision_date,
                    archive_period_days: result.document.archive_period_days,
                    archive_period_type: result.document.archive_period_type,
                    reviewing_period_days: result.document.review_period_days,
                    reviewing_period_type: result.document.review_period_type,
                    reviewing_warning_days: result.document.review_warning_days,
                    reviewing_warning_type: result.document.review_warning_type,
                    fundamental: (result.document.fundamental !== null)?result.document.fundamental:0,
                    reviewing_date: result.document.reviewing_date,
                    expiration_period_days: result.document.experiration_period_days,
                    expiration_period_type: result.document.experiration_period_type,
                    due_date_days: result.document.due_date_days,
                    disableFields: (action == 'view') ? true : false,
                    bundles: result.selected_bundles,
                    to_review_date_disabled: (result.document.review_period_days == '' || result.document.review_period_days == null) ? false : true,
                    webform:(result.document.webform == 1)?result.document.webform:0,
                    expired_date: result.document.expired_date,
                    bundle_revise_status:result.document.bundle_revise_status,
                    historical_date: result.document.historical_date,
                    selectedmaindocuments: (result.selected_bundles !== undefined) ? result.selected_bundles.filter(items => (items.main_document === 1)) : [],
                    bundle_options_maindoc: result.selected_bundles,
                    priority: result.priority,
                    cancel:(type ==0)?1:0,
                    sucess:'',
                    corporate : result.document.corporate,
                    roc_update:0,
                    dataLoad:(action === "view")?1:0,
                })
                if((action === 'edit'))  {
                this.approvalRightsPermissions();
              }
            });
        // if (action === "edit") {
        //   datasave.service(url2, 'GET').then(
        //       response => {
        //           this.setState({
        //               codedata: response.code,
        //               namedata: response.name,
        //               combined: response.all
        //           })
        //       }
        //   )
        // }

    }

    /**
     * empty document data
     */
    handleDocumentEmptyData() {
        const { t } = this.state;
        //this.handleNoParentData();
        //this.copyParentData();
        //  moment(startdate, "DD-MM-YYYY").add(5, 'days');
        //var d = moment(this.state.revision_date, 'YYYY-MM-DD').add(7, 'days');
        // if(this.props.credentials.parent_type == 'document' || this.props.credentials.parent_type == 'webform') {
        //     var url = this.state.get_insert_url + '/' + this.props.credentials.parent_id;
        //     }
        //     else{
        // var url = window.GET_FOLDER_DETAILS + this.props.credentials.parent_id;
        //     }
        // // import timezone from 'moment-timezone'
        // datasave.service(url, "GET")
        //     .then(result => {
        //       if(this.props.credentials.parent_type == 'document'||this.props.credentials.parent_type == 'webform') {
        //     var doc_type_id = result.document.doc_type_id;
        //     var  use_existing_file_name =  (result.document.file_path == null) ? t('Choose file') : result.document.file_path;
        //     var  use_existing_file_edit_img =  (result.document.file_path !== null && result.document.doc_type_id >= 4) ? t('Click here to preview') : '';
        //     var  file_path = result.document.file_path;
        //     var  file_id = result.document.file_id;
        //     // var status_id = result.document.docstatusId;
        //     // if(result.document.docstatusId == 8){
        //     // status_id = (result.document.publish_date <= current_date) ? 6:result.document.docstatusId;
        //     // }
        //   }else {
            var doc_type_id = 1;
            var  use_existing_file_name = 'Choose file';
            var  use_existing_file_edit_img = '';
            var  file_path = '';
            var  file_id = '';
          //}
        // var next_doc_id = result.next_code[0].doc_next_id;
        // var template = result.next_code[0].template;
        // var position = result.next_code[0].position;
        // var next_position = this.getposition(position, next_doc_id);
        // template = (template) ? template : '0';
        // var combine =this.getUpdateCode(result.next_code[0].doc_next_id,result.next_code[0].template,result.next_code[0].position);
        //var parent_id = result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id;
        // this.getNotifications();
        var result = [];
        result.folder = [];
        result.standards = [];
        result.tags = [];
        result.spaces = [];
        result.r_u = [];
        result.r_u[1] = [];
        result.notifications = [];
        result.rights = [];
        result.r_u[2] = [];
        this.props.credentials.manual_flag = 0;
        var parent_type = this.props.credentials.parent_type;
        this.setState({
            [window.tabs.notification]: result.notifications,
            [window.tabs.r_u_default]: result.r_u[1],
            [window.tabs.r_u_extra]: result.r_u[2],
            [window.tabs.approval_cycle]: result.rights,
            [window.tabs.spaces]: result.spaces,
            tags: result.tags,
            standards: result.standards,
            //code: combine,
            name: '',
            type:parent_type,
            parent_id: '',
            parent_type: '',
            //manual_id: parent_id,
            disableFields: false,
            version: '001',
            layout_id: '',
            status: 'New',
            // doc_status_id:1,
            parent_id: '',
            reason_of_change: '',
            reason_of_change_text: '',
            doc_type_id: doc_type_id,
            use_existing_file_name: use_existing_file_name,
            use_existing_file_edit_img: use_existing_file_edit_img,
            file_path: file_path,
            file_id:file_id,
          //  doc_type_id: "1",
            owners: [],
            bundles:[],
            selectedmaindocuments:[],
            bundle_options_maindoc:[],
          //  use_existing_file_name: t('Choose file'),
          //  use_existing_file_edit_img: '',
            reason_of_expiration: '',
            reason_of_expiration_extra: '',
            to_revision_date:'',
            index_doc: 1,
            export_format: 1,
            doc_status_id: -1,
            current_status_id: -1,
          //  file_id:'',
          //  file_path:'',
            reason_of_change: '',
            reason_of_change_text: '',
            available_in_masterdata: 1,
            bundle_revise_status:1,
            use_in_statistics: 1,
            show_in_whats_new: 1,
            table_of_contents: 1,
            fundamental: 0,
            revision_date: moment().format('YYYY-MM-DD'),
            due_date_days: '',
            revision_date_behaviour: 1,
            publish_date: '',
            archive_period_days: '',
            archive_period_type: 'days',
            reviewing_period_days: '',
            reviewing_period_type: 'days',
            reviewing_warning_days: '',
            reviewing_warning_type: 'days',
            reviewing_date: '',
            expiration_period_days: '',
            expiration_period_type: 'days',
            showComment: false,
            doc_details_disabled: false,
            show_whats_new_disabled: false,
            rev_details_disabled: false,
            revision_date_behaviour_disabled: false,
            to_review_date_disabled: false,
            communication_disabled: false,
            extra_tab_disabled: false,
            approvalcycle_disabled: false,
            due_date_disabled: false,
            default_tab_disabled: false,
            roc: false,
            disableFields: false,
            reviewing_period_days_disabled: false,
            expiration_period_days_disabled: false,
            default_tab_disabled: false,
            reviewing_date_disabled: false,
            exp_his_disabled: false,
            cr_webform_disabled:false,
            sucess:'',
            language_title : [],
             })
      //  })

    }
    handleDocumentCloneEmptyData() {
      const { t } = this.state;
      //this.handleNoParentData();
      //this.copyParentData();
      //  moment(startdate, "DD-MM-YYYY").add(5, 'days');
      //var d = moment(this.state.revision_date, 'YYYY-MM-DD').add(7, 'days');
      if(this.props.credentials.parent_type == 'document' || this.props.credentials.parent_type == 'webform') {
          var url = this.state.get_insert_url + '/' + this.props.credentials.parent_id;
          }
          else{
      var url = window.GET_FOLDER_DETAILS + this.props.credentials.parent_id;
          }
      // import timezone from 'moment-timezone'
      datasave.service(url, "GET")
          .then(result => {
            if(this.props.credentials.parent_type == 'document'||this.props.credentials.parent_type == 'webform') {
          var doc_type_id = result.document.doc_type_id;
          var  use_existing_file_name =  (result.document.file_path == null) ? t('Choose file') : result.document.file_path;
          var  use_existing_file_edit_img =  (result.document.file_path !== null && result.document.doc_type_id >= 4) ? t('Click here to preview') : '';
          var  file_path = result.document.file_path;
          var  file_id = result.document.file_id;
          var  webform =(result.document.webform == 1)?result.document.webform:0;
          var parent_id =  result.document.parent_id;
          var manual_id = result.document.parent_id + '-' + result.document.parent_type + '-' + result.document.manual_id;
           var parent_type= result.document.parent_type;
          // var status_id = result.document.docstatusId;
          // if(result.document.docstatusId == 8){
          // status_id = (result.document.publish_date <= current_date) ? 6:result.document.docstatusId;
          // }
        }else {
          var doc_type_id = 1;
          var  use_existing_file_name = 'Choose file';
          var  use_existing_file_edit_img = '';
          var  file_path = '';
          var  file_id = '';
          var  manual_id = result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id;
          var webform = 0;
        }
      // var next_doc_id = result.next_code[0].doc_next_id;
      // var template = result.next_code[0].template;
      // var position = result.next_code[0].position;
      // var next_position = this.getposition(position, next_doc_id);
      // template = (template) ? template : '0';
      // var combine =this.getUpdateCode(result.next_code[0].doc_next_id,result.next_code[0].template,result.next_code[0].position);
      //var parent_id = result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id;
      // this.getNotifications();
      var result = [];
      result.folder = [];
      result.standards = [];
      result.tags = [];
      result.spaces = [];
      result.r_u = [];
      result.r_u[1] = [];
      result.notifications = [];
      result.rights = [];
      result.r_u[2] = [];
      this.props.credentials.manual_flag = 0;
      var parent_type = this.props.credentials.parent_type;
      var clone_credentials = this.props.credentials;
      this.setState({
          [window.tabs.notification]: result.notifications,
          [window.tabs.r_u_default]: result.r_u[1],
          [window.tabs.r_u_extra]: result.r_u[2],
          [window.tabs.approval_cycle]: result.rights,
          [window.tabs.spaces]: result.spaces,
          tags: result.tags,
          standards: result.standards,
          clone_credentials :clone_credentials,
          //code: combine,
          name: '',
          type:parent_type,
          parent_type: '',
          //manual_id: parent_id,
          disableFields: false,
          version: '001',
          layout_id: '',
          status: 'New',
          // doc_status_id:1,
          parent_id: parent_id,
          manual_id:manual_id,
          reason_of_change: '',
          reason_of_change_text: '',
          doc_type_id: doc_type_id,
          use_existing_file_name: use_existing_file_name,
          use_existing_file_edit_img: use_existing_file_edit_img,
          file_path: file_path,
          file_id:file_id,
        //  doc_type_id: "1",
          owners: [],
        //  use_existing_file_name: t('Choose file'),
        //  use_existing_file_edit_img: '',
          reason_of_expiration: '',
          reason_of_expiration_extra: '',
          to_revision_date: '',
          index_doc: 1,
          export_format: 1,
          doc_status_id: -1,
          reason_of_change: '',
          reason_of_change_text: '',
          available_in_masterdata: 1,
          bundle_revise_status:1,
          use_in_statistics: 1,
          show_in_whats_new: 1,
          table_of_contents: 1,
          fundamental: 0,
          revision_date: moment().format('YYYY-MM-DD'),
          due_date_days: '',
          revision_date_behaviour: 1,
          publish_date: '',
          archive_period_days: '',
          archive_period_type: 'days',
          reviewing_period_days: '',
          reviewing_period_type: 'days',
          reviewing_warning_days: '',
          reviewing_warning_type: 'days',
          reviewing_date: '',
          expiration_period_days: '',
          expiration_period_type: 'days',
          showComment: false,
          doc_details_disabled: false,
          show_whats_new_disabled: false,
          rev_details_disabled: false,
          revision_date_behaviour_disabled: false,
          to_review_date_disabled: false,
          communication_disabled: false,
          extra_tab_disabled: false,
          approvalcycle_disabled: false,
          due_date_disabled: false,
          default_tab_disabled: false,
          roc: false,
          disableFields: false,
          reviewing_period_days_disabled: false,
          expiration_period_days_disabled: false,
          default_tab_disabled: false,
          reviewing_date_disabled: false,
          exp_his_disabled: false,
          cr_webform_disabled:false,
          webform:webform,
          sucess:'',
          language_title : [],
           })
      })
    }

    componentDidMount() {
        // var url = window.GET_INSERT_DOCUMENT_DETAILS_ONLY + '/' + this.props.credentials.parent_id;
        // datasave.service(url, "GET")
        //     .then(result => {
        //         this.setState({
        //             doc_id: result.id,
        //             doc_status: result.status,
        //             doc_status_id: result.docstatusId,
        //         })
        //     });
        datasave.service(this.state.get_insert_url, 'GET', '')
            .then(response => {
                this.setState({
                    layouts: response.layouts,
                    // layout_id: response.layouts[0].id,
                    doc_types: response.doc_type,
                    //doc_type_id: response.doc_type[0].id,
                    //notifications: response.notifications,
                    spaces: response.spaces,
                    spaces_types: response.spaces_types,
                })
            })
            .catch(error => {
                // this.setState({
                //     errors: error.response.data.errors
                // })
            })
            //     datasave.service(window.GET_INSERT_DOCUMENT_DETAILS,'GET','')
            // .then(response => {
            //     this.setState({
            //         notifications : response.notifications,
            //     })
            // })
            .catch(error => {
                this.setState({
                    errors: error.response.data.errors
                })
            })
        var url = window.GET_RIGHTSDETAILS
        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    tasks: result.jgd,
                    items: result.jgd,
                    types: result.types,
                    selected: [],
                })
            });
        var url = window.GET_STANDARDS;
        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    standard_options: result.standards,
                    tag_options: result.tags,
                    owner_options: result.owners,
                })
            });

        var url = window.GET_Bundles;
        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    Bundle_options: result,
                })

            });
            var url = window.GET_FOLDERS_IDS + '/' + this.props.credentials.manual_id;
            datasave.service(url, "GET")
                .then(result => {
                    if (result.length > 0) {
                        if (this.state.manual_id === '') {
                            this.setState({
                                //  manual_id: result[0].id + '-' + result[0].type + '-' + result[0].manual_id,
                                manuals: result,
                            })

                        }
                        else {
                            this.setState({
                                //manual_id: result[0].id + '-' + result[0].type + '-' + result[0].manual_id,
                                manuals: result
                            })
                        }
                        this.props.credentials.manual_flag = 0;
                    }
                });
    }

    approvalRightsPermissions() {
        if (this.props.credentials.action === 'edit') {
            if (this.state.doc_status_id === 1 || this.state.doc_status_id === 39 || this.state.doc_status_id === 40||this.state.doc_status_id === 2 ) {
                this.setState({
                    due_date_disabled: false,
                    reviewing_date_disabled:true,
                })
            }
            if (this.state.doc_status_id === 3) {
                this.setState({
                    doc_details_disabled: true,
                    show_whats_new_disabled: false,
                    rev_details_disabled: true,
                    revision_date_behaviour_disabled: false,
                    to_review_date_disabled: (this.state.reviewing_period_days == '' || this.state.reviewing_period_days == null) ? false : true,
                    extra_tab_disabled: false,
                    approvalcycle_disabled: true,
                    due_date_disabled: true,
                    default_tab_disabled: false,
                    roc: true,
                    expiration_period_days_disabled: false,
                    review_date_disabled: true,
                    reviewing_date_disabled:true,
                })
            }
            else if (this.state.doc_status_id === 4 || this.state.doc_status_id === 6 || this.state.doc_status_id === 8) {
                this.setState({
                    doc_details_disabled: true,
                    show_whats_new_disabled: false,
                    rev_details_disabled: true,
                    revision_date_behaviour_disabled: false,
                    to_review_date_disabled: (this.state.reviewing_period_days == '' || this.state.reviewing_period_days == null) ? false : true,
                    extra_tab_disabled: true,
                    approvalcycle_disabled: true,
                    due_date_disabled: true,
                    default_tab_disabled: true,
                    roc: true,
                    reviewing_period_days_disabled: false,
                    expiration_period_days_disabled: false,
                    review_date_disabled: true,
                  reviewing_date_disabled:true,
                })
            }
            else if (this.state.doc_status_id === 9) {
                this.setState({
                    doc_details_disabled: true,
                    show_whats_new_disabled: true,
                    rev_details_disabled: true,
                    revision_date_behaviour_disabled: true,
                    to_review_date_disabled: (this.state.reviewing_period_days == '' || this.state.reviewing_period_days == null) ? false : true,
                    extra_tab_disabled: false,
                    approvalcycle_disabled: true,
                    due_date_disabled: true,
                    default_tab_disabled: true,
                    review_date_disabled: true,
                    roc: true,
                    reviewing_period_days_disabled: false,
                    expiration_period_days_disabled: false,
                    reviewing_date_disabled:false,
                })
            }
            else if (this.state.doc_status_id === 10 || this.state.doc_status_id === 11 || this.state.doc_status_id === 13 || this.state.doc_status_id === 15 || this.state.doc_status_id === 16 || this.state.doc_status_id === 18) {
                let review_date_disabled = false;
                let to_review_date_disabled = false;
                if (this.state.doc_status_id === 10 || this.state.doc_status_id === 11 || this.state.doc_status_id === 13) {
                    review_date_disabled = (this.state.reviewing_period_days === '' || this.state.reviewing_period_days === null) ? false : true;
                }
                if (this.state.doc_status_id === 15 || this.state.doc_status_id === 16 || this.state.doc_status_id === 18) {
                    review_date_disabled = true;
                }
                this.setState({
                    doc_details_disabled: true,
                    show_whats_new_disabled: true,
                    rev_details_disabled: true,
                    revision_date_behaviour_disabled: true,
                    reviewing_date_disabled: true,
                    to_review_date_disabled: review_date_disabled,
                    extra_tab_disabled: false,
                    approvalcycle_disabled: true,
                    due_date_disabled: true,
                    default_tab_disabled: true,
                    roc: true,
                    reviewing_period_days_disabled: false,
                    expiration_period_days_disabled: false,
                })
            }
        }
        else if (this.state.doc_status_id === 39 || this.state.doc_status_id === 40) {
            this.setState({
                doc_details_disabled: false,
                show_whats_new_disabled: false,
                rev_details_disabled: false,
                revision_date_behaviour_disabled: false,
                to_review_date_disabled: false,
                extra_tab_disabled: false,
                approvalcycle_disabled: false,
                due_date_disabled: false,
                default_tab_disabled: false,
                roc: false,
                expiration_period_days_disabled: false,
                review_date_disabled: true,
                reviewing_date_disabled:true,

            })
        }
        else {
            this.setState({
                doc_details_disabled: false,
                show_whats_new_disabled: false,
                rev_details_disabled: false,
                revision_date_behaviour_disabled: true,
                to_review_date_disabled: false,
                reviewing_date_disabled: false,
                communication_disabled: false,
                extra_tab_disabled: false,
                approvalcycle_disabled: false,
                due_date_disabled: false,
                default_tab_disabled: false,
                roc: false,
                reviewing_period_days_disabandlepropsled: false,
            })
        }

        if (this.state.doc_status_id === 22 || this.state.doc_status_id === 23) {
            this.setState({
                doc_details_disabled: true,
                show_whats_new_disabled: true,
                rev_details_disabled: true,
                revision_date_behaviour_disabled: true,
                to_review_date_disabled: true,
                extra_tab_disabled: true,
                approvalcycle_disabled: true,
                due_date_disabled: true,
                default_tab_disabled: true,
                reviewing_date_disabled: false,
                exp_his_disabled: true,
                cr_webform_disabled:false,
                diable_ExpirationPeriod: (this.state.doc_status_id === 22) ? false : true,
                roc: true,
                //disableFields:true,
                reviewing_period_days_disabled: true,
                expiration_period_days_disabled: false,
            })
        }
    }
    handleParentData() {
        var url = window.GET_FOLDERS_IDS + '/' + this.props.credentials.manual_id;
        datasave.service(url, "GET")
            .then(result => {
                if (result.length > 0) {
                    if (this.state.manual_id === '') {
                        this.setState({
                            //  manual_id: result[0].id + '-' + result[0].type + '-' + result[0].manual_id,
                            manuals: result,
                        })

                    }
                    else {
                        this.setState({
                            //manual_id: result[0].id + '-' + result[0].type + '-' + result[0].manual_id,
                            manuals: result
                        })
                    }
                    this.props.credentials.manual_flag = 0;
                }
            });
    }
    handleNoParentData() {
      if (this.props.credentials.parent_type == 'document') {
          var url = this.state.get_insert_url + '/' + this.props.credentials.parent_id;
          datasave.service(url, "GET")
              .then(result => {
                  this.setState({
                      code: this.getUpdateCode(result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position),
                       manual_id: result.document.parent_id + '-' + result.document.parent_type + '-' + result.document.manual_id,
                  })
              });
              this.props.credentials.manual_flag = 0;
      }
      else {
          var url = window.GET_FOLDER_DETAILS + this.props.credentials.parent_id;
          datasave.service(url, "GET")
              .then(result => {
                  this.setState({
                      code: this.getUpdateCode(result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position),
                       manual_id: result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id,
                  })
              });
              this.props.credentials.manual_flag = 0;
      }

        // var url = window.GET_FOLDERS_IDS + '/' + this.props.credentials.manual_id;
        //
        // datasave.service(url, "GET")
        //     .then(result => {
        //         if (result.length > 0) {
        //             if (this.state.manual_id === '') {
        //                 this.setState({
        //                     manuals: result,
        //                     manual_id: result[0].id + '-' + result[0].type + '-' + result[0].manual_id,
        //
        //                 })
        //
        //             }
        //             else {
        //                 this.setState({
        //                     //manual_id: result[0].id + '-' + result[0].type + '-' + result[0].manual_id,
        //                     manuals: result
        //                 })
        //             }
        //             this.props.credentials.manual_flag = 0;
        //         }
        //     });
    }
    removeFileUpload() {
      const {t} = this.state;
      if(this.state.file_id != '') {
       var url = window.DELETE_UPLOADED_FILE + '/' + this.state.file_id;
       datasave.service(url, "POST")
           .then(result => {
               this.setState({
                 use_existing_file_name: t('Choose file'),
                 use_existing_file_edit_img: '',
                 sucess : '',
                 file_id: '',
                 file_path: '',
                 file_name:'',
               })
               OCAlert.alertSuccess(t('File deleted successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
          });
      }
    }
    handleCancel(event) {
        if (this.props.credentials.action == 'create') {
            this.props.cancelData();
            this.handleDocumentEmptyData();
        }
        else if (this.props.credentials.action == 'edit') {
            this.props.cancelData();
            this.handleDocumentEmptyData();
             // if(this.props.credentials.cancelPopup == 1){
             //   this.handleDocumentdata('view',0);
             // }
             // else{
             //   this.handleDocumentdata('edit',0);
             // }
        }
        else {
        }
    }
    handleSubmit = (event) => {
        var formvalid = true;
        event.preventDefault()
        this.setState({
            submitted: 'true'
        });
        for (var i = 0; i < mandatory_fields.length; i++) {
            if (this.state[mandatory_fields[i]].length === 0 || this.state.layout_id == '0' || this.state.layout_id == '') {
                formvalid = false;
            }
            //  if(this.state.doc_type_id == 4||this.state.doc_type_id == 5){
            //     formvalid = false;
            //     this.setState({
            //         upload_valid:'required',
            //         //upload_error:'Upload file is required',
            //     })
            // }
            //     else{
            //         this.setState({
            //             upload_valid:'',
            //         })
            //     }

        }

        if (formvalid) {

            if ((this.state.clonename === this.state.name) && (this.state.code === this.state.clonecode) || this.props.credentials.action === "create") {
                this.formSave();

            } else {

                if (this.state.namedata.length > 0 && this.state.clonename !== this.state.name) {
                    if (this.state.clonecode !== this.state.code && this.state.name !== this.state.clonename) {
                        this.setState({
                            show: true, both: false
                        })
                    } else {
                        this.setState({
                            show: true
                        })
                    }

                } else {
                    if (this.state.codedata.length > 0 && this.state.clonecode !== this.state.code) {

                        this.setState({
                            show: true
                        })
                    } else {
                        this.formSave();
                    }
                }

            }
        }else {
          OCAlert.alertWarning('You still have empty fields that are required, please fill these in and try again',{timeOut: window.TIMEOUTNOTIFICATION})
        }

    }
    formSave() {
        const { t } = this.state;
        const { history } = this.props
        if (this.props.credentials.action === 'edit') {
            if (this.props.credentials.parent_type === 'document') {
                var url = this.state.get_insert_url + '/' + this.props.credentials.parent_id;
                console.log(this.state.get_insert_url);
                console.log(this.props.credentials.parent_id);
                datasave.service(url, 'PUT', this.state)
                    .then(response => {

                        if (response != window.SUCCESS) {
                            this.setState({
                                code_error: (response.updatedObjDocument) ? response.updatedObjDocument : '',
                                // code_error: response.code,
                                // name_error: response.name,
                                // type_error: response.doc_type,
                                // export_format_error: response.export_format,
                                // layout_error: response.layout,
                            })
                            OCAlert.alertWarning('Something went wrong,please try again', {timeOut: window.TIMEOUTNOTIFICATION})
                        } else {
                            this.setState({
                                disableFields: true,

                            });
                             this.props.updateFolder(this.props.credentials.manual_id);
                            OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
                        }
                    })

            }
        } else {
            datasave.service(this.state.get_insert_url, 'POST', this.state)
                .then(resultObj => {
                    if (resultObj.updatedObjDocument.datafolder === undefined) {
                        this.setState({
                            code_error: (resultObj.updatedObjDocument) ? resultObj.updatedObjDocument : '',
                            // name_error: (resultObj.updatedObjDocument.name) ? resultObj.updatedObjDocument.name[0] : '',
                            // type_error: (resultObj.updatedObjDocument.doc_type_id) ? resultObj.updatedObjDocument.doc_type_id[0] : '',
                            // export_format_error: (resultObj.updatedObjDocument.export_format) ? resultObj.updatedObjDocument.export_format[0] : '',
                            // layout_error: resultObj.updatedObjDocument.layout[0],
                        })
                        OCAlert.alertWarning('Something went wrong,please try again', {timeOut: window.TIMEOUTNOTIFICATION})
                    }
                    else {
                        this.props.updateFolder(this.props.credentials.manual_id, 'D' + resultObj.updatedObjDocument.id);
                        //this.props.updateFolder(resultObj.updatedObjDocument.datafolder);
                        this.setState({
                            disableFields: true,

                        });
                        OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
                    }
                    // if (response.name || response.code || response.doc_type || response.export_format || response.layout) {
                    //     this.setState({
                    //         code_error: response.code,
                    //         name_error: response.name,
                    //         type_error: response.doc_type,
                    //         export_format_error: response.export_format,
                    //         layout_error: response.layout,
                    //     })
                    // } else if (response.data === 'success') {

                })
                .catch(error => {
                    // this.setState({
                    //     errors: error.response.data.errors
                    // })
                })
        }
    }
    getDuedate(count, type) {


    }
    filterArray = (allList, selectedList) => {
        var pack_func = allList;
        Object.values(selectedList).map(
            function (item, key) {
                pack_func = pack_func.filter(selected => (selected.id !== item.id));
            }, this);
        return pack_func;
    }
    handleSelect(event) {
        const { name, value } = event.target;
        this.setState({
            [name]: !this.state[name],
        })
    }

    handleChangenum(event) {
        const { name, value } = event.target;
        const re = /^[0-9\b]+$/;
        if (name == 'reviewing_period_days' && value != '') {
          var rev = this.state.revision_date;
          rev = (rev !== null)?rev:moment().format('YYYY-MM-DD');
            var d = moment(rev, 'YYYY-MM-DD').add(value, this.state.reviewing_period_type);
            this.setState({
                to_revision_date: d.format('YYYY-MM-DD'),
                to_review_date_disabled:true,
                [name]: value,
            })
        }
        else if (name == 'reviewing_period_days' && value === '') {
            this.setState({
                to_revision_date: '',
                to_review_date_disabled:false,
                [name]: value,
            })
        }
        // if value is not blank, then test the regex
        // value === '' ||
        if ( (value != ''&& re.test(value))  || value === '') {
            this.setState({ [name]: value })
        }
    }
    handleChangeReviewdate(value,type) {
      var d = moment().format('YYYY-MM-DD');
      if (value != '' && value != null) {
          var rev = moment(d, 'YYYY-MM-DD').add(value, type);
          return rev.format('YYYY-MM-DD')
      }
      else if(value === 0) {
          return d;
      }
      else{
        return null;
      }
    }
    handleChange(event) {
        const { name, value } = event.target;
        if (name == 'code') {
            this.setState({ [name]: value, code_error: '' });
        }
        else if (name == 'reviewing_period_type') {
            var d = moment(this.state.revision_date, 'YYYY-MM-DD').add(this.state.reviewing_period_days, value);
            this.setState({
                to_revision_date: d.format('YYYY-MM-DD'),
                [name]: value,
            })
        }
        else if(name == 'doc_type_id' && value != this.state.doc_type_id){
          this.setState({
              use_existing_file_name:null,
              use_existing_file_edit_img:'',
              file_path:'',
              file_id:'',
              sucess:'',
              [name]: value,
          })
        }
        else if(name == 'reason_of_change_text') {
          this.setState({ [name]: value,roc_update :1 });
        }
        else {
            this.setState({ [name]: value });
        }
    }

    handleChangeMultiStandard(event) {
        this.setState({ standards: event });
    }
    handleChangeMultiTag(event) {
        this.setState({ tags: event });
    }
    handleChangeMultiOwner(event) {
        this.setState({ owners: event });
    }
    handleChangeMultiBundle(event) {
        let difference = this.state.bundles.filter(x => !event.includes(x));

        this.setState({
            bundles: event,
            bundle_options_maindoc: event,
        });
        if (difference.length > 0) {
            var removed_list = this.state.selectedmaindocuments;
            difference.map(function (items, key) {
                removed_list = removed_list.filter(remove => (remove.value !== items.value))
            }, this);
            this.setState(prevState => ({
                selectedmaindocuments: removed_list,
            }));
        }
    }
    handlemaindocumentbundle(e, data) {
        this.setState({ selectedmaindocuments: e });
    }
    handleFile(event) {
        const { t } = this.state;
        if (event.target.files[0] !== undefined || event.target.files[0] !== null) {
            this.setState({
                doc_use_existing_file: event.target.files[0],
                use_existing_file_name: event.target.files[0]['name'],
                use_existing_file_sucess: t('file uploaded sucessfully'),
                use_existing_file_edit_img: '',


            })
            let files = event.target.files || event.dataTransfer.files;
            if (!files.length)
                return;
            this.createImage(files[0]);
        }
    }
    createImage(file) {
        let reader = new FileReader();
        reader.onload = (e) => {
            this.setState({
                doc_use_existing_file: e.target.result
            })
        };
        reader.readAsDataURL(file);
    }
    updateSelected = (latestDropped, result, type, id = '') => {
        var array = [...this.state[type]]; // make a separate copy of the array
        if (result.type === 'remove') {
            var filterArray = array.filter(selected => (selected.name !== latestDropped.name));
        }
        if (result.type === 'remove') {
            this.setState({
                [type]: filterArray
            })
        }
        else {
            this.setState(prevState => ({
                [type]: [...prevState[type], latestDropped]
            }));
        }
    }
    updateSelectedRights = (latestList) => {
        this.setState({
            [window.tabs.approval_cycle]: latestList,
        })
    }
    handleActiveTab(key) {
        this.setState({
            active_tab: key,
        });
    }
    handleNotification = (latestDropped, result, type, id) => {
        var array = [];
        if (this.state[type] !== undefined && this.state[type].length > 0) {
            array = [...this.state[type]];
            var selectedArrayMatched = array.filter(selected => (selected.n_id === id));
            var selectedArrayUnmatched = array.filter(selected => (selected.n_id !== id));
        }
        if (result.type === 'remove' && array.length > 0) {
            var filterArrayObj = selectedArrayMatched.filter(selected => (selected.id !== latestDropped.id));
            Array.prototype.push.apply(selectedArrayUnmatched, filterArrayObj)
            this.setState({
                [type]: selectedArrayUnmatched,
            })
        } else {
            var obj = {};
            Object.keys(latestDropped).forEach(function (key) {
                obj[key] = latestDropped[key];
            })
            obj['n_id'] = id;
            this.setState(prevState => ({
                [type]: [...prevState[type], obj]
            }));
        }
    }
    handleNotificationSelect(data) {
        this.setState({
            notifications: data
        })
    }
    handlehide() {
        this.setState({
            show: false
        })
    }
    handlePopOk() {
        this.formSave();
        this.handlehide()
    }
    handleChangeFileUpload(e) {
        const { t } = this.state;
        let Userdata = store.getState();
        let systemsettings = Userdata.UserData.systemsettings;
        let doc_type = this.state.doc_type_id;
        const name = e.target.files[0].name;
        const lastDot = name.lastIndexOf('.');

        const fileName = name.substring(0, lastDot);
        const ext = name.substring(lastDot + 1);
        const validateType = window.DOC_TYPES_validate[doc_type].includes(ext);
        if (doc_type <= 4 && validateType === false) {
          OCAlert.alertError(t('Please upload respective format ' + window.DOC_TYPES[doc_type]), { timeOut: window.TIMEOUTNOTIFICATION });
          return false;
        }
        let kilobytes = (e.target.files[0]['size'] / 1000).toFixed(1);
        let megabytes = kilobytes / 1024;
        let sizeType = 4;
        let specifiedSize = 1024;
        if (doc_type <= 3) {
          sizeType = systemsettings['18-1'] == undefined ? 4 : parseInt(systemsettings['18-1']);
          specifiedSize = systemsettings['17-1'] == undefined ? 1024 : parseInt(systemsettings['17-1']);
        }
        else if (doc_type > 3) {
          sizeType = systemsettings['20-1'] == undefined ? 4 : parseInt(systemsettings['20-1']);
          specifiedSize = systemsettings['19-1'] == undefined ? 1024 : parseInt(systemsettings['19-1']);
        }


        if (sizeType == 4 && kilobytes > specifiedSize || sizeType == 5 && megabytes > specifiedSize) {
            OCAlert.alertError(t('Size of a document is more than specified size in settings'), { timeOut: window.TIMEOUTNOTIFICATION });
        } else {
            this.handleUpload(e);
        }
    }
    handleUpload(e) {
        this.setState({
            file_name: e.target.files[0]['name'],
            // location: this.props.state.location,
            // folder: this.props.state.folder,
        })
        if (e.target.name === 'image') {
            if (e.target.files[0] !== undefined || e.target.files[0] !== null) {
                const formData = new FormData();
                formData.append('file', e.target.files[0])
                const url = window.UPLOAD_FILE + '/' + parseInt(this.state.doc_type_id);
                document.getElementById("loding-icon").setAttribute("style", "display:block;");
                axios.post(window.backendURL + url, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
                    .then(response => {
                        document.getElementById("loding-icon").setAttribute("style", "display:none;");

                        this.updateImageUpload(response);
                    })
                    .catch(error => {
                        document.getElementById("loding-icon").setAttribute("style", "display:none;");

                        this.setState({
                            errors: error.response.data.errors
                        })
                    })
            }
        }
    }
    disableAllTabs(){
      this.setState({
        active_tab : undefined,
      });
    }
    handleAddSpace(){
      this.props.actionEdit(this.props.credentials.parent_id, this.props.credentials.parent_type, 'edit', this.props.credentials.addtype, this.props.credentials.manual_id, this.props.credentials.access_details);
      this.setState({
        defaultKeyForSpace : 3,
        active_tab : 1,
      });
    }
    handleChangeTransaltion () {
        this.setState({
            showtranslation:true,
        })
    }
    handleTranslationCancel (translatedstring) {
      this.setState({
        showtranslation:false,
        language_title : translatedstring,
        entity_type : 3,
      })
    }

    render() {
        const { clonecode, clonename, code, name, t } = this.state
console.log(this.props.credentials.rights)
        const data1 = this.state.codedata.map(item => {
            return (
                <tr>
                    <td>{item.code}</td>
                    <td>{item.name}</td>
                </tr>
            )
        })
        const data2 = this.state.namedata.map(item => {
            return (
                <tr>
                    <td>{item.code}</td>
                    <td>{item.name}</td>
                </tr>
            )
        })
        const data3 = this.state.combined.map(item => {
            return (
                <tr>
                    <td>{item.code}</td>
                    <td>{item.name}</td>
                </tr>
            )
        })

        const popup = (
            <reactbootstrap.Modal
                size="lg"
                show={this.state.show}
                onHide={this.handlehide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title">
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                    </reactbootstrap.Modal.Title>
                    <reactbootstrap.Modal.Body>
                        <reactbootstrap.Tabs id="controlled-tab-example">
                            <reactbootstrap.Tab eventKey={1} title={t("Used in")}>
                                <reactbootstrap.Table striped bordered hover size="sm">
                                    <thead>
                                        <tr>
                                            <th>{t('Document code')}</th>
                                            <th>{t('Document name')}</th>
                                        </tr>
                                    </thead>

                                    {this.state.both &&
                                        <>
                                            {clonename !== name &&
                                                data1}
                                            {clonecode !== code &&
                                                data2}
                                        </>}

                                    {(clonename !== name) && (clonecode !== code) && data3}
                                </reactbootstrap.Table>
                                {/* <Pagination   size="sm">{pageNumbers}</Pagination> */}
                                <reactbootstrap.Table striped bordered hover size="sm">
                                    <thead>
                                        {clonename !== name &&
                                            <tr>
                                                <th className="taghead" style={{ width: '30%' }}>{t('Previous name')}</th>
                                                <td>{clonename}</td>
                                            </tr>
                                        }
                                        {clonename !== name &&
                                            <tr>
                                                <th className="taghead" style={{ width: '30%' }}>{t('Updated name')}</th>
                                                <td>{name}</td>
                                            </tr>}
                                        {clonecode !== code &&
                                            <tr>
                                                <th className="taghead" style={{ width: '30%' }}>{t('Previous code')}</th>
                                                <td>{clonecode}</td>
                                            </tr>
                                        }{clonecode !== code &&
                                            <tr>
                                                <th className="taghead" style={{ width: '30%' }}>{t('Updated code')}</th>
                                                <td>{code}</td>
                                            </tr>
                                        }
                                    </thead>
                                </reactbootstrap.Table>
                            </reactbootstrap.Tab>
                        </reactbootstrap.Tabs>
                    </reactbootstrap.Modal.Body>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button onClick={() => this.handlehide()}>{t('Cancel')}</reactbootstrap.Button>
                    &nbsp;&nbsp; &nbsp;&nbsp;
              <reactbootstrap.Button onClick={() => this.handlePopOk()}>{t('Edit')}</reactbootstrap.Button>
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );


        const date = new Date();

        if (this.props.credentials.manual_flag && this.props.credentials.cycle_run == 0 && this.props.credentials.action === 'create') {
          //&& this.props.credentials.action === 'create') {
            this.handleParentData();
        }
        if (this.props.credentials.manual_flag === 1) {
            if (this.props.credentials.action === 'edit') {
                if (this.props.credentials.parent_type === 'document') {
                  if(this.props.cancelPopup == 1)
                  {
                    this.handleDocumentEmptyData();
                    this.handleDocumentdata('view',0);
                  }
                    if (this.props.credentials.manual_flag && this.props.cancelPopup == 0) {
                        this.handleDocumentEmptyData();
                        this.handleDocumentdata('edit');

                    }
                }
            }
            else if (this.props.credentials.action === 'view') {
                if (this.props.credentials.parent_type === 'document') {
                    if (this.props.credentials.manual_flag) {
                      if(this.props.credentials.cycle_run == 0) {
                        this.handleDocumentEmptyData();
                      }
                        this.handleDocumentdata('view');
                    }
                }
            }
            else {
                if (this.props.credentials.manual_flag) {
                    this.confirmPopup();
                    // var alert = window.confirm('Do yoy want copy the parent folder data');
                    // if (alert === true) {
                    //     this.handleCopyData();
                    // }
                    // else {
                    //     this.handleDocumentEmptyData();
                    // }
                }
            }
        }
        return (
            <div>
                {popup}
                <Can
                    perform="Manual_management,R_manual,E_manual,R_folder,E_folder,V_DOC_rights,C_DOC_rights,V_R_U_rights,M_R_U,AIS_extra_R_U_rights,V_extra_R_U_rights,V_notification_rights,Change_notification_rights,R_space,E_space,D_space"
                    yes={() => (
                        <DocumentComponent
                            // renderSwitch = {this.renderSwitch.bind(this)}
                            handleChange={this.handleChange.bind(this)}
                            handleSubmit={this.handleSubmit.bind(this)}
                            handleCancel={this.handleCancel.bind(this)}
                            handleSelect={this.handleSelect.bind(this)}
                            handleFile={this.handleFile.bind(this)}
                            handleChangenum={this.handleChangenum.bind(this)}
                            updateSelected={this.updateSelected.bind(this)}
                            handleActiveTab={this.handleActiveTab.bind(this)}
                            updateSelectedRights={this.updateSelectedRights.bind(this)}
                            handleChangeMultiStandard={this.handleChangeMultiStandard.bind(this)}
                            handleChangeMultiOwner={this.handleChangeMultiOwner.bind(this)}
                            handleChangeMultiTag={this.handleChangeMultiTag.bind(this)}
                            updateImageUpload={this.updateImageUpload.bind(this)}
                            handleNotification={this.handleNotification}
                            notificationObject={this.state.notification}
                            handleNotificationSelect={this.handleNotificationSelect}
                            handleChangeFileUpload = {this.handleChangeFileUpload}
                            removeFileUpload = {this.removeFileUpload}
                            details={this.state}
                            code_error={this.state.code_error}
                            name_error={this.state.name_error}
                            filterArray={this.filterArray.bind(this)}
                            handleChangeMultiBundle={(e) => this.handleChangeMultiBundle(e, this)}
                            handlemaindocumentbundle={(e) => this.handlemaindocumentbundle(e, this)}
                            object={this.state}
                            credentials={this.props.credentials}
                            handlecycle={this.props.handleCycle}
                            handleprops={this.props}
                            spacesExist={this.state.spaces.length > 0 ? true : false}
                            handleAddSpace = {this.handleAddSpace.bind(this)}
                            defaultKeyForSpace = {this.state.defaultKeyForSpace}
                            disableAllTabs = {this.disableAllTabs.bind(this)}
                            corporate = {this.state.corporate}
                            handleChangeTransaltion = {this.handleChangeTransaltion.bind(this)}
                        />
                    )}
                />
                {this.state.showtranslation &&
                <DocumenTranslation name={this.state.name} showtranslation={this.state.showtranslation} handleTranslationCancel={this.handleTranslationCancel.bind(this)} doc_id={this.props.credentials.parent_id} parent_type={this.props.credentials.parent_type} action={this.props.credentials.action} entity_type={3}></DocumenTranslation>}
            </div>
        );
    }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(Document));
