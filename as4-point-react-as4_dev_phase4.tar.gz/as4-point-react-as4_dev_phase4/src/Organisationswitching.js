import React, { Component } from 'react';
import axios from 'axios';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from './language';
import { datasave } from './_services/db_services';
import MultiSelect from './_components/MultiSelect';
import { Button, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import { Input, Label } from 'reactstrap';
import legalform from './legal_form.json';
import fte from './fte.json';

import { OCAlert } from '@opuscapita/react-alerts';




// import Iframe from 'react-iframe'

class Organisationswitching extends Component {
    constructor(props) {
        super(props)
        this.state = {
            save: 'Save',
            credentials: this.props.credentials,
            file: '',
            file_details: '',
            showpopup: false,
            t: props.t,
            eventcancel: false,
            thruprops: true,
            no_of_sites : 0,
            selectedorganisation : '',
            activeTab : 0,
            legalform: legalform,
            fte_form: fte,
            industries_data: [],
            vatnumber:'',
            telephone:'',
            fax:'',
            address:'',
            location_id:'',
            industry:'',
            siteList:[],
            site : '',
            industry_sub_data: [],
            multiIndustry: [],



        }
        // this.handleChangeFile = this.handleChangeFile.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.cancelPopup = this.cancelPopup.bind(this);
        this.showPopup = this.showPopup.bind(this);
        this.handleTab = this.handleTab.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handlechangeorganisation = this.handlechangeorganisation.bind(this);
        this.checkNoofSites = this.checkNoofSites.bind(this);
        this.handleChangeSector = this.handleChangeSector.bind(this);
        this.handleChangeMultiIndustry = this.handleChangeMultiIndustry.bind(this);


    }
    // handleChangeFile(e) {
    //     //    e.preventDefault(e);
    //     this.setState({
    //         file_details: e.target.value,
    //         file: e.target.files[0],
    //     })
    // }
    handleSubmit() {
      this.setState({ submitted: true })
      const data ={
        vatnumber : this.state.vatnumber,
        telephone : this.state.telephone,
        fax : this.state.fax,
        address : this.state.address,
        destination_id : this.state.selectedorganisation,
        parentsite : this.state.site,
        location :this.state.location_id,
        fte : this.state.fte,
        legalform : this.state.legal_form,
        sector : this.state.industry,
        sitestatus : 1,
        source_id : this.props.id,
        sub_industry: this.state.multiIndustry,

      }
      if((this.state.vatnumber!=''&&this.state.telephone!='')&&(this.state.fax!=''&& this.state.address!='')
      &&(this.state.selectedorganisation.length!=0&&this.state.site.length!=0)&&(this.state.location_id&&this.state.fte.length!=0)&&
      (this.state.legal_form.length!=0&&this.state.industry.length!=0)){

        if(this.state.selectedorganisation==this.props.id) {
          this.swiththeOrganisationUndersite(this.state.site,data);
        }
        else{
          this.checkNoofSites(data);
        }
      }
    }
    checkNoofSites(data) {
      const details = {
         id: this.state.selectedorganisation,
      }
      console.log(this.state.selectedorganisation);

      let destinationorg = [];
      let sourceorg =[];

         datasave.service(window.GET_NO_OF_SITES, 'POST', details)
            .then(response => {
                destinationorg = this.props.activedata.filter((menu) =>menu.id==this.state.selectedorganisation);
                sourceorg=this.props.activedata.filter((menu)=>menu.id==this.props.id);
                if(destinationorg[0]['site']!=undefined) {
                  let remaining_site = parseInt(destinationorg[0]['no_of_sites'])-parseInt(destinationorg[0]['site'].length);
                  let sourceorg_sites=  (sourceorg[0]['site']!=undefined?parseInt(sourceorg[0]['site'].length):0)
                  let addingsites = sourceorg_sites+1;
                   if(remaining_site>=addingsites) {
                      this.orgSwitching(data)
                   }
                   else{
                      OCAlert.alertWarning(this.state.t('Number of sites are exceeded under this organisation, please contact the admin!'), { timeOut: window.TIMEOUTNOTIFICATION1});
                   }
                }
                else{
                  let sourceorg_sites=  (sourceorg[0]['site']!=undefined?parseInt(sourceorg[0]['site'].length):0)
                  let addingsites = sourceorg_sites+1;
                   if(destinationorg[0]['no_of_sites']>=addingsites){
                      this.orgSwitching(data)
                   }
                   else {
                      OCAlert.alertWarning(this.state.t('Number of sites are exceeded under this organisation, please contact the admin!'), { timeOut: window.TIMEOUTNOTIFICATION1});
                    }
                }
               this.cancelPopup();
        })
    }
    swiththeOrganisationUndersite(id,data) {

      datasave.service(window.ORGANISATION_SWITCHING,'POST',data)
      .then(response => {
        window.location.reload();
      })
    }
    orgSwitching (data) {

      datasave.service(window.ORGANISATION_SWITCHING,'POST',data)
      .then(response => {
        window.location.reload();
      })
    }
    handleCancel(e) {
        this.cancelPopup();
    }
    cancelPopup() {
        this.setState({ showpopup: false, eventcancel: true });
        this.props.changeStatus(false)
    }
    showPopup() {
        this.setState({ showpopup: true });
    }
    componentDidMount () {
      this.setState({
        showpopup: this.props.status,
        id : this.props.id,
        selectedorganisation : this.props.id,
      })
      this.getSiteofOrganisation(this.props.id);
      // datasave.service(window.GET_MANUALS_SWITCHING, 'POST', data)
      //   .then(response=>{
      //     console.log(response);
      //     this.setState({
      //       manual_list:response,
      //     })
      //   })

      datasave.service(window.sectors, 'GET')
        .then(response => {
          this.setState({
            industries_data: response
          })
        })
    }
    handleChangeMultiIndustry(event) {
      if (event.target == undefined) {
        const { value } = event;
        this.setState({ multiIndustry: event });
      }

    }
    handleChangeSector(event) {
      this.setState({
        industry: event.target.value,
        loading: false
      })
      const details = {
        id: event.target.value
      }
      this.setState({
        multiIndustry: []
      })
      datasave.service(window.GET_SUBSECTOR, 'post', details)
        .then(result => {
          this.setState({
            industry_sub_data: result
          })
        })
    }
    getSiteofOrganisation(id) {
      const data ={
        id:id
      }
      datasave.service(window.GET_ORGANISATION_SITES, 'post', data)
        .then(response => {
          if(id==this.props.id){
            this.setState({
              siteList: response['site'].filter((menu) =>menu.id!==this.props.id),
            })
          }
          else{
            this.setState({
              siteList: response['site'],
            })
          }

        })
    }

    handleTab(k){
      this.setState({
        activeTab:k
      })
    }
    handleChange = (e) =>{
      const {name,value} = e.target;
      this.setState({
        [name]:value
      })
    }
    handleChangeNumber =(event) =>{
      if (/^(?:[0-9\b]*)$/.test(event.target.value)) {
        this.setState({
          telephone: event.target.value,
        })
      }
    }
  getLegalOptionItems() {
      let temp = [];
      if (this.state.legalform.length >= 1) {
          if (this.state.legalform) {
              temp = this.state.legalform.map((legal) => {
                return (<option id={legal.id} value={legal.value} >{legal.value}</option>)
              }
            );
            return temp;
          }
      }
  }
  handlechangeorganisation (e) {
    this.setState({
      selectedorganisation:e.target.value
    })
    this.getSiteofOrganisation(e.target.value);
  }
  getFTEOptionItems() {
      let temp = [];
      if (this.state.fte_form.length >= 1) {
          if (this.state.fte_form) {
              temp = this.state.fte_form.map((fte) => {
                return (<option value={fte.value}>{fte.value}</option>)
              }
            );
            return temp;
          }
      }
  }
  getSectorOptionItems() {
      let temp = [];
      if (this.state.industries_data.length >= 1) {
          if (this.state.industries_data) {
              temp = this.state.industries_data.map((ind) => {
                return (<option id={ind.id} value={ind.id} >{ind.name}</option>)
              }
            );
            return temp;
          }
      }
  }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.import !== this.props.import) {
            this.setState({
                showpopup: true,
            });
        }
    }
      render() {
        const { t,loading, memo_data, error, id,telephone,submitted,vatnumber,industry } = this.state;
        return (
            <reactbootstrap.Modal show={this.state.showpopup} onHide={this.cancelPopup}  aria-labelledby="example-custom-modal-styling-title" size='xl'>
                <reactbootstrap.Modal.Header closeButton >
                  <reactbootstrap.Modal.Title id="contained-modal-title-vcenter" />
                      <reactbootstrap.Modal.Body col-md-12 pr-0>
                      <reactbootstrap.Tabs activeKey = {this.state.activeTab} onSelect={(k) => { this.handleTab(k) }}>

                      <reactbootstrap.Tab eventKey ={0} title = {'sites'}>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('VAT number')}:<span style={{ color: "red" }}>*</span></InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <Input type="text"
                                className="form-control"
                                name="vatnumber"
                                value={vatnumber}
                                onChange={this.handleChange}
                                id="vatnumber"
                                placeholder=""
                                className="input_sw"
                              />
                              <div className="mt-2" >{!this.state.vatnumber && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                            </div>
                          </InputGroup>
                        </div>
                      </FormGroup>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Phone number')}: <span style={{ color: "red" }}>*</span></InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <Form.Control
                                name='telephone'
                                className="input_sw"
                                placeholder={t("Enter Number")}
                                aria-label="Telephone"
                                aria-describedby="basic-addon1"
                                value={telephone}
                                onChange={this.handleChangeNumber}
                              />
                              <div className="mt-2"> {!this.state.telephone && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                            </div>
                          </InputGroup>
                        </div>

                      </FormGroup>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('FAX')}: <span style={{ color: "red" }}>*</span></InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <Input type="text"
                                className="form-control"
                                name="fax"
                                value={this.state.fax}
                                onChange={this.handleChange}
                                id="fax"
                                placeholder=""
                                className="input_sw"
                              />
                              <div className="mt-2">{!this.state.fax && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                            </div>
                          </InputGroup>
                        </div>
                      </FormGroup>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Address')}: <span style={{ color: "red" }}>*</span></InputGroup >
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <Input type="text"
                                className="form-control"
                                name="address"
                                value={this.state.address}
                                onChange={this.handleChange}
                                id="fax"
                                placeholder=""
                                className="input_sw"
                              />
                              <div className="mt-2">{!this.state.address && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                            </div>
                          </InputGroup>
                        </div>
                      </FormGroup>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Organisation')}:<span style={{ color: "red" }}>*</span></InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <FormControl as="select" name="paresite"
                                className="input_sw"
                                value={this.state.selectedorganisation}
                                onChange={this.handlechangeorganisation} >
                                <option>{t('Select')}</option>
                                {/*{this.getOptionItems()} */}
                                 {this.props.activedata.map(org => <option value={org.id}>{org.name}</option>)}
                              </FormControl>
                              <div className="mt-2">{!this.state.selectedorganisation && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                            </div>
                          </InputGroup>
                        </div>

                      </FormGroup>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Parent site')}:<span style={{ color: "red" }}>*</span></InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <FormControl as="select" name="paresite"
                                className="input_sw"
                                disabled={this.state.required}
                                value={this.state.site}
                                onChange={e => this.setState({ site: e.target.value, loading: false })} >
                                <option>{t('Select')}</option>
                                {/*{this.getParentSiteOptions()} */}

                              {this.state.siteList.map(site => <option value={site.id}>{site.name}</option>)}
                              </FormControl>
                              <div className="mt-2" style={{ color: 'red' }} className="error-block">{this.state.siteerror} </div>
                              <div className="mt-2">
                                {this.state.site.length==0&& submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                              </div>
                            </div>

                          </InputGroup>

                        </div>
                      </FormGroup>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Location')}:<span style={{ color: "red" }}>*</span></InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <FormControl
                                name="location_id"
                                className="input_sw"
                                value={this.state.location_id}
                                onChange={e => this.setState({ location_id: e.target.value, loading: false })}
                                placeholder={t("Location")}
                                aria-label="location"
                                aria-describedby="basic-addon1">
                                {/* <option value='0'>Select</option>
                        {this.state.locations_data.map(location => <option value={location.id}>{location.locations}</option>)} */}
                              </FormControl>
                              <div className="mt-2">
                                {!this.state.location_id && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                              </div>
                            </div>

                          </InputGroup>
                        </div>
                      </FormGroup>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('FTE')}:<span style={{ color: "red" }}>*</span></InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <Form.Control as="select" name="fte"
                                className="input_sw"
                                value={this.state.fte}
                                onChange={e => this.setState({ fte: e.target.value, loading: false })} >
                                <option>{t('Select')}</option>
                                {this.getFTEOptionItems()}
                              </Form.Control>
                              <div className="mt-2">
                                {!this.state.fte && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                              </div>
                            </div>
                          </InputGroup>
                        </div>
                      </FormGroup>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Legal form')}:<span style={{ color: "red" }}>*</span></InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div className="col-md-8 input-padd">
                              <Form.Control as="select" name="legal_form"
                                className="input_sw"
                                value={this.state.legal_form}
                                onChange={e => this.setState({ legal_form: e.target.value, loading: false })} >
                                <option>{t('Select')}</option>
                                {this.getLegalOptionItems()}
                              </Form.Control>
                              <div className="mt-2">
                                {!this.state.legal_form && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                              </div>
                            </div>

                          </InputGroup>
                        </div>
                      </FormGroup>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Sector')}:<span style={{ color: "red" }}>*</span></InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <Form.Control as="select" name="industry"
                                className="input_sw"
                                value={industry}
                                onChange={this.handleChangeSector} >
                                <option id='0' value='0'> {t('Select')}</option>
                                {this.getSectorOptionItems()}
                              </Form.Control>
                              <div className="mt-2">
                                {!this.state.industry && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                            </div>
                          </InputGroup>
                        </div>
                      </FormGroup>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Sub sector')}:</InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <div className="input_sw">
                                <MultiSelect
                                  options={this.state.industry_sub_data}
                                  // disabled={details.disableFields}
                                  standards={this.state.multiIndustry}
                                  handleChange={this.handleChangeMultiIndustry}
                                />
                              </div>
                            </div>
                          </InputGroup>
                        </div>
                      </FormGroup>


                      </reactbootstrap.Tab>
                      </reactbootstrap.Tabs>


                      </reactbootstrap.Modal.Body>
                    </reactbootstrap.Modal.Header >
                    <reactbootstrap.Modal.Footer>
                      <reactbootstrap.Button onClick={() => this.handleSubmit()}>{'Save'}</reactbootstrap.Button>

                        <reactbootstrap.Button onClick={() => this.handleCancel()}>{'Close'}</reactbootstrap.Button>
                    </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );
    }
}
export default translate(Organisationswitching)
