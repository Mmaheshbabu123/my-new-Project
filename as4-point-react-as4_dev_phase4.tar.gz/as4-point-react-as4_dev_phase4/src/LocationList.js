import axios from 'axios'
    import React, { Component } from 'react'
    import { Link } from 'react-router-dom'
    import * as reactbootstrap from 'react-bootstrap';
    import {translate} from './language';

    class LocationList extends Component {
      constructor (props) {
        super(props)
        this.state = {
          locations: [],
          t:props.t,
        }
      }
      componentDidMount () {
        axios.get(process.env.REACT_APP_serverURL + '/api/location').then(response => {
          this.setState({
            locations: response.data
          })
        })
      }

      render () {
        const { locations,t } = this.state
        return (
          <div className='container py-4'>
            <div className='row justify-content-center'>
              <div className='col-md-8'>
                <div className='card'>
                  <div className='card-header'>{t('All locations')}</div>
                  <div className='card-body'>
                  <reactbootstrap.Table responsive>
                    <thead>
                      <tr>
                        <th>{t('Name of location')}</th>
                        <th colspan="2">{t('Actions')}</th>
                      </tr>
                    </thead>
                      <tbody>
                      {locations.map(location => (
                      <tr>
                        <td>{location.locations} </td>
                        <td>
                        <Link
                          className='list-group-item list-group-item-action d-flex justify-content-between align-items-center'
                          to={`/${location.id}`}
                          key={location.id}
                        >
                          {t('Edit')}
                        </Link>
                        </td>
                        <td>
                        <Link
                          className='list-group-item list-group-item-action d-flex justify-content-between align-items-center'
                          to={`/${location.id}`}
                          key={location.id}
                        >
                          {t('Delete')}
                        </Link>
                        </td>
                      </tr>
                      ))}
                      </tbody>
                    </reactbootstrap.Table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )
      }
    }

    export default translate(LocationList)
