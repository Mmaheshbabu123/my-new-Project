import React, { Component } from 'react';
import { Modal, Button } from 'react-bootstrap';
import { datasave } from '../src/_services/db_services'
import DragnDrop from '../src/DragnDrop'
import { filterArray } from './_helpers/filter-array'




class DashBoardPopUp extends Component {

    constructor(props) {
        super(props);

        this.state = {






        }


        // this.updateNotification = this.updateNotification.bind(this);
        // this.handleCheck = this.handleCheck.bind(this);
        //  this.handleChangeOrder = this.handleChangeOrder.bind(this);
    }





    render() {


        return (

            < div >





                <Button>hello</Button>



            </div >
        )
    }
    componentDidMount() {


    }

}

export default DashBoardPopUp;
