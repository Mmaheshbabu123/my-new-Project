import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { throwStatement } from '@babel/types';
import { AgGridReact } from 'ag-grid-react';

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import './NavigationView.css';
import { translate } from '../language';
import { persistor, store } from '../store';
import DocumentReportView from './DocumentReportView';
import WebformReportView from './WebformReportView';
import ReactDataGrid from "react-data-grid-defaultvalue";
import PopUpModal from './PopUpModal';
import { Editors, Data, Filters,Toolbar } from "react-data-grid-addons-default-filters";
import { OCAlert } from '@opuscapita/react-alerts';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css';
import {ReactDataGridCommonFunc} from './ReactDataGridCommonFunc';
import CustomReportView from './CustomReportView';
const selectors = Data.Selectors;
const { NumericFilter, AutoCompleteFilter, MultiSelectFilter, SingleSelectFilter } = Filters;
const applyTitleOnCol = (item) =>{ return <span title={item.name}>{item.name}</span>; }

class NavigationView extends Component {
    grid = {};
    constructor(props) {
        super(props);
        this.state = {
            columns: [],
            rows: [],
            status: false,
            defaultColDef: {},
            filters:{},
            originalData:[],
            gridId: this.props.match.params.gridid,
            gridItemId: this.props.match.params.griditemid,
            tileId: this.props.match.params.tileid,
            personId: this.props.match.params.personid,
            entity_type: '',
            sub_entity_type: 0,
            entities_list: [],
            show: '',
            entity_ids: [],
            entity_status: false,
            navigationDocsList: [],
            t: props.t,
            responseText: 'Loading....',
            responseStatus: false,
            didUpdateStatus:true,
	    notDirectView: 0,
        }
        this.handleOnClick = this.handleOnClick.bind(this);
    }

    handleOnClick(event) {
        var entity_ids = [];
        entity_ids.push(parseInt(event.target.id));
        this.getNavigationDocuments(entity_ids, this.state.entity_type, {notDirectView: 1});
    }


    displayEntitiesList() {
        var table = [];
        let entity_status = this.state.entity_status;
        let show = this.state.show;
        let entity_type = this.state.entity_type;
        let entities_list = this.state.entities_list;
        let entity_ids = this.state.entity_ids;
        let sub_entity_type = this.state.sub_entity_type;
        if (entity_status) {
            if (show) {
                if (entity_type !== parseInt(window.DOCUMENT_REPORT_ENTITY) && entity_type !== parseInt(window.WEBFORM_REPORT_ENTITY) && entity_type !== parseInt(window.CUSTOM_REPORT_TILE_TYPE) && entity_type !== parseInt(window.BLOCKBOX_REPORT_ENTITY)) {
                    entities_list.map((key) => {
                        table.push(<reactbootstrap.Button id={key.id} onClick={this.handleOnClick}>{key.name}</reactbootstrap.Button>)
                        table.push(<br></br>)
                    })
                } else {
                    table.push(this.entityTypeSwitch(entity_type, entities_list, entity_ids, sub_entity_type));
                }
            } else {
                this.getNavigationDocuments(this.state.entity_ids, this.state.entity_type, {});
            }
        }
        return table;
    }

    entityTypeSwitch(entity_type, entities_list, entity_ids, sub_entity_type) {
        switch (parseInt(entity_type)) {
            case window.DOCUMENT_REPORT_ENTITY:
                return <DocumentReportView report_ids={entity_ids} />;
                break;
		case window.WEBFORM_REPORT_ENTITY: case window.BLOCKBOX_REPORT_ENTITY:
                return <WebformReportView reportData={entities_list} report_type={sub_entity_type} />
                break;
            case window.CUSTOM_REPORT_TILE_TYPE:
                return <CustomReportView report_ids = {entities_list}/>
            default:
                break;
        }
    }



    getNavigationDocuments(entity_ids, entity_type, setObj) {
        var data = {
            entity_ids: entity_ids,
            entity_type: entity_type,
            personId: this.state.personId,
        }
        datasave.service(window.GET_NAVIGATIONDOCS, 'POST', data).then(result => {
            if (result['status'] == 200) {
                this.getAllDocsList(result['data'], data, setObj);
            } else {
                this.getAllDocsList('', data, setObj);
            }
        })
    }

    async getAllDocsList(docslist, data, setObj) {
      const { t } = this.state;
      data['grid_type'] = this.state.gridId;
      data['grid_items_id'] = this.state.gridItemId;
      data['tile_id'] = docslist;
      data['p_id'] = this.state.personId;
	    const {notDirectView} = this.state;
        if (docslist != '') {
          await datasave.service(window.TILE_DETAILS, 'POST', data).then(
            async result => {
              let translatedColumns = ReactDataGridCommonFunc.getTranslatedColumns(result.columnDefs, t);
              let columns = ReactDataGridCommonFunc.orderColumnAccordingToPriority(translatedColumns);
              columns.map(key=>{ key['headerRenderer'] = applyTitleOnCol(key); });
              let sortColdirectObj = await ReactDataGridCommonFunc.getSortColAndSortDirection(columns);
              let originalData = result.rowData;
              let rows =  Object.keys(sortColdirectObj).length > 0 ?
              await ReactDataGridCommonFunc.sortRows(result.rowData, sortColdirectObj['sortColumn'], sortColdirectObj['sortDirection'],
                originalData, columns, 0, []) : result.rowData;
              let defaultColDef = result.defaultColDef;
	      const filters = ReactDataGridCommonFunc.getFiterAccordingToType(columns);
              const filteredRows = ReactDataGridCommonFunc.getRows(rows, filters);
	      if(filteredRows.length === 1){
	      filteredRows.map(key=>{ this.redirectFunc(key['id'], key['webform'] === null ? 0 : key['webform'], parseInt(notDirectView) === 0? 1 : 0) });
	      }else{
              setObj['status'] = true;
	      setObj['columns'] = columns;
	      setObj['rows'] = rows;
	      setObj['defaultColDef'] = defaultColDef;
	      setObj['originalData'] = originalData;
	      setObj['entity_status'] = false;
	      setObj['filters'] = ReactDataGridCommonFunc.getFiterAccordingToType(columns)
              this.setState(setObj);
	      }
		    /*    this.setState({
                  status: true,
                  columns: columns,
                  rows: rows,
                  defaultColDef: defaultColDef,
                  originalData:originalData,
                  entity_status: false,
                  filters:ReactDataGridCommonFunc.getFiterAccordingToType(columns)
              })*/

          })
        } else {
		setObj['status'] = true;
		setObj['entity_status'] = false;
		this.setState(setObj);
         /*   this.setState({
                status: true,
                entity_status: false
            })*/
        }
    }

    defaultText() {
        const { t } = this.state;
        var columnDefs = this.state.columnDefs;
        var rowData = this.state.rowData;
        var status = this.state.status;
        if (rowData.length === 0 && status === true || columnDefs.length === 0 && status === true) {
            return { noRowsToShow: t('No Data To Show') };
        }

    }
    handlegoback = () => {
        let goback = window.location.search.replace('?q=', '');
        this.props.history.push(goback);
    }

    //----------------------------------------------------------------------------------
    onSelectionChanged() {
        var selectedRows = this.gridApi.getSelectedRows();
        var selectedRowsString = "";
        var selectedRowsStringWebform = 0;
        selectedRows.forEach(function (selectedRow, index) {
            if (index !== 0) {
                selectedRowsString += ", ";
            }
            selectedRowsString += selectedRow.id;
            selectedRowsStringWebform += (selectedRow.webform !== undefined) ? selectedRow.webform : 0;
        });
        if (selectedRowsStringWebform) {
            window.location = '/webformaction/' + selectedRowsString + '/1/' + window.COMING_FROM_CASE4_todos + '/0' + '/0' + '/0' + '/0' + '/0' + '/1' + '?q=' + window.location.pathname;
        }
        else {
            window.location = '/documentview/' + selectedRowsString + '?q=' + window.location.pathname;
        }
        // window.location = '/documentview/' + selectedRowsString + '?q=' + window.location.pathname;
        //document.querySelector("#selectedRows").innerHTML = selectedRowsString;
    }

    handleGoBack = () =>{
	    this.setState({status: false, entity_status: true, rows:[], columns: [], defaultColDef: {}, filters: {}, notDirectView: 0});
    }
    getDisplay() {
        var table = [];
        const { t, columns,rows,filters,originalData, status, notDirectView } = this.state;
        if (this.state.status === true) {
          const filteredRows = ReactDataGridCommonFunc.getRows(rows, filters);
          table.push(
            <div>
	      {parseInt(notDirectView) === 1 && <a href="#" onClick = {(e)=>this.handleGoBack()}>{t('go back')}</a>}
              <ReactDataGrid
                ref={(grid) => { this.grid = grid; }}
                columns={columns}
                rowGetter={i=>this.rowGetterFunc(i,filteredRows)}
                rowsCount={filteredRows.length}
                onRowClick={(rowId,row)=>this.onRowClick(rowId,row)}
                onGridSort={(sortColumn, sortDirection) =>this.setRows(
                ReactDataGridCommonFunc.sortRows(rows,sortColumn,sortDirection,originalData, columns, 0, []))}
                onAddFilter={filter => this.setFilters(filter)}
                minHeight={480}
                getValidFilterValues={columnKey => ReactDataGridCommonFunc.getValidFilterValues(rows, columnKey)}
              />
            {this.displayExportButton()}
            </div>
          )

        }
        return table;
    }

    displayExportButton(){
      const { t, status, columns, rows, defaultColDef } = this.state;
      if(status && columns.length > 0 && rows.length > 0 && Object.keys(defaultColDef).length > 0 && defaultColDef['export']){
        return (<reactbootstrap.Button  onClick={() => this.exportXLS()}>{t('Export XLS')}</reactbootstrap.Button>);
      }
    }

    exportXLS() {
        const {rows, columns, filters} = this.state;
        var data = {};
        data.columnDefs = columns;
        data.rowData = ReactDataGridCommonFunc.getRows(rows, filters);
        datasave.service('/api/generatefile', "POST", data)
            .then(response => {
                var a = document.createElement("a");
                a.setAttribute("type", "file");
                a.href = response.file;
                a.download = response.name;
                document.body.appendChild(a);
                a.click();
                a.remove();
            });
    }


    componentDidUpdate(){
      const { t, status, columns, rows, didUpdateStatus, defaultColDef } = this.state;
      if(status && didUpdateStatus && columns.length > 0 && rows.length > 0){
        if(defaultColDef['filterable'] !== undefined && defaultColDef['filterable']){
          this.grid.onToggleFilter();
          this.setState({didUpdateStatus:false});
        }

      }
    }



    setRows(rows){
      this.setState({rows:rows});
    }

    setFilters(filter){
      let data = ReactDataGridCommonFunc.handleFilterChange(filter, this.state.filters);
      this.setState({filters:data})
    }

    rowGetterFunc(i,filteredRows){
      return filteredRows[i];
    }

    redirectFunc = (id, webform, singleRedirect) =>{
	    const redirectPath = parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications';
        if (webform) {
            // window.open('/webformaction/' + id + '/1/' + window.COMING_FROM_CASE4_todos + '/0' + '/0' + '/0' + '/0' + '/0' + '/1' +'?q=' + redirectPath, '_blank');
            window.location = '/webformaction/' + id + '/1/' + window.COMING_FROM_CASE4_todos + '/0' + '/0' + '/0' + '/0' + '/0' + '/1' +'?q=' + redirectPath;
        } else {
            // window.open('/documentview/' + id + '?q=' + redirectPath, '_blank')
            window.location = '/documentview/' + id + '?q=' + redirectPath;
        }
    }

    onRowClick = (rowIdx, row) => {
      if(rowIdx !== -1 && row !== undefined){
        this.redirectFunc(row['id'], row['webform'] === null ? 0 : row['webform'], 0);
      }
    }
    sortingByName=(data1)=>{
    return  data1.sort(function(a,b){return (a.name).toLowerCase() < (b.name).toLowerCase() ? -1 : 1;});
    }
    //----------------------------------------------------------------------------------
    render() {
        // alert("navigation buttons")
        const { t, status, columns, rows } = this.state;
        if (this.state.responseStatus) {
            return (<div className='fluid pl-5'>

                <div className='container-fluid pl-4 reactDataGridClass py-4' >
                    <div className='row justify-content-center' >
                        <div className='col-md-12' >
                                <div className="navigation-view-buttons">
                                    {this.displayEntitiesList()}
                                </div>
                                <div>{status && columns.length === 0 && rows.length === 0 ? 'No data to show' : ''}</div>
                                {this.getDisplay()}
                        </div>
                    </div>
                </div>
            </div>);
        } else {
            return (
                <div>
                    <h3>{t(this.state.responseText)}</h3>
                </div>
            );
        }
    }



    componentDidMount() {
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        if (person_id == this.state.personId) {
            datasave.service(window.GET_LISTOFENTITIES + '/' + this.state.tileId + '/' + this.state.personId, 'GET', '').then(result => {
                if (result['status'] == 200) {
                    var grid_ids = [];
                        const entity_type = result.entity_type_id !== undefined ? parseInt(result.entity_type_id) : 0;
			const sub_entity_type = result.sub_entity_type !== undefined ? result.sub_entity_type : 0;
			const show = result.show !== undefined ?  parseInt(result.show) : 0 ;
			let sortedEntityList = result.entity_type_id !== undefined && parseInt(result.entity_type_id) === window.NAVIGATION_MANUAL_TYPE  ? this.sortingByName(result.entities_list) :  result.entities_list;
                    sortedEntityList.map(key => {
                        grid_ids.push(key.id !== undefined ? parseInt(key.id) : parseInt(key));
                    })
			if(show === 1 && grid_ids.length === 1 && entity_type !== parseInt(window.DOCUMENT_REPORT_ENTITY) && entity_type !== parseInt(window.CUSTOM_REPORT_TILE_TYPE) && entity_type !== parseInt(window.WEBFORM_REPORT_ENTITY) && entity_type !== parseInt(window.BLOCKBOX_REPORT_ENTITY)){
                        this.getNavigationDocuments(grid_ids, entity_type, {entity_type: entity_type, entities_list: sortedEntityList,
                        show: show, entity_ids: grid_ids, entity_status: true, responseStatus: true, sub_entity_type: sub_entity_type});                              }else{
			this.setState({
                        entity_type: entity_type,
                        entities_list: sortedEntityList,
                        show: show,
                        entity_ids: grid_ids,
                        entity_status: true,
                        responseStatus: true,
                        sub_entity_type: sub_entity_type,
                    })
	         }
                } else {
                    this.setState({
                        status: true,
                        responseStatus: true,
                    })
                }
            });
        } else {
            this.setState({
                responseText: 'Access Denied'
            })
        }
    }

}


export default translate(NavigationView);
