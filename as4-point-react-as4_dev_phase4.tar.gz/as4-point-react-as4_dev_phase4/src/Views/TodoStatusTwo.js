import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap'

import { datasave } from '../_services/db_services'
import { connect } from "react-redux";
import { translate } from '../../src/language';
import FirstCycleComponent from '../../src/_components/DocumentCycleComponent/FirstCycleComponent';
import SecondCycleComonent from '../../src/_components/DocumentCycleComponent/SecondCycleComonent';
import ThirdCycleComponent from '../../src/_components/DocumentCycleComponent/ThirdCycleComponent';
import TodosComponentTwo from '../../src/TodosComponents/TodosComponentTwo';
import WebFormBuild from '../Webforms/Views/WebformBuildAction';

class TodoStatusTwo extends Component {
    constructor(props) {
        super(props)
        this.state = {
            save: 'Save',
            credentials: this.props.credentials,
            savevalue: 'true',
            loading: false,
            error: '',
            description: '',
            status: 1,
            submitted: false,
            memo_data: [],
            doc_id: '',
            doc_status: '',
            doc_status_id: '',
            uid: '',
            documentId: this.props.match.params.id,
            documentStatus: this.props.match.params.status,
            todoId: this.props.match.params.t_id,
            logPerName: '',
            date: 0,
            t: props.t,
            file_path: '',
            webform: (this.props.match.params.webform !== undefined && parseInt(this.props.match.params.webform)) ? 1 : 0,
        }
    }

    componentDidMount() {
        var url = window.GET_INSERT_DOCUMENT_DETAILS_ONLY + '/' + this.props.match.params.id;

        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    doc_id: result.id,
                    doc_status: result.status,
                    doc_status_id: result.docstatusId,
                })
            });
        datasave.service(window.GETCOMMENTS + '/' + this.state.todoId, "GET")
            .then(result => {
                if (result['status'] === 200) {
                    if (result['data'].length > 0) {
                        result['data'].map((key) => {
                            this.setState({
                                comment: key['comment'],
                                commentedPerName: key['name'],
                                logPerName: key['Logname'],
                                date: key['date'],
                                file_path: key['file_path'],
                                status: true,
                            })
                        })



                    } else {
                    }
                } else {
                }
            });

    }
    handlegoback = () => {
        let goback = window.location.search.replace('?q=', '');
        this.props.history.push(goback);
    }
    render() {
        const { doc_id, doc_status, webform, doc_status_id, t } = this.state;
        return (
            // <div className="container py-4">
            <div className=" row mt-5 mb-5" >
                <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
                <div style={{ marginLeft: '-1.5rem' }} className='col-md-11' >
                    <div className="row justify-content-center">
                        <div className="col-md-12">
                            <div className="card">
                                <div className="todocycle-back-menu col-md-12" style={{ textAlign: 'end', alignSelf: 'flex-end', cursor: 'pointer' }} onClick={(e) => this.handlegoback()}>
                                    {t('Go back')}
                                </div>
                                {/* <div className="todocycle-back-menu col-md-12" style={{ paddingLeft: '3rem', paddingBottom: '0.5rem', paddingTop: '1rem', paddingRight: '3rem', textAlign: 'right', alignSelf: 'center', cursor: 'pointer' }} onClick={(e) => this.handlegoback()}>
                                    {t('Go back')}
                                </div> */}
                                {this.state.comment && <div style={{ paddingLeft: '3rem', paddingBottom: '0rem', paddingTop: '1rem' }}>{t('Hi')} {this.state.logPerName}, {t('the below document  was not read and understood with the following comment: ')}{this.state.comment} {t('by')} {this.state.commentedPerName} {('on')} {this.state.date}. {t('Please provide the necessary feedback below the document for this person.')}</div>

                                    // {this.state.comment && <div style={{ paddingLeft: '3rem', paddingBottom: '0rem', paddingTop: '1rem' }}>Hi {this.state.logPerName}, ‘{this.state.commentedPerName}’ has provided this feedback on your comment: {this.state.comment}.  Please read the document again. Below the document you can continue.</div>
                                }
                                {this.state.file_path && <div style={{ paddingLeft: '3rem', paddingBottom: '0rem' }}> <span>{t('Remark document link') +' : '}<a href={this.state.file_path}>{t('Link')}</a></span></div>}

                                {/* <FirstCycleComponent
                                details={this.state.doc_status}
                            /> */}
                                {webform !== 1 &&
                                <div style={{ paddingLeft: '3rem', paddingBottom: '0.5rem' }}>
                                    <SecondCycleComonent
                                        doc_id={this.state.doc_id}
                                    />
                                </div>
                                }
                                {webform === 1 &&
                                  <WebFormBuild {...this.props} todoid = {0}  simulate = {1} refid = {1} webform_id = {this.props.match.params.id} stepid = {1} view = {1} stepAction = {window.FROM_CASE1_activation_cycle} />
                                }
                                {/* <ThirdCycleComponent

                                    status={this.state.doc_status}
                                /> */}
                                <TodosComponentTwo webform= {webform} history={this.props.history} id={this.state.documentId} docStatus={this.state.documentStatus} todoId={this.state.todoId}></TodosComponentTwo>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        );
    }

    // componentDidMount() {
    //     datasave.service(window.GETCOMMENTS + '/' + this.state.todoId, "GET")
    //         .then(result => {
    //             if (result['status'] === 200) {
    //                 if (result['data'].length > 0) {
    //                     result['data'].map((key) => {
    //                         this.setState({
    //                             comment: key['comment'],
    //                             commentedPerName: key['name'],
    //                             logPerName: key['Logname'],
    //                             date: key['date'],
    //                             status: true,
    //                         })
    //                     })



    //                 } else {
    //                 }
    //             } else {
    //             }
    //         });
    // }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(TodoStatusTwo));
