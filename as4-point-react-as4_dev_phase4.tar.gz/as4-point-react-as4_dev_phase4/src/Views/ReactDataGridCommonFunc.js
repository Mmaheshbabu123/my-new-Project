
import { Editors, Data, Filters,Toolbar } from "react-data-grid-addons-default-filters";
const { NumericFilter, AutoCompleteFilter, MultiSelectFilter, SingleSelectFilter } = Filters;
const selectors = Data.Selectors;
const sortColDirection = {'asc' : 'ASC', 'desc' : 'DESC'};
export const ReactDataGridCommonFunc = {
  orderColumnAccordingToPriority,
  sortRows,
  handleFilterChange,
  getFiterAccordingToType,
  getValidFilterValues,
  getRows,
  getSortColAndSortDirection,
  getTranslatedColumns
}


function getRows(rows, filters) {
    let filtersKeyArr = Object.keys(filters);
    if(filtersKeyArr.length > 0 && rows.length > 0){
      return rows.filter(singleRowData=>{
        let resArr = filtersKeyArr.map(key=>{
            if(singleRowData[key] !== undefined){
              return fiterConstAccordingToTokenId(singleRowData[key], filters[key]['filterTerm'], filters[key]['column']['token_id']);
            }else{
              return 0;
            }
        });
        return resArr.indexOf(0) === -1;
      })
    }
    rows = selectors.getRows({ rows, filters });

    return rows;
  }


function fiterConstAccordingToTokenId(dataValue, filterValue , tokenId){
  let filterValArr  = [];
  switch(tokenId){
    case window.DOCUMENT_NAME_TOKEN_ID : case window.FOLDER_NAME_TOKEN_ID :
    case window.FOLDER_CODE_TOKEN_ID : case window.DOCUMENT_CODE :
    case window.DOCUMENT_VERSION_TOKEN_ID : case window.SPACE_NAME_TOKEN_ID :
    case window.LAYOUT_NAME_TOKEN_ID : case window.STANDARD_NAME_TOKEN_ID :
    case window.TAG_NAME_TOKEN_ID : case window.NOTIFICATION_RECEIVED_ON_TOKEN_ID :
    case window.REVISION_REVIEW_DATE_TOKEN_ID : case window.REASON_OF_CHANGE_TOKEN_ID :
    case window.PREVIOUS_VERSION_TOKEN_ID : case window.DOCUMENT_STATUS_TOKEN_ID :
    case window.JOBS_NAME_TOKEN_ID : case window.JOBS_ABBREVIATINO_TOKEN_ID :
    case window.DEPARTMENTS_NAME_TOKEN_ID : case window.DEPARTMENTS_ABBREVIATION_TOKEN_ID :
    case window.PERSONS_NAME_TOKEN_ID : case window.EXTERNALLINKS_CODE_TOKEN_ID :
    case window.EXTERNALLINKS_NAME_TOKEN_ID : case window.EXTERNALLINKS_DESC_TOKEN_ID :
    case window.DEFINITIONS_NAME_TOKEN_ID : case window.DEFENITIONS_DESC_TOKEN_ID :
    case window.STANDARDS_DESC_TOKEN_ID : case window.EVENT_USER_TOKEN_ID :
    case window.DOCUMENT_TYPE_TOKEN_ID : case window.OPERATIONS_NOTIFY_TOKEN_ID :
    case window.DATE_OF_NOTIFY_TOKEN_ID : case window.READ_UNREAD_NOTIFY_TOKEN_ID :
    case window.PERSONS_EMAIL_TOKEN_ID : case window.TODO_PERSON_TOKEN_ID :
    case window.PERSONS_UID_TOKEN_ID : case window.VERIFIED_BY_TOKEN_ID :
    case window.AUTHORISED_BY_TOKEN_ID : case window.VERIFICATION_DATE_TOKEN_ID :
    case window.AUTHORISED_DATE_TOKEN_ID : case window.ACTIVATION_DATE_TOKEN_ID :
    case window.REVISED_BY_TOKEN_ID : case window.DOCUMENT_OWNER_PERSON_TOKEN_ID :
    case window.DOCUMENT_OWNER_JOB_TOKEN_ID : case window.MANUAL_NAME_TOKEN_ID :
    case window.MANUAL_CODE_TOKEN_ID : case window.DUE_DATE_TOKEN_ID :
    case window.DOCUMENT_OWNER1_TOKEN_ID : case window.DOCUMENT_OWNER2_TOKEN_ID :
    case window.DOCUMENT_OWNER3_TOKEN_ID : case window.STARTED_BY_TOKEN_ID :
    case window.CURRENT_STEP_TOKEN_ID : case window.START_DATE_TOKEN_ID :
    case window.FORM_NO_TOKEN_ID : case window.LATEST_ACTION_TOKEN_ID :
    case window.DOCUMENT_REVISION_DATE_TOKEN_ID: case window.RELEASE_PERSON_TOKEN_ID:
    case window.BLOCKED_BY_TOKEN_ID: case window.BLOCKED_AT_TOKEN_ID: case window.ORIGIN_TOKEN_ID:
    case window.KPI_NAME_TOKEN_ID: case window.KPI_TARGET_VALUE_TOKEN_ID: case window.KPI_START_DATE_TOKEN_ID:
    case window.KPI_END_DATE_TOKEN_ID: case window.KPI_MIN_VALUE_TOKEN_ID:case window.KPI_MAX_VALUE_TOKEN_ID:
    case window.KPI_FREQ_DATE_TOKEN_ID: case window.KPI_ACTUAL_VALUE_TOKEN_ID: case window.KPI_MIN_VALUE_PER_TOKEN_ID:
    case window.KPI_MAX_VALUE_PER_TOKEN_ID:
    filterValArr = filterValue.split(",");
    dataValue = dataValue !== null && dataValue.length > 0 ? dataValue.trim().toLowerCase() : '';
    return commonValueMatchingFunc(dataValue, filterValArr, 1, 1);
    break;
	  case window.SPACE_NAME_TOKEN_ID : case window.IDENTIFICATION_FIELDS_TOKEN_ID: case window.IDENTIFICATION_FIELDS_TOKEN_ID2: case window.IDENTIFICATION_FIELDS_TOKEN_ID3: case window.IDENTIFICATION_FIELDS_TOKEN_ID4: case window.IDENTIFICATION_FIELDS_TOKEN_ID5: case window.IDENTIFICATION_FIELDS_TOKEN_ID6: case window.IDENTIFICATION_FIELDS_TOKEN_ID7: case window.IDENTIFICATION_FIELDS_TOKEN_ID8:
    filterValArr = filterValue.split(",");
    return commonValueMatchingFunc(dataValue.trim().toLowerCase(), filterValArr, 0, 1);
    break;
    case window.TODO_OPERATIONS_TOKEN_ID : case window.DOCUMENT_FUNDAMENTAL_TOKEN_ID : case window.ISDONE_TOKEN_ID:
    return Object.keys(filterValue).length > 0 && filterValue['value'] !== undefined ? commonValueMatchingFunc(dataValue.trim().toLowerCase(), [filterValue['value']], 0, 1) : 1;
    break;
    default:
    return 1;
    break;
  }
}

function commonValueMatchingFunc(dataValue, filterValArr, orOrAnd, trimAndLowerOrNot){
  if(filterValArr.length > 0 || (filterValArr.length === 0 && dataValue.length === 0)){
    let resArr = filterValArr.map(value=>{
       value = parseInt(trimAndLowerOrNot) === 1 ? value.trim().toLowerCase() : value;
      if(dataValue.indexOf(value) !== -1){
        return 1;
      }else{
        return 0;
      }
    })
    return parseInt(orOrAnd) === 1 ? (resArr.indexOf(1) !== -1 ? 1 : 0) : (resArr.indexOf(0) === -1 ? 1 : 0);
  }else{
    return 1;
  }
}

function getSortColAndSortDirection(columns){
  let count = 0;
  let sortColumn = '';
  let sortDirection = '';
  columns.map(key=>{
    if(key['sortorder'] !== 'null' && count === 0){
      sortColumn = key['key']
      sortDirection = sortColDirection[key['sortorder']]
      count++;
    }
  })
  return count !== 0 ? {'sortColumn' : sortColumn , 'sortDirection' : sortDirection} : {};
}


function orderColumnAccordingToPriority(column){
  if(column.length > 0){
     return column.sort(function(a , b) {
      return a['priority'] - b['priority'];
    });
  } else{
    return [];
  }
}

 function  sortRows(rows, sortColumn, sortDirection,originalData, columns, reverseDate, onlyDateIdentification) {
   let typeArr = columns.map(key=>{ return  key['key'] === sortColumn ? key['token_id'] : 0});
   let comparer;
   if(typeArr.indexOf(window.START_DATE_TOKEN_ID) !== -1
      || typeArr.indexOf(window.DOCUMENT_REVISION_DATE_TOKEN_ID) !== -1
      || typeArr.indexOf(window.REVISION_REVIEW_DATE_TOKEN_ID) !== -1
      || typeArr.indexOf(window.DATE_OF_NOTIFY_TOKEN_ID) !== -1
      || typeArr.indexOf(window.ACTIVATION_DATE_TOKEN_ID) !== -1
      || typeArr.indexOf(window.DUE_DATE_TOKEN_ID) !== -1
      || typeArr.indexOf(window.AUTHORISED_DATE_TOKEN_ID) !== -1
      || typeArr.indexOf(window.VERIFICATION_DATE_TOKEN_ID) !== -1
      || typeArr.indexOf(window.NOTIFICATION_RECEIVED_ON_TOKEN_ID) !== -1
      || typeArr.indexOf(window.LATEST_ACTION_TOKEN_ID) !== -1
      || typeArr.indexOf(window.BLOCKED_AT_TOKEN_ID) !== -1
      || (typeArr.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID) !== -1 &&
	      onlyDateIdentification.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID) !== -1)
      || (typeArr.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID2) !== -1 &&
	      onlyDateIdentification.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID2) !== -1)
      || (typeArr.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID3) !== -1 &&
	      onlyDateIdentification.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID3) !== -1)
      || (typeArr.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID4) !== -1 &&
	      onlyDateIdentification.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID4) !== -1)
      || (typeArr.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID5) !== -1 &&
	      onlyDateIdentification.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID5) !== -1)
      || (typeArr.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID6) !== -1 &&
	      onlyDateIdentification.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID6) !== -1)
      || (typeArr.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID7) !== -1 &&
	      onlyDateIdentification.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID7) !== -1)
      || (typeArr.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID8) !== -1 &&
	      onlyDateIdentification.indexOf(window.IDENTIFICATION_FIELDS_TOKEN_ID8) !== -1)
   ){
      comparer = (a, b) => {
        let aDateTime = a[sortColumn].split(' ');
        let bDateTime = b[sortColumn].split(' ');
        let aDateObj,bDateObj;
        let alength = aDateTime.length;
        let blength = bDateTime.length;

        if(alength > 0 && aDateTime[0] !== "" && blength > 0 && bDateTime[0] !== ""){
          let aDateOnly = parseInt(reverseDate) === 1 ? aDateTime[0].split("-").reverse().join("-") : aDateTime[0];
          let bDateOnly = parseInt(reverseDate) === 1 ? bDateTime[0].split("-").reverse().join("-") : bDateTime[0];
          aDateObj = alength > 1 ? new Date(aDateOnly + " " + (aDateTime[1])) : new Date(aDateOnly);
          bDateObj = blength > 1 ? new Date(bDateOnly + " " + (bDateTime[1])) : new Date(bDateOnly);
          if (sortDirection === "ASC") {
            return  aDateObj.getTime() > bDateObj.getTime()  ? 1 : -1;
          } else if (sortDirection === "DESC") {
            return  aDateObj.getTime() < bDateObj.getTime()  ? 1 : -1;
          }
        }else{
          return alength === 0 || aDateTime[0] === "" ? 1 : -1 ;
        }
     };
   }else{
     comparer = (a, b) => {
        if (sortDirection === "ASC") {
          return  a[sortColumn] === undefined || a[sortColumn] === '' || (b[sortColumn] !== undefined && b[sortColumn] !== '' && a[sortColumn] > b[sortColumn]) ? 1 : -1;
        } else if (sortDirection === "DESC") {
          return  a[sortColumn] === undefined || a[sortColumn] === '' || a[sortColumn] < b[sortColumn] ? 1 : -1;
        }
      };
   }
   return sortDirection === "NONE" ? originalData : [...rows].sort(comparer);
  };

  function handleFilterChange(filter,filters){
    const newFilters = { ...filters };
        if (filter.filterTerm) {
          newFilters[filter.column.key] = filter;
        } else {
          delete newFilters[filter.column.key];
        }
        return newFilters;
  };

  function getFiterAccordingToType(columns, EditConst){
    let filters = {};
    columns.map((key,index)=>{
       switchCaseForTypeFilter(key['token_id'], key, index, filters, EditConst);
    });
    return filters;
  }


  function switchCaseForTypeFilter(type, key, index, filters, EditConst){
    let temp = { ...key };
    temp['rowType'] = 'filter';
    temp['idx'] = index;
    switch (type) {
      case window.TODO_OPERATIONS_TOKEN_ID : case window.DOCUMENT_FUNDAMENTAL_TOKEN_ID : case window.ISDONE_TOKEN_ID:
        key['filterRenderer'] = SingleSelectFilter;
        if(temp['initial_filter'] !== null && temp['initial_filter'] !== ''){
          filters[temp['key']] = {'column':temp ,
          'filterTerm': {'value':temp['initial_filter'],'label': temp['initial_filter']},
          'filterValues':filterValues,
          'rawValue': {'value':temp['initial_filter'],'label': temp['initial_filter']}
          };
          key['initial_filter'] = {'value' : key['initial_filter'],'label' : key['initial_filter']};
        }
      break;
      default :
      if(temp['initial_filter'] !== undefined && temp['initial_filter'] !== null && temp['initial_filter'] !== ''){
        filters[temp['key']] = {'column':temp ,'filterTerm': temp['initial_filter']};
      }
      break;
    }
  }

  function filterValues(singleRowData, filter, column){
    return singleRowData[column] === filter['filterTerm']['value'] ? 1 : 0;
  }

  function getValidFilterValues(rows, columnId) {
      return rows
        .map(r => r[columnId])
        .filter((item, i, a) => {
          return i === a.indexOf(item);
        });
    }

  function getTranslatedColumns(columns, t){
    let translatedColumns = [];
  if(columns.length > 0){
    translatedColumns = columns.map(column => {
      let row = {...column, name : t(column.name)}
      return row;
    })
  }
    return translatedColumns;
  }
