import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap'

import { datasave } from '../_services/db_services'
import { connect } from "react-redux";
import { translate } from '../../src/language';
import FirstCycleComponent from '../../src/_components/DocumentCycleComponent/FirstCycleComponent';
import SecondCycleComonent from '../../src/_components/DocumentCycleComponent/SecondCycleComonent';
import ThirdCycleComponent from '../../src/_components/DocumentCycleComponent/ThirdCycleComponent';
import TodosComponentOne from '../../src/TodosComponents/TodosComponentOne';
import WebFormBuild from '../Webforms/Views/WebformBuildAction';

class TodoStatusOne extends Component {
    constructor(props) {
        super(props)
        this.state = {
            save: 'Save',
            credentials: this.props.credentials,
            savevalue: 'true',
            loading: false,
            error: '',
            description: '',
            status: 1,
            submitted: false,
            memo_data: [],
            doc_id: '',
            doc_status: '',
            doc_status_id: '',
            uid: '',
            documentId: this.props.match.params.id,
            documentStatus: this.props.match.params.status,
            todoId: this.props.match.params.t_id,
            commentedPerName: '',
            comment: '',
            logPerName: '',
            date: 0,
            t: props.t,
            file_path: '',
            webform: (this.props.match.params.webform !== undefined && parseInt(this.props.match.params.webform)) ? 1 : 0,
        }
    }

    componentDidMount() {
        var url = window.GET_INSERT_DOCUMENT_DETAILS_ONLY + '/' + this.props.match.params.id;

        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    doc_id: result.id,
                    doc_status: result.status,
                    doc_status_id: result.docstatusId,
                })
            });
        datasave.service(window.GETCOMMENTS + '/' + this.state.todoId, "GET")
            .then(result => {
                if (result['status'] === 200) {
                    if (result['data'].length > 0) {
                        result['data'].map((key) => {
                            this.setState({
                                comment: key['comment'],
                                commentedPerName: key['name'],
                                logPerName: key['Logname'],
                                date: key['date'],
                                file_path: key['file_path'],
                                status: true,
                            })
                        })



                    } else {
                    }
                } else {
                }
            });
    }
    handlegoback = () => {
        let goback = window.location.search.replace('?q=', '');
        this.props.history.push(goback);
    }
    commentView() {
        const { t } = this.state;
        var table = [];

        if (this.state.comment != '') {
            table.push(
                <div>{t('Hi')}&nbsp;{this.state.logPerName},&nbsp;{t('the below document is having the following feedback:')}&nbsp;
                    {this.state.comment}&nbsp;{t('by')}&nbsp;{this.state.commentedPerName}&nbsp;{t("on")}&nbsp;{this.state.date}.</div>

            );
            if (this.state.file_path != '') {
                table.push(
                    <div> <span>{t('The user also attached a document with remarks; you can find this by clicking on the following link:')} <a href={this.state.file_path}>{t('Link')}</a></span></div>

                )
            }
        } else {
            table.push(< div >{t('Hi')}&nbsp;{this.state.logPerName},&nbsp;{t('you are about to read and understand this document. Please read the below document and continue.')}</div>);
        }
        return table;
    }
    render() {
        const { doc_id, doc_status, doc_status_id, t, webform } = this.state;
        return (
            // <div className="container py-4">
            <div className=" row mt-5 mb-5" >
                <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
                <div style={{ marginLeft: '-1.5rem' }} className='col-md-11' >
                    <div className="row justify-content-center">
                        <div className="col-md-12">
                            <div className="card">
                                {/* <div className="todocycle-back-menu col-md-12" style={{ paddingLeft: '3rem', paddingBottom: '0.5rem', paddingTop: '1rem', paddingRight: '3rem', textAlign: 'right', alignSelf: 'center', cursor: 'pointer' }} onClick={(e) => this.handlegoback()}>
                                    {t('Go back')}
                                </div> */}
                                <div className="todocycle-back-menu col-md-12" style={{ textAlign: 'end', alignSelf: 'flex-end', cursor: 'pointer' }} onClick={(e) => this.handlegoback()}>
                                    {t('Go back')}
                                </div>
                                <div style={{ paddingLeft: '1.5rem', paddingBottom: '2rem', paddingTop: '0rem' }} className="">
                                    {this.commentView()}
                                </div>
                                {webform !== 1 &&
                                <div style={{ padding: '0rem', paddingBottom: '0rem', paddingTop: '0rem' }}>
                                    <SecondCycleComonent
                                        doc_id={this.state.doc_id}
                                    />
                                </div>
                                }
                                {webform === 1 &&
                                  <WebFormBuild {...this.props} todoid = {0}  simulate = {1} refid = {1} webform_id = {this.props.match.params.id} stepid = {1} view = {1} stepAction = {window.FROM_CASE1_activation_cycle} />
                                }
                                {/* <div style={{ padding: "0% 0% 10% 4%" }}> */}


                                {/* <div style={{}}>
                                    <ThirdCycleComponent

                                        status={this.state.doc_status_id}
                                        doc_id={this.state.doc_id}
                                    />
                                </div> */}
                                {/* <div style={{ padding: "0% 0% 10% 4%" }}> */}
                                <div className="p-4" style={{}}>
                                    <TodosComponentOne webform= {webform} history={this.props.history} id={this.state.documentId} docStatus={this.state.documentStatus} todoId={this.state.todoId}></TodosComponentOne>
                                </div>



                            </div>
                        </div>
                    </div>
                </div>
            </div >
        );
    }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(TodoStatusOne));
