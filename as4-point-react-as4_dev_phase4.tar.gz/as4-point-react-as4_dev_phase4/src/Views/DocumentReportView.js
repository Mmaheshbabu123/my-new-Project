import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { throwStatement } from '@babel/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { translate } from '../language';
import { persistor, store } from '../store';
import DisplayReportComponent from '../DisplayReportComponent';
class DocumentReportView extends Component {
    constructor(props) {
        super(props)
        this.state = {
            t: props.t,
            report_tab_data: [],
            active_tab: 0,
            responseText: '....loading',
            status: false
        }
    }

    render() {
        const { t } = this.state;
        console.log(this.state);
        return (
            <div className='container py-5'>
                {this.state.status === true ? this.displayReport() : t(this.state.responseText)}
            </div>
        );
    }
    handleTab(k) {
        this.setState({ active_tab: parseInt(k) })
    }

    displayReport() {
        return <div>
            <reactbootstrap.Tabs defaultActiveKey="profile" activeKey={this.state.active_tab} onSelect={(k) => { this.handleTab(k) }}>
                {this.state.report_tab_data}
            </reactbootstrap.Tabs>
            <DisplayReportComponent rkey={this.state.active_tab} />
        </div>
    }


    async getTabData(selectedReportIds) {
        let tabData = [];
        let allReportName = window.SHOW_DOC_REPORTS;
        // let selectedReportIds = this.state.report_ids;
        let firstCount = 0;
        let activeTab = 0;
        if (selectedReportIds.length > 0) {
            await allReportName.map(key => {
                let value = parseInt(key['value']);
                let label = key['label'];
                if (selectedReportIds.indexOf(value) !== -1) {
                    activeTab = firstCount === 0 ? value : activeTab;
                    firstCount++;
                    tabData.push(<reactbootstrap.Tab eventKey={value} title={label}>
                    </reactbootstrap.Tab>);
                }
            })
            return { activeTab: activeTab, tabData: tabData };
        }
    }

    async componentDidMount() {
        let report_ids = this.props.report_ids;
        if (report_ids !== '' && report_ids.length > 0) {
            let data = await this.getTabData(report_ids);
            this.setState({ active_tab: parseInt(data['activeTab']), report_tab_data: data['tabData'], status: true })
        } else {
            this.setState({ responseText: 'No reports to show' })
        }
    }
}
export default translate(DocumentReportView);
