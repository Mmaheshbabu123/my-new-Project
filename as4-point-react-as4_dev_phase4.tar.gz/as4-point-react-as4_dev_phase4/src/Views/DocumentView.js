import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap'
import { datasave } from '../_services/db_services'
import { connect } from "react-redux";
import { translate } from '../../src/language';
import SecondCycleComonent from '../../src/_components/DocumentCycleComponent/SecondCycleComonent';
import RevisionMenu from '../_components/RevisionMenu';
import { persistor, store } from '../store';

class DocumentView extends Component {
    constructor(props) {
        super(props)
        console.log(this.props)
        this.state = {
            save: 'Save',
            credentials: this.props.credentials,
            savevalue: 'true',
            loading: false,
            error: '',
            description: '',
            status: 1,
            submitted: false,
            memo_data: [],
            doc_id: '',
            doc_status: '',
            doc_status_id: '',
            uid: '',
            t: props.t,
            lang:'Dutch',
            access: -1,
            tile_id:(this.props.match.params.tile_id !== undefined)?this.props.match.params.tile_id:0,
        }
    }
    handlegoback = () => {
        let goback = window.location.search.replace('?q=', '');
        this.props.history.push(goback);
    }
    async componentDidMount() {
        let Userdata = store.getState();
        let personid = Userdata.UserData.user_details.person_id;
        let docid = this.props.match.params.id;
        let access = 0;
        let latestdocid;
        let corporateObj = await this.checkCorporateDocOrNot(docid);
        let accessUrl = window.GET_ACCESS_CHECK + '/' + docid + '/' + personid;

        await datasave.service(accessUrl, "GET")
            .then(result => {
                access = result.access;
                latestdocid = result.latestdocid;
            });
        var url = window.GET_INSERT_DOCUMENT_DETAILS_ONLY + '/' + latestdocid;
        if (access)
        {
          await datasave.service(url, "GET")
              .then(result => {
                  this.setState({
                      doc_id        : corporateObj.doc_id ? corporateObj.doc_id : latestdocid,
                      envurl        : corporateObj.envurl ? corporateObj.envurl : '',
                      doc_status    : result.status,
                      doc_status_id : result.docstatusId,
                      access: access,
                  })
              });
        }
        else
        {
           this.setState({
              access: access
           });
        }
    }

    async checkCorporateDocOrNot(docId){
      let returnObj = {};
      await datasave.service(window.GET_META_DATA + '/' + docId, "GET")
          .then(result => {
              if (result.docpath[0].corporate == 1) {
                  var url = result.docpath[0].envfilename!=null ? result.docpath[0].envfilename : window.backendURL + '/';
                  if (result.docpath[0].doc_type_id <= 3) {
                    returnObj = {
                        doc_id: result.docpath[0].corporate_id,
                        envurl: url,
                    }
                  }
              }
          });
        return returnObj;
    }

    render() {
        const { doc_id, doc_status, doc_status_id, t, access } = this.state;

        if (access)
        {
        return (
            // <div className="container one">
            <div className=" row mt-5 mb-5" >
                <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
                <div style={{ marginLeft: '-1.5rem' }} className='col-md-11' >
                    <div className="row justify-content-center">
                        <div className="col-md-12">
                            <div className="card">
                            {/* <div className="todocycle-back-menu col-md-12" style={{paddingLeft: '3rem', paddingBottom: '0.5rem', paddingTop: '1rem',paddingRight: '3rem', textAlign: 'right',alignSelf: 'center',cursor: 'pointer'}} onClick={(e) => this.handlegoback()}>
                                {t('Go back')}
                            </div> */}
                            <div className="todocycle-back-menu col-md-12" style={{ textAlign: 'end',alignSelf: 'flex-end',cursor: 'pointer'}} onClick={(e) => this.handlegoback()}>
                                {t('Go back')}
                            </div>
                            <div className="pl-0 pr-5 pt-2">
                                <RevisionMenu
                                    doc_id={this.state.doc_id}
                                />
                                </div>

                                <div className="pt-2">
                                <SecondCycleComonent
                                    doc_id={this.state.doc_id}
                                    tile_id ={this.state.tile_id}
                                    url = {this.state.envurl}
                                />
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
        }
        else {
          return (
            // <div className="container one">
            <div className=" row mt-5 mb-5" >
                <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
                <div style={{ marginLeft: '-1.5rem' }} className='col-md-11' >
                    <div className="row justify-content-center">
                        <div className="col-md-12">
                            <div className="card mt-5 py-5" style = {{ alignContent: 'flexStart', display: 'flex', alignItems: 'center' }}>
                               {t('Access denied')}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          );
       }
    }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(DocumentView));
