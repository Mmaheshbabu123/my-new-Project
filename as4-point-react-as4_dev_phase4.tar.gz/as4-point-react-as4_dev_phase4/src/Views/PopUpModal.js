import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { throwStatement, existsTypeAnnotation } from '@babel/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import './todo.css';
import './todos.css';
import { persistor, store } from '../store';
import { translate } from '../language';



import Loading from '../Loading';

class todos extends Component {
    constructor(props) {
        super(props);

        this.state = {
            t: props.t,
        }
    }


    render() {
        const { t } = this.state;

            return (
              <reactbootstrap.Modal show={this.props.show} onHide={this.props.handleClose}>
        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title>{this.props.title}</reactbootstrap.Modal.Title>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Body>
        <label>{this.props.firstDropDownName}</label>
        <reactbootstrap.Form.Control as={'select'} disabled = {this.props.firstDropDownDisable} name={this.props.firstDropDownName} value={this.props.firstDropDownSelectvalue} onChange={(e)=>this.handleDropDown(this.props.firstDropDownSelectName,e.target.value)} >
            <option value={0}>{'-------- Select -------'}</option>
            {this.getOptions(this.props.firstDropDownOptionData,this.props.firstDropDownOptionlabName,this.props.firstDropDownOptionValName)}
        </reactbootstrap.Form.Control>
        <label>{this.props.secondDropDownName}</label>
        <reactbootstrap.Form.Control as={'select'} disabled = {this.props.secondDropDownDisable} name={this.props.secondDropDownName} value={this.props.secondDropDownSelectvalue} onChange={(e)=>this.handleDropDown(this.props.secondDropDownSelectName,e.target.value)} >
            <option value={0}>{'-------- Select -------'}</option>
            {this.getOptions(this.props.secondDropDownOptionData,this.props.secondDropDownOptionlabName,this.props.secondDropDownOptionValName)}
        </reactbootstrap.Form.Control>
        </reactbootstrap.Modal.Body>
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button variant="secondary" onClick={this.props.handleClose}>
            {this.props.closeButtonName}
          </reactbootstrap.Button>
          <reactbootstrap.Button variant="primary" onClick={this.props.handleConfirm}>
            {this.props.saveButtonName}
          </reactbootstrap.Button>
        </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
      );

    }

    getOptions(data,labelName,valueName){
      let options = [];
      if(data.length > 0){
        data.map(key=>{
          options.push(<option value={key[valueName]}>{key[labelName]}</option>)
        })
      }
      return options;
    }
    handleDropDown(name,value){
      this.props.handleSelect(name,value)
    }


}

export default translate(todos);
