import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { throwStatement } from '@babel/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { translate } from '../language';
import { persistor, store } from '../store';
import ReactDataGrid from "react-data-grid-defaultvalue";
import PopUpModal from './PopUpModal';
import { Editors, Data, Filters,Toolbar } from "react-data-grid-addons-default-filters";
import { OCAlert } from '@opuscapita/react-alerts';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css';
import {ReactDataGridCommonFunc} from './ReactDataGridCommonFunc';
const selectors = Data.Selectors;
const { NumericFilter, AutoCompleteFilter, MultiSelectFilter, SingleSelectFilter } = Filters;
const applyTitleOnCol = (item) =>{ return <span title={item.name}>{item.name}</span>; }

class notifications extends Component {
    grids = {};
    constructor(props) {
        super(props);
        this.state = {
          columns: [],
          rows: [],
          status: true,
          defaultColDef: {},
          filters:{},
          originalData:[],
          selectedRow:{},
          selectedIndexes : [],
          t: props.t,
          gridId: this.props.match.params.gridid,
          gridItemId: this.props.match.params.griditemid,
          tileId: this.props.match.params.tileid,
          personId: this.props.match.params.personid,
          selectIds: [],
          activeTabs: props.t('Unread'),
          responseText: 'Loading....',
          didUpdateStatus:false,
        }
        this.exportXLS = this.exportXLS.bind(this);
    }

    componentDidUpdate(){
      const {didUpdateStatus, status, defaultColDef}  = this.state;
      console.log('did update');
      console.log(didUpdateStatus);
      console.log(status);
      if(didUpdateStatus && status){
        if(defaultColDef['filterable'] !== undefined && defaultColDef['filterable']){
           this.grid.onToggleFilter();
        }
         this.setState({didUpdateStatus:false});
      }
    }

    exportXLS() {
        const {rows, columns, filters} = this.state;
        var data = {};
        data.columnDefs = columns;
        data.rowData = ReactDataGridCommonFunc.getRows(rows, filters);
        datasave.service('/api/generatefile', "POST", data)
            .then(response => {
                var a = document.createElement("a");
                a.setAttribute("type", "file");
                a.href = response.file;
                a.download = response.name;
                document.body.appendChild(a);
                a.click();
                a.remove();
            });
    }


    handleRead() {
        const { t, selectIds } = this.state;
        if (selectIds.length > 0) {
            var data = { id: selectIds };
            datasave.service(window.UPDATE_NOTIFY_RID, 'POST', data).then(result => {
                if (result['status'] == 200) {
                    OCAlert.alertSuccess(t(result['AlertMsg']), { timeOut: window.TIMEOUTNOTIFICATION });
                    this.handleTabs(0);
                } else {
                    alert(result['AlertMsg']);
                }
            });
        } else {
            alert(t('None are selected'));
        }
    }

    handleDelete() {
      const { t, selectIds } = this.state;
      if(selectIds.length > 0){
        let data = { id : selectIds };
          datasave.service(window.DELETE_NOTIFY_ID, 'POST',data).then(result => {
              if (result['status'] == 200) {
                OCAlert.alertSuccess(t(result['AlertMsg']), { timeOut: window.TIMEOUTNOTIFICATION });
                this.handleTabs(1);
              } else {
                  alert(result['AlertMsg']);
              }
          });
      } else{
        alert(t('None are selected'));
      }
    }

    handleTabs(key) {
        let data = {
          grid_type : this.state.gridId,
          grid_items_id : this.state.gridItemId,
          tile_id : this.state.tileId,
          p_id : this.state.personId
        }
        if (parseInt(key) === 0) {
                this.handleService(window.TILE_DETAILS, key, {},'POST', data);
        } else {
          let  url = window.READ_NOTIFICATION + '/' +
                this.state.gridItemId + '/' + this.state.tileId +
                '/' + this.state.personId;
            this.handleService(url, key, {},'GET', '');
        }
    }

    async handleService(url, key, setObj, requestType, data) {
      const {t} =this.state;
      await datasave.service(url, requestType, data).then(
        async result => {
          let translatedColumns = ReactDataGridCommonFunc.getTranslatedColumns(result.columnDefs, t);
          let columns = ReactDataGridCommonFunc.orderColumnAccordingToPriority(translatedColumns);
          columns.map(key=>{ key['headerRenderer'] = applyTitleOnCol(key); });
          let sortColdirectObj = await ReactDataGridCommonFunc.getSortColAndSortDirection(columns);
          let originalData = result.rowData;
          let rows =  Object.keys(sortColdirectObj).length > 0 ?
           await ReactDataGridCommonFunc.sortRows(result.rowData, sortColdirectObj['sortColumn'], sortColdirectObj['sortDirection'], originalData, columns, 0, []) :
           result.rowData;
          let defaultColDef = result.defaultColDef;
          let filters = ReactDataGridCommonFunc.getFiterAccordingToType(columns);
          let filteredRows = ReactDataGridCommonFunc.getRows(rows, filters);
          // if(defaultColDef['filterable'] !== undefined && defaultColDef['filterable']){
          //   await this.grid.onToggleFilter();
          // }
          if(filteredRows.length === 1){
	  filteredRows.map(singleRowObj=>{ this.onRowClick(0, singleRowObj, 1) });
	  }else{
	  setObj['status'] = true;
          setObj['columns'] = columns;
          setObj['rows'] = rows;
          setObj['defaultColDef'] = defaultColDef;
          setObj['originalData'] = originalData;
          setObj['activeTabs'] = parseInt(key);
          setObj['selectedIndexes'] = [];
          setObj['selectIds'] = [];
          setObj['filters'] = filters;
          setObj['responseText'] = rows.length === 0 ? t('There are no notifications for you.') : '';
          this.setState(setObj);
	  }
      })
    }

    render() {
      const { t, columns,rows,filters,originalData, status, activeTabs, responseText} = this.state;
      const filteredRows = ReactDataGridCommonFunc.getRows(rows, filters);
        if (this.state.status) {
            return (
                <div className="fluid pl-5">
                    <div className="container-fluid pl-4 reactDataGridClass py-4" >
                        <div className='row justify-content-center' >
                            <div className='col-md-12' >
                              <div>{t(responseText)}</div>
                                <div>
                                    <reactbootstrap.Tabs id='controlled-tab-example' activeKey={this.state.activeTab} onSelect={k => this.handleTabs(k)}>
                                        <reactbootstrap.Tab eventKey={0} title={t("Unseen")}>
                                        </reactbootstrap.Tab>
                                        <reactbootstrap.Tab eventKey={1} title={t("Seen")}>
                                        </reactbootstrap.Tab>
                                    </reactbootstrap.Tabs>
                                </div>
                                <ReactDataGrid
                                ref={(grid) => { this.grid = grid; }}
                                columns={columns}
                                rowGetter={i=>this.rowGetterFunc(i,filteredRows)}
                                rowsCount={filteredRows.length}
                                onRowClick={(rowId,row)=>this.onRowClick(rowId, row, 0)}
                                onGridSort={(sortColumn, sortDirection) =>this.setRows(
                                ReactDataGridCommonFunc.sortRows(rows,sortColumn,sortDirection,originalData, columns, 0, []))}
                                onAddFilter={filter => this.setFilters(filter)}
                                minHeight={480}
                                getValidFilterValues={columnKey => ReactDataGridCommonFunc.getValidFilterValues(rows, columnKey)}
                                rowSelection={{
                                    showCheckbox:  true,
                                    enableShiftSelect: true,
                                    onRowsSelected: this.onRowsSelected,
                                    onRowsDeselected: this.onRowsDeselected,
                                    selectBy: {
                                      indexes: this.state.selectedIndexes
                                    }
                                  }}
                                />
                                {this.displayExportButton()}
                                {parseInt(activeTabs) === 0 ? <reactbootstrap.Button className="mt-2 mb-5" style={{ marginRight: '1rem' }} onClick={() => this.handleRead()}>{t('Read')}</reactbootstrap.Button> :
                                 <reactbootstrap.Button className="mt-2 mb-5" style={{ marginRight: '1rem' }} onClick={() => this.handleDelete()}>{t('Delete')}</reactbootstrap.Button>}
                            </div></div></div></div >

            );
        } else {
            return (
                <div>
                    <h3>{t(this.state.responseText)}</h3>
                </div>
            );
        }
    }

    displayExportButton(){
      const { t, status, columns, rows, defaultColDef } = this.state;
      if(status && columns.length > 0 && rows.length > 0 && Object.keys(defaultColDef).length > 0 && defaultColDef['export']){
        return (<reactbootstrap.Button className="mt-2 mb-5" onClick={() => this.exportXLS()}>{t('Export XLS')}</reactbootstrap.Button>);
      }
    }
    // {this.handleColumnColor()}
    onRowsSelected = rows => {
      let selectIds = [];
      let selectedIndexes = rows.map( key=>{
        selectIds.push(key.row['table_id']);
      return key.rowIdx; });
      this.setState({selectedIndexes:selectedIndexes,selectIds:selectIds});
    }

    onRowsDeselected = rows => {
      let unSelectedIds = [];
      let selectedIndexes =  this.state.selectedIndexes;
      let selectIds = this.state.selectIds;
      let rowIndexes = rows.map(key => {
        unSelectedIds.push(key.row['table_id']);
        return key.rowIdx
      });
      this.setState({
        selectedIndexes: selectedIndexes.filter(x => !rowIndexes.includes(x)),
        selectIds: selectIds.filter(x => !unSelectedIds.includes(x))
      });
    };

    getRows(rows, filters) {
      rows = selectors.getRows({ rows, filters });
      return rows;
    }

    setRows(rows){
      this.setState({rows:rows});
    }

    setFilters(filter){
      let data = ReactDataGridCommonFunc.handleFilterChange(filter,this.state.filters);
      this.setState({filters:data})
    }

    rowGetterFunc(i,filteredRows){
      return filteredRows[i];
    }

    onRowClick = (rowIdx, row, singleRedirect) => {
      let id,docId;
      if(rowIdx !== -1 && row !== undefined){
        id = row['table_id'];
        docId = row['id'];
        // window.open('/notificationview/' + docId + '/' + id + '?q=' + (parseInt(singleRedirect) !== 1 ?  window.location.pathname : '/notifications'),'_blank');
        window.location = '/notificationview/' + docId + '/' + id + '?q=' + (parseInt(singleRedirect) !== 1 ?  window.location.pathname : '/notifications');
      }
    }

    componentDidMount() {
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        let data = {
          grid_type : this.state.gridId,
          grid_items_id : this.state.gridItemId,
          tile_id : this.state.tileId,
          p_id : this.state.personId
        }
        if (person_id == this.state.personId) {
            var url = window.TILE_DETAILS;
            this.handleService(url, 0, {didUpdateStatus:true}, 'POST', data);
        } else {
            this.setState({
                responseText: 'Access Denied'
            })
        }
    }
}

export default translate(notifications);
