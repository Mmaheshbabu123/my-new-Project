import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap'

import { datasave } from '../_services/db_services'
import { connect } from "react-redux";
import { translate } from '../../src/language';
import SecondCycleComonent from '../../src/_components/DocumentCycleComponent/SecondCycleComonent';
import ThirdCycleComponent from '../../src/_components/DocumentCycleComponent/ThirdCycleComponent';
import CommentComponent from '../../src/CommentComponent';

class NotificationView extends Component {
    constructor(props) {
        super(props)
        this.state = {
            save: 'Save',
            credentials: this.props.credentials,
            savevalue: 'true',
            loading: false,
            error: '',
            description: '',
            status: 1,
            submitted: false,
            memo_data: [],
            doc_id: this.props.match.params.docId,
            doc_status: '',
            doc_status_id: '',
            uid: '',
            notifyComment: '',
            t: props.t,
            id: this.props.match.params.id


        }
    }
    handlegoback = () => {
        let goback = window.location.search.replace('?q=', '');
        this.props.history.push(goback);
    }
    componentDidMount() {
        var url = window.GET_INSERT_DOCUMENT_DETAILS_ONLY + '/' + this.props.match.params.docId;
        var notfication_url = window.UPADTE_NOTIFICATIONS + '/' + 1;
        datasave.service(notfication_url, "POST")
            .then(result => {

            });
        datasave.service(url, "GET")
            .then(result => {

                this.setState({
                    doc_id: result.id,
                    doc_status: result.status,
                    doc_status_id: result.docstatusId,
                })
            });


    }
    render() {

        const { doc_id, doc_status, doc_status_id, t } = this.state;
        return (
            // <div className="container py-4">
            <div className=" row mt-5 mb-5" >
                <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
                <div style={{ marginLeft: '-1.5rem' }} className='col-md-11' >
                <div className="row justify-content-center">
                    <div className="col-md-12">
                        <div className="card">
                            {/* <div className="todocycle-back-menu col-md-12" style={{paddingLeft: '3rem', paddingBottom: '0.5rem', paddingTop: '1rem',paddingRight: '3rem', textAlign: 'right',alignSelf: 'center',cursor: 'pointer'}} onClick={(e) => this.handlegoback()}>
                                {t('Go back')}
                            </div> */}
                             <div className="todocycle-back-menu col-md-12" style={{ textAlign: 'end', alignSelf: 'flex-end', cursor: 'pointer' }} onClick={(e) => this.handlegoback()}>
                                    {t('Go back')}
                                </div>
                           <div style={{padding: '3rem', paddingBottom: '0rem', paddingTop: '1rem'}} className="zero">
                            <CommentComponent
                                 url={window.GET_NOTIFY_COMMENT + '/' + this.props.match.params.id}
                            />
                            </div>
                            <div className="zero-one pl-5 pr-5 pt-4">
                            <SecondCycleComonent
                                doc_id={this.state.doc_id}
                                type={'notify'}
                                n_id={this.state.id}
                            />
                            </div>
                            <div className="zero-two pl-5 pr-5 pt-4">
                            <ThirdCycleComponent
                                // credentials ={'78'}
                                status={this.state.doc_status_id}
                            />
                            </div>


                        </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(NotificationView));
