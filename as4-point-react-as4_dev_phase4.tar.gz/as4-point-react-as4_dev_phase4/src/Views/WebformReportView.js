import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { throwStatement } from '@babel/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { translate } from '../language';
import { persistor, store } from '../store';



class WebformReportView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            t: props.t,
            responseText: 'Loading....',
            reportData: [],
            reportViewData: [],
            report_type: 0,
            reportOverViewStatus:false,
        }
    }

    render() {
        const { t } = this.state;
        return (<div className="container py-5 hi">
            {this.state.status === true ? <div>{this.state.reportViewData}</div> : <div>{t(this.state.responseText)}</div>}
        </div>);
    }

    async getReportView(reportData, report_type) {
        const { t } = this.state;
        let table = [];
        await reportData.map(key => {
            table.push(<div>
                <reactbootstrap.Button onClick={(e) => this.handleOnClick(key['id'], key['webform_id'], report_type,key['name'])}> {key['name']} </reactbootstrap.Button>
            </div>);
        })
        return table;
    }

    handleOnClick(id, webform_id, type, name) {
      let storage = store.getState();
      let loggedPerson = storage.UserData.user_details.person_id;
      let url = '/report_view/' + id + '/' + webform_id + '/' + loggedPerson + '/' + name;
      window.location.replace(url, '_blank');
    }

    async componentDidMount() {
        let reportData = this.props.reportData;
        let report_type = this.props.report_type;
        if (reportData !== '' && reportData.length > 0) {
	  let reportViewData = await this.getReportView(reportData, report_type);
          if(reportData.length === 1){
	    reportData.map(key=>{ this.handleOnClick(key['id'], key['webform_id'], report_type, key['name'] )});
	  }else{
            this.setState({ reportViewData: reportViewData, reportData: reportData, report_type: report_type, status: true });
	  }
        } else {
            this.setState({ responseText: 'No web report to show' });
        }
    }

}

export default translate(WebformReportView);
