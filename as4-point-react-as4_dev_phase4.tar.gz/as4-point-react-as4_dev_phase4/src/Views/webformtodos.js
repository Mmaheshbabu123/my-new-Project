import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { throwStatement, existsTypeAnnotation } from '@babel/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import './todo.css';
import './todos.css';
import { persistor, store } from '../store';
import { translate } from '../language';
import Loading from '../Loading';
import ReactDataGrid from "react-data-grid-defaultvalue";
import PopUpModal from './PopUpModal';
import { Editors, Data, Filters,Toolbar } from "react-data-grid-addons-default-filters";
import { OCAlert } from '@opuscapita/react-alerts';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import {ReactDataGridCommonFunc} from './ReactDataGridCommonFunc';
import Pagination from 'react-bootstrap/Pagination';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
const chunkSize = 250;
const getPaginatedRow = (filteredRows, selectedPage, pageDivBy) =>{
          let start = (parseInt(selectedPage) - 1) * parseInt(pageDivBy)
          let end = parseInt(selectedPage) * parseInt(pageDivBy);
          return filteredRows.filter((key, index)=>{  return index >= start && index < end });
};
const selectors = Data.Selectors;
const { NumericFilter, AutoCompleteFilter, MultiSelectFilter, SingleSelectFilter } = Filters;
const handleFilterChange = (filter,filters)=> {
  const newFilters = { ...filters };
      if (filter.filterTerm) {
        newFilters[filter.column.key] = filter;
      } else {
        delete newFilters[filter.column.key];
      }
      return newFilters;
};
const EditConst = ({ value }) => {
    return (<div>{'Edit'}</div>);
};
const dueDateColorConst = ({ value }) => {
  if (value !== '') {
      if ((new Date(value).getTime() - new Date().getTime()) / (1000 * 3600 * 24) <= -1) {
          return <div className={'due_date_class1'} style={{'background-color':'red'}}>{value}</div>;
      } else {
          return <div className={'due_date_class1'} style={{'background-color':'green'}}>{value}</div> ;
      }
  }else{
    return <span>{value}</span>
  }
};

const applyTitleOnCol = (item) =>{
  return <span title={item.name}>{item.name}</span>;
}

class webformtodos extends Component {
    grid = {};
    constructor(props) {
        super(props);
        let userData = store.getState();
        this.state = {
            columns: [],
            rows: [],
            filters:{},
            status: false,
            gridId: this.props.match.params.gridid,
            gridItemId: this.props.match.params.griditemid,
            tileId: this.props.match.params.tileid,
            personId: this.props.match.params.personid,
            formManage: this.props.match.params.simulate,
            t: props.t,
            responseText: 'Loading....',
            selectedIndexes :[],
            selectedRow:{},
            checkedTodoId:0,
            changeUserTodoId:0,
            changedUserId:0,
            show:false,
            todoPersonDetails:[],
            personDetails:[],
            logedinRoleId: userData.UserData.user_details.role_id,
            AS4PersonOrNot: 0,
            defaultColDef:{},
            selectedIndexes1:[],
            selectedSubmitIds:[],
            selectedPage: 1,
            pageDivBy : 10,
            selectedWebTodoId: 0,
            ref_id: 0,
	          onlyDateIdentification: []
        }
        this.addedFilters = {};
    }


  paginate = (number) =>{
         this.setState({selectedPage: number});
  }
    pageFunc = (total, pageDivBy, selectedPage) =>{
          let table = [];
          let resultNumbers = [];
          for(let i = 1 ; i <= Math.ceil(total/pageDivBy); i++){
           resultNumbers.push(i);
          }
          resultNumbers.map(number => {
            table.push(
                <Pagination.Item key={number} id={number} active = { parseInt(number) === parseInt(selectedPage)} onClick={(e) => this.paginate(number)}>{number}</Pagination.Item>
            );
          })
          return table;

  }


    render() {
      const ToDOTILEPermission = () => {
       let {formManage} = this.state;
       if(parseInt(formManage) === 2 && !CanPermissions('Form_management', '')){
         return false;
       }
       else if(parseInt(formManage) === 1 && !CanPermissions('webform_todo_management', '')){
         return false;
       }
       else {
         return true;
       }
     }

	    const {t, status, responseText} = this.state;
        localStorage.setItem('prevLocation', window.location.pathname);
            return (
              <>{ToDOTILEPermission()?
                <div className="fluid pl-5">
                <div className = {'container-fluid pl-4 reactDataGridClass py-5'}>
            		{!status && <div>{t(responseText)}</div>}
                {this.displayPopUp()}
                {this.getReactDataGridComponent()}
                {this.getButtons()}
                </div>
              </div>:<AccessDeniedPage />}
            </>
            );
    }

    getButtons(){
      const {t, AS4PersonOrNot, formManage} = this.state;
      const changeUser = CanPermissions('Change_user', '');
        return (
          <div>
            {this.displayExportButton()}
            {parseInt(formManage) === 1 && changeUser ? <reactbootstrap.Button className="mt-3 mb-5 mr-3" onClick={(e)=>this.handleChangeUser(e)}>{t('Change user')}</reactbootstrap.Button> : ''}
            {(parseInt(formManage) === 2 && CanPermissions('D_formmanagement_webform_todo', '')) ? <reactbootstrap.Button className="mt-3 mb-5" onClick={(e)=>this.handleDeleteTodo(e)}>{t('Delete')}</reactbootstrap.Button> : ''}
            {(parseInt(formManage) === 1 && CanPermissions('D_webformtodomanagement_webform_todo',''))?<reactbootstrap.Button className="mt-3 mb-5" onClick={(e)=>this.handleDeleteWebformTodo(e)}>{t('Delete')}</reactbootstrap.Button>:''}
          </div>
        );
    }

    displayExportButton() {
      const { t, status, columns, rows, defaultColDef } = this.state;
      const ExportXLS = CanPermissions('formmanagement_export_xls', '');
      if(status && columns.length > 0 && rows.length > 0 && Object.keys(defaultColDef).length > 0 && defaultColDef['export'] && ExportXLS){
        return (
          <reactbootstrap.Button className="mt-3 mb-5 mr-3" onClick={() => this.exportXLS()}>{t('Export XLS')}</reactbootstrap.Button>
        );
      }
    }

    exportXLS() {
      const {rows, columns, filters} = this.state;
      var data = {};
      data.columnDefs = columns;
      data.rowData = ReactDataGridCommonFunc.getRows(rows, filters);
      datasave.service('/api/generatefile', "POST", data)
        .then(response => {
          var a = document.createElement("a");
          a.setAttribute("type", "file");
          a.href = response.file;
          a.download = response.name;
          document.body.appendChild(a);
          a.click();
          a.remove();
      });
    }

    displayPopUp(){
      if(this.state.show){
        return (
          <PopUpModal show={this.state.show}
          title={'Change user'}
          handleSelect={this.handleSelect.bind(this)}
          handleClose={(e)=>this.handleClose(e)}
          firstDropDownName="Selected todos webform organisation units : "
          firstDropDownSelectName="changeUserTodoId"
          firstDropDownSelectvalue={this.state.changeUserTodoId}
          firstDropDownOptionValName="value"
          firstDropDownOptionlabName="label"
          firstDropDownOptionData={this.state.todoPersonDetails}
          firstDropDownDisable={true}
          secondDropDownName="Person to be replace : "
          secondDropDownSelectName="changedUserId"
          secondDropDownSelectvalue={this.state.changedUserId}
          secondDropDownOptionValName="value"
          secondDropDownOptionlabName="label"
          secondDropDownOptionData={this.state.personDetails}
          secondDropDownDisable={false}
          saveButtonName={'Confirm'}
          closeButtonName={'Close'}
          handleConfirm={(e)=>this.handleConfirm(e)}
          />
        );
      }
    }
    handleSelect(name,value){
      this.setState({[name]:parseInt(value)});
    }

    handleClose(){
      this.setState({
        changeUserTodoId:0,
        changedUserId:0,
        show:false,
        todoPersonDetails:[],
        personDetails:[],
        selectedIndexes:[],
        selectedRow:{}
      })
    }
    handleConfirm(){
      const {t,changeUserTodoId,changedUserId} = this.state;
      if(changeUserTodoId !== 0 && changeUserTodoId !== undefined && changedUserId !== 0 && changedUserId !== undefined){
        datasave.service(window.UPDATE_WEBFORM_USER_BY_TODOID +'/'+ changeUserTodoId +'/'+ changedUserId, 'GET', '')
           .then(async result => {
             if(result['status'] == 200){
               this.setState({
                 show:false,
               });
               this.componentDidMount();
               OCAlert.alertSuccess(t('User changed successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
             } else{
               OCAlert.alertError(result['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
             }
           });
      }else{
        OCAlert.alertError(t('Please select both, person to be changed and replacing person'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    }

    handleChangeUser(){
        const {t,selectedIndexes} = this.state;
        if(selectedIndexes.length > 0){
          let todoId = this.state.selectedRow['webtodo_id'];
          this.getPersonRelatedToTodo(todoId);
        } else{
          OCAlert.alertError(t('Select respective todo to change the user'), { timeOut: window.TIMEOUTNOTIFICATION });
        }

    }

    async deleteService(data){
      const {t, selectedSubmitIds, rows} = this.state;
       let tempRows = rows;
       await datasave.service(window.DELETE_WEBFORM_SUBMIT , 'POST', data)
           .then(async result => {
            if(result['status'] === 200){
        		 tempRows =  await tempRows.filter(rowObj=>{ return selectedSubmitIds.indexOf(parseInt(rowObj['ref_id'])) === -1});
    		     this.setState({rows: tempRows, selectedSubmitIds: [], selectedIndexes1: []});
               // let url = 'accesspermission/' + id;
               // window.open(url, '_blank');
               OCAlert.alertSuccess(t('Details removed successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
             }else{
               OCAlert.alertError(t('Error please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
             }
           });

    }
    async handleDeleteWebformTodo() {

      const {selectedWebTodoId, ref_id} = this.state;
      let data = {
        todo_ids: [selectedWebTodoId],
        submit_ids: [ref_id],
        type:2
      }
      const tempAsyncFunc = async()=>{
          	await this.deleteService(data);
        	}
        	tempAsyncFunc();

          this.componentDidMount();
    }
    handleDeleteTodo(){
      const {t, selectedSubmitIds} = this.state;
      if(selectedSubmitIds.length > 0) {
        let data = {
          submit_ids : selectedSubmitIds,
          todo_ids : [],
          type:1,
        }
        let todoId = this.state.selectedRow['webtodo_id'];
      	const tempAsyncFunc = async()=>{
        	await this.deleteService(data);
      	}
      	tempAsyncFunc();
      } else {
        OCAlert.alertError(t('Select respective details to delete'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    }

    getReactDataGridComponent() {
      const { columns,rows,filters,originalData, selectedIndexes, selectedIndexes1, selectedPage, pageDivBy, onlyDateIdentification} = this.state;
      const filteredRows = ReactDataGridCommonFunc.getRows(rows, Object.keys(filters).length ? filters: this.addedFilters);
      const filteredRowsPagination = getPaginatedRow(filteredRows, selectedPage, pageDivBy);
      const formManage = parseInt(this.state.formManage);
      let headers = [];
      const editWebformTodos = CanPermissions('edit_webform_todos', '');

      if (CanPermissions('edit_webform_todos', '')) {
        headers = columns
      } else {
        headers = columns.filter(x => x.key !== 'Edit');
      }

      const getSelectedSubmitIdIndex = (filteredRowsPagination, selectedSubmitIds) =>{
	    let result = filteredRowsPagination.map((key, index)=>{
		    return selectedSubmitIds.indexOf(key['webtodo_id']) !== -1 ? index : -1;
	    });
            return result.filter(key=>{ return key !== -1 ? true : false});
      }

      return (
       <div>

        <ReactDataGrid
        ref={(grid) => { this.grid = grid; }}
        columns={headers}
        rowGetter={i=>this.rowGetterFunc(i,filteredRowsPagination)}
        rowsCount={filteredRowsPagination.length}
        onRowClick={(rowId,row, column)=>this.onRowClick(rowId,row, column)}
        rowRenderer={this.RowRenderer}
        rowSelection={{
            showCheckbox: formManage === 1 || formManage === 2 ? true : false,
            enableShiftSelect: true,
            onRowsSelected: formManage === 1 ? this.onRowsSelected : this.onRowsSelected1,
            onRowsDeselected: formManage === 1 ? this.onRowsDeselected : this.onRowsDeselected1,
            selectBy: {
	            indexes: formManage === 1 ?  getSelectedSubmitIdIndex(filteredRowsPagination, this.state.selectedRow['webtodo_id'] !== undefined ? [this.state.selectedRow['webtodo_id']]: []) : getSelectedSubmitIdIndex(filteredRowsPagination, this.state.selectedSubmitIds)
            }
          }}
          onGridSort={(sortColumn, sortDirection) =>this.setRows(
          ReactDataGridCommonFunc.sortRows(rows, sortColumn, sortDirection, originalData, headers, 1, onlyDateIdentification))}
          onAddFilter={filter => this.setFilters(filter)}
          getValidFilterValues={columnKey => this.getValidFilterValues(rows, columnKey)}
          minHeight={480}
        />
        <Pagination style={{ width: '900px', overflow: 'auto',scrollbarWidth: 'thin'}} size="md">
	      { this.pageFunc(filteredRows.length, pageDivBy, selectedPage)}
         </Pagination></div>
      )
    }


    RemindToAddSubmitElement(data,typeid=1) {
        const { t } = this.state;
        let type = typeid === 1?'webform':'document'
        let msg = 'This '+ type +' is currently in use  by';
        let title = 'Unable to open '+type;
        confirmAlert({
            title: t(title),
            message: t(msg)+' '+data,
            buttons: [
                {
                    label: this.props.t('OK'),
                    // onClick: () =>this.removeWebformFrame()
                },
            ]
        });
    }

    redirectFunc = (webTodoId, documentId, submitId, currentStepId, childFormSubmit, column, singleRedirect) =>{
      let {formManage} = this.state;
        const data = {
          todo_id: webTodoId,
          doc_id: documentId,
          ref_id: submitId,
          current_step_id: currentStepId,
        }
        localStorage.setItem('from_simulate',0);
        if (parseInt(formManage) === 1) {
          // window.open('/webformaction/' + documentId + '/' + 0 + '/' + submitId + '/' + currentStepId + '/1/' + window.COMING_FROM_CASE3_management + '/0' + '/0' + '/0' + '/0' + '/0' + '/0' + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications'),'_blank');
          window.location = '/webformaction/' + documentId + '/' + 0 + '/' + submitId + '/' + currentStepId + '/1/' + window.COMING_FROM_CASE3_management + '/0' + '/0' + '/0' + '/0' + '/0' + '/0' + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications');
        }
        else if (parseInt(formManage) !== 2){
          datasave.service(window.GETWEBFORMTODODETAILS , 'POST', data)
           .then(todo_response => {
                let todo_details =todo_response.result['todos_details'];
                let lock_details = todo_response.result['lock_person'];
                let person_name = lock_details['user_name'];
                var is_lock = todo_details['is_lock'];
               if(is_lock === 0 && Object.values(lock_details).length > 0) {
                   this.RemindToAddSubmitElement(person_name,1)
               }
               else if (is_lock === 0 && lock_details.length == 0 ||is_lock === 1 ) {
                 let details = todo_details;
                   details['is_lock_val'] = 0;
                  datasave.service(window.UPDATE_WEBFORMTODO_LOCK_DETAILS, 'POST',details)
                   .then(response_islock => {
                       // window.open('/webformaction/' + documentId + '/' + webTodoId + '/' + submitId + '/' + currentStepId + '/0' + '/0' + '/0' + '/0' + '/0' + '/0' + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications'),'_blank');
                       window.location = '/webformaction/' + documentId + '/' + webTodoId + '/' + submitId + '/' + currentStepId + '/0' + '/0' + '/0' + '/0' + '/0' + '/0' + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications');
                   })
               }
           })
        }
        else{
        if(column['key'] !== undefined && column['key'] === window.STATIC_EDIT_TOKEN_NAME){
          // window.open('/webformaction/' + documentId + '/' + 0 + '/' + submitId + '/' + currentStepId + '/1/' + window.FROM_CASE2_management + '/0' + '/0' + '/0' + '/0' + '/0' + '/0' + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications'),'_blank');
          window.location = '/webformaction/' + documentId + '/' + 0 + '/' + submitId + '/' + currentStepId + '/1/' + window.FROM_CASE2_management + '/0' + '/0' + '/0' + '/0' + '/0' + '/0' + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications');
        }else{
          // window.open('/webformaction/' + documentId + '/' + 0 + '/' + submitId + '/' + currentStepId + '/1/' + window.COMING_FROM_CASE3_management + '/0' + '/0' + '/0' + '/0' + '/0' + '/0' + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications'),'_blank');
          window.location = '/webformaction/' + documentId + '/' + 0 + '/' + submitId + '/' + currentStepId + '/1/' + window.COMING_FROM_CASE3_management + '/0' + '/0' + '/0' + '/0' + '/0' + '/0' + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications');
        }
      }
    }

    onRowClick = (rowIdx, row, column) => {
      const editWebformTodos = CanPermissions('edit_webform_todos', '');
      if (window.location.href.includes("formmanagement")) {
        if(rowIdx !== -1 && row !== undefined && editWebformTodos){
          this.redirectFunc(row['webtodo_id'], row['webform_id'], row['ref_id'], row['current_step_id'], row['child_form_submit'], column, 0);
        }
      } else {
        if(rowIdx !== -1 && row !== undefined){
          this.redirectFunc(row['webtodo_id'], row['webform_id'], row['ref_id'], row['current_step_id'], row['child_form_submit'], column, 0);
        }
      }
    }

    rowGetterFunc(i,filteredRows){
      const row = Object.assign({}, filteredRows[i]);
      const editWebformTodos = CanPermissions('edit_webform_todos', '');
      if (window.location.href.includes("formmanagement")) {
        if((parseInt(this.state.formManage) === 2) && editWebformTodos) {
            row[window.STATIC_EDIT_TOKEN_NAME] = <div title=""><div>{'Edit'}</div></div>;
        }
      } else {
        if(parseInt(this.state.formManage) === 2) {
            row[window.STATIC_EDIT_TOKEN_NAME] = <div title=""><div>{'Edit'}</div></div>;
        }
      }

      return row;
    }
    RowRenderer = ({ renderBaseRow, ...props }) => {
        const color =props.row.blockbox_linked===true ? "red" : "";
        return <div style={{color}}>{renderBaseRow(props)}</div>;
      };
    getRows(rows, filters) {
      rows = selectors.getRows({ rows, filters });
      return rows;
    }

    setRows(rows){
      this.setState({rows:rows});
    }

    setFilters(filter){
      let data = handleFilterChange(filter,this.state.filters);
      this.addedFilters = data;
      this.setState({filters:data, selectedIndexes1:[], selectedSubmitIds:[], selectedRow :{}, selectedIndexes:[], selectedPage: 1});
    }

    onRowsSelected = rows => {
      if(rows.length === 1){
        rows.map( key=>{
          this.setState({
            selectedIndexes: [key.rowIdx],
            selectedRow : key.row,
            selectedWebTodoId: key.row.webtodo_id,
            ref_id: key.row.ref_id
          })
        } ,this)
      }
    }

    onRowsDeselected = rows => {
      let rowIndexes = rows.map(r => r.rowIdx);
      this.setState({
        selectedIndexes: this.state.selectedIndexes.filter(
          i => rowIndexes.indexOf(i) === -1
        )
      });
    };

    onRowsSelected1 = rows => {
      let {selectedSubmitIds, selectedIndexes1} = this.state;
       rows.map( key=>{
        selectedSubmitIds.push(key.row['webtodo_id']);
        selectedIndexes1.push(key.rowIdx)
        });
      this.setState({selectedIndexes1:selectedIndexes1,selectedSubmitIds:selectedSubmitIds});
    }

    onRowsDeselected1 = rows => {
      let unSelectedIds = [];
      let selectedIndexes1 =  this.state.selectedIndexes1;
      let selectedSubmitIds = this.state.selectedSubmitIds;
      let rowIndexes = rows.map(key => {
        unSelectedIds.push(key.row['webtodo_id']);
        return key.rowIdx
      });
      this.setState({
        selectedIndexes1: selectedIndexes1.filter(x => !rowIndexes.includes(x)),
        selectedSubmitIds: selectedSubmitIds.filter(x => !unSelectedIds.includes(x))
      });
    };

    getValidFilterValues(rows, columnId) {
      return rows
        .map(r => r[columnId])
        .filter((item, i, a) => {
          return i === a.indexOf(item);
        });
    }


    getPersonRelatedToTodo(checkedTodoId){
      if(checkedTodoId !== undefined && checkedTodoId !== 0){
        datasave.service(window.WEBTODO_TODO_AND_PERSONS +'/'+ checkedTodoId , 'GET', '')
           .then(async result => {
             if(result['status'] == 200){
               this.setState({
                 todoPersonDetails:result['data']['todo_details'],
                 personDetails:result['data']['person_details'],
                 show:true,
                 changeUserTodoId:parseInt(checkedTodoId)
               })
             }
           })
      }
    }


    addExtraKeysForColumn(columns){
      columns.map(key=>{
        if(key['token_id'] !== undefined && parseInt(key['token_id']) === window.WEBFORM_TODO_DUE_DATE_TOKEN_ID){
          key['formatter'] = dueDateColorConst;
        }
      })
    }

    async componentDidMount() {
      await this.dataLoadMethod(0);
    }

    async dataLoadMethod(loadCount = 0){
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        let formManage = parseInt(this.state.formManage);
        let personId = parseInt(this.state.personId);
        let data = {
          grid_type : this.state.gridId,
          grid_items_id : this.state.gridItemId,
          tile_id : this.state.tileId,
          p_id : this.state.personId,
      	  manage: this.state.formManage,
      	  offset: parseInt(formManage) ? (chunkSize * loadCount) : 0,
      	  limit: parseInt(formManage) ? chunkSize : 0,
        }

        if (( formManage === 0 && parseInt(person_id) === personId) || formManage === 1 || formManage === 2) {
            await datasave.service(window.TILE_DETAILS, 'POST', data, loadCount > 0 ? 0 : 1)
                .then(async result => {
                    if (result['status'] == 200) {
                        let headerObject = await this.staticStateVariables(result);
                        let originalData = result['data']['rowData'];
                        let loadedRows = [...this.state.rows, ...originalData]
            		        let onlyDateIdentification =  result['data']['only_date_identification'] !== undefined ?
            				      result['data']['only_date_identification'] : [];
                        let rows =  Object.keys(headerObject.sortColdirectObj).length > 0 ?
                        await ReactDataGridCommonFunc.sortRows(loadedRows, headerObject.sortColdirectObj['sortColumn'], headerObject.sortColdirectObj['sortDirection'], originalData, headerObject.columns, 1, onlyDateIdentification) :
                        loadedRows;
                        if(!data.limit && Object.keys(headerObject.defaultColDef).length > 0 && headerObject.defaultColDef['filterable'] && !this.state.status){
                          await this.grid.onToggleFilter();
                        }
                          this.setState({
                              ...headerObject,
                              status: true,
                              rows: rows,
                              originalData:originalData,
                              changeUserTodoId:0,
                              changedUserId:0,
                              show:false,
                              todoPersonDetails:[],
                              personDetails:[],
                              selectedIndexes:[],
                              selectedRow:{},
                              selectedSubmitIds:[],
                              selectedIndexes1:[],
		                          onlyDateIdentification: onlyDateIdentification
                          }, async () => {
                              if(parseInt(formManage)) await this.fetchDataInChunkWise(result, loadCount);
                          })
                  } else {
                      this.setState({ status: true })
                  }
                });
        } else {
            this.setState({
                responseText: 'Access Denied'
            })
        }
       if(!loadCount) {
        var url = window.USERROLES + '/' + this.state.logedinRoleId;
        datasave.service(url, "GET")
          .then(response => {
            this.setState({
              AS4PersonOrNot: response[0] ?  response[0]['as4member'] : 0,
            })
          })
       }
    }

    async staticStateVariables(result, loadCount = 0) {
      if(loadCount)
          return {
            columns: this.state.columns,
            sortColdirectObj: this.state.sortColdirectObj,
            filters: this.state.filters,
            defaultColDef: this.state.defaultColDef
          }
      const { t } = this.state;
      let translatedColumns = ReactDataGridCommonFunc.getTranslatedColumns(result['data']['columnDefs'], t);
      let columns = ReactDataGridCommonFunc.orderColumnAccordingToPriority(translatedColumns);
      await this.addExtraKeysForColumn(columns);
      columns.map(key=>{ key['headerRenderer'] = applyTitleOnCol(key); });
      let sortColdirectObj = await ReactDataGridCommonFunc.getSortColAndSortDirection(columns);
      const filters = ReactDataGridCommonFunc.getFiterAccordingToType(columns, EditConst);
      let defaultColDef = result['data']['defaultColDef'];
      return {
        columns,
        sortColdirectObj,
        filters,
        defaultColDef
      }
    }

    async fetchDataInChunkWise(response, loadCount){
      if(response['data']['dataLoaded'] === 0){
        await this.dataLoadMethod(loadCount + 1);
      }else if(Object.keys(this.state.defaultColDef).length > 0 && this.state.defaultColDef['filterable']){
        await this.grid.onToggleFilter();
      }
    }

    orderColumnAccordingToPriority(column){
      if(column.length > 0){
         return column.sort(function(a , b) {
          return a['priority'] - b['priority'];
        });
      } else{
        return [];
      }
    }
}

export default translate(webformtodos);
