import React,{useState ,useEffect} from 'react'
import * as reactbootstrap from 'react-bootstrap'
import { datasave } from '../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts'
import { translate } from '../language';
import { store } from '../store';
import KpiMiddleReportWindow from '../Kpi/KpiReport/KpiMiddleReportWindow';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';
import loading from '../loading.gif';
const KpiReportTabView = props =>{
  const t =props.t;
  const userData  = store.getState();
  const person_id = userData.UserData.user_details.person_id;
  const urlstring  = window.location.href;
  const fromiFrame = urlstring.includes('downloadkpireport') ? 1 : 0;
  const [state, setState] = useState({ gridId: props.match.params.gridid,
      gridItemId: props.match.params.griditemid,
      tileId: props.match.params.tileid,
      personId: person_id,
	    reportList: [],
	    status: false,
      error: null,
      accessDenied: false,
	    responseText: '...loading',
	    activeReport: 0,
	    reportDetails: {fromDate: '', toDate: '', select_date_type: 0, bundle_type: 0, graph_type: 0,
        target_type: 0, target_direct_value: 0, target_element_value: [], target_date_type: 0, target_individual: 0,
        actual_type:0, operation:0, actual_individual: 0, actual_element_value: [], min_value: 0, max_value: 0,
        min_value_type: 0, max_value_type: 0, cummulative: 0, kpi_name: ''},
      reportsLoaded: false
})
const {reportList, status, responseText, activeReport, error} = state;

useEffect(()=>{
const callKpiDetailsService = async()=>{
  getKpiDetails();
}
callKpiDetailsService()
},[])
  async function getKpiDetails(){
     let data = {
          grid_type : state.gridId,
          grid_items_id : state.gridItemId,
          tile_id : state.tileId,
          p_id : state.personId
        };
  await datasave.service(window.TILE_DETAILS, 'POST', data).then(
     async reportCombineData => {
       let result = reportCombineData['kpiReports'];
       let accessDenied = (reportCombineData['kpiReportsData']['status'] === 410 || result['status'] === 410) ? true : false;
       if(accessDenied){
         setState({...state, accessDenied: true})
         return;
       }
	     if(result['status'] === 200 && result['data'].length > 0){
	     let tempActiveReport = result['data'].length > 0 && result['data'][0]['id'] !== undefined ? result['data'][0]['id'] : 0;
             await getKpiReportDetails({reportList: result['data'], status: true, responseText: '', activeReport: tempActiveReport}, tempActiveReport, reportCombineData);
	     }else{
         setState({...state, ...{responseText: 'No data', error: true}})
         if(!fromiFrame){ OCAlert.alertError(result['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });}
	     }
	})
    }
async function getKpiReportDetails(setObj, k, reportCombineData){
	// datasave.service(window.GET_KPI_REPORT + '/' + (parseInt(k)), 'GET').then(
      // async response => {
    let response = reportCombineData['kpiReportsData'];
    if(response['status'] == 200){
    const tempKpiDetails = response['data']['kpiDetails'] !== undefined ? response['data']['kpiDetails'] : {};
    const tempActualTargetElementData = response['data']['actual_target_data'] !== undefined ? response['data']['actual_target_data'] : {};
    let tempFromDate = tempActualTargetElementData['fromDate'] !== undefined ? tempActualTargetElementData['fromDate'] : '';
    let tempToDate = tempActualTargetElementData['toDate'] !== undefined ? tempActualTargetElementData['toDate'] : '';
		setObj['reportDetails'] =  {
            fromDate: tempFromDate,
            toDate: tempToDate,
            select_date_type: tempKpiDetails['select_date_type'] !== undefined ? tempKpiDetails['select_date_type'] : 0,
            bundle_type: tempKpiDetails['bundle_type'] !== undefined ? tempKpiDetails['bundle_type'] : 0,
            graph_type: tempKpiDetails['graph_type'] !== undefined ? tempKpiDetails['graph_type'] : 0,
            target_type: tempKpiDetails['target_type'] !== undefined ? tempKpiDetails['target_type'] : 0,
            target_direct_value: tempKpiDetails['target_value'] !== undefined ? tempKpiDetails['target_value'] : 0,
            target_element_value: tempActualTargetElementData['targetData'] !== undefined ?
            tempActualTargetElementData['targetData'] : [],
            target_date_type: tempKpiDetails['target_date_type'] !== undefined && tempKpiDetails['target_date_type'] !== null ? tempKpiDetails['target_date_type'] : window.KPI_TAREGET_DATE_LAST_PERIOD,
            target_individual: tempKpiDetails['target_individual'] !== undefined ? tempKpiDetails['target_individual'] : 0,
            actual_type: tempKpiDetails['actual_type'] !== undefined ? tempKpiDetails['actual_type'] : 0,
            operation: tempKpiDetails['operation'] !== undefined ? tempKpiDetails['operation'] : 0 ,
            actual_individual: tempKpiDetails['actual_individual'] !== undefined ? tempKpiDetails['actual_individual'] : 0 ,
            actual_element_value:  tempActualTargetElementData['actualData'] !== undefined ?
            tempActualTargetElementData['actualData'] : [],
            min_value: tempKpiDetails['min_value'] !== undefined ? tempKpiDetails['min_value'] : 0 ,
            max_value: tempKpiDetails['max_value'] !== undefined ? tempKpiDetails['max_value'] : 0 ,
            min_value_type: tempKpiDetails['min_value_type'] !== undefined ? tempKpiDetails['min_value_type'] : 0 ,
            max_value_type: tempKpiDetails['max_value_type'] !== undefined ? tempKpiDetails['max_value_type'] : 0 ,
            cummulative: tempKpiDetails['cummulative'] !== undefined ? tempKpiDetails['cummulative'] : 0,
            target_cummulative: tempKpiDetails['target_cummulative'] !== undefined ? tempKpiDetails['target_cummulative'] : 0,
            actual_cummulative: tempKpiDetails['actual_cummulative'] !== undefined ? tempKpiDetails['actual_cummulative'] : 0,
            kpi_name: tempKpiDetails['name'] !== undefined ? tempKpiDetails['name'] +' '+ ('('+tempFromDate + ' - ' + tempToDate+')')
	          : (tempFromDate + ' - ' + tempToDate),
            actual_element_type: tempKpiDetails['actual_element_type'] !== undefined ? tempKpiDetails['actual_element_type'] : 0,
        };
	       setState({...state, ...setObj, reportsLoaded: true});
        }else{
          if(!fromiFrame){ OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });}
        }
      // })
    }

// const handleKpiTab = async (k) =>{
//  await getKpiReportDetails({activeReport: parseInt(k)}, k);
// }
// const kpiTabs = () =>{
//  if(status && reportList.length > 0){
//   return (<reactbootstrap.Tabs activeKey={parseInt(activeReport)} onSelect={(k) => handleKpiTab(k)}>
//   {reportList.map(repObj=>{
//   return <reactbootstrap.Tab eventKey = {repObj['id']} title = {repObj['name']} ></reactbootstrap.Tab>
//   })} </reactbootstrap.Tabs>);
//  }
// }

const parentSetState = (paramState) =>{
	let tempReportDetails = {...(state.reportDetails), ...paramState}
	setState({...state, ...{reportDetails: tempReportDetails}});
}

const displayReport = () =>{
 if(status && reportList.length > 0 && parseInt(activeReport) !== 0){
 return <KpiMiddleReportWindow state = {state.reportDetails} setState = {parentSetState} kpiId = {parseInt(activeReport)} fromiFrame={fromiFrame}/>
 }
}

return (
  <>{state.accessDenied === false && CanPermissions("Overview_KPI", "")?
    <div className = {fromiFrame ? 'col-md-6 p-0 m-0':'container py-10 mt-1' }>
     {fromiFrame === 0 && <div className='goback-btn-kpi-dashboard'> <a href="javascript:;" className='goback-btn-kpi-dashboard-btn' onClick={() => props.history.goBack()}>{t('Go back')}</a></div>}
	   {fromiFrame === 0 && <p>{t(responseText)}</p>}
	   {state.reportsLoaded === true ? displayReport() : !error ? <div style={{position:'absolute', left:'40%', top:'25%', marginTop:'25%'}}> <img src = {loading} alt = {'Loading...'} width='30px'/></div> : <div>{'No data'}</div>}
    </div>  :  fromiFrame === 0 ? <AccessDeniedPage /> : null}
  </>
  )
 }
export default translate(KpiReportTabView);
