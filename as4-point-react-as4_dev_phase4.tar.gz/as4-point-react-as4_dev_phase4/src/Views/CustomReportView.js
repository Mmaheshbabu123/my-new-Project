import React, { Component, Suspense } from 'react';
import { translate } from '../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import MainCustomWindow from '../Webforms/CustomReportsV1/MainCustomWindow';

class CustomReportView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            t: props.t,
            responseText:'....loading',
            responseStatus:false,
            reportDataList:[],
            activeReportTab:0,
        }
    }

    componentDidMount(){
        const  {t} =  this.state
        const {report_ids} = this.props;
        if(report_ids.length > 0){
        datasave.service(window.GET_ALL_CUSTOM_CHART_BY_ID, 'POST', {ids:report_ids}).then(result => {
            if(result['status'] == 200){
                let data = this.getSettingsOrder(result['data']);
                this.setState({
                    reportDataList: data,
                    responseStatus: true,
                    activeReportTab : data.length > 0 && data[0]['id'] !== undefined ? data[0]['id'] : 0
                })
            }else{
              this.setState({responseText: 'Error'})
              OCAlert.alertError(t('Error occured while fetching reports!'), { timeOut: window.TIMEOUTNOTIFICATION });
            }
        })}
    }
    render(){
      const { t, responseText, responseStatus} = this.state;
      if(responseStatus){
        return   <><div>{this.getReportTabs()}</div>
                <div>{this.getCustomChart()}</div></>
      }else{
        return <div>{t(responseText)}</div>;
    }

}

getSettingsOrder(data){
  let reportIds = this.props.report_ids && this.props.report_ids.length > 0 ? this.props.report_ids : [];
  let sortedData = {};
  data.map(obj => sortedData[reportIds.indexOf(obj.id)] = obj)
  return Object.values(sortedData);
}

  getReportTabs(){
    const {activeReportTab, reportDataList} = this.state;
    return (<reactbootstrap.Tabs  activeKey={activeReportTab} onSelect={this.handleTab.bind(this)}>
    {reportDataList.map(key=>{
      return (<reactbootstrap.Tab eventKey= {key['id']} title={key['title']}>
      </reactbootstrap.Tab>)
    })}
    </reactbootstrap.Tabs>);
  }

  getCustomChart(){
    const {activeReportTab, reportDataList} = this.state;
    let reportObj = reportDataList.filter(key=> parseInt(key['id']) === parseInt(activeReportTab));
    let webformId = reportObj.length > 0 && reportObj[0]['webform_id'] !== undefined ? reportObj[0]['webform_id'] : 0;
    return this.getCustomChartComponent(activeReportTab, webformId);
  }
  getCustomChartComponent(id, webformId){
    return <MainCustomWindow id = {parseInt(id)} webformId = {parseInt(webformId)} activeTab = {1} disableFields = {1} />
  }
  handleTab(e){
    const {reportDataList} = this.state;
      let reportObj = reportDataList.filter(key=> parseInt(key['id']) === parseInt(e));
      let webformId = reportObj.length > 0 && reportObj[0]['webform_id'] !== undefined ? reportObj[0]['webform_id'] : 0;
   // this.refs.maincustomreport.fetchAllWebElements({id: e, webform_id : webformId});
      this.setState({activeReportTab : parseInt(e)});

  }
}
export default translate(CustomReportView);
