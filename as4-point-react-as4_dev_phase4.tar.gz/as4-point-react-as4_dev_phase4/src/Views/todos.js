import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { throwStatement, existsTypeAnnotation } from '@babel/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import './todo.css';
import './todos.css';
import { persistor, store } from '../store';
import { translate } from '../language';
import ReactDataGrid from "react-data-grid-defaultvalue";
import PopUpModal from './PopUpModal';
import { Editors, Data, Filters,Toolbar } from "react-data-grid-addons-default-filters";
import { OCAlert } from '@opuscapita/react-alerts';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css';
import {ReactDataGridCommonFunc} from './ReactDataGridCommonFunc';
import Loading from '../Loading';
import Pagination from 'react-bootstrap/Pagination'
const getPaginatedRow = (filteredRows, selectedPage, pageDivBy) =>{
          let start = (parseInt(selectedPage) - 1) * parseInt(pageDivBy)
          let end = parseInt(selectedPage) * parseInt(pageDivBy);
          return filteredRows.filter((key, index)=>{  return index >= start && index < end });
};
const selectors = Data.Selectors;
const { NumericFilter, AutoCompleteFilter, MultiSelectFilter, SingleSelectFilter } = Filters;
const dueDateColorConst = ({ value }) => {
  if (value !== '') {
      if ((new Date(value).getTime() - new Date().getTime()) / (1000 * 3600 * 24) <= -1) {
          return <div className={'due_date_class1'} style={{'background-color':'red'}}>{value}</div>;
      } else {
          return <div className={'due_date_class1'} style={{'background-color':'green'}}>{value}</div> ;
      }
  }else{
    return <span>{value}</span>
  }
};
const applyTitleOnCol = (item) =>{ return <span title={item.name}>{item.name}</span>; }

class todos extends Component {
    grid = {};
    constructor(props) {
        super(props);
        this.state = {
            columns: [],
            rows: [],
            status: true,
            defaultColDef: {},
            filters:{},
            originalData:[],
            gridId: this.props.match.params.gridid,
            gridItemId: this.props.match.params.griditemid,
            tileId: this.props.match.params.tileid,
            personId: this.props.match.params.personid,
            t: props.t,
            responseText: props.t('Loading'),
            selectedPage: 1,
            pageDivBy : 20,
        }
        this.exportXLS = this.exportXLS.bind(this);
    }

    exportXLS() {
        const {rows, columns, filters} = this.state;
        var data = {};
        data.columnDefs = columns;
        data.rowData = ReactDataGridCommonFunc.getRows(rows, filters);
        datasave.service('/api/generatefile', "POST", data)
            .then(response => {
                var a = document.createElement("a");
                a.setAttribute("type", "file");
                a.href = response.file;
                a.download = response.name;
                document.body.appendChild(a);
                a.click();
                a.remove();
            });
    }
  paginate = (number) =>{
	 this.setState({selectedPage: number});
  }
    pageFunc = (total, pageDivBy, selectedPage) =>{
          let table = [];
          let resultNumbers = [];
          for(let i = 1 ; i <= Math.ceil(total/pageDivBy); i++){
           resultNumbers.push(i);
          }
          resultNumbers.map(number => {
            table.push(
                <Pagination.Item key={number} id={number} active = { parseInt(number) === parseInt(selectedPage)} onClick={(e) => this.paginate(number)}>{number}</Pagination.Item>
            );
          })
          return table;

  }


    render() {
      console.log('im out');
      const { t, columns, rows, filters, originalData, status, responseText, selectedPage, pageDivBy} = this.state;
        const filteredRows = ReactDataGridCommonFunc.getRows(rows, filters);
        const filteredRowsPagination = getPaginatedRow(filteredRows, selectedPage, pageDivBy);
	  localStorage.setItem('prevLocation', window.location.pathname);
          return (
            <div className="fluid pl-5">
            <div className='container-fluid pl-4 reactDataGridClass py-4' >
              <div className="row justify-content-center">
                <div className='col-md-12'>
                      {responseText}
                      <ReactDataGrid
                        ref={(grid) => { this.grid = grid; }}
                        columns={columns}
                        rowGetter={i=>this.rowGetterFunc(i, filteredRowsPagination)}
                        rowsCount={filteredRowsPagination.length}
                        onRowClick={(rowId,row)=>this.onRowClick(rowId,row)}
                        onGridSort={(sortColumn, sortDirection) =>this.setRows(
                        ReactDataGridCommonFunc.sortRows(rows,sortColumn,sortDirection,originalData, columns, 0, []))}
                        onAddFilter={filter => this.setFilters(filter)}
                        minHeight={480}
                        getValidFilterValues={columnKey => ReactDataGridCommonFunc.getValidFilterValues(rows, columnKey)}
                      />
               <Pagination style={{ width: '900px', overflow: 'auto',scrollbarWidth: 'thin'}} size="md">
               {this.pageFunc(filteredRows.length, pageDivBy, selectedPage)}
               </Pagination>
               {this.displayExportButton()}
                </div>

              </div >
            </div>
            </div>
          );
    }



    displayExportButton(){
      const { t, status, columns, rows, defaultColDef } = this.state;
      if(status && columns.length > 0 && rows.length > 0 && Object.keys(defaultColDef).length > 0 && defaultColDef['export']){
        return (<reactbootstrap.Button onClick={() => this.exportXLS()}>{t('Export XLS')}</reactbootstrap.Button>);
      }
    }

    // {this.handleColumnColor()}

    getRows(rows, filters) {
      rows = selectors.getRows({ rows, filters });
      return rows;
    }

    setRows(rows){
      this.setState({rows:rows});
    }

    setFilters(filter){
      let data = ReactDataGridCommonFunc.handleFilterChange(filter,this.state.filters);
      this.setState({filters:data, selectedPage: 1})
    }

    rowGetterFunc(i,filteredRows){
      return filteredRows[i];
    }


    redirectFunc = (docId, document_status, todoId, webform, singleRedirect) =>{
	    const redirectPath = parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications';
        if (parseInt(document_status) === 20) {
          window.location = '/todosone/' + docId + '/' + document_status + '/' + todoId + '/' + webform + '?q=' + redirectPath;
          // window.open('/todosone/' + docId + '/' + document_status + '/' + todoId + '/' + webform + '?q=' + redirectPath,'_blank');
        } else if (parseInt(document_status) === 21) {
          window.location = '/todostwo/' + docId + '/' + document_status + '/' + todoId +  '/' + webform + '?q=' + redirectPath;
          // window.open('/todostwo/' + docId + '/' + document_status + '/' + todoId +  '/' + webform + '?q=' + redirectPath,'_blank');
        } else if (parseInt(document_status) !== 0) {
            window.location = '/todocycle/' + docId + '/' + document_status + '/' + webform + '/' + todoId + '?q=' + redirectPath;
            // window.open('/todocycle/' + docId + '/' + document_status + '/' + webform + '/' + todoId + '?q=' + redirectPath,'_blank');
        }
    }

    onRowClick = (rowIdx, row) => {
      if(rowIdx !== -1 && row !== undefined){
      	this.redirectFunc(row.id, row.status, row.todoId, row.webform, 0);
      }
    }


    async componentDidMount() {
        let Userdata = store.getState();
        const {t} =this.state;
        let person_id = Userdata.UserData.user_details.person_id;
        let data = {
          grid_type : this.state.gridId,
          grid_items_id : this.state.gridItemId,
          tile_id : this.state.tileId ,
          p_id : this.state.personId
        }
        if (person_id == this.state.personId) {
          await datasave.service(window.TILE_DETAILS, 'POST', data).then(
            async result => {
              let translatedColumns = ReactDataGridCommonFunc.getTranslatedColumns(result.columnDefs, t);
              let columns = await ReactDataGridCommonFunc.orderColumnAccordingToPriority(translatedColumns);
              let sortColdirectObj = await ReactDataGridCommonFunc.getSortColAndSortDirection(columns);
              let originalData = result.rowData;
              let rows =  Object.keys(sortColdirectObj).length > 0 ?
               await ReactDataGridCommonFunc.sortRows(result.rowData, sortColdirectObj['sortColumn'], sortColdirectObj['sortDirection'], originalData, columns, 0, []) :
               result.rowData;
              let defaultColDef = result.defaultColDef;
              if(defaultColDef['filterable'] !== undefined && defaultColDef['filterable']){
                await this.grid.onToggleFilter();
              }
              await this.addExtraKeysForColumn(columns);
              columns.map(key=>{ key['headerRenderer'] = applyTitleOnCol(key); });
              const filters = ReactDataGridCommonFunc.getFiterAccordingToType(columns);
	      const filteredRows = ReactDataGridCommonFunc.getRows(rows, filters);
	      if(filteredRows.length === 1){
	      filteredRows.map(key=>{ this.redirectFunc(key.id, key.status, key.todoId, key.webform, 1) });
	      }else{
	      this.setState({
              status: true,
              columns: columns,
              rows: rows,
              defaultColDef: defaultColDef,
              originalData:originalData,
              filters: filters,
              responseText:rows.length === 0 ?t("Good job, there are no more open to dos for you"): ''
              })
              }
          })
        } else {
            this.setState({
                responseText: t('Access Denied')
            })
        }
    }





    addExtraKeysForColumn(columns){
      columns.map(key=>{
        if(key['token_id'] !== undefined && parseInt(key['token_id']) === window.DUE_DATE_TOKEN_ID){
          key['formatter'] = dueDateColorConst;
        }
      })
    }

    getCurrentDate(dateValue, separator = '-') {
        let newDate = new Date()
        let date = newDate.getDate();
        let month = newDate.getMonth() + 1;
        let year = newDate.getFullYear();
        return `${year}${separator}${month < 10 ? `0${month}` : `${month}`}${separator}${date}`
    }

}

export default translate(todos);
