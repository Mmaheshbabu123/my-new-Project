import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap'
import { datasave } from '../_services/db_services'
import { connect } from "react-redux";
import { translate } from '../../src/language';
import { persistor, store } from '../store';
import './Todocycle.css';
import FirstCycleComponent from '../../src/_components/DocumentCycleComponent/FirstCycleComponent';
import SecondCycleComonent from '../../src/_components/DocumentCycleComponent/SecondCycleComonent';
import ThirdCycleComponent from '../../src/_components/DocumentCycleComponent/ThirdCycleComponent';
import FourthCycleComponent from '../../src/_components/DocumentCycleComponent/FourthCycleComponent';
import Workflow from '../../src/_components/Workflow';
import WebFormBuild from '../Webforms/Views/WebformBuildAction';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';


class Todocycle extends Component {
    constructor(props) {
        super(props)
        this.state = {
            save: 'Save',
            credentials: this.props.credentials,
            savevalue: 'true',
            loading: false,
            error: '',
            description: '',
            status: 1,
            submitted: false,
            memo_data: [],
            doc_id: '',
            doc_status: '',
            bundle_revise_status:1,
            doc_status_id: '',
            uid: '',
            details: '',
            show: false,
            Reason: 'Reason of Change',
            dowload_link: '',
            revise_doc_code:'',
            todo_id : 0,
            t: props.t,
            export_format : 1,
            isWebform_doc : 0,
            isAccess:1,
            webform: (this.props.match.params.webform !== undefined && parseInt(this.props.match.params.webform)) ? 1 : 0,
        }
        // this.handleReason = this.handleReason.bind(this);
        // this.handleWork = this.handleWork.bind(this);
        this.handlegoback = this.handlegoback.bind(this);
    }
    async componentDidMount() {
        var url = window.GET_INSERT_DOCUMENT_DETAILS_ONLY + '/' + this.props.match.params.id;
        var todo_id = this.props.match.params.todoid;
        var doc_id = this.props.match.params.id;
        let Userdata = store.getState();
        const personId = Userdata.UserData.user_details.person_id;
        var todo_url = window.GET_TODO_PERSON_ID + '/' + todo_id;
  await datasave.service(todo_url, "GET")
  .then(async result => {
  if(result.status === 200 && result.data.person_id === personId){
    await datasave.service(url, "GET")
         .then(async result => {
           let export_format = result.export_format ? parseInt(result.export_format) : 1;
           let isWebform_doc = result.isWebform_doc ? parseInt(result.isWebform_doc) : 0;
           if (!result.bundle_revise_status) {
        //  var url = window.GET_BUNDLE_REVISE_DOC_IDS + '/' + this.props.doc_id;
             await datasave.service(window.GET_BUNDLE_REVISE_DOC_IDS + '/' + this.props.match.params.id, 'GET')
               .then(async response => {
                 // this.setState({
                 //  revise_comment:result.comment,
                 //  revise_doc_name:result.name,
                 // });

                 let comment=[];
                 if(response.roc){
                   comment=(response.roc).split('$$');
                   comment=comment[0];
                 }

                 this.setState({
                     doc_id: result.id,
                     doc_status: result.status,
                     doc_status_id: result.docstatusId,
                     bundle_revise_status:result.bundle_revise_status,
                     revise_comment:comment,
                      revise_doc_name:response.data[1].name,
                      revise_doc_code:response.data[1].code,
                      reason_of_change_comment:response.data[1].comment,
                      todo_id :todo_id,
                      export_format : export_format,
                      isWebform_doc: isWebform_doc,
                        isAccess:1,
                   })
               })
           }
           else {
             this.setState({
                 doc_id: result.id,
                 doc_status: result.status,
                 doc_status_id: result.docstatusId,
                 bundle_revise_status:result.bundle_revise_status,
                 todo_id :todo_id,
                 export_format : export_format,
                 isWebform_doc: isWebform_doc,
                 isAccess:1,
               })
           }
         });
  }
  else {
    this.setState({
      isAccess:0,
    })
  }
  })



    }
    // handleReason(e) {
    //     var url = window.GET_INSERT_DOCUMENT_DETAILS + '/' + this.state.doc_id
    //     datasave.service(url, 'GET')
    //         .then(result => {
    //             this.setState({
    //                 details: result.document,
    //                 show: true
    //             })
    //         })
    // }
    // handleWork(e) {
    //     var id = this.state.doc_id;
    //     var url = window.WORK_CURRENT + id;
    //     datasave.service(url, 'GET', id)
    //         .then(result => {
    //         })
    // }
    handlehide = () => {
        this.setState({ show: false })
    }
    handlegoback = () => {
        let goback = window.location.search.replace('?q=', '');
        this.props.history.push(goback);
    }


    render() {
        const { doc_id, doc_status, doc_status_id, details, t, webform ,todo_id} = this.state;
        const pagerender = details.reason_of_change;
        const popup = (
            <reactbootstrap.Modal
                show={this.state.show}
                onHide={this.handlehide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title"
            >
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                    </reactbootstrap.Modal.Title>
                    <reactbootstrap.Modal.Body>
                        <reactbootstrap.Table striped bordered hover size="sm">
                            <thead>
                                <tr>
                                    <td>{this.state.Reason}</td>
                                </tr>
                            </thead>
                            <tbody>
                                {pagerender}
                            </tbody>
                        </reactbootstrap.Table>
                        <div>
                            <h1>hello</h1>
                        </div>
                    </reactbootstrap.Modal.Body>
                </reactbootstrap.Modal.Header>
            </reactbootstrap.Modal>
        );
        return (
            // <div className="container">
        <>  {this.state.isAccess === 1 ?  <div className="row mt-5 mb-5">
                <div style={{ visibility: 'hidden' }} className="col-md-1">
                    <p>welcome</p>
                </div>
                {/* <div className='row justify-content-center' > */}
                <div style={{ marginLeft: '-1.5rem' }} className='col-md-11' >
                    <div className="row justify-content-center">
                        <div className="col-md-12">
                            <div className="card">
                                {/* <div style={{ display: 'flex' }}>
                                    <div className="col-md-10">

                                    </div>
                                    <div className="col-md-2 todocycle-back-menu " style={{ paddingLeft: '3rem', paddingBottom: '0.5rem', paddingTop: '1rem', paddingRight: '3rem', textAlign: 'right', alignSelf: 'center', cursor: 'pointer' }} onClick={(e) => this.handlegoback()}>
                                        {t('Go back')}
                                    </div>

                                </div> */}
                                 <div className="todocycle-back-menu col-md-2" style={{ textAlign: 'end', alignSelf: 'flex-end', cursor: 'pointer' }} onClick={(e) => this.handlegoback()}>
                                    {t('Go back')}
                                </div>
                              {webform!==1 && <Workflow export_format = {this.state.export_format} isWebform_doc = {this.state.isWebform_doc} doc_id={this.state.doc_id}
                                />}
                                <div style={{ padding: '3rem', paddingBottom: '0rem', paddingTop: '1rem', paddingLeft:'1.5rem' }} className="zero">
                                    <FirstCycleComponent
                                        status={this.props.match.params.status} details={this.state.doc_status}
                                         doc_id={this.props.match.params.id}
                                         bundle_revise_status = {this.state.bundle_revise_status}
                                         revise_comment={this.state.revise_comment}
                                         revise_doc_name={this.state.revise_doc_name}                                      todo_id = {this.props.match.params.todoid}
                                         revise_doc_code={this.state.revise_doc_code}
                                         reason_of_change_comment={this.state.reason_of_change_comment}
                                    />
                                </div>
                                {webform !== 1 &&
                                  <div className="">
                                      <SecondCycleComonent
                                          doc_id={this.state.doc_id}
                                      />
                                  </div>
                                }
                                {webform === 1 &&
                                  <WebFormBuild {...this.props} todoid = {0}  simulate = {1} refid = {1} webform_id = {this.props.match.params.id} stepid = {1} view = {1} stepAction = {window.FROM_CASE1_activation_cycle} />
                                }
                                <ThirdCycleComponent
                                    // credentials ={'78'}
                                    status={this.state.doc_status_id}
                                    doc_id={this.state.doc_id}
                                />
                                <div className="pl-5">
                                    <FourthCycleComponent
                                        status_id={this.state.doc_status_id}
                                        status_name={this.state.doc_status}
                                        doc_id={this.state.doc_id}
                                        todoflow={false}
                                        history={this.props.history}
                                    />
                                </div>
                            </div>
                        </div>
                        {/* </div> */}
                    </div>
                </div>
            </div>:<AccessDeniedPage />}</>
        );
    }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(Todocycle));
