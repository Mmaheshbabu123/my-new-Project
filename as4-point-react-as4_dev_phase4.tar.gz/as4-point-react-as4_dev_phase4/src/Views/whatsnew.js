import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { throwStatement } from '@babel/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { translate } from '../language';
import { persistor, store } from '../store';
import ReactDataGrid from "react-data-grid-defaultvalue";
import PopUpModal from './PopUpModal';
import { Editors, Data, Filters,Toolbar } from "react-data-grid-addons-default-filters";
import { OCAlert } from '@opuscapita/react-alerts';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css';
import {ReactDataGridCommonFunc} from './ReactDataGridCommonFunc';
const selectors = Data.Selectors;
const { NumericFilter, AutoCompleteFilter, MultiSelectFilter, SingleSelectFilter } = Filters;
const applyTitleOnCol = (item) =>{ return <span title={item.name}>{item.name}</span>; }

class whatsnew extends Component {
    grid = {};
    constructor(props) {
        super(props);
        this.state = {
            columns: [],
            rows: [],
            status: false,
            defaultColDef: {},
            filters:{},
            originalData:[],
            gridId: this.props.match.params.gridid,
            gridItemId: this.props.match.params.griditemid,
            tileId: this.props.match.params.tileid,
            personId: this.props.match.params.personid,
            t: props.t,
            responseText: 'Loading....',
        }
        this.exportXLS = this.exportXLS.bind(this);
    }

    exportXLS() {
        var data = {};
        const {rows, columns, filters} = this.state;
        data.columnDefs = columns;
        data.rowData = ReactDataGridCommonFunc.getRows(rows, filters);
        datasave.service('/api/generatefile', "POST", data)
            .then(response => {
                var a = document.createElement("a");
                a.setAttribute("type", "file");
                a.href = response.file;
                a.download = response.name;
                document.body.appendChild(a);
                a.click();
                a.remove();
            });
    }

    render() {
      console.log(this.state);
      console.log(this.state.filters);
        const { t, columns,rows,filters,originalData, status, responseText} = this.state;
          const filteredRows = ReactDataGridCommonFunc.getRows(rows, filters);
            return (
                <div className="fluid pl-5">
                    <div className='container-fluid pl-4 reactDataGridClass py-4' >
                        <div className='row justify-content-center' >
                            <div className='col-md-12' >
                              <div>{t(responseText)}</div>
                              <ReactDataGrid
                              ref={(grid) => { this.grid = grid; }}
                              columns={columns}
                              rowGetter={i=>this.rowGetterFunc(i,filteredRows)}
                              rowsCount={filteredRows.length}
                              onRowClick={(rowId,row)=>this.onRowClick(rowId,row)}
                              onGridSort={(sortColumn, sortDirection) =>this.setRows(
                              ReactDataGridCommonFunc.sortRows(rows,sortColumn,sortDirection,originalData, columns, 0, []))}
                              onAddFilter={filter => this.setFilters(filter)}
                              minHeight={480}
                              getValidFilterValues={columnKey => ReactDataGridCommonFunc.getValidFilterValues(rows, columnKey)}
                              />
                            {this.displayExportButton()}
                            </div></div></div></div>

            );
    }

    displayExportButton(){
      const { t, status, columns, rows, defaultColDef } = this.state;
      if(status && columns.length > 0 && rows.length > 0 && Object.keys(defaultColDef).length > 0 && defaultColDef['export']){
        return (<reactbootstrap.Button onClick={() => this.exportXLS()}>{t('Export XLS')}</reactbootstrap.Button>);
      }
    }

    getRows(rows, filters) {
      rows = selectors.getRows({ rows, filters });
      return rows;
    }

    setRows(rows){
      this.setState({rows:rows});
    }

    setFilters(filter){
      let data = ReactDataGridCommonFunc.handleFilterChange(filter,this.state.filters);
      this.setState({filters:data})
    }

    rowGetterFunc(i,filteredRows){
      return filteredRows[i];
    }

    redirectFunc = (id, webform, singleRedirect) =>{
        if (webform) {
           window.location = '/webformaction/' + id + '/1/' + window.COMING_FROM_CASE4_todos + '/0' + '/0' + '/0' + '/0' + '/0' + '/1' + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications');
           // window.open('/webformaction/' + id + '/1/' + window.COMING_FROM_CASE4_todos + '/0' + '/0' + '/0' + '/0' + '/0' + '/1' + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications'),'_blank');
        } else {
          window.location = '/documentview/' + id + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications');
          // window.open('/documentview/' + id + '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications'),'_blank');
        }
    }

    onRowClick = (rowIdx, row) => {
      let id,webform;
      if(rowIdx !== -1 && row !== undefined){
        id = row['id'];
        webform = row['webform'];
        localStorage.setItem('from_simulate',0);
	this.redirectFunc(id, webform, 0);
      }
    }


    async componentDidMount() {
      const { t } = this.state;
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        let data = {
          grid_type : this.state.gridId,
          grid_items_id : this.state.gridItemId,
          tile_id : this.state.tileId,
          p_id : this.state.personId
        }
        if (person_id == this.state.personId) {
            await datasave.service(window.TILE_DETAILS, 'POST', data).then(
              async result => {
                let translatedColumns = ReactDataGridCommonFunc.getTranslatedColumns(result.columnDefs, t);
                let columns = ReactDataGridCommonFunc.orderColumnAccordingToPriority(translatedColumns);
                columns.map(key=>{ key['headerRenderer'] = applyTitleOnCol(key); });
                let sortColdirectObj = await ReactDataGridCommonFunc.getSortColAndSortDirection(columns);
                let originalData = result.rowData;
                let rows =  Object.keys(sortColdirectObj).length > 0 ?
                await ReactDataGridCommonFunc.sortRows(result.rowData, sortColdirectObj['sortColumn'], sortColdirectObj['sortDirection'],
                  originalData, columns, 0, []) : result.rowData;
                let defaultColDef = result.defaultColDef;
                if(defaultColDef['filterable'] !== undefined && defaultColDef['filterable']){
                  await this.grid.onToggleFilter();
                }
		const filters =  ReactDataGridCommonFunc.getFiterAccordingToType(columns);
		const filteredRows = ReactDataGridCommonFunc.getRows(rows, filters);
                if(filteredRows.length === 1){
		filteredRows.map(key=>{ key['id'] !== undefined && key['webform'] !== undefined &&
                  this.redirectFunc(key['id'], key['webform'], 1) });
		}else{
                this.setState({
                    status: true,
                    columns: columns,
                    rows: rows,
                    defaultColDef: defaultColDef,
                    originalData:originalData,
                    filters: filters,
                    responseText:rows.length === 0 ? 'There are no new documents for you.':''
                  })
		}
		})
        } else {
            this.setState({
                responseText: 'Access Denied'
            })
        }
    }
}

export default translate(whatsnew);
