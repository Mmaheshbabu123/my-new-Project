import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { throwStatement } from '@babel/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { translate } from '../language';
import { persistor, store } from '../store';
import ReactDataGrid from "react-data-grid-defaultvalue";
import PopUpModal from './PopUpModal';
import { Editors, Data, Filters,Toolbar } from "react-data-grid-addons-default-filters";
import { OCAlert } from '@opuscapita/react-alerts';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css';
import {ReactDataGridCommonFunc} from './ReactDataGridCommonFunc';
import Pagination from 'react-bootstrap/Pagination';
const selectors = Data.Selectors;
const { NumericFilter, AutoCompleteFilter, MultiSelectFilter, SingleSelectFilter } = Filters;
const getPaginatedRow = (filteredRows, selectedPage, pageDivBy) =>{
          let start = (parseInt(selectedPage) - 1) * parseInt(pageDivBy)
          let end = parseInt(selectedPage) * parseInt(pageDivBy);
          return filteredRows.filter((key, index)=>{  return index >= start && index < end })};
const applyTitleOnCol = (item) =>{ return <span title={item.name}>{item.name}</span>; }

class GroundplanManagementView extends Component {
    grid = {};

    constructor(props) {
        super(props);
        this.state = {
            columns: [],
            rows: [],
            status: false,
            defaultColDef: {},
            filters:{},
            originalData:[],
            gridId: 18,
            gridItemId:this.props.gridItemId,
            //tileId: this.props.match.params.tileid,
            // personId: this.props.personid,
            // ip_id:this.props.ip_id,
            // layer_id:this.props.layer_id,
            // unique_id:this.props.unique_id,
            t: props.t,
            responseText: 'Loading....',
            selectedPage: 1,
            pageDivBy : 10,

	}

        //this.exportXLS = this.exportXLS.bind(this);
    }

   paginate = (number) =>{
     this.setState({selectedPage: number});
   }



    pageFunc = (total, pageDivBy, selectedPage) =>{
          let table = [];
          let resultNumbers = [];
          for(let i = 1 ; i <= Math.ceil(total/pageDivBy); i++){
           resultNumbers.push(i);
          }
          resultNumbers.map(number => {
            table.push(
                <Pagination.Item key={number} id={number} active = { parseInt(number) === parseInt(selectedPage)} onClick={(e) => this.paginate(number)}>{number}</Pagination.Item>
            );
          })
          return table;
    }


    getRows(rows, filters) {
      rows = selectors.getRows({ rows, filters });
      return rows;
    }

    setRows(rows){
      this.setState({rows:rows});
    }

    setFilters(filter){
      let data = ReactDataGridCommonFunc.handleFilterChange(filter,this.state.filters);
      this.setState({filters:data, selectedPage: 1})
    }

    rowGetterFunc(i,filteredRows){
      return filteredRows[i];
    }

   onRowClick = (rowId, row) => {
     this.redirectFunc(row['doc_id']);
   }

    render(){
	    const { t, columns, rows, filters, originalData, status, responseText, selectedPage, pageDivBy} = this.state;
        const filteredRows = ReactDataGridCommonFunc.getRows(rows, filters);
        const filteredRowsPagination = getPaginatedRow(filteredRows, selectedPage, pageDivBy);
localStorage.setItem('prevLocation', window.location.pathname);
    return (
            <div>
              <div className="row justify-content-center">
                <div className='col-md-12 p-0'>
                      {t(responseText)}
                      <ReactDataGrid
                        ref={(grid) => { this.grid = grid; }}
                        columns={columns}
                        rowGetter={i=>this.rowGetterFunc(i, filteredRowsPagination)}
                        rowsCount={filteredRowsPagination.length}
                        onRowClick={(rowId,row)=>this.onRowClick(rowId,row)}
                        onGridSort={(sortColumn, sortDirection) =>this.setRows(
                        ReactDataGridCommonFunc.sortRows(rows,sortColumn,sortDirection,originalData, columns, 1, []))}
                        onAddFilter={filter => this.setFilters(filter)}
                        minHeight={480}
                        getValidFilterValues={columnKey => ReactDataGridCommonFunc.getValidFilterValues(rows, columnKey)}
                      />
               <Pagination style={{ width: '900px', overflow: 'auto',scrollbarWidth: 'thin'}} size="md">
               {this.pageFunc(filteredRows.length, pageDivBy, selectedPage)}
               </Pagination>
                </div>

              </div >
            </div>
          );
}

   redirectFunc = (documentId) =>{
    // let url = 'kpi_report_overview/' + kpi_id;
     window.open('/previewrevisionentities/' + documentId, '_blank')
    // window.open('/kpi_report_overview/' + kpi_id + '/' + kpi_todo_id + '?q=' +window.location.pathname, '_parent');
     // window.open('/webformaction/' + documentId + '/' + webTodoId + '/' + submitId + '/' + currentStepId + '/0' + '/0' + '/0' + '/0' + '/' + blockBoxTodoId + '/0' +  '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications'),'_blank');
    //  window.location = '/webformaction/' + documentId + '/' + webTodoId + '/' + submitId + '/' + currentStepId + '/0' + '/0' + '/0' + '/0' + '/' + blockBoxTodoId + '/0' +  '?q=' + (parseInt(singleRedirect) !== 1 ? window.location.pathname : '/notifications');
   }

    async componentDidMount(){
     await this.getGridData();

  }
  async componentDidUpdate(prevProps, prevState) {
    if(this.props.layer_id !== prevProps.layer_id ) {
      await this.getGridData();
    }
  }
  getGridData = async () => {
    // let Userdata = store.getState();
    // let person_id = Userdata.UserData.user_details.person_id;
    // let formManage = parseInt(this.state.formManage);
    const { t } = this.state;
    let data = {
      grid_type : this.state.gridId,
      grid_items_id : this.props.gridItemId,
      p_id : this.props.personid,
      ip_id:this.props.ip_id,
      layer_id:this.props.layer_id,
      unique_id:this.props.unique_id,
      //tile_id : this.state.tileId,
      // ip_id:this.state.ip_id,
      // layer_id:this.state.layer_id,
      // unique_id:this.state.unique_id,
    }

    //if (person_id == this.state.personId) {
 await datasave.service(window.TILE_DETAILS, 'POST', data).then(
       async result => {
 if (result['status'] == 200) {
 if(result['data']['rowData'] !== undefined && result['data']['rowData'].length > 0){

    let translatedColumns = ReactDataGridCommonFunc.getTranslatedColumns(result['data']['columnDefs'] !== undefined ? result['data']['columnDefs'] : [], t);
          let columns = ReactDataGridCommonFunc.orderColumnAccordingToPriority(translatedColumns);
          columns.map(key=>{ key['headerRenderer'] = applyTitleOnCol(key); });
          let sortColdirectObj = await ReactDataGridCommonFunc.getSortColAndSortDirection(columns);
          let originalData = result['data']['rowData'];
          let rows =  Object.keys(sortColdirectObj).length > 0 ?
          await ReactDataGridCommonFunc.sortRows(result['data']['rowData'], sortColdirectObj['sortColumn'],
      sortColdirectObj['sortDirection'], originalData, columns, 0, []) :
          result['data']['rowData'];
          let defaultColDef = result['data']['defaultColDef'];
          if(Object.keys(defaultColDef).length > 0 && defaultColDef['filterable'] && !this.state.status){
            await this.grid.onToggleFilter();
          }
    const filters = ReactDataGridCommonFunc.getFiterAccordingToType(columns);
        //  const filteredRows = ReactDataGridCommonFunc.getRows(rows, filters);
          // if(filteredRows.length === 1) {
          //   filteredRows.map(key=>{
          //     this.redirectFunc(key['doc_id']);
          //   });
          // } else {
            this.setState({
              status: true,
        responseText: rows.length === 0 ? "There are no Groundplan docs open  for you": '',
              columns: columns,
              rows: rows,
              defaultColDef: defaultColDef,
              originalData:originalData,
              layer_id:this.props.layer_id,
              filters: filters
            })
          //}
 }else{
 this.setState({
   status: true,
   columns: [],
   rows: [],
   defaultColDef: {},
   filters:{},
   originalData:[],
   responseText: "There are no more Groundplan docs for you"
 });
 }
}else{
this.setState({ status: true, responseText: 'Error please try again!' })
}
 });
// }else {
//           this.setState({
//               responseText: 'Access Denied'
//           })
//       }
}

}
export default translate(GroundplanManagementView);
