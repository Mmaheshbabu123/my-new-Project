import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Pagination from 'react-bootstrap/Pagination'
import { constants } from 'fs';
import './LayoutLinkedDocs.css';
import {translate} from '../language';


class LayoutLinkedDocs extends Component {
    constructor(props) {
        super(props)
        this.state = {
            layout_linked_docs: [],
            todosPerPage: 5,
            currentPage: 1,
            active: 1,
            count: 0,
            items: [],
            page: 5,
            t:props.t,
        }
    }
    getPageData(id, list = '') {


        const page = this.state.page;
        const items = (list !== '') ? list : this.state.layout_linked_docs;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;

    }
    componentDidMount() {
        var url = window.GET_LAYOUT_LINKED_DOCS + '/' + this.props.data;
        datasave.service(url, "GET")
            .then(response => {
                const pageData = this.getPageData(1, response);
                const count = this.getCountPage(response);
                this.setState({ layout_linked_docs: response, count: count, items: pageData, });
            });
    }
    componentDidUpdate(prevProps, prevState) {

        if (this.props.data !== prevProps.data){
            var url = window.GET_LAYOUT_LINKED_DOCS+'/'+this.props.data;
            datasave.service(url, "GET")
            .then(response => {
                const pageData = this.getPageData(1, response);
                const count = this.getCountPage(response);
                this.setState({layout_linked_docs:response,count: count,items: pageData, active:1});
            });
            }
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }

    changePage(e, id = 1) {
        // const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const list = this.state.LayoutLinkedDocs;
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });
    }

    render() {
        const { layout_linked_docs,t } = this.state
        const items = this.state.items;
        const layouts = items.map(function (data) {
            return (

                <tr key={data.key}>
                    <td>{data.dname}</td>
                    <td>{data.dcode}</td>
                    <td>{data.version}</td>
                    <td>{data.fname}</td>
                    <td>{data.fcode}</td>
                    <td>{data.mname}</td>
                </tr>
            )
        });

        let active = this.state.active;
        let pages = [];
        if (this.state.count > 0)
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }



        return (
            <div >
                <reactbootstrap.Table striped bordered hover variant="dark" >
                    <thead className="layoutlinked-header">
                        <tr>
                            <th>{t('Document name')}</th>
                            <th>{t('Document code')}</th>
                            <th>{t('Document version')}</th>
                            <th>{t('Folder')}</th>
                            <th>{t('Folder code')}</th>
                            <th>{t('Manual')}</th>
                        </tr>
                    </thead>
                    <tbody className="layoutlinked-body">
                        {layouts}

                    </tbody>

                </reactbootstrap.Table>
                <div style={{ textAlign: 'center' }} className="mt-3">
                    {layout_linked_docs.length == 0 && <span className=" records ext-center" >{t('No records found')}'</span>}
                </div>
                <div className='text-center' style={{ width: '50%', overflowX: 'auto' }}>
                    {pages.length > 1 && <Pagination size="md" active={this.state.active}>{pages}</Pagination>}
                </div>
            </div>
        );
    }
}
export default translate(LayoutLinkedDocs);
