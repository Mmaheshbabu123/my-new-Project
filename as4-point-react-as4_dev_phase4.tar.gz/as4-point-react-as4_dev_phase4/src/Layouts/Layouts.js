import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap';
import { Tabs, Tab } from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import '../Organisations.css';
import { translate } from '../language';
import Can from '../_components/CanComponent/Can';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { PagePermissions } from '../_components/CanComponent/PagePermissions';

class Layouts extends Component {
  constructor(props) {
    super(props)
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.state = {
      name: '',
      showError: '',
      revision_id: 1,
      header_id: '',
      header_typeid: '',
      header_details: [],
      body_id: '',
      body_details: [],
      footer_id: '',
      footer_details: [],
      edit_img: '',
      is_visible: true,
      is_system: true,
      logo: [],
      checked: true,
      description: '',
      submitted: false,
      loading: false,
      name_error: '',
      Header_error: '',
      code: '',
      status: 1,
      key: 1,
      url: '',
      file_name: 'Choose File',
      link_details: [],
      records: [],
      t: props.t,
      header_error: '',
      footer_error: ''
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleCancel = this.handleCancel.bind(this)
  }

  handleCancel(event) {
    this.props.updateComponent(1);
  }

  handleSubmit(event) {
    const layoutId = this.props.id;
    event.preventDefault();
    this.setState({ submitted: true });
    const { history } = this.props

    var header = this.state.header_details;
    var body = this.state.body_details;
    var footer = this.state.footer_details;
    var body_id = this.state.body_id;
    var header_id = this.state.header_id;
    var footer_id = this.state.footer_id;
    const records = this.state.records;
    header.filter(function (i, key) {
      if (i.id == header_id) {
        records.push({
          category_id: 1,
          template_id: header_id,
        });
      }
    });
    body.filter(function (i, key) {
      if (i.id == body_id) {
        records.push({
          category_id: 2,
          template_id: body_id,
        });
      }
    });
    footer.filter(function (i, key) {
      if (i.id == footer_id) {
        records.push({
          category_id: 3,
          template_id: footer_id,
        });
      }
    });
    const details = {
      name: this.state.name,
      header_id: this.state.header_id,
      body_id: this.state.body_id,
      footer_id: this.state.footer_id,
      records: this.state.records
    }
    if (layoutId) {
      if (this.validate()) {
        const id = this.props.id;
        const url = window.SHOW_LAYOUTS + '/' + this.props.id;
        datasave.service(url, 'PUT', details)
          .then(response => {
            if (response.name) {
              this.setState({
                name_error: response.name

              })
            }
            else if (response === 1) {
              // history.push('/managelayouts')
              this.props.updateComponent(1);

            }
          })
      }
    }
    else {
      if (this.validate()) {
        datasave.service(window.INSERT_LAYOUTS, 'POST', details)
          .then(response => {
            if (response.name) {
              this.setState({
                name_error: response.name
              })
            }
            else if (response === 1) {
              //  history.push('/managelayouts')
              this.props.updateComponent(1);
            }
          })
      }
      else {
        this.setState({
          showError: true
        })
      }
    }
  }

  validate() {
    var name_valid = this.state.name.replace(/\s+/g, ' ').trim();
    let formIsValid;
    const { t } = this.state;
    var require_error1 = t('Layout name is required field');
    var header_error1 = t('Template header is required field');
    var footer_error1 = t('Template footer is required field');

    if (name_valid === '' && this.state.header_id === '' && this.state.footer_id === '') {

      formIsValid = false;
      this.setState({ require_error: require_error1, header_error: header_error1, footer_error: footer_error1 })
    }
    else if (name_valid === '' && this.state.header_id !== '' && this.state.footer_id !== '') {

      formIsValid = false;
      this.setState({ require_error: require_error1 })
    }
    else if (name_valid === '' && this.state.header_id === '' && this.state.footer_id !== '') {

      formIsValid = false;
      this.setState({ require_error: require_error1, header_error: header_error1 })
    }
    else if (name_valid === '' && this.state.header_id !== '' && this.state.footer_id === '') {

      formIsValid = false;
      this.setState({ require_error: require_error1, footer_error: footer_error1 })
    }
    else if (name_valid !== '' && this.state.header_id === '' && this.state.footer_id === '') {

      formIsValid = false;
      this.setState({ header_error: header_error1, footer_error: footer_error1 })
    }
    else if (name_valid !== '' && this.state.header_id === '' && this.state.footer_id !== '') {

      formIsValid = false;
      this.setState({ header_error: header_error1 })
    }
    else if (name_valid !== '' && this.state.header_id !== '' && this.state.footer_id === '') {

      formIsValid = false;
      this.setState({ footer_error: footer_error1 })
    }
    else {
      formIsValid = true;
    }

    return formIsValid;
  }
  componentWillReceiveProps() {

    if (this.props.id === undefined) {
      this.setState({
        require_error: '',
        name_error: '',
        header_error: '',
        footer_error: ''
      })
    }
  }
  componentDidUpdate(prevProps, prevState) {
    if (this.props.id !== '' && prevProps.id !== this.props.id) {
      if (this.props.id !== undefined) {
        const get_templates_url = window.SHOW_LAYOUTS + '/' + this.props.id;
        datasave.service(get_templates_url, 'GET', '')
          .then(response => {
            this.setState({
              name: response.all[0]['name'],
              header_id: response.header_id[0] ? response.header_id[0]['template_id'] : this.state.header_id,
              body_id: response.body_id[0] ? response.body_id[0]['template_id'] : this.state.body_id,
              footer_id: response.footer_id[0] ? response.footer_id[0]['template_id'] : this.state.footer_id,
              key: 1,
              require_error: '',
              name_error: '',
              header_error: '',
              footer_error: ''
            })
            if (response.header_id[0] == undefined && response.body_id[0] == undefined && response.footer_id[0] == undefined) {
              this.setState({
                header_id: '', body_id: '', footer_id: '', require_error: '', name_error: ''
              })
            }
            if (response.header_id[0] == undefined && response.body_id[0] == undefined) {
              this.setState({
                header_id: '', body_id: '', require_error: '', name_error: ''
              })
            }
            if (response.body_id[0] == undefined && response.footer_id[0] == undefined) {
              this.setState({
                body_id: '', footer_id: '', require_error: '', name_error: ''
              })
            }
            if (response.footer_id[0] == undefined && response.header_id[0] == undefined) {
              this.setState({
                footer_id: '', header_id: '', require_error: '', name_error: ''
              })
            }
            if (response.header_id[0] == undefined) {
              this.setState({
                header_id: '', require_error: '', name_error: ''
              })
            }

          })
      } else {

        this.setState({
          name: '', header_id: '', body_id: '', footer_id: '', key: 1, require_error: '',
          name_error: '',
          header_error: '',
          footer_error: ''
        })
      }
    }


  }
  componentDidMount() {

    const layoutId = this.props.id;
    var url = window.GET_LAYOUTS_TEMPLATES;
    datasave.service(url, "GET")
      .then(response => {
        this.setState({
          header_details: response['header'],
          body_details: response['body'],
          footer_details: response['footer'],
        })
      })
    if (layoutId) {
      const get_templates_url = window.SHOW_LAYOUTS + '/' + this.props.id;
      datasave.service(get_templates_url, 'GET', '')
        .then(response => {
          this.setState({
            name: response.all[0]['name'],
            header_id: response.header_id[0] ? response.header_id[0]['template_id'] : this.state.header_id,
            body_id: response.body_id[0] ? response.body_id[0]['template_id'] : this.state.body_id,
            footer_id: response.footer_id[0] ? response.footer_id[0]['template_id'] : this.state.footer_id,

          })
        })
    }
  }
  handleSelect(selectedTab) {
    // The active tab must be set into the state so that
    // the Tabs component knows about the change and re-renders.
    this.setState({
      key: selectedTab
    });
  }
  handleChange(event) {
    const { name, value } = event.target
    const { t } = this.state;
    this.setState({ [name]: value })
    if (event.target.value == '') {
      this.setState({ require_error: t('Layout name is required field'), name_error: '' })
    } else {

      this.setState({ name_error: '', require_error: '' })
    }
  }
  render() {
    const as4_or_site = 1;//PagePermissions()
    const layout_details = CanPermissions("R_layout,E_layout", "");
    const template_details = CanPermissions("R_template,E_template", "");
    let layout_details_disabled = (layout_details) ? '' : 'disabled';
    let template_details_disabled = (template_details) ? '' : 'disabled';

    const { name, submitted, header_id, header_typeid, body_id, showError, footer_id, loading, is_visible, is_system, error, name_error, require_error, header_error, footer_error } = this.state;
    const { activedepartmentsdata, t } = this.state
    const { inactivedepartmentsdata } = this.state

    if (as4_or_site) {
      return (
        <div className='container' >
          <Can
            perform="E_layout"
            yes={() => (
              <div className='row justify-content-center' >
                <div className='col-md-9' >
                  <div className='job_list'>
                    <div className='card'>
                    <div className='card-header' > {t('Create layout')} </div>
                      <div className='card-body pb-0'>
                        <Tabs activeKey={this.state.key} onSelect={this.handleSelect} id="controlled-tab-example">
                          <Tab disabled={layout_details_disabled} eventKey={1} title={t("Layout details")}>
                            <div className='card-body pb-0'>

                              <reactbootstrap.Form >
                                <reactbootstrap.FormGroup>
                                  <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
                                    <div className=" row input-overall-sec ">
                                      <reactbootstrap.InputGroup className="">
                                        <div className="col-md-4">
                                          <reactbootstrap.InputGroup.Prepend>
                                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Name:')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                                          </reactbootstrap.InputGroup.Prepend>
                                        </div>
                                        <div class="col-md-8 input-padd">
                                          <reactbootstrap.FormControl
                                            name="name"
                                            placeholder={t("Layout name")}
                                            aria-label="Layout name"
                                            aria-describedby="basic-addon1"
                                            value={name}
                                            onChange={this.handleChange}
                                            className="input_sw "
                                          />
                                          <div style={{ color: 'red' }} className="error-block mt-2">{name_error}</div>
                                          <div style={{ color: 'red' }} className="error-block mt-2">{require_error}</div>
                                        </div>
                                      </reactbootstrap.InputGroup>


                                    </div>
                                  </div>
                                </reactbootstrap.FormGroup>
                              </reactbootstrap.Form>
                            </div>
                          </Tab>
                          <Tab disabled={template_details_disabled} eventKey={2} title={t("Template details")}>
                            <div className='card-body pb-0'>
                              <reactbootstrap.FormGroup>
                                <div className=" row input-overall-sec ">
                                  <reactbootstrap.InputGroup className="">
                                    <div className="col-md-4">
                                      <reactbootstrap.InputGroup.Prepend>
                                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Header:')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                                      </reactbootstrap.InputGroup.Prepend>
                                    </div>
                                    <div class="col-md-8 p-0">
                                      <div className="input_sw ">
                                        <reactbootstrap.Form.Control as="select" name="package_id"
                                          value={this.state.header_id}
                                          onChange={e => this.setState({ header_id: e.target.value, header_typeid: e.target.value1, header_error: '' })} >
                                          <option value=''>{t('Select')}</option>
                                          {this.state.header_details.map(header => <option value1={header.id} value={header.id}>{header.name}</option>)}
                                        </reactbootstrap.Form.Control>
                                      </div>
                                      <div style={{ color: 'red' }} className="error-block mt-2">{header_error}</div>
                                    </div>
                                  </reactbootstrap.InputGroup>
                                </div>

                              </reactbootstrap.FormGroup>
                              <reactbootstrap.FormGroup>
                                <div className=" row input-overall-sec ">
                                  <reactbootstrap.InputGroup className="">
                                    <div className="col-md-4">
                                      <reactbootstrap.InputGroup.Prepend>
                                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Body:')}</reactbootstrap.InputGroup>
                                      </reactbootstrap.InputGroup.Prepend>
                                    </div>
                                    <div class="col-md-8 p-0">
                                      <div className="input_sw ">
                                        <reactbootstrap.Form.Control as="select" name="package_id"
                                          value={this.state.body_id}
                                          onChange={e => this.setState({ body_id: e.target.value })} >
                                          <option value=''>{t('Select')}</option>
                                          {this.state.body_details.map(body => <option value={body.id}>{body.name}</option>)}
                                        </reactbootstrap.Form.Control>
                                      </div>
                                    </div>
                                  </reactbootstrap.InputGroup>
                                </div>
                              </reactbootstrap.FormGroup>

                              <reactbootstrap.FormGroup>
                                <div className=" row input-overall-sec ">
                                  <reactbootstrap.InputGroup className="">
                                    <div className="col-md-4">
                                      <reactbootstrap.InputGroup.Prepend>
                                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Footer:')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                                      </reactbootstrap.InputGroup.Prepend>
                                    </div>
                                    <div class="col-md-8 p-0 ">
                                      <div className="input_sw ">
                                        <reactbootstrap.Form.Control as="select" name="package_id"
                                          value={this.state.footer_id}
                                          onChange={e => this.setState({ footer_id: e.target.value, footer_error: '' })} >
                                          <option className="layout-option" value=''>{t('Select')}</option>
                                          {this.state.footer_details.map(footer => <option className="layout-option" value={footer.id}>{footer.name}</option>)}
                                        </reactbootstrap.Form.Control>
                                      </div>
                                      <div style={{ color: 'red' }} className="error-block mt-2">{footer_error}</div>
                                    </div>
                                  </reactbootstrap.InputGroup>
                                </div>

                              </reactbootstrap.FormGroup>

                            </div>
                          </Tab>
                        </Tabs>
                        <reactbootstrap.FormGroup className="mb-0 p-2">
                          <div style={{ textAlign: 'right' }} className="form-group mb-0">
                            <a onClick={this.handleCancel} > {t('Cancel')} </a>
                            &nbsp;&nbsp;&nbsp;
                          <reactbootstrap.Button style={{ fontSize: '14px' }} type="submit" className="btn btn-primary" onClick={this.handleSubmit} disabled={loading}>{t('Save')}</reactbootstrap.Button>
                            {loading &&
                              <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                            }


                          </div>
                        </reactbootstrap.FormGroup>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            no={() =>
              <AccessDeniedPage />
            }
          />
        </div>
      );
    }
    else {
      return (
        <AccessDeniedPage />
      )
    }
  }
}
export default translate(Layouts);
