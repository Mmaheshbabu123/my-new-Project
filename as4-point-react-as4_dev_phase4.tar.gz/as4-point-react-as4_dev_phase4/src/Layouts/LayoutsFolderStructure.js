import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import TreeMenu from 'react-simple-tree-menu'
import renderhtml from 'react-render-html';
import { datasave } from '../_services/db_services';
import FolderStructure from '../Folder/Folder';
import documentlogo from '../Space/document.png';
import folderlogo from '../Space/folder-icon.png';
import manageunlink from '../Space/manage-unlink.png';
import managelink from '../Space/manage-link.png';
import {translate} from '../language';

import { Button, Container, Form, FormGroup, Input, Label, ListGroup, ListGroupItem } from 'reactstrap';
import { objectExpression } from '@babel/types';

class LayoutsFolderStructure extends Component {
    constructor(props) {
        super(props)
        this.state = {
            blanco_data: {},
            testdata: "testdata",
            showDocHeader: false,
            showFolder: false,
            credentials: {},
            update: 1,
            lnk_ulnk_status:'',
            manualtabkey: '',
            manual_data:'',
            count:[],
            tag:'',
            layout_id:'',
            doc_id:'',
            t:props.t,
            ayout_linked_docs:'',
            unique_manual_data:'',
            alert:'false'
        }

    }


    componentDidMount() {
        var url = window.GET_UNIQUE_Manuals + '/' + this.props.data;
        datasave.service(url, 'GET', this.props.data)
        .then(response => {
            if(response.length === 0){
                this.props.status(false)
                 this.setState({alert : 'true'});
            }else{
                this.getDocsPerManual(response)
                this.props.status(true)
            }
        }
      )
    }
    componentDidUpdate(prevProps, prevState) {
        if(this.props.data !== prevProps.data  || this.state.manualtabkey !== prevState.manualtabkey ){
            var url = window.GET_UNIQUE_Manuals + '/' + this.props.data;
            datasave.service(url, 'GET', this.props.data)
            .then(response => {
                if(response.length === 0){
                    this.props.status(false)
                     this.setState({alert : 'true'});
                }else{
                    this.getDocsPerManual(response)
                    this.props.status(true)
                }

               }
            )
        }

    }
    getDocsPerManual(unique_manual_data){
            if(this.state.manualtabkey === '' && unique_manual_data.length !== 0 )
            {
                var  manualtabkey = Object.values(unique_manual_data)[0].mid
                var url = window.GET_LAYOUT_LINKED_MANUAL_DOCS + '/' + this.props.data+'/'+manualtabkey;
                datasave.service(url, 'GET', this.props.data)
                .then(response => {
                        this.setState({  manual_data: response,
                                         unique_manual_data:unique_manual_data,
                                         manualtabkey:unique_manual_data[0].mid
                        })
                    }
            )
            }else{
                var url1 = window.GET_LAYOUT_LINKED_MANUAL_DOCS + '/' + this.props.data+'/'+this.state.manualtabkey;
                datasave.service(url1, 'GET', this.props.data)
                .then(response => {
                        this.setState({  manual_data: response,
                                        unique_manual_data:unique_manual_data,
                        })
                    }
                )
            }

    }



    render() {

        const {t,manual,unique_manual_data,alert} = this.state;
        var i = -1;

        const data = Object.values(this.state.manual_data).map(function(data, key){
            return(
                <tr >
                <td>{data.dname}</td>
                <td>{data.dcode}</td>
                <td>{data.version}</td>
                <td>{data.fname}</td>
                <td>{data.fcode}</td>
                </tr>
            )
            })



        return (
        <div className="container">
        <div className="row">
            <div className="col-lg-12 p-0">

            <reactbootstrap.Tabs
                id="controlled-tab-example" className="header_tabs"
                 activeKey={this.state.manualtabkey}

                onSelect={manualtabkey => this.setState({ manualtabkey })}
            >

                {
                            Object.values(this.state.unique_manual_data).map(function(values,key) {
                            return (
                            <reactbootstrap.Tab eventKey = {values.mid} title={values.mname}>
                            <div><br/>
                            <div style={{'height': '200px','overflowY': 'auto'}}>
                            <reactbootstrap.Table striped bordered hover>
                                    <thead>
                                        <tr>
                                        <th>{t("Document name")}</th>
                                        <th>{t("Document code")}</th>
                                        <th>{t("Document version")}</th>
                                        <th>{t("Folder")}r</th>
                                        <th>{t("Folder code")}</th>
                                        </tr>
                                    </thead>
                                    <tbody >
                                    {data}
                                    </tbody>
                            </reactbootstrap.Table>
                            </div>
                            </div>
                            </reactbootstrap.Tab>
                        )}, this)
                        }
            </reactbootstrap.Tabs>
            { this.state.manual_data.length === 0 && <span className=" alert text-center">{t('No records found')}</span>}

            </div>
            </div>
            </div >
                );
        }
}

export default translate(LayoutsFolderStructure)
