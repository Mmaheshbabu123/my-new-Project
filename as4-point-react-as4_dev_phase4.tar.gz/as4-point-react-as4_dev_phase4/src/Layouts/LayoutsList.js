import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Layouts from '../Layouts/Layouts';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { translate } from '../language';
import { PagePermissions } from '../_components/CanComponent/PagePermissions';
import Pagination from 'react-bootstrap/Pagination'
import LayoutsFolderStructure from '../Layouts/LayoutsFolderStructure';
import LayoutLinkedDocs from '../Layouts/LayoutLinkedDocs';
import './LayoutsList.css'

//import { threadId } from 'worker_threads';

const KEYS_TO_FILTERS = ['name', 'id']
class LayoutsList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            component: 'true',
            componentState:'',
            layouts: [],
            active: 1,
            searchTerm: '',
            page: 5,
            items: [],
            _1stLayout: undefined,
            fcurrentPage: 1,
            mcurrentPage: 1,
            scurrentPage: 1,
            currentPage: 1,
            tabId: '',
            id: '',
            count: 0,
            filterFullList: [],
            t: props.t,
            alert: '',
            falert: '',
            malert: '',
            doc_data: [],
            folder_data: [],
            manual_data: [],
            showpopup: '',
            todosPerPage: 5,
            delBtnStatus:false,

        }
        this.searchData = this.searchData.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.changeComponent = this.changeComponent.bind(this);
    }
    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.layouts;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;

    }
    componentDidMount() {
        const url = window.GET_INSERT_LAYOUTS;
        datasave.service(url, 'GET', '')
            .then(response => {
                const pageData = this.getPageData(this.state.active, response);
                const count = this.getCountPage(response);
                this.setState({
                    layouts: response,
                    count: count,
                    items: pageData,
                    _1stLayout: response[0].id,
                    editBtnStatus: 'true',
                    componentState : 'open',
                    component:'false',

                })
            });
    }
    componentDidUpdate(prevProps, prevState) {

        if (prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
            datasave.service(window.GET_INSERT_LAYOUTS, 'GET', '')
                .then(response => {
                    const pageData = this.getPageData(this.state.active, response);
                    const count = this.getCountPage(response);
                    this.setState({
                        layouts: response,
                        items: pageData,
                        count: count,
                        clone: response,
                        didupdate: 'true',
                        editBtnStatus: 'true',
                        // _1stLayout: response[0].id,
                        _1stLayout:this.state._1stLayout,

                    })
                });

        }
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }

    componentWillMount() {
        this.setState({ items: this.state.layouts, active: 1 })
    }
    searchData(e) {
        var list = [...this.state.layouts];
        list = list.filter(function (item) {
            if (item.name !== null) {
                return item.name.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
        });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    changePage(e, id = 1) {
        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });
    }

    handlehide = () => {
        this.setState(
            { show: false, showlayoutpop: false }
        )
    }
    handleCancel() {
        this.setState(
            { show: false }
        )
    }

    handleDelete(id) {
        // var url = window.GET_LAYOUT_LINKED_DOCS + '/' + id;
        // datasave.service(url, 'GET', id).then(
        //     response => {
        //         this.setState({ doc_data: response, id: id, show: true, alert: '', })
        //         if (this.state.doc_data.length === 0) {
        //             this.setState({ alert: 'true' })
        //         }
        //     }
        // )
        this.setState({ currentPage: 1, mcurrentPage: 1, fcurrentPage: 1, popid: id, show: true, showpopup: 'true', didupdate: 'true',_1stLayout:id })
    }

    updateComponent(e) {
        if (e) {
            this.componentDidMount();
            this.setState({
                component: 'false',
                saveComponent: 1,
            })
        }
        this.props.tab(false);
    }
    update(e) {
        if (e !== this.state.tabId) {
            this.setState({
                tabId: e,
            });
        }
    }

    changeComponent(e, id) {
        this.setState({
            component: 'true',
            formId: (id !== '') ? id : '',
            editBtnStatus: 'false'

        });
        this.props.tab(true);
    }
    handlepopok() {
        this.setState({ didupdate: '1' })
        const { popid, doc_data } = this.state;

        const url = window.DELETE_LAYOUT_DATA + popid;
        datasave.service(url, 'put').then(
            response => {
                if(response === 'sucess')
                {
                   this.componentDidMount();
                }

            if (this.state.items.length - 1 == 0) {
                this.state.active = this.state.active - 1;
            }
        }
        )
        this.setState({ show: false, showpopup: '' })
    }

    handleLayoutClick(layoutid) {

        this.setState({
            // showlayoutpop: true,
            // layoutpop: layoutid,
            _1stLayout: layoutid,
            component: false,
        })
    }
    // handlespaceClickOK() {
    //     this.setState({ showlayoutpop: false, layoutpop: '' })
    // }

    updateComponentCancel(e) {

        if (e) {

            this.setState({
                component: 'false',
                saveComponent: 1,
            })
        }
    }
    handlePageClick(event) {
        this.setState({
            currentPage: Number(event.target.id)
        });
    }
    deleteBtnStatus(status){
        this.setState({delBtnStatus:status})
    }



    render() {
        const as4_or_site = 1;//PagePermissions()
        const { layouts, doc_data, folder_data, manual_data, currentPage, todosPerPage, fcurrentPage, mcurrentPage, falert, malert, alert, showpopup, t, folders,alert1 } = this.state;
        const indexOfLastTodo = currentPage * todosPerPage;
        const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
        // const currentTodos = this.state.doc_data.slice(indexOfFirstTodo, indexOfLastTodo);
        // const pagerender = currentTodos.map(doc_data => {
        //     return <tr >
        //         <td>{doc_data.dname}</td>
        //         <td>{doc_data.dcode}</td>
        //         <td>{doc_data.version}</td>
        //         <td>{doc_data.fname}</td>
        //         <td>{doc_data.fcode}</td>
        //         <td>{doc_data.mname}</td>
        //     </tr>
        // });


        // let active = this.state.active;
        const pageNumbers = [];
        for (let i = 1; i <= Math.ceil(doc_data.length / todosPerPage); i++) {
            pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
                {i}
            </Pagination.Item>);
        }

        // const popup = (
        //     <reactbootstrap.Modal
        //         size="lg"
        //         show={this.state.show}
        //         onHide={this.handlehide}
        //         dialogClassName="modal-90w"
        //         aria-labelledby="example-custom-modal-styling-title">
        //         <reactbootstrap.Modal.Header closeButton>
        //             <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
        //             </reactbootstrap.Modal.Title>
        //             <reactbootstrap.Modal.Body >
        //                 <div className="col-md-12">
        //                         <reactbootstrap.Table striped bordered hover variant="dark">
        //                             <thead>
        //                                 <tr>
        //                                     <td>Document </td>
        //                                     <td>Document Code</td>
        //                                     <td>Document Version</td>
        //                                     <td>Folder  </td>
        //                                     <td>Folder Code</td>
        //                                     <td>Manual</td>
        //                                 </tr>
        //                             </thead>
        //                             <tbody>

        //                                  {pagerender}
        //                            </tbody>
        //                         </reactbootstrap.Table>
        //                         {alert == 'true' && <span className=" alert text-center">No Records!</span>}
        //                        <div  className="colo-md-12">
        //                         <Pagination style={{width: '50%', overflowX: 'auto'}} size="sm">{pageNumbers}</Pagination>
        //                         </div>
        //                         </div>
        //             </reactbootstrap.Modal.Body>
        //         </reactbootstrap.Modal.Header>
        //         <reactbootstrap.Modal.Footer>
        //             <reactbootstrap.Button onClick={() => this.handleCancel()}>Cancel</reactbootstrap.Button>
        //             &nbsp;&nbsp; &nbsp;&nbsp;
        //         <reactbootstrap.Button onClick={() => this.handlepopok()}>Delete</reactbootstrap.Button>
        //         </reactbootstrap.Modal.Footer>
        //     </reactbootstrap.Modal>
        // );


        const popup = (
            <reactbootstrap.Modal
                size="lg md"
                className=""
                show={this.state.show}
                onHide={this.handlehide}
                dialogClassName="modal-90w layout-popup"
                aria-labelledby="example-custom-modal-styling-title"

                >
                <reactbootstrap.Modal.Header closeButton >
                    <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                    </reactbootstrap.Modal.Title>
                    <reactbootstrap.Modal.Body className="col-md-12 col-lg-12" style={{padding: '0px'}} >
                        <div className="col-md-12 pr-0">
                                <reactbootstrap.Table >

                                    <tbody>
                                      <LayoutsFolderStructure data={this.state._1stLayout} status={this.deleteBtnStatus.bind(this)} />
                                   </tbody>
                                </reactbootstrap.Table>
                                {alert == 'true' && <span className=" alert text-center">{t('No records found')}</span>}
                               <div  className="colo-md-12">
                                <Pagination style={{width: '300px', overflow: 'auto'}} size="sm">{pageNumbers}</Pagination>
                                </div>
                                </div>
                    </reactbootstrap.Modal.Body>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button onClick={() => this.handleCancel()}>{t('Cancel')}</reactbootstrap.Button>
                    &nbsp;&nbsp; &nbsp;&nbsp;
                {this.state.delBtnStatus === false && <reactbootstrap.Button onClick={() => this.handlepopok()}>{t('Delete')}</reactbootstrap.Button>}
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );



        const filtered = this.state.items;
        // const layoutsdata = filtered.map(layouts => {
        //     let className = (layouts.id === this.state._1stLayout) ? 'active' : 'inactive';

        //     return <tr >
        //             <td className={className} style={{ hover: 'color:#007bf8', cursor: "pointer", }}  ><p  onClick={(e) => this.handleLayoutClick(layouts.id)} >{layouts.name} </p></td>
        //             <td style={{display: 'flex'}} className={className}>
        //             <Can
        //                 perform = "E_layout"
        //                 yes = {() => (
        //                   <p style={{ color: "#007bf8", cursor: "pointer" }} className={className} onClick={(e) => this.changeComponent(e, layouts.id,'edit')} >
        //                   {/* {t('Edit')} */}
        //                   <i title="Edit" class="overall-sprite overall-sprite-myeditc"></i>
        //                   </p>
        //                 )}
        //             />
        //               { this.state.editBtnStatus === 'true' &&
        //                   <Can
        //                       perform = "D_layout"
        //                       yes = {() => (
        //                           <p style={{ color: "#007bf8", cursor: "pointer" }} className={className} onClick={() => this.handleDelete(layouts.id)}>
        //                             {/* {t('Delete')} */}
        //                             <i title="Delete" class="overall-sprite overall-sprite-mtdeletec"></i>
        //                           </p>
        //                       )}
        //                   />
        //               }
        //             </td>
        //         </tr>
        //     })


        let active = this.state.active;
        let pages = [];
        if (this.state.count > 0) {
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }
        }

        if (as4_or_site) {
            return (
                <Can
                    perform="E_layout,R_layout,D_layout"
                    yes={() => (
                        <div className='container py-4'>
                            <div className="row" >
                                {showpopup && popup}
                                <reactbootstrap.Col lg={4} className="pl-0">
                                {/*<div>
                                <h3 className="">{t('Layouts')}</h3>
                                </div>
                                <hr></hr>*/}
                                    <div style={{display: 'flex'}} >
                                      <input  className="form-control search-box-border  mb-2" Placeholder={t("What are you looking for ?")} onChange={this.searchData} /><br />
                                      <reactbootstrap.Button variant="link">
                                          <Can
                                              perform="E_layout"
                                              yes={() => (
                                                  <i title={t("Add Layout")} onClick={(e) => this.changeComponent(e)} class="overall-sprite overall-sprite-layoutc"></i>
                                              )}
                                          />
                                      </reactbootstrap.Button><br />
                                    </div>
                                    <div className='card'>
                                        <reactbootstrap.Table style={{ marginBottom: '0px' }} responsive bordered hover className="main-data-table">
                                            <thead>
                                                <tr style={{backgroundColor: '#EC661C', color: '#fff'}}>
                                                    <th>{t('Layout')}</th>
                                                    {/* <th></th> */}
                                                    <th>{t('Actions')}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {layouts.length == 0 && <div>{t('No records found')}</div>}
                                                {/* {layoutsdata} */}
                                                {filtered.map(layouts => {
                                                    let className = (layouts.id === this.state._1stLayout) ? 'active' : 'inactive';

                                                    return (<tr style={{}} >
                                                        <td className={className} style={{ hover: 'color:#007bf8', cursor: "pointer", }}  ><p style={{ margin: '0px' }} onClick={(e) => this.handleLayoutClick(layouts.id)} >{layouts.name} </p></td>
                                                        <td style={{}} className={className}>
                                                            <div style={{ display: 'flex' }} className="">
                                                                <div style={{ alignSelf: 'center', marginRight: '1rem' }} ClassName="">
                                                                    <Can
                                                                        perform="E_layout"
                                                                        yes={() => (
                                                                            <p style={{ color: "#007bf8", cursor: "pointer", margin: '0px' }} className={className} onClick={(e) => this.changeComponent(e, layouts.id, 'edit')} >
                                                                                {/* {t('Edit')} */}
                                                                                <i title={t("Edit")} class="overall-sprite overall-sprite-myeditc"></i>
                                                                            </p>
                                                                        )}
                                                                    />
                                                                </div>

                                                                {this.state.editBtnStatus === 'true' &&
                                                                    <div style={{ alignSelf: 'center' }} ClassName="">
                                                                        <Can
                                                                            perform="D_layout"
                                                                            yes={() => (
                                                                                <p style={{ color: "#007bf8", cursor: "pointer", margin: '0px' }} className={className} onClick={() => this.handleDelete(layouts.id)}>
                                                                                    {/* {t('Delete')} */}
                                                                                    <i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec"></i>
                                                                                </p>
                                                                            )}
                                                                        />
                                                                    </div>
                                                                }
                                                            </div>
                                                        </td>

                                                    </tr>
                                                    )
                                                })
                                                }

                                            </tbody>
                                        </reactbootstrap.Table>
                                    </div>
                                    <div className='text-center mt-3'  style={{width: '97%', overflowX: 'auto'}}>
                                        {pages.length > 1 && <Pagination size="md">{pages}</Pagination>}
                                    </div>
                                </reactbootstrap.Col>
                                {this.state.component === 'true' && <reactbootstrap.Col lg={8}> {/*<h3 style={{textAlign: 'center'}}>{t('Create Layout')} </h3>*/}<Layouts updateComponent={this.updateComponent.bind(this)}  updateComponentCancel={this.updateComponentCancel.bind(this)} id={this.state.formId} /></reactbootstrap.Col>}
                                {this.state.component !== 'true' && <reactbootstrap.Col lg={8}> {/*<h3 className="">{t('Layout details')}</h3><hr />*/}<LayoutLinkedDocs update={this.update.bind(this)}  data={this.state._1stLayout}  /></reactbootstrap.Col>}
                                {/* {this.state.componentState === 'open' && <reactbootstrap.Col lg={8}> <h3 className="">{t('Layouts Details')}</h3><hr /><LayoutsFolderStructure update={this.update.bind(this)} data={this.state._1stLayout} tabId={this.state.tabId}/></reactbootstrap.Col>} */}

                            </div>
                        </div>
                    )}
                    no={() =>
                        <AccessDeniedPage />
                    }
                />
            );
        }
        else {
            return (
                <AccessDeniedPage />
            )
        }
    }
}

export default translate(LayoutsList);


{/* <i class="overall-sprite overall-sprite-layoutc"></i>
<i class="overall-sprite overall-sprite-layoutcc"></i>
<i class="layout-template layout-template-template"></i>
<i class="layout-template layout-template-templatec"></i> */}
