import React, { Component } from 'react'
import { Container, Input } from 'reactstrap'
import { Button, Form, FormGroup, InputGroup } from 'react-bootstrap'
//import axios from 'axios'
import isEmail from 'validator/lib/isEmail'
import { Tabs, Tab } from 'react-bootstrap'
import time_zone from './timezone.json'
// import DragnDrop from './DragnDrop'
import PJDGdragndrop from './PJDGdragndrop'
import * as reactbootstarp from 'react-bootstrap'
import Pagination from 'react-bootstrap/Pagination'
import { datasave } from './_services/db_services'
import FileUpload from './_components/FileUpload/FileUpload'
import { filterArray } from './_helpers/filter-array'
import Can from './_components/CanComponent/Can';
import { CanPermissions } from './_components/CanComponent/CanPermissions';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import { persistor, store } from './store';
import { translate } from './language';
import todofrequency from './todofrequency.json';
// import SetUserData from './Actions/SetUserData';
// import { connect } from "react-redux";
// import { persistor, store } from './store';
import { OCAlert } from '@opuscapita/react-alerts';
import { PagePermissions } from './_components/CanComponent/PagePermissions';
import * as reactbootstrap from 'react-bootstrap';
import { reducers } from './GroundPlan/Building/Reducers/reducers';

const url = window.backendURL;

class Persons extends Component {
    constructor(props) {
        super(props);
        let userData = store.getState();
        const details_tab_access = CanPermissions("E_user", "");
        this.state = {
            name: '',
            timezone: time_zone[42]['text'],
            address: '',
            zip: '',
            city: '',
            phone: '',
            email: '',
            language_id: 'en',
            password: '',
            old_password: '',
            old_email: '',
            roles: [],
            Dob: '',
            role_id: '',
            sites: '',
            available_in_masterdata: 1,
            active_person: 1,
            image: '',
            file_name: props.t('Choose image'),
            file_id: '',
            jobs: [],
            groups: [],
            departments: [],
            save: 'Save',
            savevalue: 'true',
            showError: '',
            active_tab: (details_tab_access || window.location.href.includes("?myaccount")) ? 1: window.MEMBER_OF,
            dropmemberfunct: [],
            tasks: [],
            timezonelist: time_zone,
            activeTasks: [],
            types: [],
            tabs: [],
            selected: {},
            edit_img: '',
            disableFields: false,
            location: 's3',
            folder: 'profile',
            membersof: {},
            oldname: '',
            persondetails: [],
            currentPage: 1,
            todosPerPage: 5,
            show: false,
            pop: '',
            oldemail: '',
            person_uid: '',
            store_uid: '',
            t: props.t,
            language: [],
            todotext: 1,
            todo: todofrequency,
            todovalue: todofrequency[0]['value'],
            status: '',
            doccycle: '',
            active: '',
            nodata:'',
            password_error: '',
            logedinRoleId: userData.UserData.user_details.role_id,
            as4PersonOrNot: 0,
            removeProfile:false,
            formatWarning:false,
            sizeWarning:false,
            imageError:false,
            action:'Create',
            personId : this.props.match!=undefined?this.props.match.params.id:0,
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleSelect = this.handleSelect.bind(this);
        this.updateSelected = this.updateSelected.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleRemoveProfile = this.handleRemoveProfile.bind(this);
        /*  this.handlefrequencyChange = this.handlefrequencyChange.bind(this);*/
    }

    componentDidUpdate(prevProps, prevState) {
      if (prevProps.uniqueId !== this.props.uniqueId) {
        this.setState({
            name: '',
            email: '',
            password: '',
            Dob: '',
            role_id: '',
            address: '',
            zip: '',
            city: '',
            phone: '',
            selected: [],
        })
      }
    }

    async componentDidMount() {
        let Userdata = store.getState();
        const store_uid = Userdata.UserData.user_details.user_id
        const personId = this.state.personId;
        const {t} = this.state;
        const as4_or_site = PagePermissions();

        if (this.props.handleSelect !== undefined)
            this.props.handleSelect('/managemyorganisation/createperson');

        datasave.service(window.GET_ALL_LANGUAGES, 'GET')
            .then(response => {
                this.setState({
                    language: response
                });
            });
        let rolesURL = window.USERROLES + '/' + this.state.logedinRoleId;
        datasave.service(rolesURL, "GET")
          .then(response => {
            this.setState({
              as4PersonOrNot: response[0] ?  response[0]['as4member'] : 0,
            })
          })

        if (this.state.personId) {
            var url = window.CREATE_PERSON + '/' + personId;
            datasave.service(url, "GET")
                .then(response => {
                  let showRoles = this.state.as4PersonOrNot ? response['roles'] : response['roles'].filter(singleRole => (singleRole.role_type === window.SITE_ROLE));
                    this.setState({
                        person_details: response,
                        name: response['person_details'][0]['name'],
                        clonename: response['person_details'][0]['name'],
                        oldname: response['person_details'][0]['name'],
                        timezone: response['person_details'][0]['timezone'],
                        address: response['person_details'][0]['address'],
                        zip: response['person_details'][0]['zip'],
                        city: response['person_details'][0]['city'],
                        email: response['person_details'][0]['email'],
                        oldemail: response['person_details'][0]['email'],
                        language_id: response['person_details'][0]['language_id'],
                        old_password: response['person_details'][0]['password'],
                        role_id: response['person_details'][0]['role_id'],
                        active_person: response['person_details'][0]['status'],
                        available_in_masterdata: response['person_details'][0]['available_in_masterdata'],
                        Dob: response['person_details'][0]['Dob'],
                        phone: response['person_details'][0]['phone'],
                        user_id: response['person_details'][0]['user_id'],
                        organisation_id: response['person_details'][0]['organisation_id'],
                        file_name: response['person_details'][0]['filename'] ? response['person_details'][0]['filename'][0]['file_name'] : t('Choose image'),
                        removeProfile: response['person_details'][0]['profile_path'] !==t('Choose image') && response['person_details'][0]['profile_path'] !=='' ? true : false,
                        person_uid: response['person_details'][0]['user_id'],
                        selected: response['selected'],
                        todotext: response['person_details'][0]['to_do_frequency'],
                        todovalue: response['person_details'][0]['to_do_frequency_type'],
                        roles: as4_or_site ? response['roles'] : showRoles,
                        items: response['jgd'],
                        tasks: response['jgd'],
                        types: response['types'],
                        tabs: response['tabs'],
                        file_id:response['person_details'][0]['profile_id'],
                        image: (response['person_details'][0]['profile_path'] !== null) ? (response['person_details'][0]['profile_path'].length<1 ? '' : response['person_details'][0]['profile_path']) : '',
                        formatWarning:false,
                        sizeWarning:false,
                        imageError:false,
                        action:'Edit',
                    })
                    if (window.location.href.includes('?myaccount')) {
                        this.setState({
                            disableFields: true
                        })
                    }
                })

            var url1 = window.GET_STATUS + this.state.personId;
              datasave.service(url1, 'GET')
                .then(response => {
                    if (response === 1) {
                        this.setState({
                            doccycle: true
                        })
                    }
                })

        }
        else {
            var url = window.CREATE_PERSON;
            datasave.service(url, "GET")
                .then(response => {
                  let showRoles = this.state.as4PersonOrNot ? response['roles'] : response['roles'].filter(singleRole => (singleRole.role_type === window.SITE_ROLE));
                    this.setState({
                        roles: as4_or_site ? response['roles'] : showRoles,
                        tasks: response['jgd'],
                        items: response['jgd'],
                        types: response['types'],
                        tabs: response['tabs'],
                        selected: [],
                    })
                })
        }
    }

    componentWillMount() {
        if (window.location.href.includes('?myaccount')) {
            this.setState({
                status: 'myaccount'
            })
        }
    }


    handleChange(e) {
        const { name, email, todotext, value } = e.target;
        const { t } = this.state;
        let pwdError = t('Password should be minimum length of 10 characters, atleast one upper case, one special character (#, ?, !, @, $, %, ^, &, *, -) and one numeric')

        let passwordTest = true;
        if(name === 'password') {
          let pwd = e.target.value;
          if (e.target.value.length === pwd.trim().length) {
            var password = e.target.value;
            const reg = new RegExp("^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{10,}$");
            passwordTest = reg.test(password);
          }
          else {
              this.setState({
                password_error: t('Space is not allowed'),
              })
              return false;
          }
            // var password = e.target.value;
            // const reg = new RegExp("^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])(?=.*?[/\s/g]).{10,}$");
            // passwordTest = reg.test(password);
            // if(e.target.value.match(/\s/g)) {
            //     passwordTest = false;
            // }
        }
        this.setState({
            [name]: value,
            [email]: value,
            [todotext]: value,
            name_error: '',
            email_error: '',
            password_error: passwordTest ? '' : pwdError,
            timezone_error: '',
            role_error: '',
        });
    }

    updateImageUpload=async (e)=> {
      const { t } = this.state;
      // console.log(response.data.file_id[0]);
      //   this.setState({
      //       sucess: window.FILE_UPLOAD_SUCCESS,
      //       edit_img: '',
      //       file_id: response.data.file_id[0],
      //       image: response.data.filepath
      //   });
      //
        let result = await reducers.uploadImage(e);
        if(result['status']===200){
          let resultFileId = result['data']['file_id'][0];
          let filePath = result['data']['filepath'];
          let fileName = result['data']['originalfname'];
          this.setState({
            file_id: resultFileId,
            image : filePath,
            sucess: window.FILE_UPLOAD_SUCCESS,
            imageError:false,
            file_name:fileName,
          })
        }else{
          this.setState({
            formatWarning:result.formatWarning,
            sizeWarning : result.sizeWarning,
            imageError:true,
            file_name:t('Choose image'),
            file_id:0,
            image:'',
          })
        }
    }

  async handleRemoveProfile(){
  const { t } = this.state;
  this.setState({file_name:t('Choose image'),image:'',file_id: 0})
  //    var url ='/api/deleteprofile/' + this.props.match.params.id +'/'+ this.state.file_id;
  // await   datasave.service(url,'PUT').then(async response =>{
  //      if(response.data === 1){
  //        this.setState({file_name:t('Choose image'),image:'',file_id: '',removeProfile:false})
  //      }
  //    })
  //  }
    /*  handlefrequencyChange(event) {
        const { value } = event.target.value;
        this.setState({ selectedevent: event.target.value});
      } */
}
    handleExport() {
        var url = window.EXPORT_PERSONS + this.state.personId;
        var details = {
            name: this.state.name,
            oldname: this.state.oldname,
            email: this.state.email,
            oldemail: this.state.oldemail,
        }
        datasave.service(url, 'PUT', details)
            .then(response => {
                window.open(response);
                window.close();
            })
    }

    handlehide = () => {
        this.setState({ show: false })
    }

    handleSelect(key) {
        this.setState({
            active_tab: key,
        });
    }
    getLangOptionItems() {
        let temp = [];
        if (this.state.language.length >= 1) {
            if (this.state.language) {
                temp = this.state.language.map((lang) => {
                    return (<option id={lang.code_name} value={lang.code_name} >{lang.language}</option>)
                }
                );
                return temp;
            }
        }
    }

    handleSubmit = (event) => {
      const {t} = this.state;
        event.preventDefault()
        const { history } = this.props
        let Userdata = store.getState();
        const store_uid = Userdata.UserData.user_details.user_id
        const details = {
            name: this.state.name,
            oldname: this.state.oldname,
            address: this.state.address,
            city: this.state.city,
            zip: this.state.zip,
            Dob: this.state.Dob,
            phone: this.state.phone,
            language_id: this.state.language_id,
            timezone: this.state.timezone,
            email: this.state.email.toLowerCase(),
            oldemail: this.state.oldemail,
            password: parseInt(this.state.personId) ? (this.state.password ? this.state.password : this.state.old_password) : 'As4point@123',
            old_password: this.state.old_password,
            role_id: this.state.role_id,
            sites: this.state.sites,
            available_in_masterdata: this.state.available_in_masterdata,
            active_person: this.state.active_person,
            image: this.state.image,
            file_id: this.state.file_id,
            to_do_frequency: this.state.todotext,
            to_do_frequency_type: this.state.todovalue,
            // file_name: this.state.file_name,
            membersof: { ...this.state.selected },
        }
        const personId = this.state.personId;
        if(this.state.password_error === '') {
          if (this.state.personId) {
              if (this.state.oldname === this.state.name && this.state.oldemail === this.state.email) {
                  this.handleOk()
              }
              else {
                  const url1 = window.PERSON_DETAILS + personId;
                  datasave.service(url1, 'GET', '')
                      .then(response => {
                        if(response.selected.length !== 0){
                          this.setState({
                              persondetails: response.selected,
                              show: true,
                              currentPage: 1,
                              pop: true,
                          })
                        }else{
                          this.setState({
                            nodata:true,
                            show:true,
                            pop:true
                          })
                        }
                      })
                  // window.location.reload();
                  /*this.setState({
                      currentPage:1,
                      pop:true,
                  })*/
              }
              /*const personId = this.props.match.params.id;
              const url = window.UPDATE_PERSONS + personId;
              const url1 = window.PERSON_DETAILS + personId;
              datasave.service(url1,'GET','')
              .then(response => {
                  this.setState({
                  persondetails:response.selected,
                  show:true,
                  })
              })
              this.setState({
                  currentPage:1,
              })*/
          }
          else {
              datasave.service(window.CREATE_PERSON, "POST", details)
                  .then(response => {
                      if (response.name || response.email || response.password || response.timezone || response.role_id) {
                          this.setState({
                              name_error: response.name,
                              email_error: response.email,
                              password_error: response.password,
                              timezone_error: response.timezone,
                              role_error: response.role_id,
                          })
                      } else if (response === 'Link person') {
                          OCAlert.alertWarning(t('Do you want to link this person to this site?'), { timeOut: window.TIMEOUTNOTIFICATION1 })
                          // alert("Do you want to link this person to this site?")
                          datasave.service(window.LINK_PERSON, "POST", details)
                              .then(response => {
                                  history.push('/managemyorganisation/managepersons')
                                  if (this.props.handleSelect !== undefined)
                                      this.props.handleSelect('/managemyorganisation/managepersons')
                              })

                      }
                      else if (response === 'success') {
                        this.props.handlePageChange()
                        //   history.push('/managemyorganisation/managepersons')
                        //   if (this.props.handleSelect !== undefined)
                        //       this.props.handleSelect('/managemyorganisation/managepersons')

                      }
                  })
                  .catch(error => {
                      this.setState({
                          errors: error.response.data.errors
                      })
                  })
          }
      }

    }

    handlePopupCancel() {
        this.setState(
            { show: false }
        )
    }
    handleOk() {
        const { history } = this.props
        let Userdata = store.getState();
        const store_uid = Userdata.UserData.user_details.user_id
        const pid = Userdata.UserData.user_details.person_id;
        const details = {
            name: this.state.name,
            oldname: this.state.oldname,
            address: this.state.address,
            city: this.state.city,
            zip: this.state.zip,
            Dob: this.state.Dob,
            phone: this.state.phone,
            language_id: this.state.language_id,
            timezone: this.state.timezone,
            email: this.state.email.toLowerCase(),
            password: this.state.password ? this.state.password : this.state.old_password,
            old_password: this.state.old_password,
            role_id: this.state.role_id,
            sites: this.state.sites,
            available_in_masterdata: this.state.available_in_masterdata,
            active_person: this.state.active_person,
            image: this.state.image,
            file_id: this.state.file_id,
            person_uid: this.state.person_uid,
            to_do_frequency: this.state.todotext,
            to_do_frequency_type: this.state.todovalue,
            clonename: this.state.clonename,
            modifyname: this.state.name !== this.state.clonename,
            pid: pid,
            // file_name: this.state.file_name,
            membersof: { ...this.state.selected },
        }
        // let propsdata = this.props.UserData;
        // propsdata.user_details.profile_path = this.state.image;
        // propsdata.user_details.user_name = this.state.name;
        // this.props.SetUserData(propsdata);
        if (this.state.personId) {
            const personId = this.state.personId;
            const url = window.UPDATE_PERSONS + personId;
            datasave.service(url, "PUT", details)
              .then(response => {
                  if (response.name || response.email || response.password || response.timezone || response.role_id) {
                      this.setState({
                          name_error: response.name,
                          email_error: response.email,
                          password_error: response.password,
                          timezone_error: response.timezone,
                          role_error: response.role_id,
                      })
                  }
                  else if (response === 'Success') {
                      if (window.location.href.includes("?myaccount")) {
                          localStorage.setItem('Applang', this.state.language_id);
                          // this.setState({
                          //   image:Userdata.user_details.profile_path
                          // })
                          history.push('/');
                          window.location.reload();
                      }
                      else {
                          history.push('/managemyorganisation/managepersons')
                          if (this.props.handleSelect !== undefined)
                              this.props.handleSelect('/managemyorganisation/managepersons')

                          window.location.reload();
                      }
                  }
              })
              .catch(error => {
                  this.setState({
                      errors: error.response.errors
                  })
              })
        }
    }

    handleCancel(event) {
        let Userdata = store.getState();
        const store_uid = Userdata.UserData.user_details.user_id
        const { history } = this.props

        if (this.state.person_uid === store_uid && window.location.href.includes("?myaccount")) {
            history.push('/')
        }
        else {
            if(this.state.personId==0){
                this.props.handlePageChange();
            }else{
                history.push('/managemyorganisation/managepersons')
                if (this.props.handleSelect !== undefined)
                this.props.handleSelect('/managemyorganisation/managepersons')
            }
        }
    }

    updateSelected = (latestDropped, result, type, id = '') => {
        var array = [...this.state['selected']]; // make a separate copy of the array
        if (result.type === 'remove') {
            var filterArray = array.filter(selected => (selected.id !== latestDropped.id));
        }
        if (result.type === 'remove') {
            this.setState({
                selected: filterArray,
            })
        }
        else {
            this.setState(prevState => ({
                selected: [...prevState['selected'], latestDropped]
            }));
        }
    }

    handlePageClick(event) {
        this.setState({
            currentPage: Number(event.target.id)
        });
    }

    render() {
        const { t, personId } = this.state;
        let Userdata = store.getState();
        const store_uid = Userdata.UserData.user_details.user_id
        const role_disabled = (window.location.href.includes("?myaccount")) ? 'disabled' : '';
        const active_disable = (this.state.doccycle === true);
        const Role_change_permission = this.state.personId ? CanPermissions("AIS_role", "") : true ;
        let Role_change_permission_access = (Role_change_permission) ? '' : 'disabled';
        const dataLOU = CanPermissions("LOU", "");
        const details_tab_access = CanPermissions("E_user", "");
        let details_tab_disable = (details_tab_access) ? '' : 'disabled';
        const { persondetails, currentPage, todosPerPage, } = this.state;
        const indexOfLastTodo = currentPage * todosPerPage;
        const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
        const currentTodos = persondetails.slice(indexOfFirstTodo, indexOfLastTodo);
        let disable_password_email = window.location.href.includes("?myaccount") ? (CanPermissions("set_pwd_in_myaccount", "") ? '' : 'disable' ) : (this.state.personId ? (this.state.active_person === 1 ? ((this.state.personId == Userdata.UserData.user_details.person_id || this.state.as4PersonOrNot === 1) ? '' : 'disable') : '') : '');
        disable_password_email = disable_password_email ? !CanPermissions("create_update_password_access_key", "") : disable_password_email;
        const pagerender = currentTodos.map(person => {
            return (
                <tr>
                    <td>{person.name}</td>
                    <td>{person.category}</td>
                </tr>
            )
        });
        const pageNumbers = [];
        if (this.state.persondetails.length > 5) {
            for (let i = 1; i <= Math.ceil(this.state.persondetails.length / todosPerPage); i++) {
                pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
                    {i}
                </Pagination.Item>);
            }
        }
        const popup = (
            <reactbootstarp.Modal
                show={this.state.show}
                onHide={this.handlehide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title"
            >
                <reactbootstarp.Modal.Header closeButton>
                    <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
                    </reactbootstarp.Modal.Title>
                    <reactbootstarp.Modal.Body col-md-12 pr-0>
                        <reactbootstarp.Table responsive striped bordered hover size="sm">
                            <thead>
                                <tr>
                                    <td>{t('Name')}</td>
                                    <td>{t('Category')}</td>
                                </tr>
                            </thead>
                            <tbody>
                            {this.state.nodata === true &&<tr class =  "text-center"><span style = {{marginLeft:'20px'}} >{t('No records found')}</span></tr>}
                                {pagerender}
                            </tbody>
                        </reactbootstarp.Table>
                        <Pagination size="sm" style={{ width: '410px', overflow: 'auto' }}>{pageNumbers}</Pagination>
                        {this.state.oldname !== this.state.name && <div> <reactbootstarp.FormLabel>{t('Old name')}</reactbootstarp.FormLabel>
                            <reactbootstarp.Form.Control type="text" value={this.state.oldname} />
                            <reactbootstarp.FormLabel>{t('New name')}</reactbootstarp.FormLabel>
                            <reactbootstarp.Form.Control type="text" value={this.state.name} /> </div>}
                        {this.state.oldemail !== this.state.email && <div>  <reactbootstarp.FormLabel>{t('Old email')}</reactbootstarp.FormLabel>
                            <reactbootstarp.Form.Control type="text" value={this.state.oldemail} />
                            <reactbootstarp.FormLabel>{t('New email')}</reactbootstarp.FormLabel>
                            <div style={{ color: 'red' }} className="error-block mt-2">{this.state.email_error}</div>
                            <reactbootstarp.Form.Control type="text" value={this.state.email} /> </div>}
                    </reactbootstarp.Modal.Body>
                </reactbootstarp.Modal.Header>
                <reactbootstarp.Modal.Footer>
                    <reactbootstarp.Button onClick={() => this.handlePopupCancel()}>{t('Cancel')}</reactbootstarp.Button>
                    &nbsp;&nbsp; &nbsp;&nbsp;
                    <reactbootstarp.Button onClick={() => this.handleOk()}>{t('Save')}</reactbootstarp.Button>
                    <reactbootstarp.Button onClick={() => this.handleExport()}>{t('Export')}</reactbootstarp.Button>
                </reactbootstarp.Modal.Footer>
            </reactbootstarp.Modal>
        );
        const { name, timezone, address, zip, city, Dob, phone, pop, oldemail, email, language_id, save
            , savevalue, password, roles, available_in_masterdata, timezonelist,
            active_tab, active_person, role_id, file_name, oldname,
            selected, name_error, email_error, password_error, timezone_error, role_error, todovalue, todo } = this.state;
        var pack_fun = this.state.tasks;

        const linkTabs = Object.values(this.state.tabs).map(
            function (itemlist, key) {
                pack_fun = filterArray(this.state.tasks, this.state.selected);
                let disabled = (dataLOU) ? '' : 'disabled';
                return (
                    <reactbootstarp.Tab disabled={disabled} eventKey={itemlist} title={t(itemlist)} >
                        <PJDGdragndrop
                            organisatioal_unit={"Persons"}
                            itemlist={itemlist}
                            details={this.state}
                            types={this.state.types[itemlist]}
                            items={pack_fun}
                            tasks={pack_fun}
                            active_tab={this.state.active_tab}
                            type={"common"}
                            selected={this.state.selected}
                            uniqueId={this.props.uniqueId}
                            {...this}
                            updateSelectedChild={this.updateSelected} />
                    </reactbootstarp.Tab>
                )
            }, this);
            const personForm = <><FormGroup md="4" controlId="validationCustom01">
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Name')}:
                                <span style={{ color: "red" }}>*</span>
                                </InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Form.Control
                                id="name"
                                type="text"
                                name="name"
                                disabled={role_disabled}
                                placeholder={t("Name")}
                                value={name}
                                onChange={this.handleChange}
                                className="input_sw"
                            />
                            <div style={{ color: 'red' }} className="error-block mt-2">{name_error}</div>
                        </div>
                    </InputGroup>

                </div>
            </FormGroup>
            <FormGroup md="4" controlId="validationCustom01">
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Address')}:</InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Input
                                id="address"
                                type="text"
                                name="address"
                                placeholder={t("Address")}
                                value={address}
                                onChange={this.handleChange}
                                className="input_sw"
                            />
                        </div>
                    </InputGroup>
                </div>
            </FormGroup>
            <FormGroup>
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Zip')}:</InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Input
                                id="zip"
                                type="text"
                                name="zip"
                                placeholder={t("Zip")}
                                value={zip}
                                onChange={this.handleChange}
                                className="input_sw"
                            />
                        </div>
                    </InputGroup>
                </div>
            </FormGroup>
            <FormGroup>
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('City')}:</InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Input
                                id="city"
                                type="text"
                                name="city"
                                placeholder={t("City")}
                                value={city}
                                onChange={this.handleChange}
                                className="input_sw"
                            />
                        </div>
                    </InputGroup>
                </div>
            </FormGroup>
            <FormGroup>
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Birth date')}:</InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Input
                                id="Dob"
                                type="date"
                                name="Dob"
                                placeholder={t("Birth date")}
                                value={Dob}
                                onChange={this.handleChange}
                                className="input_sw"
                            />
                        </div>
                    </InputGroup>
                </div>
            </FormGroup>
            <FormGroup>
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Phone')}:</InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Input
                                id="phone"
                                organisation_id type="text"
                                name="phone"
                                placeholder={t("Phone")}
                                value={phone}
                                onChange={this.handleChange}
                                className="input_sw"
                            />
                        </div>
                    </InputGroup>
                </div>
            </FormGroup>
            <FormGroup>
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Email')}<span style={{ color: 'red' }}>  *</span></InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Input
                                id="email"
                                type="email"
                                name="email"
                                placeholder={t("Email")}
                                disabled={role_disabled || disable_password_email}
                                value={email}
                                onChange={this.handleChange}
                                className="input_sw"
                                autoComplete="off"
                            />
                            <div style={{ color: 'red' }} className="error-block mt-2">{email_error}</div>
                        </div>
                    </InputGroup>
                </div>
            </FormGroup>
            {parseInt(personId) ? <FormGroup>
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Password')}:
                                    {this.state.person_uid != store_uid &&
                                        <span style={{ color: 'red' }}>  *</span>
                                    }
                                </InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Input
                                id="password"
                                type="password"
                                name="password"
                                placeholder={t("Password")}
                                disabled={disable_password_email}
                                value={password}
                                autoComplete='new-password'
                                onChange={this.handleChange}
                                className="input_sw"
                            />
                            <div style={{ color: 'red' }} className="error-block  mt-2">{password_error}</div>
                        </div>
                    </InputGroup>
                </div>
            </FormGroup>:null}
            <FormGroup>
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Time zone')}:<span style={{ color: 'red' }}>  *</span></InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Form.Control as="select" name="timezone"
                                className="input_sw"
                                value={timezone}
                                onChange={this.handleChange} >
                                <option>Select</option>
                                {timezonelist.map(timezone => <option value={timezone.text}>{timezone.text}</option>)}
                            </Form.Control>
                            <div style={{ color: 'red' }} className="error-block mt-2">{timezone_error}</div>
                        </div>
                    </InputGroup>
                </div>
            </FormGroup>
            <FormGroup>
                <div className=" row input-overall-sec ">
                    <div className="col-md-4">
                        <InputGroup.Prepend>
                            <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('To do frequency')}:</InputGroup>
                        </InputGroup.Prepend>
                    </div>
                    {/*<div class="col-md-8 row input-padd">  */}
                    <div className="col-md-4 input-padd  ">
                        <Input
                            id="todo"
                            type="text"
                            name="todotext"
                            value={this.state.todotext}
                            onChange={this.handleChange}
                            className="input_sw"
                        />
                    </div>
                    <div class="col-md-4 input-padd">
                        <Form.Control as="select" name="todofrequency"
                            className="input_sw"
                            value={todovalue}
                            onChange={e => this.setState({ todovalue: e.target.value, loading: false })}>
                            <option style={{ display: "none" }}>{t('Select')}</option>
                            {todo.map(todo => <option id={todo.value} value={todo.value}>{todo.label}</option>)}
                        </Form.Control>
                    </div>
                </div>
                {/*</div>  */}
            </FormGroup>
            <FormGroup>
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Language')}:</InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Form.Control as="select" name="language_id"
                                className="input_sw"
                                value={this.state.language_id}
                                onChange={e => this.setState({ language_id: e.target.value, loading: false })} >
                                <option>{t('Select')}</option>
                                {this.getLangOptionItems()}
                            </Form.Control>
                        </div>
                    </InputGroup>
                </div>
            </FormGroup>
            <FormGroup>
                <div className=" row input-overall-sec ">
                    <InputGroup className="">
                        <div className="col-md-4">
                            <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Role')}:<span style={{ color: 'red' }}>  *</span></InputGroup>
                            </InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <Form.Control as="select" name="role_id"
                                className="input_sw"
                                value={role_id}
                                disabled={role_disabled || Role_change_permission_access}
                                onChange={this.handleChange} >
                                <option>Select</option>
                                {roles.map(role => <option value={role.id}>{role.name}</option>)}
                            </Form.Control>
                            <div style={{ color: 'red' }} className="error-block mt-2">{role_error}</div>
                        </div>
                    </InputGroup>
                </div>
            </FormGroup>
            <reactbootstrap.Row>
                <reactbootstrap.FormLabel className='col-md-4' style={{ paddingTop: '15px',paddingLeft:'20px', color: '#EC661C' }}>{t('Upload ')}</reactbootstrap.FormLabel>
                <reactbootstrap.InputGroup className= "col-md-8 custom-file input_sw">
                   <reactbootstrap.FormControl
                       type="file"
                       className="custom-file-input"
                       id="inputGroupFile01"
                       name='image'
                       accept = {window.DOC_TYPES['default']}
                       onChange={(e)=>this.updateImageUpload(e)}
                   />
                   <reactbootstrap.FormLabel className="custom-file-label" htmlFor="inputGroupFile01">
                   {this.state.file_name !== null && this.state.file_name }
                   </reactbootstrap.FormLabel>
                </reactbootstrap.InputGroup>
         </reactbootstrap.Row>
                <reactbootstrap.Row>
                  <reactbootstrap.Col style={{marginLeft:'360px'}}>
                      {this.state.imageError===false ?<div style={{display:this.state.file_name!== t('Choose image') ? 'block' : 'none' }}>
                      {this.state.action!=='Edit' && <span style={{ color: "green",marginLeft:'1px' }}>{window.FILE_UPLOAD_SUCCESS}</span>}
                      <span style={{display:'inline-block',paddingRight:'6px'}}>
                      <i title="preview" style={{ 'cursor': 'pointer',marginLeft:'1px' }} class="webform-sprite webform-sprite-smallviewc" onClick={(e) => window.open(this.state.image, "_blank")}></i>
                      </span>
                      <span style={{display:'inline-block'}}>
                      <i title="Remove" style={{ 'cursor': 'pointer',marginLeft:'1px' }} class="overall-sprite overall-sprite-mtdeletec" onClick={(e) => this.handleRemoveProfile()}/>
                      </span>
                      </div>
                      :
                      <>
                      {this.state.formatWarning===false && this.state.sizeWarning===false && <span style={{ color: "red" }}> {t('Invalid image format and size should be < 1MB')} </span>}
                      {this.state.formatWarning===true && this.state.sizeWarning===false && <span style={{ color: "red" }}> {t('Invalid image format')} </span>}
                      {this.state.formatWarning===false && this.state.sizeWarning===true && <span style={{ color: "red" }}> {t('File size should be < 1MB')} </span>}
                      </>}
                    </reactbootstrap.Col>
                   </reactbootstrap.Row>
            {this.state.status === 'myaccount' ? '' : <FormGroup>
                <Form.Check
                    onChange={e => this.setState({ available_in_masterdata: !available_in_masterdata })}
                    name='available_in_masterdata'
                    disabled={role_disabled}
                    checked={available_in_masterdata}
                    label={t("Available in master data")}
                />
            </FormGroup>
            }
            {this.state.status === 'myaccount' ? '' : <FormGroup>
                <Form.Check
                    onChange={e => this.setState({ active_person: !active_person })}
                    name='active_person'
                    disabled={active_disable}
                    checked={active_person}
                    label={t("Active user")}
                />
            </FormGroup>
          }</>
        const myaccount = (window.location.href.includes("?myaccount")) ? true : false;

        if(window.location.href.includes("?myaccount")) {
          details_tab_disable = myaccount ? '' : 'disabled';
        }
        return (
          <>
            {((parseInt(this.state.personId) === parseInt(Userdata.UserData.user_details.person_id) && myaccount === true) || (myaccount === false)) &&
              <div className=" row col-md-12">
                  {this.state.personId!=0 && <div style={{ visibility: 'hidden' }} className="col-md-0"><p>welcome</p></div>}
                  <div style={{  }} className='col-md-11' >
                      <Can
                          myaccount={myaccount}
                          perform="E_user,LOU"
                          yes={() => (
                              <div className="">
                                  <div className="col-md-12 mt-0 mb-0 p-0">
                                      <div className="card mt-3 mb-4">
                                          {/* <div className="card-header">{this.state.status !== 'myaccount' ? t('Create person'):t('My account')}</div> */}
                                          <div className='card-body' >
                                              <Container className="">
                                                  <Form onSubmit={this.handleSubmit} enctype="multipart/form-data">
                                                    {this.state.status !== 'myaccount' &&  <Tabs activeKey={active_tab} onSelect={this.handleSelect} id="controlled-tab-example">
                                                          <Tab disabled = {details_tab_disable} eventKey={1} title={t("Personal details")}>
                                                            {personForm}
                                                          </Tab>
                                                           {linkTabs}
                                                      </Tabs>}
                                                      {this.state.status === 'myaccount' && personForm}
                                                      <FormGroup>
                                                          <div style={{ float: 'right' }} className="organisation_list mt-3">
                                                              <a onClick={this.handleCancel} >{t('Cancel')}</a>
                                                              &nbsp;&nbsp;&nbsp;
                                                          <Button disabled={!savevalue} className="btn btn-primary" type="submit" color="primary"> {t('Save')} </Button>
                                                          </div>
                                                      </FormGroup>
                                                  </Form>{this.state.pop && popup}
                                              </Container>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          )}
                          no={() =>
                              <AccessDeniedPage />
                          }
                      />
                  </div>
              </div>
            }
            {((parseInt(this.state.personId) !== parseInt(Userdata.UserData.user_details.person_id)) && myaccount === true) &&
              <AccessDeniedPage />
            }
          </>
        );
    }
}
export default translate(Persons)

// const mapStateToProps = state => ({...state});
// const mapDispatchToProps = dispatch => ({
//     SetUserData: (payload) => dispatch(SetUserData(payload)),
//   });
// export default translate(connect(mapStateToProps, mapDispatchToProps)(Persons));
