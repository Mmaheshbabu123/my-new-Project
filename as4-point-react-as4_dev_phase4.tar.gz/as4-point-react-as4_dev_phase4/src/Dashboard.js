import React, { Component } from 'react';
import { translate } from './language';
import './Dashboard.css';
import logo_as4 from './images/Logo-AS4-Point.png';
import first from './images/Notification.png';
import second from './images/Manuals.png';
import third from './images/Newfeed.png';
import fourth from './images/Planning.png';
import fifth from './images/Reports.png';
import sixth from './images/CAPA.png';
import seventh from './images/Objective.png';
import eighth from './images/Training.png';
import menu from './images/menu.png';
import user from './images/user.png';
import search from './images/search1.png';
import book from './images/book.png';

class Dashboard extends Component {

    constructor(props) {
        super(props)
        this.state = {
            t: props.t,

        }

    }



    render() {
        const { t } = this.state;
        return (
            //     <Container-fluid >
            //         {/* <Row bg-light> */}
            //         <div class="row">
            //             <div class="col-lg-2">
            //                 <img src={logo_as4} width="80" height="60" ></img>
            //             </div>

            //             <div class="col-lg-7 dash-search-input-sec">
            //                 <div class="input-group md-form form-sm form-2 pl-0 dash-search-sec">
            //                     <input class="form-control my-0 py-1 dash-search-input " type="text" placeholder="Search" aria-label="Search"></input>
            //                     <div class="input-group-append  dash-icon-search">
            //                         <span class="input-group-text " aria-hidden="true"> <img class="search-icon" src={search} width="25" height="25" ></img></span>
            //                     </div></div>
            //             </div>
            //             <div class="col-lg-3 d-flex">
            //                 <div>
            //                     <img class="admin-icon" src={user} width="70" height="65" ></img>

            //                 </div>
            //                 <div class="admin-content" >

            //                     <p class="dash-user-name">USER NAME</p>
            //                     <p class="dash-admin-content">ADMIN</p>
            //                 </div>
            //                 <div class="admin-menu text-center">
            //                     <img src={menu} width="30" height="30" ></img>
            //                 </div>
            //             </div>
            //         </div>
            //         {/* </Row> */}

            //         <Row>
            //             <div class="col-lg-1">
            //                 <div style={{ margin: '25px  0px' }}>
            //                     <img src={first} class="first-icon " ></img>
            //                 </div>
            //                 <div style={{ margin: '25px  0px' }}>
            //                     <img src={second} class="first-icon " ></img>
            //                 </div>
            //                 <div style={{ margin: '25px  0px' }}>
            //                     <img src={third} class="first-icon " ></img>
            //                 </div>
            //                 <div style={{ margin: '25px  0px' }}>
            //                     <img src={fourth} class="first-icon " ></img>
            //                 </div>
            //                 <div style={{ margin: '25px  0px' }}>
            //                     <img src={fifth} class="first-icon " ></img>
            //                 </div>
            //                 <div style={{ margin: '25px  0px' }}>
            //                     <img src={sixth} class="first-icon " ></img>
            //                 </div>
            //                 <div style={{ margin: '25px  0px' }}>
            //                     <img src={seventh} class="first-icon " ></img>
            //                 </div>
            //                 <div style={{ margin: '25px  0px' }}>
            //                     <img src={eighth} class="first-icon " ></img>
            //                 </div>
            //             </div>

            //         </Row>

            //     </Container-fluid>



            // );

            // return (
            <div className="container-fluid dash-body">
                <div className="row dash-header-sec">
                    <div className="col-lg-2 dash-logo-sec">
                        <img src={logo_as4} width="80" height="60" ></img>
                    </div>
                    <div className="col-lg-7 dash-search-input-sec">
                        <div className="input-group md-form form-sm form-2 pl-0 dash-search-sec">
                            <input className="form-control my-0 py-1 dash-search-input " type="text" placeholder={t("Search")} aria-label="Search"></input>
                            <div className="input-group-append  dash-icon-search">
                                <span className=" " aria-hidden="true"> <img className="search-icon" src={search} width="25" height="25" ></img></span>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 dashboard-left-section">
                        {/* <span class="right-header-logo"> */}
                        <img className="admin-icon" src={user} width="70" height="65" ></img>
                        {/* </span> */}


                        <div className="admin-content" >
                            {/* <span class="right-header-content"> */}
                            <p className="dash-user-name">{t('USER NAME')}</p>
                            <p className="dash-admin-content">{t('ADMIN')}</p>
                            {/* </span> */}
                        </div>
                        <div className="admin-menu">
                            <img src={menu} width="30" height="30" ></img>
                        </div>
                    </div>

                </div>

                <div className=" row banner-section">
                    <div className="col-lg-1 left-menulist">
                        <div style={{ margin: '25px  0px' }}>
                            <img src={first} className="first-icon " ></img>
                        </div>
                        <div style={{ margin: '25px  0px' }}>
                            <img src={second} className="first-icon " ></img>
                        </div>
                        <div style={{ margin: '25px  0px' }}>
                            <img src={third} className="first-icon " ></img>
                        </div>
                        <div style={{ margin: '25px  0px' }}>
                            <img src={fourth} className="first-icon " ></img>
                        </div>
                        <div style={{ margin: '25px  0px' }}>
                            <img src={fifth} className="first-icon " ></img>
                        </div>
                        <div style={{ margin: '25px  0px' }}>
                            <img src={sixth} className="first-icon " ></img>
                        </div>
                        <div style={{ margin: '25px  0px' }}>
                            <img src={seventh} className="first-icon " ></img>
                        </div>
                        <div style={{ margin: '25px  0px' }}>
                            <img src={eighth} className="first-icon " ></img>
                        </div>


                    </div>
                    <div className="col-lg-11 row">
                        <div className="col-lg-3  dash-baner-content">
                            <div className=" col-lg-11 dash-baner-content-sec1">
                                <p>Todo`s</p>
                            </div>
                            <div>
                                <img src={book} className="first-icon  img-responsive" ></img>
                            </div>
                            <div className="col-ls-1">
                                <p>...</p>
                            </div>

                        </div>
                        <div className="col-lg-3 dash-baner-content">
                            <div className=" col-lg-11 dash-baner-content-sec2">
                                <p>To do`s Feeds</p>
                            </div>
                            <div>
                                <img src={book} className="first-icon img-responsive " ></img>
                            </div>

                        </div>
                        <div className="col-lg-3 dash-baner-content">
                            <div className="col-lg-11 dash-baner-content-sec3">
                                <p>{t('Notificationas Documents')}  </p>
                            </div>
                            <div>
                                <img src={book} className="first-icon img-responsive " ></img>
                            </div>

                        </div>


                    </div>
                    <div className="col-lg-11 row">
                    </div>


                </div>

            </div>


        );
    }
}
export default translate(Dashboard)
