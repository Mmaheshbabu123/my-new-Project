import React from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';


const LoginHtml = () => (
    <div className="container">
    <div className="row justify-content-center">
        <div className="col-md-8">
            <div className="card">
                <div className="card-header">Login</div>
                <reactbootstrap.Container className="p-5">
                    <reactbootstrap.Form>
                        <reactbootstrap.FormGroup>
                            {/* <Label>Email:</Label>
                            <Input
                                type="email"
                                name="email"
                                placeholder="Email"
                                required="1"
                            /> */}
                        <reactbootstrap.InputGroup className="mb-3">
    <reactbootstrap.InputGroup.Prepend>
      <reactbootstrap.InputGroup id="basic-addon1">@</reactbootstrap.InputGroup>
    </reactbootstrap.InputGroup.Prepend>
    <reactbootstrap.FormControl
      placeholder="Username"
      aria-label="Username"
      aria-describedby="basic-addon1"
    />
  </reactbootstrap.InputGroup>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                            {/* <Label>Name:</Label>
                            <Input
                                type="text"
                                name="password"
                                placeholder="Password"
                                required="1"
                            /> */}
                        <reactbootstrap.InputGroup className="mb-3">
    <reactbootstrap.InputGroup.Prepend>
      <reactbootstrap.InputGroup id="basic-addon1">@</reactbootstrap.InputGroup>
    </reactbootstrap.InputGroup.Prepend>
    <reactbootstrap.FormControl
      placeholder="Username"
      aria-label="Username"
      aria-describedby="basic-addon1"
    />
  </reactbootstrap.InputGroup>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                            <div>
                                <Link className='btn btn-primary btn-sm mb-3' to='/forgotpassword'>
                                    Forgot password
                                </Link>
                            </div>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                        <div className="col-lg-4">
                            <Link to='/'>
                                <reactbootstrap.Button type="submit" color="primary">Login</reactbootstrap.Button>
                            </Link>
                        </div>
                        </reactbootstrap.FormGroup>
                    </reactbootstrap.Form>
                </reactbootstrap.Container>
            </div>
        </div>
    </div>
</div>
        );
export default LoginHtml
