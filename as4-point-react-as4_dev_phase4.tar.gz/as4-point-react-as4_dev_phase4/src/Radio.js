import React from 'react';

export default function Radio({keyvalue, name, value, tick, classification, onCheck}) {
      return (
          <label>
              <input
                  name={classification}
                  type="radio"
                  value={value}
                  checked={checked || false}
                  onChange={onCheck}
                  key={keyvalue}
              />
              {name}
          </label>
      );
  }