//import axios from 'axios'
import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from './_services/db_services';
import Can from './_components/CanComponent/Can';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import CheckBoxList from './CheckBoxList';
import { Tabs, Tab } from 'react-bootstrap';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import { persistor, store } from './store';
import { translate } from './language';
import CheckBox from './CheckBox';
import _, {debounce} from 'lodash';
class Roles extends Component {
  constructor(props) {
    super(props)
    let userData = store.getState();
    this.state = {
      save: props.t('Save'),
      savevalue: 'true',
      name: '',
      responsibilites: [],
      checkedItems: new Map(),
      functions: [],
      allFunctions: [],
      checklist: [],
      checkedItems_values: [],
      checkedItems_keys: [],
      active_tab: "Dashboard",
      ItemsChecked: [false, false, false],
      package_functions: [],
      t: props.t,
      roles : [],
      parentrole : '',
      roleType : 0,
      logedinRoleId : userData.UserData.user_details.role_id,
      mainOrSite : '',
      showAS4Checkbox : 0,
      searchFunction:'',
      functionsData:[],
      roleID : this.props.match!=undefined?this.props.match.params.id:0,
    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCheck = this.handleCheck.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.handleSearch = this.handleSearch.bind(this);

  }

  handleCheck(e) {
    const item = e.target.name;
    const isChecked = e.target.checked;
    this.setState(prevState => ({ checkedItems: prevState.checkedItems.set(item, isChecked) }));
  }
  setDisplayedContacts = debounce(query => {
    this.setState({
      searchFunction:query

    });
    this.searchFuncionResult(query);
  }, 100);
  searchFuncionResult(query) {
    var items_f = {};
    console.log(this.state.functionsData);

    items_f = JSON.parse(JSON.stringify(this.state.functionsData));
    let filterObj = {};
     Object.values(items_f).map(item => {
       //let filter_values = {...item.values};
      let  list = item.values.filter(function (item1) {
           if (item1.name !== null) {
             return item1.name.toLowerCase().search(
               query.toLowerCase()) !== -1;
           }
         },this);
         if(list.length>0) {
           filterObj[item.classificationId] = item;
           filterObj[item.classificationId]['values']=list;

         }
     })
    console.log(filterObj);
     filterObj = (query != null || query != '')?filterObj:this.state.functionsData;
     //Object.keys(filterObj).length>0?filterObj:this.state.functionsData;
     var active_tab = this.state.active_tab;
     Object.values(filterObj).some(function(item,i){
       if(item.title!=null) {
       active_tab = item.title;
       return true;
     }

     })
    this.setState({
      functions:filterObj,
      active_tab:active_tab,

    })
  }
 handleSearch(e) {
const {name,value}=e.target;
this.setDisplayedContacts(value);
// var items_f = {};
// items_f = JSON.parse(JSON.stringify(this.state.functionsData));
// let filterObj = {};
//  Object.values(items_f).map(item => {
//    //let filter_values = {...item.values};
//   let  list = item.values.filter(function (item1) {
//        if (item1.name !== null) {
//          return item1.name.toLowerCase().search(
//            this.state.searchFunction.toLowerCase()) !== -1;
//        }
//      },this);
//      if(list.length>0) {
//        filterObj[item.classificationId] = item;
//        filterObj[item.classificationId]['values']=list;
//
//      }
//  })
//  console.log(filterObj);
//  console.log(filterObj.length);
//  filterObj = Object.keys(filterObj).length>0?filterObj:this.state.functionsData;
//  var active_tab = this.state.active_tab;
//  Object.values(filterObj).some(function(item,i){
//    if(item.title!=null) {
//    active_tab = item.title;
//    return true;
//  }
//
//  })
// this.setState({
//   functions:filterObj,
//   active_tab:active_tab,
//
// })
 }
  componentDidMount() {
    var url = window.USERROLES
    datasave.service(url, "GET")
    .then(response => {
      this.setState({
        roles: response,
      })
    })

    var url = window.USERROLES + '/' + this.state.logedinRoleId;
    datasave.service(url, "GET")
      .then(response => {
        this.setState({
          showAS4Checkbox: response[0] ?  response[0]['as4member'] : 0,
        })
      })

    const role_id = this.state.roleID;
    if (this.state.roleID) {
      if (this.props.handleSelect !== undefined)
        this.props.handleSelect('/managemyorganisation/createdefaultrole')
      var url = window.USERROLES + '/' + role_id;
      datasave.service(url, "GET")
        .then(response => {
          this.setState({
            name: response[0]['name'],
            parentrole : response[0]['parent_role'],
            roleType : response[0]['as4member'],
            mainOrSite : response[0]['role_type'],
          })
        })

      var url = window.USERROLES_FUNCTION + '/' + role_id;
      datasave.service(url, "GET")
        .then(response => {
          let functionsOfAllCategories = response['function'];
          let functionValues = [];
          let accesableFunctions = [];
          let personAs4OrNot = this.state.showAS4Checkbox;
          Object.keys(functionsOfAllCategories).map(function(key) {
            if (personAs4OrNot) {
               functionValues = functionsOfAllCategories[key]['values']  ? functionsOfAllCategories[key]['values'] : [];
             } else {
               functionValues = functionsOfAllCategories[key]['values']  ? functionsOfAllCategories[key]['values'].filter(item => (item.fpublic || item.checked)) : [];
             }
             functionsOfAllCategories[key]['values'] = functionValues;
          })

          this.setState({
            functions : functionsOfAllCategories,
            functionsData:functionsOfAllCategories,
            // functions: response['function'],
            allFunctions: response['allfunctions'],
          })
        })
    }
    else {
      var url = window.GET_FUNCTIONS
      datasave.service(url, "GET")
        .then(response => {
          let functionsOfAllCategories = response['function'];
          let functionValues = [];
          let accesableFunctions = [];
          let personAs4OrNot = this.state.showAS4Checkbox;
          Object.keys(functionsOfAllCategories).map(function(key) {
            if (personAs4OrNot) {
               functionValues = functionsOfAllCategories[key]['values']  ? functionsOfAllCategories[key]['values'] : [];
             } else {
               functionValues = functionsOfAllCategories[key]['values']  ? functionsOfAllCategories[key]['values'].filter(item => (item.fpublic || item.checked)) : [];
             }
             functionsOfAllCategories[key]['values'] = functionValues;
          })

          this.setState({
            // functions : functionsOfAllCategories,
            functions: response['function'],
            functionsData:response['function'],
            allFunctions: response['allfunctions'],
          });
        })
    }
    /*datasave.service(window.SHOW_CLASSIFICATIONS,'GET')
     .then(response =>
     {this.setstate({
                     functions : response
                   })
     })*/
  }



  handleCancel(event) {
    const { history } = this.props
    // if (this.props.handleSelect !== undefined) {
      if (this.state.roleID==0) {
        this.props.handlePageChange();
        // history.push('/managemyorganisation/managerole')
        // if (this.props.handleSelect !== undefined)
        //   this.props.handleSelect('/managemyorganisation/managerole')
      } else {
        history.push('/managemyorganisation/managerole')
        if (this.props.handleSelect !== undefined)
          this.props.handleSelect('/managemyorganisation/managerole')

      }
    }
  // }

  handleSubmit(event) {
    const mapData = JSON.stringify([...this.state.checkedItems])
    const values = JSON.parse(mapData)
    event.preventDefault()
    const { history } = this.props
    const details = {
      name: this.state.name,
      checkedItems: this.state.allFunctions,
      parent_role : this.state.parentrole,
      as4member : this.state.roleType,
      role_type : this.state.mainOrSite,
    }

    if (this.state.roleID) {
      const roleId = this.state.roleID;
      var url = window.USERROLES + '/' + roleId;

      datasave.service(url, 'PUT', details)
        .then(response => {
          if (response.name || response.parent_role) {
            this.setState({
              name_error: response.name,
              parent_role_error : response.parent_role
            })
          }
          else {
            history.push('/managemyorganisation/managerole')
            window.location.reload();
            if (this.props.handleSelect !== undefined)
              this.props.handleSelect('/managemyorganisation/managerole')
          }
        })
        .catch(error => {
          this.setState({
            errors: error.response.errors
          })
        })
    } else {
      var url = window.USERROLES;
      datasave.service(url, 'POST', details)
        .then(response => {
          if (response.name || response.parent_role) {
            this.setState({
              name_error: response.name,
              parent_role_error : response.parent_role
            })
          }
          else {
            this.props.handlePageChange();
            // history.push('/managemyorganisation/managerole')
            // if (this.props.handleSelect !== undefined)
            //   this.props.handleSelect('/managemyorganisation/managerole')
          }
        })
        .catch(error => {
          this.setState({
            error: error.response.errors
          })
        })
    }

  }
  onCheckBoxChange(checkName, isChecked, classification) {
    let isAllChecked = (checkName === 'all' && isChecked);
    let isAllUnChecked = (checkName === 'all' && !isChecked);
    var pack_func = this.state.allFunctions;
    const functions = Object.values(this.state.functions).map((city, index) => {
      const ObjectList = Object.values(city['values']).map((value, key) => {
        if ((isAllChecked || value.function_id === checkName) && parseInt(classification) === city.classificationId) {
          city.selectall = isAllChecked;
          value.checked = isChecked;
          pack_func.filter(function (i, key) {
            if (i.function_id == value.function_id) {
              pack_func[key].checked = (isChecked) ? true : false;
            }
          });
          return Object.assign({}, value, {
            value,
          });
        } else if (isAllUnChecked && parseInt(classification) === city.classificationId) {
          city.selectall = false;
          value.checked = false;
          pack_func.filter(function (i, key) {
            if (i.function_id == value.function_id) {
              pack_func[key].checked = (isChecked) ? true : false;
            }
          });
          return Object.assign({}, value, {
            value,
          });
        }
        return value;
      });
      Object.assign({}, city);
      return city;
    });
    this.setState({
      functions,
      allFunctions: pack_func,
    });
  }

  handleSelect(key) {
    this.setState({
      active_tab: key,
    })
  }


  render() {
    const { name_error, parent_role_error, roles, parentrole, roleType, showAS4Checkbox} = this.state;
    const { t } = this.state;
    // let accesableFunctions = [];

    var userres = Object.keys(this.state.functions).map(
      function (key) {
       {/*if (showAS4Checkbox) {
          accesableFunctions = this.state.functions[key]['values']  ? this.state.functions[key]['values'] : [];
        } else {
          accesableFunctions = this.state.functions[key]['values']  ? this.state.functions[key]['values'].filter(item => (item.fpublic || item.checked)) : [];
        }*/}
  	 return (
        <Tab eventKey={this.state.functions[key]['title']} title={t(this.state.functions[key]['title'])}>
          <Form.Group>
            <div className="col-lg-12">
              <CheckBoxList
                options={this.state.functions[key]['values']}
                // options={accesableFunctions}
                isCheckedAll={this.state.functions[key]['selectall']}
                onCheck={this.onCheckBoxChange.bind(this)}
                category={t(this.state.functions[key]['classificationId'])}
              />
            </div>
          </Form.Group>
        </Tab>
        )
      }, this
    );

    return (
      <div className=" row col-md-12">
        {this.state.roleID!=0 && <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>}
        <div style={{  }} className='col-md-11' >
          <Can
            perform="E_role"
            yes={() => (
              <div className='row' >
                <div className='col-md-12 mt-0 mb-0' >
                  <div className='card' >
                    <div className='card-body' >
                      <reactbootstrap.Container className="p-5">
                        <reactbootstrap.Form onSubmit={this.handleSubmit}>
                          <reactbootstrap.FormGroup>
                            <div className=" input-overall-sec ">
                              <reactbootstrap.InputGroup className="">
                                <div className="col-md-4">
                                  <reactbootstrap.InputGroup.Prepend>
                                    <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('User role')}: <span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                                  </reactbootstrap.InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd">
                                  <reactbootstrap.FormControl
                                    placeholder={t("User role")}
                                    aria-label="Functionname"
                                    aria-describedby="basic-addon1"
                                    value={this.state.name}
                                    onChange={e => this.setState({ name: e.target.value })}
                                    className="input_sw "
                                  />
                                  <div style={{ color: 'red' }} className="error-block mt-2">{name_error}</div>
                                </div>
                              </reactbootstrap.InputGroup>
                            </div>
                          </reactbootstrap.FormGroup>
                          <reactbootstrap.FormGroup>
                            <div className=" input-overall-sec ">
                              <reactbootstrap.InputGroup className="">
                                <div className="col-md-4">
                                  <reactbootstrap.InputGroup.Prepend>
                                    <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Search ')}: </reactbootstrap.InputGroup>
                                  </reactbootstrap.InputGroup.Prepend>
                                </div>
                                <div class="col-md-4 input-padd">
                                  <reactbootstrap.FormControl
                                    placeholder={t('Search function')}
                                    aria-label="Functionname"
                                    aria-describedby="basic-addon1"
                                    value={this.state.searchFunction}
                                    onChange={(e) =>this.handleSearch(e)}

                                    className="input_sw "
                                  />
                                </div>
                                &nbsp;&nbsp;&nbsp;
                                 {/*<Button onClick={(e)=>this.handleSearch(e)} disabled={!this.state.savevalue} color="primary">{t('Search')}</Button>*/}
                              </reactbootstrap.InputGroup>
                            </div>
                          </reactbootstrap.FormGroup>
                          {/*
                          <reactbootstrap.FormGroup>
                            <div className=" input-overall-sec ">
                              <reactbootstrap.InputGroup className="">
                                <div className="col-md-4">
                                  <reactbootstrap.InputGroup.Prepend>
                                    <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Parent role')}: <span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                                  </reactbootstrap.InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd">
                                  <reactbootstrap.FormControl
                                      as="select"
                                      name="parentrole"
                                      className="input_sw"
                                      value={parentrole}
                                      onChange={e => this.setState({ parentrole: e.target.value })} >
                                      // onChange={this.handleChange} >
                                      <option>Select</option>
                                      {roles.map(role => <option value={role.id}>{role.name}</option>)}
                                  </reactbootstrap.FormControl>
                                  <div style={{ color: 'red' }} className="error-block mt-2">{parent_role_error}</div>
                                </div>
                              </reactbootstrap.InputGroup>
                            </div>
                          </reactbootstrap.FormGroup>
                          */}
                          {showAS4Checkbox === 1 &&
                            <reactbootstrap.FormGroup>
                                <div class="col-md-6 ">
                                  <CheckBox
                                      name={t("AS4")}
                                      // tick={hide == 1 ? true : false}
                                      tick = {roleType}
                                      onCheck={e => this.setState({roleType: !roleType })}
                                      // value={'hide'}
                                  />
                                </div>
                            </reactbootstrap.FormGroup>
                          }
                          <reactbootstrap.FormGroup>
                            <div className=" input-overall-sec ">
                              <div className="col-md-4">
                                <reactbootstrap.InputGroup.Prepend>
                                  <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Roles and responsibilities')}:</reactbootstrap.InputGroup>
                                </reactbootstrap.InputGroup.Prepend>
                              </div>
                              {/* {this.state.responsibilites.map(functions =>
                          <reactbootstrap.Form.Group>
                            <reactbootstrap.Form.Check
                              onChange={this.handleCheck}
                              name={functions.id}
                              defaultChecked={(functions.checked) ? "true" : ""}
                              label={functions.name}
                              value={functions.id}
                              feedback="You must agree before submitting."
                            />
                          </reactbootstrap.Form.Group>)}*/}
                              <Tabs className="test-tab" activeKey={this.state.active_tab} onSelect={this.handleSelect} id="controlled-tab-example">
                                {userres}
                              </Tabs>
                            </div>
                          </reactbootstrap.FormGroup>
                          <FormGroup>
                          <div style={{ float: 'right' }} className="organisation_list">
                            <a  onClick={this.handleCancel} >{t('Cancel')}</a>
                            &nbsp;&nbsp;&nbsp;
                             <Button type="submit" disabled={!this.state.savevalue} color="primary">{t('Save')}</Button>
                          </div>
                          </FormGroup>

                        </reactbootstrap.Form>
                      </reactbootstrap.Container>
                    </div>
                  </div>
                </div>
              </div>
            )}
            no={() =>
              <AccessDeniedPage />
            }
          />
        </div>
      </div>
    );
  }
}
export default translate(Roles)
