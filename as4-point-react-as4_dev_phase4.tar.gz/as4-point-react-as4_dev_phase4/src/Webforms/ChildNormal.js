import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import Childformpopup from './Childformpopup';
import SecondCycleComonent from './../_components/DocumentCycleComponent/SecondCycleComonent';
// import { useReducer } from 'react';



class ChildNormal extends Component {
    constructor(props) {
      super(props)
      this.state = {
        status : false,
        showpopup: true,
        eventcancel: false,
      }
      this.preview = this.preview.bind(this)
    }


    preview () {
      datasave.service(window.GET_META_DATA + '/' + this.props.selectlistname, "GET")
              .then(result => {
                  if (result.docpath[0].doc_type_id <= 5) {
                    if (this.props.target==1){
                      window.open(window.location.origin + '/previewrevisionentities/' + this.props.selectlistname, '_blank');
                    }
                    else {
                      let url = window.location.origin + '/previewrevisionentities/' + this.props.selectlistname;
                      this.setState({
                        url : url,
                        status : true,
                      })
                    }
                  }
                  // nosonar
                  /*else{
                    if (this.props.target==1){
                      window.open('/Common/' + this.props.selectlistname);
                    }
                    else {
                      let url = window.location.origin + '/Common/' + this.props.selectlistname;
                      this.setState({
                        url : url,
                        status : true,
                      })
                    }
                  }*/

              });

    }
    changeStatus (status) {
      this.setState({
        status : status,
      })
    }

    openURL(url){
      if (this.props.target==1){
        window.open(url,"_blank");
      }else{
        window.open(url,"_self");
      }
    }
    render () {
      // let urlbyuser = this.state.url;
      // let matchstring = '/http/'
      let match = this.props.url.match(/http/);
    //  alert(match);
     console.log(match);
     
      let url = (match==null||match==undefined||match=='')?"http://" + this.props.url:this.props.url;
      if(this.state.status == true) {
        let previewurl = this.state.url;
         return(
           <Childformpopup url = {previewurl} status = {true} changeStatus = {this.changeStatus.bind(this)} doc_id = {this.props.selectlistname} />
         )
      }
        if (this.props.url !== null && this.props.url!= "") {
          return (
            <>
              {this.props.caption &&
                <reactbootstrap.Button onClick={()=>this.openURL(url)} disabled = {this.props.disable_field}>{this.props.caption}</reactbootstrap.Button>
              }
               {this.props.caption == "" || this.props.caption == null &&
              <a href = {url} style ={this.props.disable_field?{cursor:'none',textDecoration:"underline",color:'blue'}:{cursor:"pointer",textDecoration:"underline",color:'blue'}}> {this.props.url} </a>
               } 
            </>
          )
        }
        else {
          return (
            <>
              {this.props.caption &&
                <reactbootstrap.Button onClick={() =>this.preview()} disabled = {this.props.disable_field}>{this.props.caption}</reactbootstrap.Button>
              }
              {this.props.caption == "" || this.props.caption == null &&
              <a onClick={this.props.disable_field?'':this.preview} style ={this.props.disable_field?{cursor:'none',textDecoration:"underline",color:'grey'}:{cursor:"pointer",textDecoration:"underline",color:'blue'}}> {this.props.normal_name} </a>}

            </>
          )
        }
    }
}

export default ChildNormal;
