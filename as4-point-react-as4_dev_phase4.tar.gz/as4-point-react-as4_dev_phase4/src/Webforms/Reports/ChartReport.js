import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import Chart from 'react-google-charts';
import Pagination from 'react-bootstrap/Pagination'
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../../language';
import AlertPopUpComponent from '../AlertPopUpComponent';
import { store } from '../../store';
import Template from './Template';
import { CustomPicker } from 'react-color';
import { GithubPicker } from 'react-color';
import './Template.css' ;
import ReactFC from 'react-fusioncharts';
import FusionCharts from 'fusioncharts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import MultiSelect from './../../_components/MultiSelect';
import FilterCharts from './FilterCharts';
import CreateReportWindow  from '../WebReports/CreateReportWindow';
import * as Reactbootstrap from 'react-bootstrap';
import DynamicReport from './DynamicReport';
ReactFC.fcRoot(FusionCharts, Widgets, FusionTheme);

class ChartReport extends Component {
    constructor(props) {
      let date = new Date(new Date().setDate(new Date().getDate() - 30));
      let day = (date.getDate() * 10 >= 100) ? date.getDate() : '0' + date.getDate();
      let m = date.getMonth() + 1,t = new Date().getMonth() + 1;
      let month = (m * 10 >= 100) ? m : '0' + m;
      let fromDate = date.getFullYear() + '-' + month + '-' + day;
      let toMonth = (t * 10 >= 100) ?  t : '0' + t;
      let toDay = (new Date().getDate() * 10 >= 100) ? new Date().getDate() : '0' + new Date().getDate();
      let toDate = new Date().getFullYear() + '-' + toMonth + '-' + toDay;
        super(props)
       this.state = {
            t: props.t,
            chartName: '',
            inputValue: '',     //for title
            reqdata: '',        //for sending to save chart data
            color: '',          //color select value on change
            col: [],            //color array
            check: 'false',     //for color change validity
            colorIndex: '',     //color index selected
            radioVal:'1',       //for date type selected in dynamicreports.js
            dateOptions:window.DATE_OPTIONS[4],  //for time selected
            chartOptions : '',
            subtitleValue : [],
            newchartName : '',  //finalchart name
            chartType :'',
            selectedType: 1,
            subtitle: '',
            dimType: '',
            textType: '',
            legendType: '',
            columnType: '',
            lineType: '',
            query: false,
            chartData: '',
            chartCheck:false,    //check chart to saved chart r new one
            warning: false,
            query_new:'',
            resultCheck:[],     //selected webelement ids
            checkCondition: false,  //valid to check chart to show r not
            change:false,       //check before any query added options selected
            response:[],
            resultData:[],      //sfiltered options data
            response_data:[],  //important data from query
            hAxis:'',
            vAxis:'',
            personChart:'',     //name,element,time basis
            webEleAxis:'',      //check above validity
            xOptions:'',
            yOptions:'',
            finalNumber:'',
            initialNumber:'',
            rankInputValue:'',
            finalRanges:'',
            checkRange:false,
            updateButton:false,
            rankValueIndex:'',
            gaugeDisplay:'',
            reportCountcall:'monthwise',     //send to dynamicReport.js for not calling recuresively
            dynamicReport: false,
            dynamicReportData:'',           //for array got from dynamic reports used for selection opotions
            dateCheck:false,                //to check dates are existed in date fields
            checkSubmit:false,              //valid when dates are existed and changed in this component
            reportView: false,
            count:0,
            fromDate: fromDate,
            toDate: toDate,
            filterArray:'',
            filterCount:0,
            xCount:0,
            yCount:0,
        }
    this.chartTypes = this.chartTypes.bind(this);
    this.chartData = this.chartData.bind(this);
    this.getProperties = this.getProperties.bind(this);
    this.inputChange = this.inputChange.bind(this);
    this.dimType = this.dimType.bind(this);
    this.handleChangeComplete = this.handleChangeComplete.bind(this);
    this.subTitle = this.subTitle.bind(this);
    this.handleChangeMultiStandard = this.handleChangeMultiStandard.bind(this);
    this.textType = this.textType.bind(this);
    this.legendType = this.legendType.bind(this);
    this.columnType = this.columnType.bind(this);
    this.lineType = this.lineType.bind(this);
    this.saveOptions = this.saveOptions.bind(this);
    this.showData = this.showData.bind(this);
    this.handleBack = this.handleBack.bind(this);
    this.showChart = this.showChart.bind(this);
    this.hvAxis = this.hvAxis.bind(this);
    this.hAxis = this.hAxis.bind(this);
    this.vAxis = this.vAxis.bind(this);
    this.selectPersonChart = this.selectPersonChart.bind(this);
    this.xOptions = this.xOptions.bind(this);
    this.yOptions = this.yOptions.bind(this);
    this.initialnumberType = this.initialnumberType.bind(this);
    this.finalnumberType = this.finalnumberType.bind(this);
    this.rankinputChange = this.rankinputChange.bind(this);
    this.handleeditOnClick = this.handleeditOnClick.bind(this);
    this.handledeleteOnClick = this.handledeleteOnClick.bind(this);
    this.gaugeDisplay = this.gaugeDisplay.bind(this);
    this.handleDynamicBack = this.handleDynamicBack.bind(this);
    this.validationsLast = this.validationsLast.bind(this);
    }

   async  UNSAFE_componentWillMount(){
      if(this.props.id !== 'chart'){
     await datasave.service(window.CHART_REPORTS_DATA + '/' + this.props.webform_id + '/' + this.props.id,'GET','').then( async (response)=>{
        let options = JSON.parse(response.json_options.split(','));
      await  this.props.prefillquery(JSON.parse(response.json_query))
        this.setState({
          query_new: JSON.parse(response.json_query),
         chartOptions: options,
         selectedType: window.WEBFORMREPORTTYPES[response.chart_type],
         inputValue: options.title,
         chartName:  window.WEBFORMREPORTTYPES[response.chart_type].label,
         dimType: window.REPORTS_DIM_TYPE[options.is3D],
         textType: window.REPORTS_TEXT_SHOW[options.pieSliceText],
         lineType: window.REPORTS_LINE_TYPE[options.curveType],
         legendType: window.REPORTS_LEGEND_TYPE[options.legend.position],
         col: options.colors,
         chartCheck: true,
         chartType: response.chart_type,
         subtitleValue:JSON.parse(response.subtitle),
         resultData: JSON.parse(response.filter_options),
         hAxis: options.hAxis,
         vAxis: options.vAxis,
         xOptions: options.xOptions,
         yOptions: options.yOptions,
         personChart: window.SELECTED_TYPE_CHART[options.personChart],
         initialNumber: options.initialNumber,
         finalNumber: options.finalNumber,
         gaugeDisplay: window.GAUGE_DISPLAY[options.gaugeDisplay],
         finalRanges: options.finalRanges,
         updateButton: options.updateButton,
         rankInputValue: options.rankInputValue,
         checkRange: options.checkRange,
         webEleAxis:options.webEleAxis,
         columnType: window.REPORTS_COLUMN_TYPE[options.columnType],
         created_at:response.created_at,
        },()=>this.props.prefillquery(this.state.query));

      });

     }
    }

    dimType (event)
    {
      this.setState({
        dimType: event,
        change: true,
      });
    }

    handleChangeMultiStandard(event)
    {
      const {t} =this.state;
        if(this.state.chartCheck === true){
          OCAlert.alertError(t('should not select other charts'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
        if(this.state.chartCheck === false){
        this.setState({
          selectedType: event,
          inputValue: '',
          chartName: event.label,
          chartType: event.value,
          change: true,
          dateCheck: false,
          dimType:'',
          subtitle:'',
          legendType:'',
          textType:'',
          columnType:'',
          lineType:'',
          xOptions:'',yOptions:'',hAxis:'',vAxis:'',checkCondition:false,
          dynamicReport:false,
          personChart:'',
          gaugeDisplay:'',
          reportView: false,
          reportCountcall:'monthwise',
          count:0,
          radioVal:1,
        });
      }
    }

   chartTypes()
   {
     var table = [];
     let standard_options = window.WEBFORMREPORTTYPES;

        table.push(<MultiSelect
            options={standard_options}
            disabled={false}
            standards = {this.state.selectedType}
            isMulti={false}
            handleChange={this.handleChangeMultiStandard}
        />);

        return table;

   }

   handleChangeComplete = (color) => {
    this.setState({ color: color.hex });
     if(typeof(color) === 'number'){
         this.setState({ colorIndex : color });
     }
     if(this.state.color)
     {
        this.state.col.splice(this.state.colorIndex,1,this.state.color);
         this.setState({
           color: '',
         });
     }
     this.setState({
       check:false,
     })
   };

    subTitle (e)
    {
      const {name,value} = e.target;
      var res = value.split(",");
      this.setState({
        [name] : value,
        subtitle : res,
        change: true,
      });
    }

    textType(event)
    {
       this.setState({
          textType : event,
          change:true,
       });
    }

    legendType(event)
    {
      this.setState({
         legendType : event,
         change:true,
      });
    }

    columnType(event)
    {
      this.setState({
         columnType : event,
         change:true,
      });
    }

    lineType(event)
    {
      this.setState({
         lineType : event,
         change:true,
      });
    }

   chartData()
    {
     const { t } = this.state;
     let placeholder = 'Enter Two SubTitles seperated with comma';
     let numbers = [];
     let arr = this.state.finalRanges;
     let add = this.state.updateButton === true ? t('Update') : t('Add');
     let check = this.state.finalRanges !== '' ? t('Add more') : t('Add');
     if(this.state.chartType === 2){
       for(var i = 0;i <= 100;i++){
         numbers.push({
           label:i,
           value:i,
           });
       }
     }
     let table = [];
      table.push(
            <div className= 'options'>
                <reactbootstrap.Form>
                    <reactbootstrap.Col className="chart-types col-md-6" style={{padding: '10px 0px'}}>
                        <reactbootstrap.Form.Group className="row justify-content-center" controlId="formchartid">
                               <reactbootstrap.Table bordered size="md" className = "download-test">
                                 <tbody>
                                   <tr><reactbootstrap.Form.Label className="col-md-8">{t('Charts:')}<span style={{color:'red'}}>*</span></reactbootstrap.Form.Label>
                                     <div className="col-md-8 chart-select">
                                      {this.chartTypes()}
                                     </div>
                                     {this.state.chartName === 'PieChart' &&
                                      <div>
                                       <reactbootstrap.Form.Label className="col-md-5 " >{t('Dimension:')}<span style={{color:'red'}}>*</span></reactbootstrap.Form.Label>
                                       <div className="col-md-8 chart-select">
                                         <MultiSelect
                                          options={window.REPORTS_DIM_TYPE}
                                          disabled={false}
                                          standards={this.state.dimType}
                                          isMulti={false}
                                          handleChange={this.dimType}/>
                                       </div>
                                       <reactbootstrap.Form.Label className="col-md-12" >{t('Text show:')}<span style={{color:'red'}}>*</span></reactbootstrap.Form.Label>
                                       <div className="col-md-8 chart-select">
                                         <MultiSelect
                                          options={window.REPORTS_TEXT_SHOW}
                                          disabled={false}
                                          standards={this.state.textType}
                                          isMulti={false}
                                          handleChange={this.textType}/>
                                       </div>
                                     </div>
                                     }
                                     {((this.state.chartName === 'BarChart') || (this.state.chartName === 'ColumnChart')) &&
                                      <div><reactbootstrap.Form.Label className="col-md-12" >{'Columns:'}<span style={{color:'red'}}>*</span></reactbootstrap.Form.Label>
                                       <div className="col-md-8 chart-select" >
                                         <MultiSelect
                                          options={window.REPORTS_COLUMN_TYPE}
                                          disabled={false}
                                          standards={this.state.columnType}
                                          isMulti={false}
                                          handleChange={this.columnType}/>
                                        </div>
                                     </div>
                                     }
                                     {this.state.chartName === 'LineChart' &&
                                      <div><reactbootstrap.Form.Label className="col-md-3" >{'Line Shape:'}<span style={{color:'red'}}>*</span></reactbootstrap.Form.Label>
                                        <div className="col-md-8 chart-select" style={{padding: '0px'}}>
                                          <MultiSelect
                                           options={window.REPORTS_LINE_TYPE}
                                           disabled={false}
                                           standards={this.state.lineType}
                                           isMulti={false}
                                           handleChange={this.lineType}/>
                                      </div></div>
                                     }
                                     <div>
                                     <reactbootstrap.Form.Label className="col-md-12">
                                         {t('Title')}:<span style={{color:'red'}}>*</span>
                                     </reactbootstrap.Form.Label>
                                     <reactbootstrap.Form.Control className="col-md-8"
                                         type="text"
                                         name ="inputValue"
                                         value={this.state.inputValue}
                                         onChange={this.inputChange}
                                         placeholder="Enter Title"
                                     />
                                     </div>
                                     <div>
                                       <reactbootstrap.Form.Label className="col-md-12" >{t('Legend:')}<span style={{color:'red'}}>*</span></reactbootstrap.Form.Label>
                                        <div className="col-md-8 chart-select" >
                                          <MultiSelect
                                           options={window.REPORTS_LEGEND_TYPE}
                                           disabled={false}
                                           standards={this.state.legendType}
                                           isMulti={false}
                                           handleChange={this.legendType}/>
                                        </div>
                                      </div>
                                    <div>
                                    {this.state.chartName === 'PieChart' &&
                                    <div>
                                    <reactbootstrap.Form.Label className="col-md-12" >
                                        {t('Subtitles')}:<span style={{color:'red'}}>*</span>
                                    </reactbootstrap.Form.Label>
                                    <reactbootstrap.Form.Control className="col-md-8"
                                        type="text"
                                        name ="subtitleValue"
                                        value={this.state.subtitleValue}
                                        onChange={this.subTitle}
                                        placeholder={placeholder}
                                    />
                                    </div>
                                    }
                                    </div>
                                    {this.state.chartName !== 'PieChart' &&
                                     this.state.response_data.length > 0 &&
                                     this.state.chartName !== '' &&
                                     this.state.chartName !== 'Gauge' &&
                                    <div>{this.multiSelectAxisfilter()}</div>
                                    }
                                    {this.state.chartName === 'Gauge' &&
                                     this.state.response_data.length > 0 &&
                                     this.state.chartName !== '' &&
                                    <div>{this.valuesFilter()}</div>
                                    }
                                    {this.state.chartName === 'Gauge' &&
                                    <div className="col-md-8 chart-select" >
                                    <reactbootstrap.Form.Label className="col-md-12" >{t('Chart display:')}<span style={{color:'red'}}>*</span></reactbootstrap.Form.Label>
                                    <MultiSelect
                                     options= {window.GAUGE_DISPLAY}
                                     disabled={false}
                                     standards={this.state.gaugeDisplay}
                                     isMulti={false}
                                     handleChange={this.gaugeDisplay}/>
                                    </div>
                                    }
                                   </tr>
                                 </tbody>
                               </reactbootstrap.Table>
                               <div className="col-md-12">
                              <reactbootstrap.Button onClick={this.showChart} variant="primary" >
                                          {t('Show chart')}
                              </reactbootstrap.Button>
                              <reactbootstrap.Button onClick={this.saveOptions} variant="primary" >
                                          {t('Save data')}
                              </reactbootstrap.Button>
                              </div>
                              {this.state.query === true && <reactbootstrap.Form.Text style={{ color: "red" }} >
                                  {t('Query is empty')}
                              </reactbootstrap.Form.Text>}
                              {this.state.warning === true && <reactbootstrap.Form.Text style={{ color: "red" }} >
                                  {t('One or More fields are empty')}
                              </reactbootstrap.Form.Text>}
                        </reactbootstrap.Form.Group>
                    </reactbootstrap.Col>
                    {this.state.chartName === 'Gauge' &&
                    <reactbootstrap.Col className="performance-range col-md-6" style={{float: 'right'}}>
                    <div>
                    <reactbootstrap.Form.Label className="col-md-12" style = {{textAlign:'center'}}>
                        {t('Performance ranking')}:<span style={{color:'red'}}>*</span>
                    </reactbootstrap.Form.Label>
                    <div style = {{textAlign:'center'}}>
                    <reactbootstrap.Table bordered size="md">
                      <tbody>
                        <tr>
                         <th>{t('Names')}</th>
                         <th>{t('Range')}</th>
                         <th>{t('Actions')}</th>
                        </tr>
                        {this.state.finalRanges !== '' &&
                          Object.keys(arr).map((key,index)=>{
                          return (
                        <tr>
                        <td>{key}</td>
                        <td>{arr[key].initial }{' <= '}{arr[key].final}</td>
                        <td>
                        <reactbootstrap.Button onClick={(e) => this.handleeditOnClick(key,arr[key],index)} style = {{margin:'2px'}} disabled={false}>Edit</reactbootstrap.Button>
                        <reactbootstrap.Button onClick={(e) => this.handledeleteOnClick(key,arr[key],index)} style = {{margin:'2px'}} disabled={false}>Delete</reactbootstrap.Button>
                        </td>
                        </tr>)})}
                      </tbody>
                    </reactbootstrap.Table>
                    {this.state.finalRanges === '' &&
                      <div>{t('No performance ranges added click on below button to add')}</div>
                    }
                    <div><reactbootstrap.Button onClick={(e) => this.addMore()} disabled={false} style = {{float:'left'}}>{check}</reactbootstrap.Button></div>
                    </div>
                    {this.state.checkRange &&
                    <div>
                    <reactbootstrap.Table bordered size="md" >
                      <tbody>
                        <tr>
                        <td>
                        <reactbootstrap.Form.Label>
                            {t('Name')}:
                        </reactbootstrap.Form.Label>
                    <reactbootstrap.Form.Control
                        type="text"
                        name ="rankInputValue"
                        value={this.state.rankInputValue}
                        onChange={this.rankinputChange}
                        placeholder={t("Enter name")}
                    /></td>
                    <td>
                    <reactbootstrap.Form.Label>
                        {t('Initial')}:
                    </reactbootstrap.Form.Label>
                    <MultiSelect
                     options={numbers}
                     disabled={false}
                     standards={this.state.initialNumber}
                     isMulti={false}
                     handleChange={this.initialnumberType}/>
                     </td>
                     <td>
                     <reactbootstrap.Form.Label >
                         {t('Final')}:
                     </reactbootstrap.Form.Label>
                     <MultiSelect id = 'numberSelect'
                      options={numbers}
                      disabled={false}
                      standards={this.state.finalNumber}
                      isMulti={false}
                      handleChange={this.finalnumberType}/>
                      </td>
                    <td>
                     <reactbootstrap.Button  title={add} onClick={(e) => this.handleaddOnClick(e)} disabled={false} style = {{float:'left'}}>{add}</reactbootstrap.Button>
                     <reactbootstrap.Button  title="close"  onClick={(e) => this.CloseOnClick(e)} disabled={false}>{t('Close')}</reactbootstrap.Button>
                    </td>
                    </tr>
                    </tbody>
                    </reactbootstrap.Table>
                    </div>}</div>
                    </reactbootstrap.Col>
                  }
                 </reactbootstrap.Form>
            </div>
       );

     return table;
    }

    gaugeDisplay(e){
      this.setState({gaugeDisplay:e})
    }

   initialnumberType(e){
    this.setState({initialNumber:e});
   }

   finalnumberType(e){
     this.setState({finalNumber:e})
   }

   CloseOnClick(){
     this.setState({checkRange:false});
   }

   async handleaddOnClick(){
     const {t} =this.state;
     let dummy = new Object();
     let count = 0;
     let indexValue;
     let ranges = this.state.finalRanges;
     if((this.state.initialNumber === '' ) || (this.state.finalNumber === '')){
       OCAlert.alertError(t('select any values'), { timeOut: window.TIMEOUTNOTIFICATION });
        count++;
     }
     if(this.state.rankInputValue === ''){
       count++;
       OCAlert.alertError(t('give name'), { timeOut: window.TIMEOUTNOTIFICATION });
     }
     if(this.state.initialNumber.value > this.state.finalNumber.value){
       count++;
       OCAlert.alertError(t('initial value should be lesser than final value'), { timeOut: window.TIMEOUTNOTIFICATION });
     }
     if(ranges !== ''){
       Object.keys(ranges).map((key,index)=>{
         if(this.state.updateButton === true){
           indexValue = Object.keys(ranges)[this.state.rankValueIndex];
           if(index !== this.state.rankValueIndex){
            count = this.checkErrors(ranges,key,count);
           }
         }
         else {
           count = this.checkErrors(ranges,key,count);
         }
       })
       if(count === 0 && this.state.updateButton === true){
        delete ranges[indexValue];
        dummy['initial'] = this.state.initialNumber.value;
        dummy['final'] = this.state.finalNumber.value;
        ranges[this.state.rankInputValue] = dummy;
       }
       if(count === 0 && this.state.updateButton === false){
        ranges[this.state.rankInputValue] = [];
        dummy['initial'] = this.state.initialNumber.value;
        dummy['final'] = this.state.finalNumber.value;
        ranges[this.state.rankInputValue] = dummy;
        this.setState({finalRanges:ranges});
      }
     }
     else {
      let arr = new Object();
      arr['initial'] = this.state.initialNumber.value;
      arr['final'] = this.state.finalNumber.value;
      dummy[this.state.rankInputValue] = [];
      dummy[this.state.rankInputValue] = arr;
      if(count === 0)
      this.setState({finalRanges:dummy});
     }
     if(count === 0){
     this.setState({
       checkRange:false,
       initialNumber:'',
       finalNumber:'',
       rankInputValue:'',
       updateButton:false,
     });
    }
   }

   checkErrors(ranges,key,count){
     const {t} =this.state;
     if(key === this.state.rankInputValue){
       OCAlert.alertError(t('name already existed'), { timeOut: window.TIMEOUTNOTIFICATION });
       count++;
     }
     if((ranges[key].initial === this.state.initialNumber.value) || (ranges[key].final === this.state.finalNumber.value)){
       OCAlert.alertError(t('values already given'), { timeOut: window.TIMEOUTNOTIFICATION });
       count++;
     }
     if((ranges[key].initial <= this.state.initialNumber.value  && this.state.initialNumber.value <= ranges[key].final) ||
       (ranges[key].initial <= this.state.finalNumber.value && this.state.finalNumber.value <= ranges[key].final)){
       OCAlert.alertError(t('Range exists'), { timeOut: window.TIMEOUTNOTIFICATION });
       count++;
     }

     return count;
   }

  rankinputChange(e){
    const {name,value} = e.target;
    this.setState({[name]:value});
  }

  addMore(){
    this.setState({
      checkRange:true,
      initialNumber:'',
      finalNumber:'',
      rankInputValue:'',
      updateButton:false,
    });
  }

   handleeditOnClick(name,value,index){
      this.setState({
        initialNumber:{label:value.initial,value:value.initial},
        finalNumber:{label:value.final,value:value.final},
        rankInputValue:name,
        checkRange: true,
        updateButton: true,
        rankValueIndex:index,
      })
   }

   handledeleteOnClick(name,key,index){
     let arr = this.state.finalRanges;
     let valueIndex = Object.keys(this.state.finalRanges).indexOf(this.state.rankInputValue);
     if(index === valueIndex){
       delete arr[name];
       this.setState({
         checkRange:false,
         finalRanges:arr
       });
     }
     else {
      delete arr[name];
      this.setState({finalRanges:arr});
    }
   }

    inputChange(e){
      const  {name,value} = e.target;
      this.setState({
        [name]:value,
      });
    }

    async showChart(){
      let charttypes = [0,1,3],resultArr = [];
      if(this.state.dateCheck === false){   //initial time to show chart
      if(!this.state.chartCheck) {    //to check for saved chart
        await this.setState({col: '',reportView: true});
      }
      else {
          this.setState({reportView:true});
      }
     }
      if(this.state.dateCheck === true){   //if chart is already displayed and any modifications in this component to update
        this.setState({checkSubmit:true,count:0,reportView:true});
      }
    }

    validationsLast(object){
      const {t} =this.state;
      if(((object.chartOptions === '') || (object.newchartName === '')) || ((this.state.query_new === '') || (object.warning === true))){
       OCAlert.alertError('Data is insufficient', { timeOut: window.TIMEOUTNOTIFICATION });
       this.setState({checkCondition: false,dynamicReport: true,warning:object.warning,count:0});
      }
      else{
       this.setState({
         checkCondition: true,
         dynamicReport: true,
         chartOptions: object.chartOptions,
         newchartName: object.newchartName,
         col: object.col,
         chartData: object.chartData,
         reqdata:object.reqdata,
         warning: object.warning,
       });
      }
      if((object.chartData === '' )|| (object.chartData[1] === undefined)){
        OCAlert.alertError(t('Error in getting data or No data for chart'), { timeOut: window.TIMEOUTNOTIFICATION });
        this.setState({checkCondition: false,dynamicReport: true});
      }
    }

   async getProperties(resultArr) {
     // if(this.state.chartData.length === 0){
     //  let data = await this.setQuery();
     // }
     let width,height,chartTypes = [0,1,3,4];
     if(this.state.chartType === 2){
       width = '350px';
       height = '350px';
     }
     if(this.state.chartType === 4){
        width = '500px';
        height = '500px';
     }
     if(chartTypes.includes(this.state.chartType)){
       width = '900px';
       height = '900px';
     }
     let subtitle = this.state.subtitle !== '' ? this.state.subtitle : (this.state.chartCheck === true) ? this.state.subtitleValue : this.state.subtitle;
     let data = {
       query:(this.state.query_new === '')?this.props.query():this.state.query_new,
       subtitle:subtitle,
       webform_id: this.props.webform_id,
       charttype: this.state.chartType,
     }
     let length = resultArr.length;
     let array_color = await this.setColor(length);  //for colors
     let array = await this.showData(array_color);  //for validations
     let array_options =
    {
      legend : { position : this.state.legendType === undefined ? '' : this.state.legendType.value},
      title : this.state.inputValue,
      pieSliceText : this.state.textType === undefined ? '' : this.state.textType.value,
      colors : this.state.col === '' ? array_color : this.state.col,
      curveType : this.state.lineType === undefined ? '' : this.state.lineType.value,
      is3D : this.state.dimType === undefined ? '' : this.state.dimType.value,
      width: width,
      height: height,
      minorTicks: (this.state.chartType === 2)? 5 : '',
    }
     var changebarChart = this.state.chartName !== 'BarChart' ? this.state.chartName : (this.state.columnType.value !== undefined ? this.state.columnType.value : 'BarChart') ;
     let object = {
       chartOptions : array_options,
       newchartName : changebarChart,
       col : array_color,
       chartData: resultArr,
       reqdata: data,
       warning: array.warning,
     };
    this.validationsLast(object);   //final array data for charts display with options
   }

   setColor(length)
   {
     var array_color = [];
     for (var i = 1; i < length; i++) {
        var color =  '#' + Math.floor(Math.random()*16777215).toString(16);
        array_color.push(color);
     }
     this.setState({col:''});

    return array_color;
   }

   async setQuery()
   {    //used for query builder
     let query;
     let arr = [];
     let subtitle = this.state.subtitle !== '' ? this.state.subtitle : (this.state.chartCheck === true) ? this.state.subtitleValue : this.state.subtitle;
     let data = {
       query:(this.state.query_new === '')?this.props.query():this.state.query_new,
       subtitle:subtitle,
       checkResult:this.state.resultCheck,
       webform_id: this.props.webform_id,
       charttype: this.state.chart_type,
     }
     if(!this.state.chartCheck) {
       this.setState({col: ''});
     }
     if(this.state.resultCheck.length === 0){
       this.setState({query_new:this.props.query()});
     }
     await datasave.service(window.QUERY_RESULT ,'POST',data).then((response) => {
       this.setState({
         chartData : response,
       });
     });

     return data;
   }

   showData(array_color)
   {     //this is for validations
     const { chartName } = this.state;
     let warning = [],array;
     array = this.arrayOptions(array_color);
     Object.keys(array).map(function(key){
       if(array[key] === ''){
         if(key === 'title'){
           warning.push(true);
         }
         if(chartName === 'PieChart'){
           if(key === 'pieSliceText' || key === 'is3D') {
              warning.push(true);
           }
         }
         if(chartName === 'LineChart'){
             if(key === 'curveType'){
                warning.push(true);
             }
         }
         if(chartName === 'BarChart'){
           if(this.state.columnType.value === ''){
              warning.push(true);
           }
         }
         if(chartName !== 'PieChart' && chartName !== 'Gauge'){
           if(this.state.hAxis === '' || this.state.vAxis === '' || this.state.personChart === ''){
             warning.push(true);
           }
         }
         if(chartName === 'Gauge'){
           if((this.state.finalRanges === '') || (this.state.xOptions === '')){
              warning.push(true);
           }
           if((this.state.gaugeDisplay === '') || (this.state.yOptions === '')){
             warning.push(true);
           }
         }
       }
       if(key === 'legend' && (array[key].position === undefined || array[key].position === '')){
         warning.push(true);
       }
     },this);

     let check = (warning[0] === undefined)? false : true;
     let object = {
       array:array,
       warning:check,
     };

     return object;
   }

   arrayOptions(array_color){
     let array =
     {
       legend : { position : (this.state.legendType === undefined || this.state.legendType === '') ? '' : this.state.legendType.num},
       title : this.state.inputValue,
       pieSliceText : (this.state.textType === undefined || this.state.textType === '') ? '' : this.state.textType.num,
       colors : (this.state.col == '') ? array_color : this.state.col,
       columnType: (this.state.columnType === undefined || this.state.columnType === '') ? '' : this.state.columnType.num,
       curveType : (this.state.lineType === undefined || this.state.lineType === '') ? '' : this.state.lineType.num,
       is3D : (this.state.dimType === undefined || this.state.dimType === '') ? '' : this.state.dimType.num,
       hAxis: (this.state.hAxis === undefined || this.state.hAxis === '') ? '' : this.state.hAxis,
       vAxis: (this.state.vAxis === undefined || this.state.vAxis === '') ? '' : this.state.vAxis,
       xOptions: (this.state.xOptions === undefined || this.state.xOptions === '') ? '' : this.state.xOptions,
       yOptions: (this.state.yOptions === undefined || this.state.yOptions === '') ? '' : this.state.yOptions,
       personChart: (this.state.personChart === undefined || this.state.personChart === '') ? '' : this.state.personChart.num,
       gaugeDisplay: (this.state.gaugeDisplay === undefined || this.state.gaugeDisplay === '') ? '' : this.state.gaugeDisplay.value,
       finalRanges: (this.state.finalRanges === undefined || this.state.finalRanges === '') ? '' : this.state.finalRanges,
       rankInputValue: (this.state.rankInputValue === undefined || this.state.rankInputValue === '') ? '' : this.state.rankInputValue,
       initialNumber: (this.state.initialNumber === undefined || this.state.initialNumber === '') ? '' : this.state.initialNumber,
       finalNumber:(this.state.finalNumber === undefined || this.state.finalNumber === '') ? '' : this.state.finalNumber,
       checkRange:(this.state.checkRange === undefined || this.state.checkRange === '') ? '' : this.state.checkRange,
       updateButton:(this.state.updateButton === undefined || this.state.updateButton === '') ? '' : this.state.updateButton,
       webEleAxis: (this.state.webEleAxis === undefined || this.state.webEleAxis === '') ? '' : this.state.webEleAxis,
     };

     return array;
   }

   async saveOptions()
   {
     const {t} =this.state;
     let array,queryData,subtitle,warning,options;
     subtitle = this.state.subtitle !== '' ? this.state.subtitle : (this.state.chartCheck === true) ? this.state.subtitleValue : this.state.subtitle;
      if(this.state.chartOptions === '' || this.state.chartData.length === 0){
          queryData = {
          query:(this.state.query_new === '')?this.props.query():this.state.query_new,
          subtitle:subtitle,
        };
      }else {
        queryData = this.state.reqdata;
      }
      array = this.showData(this.state.col);
      options = array.array;
      warning = array.warning;
      let checkResult = (((subtitle.length === 1 || subtitle.length === 0) || subtitle.length > 2) && this.state.chartType === 4) ? false : true;
      let time = Math.trunc(new Date().getTime()/1000);
      let data =
      {
        'webform_id' : this.props.webform_id,
        'type' : '1',
        'charttype' : this.state.chartType,
        'json_options' : options,
        'json_query' : queryData,
        'selectedIds' : this.state.resultCheck,
        'title' : this.state.inputValue,
        'filter_options':this.state.resultData,
        'created_at': (this.state.created_at === '') ? time : this.state.created_at,
        'updated_at': time,
        'lock_filter': this.state.filterArray,
      };
    if(warning === false && this.state.query_new !== '' && this.state.resultCheck !== '' && options !== '' && checkResult === true){
      await datasave.service(window.CUSTOM_REPORTS , 'POST', data).then((response) => {
         if(response.status === 200){
          OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
          const {history} =  this.props;
          history.push('/reports?q=Webform_report');
          }
         else {
          OCAlert.alertError(t('Data not saved'), { timeOut: window.TIMEOUTNOTIFICATION });
         }
         });
    }
    else {
      OCAlert.alertError(t('Data is insufficient'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
   }


   handleBack(data){    //filtercharts.js call back function
     const {t} =this.state;
    if(Object.values(data).length > 0){
      let arr = [];
    if(data.selectedWebElementsIds != ''){
      OCAlert.alertSuccess(t('Filter done successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
    else{
      OCAlert.alertError(t('Select any options'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
    Object.values(data.selectedWebElementsData).map((key,index)=>{
      if(key.lock_filter === 1){
        arr.push(key.id);
      }
    })
    this.setState({
      query_new: data.query,        //set query
      resultCheck: data.selectedWebElementsIds,
      resultData: data.selectedWebElementsData,
      filterArray: arr,   //lock filter
      filterCount:1,    //send to back not to call recuresively
      response_data: data.response,   //important for all charts (required data)
    });
   }
  }

  multiSelectAxisfilter(){
    let hoptions = [];//haxis options for axis charts
    let voptions = []; //vaxis options for axis charts
    const {t} = this.state;
    hoptions.push({label:'count',value:'count',name:'hAxis'});
    voptions.push({label:'count',value:'count',name:'vAxis'});
    this.state.response_data[0].map((key)=>{
      if(key !== 'updated_at'){
       hoptions.push({
         label:key.split('||')[0],
         value:key.split('||')[1],
         name:'hAxis'
       });
       voptions.push({
         label:key.split('||')[0],
         value:key.split('||')[1],
         name:'vAxis'
       });
      }
    });
    return(
      <div>
      <div>
    <td style = {{width:'300px'}}>
    <reactbootstrap.Form.Label className="col-md-12" >
        {t('H-Axis')}(-):<span style={{color:'red'}}>*</span>
    </reactbootstrap.Form.Label>
    <MultiSelect
     options={hoptions}
     id = "haxis"
     standards={this.state.hAxis}
     value = {[]}
     handleChange={(e)=>this.hAxis(e)}/>
     </td>
     <td style = {{width:'300px'}}>
    <reactbootstrap.Form.Label className="col-md-12" >
        {t('V-Axis')} (|):<span style={{color:'red'}}>*</span>
    </reactbootstrap.Form.Label>
    <MultiSelect
     options={voptions}
     standards={this.state.vAxis}
     value = {[]}
     id = "vaxis"
     handleChange={(e)=>this.vAxis(e)}/>
    </td>
    <reactbootstrap.Form.Label className="col-md-12" style = {{color:'red'}}>
        {t('select count on H-Axis and elements or person on V-Axis')}
    </reactbootstrap.Form.Label>
    </div>
      {this.state.webEleAxis !== '' &&
      <div>
      <reactbootstrap.Form.Label className="col-md-12" >
          {t('Chart display')}:<span style={{color:'red'}}>*</span>
      </reactbootstrap.Form.Label>
        {this.personOptions()}</div>
      }
    <div>
    </div>
    </div>
   );
  }

  hAxis(event){
      this.setState({personChart:''});
      if(event == [] || event == undefined || event == ''){
        this.setState({hAxis:event});
      }
      else {
       this.hvAxis(event);
      }
  }

  vAxis(event){
    this.setState({personChart:''});
    if(event == [] || event == undefined || event == ''){
      this.setState({vAxis:event});
    }
    else {
      this.hvAxis(event);
    }
  }

  hvAxis(event){  //arrange data for haxis and vaxis and validations also
    let arr = '';
    let axis;
    let webEleAxis = [];
    let check = 0;
    let count = 0;
      const {t} = this.state;
         event.map((key,index)=>{
           axis = (key.name === 'hAxis') ? 'hAxis':'vAxis';
           let data = (axis === 'vAxis') ? this.state.hAxis:this.state.vAxis;
           if(data.length > 0){
              data.map((k,i)=>{
               if(key.value === k.value){
                 check++;
                 OCAlert.alertError(t('Cannot draw chart for same columns'), { timeOut: window.TIMEOUTNOTIFICATION });
               }
               if((key.value === '99999' && k.value !== 'count' ) || (k.value === '99999' && key.value !== 'count')){
                 check++;
                 OCAlert.alertError(t('Cannot draw chart for selected columns'), { timeOut: window.TIMEOUTNOTIFICATION });
               }
              })
           }
          if(count === 0 && check === 0){
            if(key.value === 'count'){
              arr = event;
                if(arr.length < 2){
                  if(axis === 'hAxis'){this.setState({hAxis:event});}else{this.setState({vAxis:event});}
                }
                else {
                  OCAlert.alertError(t('No possibility instead remove it and add other'), { timeOut: window.TIMEOUTNOTIFICATION });
                }
            }
          }
          if(key.value !== 'count'){
            webEleAxis.push(key.value);
          }
          })
          if(arr === '' && check === 0){
            if(axis === 'hAxis'){ this.setState({hAxis:event});}else{this.setState({vAxis:event});}
            count++;
          }
          this.setState({webEleAxis:webEleAxis});
  }

      personOptions(){    //element based,person based ,time based options
        let selectTypeChart = window.SELECTED_TYPE_CHART;
        return (
          <div>
           <MultiSelect
            options={selectTypeChart}
            standards={this.state.personChart}
            id = "personChartType"
            isMulti={false}
            handleChange={(e)=>this.selectPersonChart(e)}/>
          </div>
        );
      }

      selectPersonChart(e){
        const {t} = this.state;
        let webAxis = this.state.webEleAxis;
        if(webAxis.includes('99999') && webAxis.length > 1){
          if(e.value === 'Person' || e.value === 'Name'){
            this.setState({personChart:e});
          }
          else {
            OCAlert.alertError(t('Not possibile select other'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
        }
        if(webAxis[0] === '99999' && webAxis.length === 1) {
          if(e.value === 'Person' || e.value === 'Time'){
            this.setState({personChart:e});
          }
          else {
            OCAlert.alertError(t('Not possibile select other'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
        }
        if(webAxis.includes('99999') === false){
          if(e.value === 'Name' || e.value === 'Time'){
            this.setState({personChart:e});
          }
          else {
            OCAlert.alertError(t('Not possibile select other'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
        }
      }

      valuesFilter(){
        let xOptions = [];   //gauge chart xoptions
        let yOptions = [];   //gauge chart yoptions
        const {t} = this.state;
        this.state.response_data[0].map((key)=>{
          if(key !== 'updated_at' && key !== 'Person||99999'){
            if(key.split('||')[2] !== '5'){
              xOptions.push({
                label:key.split('||')[0],
                value:key.split('||')[1],
             });
              yOptions.push({
                label:key.split('||')[0],
                value:key.split('||')[1],
              });
           }}
        });
        return(
          <div>
          <div>
        <td style = {{width:'300px'}}>
        <reactbootstrap.Form.Label className="col-md-12" >
            {t('x-options')}:<span style={{color:'red'}}>*</span>
        </reactbootstrap.Form.Label>
        <MultiSelect
         options={xOptions}
         id = "xoptions"
         standards={this.state.xOptions}
         isMulti = {false}
         handleChange={(e)=>this.xOptions(e)}/>
         </td>
         <td style = {{width:'300px'}}>
        <reactbootstrap.Form.Label className="col-md-12" >
            {t('y-options')}:<span style={{color:'red'}}>*</span>
        </reactbootstrap.Form.Label>
        <MultiSelect
         options={yOptions}
         standards={this.state.yOptions}
         isMulti = {false}
         id = "yoptions"
         handleChange={(e)=>this.yOptions(e)}/>
        </td>
        <reactbootstrap.Button onClick={(e) => this.reset(e)} disabled={false}>{t('reset x & y options')}</reactbootstrap.Button>
        </div></div>);
      }

      reset(){
        this.setState({
          xOptions:'',
          yOptions:''
        });
      }

      xOptions(e){
        const {t} =this.state;
        if(this.state.yOptions.value === e.value){
          OCAlert.alertError(t('select different element'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
        else {
         this.setState({xOptions:e});
        }
      }

      yOptions(e){
        const {t} =this.state;
        if(this.state.xOptions.value === e.value){
          OCAlert.alertError(t('select different element'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
        else {
         this.setState({yOptions:e});
        }
      }

      async handleDynamicBack(object){
        const {t} =this.state;
          let charttypes = [0,1,3],resultArr = [];
          if(object.displayPrevData === true){
            await this.setState({dateCheck:false,reportCountcall:'monthwise',reportView:false,checkCondition:false,count:0});
          }
          if(charttypes.includes(this.state.chartType)){   //for axis charts selections
            if((object.data[0].length === 1 || object.data[1] === undefined) && object.displayPrevData === false) {
             OCAlert.alertError(t('No data for chart'), { timeOut: window.TIMEOUTNOTIFICATION });
             this.setState({checkCondition: false,reportCountcall:object.key,checkSubmit:false,count:1});
            }
            if(object.data !== undefined && (object.data[0].length > 1 || object.data[1] !== undefined)){
              this.setState({radioVal:object.radioVal,xCount:object.xCount,yCount:object.yCount,dateOptions:object.dateOptions,reportCountcall:object.key,dateCheck:true,dynamicReportData:object.totalData,checkSubmit:false,count:1,fromDate:object.fromDate,toDate:object.toDate});
              resultArr = object.data;
            }
          }
          if((this.state.chartType === 4) || (this.state.chartType === 2)){  //for pie charts and gauge
            if(object.data[1] === undefined && object.displayPrevData === false) {
             OCAlert.alertError(t('No data for chart'), { timeOut: window.TIMEOUTNOTIFICATION });
             this.setState({checkCondition: false,reportCountcall:object.key,checkSubmit:false,count:1});
            }
           if(object.data !== undefined && object.data[1] !== undefined){
               this.setState({radioVal:object.radioVal,reportCountcall:object.key,dateCheck:true,dateOptions:object.dateOptions,dynamicReportData:object.totalData,checkSubmit:false,count:1,fromDate:object.fromDate,toDate:object.toDate,xCount:object.xCount,yCount:object.yCount});
               resultArr =  object.data;
             }
          }
          if(resultArr !== undefined && resultArr.length > 0){
            await this.getProperties(resultArr);  //send for options and color
          }
        }

  render() {
    const {t} =  this.state;
    if((this.props.query() === '') && (this.state.change === true) && (this.state.query_new === '')){
      OCAlert.alertError(t('Add query or filter the data first'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
    return(
      <div>
      <Reactbootstrap.Tabs id="tabs" defaultActiveKey = 'CustomReports'>
      <Reactbootstrap.Tab eventKey= 'fielddata' title={t("Filter Data")}>
       <FilterCharts id = {this.props.webform_id} filterCount = {this.state.filterCount} ChartReportCallBack = {this.handleBack.bind(this)} cid = {this.props.id} options = {this.state.resultData}/>
      </Reactbootstrap.Tab>
      <Reactbootstrap.Tab eventKey= 'CustomReports' title={t("Custom Reports")}>
      {this.getRenderContentForCharts()}
      </Reactbootstrap.Tab>
      </Reactbootstrap.Tabs>
      </div>
    );
  }
  getRenderContentForCharts = ()=>{
    let chartName = this.state.newchartName;
    let subtitle = this.state.subtitle !== '' ? this.state.subtitle : (this.state.chartCheck === true) ? this.state.subtitleValue : this.state.subtitle;
    return (
      <div className = "container-fluid">
       {this.chartData()}
       {(this.state.resultCheck.length > 0) && (this.state.reportView === true) &&
         <div>
        <DynamicReport data = {this.state.resultData}
         selectedIds = {this.state.resultCheck}
         chartData = {this.state.response_data}
         chartType = {this.state.chartType}
         dynamicReportCallBack = {this.handleDynamicBack.bind(this)}
         checkCall = {this.state.reportCountcall}
         personElement = {this.state.webEleAxis}
         checkSubmit = {this.state.checkSubmit}
         chartName = {this.state.chartName}
         subtitle = {subtitle}
         radioVal = {this.state.radioVal}
         hAxis = {this.state.hAxis}
         vAxis = {this.state.vAxis}
         personChart = {this.state.personChart}
         webform_id = {this.props.webform_id}
         xOptions = {this.state.xOptions}
         yOptions = {this.state.yOptions}
         finalRanges = {this.state.finalRanges}
         checkCount = {this.state.count}
         fromDate = {this.state.fromDate}
         toDate = {this.state.toDate}
         filterArray = {this.state.filterArray}
         totalChartData = {this.state.dynamicReportData}
         xCount = {this.state.xCount}
         yCount = {this.state.yCount}
         dateOptions = {this.state.dateOptions}
          />
         </div>
       }
       {(this.state.checkCondition === true) && (this.state.newchartName === 'PieChart') &&
       <div className = 'chart-reports-table'>
       <Chart
         width={'500px'}
         height={'500px'}
         chartType= {'Table'}
         loader={<div>Loading Chart</div>}
         data={this.state.chartData}
         className = "Tablechart"
         />
        </div>
       }
       {this.state.check === 'true' &&
        <GithubPicker
          color={ this.state.color }
          onChangeComplete={ this.handleChangeComplete }
        />
       }
     {((this.state.newchartName !== '') && (this.state.checkCondition === true)) &&
     <div className = 'chart-reports'>
     <Chart
       chartType= {chartName}
       className = "chart-report-custom"
       loader={<div>Loading Chart</div>}
       data={this.state.chartData}
        chartEvents ={[{
        eventName: "select",
        callback:({ chartWrapper }) => {
        if(this.state.newchartName === 'PieChart')
        {
          var colorIndex = chartWrapper.getChart().getSelection()['0'].row;
        }
        else
        {
          var colorIndex = chartWrapper.getChart().getSelection()['0'].column - 1;
        }
          this.handleChangeComplete(colorIndex);
          this.setState({
              check:'true',
              index: colorIndex,
          });
       }
       }]}
       chartPackages={['corechart', 'controls']}
       options={this.state.chartOptions}
       rootProps={{ 'data-testid': '1' }}
    />
    </div>
    }
    </div>
      );
    }
  }




export default translate(ChartReport)
