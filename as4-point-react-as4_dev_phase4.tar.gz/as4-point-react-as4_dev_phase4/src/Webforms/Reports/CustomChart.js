
import React, { Component, Suspense , useState, useEffect} from 'react';
import { translate } from '../../language';
import ReactFC from 'react-fusioncharts';
import FusionCharts from 'fusioncharts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import Chart from 'react-google-charts';
import ShowReport from './DynamicReport';
import { OCAlert } from '@opuscapita/react-alerts';
import * as reactbootstrap from 'react-bootstrap';
import PieChartComponent from './ReportComponents/PieChartComponent';
import LineAndAreaChartComponent from './ReportComponents/LineAndAreaChartComponent'
import ColumnAndBarChartComponent from './ReportComponents/ColumnAndBarChartComponent';
import GaugeChartComponent from './ReportComponents/GaugeChartComponent';
import MultiSelect from './../../_components/MultiSelect';
import CheckBox from '../../CheckBox.js';
import {reportFilter} from '../WebReports/CustomFilterFunctions';



class CustomChart extends React.Component{
    constructor(props) {
        super(props)
          this.state = {
          }
    }
render(){
    return(
        <>
            <div className = 'mt-5'>
              <div>{this.getTableChartAndChartForm()}</div>
            </div>
        </>
    )
}

   getTableChartAndChartForm =  () =>{
  const { submitElementDetails, savedElementIds, savedElementsData, savedElementsTypes, submitStatus, chartData, disableFields} = this.props;
  let displayTag = [];
  if(submitStatus){
    if(savedElementIds.length > 0 && Object.keys(submitElementDetails).length > 0){
    displayTag.push(parseInt(disableFields) !== 2 && <div>{this.getChartForm()}</div>);
    displayTag.push(parseInt(disableFields) !== 2 && <div>{this.getPivotTable(chartData)}</div>);
    displayTag.push(<div>{this.getChart(chartData)}</div>);
    }else{
    displayTag.push(<div>{savedElementIds.length > 0 ? 'No data' : 'Please select webelements'}</div>);
    }
    return displayTag;
 }
}



getChart = (chartData)=>{
  const { showChartStatus, chartType } = this.props;
  if(showChartStatus){
    return(<div>{this.getChartAccordingToType(chartData)}</div>);
  }else{
    return (<div></div>);
  }
}



getChartAccordingToType(chartData){
  const {labelOptions, valueOptions, chartType, title, isThreeDOrNot, legend, aggregate, aggregateValue, label, value, xAxis, yAxis, sliceLabel } = this.props;
  switch(parseInt(chartType)){
    case window.PIE_CHART_TYPE:
    return <PieChartComponent
    title = {title}
    isThreeDOrNot = {isThreeDOrNot}
    legend = {legend}
    sliceLabel = {sliceLabel}
    chartData = {chartData}
    />
    break;
    case window.COL_CHART_TYPE:case window.BAR_CHART_TYPE:
    return <ColumnAndBarChartComponent
    chartType= {chartType}
    title = {title}
    isThreeDOrNot = {isThreeDOrNot}
    xAxis= {xAxis}
    yAxis = {yAxis}
    chartData = {chartData}
    />;
    break;
    case window.LINE_CHART_TYPE:case window.AREA_CHART_TYPE:
    return <LineAndAreaChartComponent
    chartType= {chartType}
    title = {title}
    isThreeDOrNot = {isThreeDOrNot}
    xAxis= {xAxis}
    yAxis = {yAxis}
    chartData = {chartData}
    />;
    break;
    case window.GAUGE_CHART_TYPE:
    return <GaugeChartComponent
    title = {title}
    chartData = {chartData}/>;
    break;
  }
}
getChartForm(){

  const {labelOptions, valueOptions, chartType, title, isThreeDOrNot, legend, aggregate, aggregateValue,
    label, value, xAxis, yAxis, sliceLabel, dateOrDropdown, fromDate, toDate, dateDropdownSelection, disableFields} = this.props;
    let dateOption = Object.keys(window.DATE_DEFAULT_FILTER_KEY_LABEL).map(key=>{ return {'label' : window.DATE_DEFAULT_FILTER_KEY_LABEL[key], 'value' : key}});
  return (
    <div>
    <reactbootstrap.Table>
    <tbody>
    {<tr>
    <td>{this.getRadioField('Filter by from - to date : ', 'dateOrDropdown', 0, dateOrDropdown)}</td>
    <td>{this.getRadioField('Filter by options', 'dateOrDropdown', 1, dateOrDropdown)}</td>
    <td>{parseInt(dateOrDropdown) === 0 && <div>{this.getDateField('From date :', 'fromDate', fromDate)} {this.getDateField('To date :', 'toDate', toDate)} </div>}
        {parseInt(dateOrDropdown) === 1 && <div>{this.getDropDownField('', 'dateDropdownSelection', dateDropdownSelection, dateOption, 0, 0)}</div>}</td>
    </tr>}
    {(parseInt(disableFields) !== 1 && parseInt(disableFields) !== 2) && <tr>
    <td>{this.getDropDownField('Select Chart  ', 'chartType', chartType, window.WEBFORMREPORTTYPES, 0, 0)}</td>
    <td>{this.getDropDownField('Label ', 'label', label, labelOptions, 1, 1)}</td>
    <td>{this.getMultiSelectDropDown('Value', 'value', value, valueOptions)}</td>
    </tr>}
    {(parseInt(disableFields) !== 1  && parseInt(disableFields) !== 2) && <tr>
    <td>{this.getTextField('Title', 'title', title)}</td>
    {parseInt(chartType) === window.PIE_CHART_TYPE && <td>{this.getCheckBox('3D', 'isThreeDOrNot', isThreeDOrNot)}</td>}
    {parseInt(chartType) === window.PIE_CHART_TYPE &&<td>{this.getDropDownField('Legend ', 'legend', legend, window.REPORTS_LEGEND_TYPE, 0, 0)}</td>}
    </tr>}
    {(parseInt(disableFields) !== 1 &&  parseInt(disableFields) !== 2 && parseInt(chartType) !== window.GAUGE_CHART_TYPE && parseInt(chartType) !== window.PIE_CHART_TYPE && parseInt(chartType) !== window.COL_CHART_TYPE)&&<tr>
    <td>{this.getTextField('xAxis ', 'xAxis', xAxis)}</td>
    {parseInt(chartType) !== window.AREA_CHART_TYPE && <td>{this.getTextField('yAxis ', 'yAxis', yAxis)}</td>}
    <td></td>
    </tr>}
    {(parseInt(disableFields) !== 1 && parseInt(disableFields) !== 2) &&<tr>
    {parseInt(chartType) === window.PIE_CHART_TYPE && <td>{this.getDropDownField('Slice by ', 'sliceLabel', sliceLabel, window.REPORTS_SLICE_BY, 0, 0)}</td>}
    <td>{this.getCheckBox('Aggregate ', 'aggregate', aggregate)}</td>
    {parseInt(aggregate) === 1 && <td>{this.getDropDownField('', 'aggregateValue', aggregateValue, window.AGGREGATE_OPTIONS, 0)}</td>}
    <td></td>
    </tr>}
    </tbody>
    </reactbootstrap.Table>
    <reactbootstrap.Button onClick = {(e)=>this.handleShowChartCallFunc()}>{'Show Chart'}</reactbootstrap.Button>
    {(parseInt(disableFields) !== 1 && parseInt(disableFields) !== 2) && <reactbootstrap.Button onClick = {(e)=>this.props.handleSaveCustomChart()}>{'Save Chart'}</reactbootstrap.Button>}
    </div>
  )
}

handleShowChartCallFunc = async () =>{
  const { submitElementDetails, savedElementIds,label, value} = this.props;
  if(savedElementIds.length > 0 && Object.keys(submitElementDetails).length > 0 && parseInt(label) !== 0 && value.length > 0){
  let chartData =  await this.props.getChartData();
  this.props.handleShowChart({chartData: chartData,showChartStatus:true, showPivotTable : true});
}else{
  this.props.handleShowChart({chartData: [],showChartStatus:false, showPivotTable:false});
}
}

getDateField(labelName, valueName, value){
  return <div>
  <label>
  {labelName}
  <input type = 'date' value = {value} onChange = {(e)=>this.props.handleDateField(valueName, e.target.value)}/>
  </label>
  </div>
}

getRadioField(labelName, valueName, value, propsValue){
  return <div>
  <label>
  {labelName}
  <input type = 'radio' value = {value} checked = {parseInt(propsValue) === parseInt(value) ? true : false} onChange={(e)=>this.props.handleRadioField(valueName, e.target.value)}/>
  </label>
  </div>
}
getCheckBox(labelName, valueName, value){
  return <div>
  <label>
  {labelName}
  <CheckBox
    tick={parseInt(value) === 1 ? true : false}
    onCheck={e => this.props.handleCheckBox(valueName, e.target.checked)}
  />
  </label></div>;

}

getMultiSelectDropDown(labelName, selectedValueName, selectedValue, optionData){
  return <label>
  {labelName}
  <MultiSelect
   options={optionData}
   standards={selectedValue}
   isMulti={true}
   style = {{width:"100%"}}
   handleChange={(e) => this.props.handleMultiSelect(selectedValueName, e)}
  />
  </label>
}


getTextField(labelName, valueName, value){
  return (
    <div>
    <label>
    {labelName}
    <input type = {'text'} value = {value} onChange = {(e)=>this.props.handleTextField(valueName, e.target.value, 1)}/>
    </label>
    </div>
  )
}

getDropDownField(labelName, selectedValueName, selectedValue, optionData , needSelectOption, checkLabel){
  return (
    <label>
    {labelName}
    <select value={selectedValue} onChange = {(e)=>this.props.handleSingleSelectChange(selectedValueName, e.target.value, checkLabel)}>
    {this.getOptions(optionData, needSelectOption)}
    </select>
    </label>
  )
}


getOptions(optionValue, needSelectOption){
  let optionData = optionValue.map(key=>{
    return <option value={key['value']}>{key['label']}</option>
  });
  parseInt(needSelectOption) === 1 && optionData.unshift(<option value={0}>{'---Select----'}</option>);
  return optionData;
}

getPivotTable = (chartData) => {
  const { submitElementDetails, savedElementIds, savedElementsData, savedElementsTypes, submitStatus, label, value, showPivotTable} = this.props;
  let tableHead = [];
  let tableBody = [];
  let submitIds = Object.keys(submitElementDetails);
  if(showPivotTable && savedElementIds.length > 0 && submitIds.length > 0 && parseInt(label) !== 0 && value.length > 0){
      chartData.map((valueArr, index)=>{
        let tableData = valueArr.map(value=>{ return index === 0 ? <th>{value}</th> : <td>{value}</td> })
        if(index !== 0){
         tableBody.push(<tr>{tableData}</tr>)
        }else{
         tableHead.push(<tr>{tableData}</tr>)
       }
      });
    return (<reactbootstrap.Table>
       <thead>{tableHead}</thead>
       <tbody>{tableBody}</tbody>
       </reactbootstrap.Table>)
  }
}


}
export default translate(CustomChart);
