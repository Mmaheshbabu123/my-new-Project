import React, { Component } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../../language';
import SearchInput, { createFilter } from 'react-search-input'
import { OCAlert } from '@opuscapita/react-alerts';
import { datasave } from '../../_services/db_services';
import CheckBox from '../../CheckBox';
import PersonImg from '../../images/personc.png';
import JobImg from '../../images/jobc.png';
import DepartmentImg from '../../images/departmentsc.png';
import GroupImg from '../../images/groupc.png';
import DeleteImg from '../../images/delete1.png';
import ReportsPopUp from './ReportsPopUp';
import '../../DragnDrop.css';
import $ from 'jquery';



/**
* Moves an item from one list to another list.
*/
const move = (source, destination, droppableSource, droppableDestination, draggableId) => {
  const sourceClone = Array.from(source);
  const destClone = Array.from(destination);
  const [removed] = sourceClone.filter(items => items.id === draggableId);
  destClone.splice(droppableDestination.index, 0, removed);
  const result = {};
  result[droppableSource.droppableId] = sourceClone.filter(items => items.id !== draggableId);
  result[droppableDestination.droppableId] = destClone;
  result['latestDropped'] = removed;
  result['type'] = (droppableDestination.droppableId === 'droppable') ? 'remove' : 'add';
  return result;
};
const grid = 8;


const getListStyle = isDraggingOver => ({
  background: isDraggingOver ? 'lightblue' : '#fff',
  padding: grid,
  //  width: '62%',
});

const getFlexStyle = ({
  display: 'flex',
  backgroundColor: '#fff',
});

const imageStyle = ({
  width: 20,
  cursor: "default",
});
const commonTdStyle = ({
  backgroundColor: '#fff',
  color: '#212529',
  border: '1px solid #fff',
  fontSize: '14px',
  paddingLeft: '32px',
  verticalAlign: 'middle',
  zIndex:'0px'
});
const textinline = ({
  display: '-webkit-inline-flex',
});

class AccessDragnDrop extends Component {

  constructor(props) {

    super(props);
    this.searchUpdated = this.searchUpdated.bind(this)
    this.addValues=this.addValues.bind(this);
    this.addValuesToTable=this.addValuesToTable.bind(this);
    this.state = {
      KEYS_TO_FILTERS: window.search_fields,
      t:props.t,
      items: [],
      selected: [],
      types: [],
      searchData: [],
      searchTerm: [],
      searchType: '',
      result_obj:[],
      type: '',
      html: window.REPORTS_OBJECT,
      html_right: window.HTML_RIGHT,
      updated: 1,
      webform_id:this.props.webform_id,
      report_id:this.props.report_id,
      persons: [],
      curently_hovered_item: [],
      show: false,
      showPopup :false,
      isTooltipActive: false,
      parent: "tooltip",
      checkbox:{},
      result:[],
      disabled:false,
      inserUpdateUrl:this.props.inserUpdateUrl,
      showWebElement:false,
      showAddValues:false,
      SavingElements:true,
      currentId:0,
      currentEntity_type_id:0,
      webElements:{},
      sublistWithParent:{},
      subLists:{},
      currentWebelementId:0,
      selectedWebElementsCount:0,
    }
    this.handleCheck = this.handleCheck.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleChangeOrder = this.handleChangeOrder.bind(this);
    this.handleClicktr = this.handleClicktr.bind(this);
    this.handlePersons = this.handlePersons.bind(this);
    this.handleClicktrTask = this.handleClicktrTask.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleSave= this.handleSave.bind(this);
    this.handleSaveReports=this.handleSaveReports.bind(this);
    this.handleWebElement=this.handleWebElement.bind(this);
  }
  async  handleCancel(){
    window.close();
  }

  //getdata() creates new data to send backend
  async getdata(){
    let webform_id=this.state.webform_id;
    let report_id=this.state.report_id;
    let data={}
    await  this.state.selected.map(value=>{
      var id=value.id;
      let newData={[id]:{
        entity_type_id:value.category_id,
        entity_id:value.id,
        // checked:(value.checked===undefined ||value.checked===0 || value.checked===false)?0:1,
        checked:1,
        webform_id:webform_id,
        report_id:report_id,
      }}
      data = {...data,...newData};
    });
    this.setState({
      result:data
    })
    return data;
  }
  addValuesToTable(){
    if(this.state.currentWebelementId!==undefined || this.state.currentWebelementId!=='' ){
      let   sublistWithParent = this.loopAndGetCheckedData(this.state.subLists['subLists']['values']);
      this.setState({sublistWithParent:sublistWithParent});
    }
    this.setState({
      showAddingValues:false,
    })
  }
  loopAndGetCheckedData(data){
    let sublistWithParent = this.state.sublistWithParent;
    let currentWebelementId=this.state.currentWebelementId;
    sublistWithParent[currentWebelementId] = data.map(value => {
      if(value.checked === true || value.checked === 1){
        return {'id':value.function_id,'name':value.name};
      }
    });
    return sublistWithParent;
  }
  //handleSave() for storing webform access to database
  async handleSave(){
    const {t} =this.state;
    if((this.state.selected).length>0){
      let data=await this.getdata();
      let url=this.props.inserUpdateUrl;
      datasave.service(url,"POST",data)
      .then(response=>
        OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION }),
        // setTimeout(() => { window.close(); }, 500)
      );
      this.setState({
        inserUpdateUrl:window.UPDATE_WEBFORMPERMISSION_DATA + '/' + this.props.report_id + '/' +this.props.webform_id,
      })
    }else{
      let url=window.DELETE_WEBFORMPERMISSION_DATA + '/' + this.props.report_id + '/' +this.props.webform_id;
      await  datasave.service(url,'POST')
      .then(response=>{
        if(response['status']===200) {
          OCAlert.alertSuccess(t('Updated successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
          // setTimeout(() => { window.close(); }, 500);
        }else {
          OCAlert.alertWarning(t('Something went wrong'), { timeOut: window.TIMEOUTNOTIFICATION })
        }
        this.props.cancel();
      })
      return;
    }
  }
  getSendableData = (data) => {
    return data.map(value=>{
      value['checked'] = value.checked===undefined || value.checked === false || value.checked === 0 ?0:1;
      value['overRideFilledInPeople'] = value.overRideFilledInPeople===undefined || value.overRideFilledInPeople === false || value.overRideFilledInPeople === 0 ? 0 :1;
      return value;
    })
  }
  async handleSaveReports(){
    const {t} = this.state;
    if((this.state.selected).length>0){
      let data = this.getSendableData(this.state.selected);
      let url=window.INSERT_REPORTPERMISSION_DATA + '/' + this.props.report_id + '/' +this.props.webform_id;
      datasave.service(url,"POST",data)
      .then(response => {
        if(response['status'] === 200){
          OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION })
          {/**setTimeout(() => { window.close(); }, 500)*/};
        }else{
          OCAlert.alertError(t('Error saving data please try again later'), { timeOut: window.TIMEOUTNOTIFICATION })
        }
      });
    } else{
      this.props.cancelReports();
      let  url=window.DELETE_REPORTPERMISSION_DATA + '/' + this.props.report_id + '/' +this.props.webform_id;
      await datasave.service(url,'POST')
      .then(response=>{
      })
      return;
    }
  }


  async  handleWebElement(items){
    const{t}=this.state;
    if(Object.values(this.props.webElements["webElements"]["values"]).length<1){
      OCAlert.alertWarning((t('No webElements in this document ')), { timeOut: window.TIMEOUTNOTIFICATION })
      return ;
    }
    if(Object.keys(items.selectedData).length<1){               //this will make webElements reset to false display uncheck checkbox in popup
      Object.entries(this.props.webElements).map(([key,value])=>{
        this.props.webElements['webElements']["selectall"]=false;
        this.props.webElements["webElements"]["values"].map(value1=>{
          if(value1.checked===true){
            value1.checked=false;
          }
        })
      });
      this.setState({
        sublistWithParent:{}
      })
    }
    else{
      Object.values(items.selectedData).map(value2=>{
        this.props.webElements["webElements"]['selectall']=value2.selectall;
        this.setState({
          sublistWithParent:value2.childs,
        })
      });
      Object.values(items.selectedData).map(value1=>{
        Object.values(value1.webElements).map(value2=>{
          Object.values(this.props.webElements["webElements"]["values"]).map(value3=>{
            if(value2.function_id===value3.function_id){
              value3.checked=true;
            }
          })
        })
      })
    }

    this.setState({
      showWebElement:true,
      SavingElements:true,
      showAddValues:false,
      showAddingValues:false,
      currentId:items.id,
      currentEntity_type_id:items.entity_type_id,
      selectedWebElementsCount:0
    })
  }

  handleClicktr(resultObj) {
    if (this.props.details.disableFields ||this.props.details.exp_his_disabled|| this.props.disable_based_on_right || this.props.approvalcycle_disabled || this.props.extra_tab_disabled||this.props.default_tab_disabled) {
      return;
    }
    var selected = this.state.selected;
    var remove = selected.filter(item => (item.name !== resultObj.name && item.id !== resultObj.id));
    const result = {};
    result['latestDropped'] = resultObj;
    result['type'] = 'remove';
    this.setState(prevState => ({
      items: [...prevState.items, resultObj],
      selected: remove,
    }), () => {
      this.props.updateSelectedChild(result.latestDropped, result, this.props.tab, this.props.notify_id);
    });
  }
  handleClicktrTask(resultObj,task_status = 0,show_comment = true) {
    if(this.props.tab==="webformreportaccess") {
      resultObj.selectedData={};
      resultObj.checked = false;
      resultObj.overRideFilledInPeople = false;

    }else{
      resultObj.checked=false;
    }
    if (this.props.details.disableFields ||this.props.details.exp_his_disabled|| this.props.disable_based_on_right || this.props.approvalcycle_disabled || this.props.extra_tab_disabled||this.props.default_tab_disabled) {
      return;
    }
    //if(this.props.details.action === 'edit'){
    if(this.props.remove_type === true && this.props.details.action === 'edit'){
      if(task_status == 0){
        this.setState({
          showPopup :show_comment,
          result_obj:resultObj,
        })
      }
      else{
        this.setState({
          showPopup :show_comment,
          result_obj:resultObj,
        })
        this.handleClicktr(resultObj);
      }
    }
    else{
      this.handleClicktr(resultObj);
    }

  }

  updateSelectAll() {
    $('tr').find('#verify').each(function(){
      $(this).appendTo($(this).parent().find('#9'));
      // $(this).parent().parent().find('#verify').remove();
    })
    $('tr').find('#authorise').each(function(){
      $(this).appendTo($(this).parent().find('#10'));
      // $(this).parent().parent().find('#authorise').remove();
    })
  }

  /**
  * A semi-generic way to handle multiple lists. Matches
  * the IDs of the droppable container to the names of the
  * source arrays stored in the state.
  */
  id2List = {
    droppable: 'items',
    droppable2: 'selected'
  };

  handleDragSelectedChange = (result) => {
    this.setState({
      items: result.droppable,
      selected: result.droppable2
    }, () => {

      this.props.updateSelectedChild(result.latestDropped, result, this.props.tab, this.props.notify_id);
    });
  }
  getList = id => this.state[this.id2List[id]];

  onDragEnd = resultObj => {

    const { source, destination, draggableId } = resultObj;
    // dropped outside the list
    if (!destination) {
      return;
    }
    if (source.droppableId === destination.droppableId) {
      return;
    } else {
      const result = move(
        this.getList(source.droppableId),
        this.getList(destination.droppableId),
        source,
        destination,
        draggableId
      );
      this.handleDragSelectedChange(result);
    }
  };
  searchUpdated(term, itemlist) {
    const items = { ...this.state.searchTerm };
    items[itemlist] = term;
    this.setState({
      searchTerm: items,
      searchType: itemlist,
    })
  }
  handleCheck = (id, checked, category) => {
    this.handleUpdateState(id, checked, "checkboxes", "checked", category, "flag")
  }
  handleCheckORFIP =(id, checked, category) => {
      this.handleUpdateState(id, checked, "checkboxes", "overRideFilledInPeople", category, "flag")
  }
  handleSelectTextHideAll(id, value, type, action, pid, flag) {
    let selected = this.state.selected;
    this.state.selected.map(functions => {
      Object.values(functions[type]).map(function (item, index) {
        if (item.id === id && functions.id === pid) {
          item[action] = 1;
          item[flag] = 1;
          item.show=!value;
          return;
        }
      })
    });
    this.setState({
      selected: selected,
    }, () => {
      this.props.updateSelectedRights(this.state.selected,this.props.tab);

    })
  }
  handleSelectTextAll(id, value, type, action, pid, flag) {
    let selected = this.state.selected;
    this.state.selected.map(functions => {
      Object.values(functions[type]).map(function (item, index) {
        if (value  && functions.id === pid) {
          item[action] = 1;
          item[flag] = 1;
          return;
        }
        else if(functions.id === pid){
          item[action] = 0;
          item[flag] = 0;
          return;
        }
      })
    });
    this.setState({
      selected: selected,
    }, () => {
      this.props.updateSelectedRights(this.state.selected);
    })
  }

  async handleUpdateState(id, value, type, action, pid, flag) {
    let selected = this.state.selected;
    if(action === 'checked') {
    await  this.setAccordingTocheckBox('checked', 'overRideFilledInPeople', id, value)
    }
    else if (action === 'overRideFilledInPeople') {
    await  this.setAccordingTocheckBox('overRideFilledInPeople','checked', id, value)
    }else {
      this.state.selected.map(functions => {
        if (functions.id === id) {
          functions[action] = value;
          return;
        }
      });
    }
    this.setState({
      selected: selected,
    }, () => {
      this.props.updateSelectedRights(this.state.selected,this.props.tab);
    })
  }
  setAccordingTocheckBox =(key1,key2, id, value) =>{
    this.state.selected.map(functions => {
      if (functions.id === id){
        functions[key1] = value;
        functions[key2] = !value;
        return;
      }
    });
  }
  handleChange(id, value, type_id, type) {
    const re = /^(?:[0-9]*)$/;
    if (value === '' || re.test(value)) {
      this.handleUpdateState(id, value, "textfield", type, type_id, "flag");
    }
  }
  handleHideWebElement=async ()=>{
    this.setState({showWebElement: false,
      showAddValues:false,
      SavingElements:true,
      selectedWebElementsCount:0
    });
    await this.resetWebElemets();
  }
  handleSaveWebElement=async ()=>{
    // const {t}=this.state;
    var i=0;
    await  this.props.webElements['webElements']['values'].map(value=>{
      if(value.checked===true){
        i++;
      }
    })
    // if(i<1){
    //   OCAlert.alertWarning((t('Please select minimum one webelement')), { timeOut: window.TIMEOUTNOTIFICATION })
    //   return;
    // }
    this.setState({
      showAddValues:true,
      SavingElements:false,
      selectedWebElementsCount:i,
    })
  }
  handleBackWebElement=()=>{
    this.setState({
      showAddingValues:false,
      showAddValues:false,
      SavingElements:true,
      selectedWebElementsCount:0
    })
  }
  generateReport=async ()=>{
    let selectedWebElements='';
    let entity_type_id=this.state.currentEntity_type_id;
    let entity_id=this.state.currentId;
    let childs=this.state.sublistWithParent;
    selectedWebElements=this.props.webElements['webElements']['values'].filter(function(value){
      return value.checked===true;
    })
    await this.resetWebElemets();
    var results={[entity_type_id]:{
      "entity_type_id":entity_type_id,
      "entity_id":entity_id,
      "webElements":selectedWebElements,
      "selectall": this.props.webElements['webElements']['selectall'],
      "selectall" : selectedWebElements.length===this.props.webElements['webElements']['values'].length?true:false,
      "childs":childs
    }};
    Object.values(this.state.selected).map(value=>{
      if(value.id===entity_id && value.entity_type_id===entity_type_id){
        value.selectedData=results
      }
    })

    this.setState({
      showWebElement:false,
      selectedWebElementsCount:0
    })
  }

  resetWebElemets(){
    this.props.webElements['webElements']['selectall']=false;
    return  Object.values(this.props.webElements["webElements"]["values"]).map(value3=>{
      if(value3.checked===true){
        return    value3.checked=false;
      }
    });
  }
  handleChangeOrder(id, value, type_id, type) {
    const re = /^(?:[0-9])$/;
    if (value === '' || re.test(value)) {
      this.handleUpdateState(id, value, "textfield", type, type_id, "flag");
    }
  }
  handlePersons(item) {
    let callbackend = true;
    if ((item.category_id !== undefined && item.category_id !== window.PERSON_ENTITY) || parseInt(item.entity_type_id) !== window.PERSON_ENTITY) {
      this.setState({ show: true });
      if (this.state.persons[item.id]) {
        this.setState({
          curently_hovered_item: this.state.persons[item.id]
        })
      }
      else {
        const loaded_persons = this.state.persons;
        var url = '';
        let entity_type_id = '';
        if (parseInt(item.category_id) === parseInt(window.SPACES_ENTITY) || item.category === "spaces") {
          url = window.GET_SPACE_PERSONS + '/' + item.id
        } else if (parseInt(item.category_id) === parseInt(window.ROLE_ENTITY) || item.category === "roles") {
          if (item.abbrevation === "user roles") {
            url = window.GET_ROLEPERSONS + '/' + item.id
          } else {
            callbackend = false
            let persons_of_VCIVA = this.getPersonOfVciva(item.abbrevation);
            this.setState({
              persons: persons_of_VCIVA,
              curently_hovered_item: persons_of_VCIVA
            })

          }
        } else {
          entity_type_id = item.entity_type_id;
          url = window.GetAllLinkedPersons + '/' + item.id + '/' + entity_type_id
        }

        if (callbackend) {
          datasave.service(url, "GET", '')
          .then(result => {
            const all_persons = {
              ...loaded_persons,
              ...result
            }
            this.setState({
              persons: all_persons,
              curently_hovered_item: result[item.id]
            })
          })
          .catch(error => {

          })
        }

      }
    }

    //}

  }
  getPersonOfVciva=(data)=>{
    switch (data) {
      case "view":
      return this.props.credentials.access_details[1] ? this.props.credentials.access_details[1] : [];
      break;
      case "CRUD people" :
      return this.props.credentials.access_details[2] ? this.props.credentials.access_details[2] : [];
      break;
      case "initiater":
      return this.props.credentials.access_details[6] ? this.props.credentials.access_details[6] : [];
      break;
      case "verifyer":
      return this.props.credentials.access_details[7] ? this.props.credentials.access_details[7] : [];
      break;
      case "authoriser":
      return this.props.credentials.access_details[8] ? this.props.credentials.access_details[8] : [];
      break;
      default:
      return []
    }
  }
  handleHide = () => {
    this.setState({ show: false });
  }
  async addValues(elementId,webform_id){
    const { sublistWithParent,t} = this.state;
    const {webformSublists} = this.props;
    if(webformSublists[elementId]===undefined){
      this.setState({
              showAddingValues:false,
      })
      OCAlert.alertWarning(t('No child items'), { timeOut: window.TIMEOUTNOTIFICATION })
      return;
    }
    if(sublistWithParent[elementId] !== undefined){
      let subListIds = await sublistWithParent[elementId].map(key=>{ return (key !== null && key !== undefined)?  parseInt(key['id']) : 0});
      let objectBuildMerge = Object.keys(webformSublists[elementId]).map(id1 => {
        return subListIds.includes(parseInt(id1)) ?
        { 'function_id': id1, 'name': webformSublists[elementId][id1]['name'],
        'checked': true, 'classification': 'subLists',
        'category': id1, 'parent_id':webformSublists[elementId][id1]['parent_id']}
        :
        {'function_id': id1, 'name': webformSublists[elementId][id1]['name'],
        'checked': false, 'classification': 'subLists',
        'category': id1, 'parent_id':webformSublists[elementId][id1]['parent_id']}
      }, this);

      let re=  objectBuildMerge.filter(item=>item.checked===false).length;
      let subLists = {
        'values' : objectBuildMerge,
        'selectall':(re>0)?false:true,
      };
      this.setState({
        subLists: {'subLists' : subLists},
        showAddingValues:true,
        currentWebelementId:elementId,
      });
    }
    else if (sublistWithParent[elementId] === undefined){
      let objectBuild = {};
      let objectBuildMerge = [];
      Object.values(webformSublists[elementId]).map(value=>{
        objectBuild = {'function_id': value.id,'name': value.name,
        'checked': false,'classification': 'subLists',
        'category': value.id,'parent_id':value.parent_id
      }
      objectBuildMerge.push(objectBuild);
    });
    let subLists = {
      'values' : objectBuildMerge,
      'selectall': false,
    };
    this.setState({
      subLists: {'subLists' : subLists},
      showAddingValues:true,
      currentWebelementId:elementId,
    });
  }
}


componentDidUpdate(prevProps, prevState) {
  if (prevState.items !== this.props.tasks) {
    this.setState({
      items: this.props.tasks,
    })
  }
  else if(prevState.currentId!==this.state.currentId && prevState.currentEntity_type_id!==this.state.currentEntity_type_id){
    this.setState({
      currentId:this.state.currentId,
      currentEntity_type_id:this.state.currentEntity_type_id,
    })
  }
  else if(prevState.currentWebelementId!==this.state.currentWebelementId){
    this.setState({
      currentWebelementId:this.state.currentWebelementId
    })
  }
}
rowImage=(item)=>{
  switch (item) {
    case 'persons':
    return PersonImg;
    break;
    case 'jobs':
    return JobImg;
    break;
    case 'departments':
    return DepartmentImg;
    break;
    default:
    return GroupImg
  }
}

render(){
  const { t } = this.state;
  this.updateSelectAll();
  const popupWebElement = (
    <reactbootstrap.Modal
    show={this.state.showWebElement}
    onHide={this.handleHideWebElement}
    dialogClassName="modal-90w modal-lg"
    aria-labelledby="example-custom-modal-styling-title"
    >
    <reactbootstrap.Modal.Header closeButton>
    <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">{t('Webelements')}</reactbootstrap.Modal.Title>
    </reactbootstrap.Modal.Header>
    <reactbootstrap.Modal.Body style={{height:"450px",overflow:'auto'}}>
    <ReportsPopUp
    webElements = {this.props.webElements}
    webform_id = {this.state.webform_id}
    report_id = {this.state.report_id}
    closepopUp = {this.handleHideWebElement}
    showAddValues = {this.state.showAddValues}
    showAddingValues = {this.state.showAddingValues}
    parent_id = {this.state.parent_id}
    sublistWithParent = {this.state.sublistWithParent}
    currentId = {this.state.currentId}
    addValues = {this.addValues}
    currentEntity_type_id = {this.state.entity_type_id}
    subLists = {this.state.subLists}
    addValuesToTable = {this.addValuesToTable}
    selectedWebElementsCount = {this.state.selectedWebElementsCount}
    />
    </reactbootstrap.Modal.Body>
    {this.state.SavingElements && <reactbootstrap.Modal.Footer>
      <reactbootstrap.Button onClick={this.handleHideWebElement}>{t('Close')}</reactbootstrap.Button>
      <reactbootstrap.Button onClick={this.handleSaveWebElement}>{t('Next')}</reactbootstrap.Button>
      </reactbootstrap.Modal.Footer>}
      {!this.state.SavingElements &&  <reactbootstrap.Modal.Footer>
        <reactbootstrap.Button onClick={this.handleBackWebElement}>{t('Back')}</reactbootstrap.Button>
        <reactbootstrap.Button onClick={this.generateReport}>{t('Save')}</reactbootstrap.Button>
        </reactbootstrap.Modal.Footer>}
        </reactbootstrap.Modal>
      );
      const popupContent = (
        <reactbootstrap.Modal
        show={this.state.show}
        onHide={this.handleHide}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
        >
        <reactbootstrap.Modal.Header closeButton>
        <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">{t("Persons")}</reactbootstrap.Modal.Title>
        <reactbootstrap.Modal.Body>
        <ul>
        {this.state.curently_hovered_item.length != 0 &&
          this.state.curently_hovered_item.map(person =>
            <li>{person.name}</li>
          )
        }
        {this.state.curently_hovered_item.length === 0 &&
          t('No persons are linked')
        }
        </ul>
        </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal.Header>
        </reactbootstrap.Modal>
      );
      if (this.props.types !== undefined && this.state.items !== undefined) {
        const types = this.props.types;
        this.state.selected = this.props.selected;
        if (this.props.selected !== undefined && this.props.selected.length === 0 && this.props.updateProps === 1 && this.state.updated > 0) {
          this.setState({
            selected: this.props.selected,
            updated: 0,
          });
        }
        else if (this.props.selected !== undefined && this.props.selected.length > 0 && this.props.updateProps === 1 && this.state.selected.length === 0) {
          this.setState({
            selected: this.props.selected,
            updated: 2,
          });
        }
        var filteredNames = [];
        var dragObject = <reactbootstrap.Tabs activeKey={this.props.activeKey} onSelect={this.props.onSelect} id="controlled-tab-example">
        {Object.values(types).map(
          function (itemlist, key) {
            var search = '';
            if (this.state.searchTerm && this.state.searchType) {
              search = this.state.searchTerm[itemlist];
              search = (search !== undefined) ? search : '';
            }
            filteredNames[itemlist] = this.state.items.filter(createFilter(search, this.state.KEYS_TO_FILTERS));
            return (
              <reactbootstrap.Tab className="input-right-field" id="dashdragndrop" eventKey={itemlist} title={t(itemlist.charAt(0).toUpperCase() + itemlist.slice(1))}>
              <reactbootstrap.Table  responsive striped hover >

              <thead style={{position: 'sticky',top: '0',backgroundColor: '#fff'}}>
              <tr>
              <td style={{ padding: '0.25rem' }} colSpan="3" >
              <SearchInput style={{ colour: 'red', border: '0px', color: '#EC661C', fontSize: '13px', }} className="search-input approval-input" onChange={(e) => this.searchUpdated(e, itemlist)} />
              </td>
              </tr>
              <tr>
              {this.state.html_right[0][itemlist].map(rights =>
                <th style={{ backgroundColor: '#EC661C', fontSize: '14px', color: '#fff', padding: '0.25rem' }} title={t(rights.name)}>{t(rights.name)}</th>
              )}
              </tr>
              </thead>
              <tbody style={{ backgroundColor: '#fff', border: '0px' }}>
              {/* <div> */}
              {Object.values(filteredNames[itemlist]).map(

                function (item, index) {
                  item.category_id = (item.entity_type_id !== undefined) ? item.entity_type_id : item.category_id;
                  if (item != undefined && item.id !== undefined && item.category === itemlist) {
                    return (
                      <Draggable className="right-field-border"
                      isDragDisabled={this.props.details.disableFields}
                      key={item.id}
                      draggableId={item.id}
                      type={item.category}
                      index={index}>
                      {(provided, snapshot) => (
                        <tr
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        >
                        <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6'}}>
                        <div style={textinline} onClick={(e) => this.handlePersons(item)}>
                        <span className="">{item.category != 'spaces' && <img style={imageStyle} src={this.rowImage(item.category)} alt="persons" />}&nbsp;</span>&nbsp;
                        <span style={{wordBreak: 'break-word'}}>{item.name}</span>
                        </div>
                        {popupContent}
                        </td>
                        {item.category != 'persons' && <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6', textAlign:'center',wordBreak: 'break-word'}}>{item.abbrevation}
                        </td>
                      }
                      </tr>
                    )}
                    </Draggable>
                  )
                }
              }, this)}
              </tbody>
              </reactbootstrap.Table>
              </reactbootstrap.Tab>
            )
          }, this)}
          </reactbootstrap.Tabs>
        }
        return (
          <div>
          <div className="col-md-12 p-0" style={getFlexStyle}>
          <DragDropContext onDragEnd={this.onDragEnd}>
          <Droppable droppableId="droppable2">
          {(provided, snapshot) => (
            <div className="selected-item-header-section"
            ref={provided.innerRef}
            style={getListStyle(snapshot.isDraggingOver)}>
            <p>{t("Selected items")}</p>
            <div className='border-remove' style={{ width: '100%', overflowX: 'auto',  }}>
            <reactbootstrap.Table style={{ width: '100%', overflowX: 'auto', margin: '0' }} striped responsive bordered hover variant="dark">
            <thead  style={{ backgroundColor: '#EC661C',position: 'sticky',top: '0' }}>
            <tr >
            {this.state.html[0][this.props.type].map(commons =>
              <th style={{ paddingTop: '20px', border: '0px', width:this.props.width}} className={commons.class} key={commons.name} title={t(commons.name)}></th>
            )}
            </tr>
            </thead>
            <tbody >
            {this.state.selected !== undefined && this.state.selected.map(
              function (item, index) {
                if (this.props.type === "web" || this.props.type === "report") {
                  return (
                    <tr style={commonTdStyle}>
                    <td  style={{width:this.props.width}}>
                    <div style={textinline} onClick={(e) => this.handlePersons(item)}>
                    <div >{item.category !== 'spaces' && <img style={imageStyle} src={this.rowImage(item.category)} alt="persons" />}</div>&nbsp;
                    <span style={{cursor: 'default', wordBreak: 'break-word',width: '5rem'}}>{item.name}</span>
                    </div>{popupContent}</td>
                    {/**<td style={{textAlign: 'center'}} className="dpt-abrivation">
                    <span style= {{cursor: 'default', color: '#212529',wordBreak: 'break-word'}}>{item.abbrevation}</span>
                    </td>*/}
                    {this.props.tab===window.tabs.webformreportaccess&&<td id = {item.id}  style={{width:this.props.width,paddingLeft:this.props.checkboxpadding}}>
                    <CheckBox
                    key={item.id}
                    tick={item.checked}
                    classification={item.name}
                    approvalcycle_disabled = {this.props.details.approvalcycle_disabled}
                    onCheck={(e) => this.handleCheck(item.id, e.target.checked,item.category)}
                    keyvalue={item.id}
                    disabled = {this.props.details.disableFields||this.props.details.exp_his_disabled}
                    />
                    </td>}
                {  /**  {this.props.tab===window.tabs.webformreportaccess&&<td id = {item.id} style={commonTdStyle}>
                    <CheckBox
                    key={item.id}
                    tick={item.overRideFilledInPeople}
                    classification={item.name}
                    approvalcycle_disabled = {this.props.details.approvalcycle_disabled}
                    onCheck={(e) => this.handleCheckORFIP(item.id, e.target.checked,item.category)}
                    keyvalue={item.id}
                    disabled = {this.props.details.disableFields||this.props.details.exp_his_disabled}
                    />
                    </td>}*/}
                    {this.props.tab===window.tabs.webformreportaccess&&<td id = {item.id}  style={{width:this.props.width,paddingLeft:'11%'}}>
                    <i title={t('Add elements')} className="webform-sprite webform-sprite-createlistc" onClick={(e) => this.handleWebElement(item)}/>{popupWebElement}</td>}
                    <td className = 'remove' style={{textAlign: 'center',width:this.props.width}}  disabled={this.props.details.disableFields || this.props.disable_based_on_right||this.props.approvalcycle_disabled||this.props.extra_tab_disabled||this.props.default_tab_disabled}>
                    {this.props.remove_type === undefined && <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => this.handleClicktr(item)}></img>}
                    {this.props.remove_type === true && <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => this.handleClicktrTask(item)}></img>}
                    </td>
                    </tr>
                  )
                }
              }, this)}
              {provided.placeholder}
              </tbody>
              </reactbootstrap.Table>
              </div>
              </div>
            )}
            </Droppable>
            <Droppable droppableId="droppable">
            {(provided, snapshot) => (
              <div className="avialble-filed-person "
              ref={provided.innerRef}
              style={getListStyle(snapshot.isDraggingOver)}
              >
              <p>{t('Available items')}</p>
              {provided.placeholder}
              {dragObject}
              </div>
            )}
            </Droppable>
            </DragDropContext>
            </div>

            <reactbootstrap.Row style={{float:'right',paddingTop:'13px',paddingRight:'18px'}}>
               {this.props.tab===window.tabs.webformfullaccess &&
                    <reactbootstrap.Button onClick={(e)=>this.handleSave()} style={{margin:'2px', }} disabled={this.state.disabled}>{t('Save Webform access')}</reactbootstrap.Button>}
              {this.props.tab===window.tabs.webformreportaccess &&
                    <reactbootstrap.Button onClick={(e)=>this.handleSaveReports()} style={{margin:'2px', }} disabled={this.state.disabled}>{t('Save Reports access')}</reactbootstrap.Button>}
                    <reactbootstrap.Button onClick={(e)=>this.handleCancel()} style={{margin:'2px', }}>{t('Cancel')}</reactbootstrap.Button>
            </reactbootstrap.Row>
                </div>
              );
            }
          }
          export default translate(AccessDragnDrop)
