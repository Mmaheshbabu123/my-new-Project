import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import {translate} from '../../language';
import AccessDragnDrop from './AccessDragnDrop';
import CustomDragnDrop from './CustomDragnDrop';

class AccessPermission extends Component {
  constructor(props) {
    super(props)
    this.state=({
      tasks: [],
      items: [],
      types: [],
      selected: [{ 'approval_cycle': '' }],
      active_tab1: 1,
      credentials :true,
      disableFields: false,
      [window.tabs.webformfullaccess]: [],
      [window.tabs.webformreportaccess]: [],
      [window.tabs.customchartaccess]: [],
      t:props.t,
      checkbox:[],
      inserUpdateUrl:'',
      webElements:{},
    })
    this.handleActiveTab = this.handleActiveTab.bind(this);
    this.cancel = this.cancel.bind(this);
    this.cancelReports = this.cancelReports.bind(this);
    this.cancelCustom = this.cancelCustom.bind(this);
  }
  async  componentDidMount(){
    const lang_code = await (localStorage.getItem('Applang'));
    var url = window.GET_NOTIFICATIONS_TAB_DATA;
    let url1 = window.GET_WEBFORMPERMISSION_DATA + '/' +this.props.match.params.reportId + '/' +this.props.match.params.webform_id;
    let url2 = window.GET_REPORTPERMISSION_DATA + '/' +this.props.match.params.reportId + '/' +this.props.match.params.webform_id;
    let url3 = window.FETCH_ALL_WEBELEMENTS + '?webform_id=' + this.props.match.params.webform_id;
    let url4 = window.FETCH_LIST_DATA + '/'+ this.props.match.params.webform_id + '/' + lang_code;
    let url5 = window.GET_CUSTOMPERMISSION_DATA + '/' +this.props.match.params.reportId + '/' +this.props.match.params.webform_id;

     await this.notificationTabData(url);
     await this.webFormPermissionData(url1);
     await this.webElementsAndReportPermissionData(url2,url3,url4);
     await this.customPermissionData(url5);
  }
  async getAllListData(url4,webElements){
    await datasave.service(url4, 'GET').then(
      async  response => {
        let values=await this.constructListData(response.response,webElements);
        this.setState({
          webformSublists:values
        })
      });
    }
    constructListData(response,webElements){
      let objectBuild = {};
      Object.keys(webElements['values']).map(key=>{
        Object.keys(response).map(key1=>{
          if(webElements['values'][key].jsonData!==null ){
            if(webElements['values'][key].jsonData['list']!==undefined && key1===(webElements['values'][key].jsonData['list']).toString()){
              objectBuild[webElements['values'][key].function_id]=response[key1];
            }
          }
        })

      })
      return objectBuild;
    }
    async webElementsAndReportPermissionData(url2,url3,url4){
      let webElements='';
      let webelementResult = [];
      let defaultwebElementsCount=0;
      await  datasave.service(url3, 'POST')
      .then( async result => {
        webelementResult = result['data'];
        let values = await this.constructWebelemenObj(result['data'],[]);
        webElements = {'values' : values, 'selectall': false,};
        defaultwebElementsCount = webElements['values'].length;
        this.setState({webElements: {'webElements' : webElements},});
      });


      await  datasave.service(url2,'GET')
      .then( async response=>{
        let data = Object.values(response);
        if(data.length > 0){
          await data.map(async obj=>{
            let webElements =  obj['selectedData'] !== undefined  && obj['selectedData'][obj.entity_type_id]['webelement_id'] !== undefined &&  obj['selectedData'][obj.entity_type_id]['webelement_id'].length > 0 ? obj['selectedData'][obj.entity_type_id]['webelement_id'] : [];
            if(webElements.length > 0){
              obj['selectedData'][obj.entity_type_id]['webElements'] = await this.constructWebelemenObj(webelementResult,webElements);
              obj['selectedData'][obj.entity_type_id]['selectall']=(obj['selectedData'][obj.entity_type_id]['webElements'].length===defaultwebElementsCount)?true:false;
            }
          })
          this.setState({[window.tabs.webformreportaccess] : data});
        }
      });
      await this.getAllListData(url4, webElements );
    }
    async  customPermissionData(url){
    await datasave.service(url, 'GET')
    .then( async response =>{
      let data = Object.values(response);
      console.log(data);
      this.setState({
        [window.tabs.customchartaccess]:data,
      })
    })
  }
    async notificationTabData(url){
      await datasave.service(url, "GET")
      .then(async result => {
        await (result.jgd).map(value=>{value.selectedData=[];value.overRideFilledInPeople=0;});
        await this.setState({
          tasks: result.jgd,
          items: result.jgd,
          types: result.types,
          checkbox:result.checkboxes,
          // selected: [],
        })
      });
    }
    async webFormPermissionData(url1){
      await  datasave.service(url1,'GET')
      .then(response=>{
        if(response.length>0){
          this.setState({
            [window.tabs.webformfullaccess]:response,
            inserUpdateUrl:window.UPDATE_WEBFORMPERMISSION_DATA + '/' + this.props.match.params.reportId + '/' +this.props.match.params.webform_id})
          }
          else{
            this.setState({
              [window.tabs.webformfullaccess]:response,
              inserUpdateUrl:window.INSERT_WEBFORMPERMISSION_DATA + '/' + this.props.match.params.reportId + '/' +this.props.match.params.webform_id})
            }
          });
        }

        async constructWebelemenObj(data,selectedWebElementArr){
          let objectBuild = {};
          let result = [];
          result =  await data.map(function(item, i){
            objectBuild = {
              'function_id': item.id,
              'name': item.name,
              'checked': false,
              'classification': 'webElements',
              'category': item.id,
              'jsonData':JSON.parse(item.json_data),
              'type':item.type,
            }
            if(selectedWebElementArr.length > 0){
              if(selectedWebElementArr.indexOf(item.id) !== -1){
                objectBuild['checked'] = true;
                return objectBuild;
              }
            }else{
              return objectBuild;
            }
          });
          return result.filter(key=>{ return key !== undefined });
        }

        handleActiveTab(key) {
          this.setState({
            active_tab1: key,
          });
        }
        updateSelectedRights = (latestList,tab) => {
          this.setState({
            [tab]: latestList,
          })
        }
        filterArray = (allList, selectedList) => {
          var pack_func = allList;
          Object.values(selectedList).map(
            function (item, key) {
              pack_func = pack_func.filter(selected => (selected.id !== item.id));
            }, this);
            return pack_func;
          }


          updateSelected = (latestDropped, result, type, id = '') => {
            console.log('enter');
            var array = [...this.state[type]]; // make a separate copy of the array
            if (result.type === 'remove') {
              var filterArray = array.filter(selected => (selected.name !== latestDropped.name));
            }
            if (result.type === 'remove') {
              this.setState({
                [type]: filterArray
              })
            }
            else {
              this.setState(prevState => ({
                [type]: [...prevState[type], latestDropped]
              }));
            }
          }
          cancel(){
            this.setState({
              [window.tabs.webformfullaccess]:[],
              inserUpdateUrl:window.INSERT_WEBFORMPERMISSION_DATA + '/' + this.props.match.params.reportId + '/' +this.props.match.params.webform_id
            });
          }
          cancelReports(){
            this.setState({
              [window.tabs.webformreportaccess]:[],
            })
          }
          cancelCustom(){
            this.setState({
              [window.tabs.customchartaccess]:[]
            })
          }
          render(){
            const {t}=this.state;
            var filter_webform = this.state.tasks;
            var filter_report = this.state.tasks;
            var filter_custom = this.state.tasks;
            if (this.state[window.tabs.webformfullaccess].length > 0 || this.state[window.tabs.webformreportaccess].length > 0 || this.state[window.tabs.customchartaccess].length > 0) {
              filter_webform = this.filterArray(this.state.tasks, this.state[window.tabs.webformfullaccess])
              filter_report = this.filterArray(this.state.tasks, this.state[window.tabs.webformreportaccess])
              filter_custom = this.filterArray(this.state.tasks, this.state[window.tabs.customchartaccess])
            }
            if(this.state.tasks.length>1){
              return(
                <reactbootstrap.Container>
                <reactbootstrap.Tabs activeKey={this.state.active_tab1} className="header_tabs" onSelect={this.handleActiveTab} id="controlled-tab-example">
                {this.props.match.params.type == 1 && <reactbootstrap.Tab eventKey={1} title={t("Reports permission")}>
                <AccessDragnDrop
                cancelReports={this.cancelReports}
                webformSublists={this.state.webformSublists}
                webform_id={this.props.match.params.webform_id}
                report_id={this.props.match.params.reportId}
                webElements={this.state.webElements}
                types={this.state.types}
                tasks={filter_report}
                active_tab={this.state.active_tab}
                checkbox={this.state.checkbox}
                details={this.state}
                type={window.tabs.report}
                selected={this.state[window.tabs.webformreportaccess]}
                {...this}
                updateSelectedRights={this.updateSelectedRights}
                updateSelectedChild={this.updateSelected}
                credentials={this.state.credentials}
                activeKey={this.state.active_tab}
                onSelect={this.state.handleActiveTab}
                tab={window.tabs.webformreportaccess}
                updateProps={1}
                remove_type = {true}
                width = {'25%'}
                checkboxpadding = {'9%'}
                />
                </reactbootstrap.Tab>}
                {this.props.match.params.type == 1 && <reactbootstrap.Tab  eventKey={2} title={t("Webform permission")} >
                <AccessDragnDrop
                cancel={this.cancel}
                webElements={this.state.webElements}
                inserUpdateUrl={this.state.inserUpdateUrl}
                webform_id={this.props.match.params.webform_id}
                report_id={this.props.match.params.reportId}
                types={this.state.types}
                tasks={filter_webform}
                active_tab={this.state.active_tab}
                checkbox={this.state.checkbox}
                details={this.state}
                type={window.tabs.web}
                selected={this.state[window.tabs.webformfullaccess]}
                {...this}
                updateSelectedRights={this.updateSelectedRights}
                updateSelectedChild={this.updateSelected}
                activeKey={this.state.active_tab}
                onSelect={this.state.handleActiveTab}
                tab={window.tabs.webformfullaccess}
                credentials={this.state.credentials}
                webformSublists={this.state.webformSublists}
                updateProps={1}
                remove_type = {true}
                width = {'33.33%'}
                checkboxpadding = {'13%'}
                />
                </reactbootstrap.Tab>}
                {this.props.match.params.type == 2 && <reactbootstrap.Tab eventKey={1} title={t("Custom chart permission")}>
                <CustomDragnDrop
                cancel={this.cancelCustom}
                webformSublists={this.state.webformSublists}
                webform_id={this.props.match.params.webform_id}
                report_id={this.props.match.params.reportId}
                webElements={this.state.webElements}
                types={this.state.types}
                tasks={filter_custom}
                active_tab={this.state.active_tab}
                checkbox={this.state.checkbox}
                details={this.state}
                type={window.tabs.report}
                selected={this.state[window.tabs.customchartaccess]}
                {...this}
                updateSelectedRights={this.updateSelectedRights}
                updateSelectedChild={this.updateSelected}
                credentials={this.state.credentials}
                activeKey={this.state.active_tab}
                onSelect={this.state.handleActiveTab}
                tab={window.tabs.customchartaccess}
                updateProps={1}
                remove_type = {true}
                width = {'25%'}
                checkboxpadding = {'9%'}
                />
                </reactbootstrap.Tab>}
                </reactbootstrap.Tabs>
                </reactbootstrap.Container>
              )
            }
            else{return(
              <div>{t('loading')}</div>
            )}
          }
        }
        export default translate(AccessPermission);
