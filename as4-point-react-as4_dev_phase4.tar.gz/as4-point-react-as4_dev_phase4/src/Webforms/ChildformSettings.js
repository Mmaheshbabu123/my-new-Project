import React, { Component } from 'react'
import { translate } from '../language'
import * as reactbootstrap from 'react-bootstrap';
import * as Reactbootstrap from 'react-bootstrap'
import CheckBox from '../CheckBox';
import { Button, Form, FormGroup } from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';


class ChildformSettings extends Component {
    constructor(props) {
        super(props)
        this.state = {
          show_last_filled_webform : true,
          showparent : true,
          enable: true,
          t: props.t,
        }
    }
    componentDidMount () {
        datasave.service(window.FETCH_CHILDFORM_SETTINGS+'/'+this.props.webform_id,'GET')
            .then(response=>{
                this.setState({
                    showparent : response[0]['showparent'],
                    show_last_filled_webform : response[0]['show_last_filled_webform'],
                    enable : response[0]['enable'],
                })
            })
    }

    handleCheckBox = (e) => {
        const { name, checked ,id} = e.target;
        this.setState({ [name]: checked })

    }
    showConfirmPopUp () {
        const { t } = this.state;
        const data = {
            showparent : this.state.showparent,
            show_last_filled_webform : this.state.show_last_filled_webform,
            enable : this.state.enable,
            webform_id : this.props.webform_id
        }
        datasave.service(window.SAVE_CHILDFORM_SETTING,'POST',data)
            .then(response =>{
              OCAlert.alertSuccess(t('Saved successfully.'), { timeOut: window.TIMEOUTNOTIFICATION });
            })
    }
    async handleCancel() {
      this.componentDidMount();
   }


    renderJsx() {
        let jsx = [];
        const { t,show_last_filled_webform,showparent,enable } = this.state
        jsx.push(
            <>
                <Reactbootstrap.Form.Group className="row" as='Showparent'>
                    <div className="col-md-1 pl-4">
                    <CheckBox
                        tick={showparent}
                        style={{ paddingLeft: '0px' }}
                        onCheck={this.handleCheckBox}
                        // name="Save insted of forward"
                        classification="showparent"
                    />
                    </div>
                    <div style={{ paddingTop: '9px' }} className="col-md-11 pl-0"><span>{t("Show parent")}</span></div>
                </Reactbootstrap.Form.Group>
                <Reactbootstrap.Form.Group className="row" as='Showlastfilledwebform'>
                    <div className="col-md-1 pl-4">
                    <CheckBox
                        tick={show_last_filled_webform}
                        style={{ paddingLeft: '0px' }}
                        onCheck={this.handleCheckBox}
                        // name="Save insted of forward"
                        classification="show_last_filled_webform"
                    />
                    </div>
                    <div style={{ paddingTop: '9px' }} className="col-md-11 pl-0"><span>{t("Show last filled in webform")}</span></div>
                </Reactbootstrap.Form.Group>
                <Reactbootstrap.Form.Group className="row" as='Showlastfilledwebform'>
                    <div className="col-md-1 pl-4">
                    <CheckBox
                        tick={enable}
                        style={{ paddingLeft: '0px' }}
                        onCheck={this.handleCheckBox}
                        // name="Save insted of forward"
                        classification="enable"
                    />
                    </div>
                    <div style={{ paddingTop: '9px' }} className="col-md-11 pl-0"><span>{t("Enable first field in webform")}</span></div>
                </Reactbootstrap.Form.Group>
            </>
        )
        return jsx;
    }


    render() {
        const { t } = this.state
        return (
            <reactbootstrap className="row ">
                <div  className='col-md-12'>
                    <div className="samplae col-md-12 pt-2 mt-2  mb-3" >
                        <reactbootstrap.Form enctype="multipart/form-data">
                          {this.renderJsx()}
                        </reactbootstrap.Form>
                    </div>
                    <FormGroup>
                        <div style={{ float: 'right' }} className="organisation_list">
                            <a onClick={(e) => this.handleCancel()} > {t('Cancel')} </a>
                            &nbsp;&nbsp;&nbsp;
                         <Button type="submit" name="save" className="btn btn-primary" onClick={this.showConfirmPopUp.bind(this)}>{t('Save')}</Button>

                        </div>
                    </FormGroup>
                </div>
            </reactbootstrap>
        )

    }
}
export default translate(ChildformSettings)
