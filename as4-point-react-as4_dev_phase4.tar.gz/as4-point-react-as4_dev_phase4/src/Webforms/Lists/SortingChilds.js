import React, { Component } from 'react';
import { Input } from 'reactstrap'
import { render } from 'react-dom';
import { SortableContainer, SortableElement } from 'react-sortable-hoc';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import TranslationsPopup from './TranslationsPopup';
import $ from 'jquery';

$.fn.setCursorPosition = function (pos) {
    this.each(function (index, elem) {
        if (elem.setSelectionRange) {
            elem.setSelectionRange(pos, pos);
        } else if (elem.createTextRange) {
            var range = elem.createTextRange();
            range.collapse(true);
            range.moveEnd('character', pos);
            range.moveStart('character', pos);
            range.select();
            range.focus();
        }
    });
    return this;
};

class SortingChilds extends Component {

  constructor(props) {
    super(props)
    this.state = {
      t: props.t,
    }
      this.updateChildListCursor = this.updateChildListCursor.bind(this);
  }

  componentDidMount() {
  }
  componentDidUpdate(prevProps, prevState) {
    this.updateChildListCursor();
  }



  updateChildListCursor(){
    let active_child = [];
    if(localStorage.getItem('active_child') !== null){
        active_child = JSON.parse(localStorage.getItem('active_child'));
        $(active_child.tagname +'[id =childindex'+active_child.id+']').focus().setCursorPosition(active_child.position);
    }
  }

  render() {
    const { t } = this.state;
    const sortDisable = (this.props.searchTerm !== '' || this.props.formDisable==='disabled')? 'disabled' : '';
    const SortableItem = SortableElement(({ child_key, name, id, hide, updateChilds, translationsDisplay, details, disabled, childUniqueKey}) => (
      <tr>
        <td style={{width: '160px'}}>
          <reactbootstrap.FormControl
            name='name'
            // autoFocus = {(details.current_child_id === child_key) ? true : false}
            placeholder={t("Child name")}
            aria-label="Functionname"
            aria-describedby="basic-addon1"
            value={name}
            onChange={e => updateChilds(e, 'name', child_key)}
            className="input_sw value-fields"
            id={"childindex" + child_key}
            disabled={this.props.formDisable}
          />
          {!name &&
            <div style={{ color: 'red' }} className="error-block mt-2">{t("Child name should not be empty")}</div>
          }
          {(details.child_edit_nameunique_error && details.current_child_id === child_key) &&
            <div style={{ color: 'red' }} className="error-block mt-2">{t("The name has already been taken !")}</div>
          }
        </td>
        <td style={{width: '160px'}}>
          <reactbootstrap.FormControl
            name='id'
            placeholder={t("id")}
            aria-label="Functionname"
            aria-describedby="basic-addon1"
            value={id}
            onChange={e => updateChilds(e, 'id', id)}
            className="input_sw id-field"
            id={"id" + id}
            disabled={this.props.formDisable}
          />
        </td>
        <td style={{textAlign: 'center'}}>
          <reactbootstrap.Form.Check
            onChange={e => updateChilds(!hide, 'hide', child_key)}
            name='hide'
            checked={hide}
            disabled={this.props.formDisable}
          />
        </td>
        <td>
          <div style={{ paddingLeft: '10px' }}>
              <Button disabled={this.props.formDisable} className="btn btn-primary" type="button" color="primary" onClick={ e => translationsDisplay(childUniqueKey)} >
                {t("Translations")}
              </Button>
          </div>
        </td>
      </tr>
    ));

    const SortableList = SortableContainer(({ items }) => {
      return (
       <reactbootstrap.Table>
         {items.map((child_item, child_index) => (
           <>
             {((this.props.type === 'view' && (!child_item.hide || this.props.showHiddenList)) || (this.props.type !== 'view') || child_item.laguage_id === 'en') &&
               <SortableItem key={`item-${child_item}`} index={child_index} child_key={child_index} name={child_item.name} id={child_item.id} hide={child_item.hide} updateChilds={this.props.updateChilds} translationsDisplay = {this.props.translationsDisplay} details={this.props.details} disabled={sortDisable}
                 childUniqueKey={(child_item.uniqueId) ? child_item.uniqueId : (child_item.id)}/>
             }
           </>
         ))}
         {(this.props.currentChildKey !== undefined) && (this.props.currentChildKey !== null) &&
           <TranslationsPopup currentTranslations={this.props.currentTranslations} showtranslationPopup={this.props.showtranslationPopup}
            translationsCancel  = {this.props.translationsCancel} currentChildKey = {this.props.currentChildKey} translationsCancel  = {this.props.translationsCancel} translationsOk = {this.props.translationsOk}
            listId = {this.props.listId} translatechildItems = {this.props.translatechildItems} unsavedData = {this.props.unsavedData}/>
         }
       </reactbootstrap.Table>
      );
    });

    return (
     <SortableList items={this.props.child_items} onSortEnd={this.props.onSortEnd} />
    );

  }
}


export default translate(SortingChilds)
