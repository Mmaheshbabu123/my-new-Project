import React, { Component } from 'react';
import Pagination from 'react-bootstrap/Pagination'
import * as reactbootstrap from 'react-bootstrap';
import Can from '../../_components/CanComponent/Can';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
import { translate } from '../../language';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import _ from 'lodash'
import { Link } from "react-router-dom";
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from '../../store';
import { datasave } from '../../_services/db_services';
import SortingChilds from './SortingChilds';
import arrayMove from 'array-move';
import './ListSortTable.css';

class ListForm extends Component {
  constructor(props) {

    super(props)

    const type = this.getListType();
    const create_type = window.GET_TYPE_DETAILS[type]["create_type"];
    const name_type = window.GET_TYPE_DETAILS[type]["name_type"];
    this.state = {
      t: props.t,
      parent_list_name: '',
      parent_list_name_error: false,
      parent_list_uniquename_error: false,
      child_name: '',
      child_textbox: false,
      child_items: [],
      savevalue: '',
      parent_items: [],
      old_child_items: [],
      child_nameunique_error: false,
      show_hidealert: false,
      child_empty: false,
      child_edit_nameunique_error: false,
      child_name_error: false,
      filterFullList: [],
      searchTerm: '',
      type: type,
      create_type:create_type,
      name_type:name_type,
      translatedChildItems : [],
      showtranslationPopup : false,
      languages : [],
      translatechildItems : {},
      currentTranslations: [],
      currentChildKey: null,
      prevStateData: [],
      prevPropsData: [],
      prevData:{},
      impactData:[],
      showImapactModal:false,
      changes:'',
    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.searchData = this.searchData.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.forwardTosave = true;
  }

  componentWillMount() {

  }

  async componentDidMount() {
    let lang_url = window.GET_ALL_LANGUAGES
    await datasave.service(lang_url,'GET')
    .then(async response => {
      this.setState({
        languages: response,
      });
    });
    this.listDataMode();
  }

  getListType(){
    if(window.location.href.includes('schedular')) {
      return window.SCHEDULARTYPE;
    }
    else if(window.location.href.includes('list')) {
      return window.LISTTYPE;
    }
    else if(window.location.href.includes('category')) {
      return window.CATEGORYTYPE;
    }
    else {
      return window.LOCATIONTYPE;
    }
  }

  listDataMode() {
    if (this.props.id !== undefined) {
      const URL = window.GET_PARENTLIST_DATA + '/' + this.props.id;
      datasave.service(URL, 'GET')
        .then(response => {
          let responseClone = JSON.parse(JSON.stringify(response))
          this.setState({
            parent_list_name: response.parent_data.name,
            child_items: response.child_data,
            filterFullList: response.child_data,
            old_child_items: response.child_data,
            parent_list_name_error: false,
            parent_list_uniquename_error: false,
            child_name_error: false,
            child_textbox: true,
            searchTerm: '',
            type: response.parent_data.type,
            translatechildItems: response.translatedChildData,
            prevData: this.getClonnedData(responseClone),
            child_name: '',
          }, () => this.getSublistTranslation(response.translatedChildData, response.parent_data, response.child_data))
        })
    }
  }

  getSublistTranslation(data, parent, sublist){
    let childTranslations = {};
    if(!data){
      sublist.map(val => {
        this.state.languages.map(lang => {
          if(lang.id !== 1){
            let temp = {};
            temp.name            = null;
            temp.parent_child_id = val.id;
            temp.parent_list_id  = val.parent_id;
            temp.language_id     = lang.id;
            temp.language        = lang.language;
            childTranslations = {...childTranslations,
              [val.id] : {...childTranslations[val.id], [lang.id] : temp }
            }}
        })})
        this.setState({
          translatechildItems : childTranslations,
        })
    }
  }

  componentDidUpdate(prevProps, prevState) {
    const { t } = this.state;
    if (this.props.id !== undefined && prevProps.id !== this.props.id) {
      if (prevProps.id !== this.props.id) {
        this.listDataMode();
      }
      if (Number(localStorage.getItem('listTranslationUpdate')) === 1) {
        this.setState(prevStateData => {
         return {
           saveDataAlert: true,
           prevStateData: prevStateData,
           prevPropsData: prevProps,
         };
       })
      }
    }
    else if (this.props.id === undefined && prevProps.id !== this.props.id) {
      this.setState({
        parent_list_name: '',
        child_items: [],
        old_child_items: [],
        parent_list_name_error: false,
        parent_list_uniquename_error: false,
        child_name_error: false,
        child_textbox: false,
        searchTerm: '',
        type:  this.getListType(),
        child_name: '',
      })
    }
  }

  addChild(event) {
    const { t } = this.state;
    let parentUnique = true;
    if (this.state.parent_list_name.replace(/\s/g, '').length) {
      this.props.parent_items.map((parent, key) => {
        if (parent.name === this.state.parent_list_name && this.props.id !== parent.id && this.state.type===parent.type) {
          parentUnique = false;
          this.setState({
            parent_list_uniquename_error: true,
          })
        }
      })
      if (parentUnique) {
        this.setState({
          child_textbox: true,
        })
      }
    } else {
      this.setState({
        parent_list_name_error: true,
      })
    }
  }

  handleChange(name, value, item) {
    // const { name, value } = e.target;
    localStorage.removeItem('active_child');
    this.setState({
      [name]: value,
      parent_list_name_error: false,
      parent_list_uniquename_error: false,
      child_nameunique_error: false,
      child_empty: false,
      child_name_error: false,
      current_child_id : '',
    });
    // if (item === 'Parent' && this.props.id !== undefined) {
    if (item === 'Parent') {
      localStorage.setItem('listTranslationUpdate', 1);
      let newList = (this.props.id === undefined) ? 'new' : 'old';
      localStorage.setItem('listNewOrOld', newList);
    }
  }

  handleKeyPress(event, type) {
    let Userdata = store.getState();
    const loggedin_personid = Userdata.UserData.user_details.person_id;
    let uniqueChild = true;
    if (event.key == 'Enter' && type === 'child') {
      if (event.target.value.replace(/\s/g, '').length) {
        if (this.state.child_items.length > 0) {
          this.state.child_items.map((child, key) => {
            if (child.name.replace(/\s/g, '') === this.state.child_name.replace(/\s/g, '')) {
              uniqueChild = false;
              this.setState({
                child_nameunique_error: true,
              })
            }
          })
        }
        if (uniqueChild) {
          const listIndex = this.state.child_items.length + 1;
          const childUniqueId = Math.floor(10000 + Math.random() * 90000);
          const data = {
            'id': '',
            'name': event.target.value,
            'hide': 0,
            'user_id': loggedin_personid,
            'status': 1,
            'index': listIndex,
            'uniqueId': childUniqueId,
          };
          this.state.child_items.push(data);

          this.pushTransalteChilds(event.target.value, listIndex, loggedin_personid, childUniqueId);
          localStorage.setItem('listTranslationUpdate', 1);
          let newList = (this.props.id === undefined) ? 'new' : 'old';
          localStorage.setItem('listNewOrOld', newList);

          const orderedChildItems = [];
          this.state.child_items.map((child, key) => {
            orderedChildItems[child.index - 1] = child;
          });

          this.setState({
            child_name: '',
            child_textbox: true,
            filterFullList: orderedChildItems,
          })
        }
      } else {
        this.setState({
          child_name_error: true,
        })
      }
    }
    else if (event.key == 'Enter' && type === 'parent') {
      event.preventDefault();
      this.addChild();
      return false
    }
  }

  pushTransalteChilds(name, childIndex, loggedin_personid, childUniqueId) {
    let translateChildsOfChild = this.state.translatechildItems ? this.state.translatechildItems : {};
    // let translateChildsOfChild = this.state.translatechildItems;

    let languageTranslations = {};
    this.state.languages.map((languageItem, languageIndex) => {
      const transalteChild = {
        'user_id': loggedin_personid,
        'name': "",
        'language_id': languageItem.id,
        'language': languageItem.language,
      };
      if(languageItem.code_name !== window.DEFAULT_LANGUAGE) {
        languageTranslations[languageItem.id] = transalteChild;
      }
      translateChildsOfChild[childUniqueId] = languageTranslations;
    })
    this.setState({
      translatechildItems: translateChildsOfChild,
    })
  }

  updateChilds(e, type, id) {
    let value = (type === 'name') ? e.target.value : e;

    let uniqueChild = true;
    if (type === 'name') {
      if (this.state.child_items.length > 0) {
        this.state.child_items.map((child, key) => {
          if (child.name === value && value !== '') {
            uniqueChild = false;
            this.setState({
              child_edit_nameunique_error: true,
              current_child_id: id
            })
          }
        })
      }
    }

    if (uniqueChild) {
      this.setState({
        child_edit_nameunique_error: false
      })
    }

    let childs_data = this.state.filterFullList;
    childs_data[id][type] = value;
    this.setState({
      filterFullList: childs_data,
      child_empty: false,
      current_child_id: id
    })
    if (value === '') {
      this.setState({
        child_empty: true,
      })
    }
    // if (this.props.id !== undefined) {
      localStorage.setItem('listTranslationUpdate', 1);
      let newList = (this.props.id === undefined) ? 'new' : 'old';
      localStorage.setItem('listNewOrOld', newList);
    // }
    if (type === 'name') {
      let cursorEnd = e.target.selectionEnd;
      let active_child = {};
      active_child.id = id;
      active_child.tagname = e.target.tagName;
      active_child.position = cursorEnd;
      localStorage.setItem('active_child', JSON.stringify(active_child));
    }
  }

 translationsDisplay(childUniqueKey) {
   this.setState({
     showtranslationPopup: true,
     currentTranslations: this.state.translatechildItems[childUniqueKey],
     currentChildKey: childUniqueKey,
   })
 }

  translationsOk(allTranslations, updatedTranslations, parentChildKey) {
  //   // let updatingChild = this.state.translatechildItems;
  //   // updatingChild[parentChildKey] = updatedTranslations;
  //   this.setState({
  //     showtranslationPopup : false,
  //     unsavedData: allTranslations,
  //     // translatechildItems: updatingChild,
  //   });
  }

  translationsCancel() {
    this.setState({
      showtranslationPopup : false,
    });
  }

  handlePopupCancel = () => {
    this.setState({
      show_hidealert: false,
      saveDataAlert: false,
     });
     localStorage.setItem('listTranslationUpdate', 0);
  }

  handleSelect(value, name) {
    this.setState({
      [name]: value
    })
  }

  handleSubmit(sumitedType) {
    let Userdata = store.getState();
    const loggedin_personid = Userdata.UserData.user_details.person_id;
    const URL = window.LISTNCHILDS;

    let new_parent = [];
    let update_parent = [];
    let child_newlist = [];
    let child_updatelist = [];
    let details = [];
    let parentid = null;
    let hidePopup = false

    if (!this.state.parent_list_name_error && !this.state.parent_list_uniquename_error && !this.state.child_nameunique_error && this.state.parent_list_name && !this.state.child_empty && !this.state.child_edit_nameunique_error) {
      this.setState({
        child_name: '',
        parent_list_name_error: false,
        parent_list_uniquename_error: false,
        child_nameunique_error: false,
        child_empty: false,
        child_edit_nameunique_error: false,
        child_textbox: false,
        searchTerm: '',
      })

      let childItemsAll = (Number(localStorage.getItem('listTranslationUpdate')) === 1 && this.state.prevStateData.child_items !== undefined && sumitedType === "warningSave") ? this.state.prevStateData.child_items : this.state.child_items;

      childItemsAll.map((child, key) => {
        if (child.hide) {
          hidePopup = (Number(localStorage.getItem('listTranslationUpdate')) === 1 && sumitedType === "warningSave") ? false : true;
        }
      });
      // if(this.state.type == 3 || this.state.type == 4){
      //   this.handleOk(sumitedType)
      //   return;
      // }
      if (localStorage.getItem('listNewOrOld') === null) {
        if (hidePopup && this.state.type !== 3 && this.state.type !== 4) {
          this.setState({
            show_hidealert: true
          })
        } else {
          this.handleOk(sumitedType);
        }
      }
      if (this.props.id && this.props.id !== undefined && (localStorage.getItem('listNewOrOld') !== undefined && localStorage.getItem('listNewOrOld') === 'old')) {
        if (hidePopup && this.state.type !== 3 && this.state.type !== 4) {
          this.setState({
            show_hidealert: true
          })
        } else {
          this.handleOk(sumitedType);
        }
      } else if (this.props.id === undefined) {
        new_parent = {
          'name': (localStorage.getItem('listNewOrOld') === 'new' && this.state.prevStateData.parent_list_name !== undefined  && sumitedType === "warningSave") ? this.state.prevStateData.parent_list_name : this.state.parent_list_name,
          // 'name': this.state.parent_list_name,
          'user_id': loggedin_personid,
          'status': 1,
          'type': this.state.type
        };
       let childDataDetails = (localStorage.getItem('listNewOrOld') === 'new' && this.state.prevStateData.child_items !== undefined && sumitedType === "warningSave") ? this.state.prevStateData.child_items : this.state.child_items;
       let childFilterFullList = (localStorage.getItem('listNewOrOld') === 'new' && this.state.prevStateData.filterFullList !== undefined && sumitedType === "warningSave") ? this.state.prevStateData.filterFullList : this.state.filterFullList;
       // var childDataDetails = this.state.child_items;
       // var childFilterFullList = this.state.filterFullList;
       let newTranslations = (localStorage.getItem('listNewOrOld') === 'new' && this.state.prevStateData.translatechildItems !== undefined && sumitedType === "warningSave") ? this.state.prevStateData.translatechildItems : this.state.translatechildItems;
       // let newtranslations = this.state.translatechildItems;

       let emptyChildError = false
       if(childDataDetails.length > 0) {
          childFilterFullList.map((child, key) => {
            if (child.name === '' || child.name === null) {
              emptyChildError = true
            } else {
              delete child['id'];
              child['index'] = key + 1;
              child_newlist.push(child);
            }
          })
       }

       if (!emptyChildError) {
         details = {
           newp: new_parent,
           updatep: update_parent,
           new_childs: child_newlist,
           update_childs: child_updatelist,
           parent_id: parentid,
           translationList: newTranslations,
         }
         datasave.service(URL, 'POST', details)
           .then(response => {
             const createdParentId = response;
             if (response) {
               if (response.name) {
                 this.setState({
                   parent_list_uniquename_error: true
                 })
               } else {
                 if (this.props.id !== undefined) {
                   const URL = window.GET_PARENTLIST_DATA + '/' + this.props.id;
                   datasave.service(URL, 'GET')
                     .then(response => {
                       let responseClone = JSON.parse(JSON.stringify(response))
                       this.setState({
                         filterFullList: response.child_data,
                         child_items: response.child_data,
                         translatechildItems: response.translatedChildData,
                         prevData:this.getClonnedData(responseClone),
                       })
                     })
                 }
                 this.props.updateParentList(createdParentId)
                 this.props.updateComponent(1, 'view', createdParentId);
               }
             }
           })
           .catch(error => {
             this.setState({
               errors: error
             })
           })
       } else {
         this.setState({
           child_empty: true,
         })
       }
      }
    } else if (this.state.parent_list_name_error || this.state.parent_list_name === '') {
      this.setState({
        parent_list_name_error: true,
      })
    } else if (this.state.parent_list_uniquename_error) {
      this.setState({
        parent_list_uniquename_error: true,
      })
    }

    this.setState({
      saveDataAlert: false,
    })
    localStorage.setItem('listTranslationUpdate', 0);
  }

  async handleOk(sumitedType) {
    let Userdata = store.getState();
    const loggedin_personid = Userdata.UserData.user_details.person_id;
    const URL = window.LISTNCHILDS;

    this.setState({
      show_hidealert: false,
    })

    let new_parent = [];
    let update_parent = [];
    let child_newlist = [];
    let child_updatelist = [];
    let details = [];

    update_parent = {
      'id': (Number(localStorage.getItem('listTranslationUpdate')) === 1 && sumitedType === "warningSave") ? (this.state.prevPropsData.id ? this.state.prevPropsData.id : this.props.id) : this.props.id,
      // 'id': this.props.id,
      // 'name': this.state.parent_list_name,
      'name': (Number(localStorage.getItem('listTranslationUpdate')) === 1 && sumitedType === "warningSave") ? (this.state.prevStateData.parent_list_name ? this.state.prevStateData.parent_list_name : this.state.parent_list_name) : this.state.parent_list_name,
      'user_id': loggedin_personid,
      'type': this.state.type
    }
    // let parentid = this.props.id;
    let parentid = (Number(localStorage.getItem('listTranslationUpdate')) === 1 && sumitedType === "warningSave") ? (this.state.prevPropsData.id ? this.state.prevPropsData.id : this.props.id) : this.props.id;

    let childData = (Number(localStorage.getItem('listTranslationUpdate')) === 1 && sumitedType === "warningSave") ? (this.state.prevStateData.filterFullList ? this.state.prevStateData.filterFullList : this.state.filterFullList) : this.state.filterFullList;
    // var childData = this.state.filterFullList;

    let emptyChildError = false
    childData.map((child, key) => {
      if (child.name === '' || child.name === null) {
        emptyChildError = true
      } else {
        if (child.id !== '') {
          child_updatelist.push(child);
        } else {
          delete child['id'];
          child_newlist.push(child);
        }
      }
    });

    if (!emptyChildError) {
      details = {
        newp: new_parent,
        updatep: update_parent,
        new_childs: child_newlist,
        update_childs: child_updatelist,
        parent_id: parentid,
        translationList: (Number(localStorage.getItem('listTranslationUpdate')) === 1 && sumitedType === "warningSave") ? (this.state.prevStateData.translatechildItems ? this.state.prevStateData.translatechildItems : this.state.translatechildItems) : this.state.translatechildItems,
        // translationList: this.state.translatechildItems,
      }
      if(this.state.type == 3 || this.state.type == 4){
        await this.checkForChanges(URL, details);
      }else {
        this.forwardTosave = true;
      }
      if(this.forwardTosave){
        this.forwardTosaveMethod(URL, details);
      }
      localStorage.setItem('listTranslationUpdate', 0);
    } else {
      this.setState({
        child_empty: true,
      })
    }
  }

  checkForChanges = async (URL, details) => {
    const { prevData } = this.state;
    let currentName = ''
    let oldeName = ''
    let currentHideCount = 0;
    let prevHideCount = 0;
    let parentNameEdited = prevData.lists.name !== details.updatep.name ? 1 : 0;
    let newChildAdded = details.new_childs ? details.new_childs.length : 0;
    let newChilds = newChildAdded ? details.new_childs.map(val => {return val.name}) : [];
    let nameChangedSublists = [];
    let hiddenSublists = [];
    let unHiddenSublists = [];
    var currentChanges = _.differenceWith(prevData.sublists.sublists, details.update_childs, _.isEqual);
    var subLists = details.update_childs;
    currentChanges.forEach((item) => {
      let temp = subLists.filter(val => val.id === item.id)[0];
      let tempHide = temp['hide'] ? 1:0;
      let itemHide = item.hide ? 1:0;
      if(temp['name'] !== item.name)
         nameChangedSublists = [...nameChangedSublists, `${item.name} -> ${temp['name']}`];
      if(tempHide !== itemHide){
         if(itemHide) { unHiddenSublists = [...unHiddenSublists, temp['name']] }
         else{ hiddenSublists = [...hiddenSublists, temp['name']]}
       }
    });
    details.update_childs.forEach((item, i) => {
       currentName = currentName + item.name;
       if(item.hide) currentHideCount++ ;
    });
    prevData.sublists.sublists.forEach((item, i) => {
        oldeName = oldeName + item.name;
        if(item.hide) prevHideCount++ ;
    });
    let childSettingsChanged = currentHideCount !== prevHideCount ? 1 : 0;
    let childListsEdited = (oldeName.split('').sort().join('') !== currentName.split('').sort().join('')) ? 1 : 0;
    if(parentNameEdited || childListsEdited || newChildAdded || childSettingsChanged){
      this.forwardTosave = false;
      await this.showLinkedWebformImpactAnalysis(details, {
        parentNameEdited,
        childListsEdited,
        newChildAdded,
        childSettingsChanged,
        newChilds,
        hiddenSublists,
        unHiddenSublists,
        nameChangedSublists
      });
    }else{
      this.forwardTosave = true;
    }
  }
  showLinkedWebformImpactAnalysis = async (details, changes) => {
    const URL = window.SUBLISTNAME + '/' + details.updatep.id + '/' + this.state.type;
    await datasave.service(URL,'GET')
      .then(response =>{
        this.forwardTosave = response.length ? false:true;
        this.setState({ impactData: response, showImapactModal: response.length ? true:false, changes:changes, forwardTosaveDetails:details })
      });
    return;
  }
  forwardTosaveMethod = (URL, details, changed = 0, changesObj = '') => {
    const { t } = this.state;
    datasave.service(URL, 'PUT', {...details,
          changed,
          prevData:this.state.prevData,
          changesObj,
          linkedWebforms:this.state.impactData,
          type:this.state.type
    }).then(response => {
        if (response) {
          if (response.name) {
            this.setState({
              showImapactModal:false,
              parent_list_uniquename_error: true
            })
          } else {
            if (this.props.id !== undefined) {
              const URL = window.GET_PARENTLIST_DATA + '/' + this.props.id;
              datasave.service(URL, 'GET')
                .then(response => {
                  OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
                  let responseClone = JSON.parse(JSON.stringify(response))
                  this.setState({
                    filterFullList: response.child_data,
                    child_items: response.child_data,
                    translatechildItems: response.translatedChildData,
                    showImapactModal:false,
                    prevData: this.getClonnedData(responseClone),
                  })
                })
            }
            this.props.updateParentList(this.props.id)
            this.props.updateComponent(1, 'view', this.props.id);
          }
        }else{
          OCAlert.alertError(t('Unable to save list data.'), { timeOut: window.TIMEOUTNOTIFICATION })
          this.setState({
            showImapactModal:false,
          })
        }
      })
      .catch(error => {
        this.setState({
          errors: error,
          showImapactModal:false,
        })
      })
  }

  getClonnedData = (responseClone) => {
    let prevData = {
      lists: {},
      sublists: {},
    };
    prevData = {...prevData,
      ['lists']: {name: responseClone.parent_data.name},
      ['sublists']:{
        count: responseClone.child_data ? responseClone.child_data.length:0,
        sublists:responseClone.child_data?responseClone.child_data:[]
      }
    }
    return prevData;
  }


  handleCancel(event) {
    this.props.updateComponent(0, 'view', this.props.id);
  }

  searchData(e) {
    var list = [...this.state.child_items];
    let res = '';
    list = list.filter(function (item) {
      if (item.name !== null) {
        res = item.name.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
      return res;
    });
    this.setState({
      filterFullList: list,
      searchTerm: e.target.value,
      current_child_id : '',
    });

  }

  onSortEnd = ({ oldIndex, newIndex }) => {
    this.setState(({ filterFullList }) => ({
      filterFullList: arrayMove(filterFullList, oldIndex, newIndex),
    }));

    const orderedData = this.state.filterFullList;
    orderedData.map((child, key) => {
      child['index'] = key + 1;
    });

    this.setState({
      filterFullList: orderedData,
    })
  };

  render() {
    const { t } = this.state;
    const { type, parent_list_name, child_name, child_textbox, child_items, savevalue, parent_list_name_error, parent_list_uniquename_error, child_nameunique_error, child_name_error } = this.state;
    var formDisable = (this.props.type === 'view') ? 'disabled' : '';
    var modeType = this.props.type;

    const popupContent = (
      <reactbootstrap.Modal
        show={this.state.show_hidealert && (type !== 3 && type !== 4)}
        onHide={this.handlePopupCancel}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
            {t(this.props.title_type)}
          </reactbootstrap.Modal.Title>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Body col-md-12>
          {t("You are about to hide list items, Hiding these items can have impact on the functionality of your Webform(s)")}
        </reactbootstrap.Modal.Body>
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={() => this.handlePopupCancel()}>{t('Cancel')}</reactbootstrap.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
          <reactbootstrap.Button onClick={() => this.handleOk()}>{t('OK')}</reactbootstrap.Button>
        </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
    );

    const saveDataContent = (
      <reactbootstrap.Modal
        show={this.state.saveDataAlert}
        onHide={this.handlePopupCancel}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
            {t("Save data")}
          </reactbootstrap.Modal.Title>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Body col-md-12>
          {t("Something has been edited would you like to save it?")}
        </reactbootstrap.Modal.Body>
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={() => this.handlePopupCancel()}>{t('Cancel')}</reactbootstrap.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
          <reactbootstrap.Button onClick={() => this.handleSubmit("warningSave")}>{t('OK')}</reactbootstrap.Button>
        </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
    );

    return (
      <div className='container '>
        <div className='row ' >
          <div className='col-md-12' >
            <div><h3 className="mt-2 mb-3 d-none" style={{ textAlign: 'center' }}>{t(this.state.create_type)}</h3></div>
            <div className='card'>
              <div className='card-body mb-3' >
                <reactbootstrap.Container className="">
                  <reactbootstrap.Form >
                    <reactbootstrap.FormGroup>
                      <div className=" row input-overall-sec ">
                        <reactbootstrap.InputGroup className="">
                          <div className="col-md-12 row mb-3">
                            <div className="col-md-4">
                              <reactbootstrap.InputGroup.Prepend>
                                <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{ t(this.state.name_type)}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                              </reactbootstrap.InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd" onKeyPress={e => this.handleKeyPress(e, 'parent')}>
                              <reactbootstrap.FormControl
                                name='parent_list_name'
                                placeholder={t("Parent name")}
                                aria-label="Functionname"
                                aria-describedby="basic-addon1"
                                value={parent_list_name}
                                onChange={e => this.handleChange(e.target.name, e.target.value, 'Parent')}
                                className="input_sw"
                                disabled={formDisable}
                              />
                              {((!parent_list_name && this.props.id) || parent_list_name_error) &&
                                <div style={{ color: 'red' }} className="error-block mt-2">{t("Give parent name to add childs")}</div>
                              }
                              {parent_list_uniquename_error &&
                                <div style={{ color: 'red' }} className="error-block mt-2">{t("The name has already been taken !")}</div>
                              }
                            </div>
                          </div>
                          &nbsp;&nbsp;&nbsp;
                          {/*
                          {this.props.type !== 'view' &&
                            <div class="col-md-12 mt-2 pl-4 input-padd">
                              <Button style={{ fontSize: '15px' }} type="button" className="btn btn-primary" onClick={e => this.addChild()}>{t('Add childs')}</Button>
                            </div>
                          }
                          */}
                          {(child_textbox || (this.props.type === 'edit')) && parent_list_name && !parent_list_uniquename_error &&
                            <>
                            <div className="row col-md-12 mb-3">
                              <div className="col-md-4">
                                <reactbootstrap.InputGroup.Prepend>
                                  <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Item name')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                                </reactbootstrap.InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd" onKeyPress={e => this.handleKeyPress(e, 'child')}>
                                <reactbootstrap.FormControl
                                  name='child_name'
                                  autoFocus
                                  placeholder={t("Item name")}
                                  aria-label="Functionname"
                                  aria-describedby="basic-addon1"
                                  value={child_name}
                                  // onChange={{this.handleChange}
                                  onChange={e => this.handleChange(e.target.name, e.target.value, 'Child')}
                                  className="input_sw"
                                  disabled={formDisable}
                                />
                                {child_name_error &&
                                  <div style={{ color: 'red' }} className="error-block mt-2">{t("Child should not be empty !")}</div>
                                }
                                {child_nameunique_error &&
                                  <div style={{ color: 'red' }} className="error-block mt-2">{t("The name has already been taken !")}</div>
                                }
                              </div>
                            </div>
                            </>
                          }
                          <div className="col-md-12">
                            <div className="fixed-header">
                              <div  className="table-values"  style={{width: '100%', float: 'left'}}>
                                <div className="column1">{t("Value")}</div>
                                <div className="column4">{t("Id")}</div>
                                <div className="column2">{t("Hide")}</div>
                                <div className="column3">{t("Add translations")}</div>
                              </div>
                              <div style={{width: '100%', float: 'left'}}>
                                <div className="column1">
                                  <div className="one">
                                    <input type="text" autofocus className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#ec661c" }} value={this.state.searchTerm} placeholder={t("Search item")} onChange={this.searchData} />
                                  </div>
                                </div>
                                <div className="column4">
                                  <div className="tw0" style={{ textAlign: 'center'}}>

                                  </div>
                                </div>
                                <div className="column2">
                                  <div className="three" style={{ textAlign: 'center'}}>
                                    <reactbootstrap.Form.Check
                                      name='hide'
                                      checked='true'
                                    />
                                  </div>
                                </div>
                                <div className="column3">
                                 <div>
                                   <span className="" variant="link">
                                     <p>{t("Translations")}</p>
                                   </span>
                                 </div>
                               </div>
                             </div>
                            </div>
                            {child_items.length !== 0 &&
                                <reactbootstrap.Table className="site-table-main list-table">
                                  <tbody>
                                    <SortingChilds id={this.props.id} type={modeType} child_items={this.state.filterFullList} updateChilds={this.updateChilds.bind(this)} translationsDisplay = {this.translationsDisplay.bind(this)} showHiddenList={this.props.showHiddenList} formDisable={formDisable} searchTerm={this.state.searchTerm} details={this.state}
                                      onSortEnd={this.onSortEnd.bind(this)} showtranslationPopup={this.state.showtranslationPopup} handlePopupCancel = {this.handlePopupCancel} languages = {this.state.languages} translatechildItems = {this.state.translatechildItems} currentTranslations={this.state.currentTranslations}
                                      currentChildKey = {this.state.currentChildKey} translationsCancel  = {this.translationsCancel.bind(this)} translationsOk = {this.translationsOk.bind(this)} listId = {this.props.id} unsavedData = {this.state.unsavedData}/>
                                  </tbody>
                                </reactbootstrap.Table>
                            }
                          </div>
                        </reactbootstrap.InputGroup>
                      </div>
                    </reactbootstrap.FormGroup>
                    {this.props.type !== 'view' &&
                      <FormGroup>
                        <div style={{ float: 'right' }} className="organisation_list mt-3 mr-3">
                          <a onClick={this.handleCancel} >{t('Cancel')}</a>
                          &nbsp;&nbsp;&nbsp;
                          <Button disabled={savevalue} className="btn btn-primary" type="button" color="primary" onClick={() => this.handleSubmit("save")}> {t('Save')} </Button>
                          {popupContent}
                        </div>
                      </FormGroup>
                    }
                    {saveDataContent}
                  </reactbootstrap.Form>
                  {this.state.showImapactModal === true && this.popupModal()}
                </reactbootstrap.Container>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  closeImpactModal = () => {
    this.setState({
      showImapactModal:false,
    })
  }

  popupModal = () => {
    const { impactData, changes, forwardTosaveDetails, t } = this.state;
    let changedTxt = '';
    if(changes.parentNameEdited || changes.childListsEdited || changes.newChildAdded || changes.childSettingsChanged){
      changedTxt = changes.parentNameEdited ? 'List name is modified' : '';
      changedTxt = changes.newChildAdded ? (changedTxt + (changedTxt ? ', n':'N')) + 'ew sub list added' : changedTxt;
      changedTxt = changes.childSettingsChanged ? (changedTxt + (changedTxt ? ', s':'S')) + 'ub list settings changed' : changedTxt;
      changedTxt = changes.childListsEdited ? (changedTxt + (changedTxt ? ', s':'S')) + 'ub lists names are modified' : changedTxt;
    }
    return(
        <reactbootstrap.Modal
          show={this.state.showImapactModal}
          onHide={() => this.closeImpactModal()}
          size="lg"
          aria-labelledby="example-custom-modal-styling-title"
        >
        <reactbootstrap.Modal.Header closeButton>
           <p className='common-color' style={{textAlign : 'center', width:'100%', fontSize : 'large' }}> {t('Impact analysis')} </p>
        </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body col-md-12>
          {(impactData.length>0 )?  <div>
                 <reactbootstrap.Table className="" >
                   <th style={{position: 'sticky',zIndex: '99',top: '0',backgroundColor: '#ffffff'}}>{t('Document code')}</th>
                   <th style={{position: 'sticky',zIndex: '99',top: '0',backgroundColor: '#ffffff'}}>{t('Document name')}</th>
                   <th style={{position: 'sticky',zIndex: '99',top: '0',backgroundColor: '#ffffff'}}>{t('Document version')}</th>
                   {impactData.map(doc => {
                     return <tr><td>{doc.code}</td>
                       <td>{doc.name}</td>
                       <td>{doc.version}</td>
                     </tr>
                   })
                   }
                 </reactbootstrap.Table>
                 <p><strong>{t('Changes')}</strong>: {changedTxt}.</p>
               </div> :
            <div style={{color:'gray',fontSize: "large"}}>{t("No details linked with this list, you want to delete this list ?")}</div>}
          </reactbootstrap.Modal.Body>
          <reactbootstrap.Modal.Footer>
              <FormGroup>
                <div style={{ float: 'right' }} className="organisation_list mt-3 mr-3">
                  <a onClick={() => this.closeImpactModal()} >{t('Cancel')}</a>
                  &nbsp;&nbsp;&nbsp;
                  <Button className="btn btn-primary" type="button" color="primary" onClick={() => this.forwardTosaveMethod(window.LISTNCHILDS, forwardTosaveDetails, 1, changes)}> {t('Save')} </Button>
                </div>
              </FormGroup>
          </reactbootstrap.Modal.Footer>
        </reactbootstrap.Modal>
    );
  }
}

export default translate(ListForm);
