import React, { Component } from 'react';
import Pagination from 'react-bootstrap/Pagination'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import SearchInput, { createFilter } from 'react-search-input';
import Can from '../../_components/CanComponent/Can';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
import { CanPermissions } from '../../_components/CanComponent/CanPermissions';
import { translate } from '../../language';
import { OCAlert } from '@opuscapita/react-alerts';
import ListForm from './ListForm';
import { Link } from "react-router-dom";
import * as reactbootstarp from 'react-bootstrap';
import './ListForm.css';
import './showHide.css';
import { store } from '../../store';


class ManageList extends Component {

  constructor(props) {
    super(props)
    const listType = this.getListType()
    const main_header = window.GET_TYPE_DETAILS[listType]["main_header"];
    const add_type = window.GET_TYPE_DETAILS[listType]["add_type"];
    const create_type = window.GET_TYPE_DETAILS[listType]["create_type"];
    const title_type = window.GET_TYPE_DETAILS[listType]["title_type"];
    const popup_name = window.GET_TYPE_DETAILS[listType]["popup_name"];
    this.state = {
      t: props.t,
      component: 'false',
      parent_items: [],
      items: [],
      type: 'view',
      active: 1,
      count: 0,
      page: 5,
      show_deletePopup: false,
      searchTerm: '',
      saveComponent: "",
      didupdate: false,
      showHiddenList: false,
      simulation_list: [],
      listOrSchedular: listType,
      listType: listType,
      main_header: main_header,
      add_type: add_type,
      create_type: create_type,
      title_type: title_type,
      popup_name: popup_name,
      popup_deleteItems: [],
      popup_deleteName: '',
      popup_CNV: [],
      show_inactivePopup: false,
      dataPerPage:4,
      currentPage:1
    }
    this.updateParentList = this.updateParentList.bind(this);
    this.searchData = this.searchData.bind(this);
  }

  changeComponent(e, type, id = undefined) {
    localStorage.removeItem('active_child');
    this.setState({
      component: 'true',
      type: type,
      parent_id: id,
    });

  }
  getListType() {
    if (window.location.href.includes('schedular')) {
      return window.SCHEDULARTYPE;
    }
    else if (window.location.href.includes('list')) {
      return window.LISTTYPE;
    }
    else if (window.location.href.includes('category')) {
      return window.CATEGORYTYPE;
    }
    else if (window.location.href.includes('location')) {
      return window.LOCATIONTYPE;
    }
  }
  updateComponent(showComponent, type, currentParent) {
    if (showComponent) {
      const URL = window.PARENT_LISTS + '/' + this.state.listOrSchedular;
      datasave.service(URL, 'GET')
        .then(response => {
          const lists_data = response
          var fist_list = lists_data[0]
          const pageData = this.getPageData(this.state.active, response);
          const count = this.getCountPage(response);
          this.setState({
            component: 'true',
            parent_items: response,
            count: count,
            items: pageData,
            type: type,
            parent_id: currentParent,
            saveComponent: 1,
          })
        })
    } else {
      this.setState({
        component: 'false',
        type: type,
        parent_id: currentParent,
      })
    }

  }

  componentDidMount() {
    const URL = window.PARENT_LISTS + '/' + this.state.listOrSchedular;
    const URL1 = window.IsListUsedInSimulation;

    datasave.service(URL1, 'GET').then(response => {
      this.setState({
        simulation_list: response
      })
    })

    datasave.service(URL, 'GET')
      .then(response => {
        const lists_data = response
        var fist_list = lists_data[0];
        const pageData = this.getPageData(this.state.active, response);
        const count = this.getCountPage(response);
        this.setState({
          component: (response.length > 0) ? 'true' : 'false',
          parent_items: response,
          count: count,
          items: pageData,
          parent_id: fist_list ? fist_list['id'] : undefined,
          type: 'view',
        })
      })

  }

  componentDidUpdate(prevProps, prevState) {

    if (prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
      const URL = window.PARENT_LISTS + '/' + this.state.listOrSchedular;
      datasave.service(URL, 'GET')
        .then(response => {
          const pageData = this.getPageData(this.state.active, response);
          const count = this.getCountPage(response);
          this.setState({
            component: (response.length > 0) ? 'true' : 'false',
            parent_items: response,
            count: count,
            items: pageData,
            didupdate: false,
            type: 'view',
            saveComponent: "",
          }, () => this.searchData())
        })
    }
  }

  componentWillMount() {
    // this.setState({ items: this.state.parent_items })
  }

  updateParentList(currentParentId) {
    const URL = window.PARENT_LISTS + '/' + this.state.listOrSchedular;
    datasave.service(URL, 'GET')
      .then(response => {
        this.setState({
          parent_items: response,
        })
        response.map((list, index) => {
          if (list.id == currentParentId) {
            const activePage = Math.ceil((index + 1) / 5)
            this.changePage('', activePage)
          }
        })

      })
  }

  async handleDelete(id) {
    let name = '';
    // await datasave.service(URL, 'GET')
    //   .then(async response => {
    //     await response.map(value => {
    //       { name.push(value["name"]) }
    //       console.log(name)
    //     })
    //   })
    this.state.parent_items.map(async (list) => {
      if (list.id === id) {
        name = list.name
      }
    });
    this.setState({
      show_deletePopup: true,
      delete_list_id: id,
      // popup_deleteItems: name,
      popup_deleteName: name,
    })

  }

  async handleInactive(id) {

    let name = ''
    this.state.parent_items.map(async (list) => {
      if (list.id === id) {
        name = list.name
      }
    });
    this.setState({
       popup_CNV: []
    })
    const URL = window.SUBLISTNAME + '/' + id + '/' + this.state.listType;
    await datasave.service(URL,'GET')
      .then(response =>{
        this.setState({ popup_CNV: response, popup_deleteName: name, })
      });
    this.setState({ show_inactivePopup: true ,delete_list_id:id})
  }
  handleOk() {

    const { t } = this.state
    var url = window.DELETE_LIST + '/' + this.state.delete_list_id + '/' + this.state.listType;
    var pageData = [];
    var count = 0;
    var pre_id = '';

    datasave.service(url, 'PUT')
      .then(response => {

        if (this.state.items.length > 1) {
          pageData = this.getPageData(this.state.active, response);
          count = this.getCountPage(response);

          this.state.parent_items.map((list, index) => {
            if (list.id === this.state.delete_list_id) {
              var activePage = Math.ceil((index + 1) / 5);
              this.changePage('', activePage);
            }
            else {
              pre_id = list.id;
            }
          })

        } else if (this.state.items.length === 1) {
          pageData = this.getPageData(this.state.active - 1, response);
          count = this.getCountPage(response);

          this.state.parent_items.map((list, index) => {
            if (list.id === this.state.delete_list_id) {
              var activePage = Math.ceil((index + 1) / 5);
              this.changePage('', activePage - 1);
            }
            else {
              pre_id = list.id;
            }
          })

        }
        this.setState({
          count: count,
          parent_items: response,
          items: pageData,
          parent_id: pre_id,
          show_deletePopup: false,
          didupdate: true,
        })

      })

  }
  getCountPage(items) {
    const itemLength = items.length;
    return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }

  getPageData(id, list = '') {
    const page = this.state.page;
    const items = (list !== '') ? list : this.state.parent_items;
    const page_data = items.slice(page * (id - 1), page * id);

    return page_data;
  }

  changePage(e, id) {
    const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
    const page_data = this.getPageData(id, list);
    this.setState({
      items: page_data,
      active: id,
    });
  }

  searchData(string = '', onChange = 0) {
    let searchterm = onChange === 1 ? string : this.state.searchTerm;
      var list = [...this.state.parent_items];
      let res = '';
      list = list.filter(function (item) {
        if (item.name !== null) {
          res = item.name.toLowerCase().search(
            searchterm.toLowerCase()) !== -1;
        }
        return res;
      });
      let active = searchterm !== '' ? 1 : this.state.active;
      const page_data = this.getPageData(active, list);
      const count = this.getCountPage(list);
      this.setState({
        items: page_data,
        count: count,
        active: active,
        searchTerm: searchterm,
        filterFullList: list,
      });
  }

  handlePopupCancel = () => {
    this.setState({ show_deletePopup: false, });
  }

  showHiddenList(e) {
    this.setState({
      showHiddenList: !this.state.showHiddenList,
    })
  }
  handleInactivePopupCancel = () => {
    this.setState({
      show_inactivePopup: false,
    });
  }
  deleteViaImpactAnalysis =async ()=>{
    await this.handleInactivePopupCancel();
    await this.handleOk();
  }
  handlePageClick(event) {
      this.setState({
          currentPage: Number(event.target.id)
      });
  }

  render() {
    const popup_CNVLength=this.state.popup_CNV;
    const { t } = this.state;
    let Userdata = store.getState();
    const accessPage = (this.state.listType === window.LISTTYPE) ? CanPermissions("E_list,V_list,D_list", "") : ((this.state.listType === window.SCHEDULARTYPE) ? CanPermissions("E_schedular,V_schedular,D_schedular", "") : ((this.state.listType === window.CATEGORYTYPE) ? CanPermissions("E_category,V_category,D_category", "") : CanPermissions("E_location,V_location,D_location", "")));
    const addEditList = (this.state.listType === window.LISTTYPE) ? CanPermissions("E_list", "") : ((this.state.listType === window.SCHEDULARTYPE) ? CanPermissions("E_schedular", "") : ((this.state.listType === window.CATEGORYTYPE) ? CanPermissions("E_category", "") : CanPermissions("E_location", "")));
    const DeleteList = (this.state.listType === window.LISTTYPE) ? CanPermissions("D_list", "") : ((this.state.listType === window.SCHEDULARTYPE) ? CanPermissions("D_schedular", "") : ((this.state.listType === window.CATEGORYTYPE) ? CanPermissions("D_category", "") : CanPermissions("D_location", "")));
    const { parent_items, parent_id, active, simulation_list ,popup_CNV,dataPerPage,currentPage} = this.state;
    const indexOfLastdata = currentPage * dataPerPage;
    const indexOfFirstData = indexOfLastdata - dataPerPage;
    const currentData = popup_CNV.slice(indexOfFirstData, indexOfLastdata);
    const filtered = this.state.items;
    let pages = [];
    if (this.state.count > 0)
      for (let number = 1; number <= this.state.count; number++) {
        pages.push(
          <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
            {number}
          </Pagination.Item>,
        );
      }

    const popup_deleteItems = this.state.popup_deleteItems;
    const pageNumbers = [];
    if(popup_CNV.length > 4) {
        for (let i = 1; i <= Math.ceil(popup_CNV.length / dataPerPage); i++) {
        pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
            {i}
        </Pagination.Item>);
    }
  }
    const ncm = <reactbootstrap.Table className="" >

      <th style={{position: 'sticky',zIndex: '99',top: '0',backgroundColor: '#ffffff'}}>{t('Document code')}</th>
      <th style={{position: 'sticky',zIndex: '99',top: '0',backgroundColor: '#ffffff'}}>{t('Document name')}</th>
      <th style={{position: 'sticky',zIndex: '99',top: '0',backgroundColor: '#ffffff'}}>{t('Document version')}</th>

      {currentData.map(doc => {

        return <tr><td>{doc.code}</td>
          <td>{doc.name}</td>
          <td>{doc.version}</td>
        </tr>
      })
      }
    </reactbootstrap.Table>
    const inactivePopUp = (
      <reactbootstarp.Modal
        show={this.state.show_inactivePopup}
        onHide={this.handleInactivePopupCancel}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstarp.Modal.Header closeButton>
          <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
          {/*{this.state.title_type}*/}
            {t("Impact analysis")}
          </reactbootstarp.Modal.Title>

        </reactbootstarp.Modal.Header>
        <reactbootstarp.Modal.Body col-md-12>
          {/* <div>{t("Are you sure do you want to inactive this ") + (this.state.popup_deleteName + ' ' + this.state.popup_name)}</div> */}

        {(popup_CNVLength.length>0 )?  <div><div style={{color:'gray',fontSize: "large"}}>{t("Details in this") + (this.state.popup_deleteName + ' ' + this.state.title_type)}</div><div > {this.state.show_inactivePopup === true?ncm:''} </div></div>:<div style={{color:'gray',fontSize: "large"}}>{t("No details linked with this list, you want to delete this list ?")}</div>}
        <Pagination style={{width: '530px', overflow: 'auto'}} size="sm">{pageNumbers}</Pagination>
        </reactbootstarp.Modal.Body>
      {popup_CNVLength.length>0 &&  <reactbootstarp.Modal.Footer>
          <reactbootstarp.Button onClick={() => this.handleInactivePopupCancel()}>{t('Cancel')}</reactbootstarp.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
                {/* <reactbootstarp.Button >{t('Inactive')}</reactbootstarp.Button> */}
        </reactbootstarp.Modal.Footer>}
        {popup_CNVLength.length<1 &&  <reactbootstarp.Modal.Footer>
            <reactbootstarp.Button onClick={() => this.handleInactivePopupCancel()}>{t('No')}</reactbootstarp.Button>
            <reactbootstarp.Button onClick={() => this.deleteViaImpactAnalysis()}>{t('Yes')}</reactbootstarp.Button>
            &nbsp;&nbsp; &nbsp;&nbsp;
                  {/* <reactbootstarp.Button >{t('Inactive')}</reactbootstarp.Button> */}
          </reactbootstarp.Modal.Footer>}
      </reactbootstarp.Modal>
    );

    const popupContent = (
      <reactbootstarp.Modal
        show={this.state.show_deletePopup}
        onHide={this.handlePopupCancel}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstarp.Modal.Header closeButton>
          <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
          {/*{this.state.title_type}
            // {t("Impact Analysis")}*/}
        {t("Delete ")}
          </reactbootstarp.Modal.Title>

        </reactbootstarp.Modal.Header>
        <reactbootstarp.Modal.Body col-md-12>
          {t("Are you sure do you want to delete this ") + (this.state.popup_deleteName + ' ' + this.state.popup_name)}
        </reactbootstarp.Modal.Body>
        <reactbootstarp.Modal.Footer>
          <reactbootstarp.Button onClick={() => this.handlePopupCancel()}>{t('Cancel')}</reactbootstarp.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
                <reactbootstarp.Button onClick={() => this.handleOk()}>{t('OK')}</reactbootstarp.Button>
        </reactbootstarp.Modal.Footer>
      </reactbootstarp.Modal>
    );
    this.state.simulation_list.map(ele => {

    })
    let Lists_body = filtered.map((parent, key) => {
      if (parent.type == 1 || parent.type === 2) {
        let higlet_class = ((parent.id === parent_id)) ? 'sactive' : 'sinactive';
        return (
          <tr style={{ borderBottom: "1px solid #dee2e6" }} className={higlet_class}>
            <td style={{ cursor: 'pointer', hover: 'color:#007bf8' }} onClick={(e) => this.changeComponent(e, 'view', parent.id)}>{parent.type == 1 ? <i style={{ float: 'left' }} class="webform-sprite webform-sprite-listnamec"></i> : <i style={{ float: 'left' }} class="webform-sprite webform-sprite-timetablec"></i>}<span>{parent.name}</span></td>
            <td style={{ display: "flex", justifyContent: 'center', borderTop: '0px', borderBottom: '0px', borderLeft: '0px' }}>
              {addEditList &&
                <div style={{ paddingLeft: '10px' }}>
                  <span className="" variant="link">
                    <i title={t("Edit")} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc" onClick={(e) => this.changeComponent(e, 'edit', parent.id)}></i>
                  </span>
                </div>
              }
              {/*<div style={{paddingLeft: '10px'}}>
                <span className="" variant="link">
                    <i title="View"  style ={{'cursor':'pointer'}} class="overall-sprite overall-sprite-myeditc" onClick={(e) => this.changeComponent(e, 'view', parent.id)}></i>
                </span>
              </div> */}
              {simulation_list.indexOf(parent.id) !== -1 ?
                <div style={{ paddingLeft: '10px' }} ><span><i title={t("Active")} class="overall-sprite overall-sprite-myinactivec" ></i></span>{popupContent}{inactivePopUp}</div> :
                <div style={{ paddingLeft: '10px' }}>
                  {DeleteList &&
                    <>
                      <span className="" variant="link" onClick={this.handleDelete.bind(this, parent.id)}>
                        <i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec"></i>
                      </span>
                      {popupContent}{inactivePopUp}
                    </>
                  }
                </div>
              }
              {simulation_list.indexOf(parent.id) !== -1 ? <div class="pl-2" id="11" style={{}}>

              <i title={t("Open")} class="overall-sprite overall-sprite-gridopenc" id={parent.id} onClick={(e) => this.handleInactive(e.target.id)}></i></div> : <span id='11'></span>}

            </td>

          </tr>
        )
        // })
      } else {
        let higlet_class = ((parent.id === parent_id)) ? 'sactive' : 'sinactive';
        return (
          <tr style={{ borderBottom: "1px solid #dee2e6" }} className={higlet_class}>
            <td style={{ cursor: 'pointer', hover: 'color:#007bf8' }} onClick={(e) => this.changeComponent(e, 'view', parent.id)}>{parent.type == 3 ? <i style={{ float: 'left' }} class="sprite-filecl sprite-filecl-fcategoryc"></i> : <i style={{ float: 'left' }} class="sprite-filecl sprite-filecl-flocationc"></i>}<span>{parent.name}</span></td>
            <td style={{ display: "flex", justifyContent: 'center', borderTop: '0px', borderBottom: '0px', borderLeft: '0px' }}>
              {addEditList &&
                <div style={{ paddingLeft: '10px' }}>
                  <span className="" variant="link">
                    <i title={t("Edit")} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc" onClick={(e) => this.changeComponent(e, 'edit', parent.id)}></i>
                  </span>
                </div>
              }
              {/*<div style={{paddingLeft: '10px'}}>
                <span className="" variant="link">
                    <i title="View"  style ={{'cursor':'pointer'}} class="overall-sprite overall-sprite-myeditc" onClick={(e) => this.changeComponent(e, 'view', parent.id)}></i>
                </span>
              </div> */}
              {simulation_list.indexOf(parent.id) !== -1 ?
                <div style={{ paddingLeft: '10px' }}><span><i title={t("Active")} class="overall-sprite overall-sprite-myinactivec"></i></span></div> :
                <div style={{ paddingLeft: '10px' }}>
                  {DeleteList &&
                    <>
                      <span className="" variant="link" onClick={this.handleDelete.bind(this, parent.id)}>
                        <i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec"></i>
                      </span>
                      {popupContent}{inactivePopUp}
                    </>
                  }
                </div>
              }
            </td>
          </tr>
        )
        // })

      }
    })
    if (accessPage && (Userdata.UserData.webformAccess === 1)) {
      return (
        <div className='container webform-list-page'>
          <div className="card-body mb-3">
            <div className='row'>
              <div className='col-md-12 mb-3'>
                <div className='card'>
                  <div className="text-center">
                    <div className='card-header d-none'><h3>{t(this.state.main_header)}</h3></div>
                  </div>
                  <div className="row container">
                    <reactbootstrap.Col lg={4}>
                      <div className="text-center">
                        <h3 className="mt-3 mb-3  d-none" style={{}}>{t(this.state.title_type)} </h3><hr />
                        <div style={{ display: 'flex' }} className="mb-2">
                          <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C" }} placeholder={t("What are you looking for ?")} autoFocus onChange={(e) => this.searchData(e.target.value, 1)} /><br />
                          {addEditList &&
                            <reactbootstrap.Button onClick={(e) => this.changeComponent(e, 'create')} variant="link">
                              <i title={t(this.state.add_type)} class="webform-sprite webform-sprite-createlistc"></i>
                            </reactbootstrap.Button>
                          }
                          <reactbootstrap.Button onClick={(e) => this.showHiddenList(e)} variant="link">
                            {this.state.showHiddenList &&
                              <i title={t("Show hidden list")} class="eye eye-show"></i>
                            }
                            {!this.state.showHiddenList &&
                              <i title={t("Show hidden list")} class="eye eye-hide"></i>
                            }
                          </reactbootstrap.Button>
                        </div>
                        <reactbootstrap.Table responsive bordered hover>
                          <thead>
                            <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
                              <th>{t('Name')}</th>
                              <th>{t('Actions')}</th>
                            </tr>
                          </thead>
                          <tbody>
                            {Lists_body}
                          </tbody>
                        </reactbootstrap.Table>
                        <div className="pg col-md-12">
                          {pages.length > 1 && <Pagination style={{ width: '200px', overflow: 'auto' }} size="md">{pages}</Pagination>}
                        </div>
                      </div>
                    </reactbootstrap.Col>
                    {this.state.component === 'true' &&
                      <reactbootstrap.Col lg={8} className='mt-2'>
                        <h3 className=""></h3>
                        <ListForm type={this.state.type} id={this.state.parent_id} parent_items={this.state.parent_items} title_type={this.state.title_type} updateParentList={this.updateParentList} showHiddenList={this.state.showHiddenList} updateComponent={this.updateComponent.bind(this)} />
                      </reactbootstrap.Col>
                    }
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    } else {
      return (
        <AccessDeniedPage />
      );
    }

  }
}

export default translate(ManageList);
