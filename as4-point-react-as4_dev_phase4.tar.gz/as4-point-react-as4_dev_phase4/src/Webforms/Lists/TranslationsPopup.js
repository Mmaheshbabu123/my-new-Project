import React, { Component } from 'react';
import { render } from 'react-dom';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../../language';
import { datasave } from '../../_services/db_services';


class TranslationsPopup extends Component {

  constructor(props) {
    super(props)
    this.state = {
      t: props.t,
      popupCurrentTranslations :[],
      translateChilds: [],
    }
  }

  componentDidMount() {
    this.getTranslation(this.props.currentTranslations);

    {/*if (this.props.unsavedData === undefined || this.props.unsavedData === null) {
      if (this.props.listId !== undefined) {
        const URL = window.GET_PARENTLIST_DATA + '/' + this.props.listId;
          datasave.service(URL, 'GET')
            .then(response => {
              let data = response.translatedChildData;
              this.setState({
                translateChilds: data,
              }, () => { this.getTranslation(data[this.props.currentChildKey]) });
            })
      } else {

      }
    } else {
      this.setState({
        translateChilds: this.props.unsavedData,
      }, () => { this.getTranslation(this.props.unsavedData[this.props.currentChildKey]) });

    }
    */}
  }

  getTranslation(data) {
    let current_translation = [];
    let current_list_translations = data;
    Object.entries(current_list_translations).forEach(([key, value]) => {
      current_translation.push(value);
    })
    this.setState({
      popupCurrentTranslations: current_translation,
    })
  }

  updateTranslations(translationValue, parentChildKey, languageKey) {
    let popUpTranslations = this.state.popupCurrentTranslations;

    popUpTranslations.map((value, index) => {
      if (value.language_id == languageKey) {
          value.name = translationValue;
      }
    })
    this.setState({
      popupCurrentTranslations: popUpTranslations,
    })
    let newList = (this.props.listId === undefined) ? 'new' : 'old';
    localStorage.setItem('listNewOrOld', newList);
    if (this.props.listId !== undefined) {
      localStorage.setItem('listTranslationUpdate', 1);
    }
  }

  // translationsOk(updatedTranslations, parentChildKey) {
  //   this.props.translationsOk(this.state.translateChilds, updatedTranslations, parentChildKey);
  // }

  // translationsCancel() {
  //   this.props.translationsCancel(this.state.translateChilds);
  // }


  render() {
    const {t} = this.state;
    const { popupCurrentTranslations } = this.state;

    const translationPopup = (
      <reactbootstrap.Modal
        show={this.props.showtranslationPopup}
        onHide={this.props.translationsCancel}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
            {"Add translations"}
          </reactbootstrap.Modal.Title>
        </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body col-md-12>
            {popupCurrentTranslations.map((value, index) => (
              <>
                <div className="col-md-12 row mb-3">
                  <div className="col-md-4">
                    <reactbootstrap.InputGroup.Prepend>
                      <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{value.language}</reactbootstrap.InputGroup>
                    </reactbootstrap.InputGroup.Prepend>
                  </div>
                  <div class="col-md-8 input-padd">
                    <reactbootstrap.FormControl
                      name={'translation' + index}
                      placeholder={""}
                      aria-label="Functionname"
                      aria-describedby="basic-addon1"
                      value={value.name}
                      onChange={e => this.updateTranslations(e.target.value, this.props.currentChildKey, value.language_id)}
                      className="input_sw"
                    />
                  </div>
                </div>
              </>
            ))}
          </reactbootstrap.Modal.Body>
        {/*
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={() => this.translationsCancel()}>{t('Cancel')}</reactbootstrap.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
          <reactbootstrap.Button onClick={() => this.translationsOk(this.state.popupCurrentTranslations, this.props.currentChildKey)}>{t('Ok')}</reactbootstrap.Button>
        </reactbootstrap.Modal.Footer>
        */}
      </reactbootstrap.Modal>
    );

    return (
      <div>
        {translationPopup}
      </div>

    );
  }

}

export default translate(TranslationsPopup)
