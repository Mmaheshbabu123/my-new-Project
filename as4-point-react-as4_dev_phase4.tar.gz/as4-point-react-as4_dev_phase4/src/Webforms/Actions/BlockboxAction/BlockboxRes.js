import React, { Component } from 'react'
import { translate } from '../../../language'
import * as Reactbootstrap from 'react-bootstrap'
import { OCAlert } from '@opuscapita/react-alerts';
class BlockboxRes extends Component {

    constructor(props){
        super(props)
        this.handleChange = this.handleChange.bind(this)
        this.handleSelect = this.handleSelect.bind(this)
        this.getIntialState();
    }
    getIntialState =()=>{
        this.state = {
            t:this.props,
            responsible_type:1,
            responsible_type_id:undefined,
            clickorigin:undefined,
            from_distance:1,

        }
    }
    handleChange(event) {
      const { name, value } = event.target;
       this.setState({ [name]: value});
     }
     handleSelect(event) {
       const { name, value } = event.target;
      this.setState({ [name]: !this.state[name],})
     }
    componentWillReceiveProps(nextProps){

        if(this.props.edit){
            const {data} =  this.props

            // border:this.cssobj.border,custom:this.cssobj.customcss,background:this.cssobj.background,
            //         color:this.cssobj.color
                    let obj = data.editblockbox


            this.setState({
              responsible_type:obj.responsible_type,
              responsible_type_id:obj.responsible_type_id,
              from_distance:obj.from_distance,
            })
        }

    }
    render(){
console.log(this.props)
this.props.sendblockbox(this.state)

        return(
                <>
                {this.getRenderContent()}
                </>
        )
    }
    getRenderContent =()=>{

        const {responsible_type,responsible_type_id,from_distance,handleChange,handleSelect} =  this.state
        let string = parseInt(responsible_type) === window.PERSON_ENTITY ? 'person' : parseInt(responsible_type) === 2 ? 'jobs' : parseInt(responsible_type) === 3 ? 'departments' : 'groups';
          let obj = this.props.pjgd[string] === undefined ? [] :this.props.pjgd[string];
        const html  =(
            <>
              <div className="col-md-12"style = {{}}>
                <Reactbootstrap.Form className="col-md-12">
                    <Reactbootstrap.Form.Group controlId="formBasicEmail">

                       <div className = 'row col-md-12'>
                           <Reactbootstrap.Form.Label className="col-md-4 p-0" style = {{color: 'rgb(236, 102, 28)'}} >Block box responsible:</Reactbootstrap.Form.Label>

                        <div className = 'col-md-8 p-0 input_sw'>
                            <Reactbootstrap.Form.Control
                            name="responsible_type"
                            as="select"
                            value={this.state.responsible_type}
                            onChange={this.handleChange} >
                                <option value={window.PERSON_ENTITY}>{'Person'}</option>
                                <option value={window.JOB_ENTITY}>{'Job'}</option>
                                <option value={window.DEPARTMENT_ENTITY}>{'Department'}</option>
                                <option value={window.GROUP_ENTITY}>{'Group'}</option>
                                <option value = {window.IMPORTED_LIST}>{'Imported list'}</option>
                            </Reactbootstrap.Form.Control>
                        </div>
                       </div>
                    </Reactbootstrap.Form.Group>
                    <Reactbootstrap.Form.Group>

                     <div className = 'row col-md-12'>
                       <Reactbootstrap.Form.Label className="col-md-4 p-0" style = {{color: 'rgb(236, 102, 28)'}} >Organisational unit:</Reactbootstrap.Form.Label>
                        <div className = 'col-md-8 p-0 input_sw'>
                              <Reactbootstrap.FormControl as="select" name="manual_id"
                                  value={responsible_type_id}
                                  name = {'responsible_type_id'}
                                  // disabled={details.disableFields || details.exp_his_disabled}
                                  onChange={this.handleChange}
                                  className="input_sw"
                              >   <option value={0}>{'---Select---'}</option>
                              { (obj !== undefined && obj.length > 0) ? obj.map(org => <option value={org.id}>{org.name}</option>):[]}
                                </Reactbootstrap.FormControl>
                        </div>
                      </div>
                      </Reactbootstrap.Form.Group>
                              <Reactbootstrap.FormGroup className="mt-3">
                                  <Reactbootstrap.Form.Check
                                      onChange={this.handleSelect}
                                      name='from_distance'
                                      checked={from_distance}
                                      disabled={false}
                                      label={"From a distance"}
                                  />
                              </Reactbootstrap.FormGroup>
                      </Reactbootstrap.Form>

                </div>
            </>
        )
        return html
    }

  }
  export default translate(BlockboxRes)
