export const create = {
    createRule
};
var cloneRule = ''; var count = 0;
var nodeAdded =  false;

function createRule(obj = '', treeData= '', stateObj= '') {


    const createdobj = createObj(obj, stateObj);

    if (treeData.length === 0) {
        createdobj.showworkflow =1
        treeData = [createdobj]
        return  { tree: treeData,
                  createdobj :createdobj,
                  nodeadded:nodeAdded,
   }
    } else {


        createTreeStructure(createdobj, treeData, stateObj);
    }

    return { tree: treeData,
             createdobj :createdobj,
             nodeadded:nodeAdded,
    }
}
function createObj(obj, stateObj) {
    let data = {}
    const { orgArrayIds, type, clickid, edittype, editclick } = stateObj
    let rule = editclick ? ((parseInt(edittype) === 1) ? 'And' : 'OR') : ((type === 1) ? 'And' : 'OR');
    let name = obj.author; let label; let label2;
    if (orgArrayIds.includes(parseInt(obj.action))) {
        cloneRule = 'OR' + ' ' + name + ' Equals ' + obj.orgunit
        label = rule + ' ' + name + ' Equals ' + obj.orgunit;
    } else {
        name = parseInt(obj.action) === window.WEBFORM_CALCULATION ? obj.control : 'Workflow';
        let operator = parseInt(obj.action) === window.WEBFORM_CALCULATION ? obj.operator : 'Equals';
        let value = parseInt(obj.action) === window.WEBFORM_CALCULATION ? obj.value : obj.workflow;
        cloneRule = 'OR' + ' ' + name + ' ' + operator + ' ' + value;
        label2 = rule + ' ' + name + ' ' + operator + ' ' + value;
    }
    return data = {
        label: orgArrayIds.includes(parseInt(obj.action)) ? label : label2,
        key: 'N' + Math.floor(Math.random() * 10000) + 1,
        index: (editclick) ? clickid : Math.floor(Math.random() * 1000) + 1,
        parent: 12,
        action: obj.action,
        orgname: obj.orgunit,
        orgid: obj.orgid,
        control: obj.control,
        controlType: obj.controlType,
        controlid: obj.controlid,
        operator: obj.operator,
        operatorId: obj.operatorId,
        workflow: obj.workflow,
        workflowid: obj.workflowid,
        value: obj.value,
        valueId:obj.valueId,
        type: editclick ? edittype : type,
        name: name,
        operatorid: obj.operatorId,
        nodes: [],
        onleave:obj.onleave,
        onenter:obj.onenter,
        showworkflow:0,
        valueType:obj.valueType,
        isDateType:obj.isDateType,
        count:obj.count,
        periodtype:obj.periodtype,
        category:obj.category,
        color:obj.color ? obj.color : '', // required only for ground plan
    }

}
function createTreeStructure(obj, data, stateObj) {


    Object.values(data).map((item1, at) => {
        if (item1.index === stateObj.clickid) {
            if (stateObj.deleteclick) {
                data.splice(at, 1);

                return;
            } else {

            let index = stateObj.editclick ? at : data.length;
            obj.nodes = stateObj.editclick ? item1.nodes : [];
            if (stateObj.type === 1) {
                if (item1.nodes.length) {
                    obj.label =  cloneRule // modify label from AND to OR type
                    obj.type = 0;
                    item1.nodes[item1.nodes.length] = obj;
                } else {
                    nodeAdded = true;
                    item1.nodes[0] = obj;
                }
                return
            } else {
                obj.showworkflow = 1;
                nodeAdded = false;
                data[index] = obj;

            }
        }
            return
        }
        if(item1.nodes.length>0){
        checkNode(item1.nodes,stateObj,obj);
        }
    })

}
function checkNode(nodes, stateObj,obj) {




    Object.values(nodes).map((item2, at) => {
        if (item2.nodes.length >= 1) {
            if(item2.index === stateObj.clickid){

                if (stateObj.deleteclick) {
                    nodes.splice(at, 1);
                    return;

                } else {

                    let index = stateObj.editclick === true ? at : nodes.length;
                    obj.nodes = stateObj.editclick ? item2.nodes : [];
                    if(stateObj.type === 1){
                            if(Object.values(item2.nodes.length)){
                                obj.type = stateObj.editclick ?obj.label: 0;
                                obj.label = stateObj.editclick ? obj.label:cloneRule;
                                item2.nodes[item2.nodes.length] = obj
                                nodeAdded = false;

                            }else{
                                nodeAdded =  true
                                item2.nodes[0] = obj
                            }
                    }else{
                        nodeAdded = false;
                        nodes[index] = obj
                    }

                }
                return

            }

            Object.values(item2.nodes).map((item3,i)=>{

                if(item3.index === stateObj.clickid){

                    if (stateObj.deleteclick) {
                        item2.nodes.splice(i, 1);
                        return
                    } else {
                        let index = stateObj.editclick ? i : (item3.nodes).length;
                        obj.nodes = stateObj.editclick ? item3.nodes : [];
                        if(stateObj.type===1){
                            if(item3.nodes.length){
                                obj.label = stateObj.editclick ? obj.label : cloneRule;
                                obj.type = stateObj.editclick ? obj.type : 0;
                                nodeAdded = false;
                                item3.nodes[item3.nodes.length] = obj;

                            }else{
                                nodeAdded =  true
                                item3.nodes[0] = obj
                            }
                        }else{
                            nodeAdded = false;
                            item2.nodes[index] = obj
                        }
                    }
                    return
                }
                if (item3.nodes.length>0) {


                    checkNode(item3.nodes, stateObj,obj);
                }
            })





        } else {

            if (item2.index === stateObj.clickid) {


                if (stateObj.deleteclick) {
                    nodes.splice(at, 1);
                    return
                } else {


                    let index = stateObj.editclick ? at : nodes.length;
                    obj.nodes = stateObj.editclick ? item2.nodes : [];
                        if(stateObj.type === 1){


                            if(item2.nodes.length){
                                obj.label = stateObj.editclick ? obj.label:cloneRule;
                                obj.type = 0;
                                nodeAdded = false;
                                item2.nodes[item2.nodes.length] = obj;
                            }else{
                                nodeAdded  =  true
                                item2.nodes[0] = obj
                            }
                        }else{
                            nodeAdded = false;
                            nodes[index] = obj
                        }

                }
                return

            }
        }

    })
}
