// import {store } from '../../store'
export const filter = {
    latestdata
};
// let storage = store.getState();
var controlTypes = {};
var org = [1, 2, 3, 4];
let name = ''
var persons = [];
var groups = [];
var departments = [];
var jobs = [];
var workflows = [];
var calculation = [];
var rules = [];
var value = '';
var doNotCheckValuesType = [2,12,9,1,3,4,10,5];
var final = {};
var nodeItem = {};
function latestdata(data,controlTypesData,type =1) {
  final = {};
    persons = data.persons
    jobs = data.jobs
    groups = data.groups
    departments = data.departments
    workflows = data.workflows
    calculation = data.calculation
    rules = data.rules;
    controlTypes = controlTypesData;
  if(type === 1){
    Object.keys(rules).map(ele => {
      return   getLatestData(ele)
    })
    return final
}else{


    getLatestDataForTriggers();
}
}
function getLatestData(ele) {

    let obj = rules[ele]



    obj.map((rule, at) => {


        let temp = rule.tree_data!== null && rule.tree_data!== undefined ? Object.values(JSON.parse(rule.tree_data)):[];
        modifydata(temp);
        rule.tree_data = temp;
    })
    final[ele] = obj;
}
function getLatestDataForTriggers(rule){

}

function modifydata(data) {


    let action; let array; let index = []; let string;
    Object.values(data).map((item1, at) => {
      nodeItem = item1;
        if (org.includes(parseInt(item1.action))) {
            action = parseInt(item1.action)
            array = action === 1 ? persons : action === 2 ? jobs : action === 3 ? departments : groups;
            index = array.filter(i => { return i.id == item1.orgid });

            if (index.length === 0) {
              let place  = data.map(function(e) { return e.orgid; }).indexOf(item1.orgid);
                data.splice(place, 1)
                // data.splice(at, 1)
                // data[at] = [];
            } else {
                string = createOrg(index, item1.type, item1.name);
                item1.label = string
                item1.orgname = name
            }
        } else {
            if (item1.action == window.WEBFORM_WORKFLOW) {
                index = workflows.filter(item => { return item.id == item1.workflowid })

                if (index.length === 0 && item1.workflowid !== window.EMAIL_ALL_STEPS_WORKFLOW) {
                  let place  = data.map(function(e) { return e.workflowid; }).indexOf(item1.workflowid);
                    data.splice(place, 1)
                    // data[at] = [];
                } else {
                    string = createWorkflow(index, item1.type)
                    item1.label = string
                    item1.workflow = name
                }
            } else {
                index = calculation.filter(item => { return item.id == item1.controlid });
                if (index.length === 0) {
                  // console.log(index);
                  let place  = data.map(function(e) { return e.controlid; }).indexOf(item1.controlid);
                  // console.log(place);
                    data.splice(place, 1)
                    // data[at] = [];
                } else {
                    item1.label = createControl(index, item1.type, item1.controlType, item1.operator, item1.value, item1.name === 'self' ? 1 : 0);
                    item1.control = name;
                    item1.value = value
                }
            }
        }
            if(item1.nodes !== undefined && item1.nodes.length>0){
            modifyNode(item1.nodes);}
    })


}
function modifyNode(nodes) {
    let action; let array; let index = []; let string;
    Object.values(nodes).map((item2, at) => {
      nodeItem = item2;
        if (item2.nodes.length >= 1) {
            if (org.includes(parseInt(item2.action))) {
                action = parseInt(item2.action)
                array = action === 1 ? persons : action === 2 ? jobs : action === 3 ? departments : groups;
                index = array.filter(i => { return i.id == item2.orgid });
                if (index.length === 0) {
                  let place  = nodes.map(function(e) { return e.orgid; }).indexOf(item2.orgid);
                    nodes.splice(place, 1)
                    // nodes[at] = [];
                } else {
                    string = createOrg(index, item2.type, item2.name);
                    item2.label = string
                    item2.orgname = name
                }
            } else {
                if (item2.action == window.WEBFORM_WORKFLOW) {
                    index = workflows.filter(item => { return item.id == item2.workflowid })

                    if (index.length === 0 && item2.workflowid !== window.EMAIL_ALL_STEPS_WORKFLOW) {
                      let place  = nodes.map(function(e) { return e.workflowid; }).indexOf(item2.workflowid);
                        nodes.splice(place, 1)
                        // nodes.splice(at, 1)
                        // nodes[at] = [];
                    } else {
                        string = createWorkflow(index, item2.type)
                        item2.label = string
                        item2.workflow = name
                    }
                } else {
                    index = calculation.filter(item => { return item.id == item2.controlid });
                    if (index.length === 0) {
                      let place  = nodes.map(function(e) { return e.controlid; }).indexOf(item2.controlid);
                      // console.log(place);
                        // data.splice(place, 1)
                        nodes.splice(place, 1)
                        // nodes[at] = [];
                    } else {
                        item2.label = createControl(index, item2.type, item2.controlType, item2.operator, item2.value, item2.name === 'self' ? 1 : 0);
                        item2.control = name;
                        item2.value = value
                    }
                }
            }
            Object.values(item2.nodes).map((item3, at1) => {


                if (org.includes(parseInt(item3.action))) {
                    action = parseInt(item3.action)
                    array = action === 1 ? persons : action === 2 ? jobs : action === 3 ? departments : groups;


                    index = array.filter(i => { return i.id == item3.orgid });


                    if (index.length === 0) {
                      let place  = item2.nodes.map(function(e) { return e.orgid; }).indexOf(item3.orgid);
                        item2.nodes.splice(place, 1)
                        // item3.nodes.splice(at1, 1)
                        // item3.nodes[at1] = [];
                    } else {


                        string = createOrg(index, item3.type, item3.name);
                        item3.label = string
                        item3.orgname = name
                    }
                } else {
                    if (item3.action == window.WEBFORM_WORKFLOW) {
                        index = workflows.filter(item => { return item.id == item3.workflowid })

                        if (index.length === 0 && item3.workflowid !== window.EMAIL_ALL_STEPS_WORKFLOW) {
                          let place  = item2.nodes.map(function(e) { return e.workflowid; }).indexOf(item3.workflowid);
                            item2.nodes.splice(place, 1)
                            // item3.nodes.splice(at1, 1)
                            // item3.nodes[at1] = [];
                        } else {
                            string = createWorkflow(index, item3.type)
                            item3.label = string
                            item3.workflow = name
                        }
                    } else {
                        index = calculation.filter(item => { return item.id == item3.controlid });
                        if (index.length === 0) {
                          let place  = item2.nodes.map(function(e) { return e.controlid; }).indexOf(item3.controlid);
                            item2.nodes.splice(place, 1)
                            // item3.nodes.splice(at1, 1)
                            // item3.nodes[at1] = [];
                        } else {
                            item3.label = createControl(index, item3.type, item3.controlType, item3.operator, item3.value, item3.name === 'self' ? 1 : 0);
                            item3.control = name;
                            item3.value = value
                        }
                    }
                }
                if (item3.nodes.length > 0)
                    modifyNode(item3.nodes)

            })


        } else {
            if (org.includes(parseInt(item2.action))) {
                action = parseInt(item2.action)
                array = action === 1 ? persons : action === 2 ? jobs : action === 3 ? departments : groups;
                index = array.filter(i => { return i.id == item2.orgid });
                if (index.length === 0) {
                  let place  = nodes.map(function(e) { return e.orgid; }).indexOf(item2.orgid);
                    nodes.splice(place, 1)
                    // nodes.splice(at, 1)
                    // nodes[at] = [];
                } else {

                    string = createOrg(index, item2.type, item2.name);
                    item2.label = string
                    item2.orgname = name
                }
            } else {

                if (item2.action == window.WEBFORM_WORKFLOW) {
                    index = workflows.filter(item => { return item.id == item2.workflowid })

                    if (index.length === 0 && item2.workflowid !== window.EMAIL_ALL_STEPS_WORKFLOW) {
                      let place  = nodes.map(function(e) { return e.workflowid; }).indexOf(item2.workflowid);
                        nodes.splice(place, 1)
                        // nodes.splice(at, 1)
                        // nodes[at] = [];
                    } else {
                        string = createWorkflow(index, item2.type)
                        item2.label = string
                        item2.workflow = name
                    }
                } else {
                    index = calculation.filter(item => { return item.id == item2.controlid });
                    if (index.length === 0) {
                      let place  = nodes.map(function(e) { return e.controlid; }).indexOf(item2.controlid);
                        nodes.splice(place, 1)
                        // nodes.splice(at, 1)
                        // nodes[at] = [];
                    } else {
                        item2.label = createControl(index, item2.type, item2.controlType, item2.operator, item2.value, item2.name === 'self' ? 1 : 0);
                        item2.control = name;
                        item2.value = value
                    }
                }
            }

        }
    })
}

function createOrg(item, type, category) {
    item.map(org => {
        name = org.name;
    })
    type = type == 1 ? 'And' : 'OR';
    let string = type + ' ' + category + ' Equals ' + name;
    return string;
}
function createWorkflow(item, type) {
    name = ''
    item.map(e => {
        name = e.step_name
    });
    if(item.length === 0){
    name = 'All steps'}
    type = type == 1 ? 'And' : 'OR';
    let string = type + ' ' + 'Workflow' + ' Equals ' + name;
    return string;
}
function createControl(array, type, controlType, operator, value3, isSelf = 0) {
    let emptyValueType = nodeItem.valueType === 3 ? 1:0;
    let typeofControl = '';
    array.map(key => { name = key.name })
        type = type == 1? 'And':'OR'
    let  index = controlTypes.filter(i => { return i.typeid == controlType});
        index.map(key =>{ typeofControl = key.name})
        name =  name+'('+typeofControl+')';
        value =  value3 ? value3 : emptyValueType ? 'empty' : value3 ;
    let string = type+' '+ (isSelf ? 'self' : name) + ' ' + operator + ' ' + value;
    return string;
}
