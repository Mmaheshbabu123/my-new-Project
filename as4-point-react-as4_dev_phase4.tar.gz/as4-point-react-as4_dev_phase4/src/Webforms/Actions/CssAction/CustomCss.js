import React, { Component } from 'react'
import { translate } from '../../../language'
import * as Reactbootstrap from 'react-bootstrap'
import { SketchPicker } from 'react-color';
import { OCAlert } from '@opuscapita/react-alerts';
class CustomCss extends Component {

    constructor(props){
        super(props)
        this.getIntialState();
    }
    getIntialState =()=>{
        this.state = {
            t:this.props,
            color:undefined,
            background:undefined,
            clickorigin:undefined,
            popUpShow:false,
            customcss:'',
            border:'',

        }
    }

handlePickerChange =(color,type)=>{
  let string = type === 1 ?'color':'background'

    this.setState({
        [string]:color.hex
    })
}
handleadd(type){
    this.setState({clickorigin:type,popUpShow:true})
}
handleBorder = (e)=>{
    this.setState({
        border:e.target.value
    })
}
componentWillReceiveProps(nextProps){

    if(this.props.edit){
        const {data} =  this.props

        // border:this.cssobj.border,custom:this.cssobj.customcss,background:this.cssobj.background,
        //         color:this.cssobj.color
                let obj = data.editcss


        this.setState({
            background:obj.background,
            color:obj.color,
            border:obj.border


        })
    }

}
    render(){
        this.props.send(this.state)


        return(
                <>
                {this.getRenderContent()}
                </>
        )
    }
    getRenderContent =()=>{
        const {color,background, popUpShow, border} =  this.state
        const html  =(
            <>
              <div className="col-md-12"style = {{}}>
                <Reactbootstrap.Form className="col-md-12">
                    <Reactbootstrap.Form.Group controlId="formBasicEmail">

                       <div className = 'row col-md-12'>
                           <Reactbootstrap.Form.Label className="col-md-4 p-0" style = {{color: 'rgb(236, 102, 28)'}} >Color:</Reactbootstrap.Form.Label>
                        <div style={{marginLeft: '-5px'}} className = 'col-md-4 p-0 input_sw'>
                            <Reactbootstrap.Form.Control type="text" id ={2}  col='4'  placeholder="Color"
                            name  = "border"
                            value = {color}
                            onInput = {false}
                            readonly
                            disabled
                            />
                        </div>
                        <div className = 'col-md-4'>
                        <Reactbootstrap.Button  variant="outline-primary" onClick = {(e)=>this.handleadd(1)}>
                            Add here
                        </Reactbootstrap.Button>
                        </div>
                       </div>
                    </Reactbootstrap.Form.Group>
                    <Reactbootstrap.Form.Group>

                     <div className = 'row col-md-12'>
                       <Reactbootstrap.Form.Label className="col-md-4 p-0" style = {{color: 'rgb(236, 102, 28)'}} >Background-color:</Reactbootstrap.Form.Label>
                       <div style={{marginLeft: '-5px'}} className = 'col-md-4 p-0 input_sw'>
                        {/* {background} */}
                        <Reactbootstrap.Form.Control type="text" id ={2} col='4'  placeholder="Background"
                            name  = "border"
                            value = {background}
                            onInput = {false}
                            readonly
                            disabled
                            />
                        </div>
                        <div className = 'col-md-4'>
                        <Reactbootstrap.Button  variant="outline-primary" onClick = {(e)=>this.handleadd(2)} >
                            Add  here
                        </Reactbootstrap.Button>
                        </div>
                       </div>
                    </Reactbootstrap.Form.Group>
                    <Reactbootstrap.Form.Group className="col-md-12 row p-0">
                        <Reactbootstrap.Form.Label className="col-md-4" style = {{color: 'rgb(236, 102, 28)'}} >
                            Border:
                        </Reactbootstrap.Form.Label>
                    <Reactbootstrap.Form.Control className="col-md-8 input_sw" type="text" id ={2} col={4}  placeholder="for example 5px solid red"
                        onInput = {this.handleBorder}
                        name  = "border"
                        value = {border}
                    />
                    </Reactbootstrap.Form.Group>
                      {/* <Reactbootstrap.Form.Group controlId="exampleForm.ControlTextarea1">
                        <Reactbootstrap.Form.Label>Technical Query</Reactbootstrap.Form.Label>
                        <Reactbootstrap.Form.Control
                            style={{ height: '1%' }} as="textarea" rows="6" col='5'
                            id= 'technical'
                             />
                    </Reactbootstrap.Form.Group> */}
                </Reactbootstrap.Form>
                </div>
                {popUpShow && this.showPopup()}
            </>
        )
        return html
    }
    showPopup =()=>{
        const {popUpShow, color, clickorigin,background} = this.state
        return (<Reactbootstrap.Modal show={popUpShow} onHide = {()=>{this.setState({popUpShow:false})}}>
             <Reactbootstrap.Modal.Header closeButton>
            <Reactbootstrap.Modal.Body>
                {clickorigin === 1 &&  <SketchPicker  className="picker-sketch"
                            color={color}
                            onChangeComplete={(e) =>this.handlePickerChange(e,clickorigin) }
                        />}
                {clickorigin === 2 &&
                 <SketchPicker  className="picker-sketch"
                 color={background}
                 onChangeComplete={(e) =>this.handlePickerChange(e,clickorigin) }
             />
                }
            </Reactbootstrap.Modal.Body>
            </Reactbootstrap.Modal.Header>
        </Reactbootstrap.Modal>

        );
    }
}
 export default translate(CustomCss)
