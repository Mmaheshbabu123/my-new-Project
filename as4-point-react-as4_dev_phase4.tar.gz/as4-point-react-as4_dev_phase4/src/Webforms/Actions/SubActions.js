import React, { Component, Suspense } from 'react'
import { translate } from '../../language'
import * as Reactbootstrap from 'react-bootstrap'
import { datasave } from '../../_services/db_services'
import {store } from '../../store'
import '../webform.css'
import CheckBox from '../../CheckBox';
import { OCAlert } from '@opuscapita/react-alerts';
import * as moment from 'moment/moment';
import DatePicker from 'react-datepicker';
const CusomCss = React.lazy(() => import('./CssAction/CustomCss'));

const ALLSTEPS = 777777;
class SubAction extends Component {
    child_data = []; track = 0; NAoption = false;
    cssobj = {};
    constructor(props) {
        let storage = store.getState();
        let actions = storage.UserData.webform_authors

        const operators = storage.UserData.webform_operator_linking
        let isDateType = undefined
        super(props)
        this.state = {
            t: props.t,
            actions: actions !== undefined ? actions : [],
            // actions:[],
            author: 'Workflow',
            control: 12,
            orgname: undefined,
            operators: operators !== undefined ? operators : [],
            type: this.props.type,
            selectedType: parseInt(this.props.action) === window.WEBFORM_CALCULATION ? window.WEBFORM_CALCULATION : (parseInt(this.props.action) === window.WEBFORM_WORKFLOW ? window.WEBFORM_WORKFLOW : window.WEBFORM_WORKFLOW),
            orgArrayIds: window.WEBFORM_ORG_ID,
            allOrgUnits: {},
            webformid: this.props.webform_id,
            controls: [],
            controlType: '',
            workflowsteps: [],
            value: undefined,
            getValueOptions: [],
            child_data: [],
            startDate: '',
            enter:false,
            leave:true,
            required:false,
            overwrite:false,
            selectvaluetype:undefined,
            periodtype:1,
            category:4,
            count:undefined,
            PJDG: [],
            child_data_default:[],
            editclick : this.props.groundplan ? this.props.edit : false,
        }
        this.getchild = React.createRef();
    }
    changeActions = (e) => {
        const {  value, childNodes, selectedIndex } = e.target;
        var id = childNodes[selectedIndex].getAttribute('id')

        this.setState({
            author: value,
            selectedType: id,
            operator:undefined,
            operatorId:undefined,
            controlType:undefined,
            controlId:undefined,
            controller:undefined,
        })
    }
    changeOperators = (e) => {
        const { value, childNodes, selectedIndex } = e.target;
        var id = childNodes[selectedIndex].getAttribute('id')
        this.setState({ operatorId: id, operator: value })

    }
    handleCheckBox = (e,type)=>{
        const {target} =  e;
        type === 0 ? this.setState({enter:target.checked}):this.setState({leave:target.checked})
    }
    handleCheckBlockBox = (e,type) => {
      const {target} =  e;
      type === 0 ? this.setState({required:target.checked}):this.setState({overwrite:target.checked})
    }
    handleorg = (e) => {
        const {  value, childNodes, selectedIndex } = e.target
        let id = childNodes[selectedIndex].getAttribute('id')
        let name = childNodes[selectedIndex].getAttribute('name')
        this.setState({
            orgid: id,
            orgname: name

        })
    }
    async componentDidMount() {
        const { orgArrayIds } = this.state
        const { edit, data, apidata, from } = this.props
        if(apidata !== undefined) {
            let contr = [];
            if(from === 'actions'){
            await  datasave.service(window.FETCH_ALL_WEBELEMENTS + '?webform_id=' + this.props.webform_id, 'POST').then(res =>{
                if(parseInt(res['status']) === 200){
                     let ids = apidata['controls'].map( i=> i.id);
                    res['data'].map(item=>{
                        if(ids.includes(item.id)){
                            contr.push(item)
                        }
                    })
                }
            })}
            apidata['controls'] =  contr.length >0 ?contr:apidata['controls'];
            let response = apidata
            if (edit) {
                orgArrayIds.includes(parseInt(data.action)) ? this.setStateOrgData(response) : this.setStateWorkflowAndCalculation(response);
            } else {
                this.setState({
                    allOrgUnits: response,
                    controls: response['controls'],
                    workflowsteps: response['workflow']
                })
            }
        } else {
           this.getDataFromApi();
        }
        const URL = window.GET_READ_UNDERSTOOD_DATA;
        datasave.service(URL, 'GET')
          .then(response => {
            this.setState({
              PJDG: response.jgd,
            },()=>{this.setListOptions()})
          });
          if(this.props.currentClickitem === window.WEBFORM_DefaultValue){
              let currentElementType = 0;
             currentElementType = this.state.controls.filter(ele=>{return ele.id === this.props.webelement_id})
            if(currentElementType.length > 0){
              currentElementType = currentElementType[0]['type'];
            }
            this.setState({
              currentElementType:currentElementType
            },()=>{this.setListOptions('DEFAULT')})
          }
    }
    getDataFromApi=()=>{
        const { orgArrayIds } = this.state
        const { edit, data } = this.props

        datasave.service(window.GET_ORG_UNITS + '/' + this.props.webform_id, 'GET')
            .then(response => {
                if (edit) {

                    orgArrayIds.includes(parseInt(data.action)) ? this.setStateOrgData(response) : this.setStateWorkflowAndCalculation(response);
                } else {
                    this.setState({
                        allOrgUnits: response,
                        controls: response['controls'],
                        workflowsteps: response['workflow']
                    })
                }
            })
    }
    setStateOrgData = (response) => {
        const { data } = this.props
        this.setState({
            allOrgUnits: response,
            controls: response['controls'],
            workflowsteps: response['workflow'],
            author: data.author,
            orgname: data.orgunit,
            orgid: data.orgid,
            selectedType: parseInt(data.action),
            defaultValue:data.defaultValue,
            defaultValueId:data.defaultValueId
        })
    }
    setStateWorkflowAndCalculation = (response) => {
        const { data} = this.props
        this.setState({
            allOrgUnits: response,
            controls: response['controls'],
            workflowsteps: response['workflow'],
            selectedType: parseInt(data.action),
            author: parseInt(data.action) === window.WEBFORM_CALCULATION ? 'Calculation' : 'Workflow',
            controller: parseInt(data.action) === window.WEBFORM_CALCULATION ? data.control : undefined,
            operator: parseInt(data.action) === window.WEBFORM_CALCULATION ? data.operator : undefined,
            value: parseInt(data.action) === window.WEBFORM_CALCULATION ?  data.value : undefined,
            controlType: parseInt(data.action) === window.WEBFORM_CALCULATION ? parseInt(data.controlType) : undefined,
            controlId:parseInt(data.action) === window.WEBFORM_CALCULATION ? parseInt(data.controlid):undefined,
            operatorId:parseInt(data.action) === window.WEBFORM_CALCULATION ? parseInt(data.operatorId):undefined,
            workflow: data.workflow,
            workflowid:data.workflowid,
            enter:data.onenter,
            leave:data.onleave,
            required:data.required,
            overwrite:data.overwrite,
            selectvaluetype:parseInt(data.valueType),
            valueId:data.valueId,
            count:data.count,
            periodtype:data.periodtype,
            category:data.category,
            defaultValue:data.defaultValue,
           defaultValueId:data.defaultValueId
        })
        this.isDateType = parseInt(data.isDateType)

    }
    changeControls = (e) => {
        const { value, childNodes, selectedIndex } = e.target
        let id = childNodes[selectedIndex].getAttribute('id')
        let name = childNodes[selectedIndex].getAttribute('name')
        let typeid = childNodes[selectedIndex].getAttribute('type')
        this.NAoption = false
        this.setState({
            controlId: parseInt(id),
            controller: name,
            selectedController: name,
            controlType: typeid,
            value: undefined,
            child_data:[],
            selectvaluetype:1,
            valueId:undefined,
        })
    }
    changeValues = (e,from,type = 1) => {
         let controlType = from === 'DEFAULT' ?this.state.currentElementType :this.state.controlType;
         let value = type ===1 ?e.target.value: e
         let name  =  undefined
         let valueId = 0
           if([window.NUMERICFIELD,window.DECIMALFIELD].includes(parseInt(controlType))){
           value =   e.target.validity.valid ? value: this.state.value!== undefined?this.state.value:''
         }
         name = value
         if([11,12,10,7,8].includes(parseInt(controlType))){
             const {  childNodes, selectedIndex } = e.target
             valueId = childNodes[selectedIndex].getAttribute('id')
             name  = childNodes[selectedIndex].getAttribute('name')
         }
         if(from === 'DEFAULT'){
           this.setState({
             defaultValue:name,
             defaultValueId:valueId
           })
         }else{
           this.setState({
               value: name,
               valueId:valueId
           })
         }
     }

    cancelrule = (e) => {
        this.props.changeComponent(false)
    }
    postSave = (e) => {
        const { t } = this.state
        if (this.validate()) {
            this.props.changeComponent(true, this.createObj(e))
        } else {
            OCAlert.alertWarning(t('One or more required fields were not filled in.'), { timeOut: 2000 });
        }
    }
    changeWorkflow = (e) => {
        const { value, childNodes, selectedIndex } = e.target
        let id = childNodes[selectedIndex].getAttribute('id')
        let name = childNodes[selectedIndex].getAttribute('name')
        this.setState({
            workflowid: parseInt(id),
            workflow: name
        })
    }
    createObj = (e) => {
        const { type, orgname, selectedType, controller, orgid, author, workflow,
            workflowid, controlId, valueId, value, operatorId, operator, controlType,selectvaluetype,count,periodtype,category,
          defaultValue,defaultValueId } = this.state
        return {
            action: type.action === 1 ? selectedType : undefined,
            author: type.action === 1 ? author : undefined,
            orgid: type.action === 1 ? orgid : undefined,
            orgunit: type.orgunit === 1 ? orgname : undefined,
            workflow: type.workflow === 1 ? workflow : undefined,
            workflowid: type.workflow === 1 ? workflowid : undefined,
            controlid: type.control === 1 ? controlId : undefined,
            control: type.control === 1 ? controller : undefined,
            valueId:  valueId,
            value: type.control === 1 ? value : undefined,
            operatorId: type.control === 1 ? operatorId : undefined,
            operator: type.control === 1 ? operator : undefined,
            controlType: type.control === 1 ? controlType : undefined,
            onleave:this.state.leave,
            onenter:this.state.enter,
          ///  releaseoptions:this.props.releaseblockbox ?{}:{
              required:this.state.required,
              overwrite:this.state.overwrite,
            //},
            valueType:selectvaluetype,
            isDateType:this.isDateType,
            css:this.props.SHOWCSS ? {
                border:this.cssobj.border,custom:this.cssobj.customcss,background:this.cssobj.background,
                color:this.cssobj.color
            }:{},
            count:count,
            periodtype:periodtype,
            category:category,
            defaultValue:(this.props.currentClickitem === window.WEBFORM_DefaultValue && defaultValue !== undefined ) ? defaultValue:null,
            defaultValueId:(this.props.currentClickitem === window.WEBFORM_DefaultValue && defaultValueId !== undefined) ? defaultValueId:null,
        }
    }
    validate = () => {
        let array = this.getValidationArray();
        return this.sendTrueOrFalse(array)
    }
    getValidationArray() {
        const { type } = this.state
        let arraycheck = [];
        Object.keys(type).map(function (key) {
            if (type[key] === 1) {
              return  arraycheck.push(key)
            }
        })
        return arraycheck
    }
    sendTrueOrFalse = (array) => {
        let value = true;
        if(this.props.from === 'actions'){
            // this.validateCss();
        }


        const { orgArrayIds, selectedType } = this.state
        if (orgArrayIds.includes(parseInt(selectedType))) {
            if (array.includes('orgunit')) {
                value = this.state.orgid === undefined ? false : true
                if (!value) {
                    return false
                }
            }
        } else {
            if ((array.includes('workflow')) && (parseInt(selectedType) === window.WEBFORM_WORKFLOW)) {
                value = this.state.workflowid === undefined ? false : true
                if (!value) {
                    return false
                }
            }
            if (array.includes('control') && parseInt(selectedType) === window.WEBFORM_CALCULATION) {
                value = this.state.controlId === undefined ? false : this.state.operatorId === undefined ? false : this.state.value === undefined ? false : true;
                value = this.state.controlId === undefined ? false : this.state.operatorId === undefined ? false : (this.state.selectvaluetype === 3) ? true: value;
                if (!value) {
                    return false
                }
            }
        }
        return value
    }
    getValueOptions = (type,from = 'NO_DEFAULT') => {
          let controlType = parseInt(type)
          const { value, valueId } = this.state
          let controlid = from === 'NO_DEFAULT' ? this.state.controlId : this.props.webelement_id;
          let values = [];
          if (controlType === window.DATEFIELD) {

                  let controls  = this.state.controls;
                  let obj ={}; let type = 1;
                  const item = controls.filter( item =>{ return item.id === controlid});
                   if(item.length){
                     Object.values(item).map(item =>{
                          obj = JSON.parse(item.json_data);
                          return obj
                     })}
                     type = obj.display_type !== undefined ? obj.display_type:1;
                  if( parseInt(type) === 2){
                      this.isDateType = 2
                            values.push(
                                  <Reactbootstrap.Form.Group controlId="form">

                                      <DatePicker

                                              selected={ value !== undefined ? new Date(value):undefined}
                                              onChange={(date) => this.changeValues(date,from,0)}
                                              showTimeSelect
                                              withPortal = {true}
                                              timeCaption="time"
                                              dateFormat="dd-MM-yyyy h:mm aa"
                                      />

                                      </Reactbootstrap.Form.Group>
                            )
                  }else{
                      this.isDateType = 1;
                      values.push(<Reactbootstrap.Form.Control
                      type="date" name="date" onChange={(e)=>this.changeValues(e,from,1)} style={{ }} value={value}>
                      </Reactbootstrap.Form.Control>)
                  }
          }
          if (controlType === window.TEXTBOX) {
              values.push(
                  <Reactbootstrap.Form.Control as="textarea" onChange={(e)=>this.changeValues(e,from,1)} value={value} rows="3" />
              )
          }
          if (controlType === window.DATABASELIST || controlType === window.TEXTFIELD || controlType === window.DECIMALFIELD || controlType === window.NUMERICFIELD  || controlType === window.DATABASELIST_MULTISELECT) {
              values.push(
                  <Reactbootstrap.Form.Control type='text' pattern = {(controlType === window.DECIMALFIELD || controlType === window.NUMERICFIELD) ? "[0-9]+(,[0-9]+)*,?":true} style={{  }} onChange={(e)=>this.changeValues(e,from,1)} placeholder = 'Value' value={value === undefined ?"":value} />
              )
          }
          if(controlType === Window.LIST || controlType === window.RADIO_BUTTON || controlType === Window.CHECKBOX || controlType === window.LISTORG){
            console.log(this.state.child_data);
              if(this.state.child_data.length>0){
                  let options = [];
                  Object.values(this.state.child_data).map(item => {
                    return   options.push(<option  key = {item.id} id={item.id} name  = {item.name} value = {item.id}> {item.name}</option>)
                  })
                  if(controlType !== window.LISTORG){
                      if(this.NAoption){
                          options.push(<option key = {-1} value  = {-1} name = "N/A" id = {-1}>N/A</option>)
                      }
                  }
                  values.push(
                      <Reactbootstrap.Form.Control style={{  }} as="select" name="outype" value={valueId} onChange={(e)=>this.changeValues(e,from,1)} >
                          <option>---Select---</option>
                          {options}
                      </Reactbootstrap.Form.Control>
                  )
              }
          }
          if (values.length === 0) {
              values.push(
                  <h6>No values  assigned for current element </h6>
              )
          }
          this.track = 0

          return values;


      }
    getparentId =(from)=>{
            let controls  = this.state.controls;
            let obj ={}; let id = 0;
            let controlId = from !== 'DEFAULT'?this.state.controlId:this.props.webelement_id;
             const item = controls.filter( item =>{ return item.id === controlId});
                if(item.length){
                   Object.values(item).map(item =>{
                      return  obj = JSON.parse(item.json_data);
                   })}
                  if(obj !== null){
                    this.NAoption = obj.na !== undefined ?(parseInt(obj.na) === 1 ? true:false) :false;
                    id = obj.list !== undefined ? obj.list :id;
                  }

            return id;

    }
    getListOrgUnits =()=>{
        let controls  = this.state.controls;
        let obj ={};
        const item = controls.filter( item =>{ return item.id === this.state.controlId});
        let selectedItemsOfLou = [];

        if(item.length){
            Object.values(item).map(item =>{
              return obj = item.json_data!= null? JSON.parse(item.json_data):undefined;
           })
        if(obj!== undefined && obj !== null) {
          let allPJDG = this.state.PJDG;
          if(obj.selectAll === 1) {
            selectedItemsOfLou = allPJDG.filter(itemOfPjdg => (itemOfPjdg.category === obj.orgUnit));
          } else {
            selectedItemsOfLou = obj.selectedItems;
          }
           if(obj.showAllPersons == true) {
              this.getPersonsInorg(selectedItemsOfLou);
           } else {
             this.setState({
                 child_data: selectedItemsOfLou,
             })
           }
        }
    }
    }
    getPersonsInorg = (data)=>{
        let obj ={
            org:data
        }
        datasave.service(window.GET_PERSONS_ACTIONS, 'POST',obj).then(
            response =>{
              if(response['status'] == 500){
                OCAlert.alertWarning("error occured form our side, we're unable to process", { timeOut: 2000 });
                this.setState({
                  child_data:[]
                })
              }else{
                this.setState({
                    child_data:response['data']
                })
              }
            })
    }
    handleRadioSelect =(e,type)=>{
        this.setState({
            selectvaluetype:type,
            valueId:undefined,
            value:undefined
        })
    }
    handlePeriodChange(e,from){
      const {  childNodes, selectedIndex } = e.target
      let valueId = childNodes[selectedIndex].getAttribute('id')
        this.setState({
          [from]:parseInt(valueId),
        },()=>{this.setState({
          value:this.prepareString()
        })})
    }
    changePeriodValue =(e)=>{
      const{target}= e
      const {periodtype,category} =  this.state
      let value = target.validity.valid ? target.value :this.state.count!== undefined? this.state.value:''
      this.setState({
        count:value,
        valueId:900009,
      },()=>{this.setState({
        value:this.prepareString()
      })})

    }
    prepareString =()=>{
      const {periodtype,category,count} =  this.state

      let symbol = periodtype === 1 ? " + " : " - ";
      let type  = category === 4 ? ' Year': category === 3 ? ' Months':category === 2 ? ' Days': category === 1 ?' Hours':' Minutes';
      return "Now "+ symbol + count + type;
    }
    render() {
          const { SHOWCSS } =  this.props
            if(SHOWCSS){
             return  this.getCssRender()
           }
            else{
                return this.getRenderContent()
            }


    }
    getRenderContent =()=>{

        const { author, operators, selectedType, orgArrayIds, allOrgUnits, t,workflowsteps,
            type, controller, operator, workflow, controlType, orgname, controls,controlId,
            selectvaluetype, orgid, workflowid} = this.state;
            const { SHOWCSS, webelement_id, fromManageElements } =  this.props;
            let selftype;

        let options = []; let operatorOptions = []; let orgOptions = []; let controlOptions = []; let workflowOptions = [];

        this.state.actions.forEach(element => options.push(<option key = {element.typeid} id={element.typeid}>{element.name}</option>))
        Object.keys(operators).map((item) => {
            if (item == controlType) {
                let arr = fromManageElements && (controlType == '2' || controlType == '1') ? [...operators[item], {name:'Not contains', typeid: 1005}] : operators[item]
                return arr.forEach(ele =>  operatorOptions.push(<option  key = {ele.typeid} id={ele.typeid}>{ele.name}</option>))
            }
        })
        let string = parseInt(selectedType) === window.PERSON_ENTITY ? 'person' : parseInt(selectedType) === 2 ? 'jobs' : parseInt(selectedType) === 3 ? 'departments' : 'groups';
        let obj = allOrgUnits[string] === undefined ? [] : allOrgUnits[string];
        obj.map(item => {
            return orgOptions.push(<option key={item.id} value = {item.id} name = {item.name} id={item.id}>{item.name}</option>)
        })
        let controlsdata = controls;
        controlsdata.map(item => {
          let namewithtype = item.alias?item.alias+'('+item.typename+')':item.name+'('+item.typename+')';
          if(item.id === webelement_id) selftype = item.type;
          if(fromManageElements === 1){
            if(item.id !== webelement_id) controlOptions.push(<option key = {item.id} name= {namewithtype}  value  = {item.id} type={item.type} id={item.id}> {namewithtype}</option>)
          }
          else { controlOptions.push(<option key = {item.id} name= {namewithtype}  value  = {item.id} type={item.type} id={item.id}> {namewithtype}</option>) }
        })
        if(fromManageElements === 1) {controlOptions.unshift(<option key = {webelement_id} name= {'Self'}  value  = {webelement_id} type={selftype} id={webelement_id}> Self </option>)}
        workflowsteps.map(item => {
            workflowOptions.push(<option  key = {item.id} value  = {item.id} name={item.step_name} id={item.id}> {item.step_name} </option>)
        })
        return (
            <div className='container ' >
                <div className='row ' >


                    <div className='col-md-12' >
                        {type.action === 1 &&
                        <div className="col-md-12 row mb-3">
                         <div className="col-md-4">
                          <span style={{color: '#EC661C'}}> Actions:</span>
                          </div>
                          <div className="col-md-8 p-0 input_sw">
                           <Reactbootstrap.Form.Control
                             as="select"
                             name="type"
                             value={author}
                             onChange={this.changeActions}
                             style={{  }} >
                            {this.props.triggers  ? <option id ={window.WEBFORM_WORKFLOW}>Workflow</option>:(this.props.groundplan ? <option id ={window.WEBFORM_CALCULATION}>Calculation</option> : options)}
                         </Reactbootstrap.Form.Control>
                        </div><br></br></div>}
                        {((parseInt(selectedType) === window.WEBFORM_CALCULATION) && type.control === 1) &&
                          <div>
                          <div className="col-md-12 row mb-3">
                            <div className="col-md-4">
                              <span style={{color: '#EC661C'}}>
                                Controls:
                               </span>
                            </div>
                          <div className="col-md-8 p-0 input_sw">
                             <Reactbootstrap.Form.Control
                                as="select"
                                name="type"
                                value={controlId}
                                onChange={this.changeControls}
                                style={{  }} >
                                <option > ---Select--- </option>
                                {controlOptions}
                            </Reactbootstrap.Form.Control>
                            </div>
                          </div>
                          <div className="col-md-12 row mb-3 ">
                            <div className="col-md-4">
                             <span style={{color: '#EC661C'}}>Operators:</span>
                            </div>
                            <div className="col-md-8 p-0 input_sw">
                              <Reactbootstrap.Form.Control
                                as="select"
                                name="type"
                                value={operator}
                                onChange={this.changeOperators}
                                style={{ }} >
                                <option > ---Select--- </option>
                                {operatorOptions}
                            </Reactbootstrap.Form.Control>
                          </div>
                        </div>
                         <div className="col-md-12 row mb-3 ">
                             <div className="col-md-4">
                                <span style={{color: '#EC661C'}}>
                                   Value:
                                </span>
                              </div>
                            <div className="col-md-8 p-0 ">
                              <td>
                                <input type='radio'   name='radio'   checked = {selectvaluetype === 1} onChange = {(e)=>this.handleRadioSelect(e,1)} /> Value &nbsp;&nbsp;
                                {(window.EMPTY_ALLOWED_TYPES.includes(parseInt(controlType)) && fromManageElements === 1) && <>
                                    <input type='radio' name='radio'  checked = {selectvaluetype === 3} onChange = {(e)=>this.handleRadioSelect(e,3)} /> Empty &nbsp;&nbsp;
                                </>}
                                <input type='radio'   name='radio'    checked = {selectvaluetype === 0} onChange = {(e)=>this.handleRadioSelect(e,0)} /> Webelement &nbsp;&nbsp;
                                {(parseInt(controlType) === window.DATEFIELD) && <span> <input type='radio'   name='radio'    checked = {selectvaluetype === 2} onChange = {(e)=>this.handleRadioSelect(e,2)} /> Custom date </span>}
                              </td>
                              {(controlType !== undefined && selectvaluetype === 1) && this.getValueOptions(controlType)}
                              {(controlType !== undefined && selectvaluetype === 0) && this.getWebElemetns(controlOptions)}
                              {( parseInt(controlType) ===  window.DATEFIELD && selectvaluetype === 2) && this.getCustomdate()}
                            </div>

                          </div>

                        </div>
                        }
                        {(orgArrayIds.includes(parseInt(selectedType)) && type.orgunit === 1) &&
                           <div className="col-md-12 row mb-3">
                            <div className="col-md-4">
                             <span style={{color: '#EC661C' }}>  Organisation unit:</span>
                            </div>
                            <div className="col-md-8 p-0 ">
                               <Reactbootstrap.Form.Control
                               className="input_sw"
                                as="select"
                                name="type"
                                value={orgid}
                                onChange={this.handleorg}
                                style={{ }} >
                                <option > ---Select--- </option>
                                {orgOptions}
                            </Reactbootstrap.Form.Control>
                            </div>
                        </div>
                        }
                        {(parseInt(selectedType) === window.WEBFORM_WORKFLOW && type.workflow === 1) &&
                           <div className="col-md-12 row mb-3">
                            <div className="col-md-4">
                             <span style={{color: '#EC661C'}}>  Workflow: </span>
                           </div>
                          <div className="col-md-8 input_sw p-0">
                              <Reactbootstrap.Form.Control
                                as="select"
                                name="type"
                                value={workflowid}
                                onChange={this.changeWorkflow}
                                style={{ }} >
                                <option > ---Select--- </option>
                                {this.props.triggers && <option id = {ALLSTEPS} name = 'All steps' value = {ALLSTEPS} > All steps</option>}
                                {workflowOptions}
                            </Reactbootstrap.Form.Control>
                        </div>
                        </div>
                        }
                        {this.props.triggers &&
                         <CheckBox
                         tick={this.state.enter}
                         style={{ paddingLeft: '0px' }}
                         onCheck={(e) => this.handleCheckBox(e, 0)}
                         name={t("On enter")}
                         classification='label'
                         />}
                        { this.props.triggers && <CheckBox
                         tick={this.state.leave}
                         style={{ paddingLeft: '0px' }}
                         onCheck={(e) => this.handleCheckBox(e, 1)}
                         name={t("On leave")}
                         classification='label'
                     />}
                    {this.props.releaseblockbox &&  <div className="col-md-4">
                       <span style={{color: '#EC661C'}}>  Release options: </span>
                     </div>}
                     {this.props.releaseblockbox &&

                      <CheckBox
                      tick={this.state.required}
                      style={{ paddingLeft: '0px' }}
                      onCheck={(e) => this.handleCheckBlockBox(e, 0)}
                      name={t("Enable editing of initial data")}
                      classification='label'
                      />}
                      {this.props.releaseblockbox &&

                       <CheckBox
                       tick={this.state.overwrite}
                       style={{ paddingLeft: '0px' }}
                       onCheck={(e) => this.handleCheckBlockBox(e, 1)}
                       name={t("Overwrite")}
                       classification='label'
                       />}
                       {(this.props.currentClickitem === window.WEBFORM_DefaultValue && this.state.currentElementType !== undefined) &&
                        <>
                        <div className = "row col-md-12 ">
                        <div className = "col-md-4"> <span style={{color: '#EC661C'}}> Default value:</span> </div>
                        <div className="col-md-8 p-0 input_sw">
                        {this.getDefaultValueOptions(this.state.currentElementType,'DEFAULT')}
                        </div>
                        </div>
                        </>
                        }
                         <div>

                     </div>



                            { !SHOWCSS  && this.getSubmitButtons()}
                    </div>

                </div>
            </div>
        )
    }
    getCssRender = ()=>{
        const html =(
            <Suspense fallback={<div>Loading...</div>}>
            <Reactbootstrap.Tabs id="tabs" defaultActiveKey = 'Action' id = {1} >
                <Reactbootstrap.Tab  eventKey= 'Action' title={"Action"}>
                    <div style ={{marginTop:'25px'}}>
                    {this.getRenderContent()}
                    </div>
                    <div style ={{marginTop:'25px'}}>

                    <CusomCss
                    send={this.getcssobj}
                    edit = {this.props.edit}
                    data = {this.props.data}
                    />
                    <div  style ={{marginTop:'10px'}}>
                    {this.getSubmitButtons()}
                    </div>
                    </div>
                </Reactbootstrap.Tab>
                </Reactbootstrap.Tabs>
            </Suspense>

        )
        return html
    }


    componentDidUpdate(prevProps, prevState) {
       if(this.state.controlType !== undefined && this.state.controlType !== prevState.controlType && !this.state.editclick){
         this.setListOptions();
     }
    }
    getWebElemetns = (options)=>{
        const {controlId,valueId} =  this.state
        let filteredoptions = Object.values(options).filter(option=>{return parseInt(option.key) !== parseInt(controlId)})

        return(
                <Reactbootstrap.Form.Control className = 'input_sw'
                    as="select"
                    name="type"
                    value={valueId}
                    onChange={this.changeWebElementsValue}
                    style={{ }} >
                    <option id = {0} >----Select----</option>
                    {filteredoptions}
                </Reactbootstrap.Form.Control>
        )
    }
    changeWebElementsValue = (e)=>{
        const { value, childNodes, selectedIndex } = e.target
        let id = childNodes[selectedIndex].getAttribute('id')
        let name = childNodes[selectedIndex].getAttribute('name')
        this.setState({
            valueId:id,
            value:name
        })

    }
    getSubmitButtons = ()=>{
      const {t} =  this.state
      return (
        <div className="col-md-12 mt-4 btnn">
        <Reactbootstrap.Button variant="outline-success" style={{ float: 'right' }} onClick={this.postSave} > {t("Save")}</Reactbootstrap.Button>
    <a  className="mr-3" style={{ float: 'right',paddingTop: '7px' }} href="javascript:;" onClick={this.cancelrule} > {t("Cancel")} &nbsp;&nbsp;&nbsp; </a> &nbsp;&nbsp;&nbsp; </div>
      )
    }
    getCustomdate = ()=>{
      const  {category,periodtype,count} =  this.state
      // return(<>
      //   <Reactbootstrap.Form.Control className = 'input_sw'
      //       as="select"
      //       name="type"
      //       >
      //       <option id = {0} >----Upcoming feature----</option>
      //   </Reactbootstrap.Form.Control>
      //   </>)
        return(<>
          <div className="col-md-12 row">
           <div className="col-md-4">
          </div>
         <div className="col-md-8 input_sw p-0">
             <Reactbootstrap.Form.Control
               as="select"
               name="type"
               >
               <option>Now</option>
           </Reactbootstrap.Form.Control>
       </div>
       </div>
          <div className="col-md-12 row">
           <div className="col-md-4">
            <span style={{color: '#EC661C'}}>  period: </span>
          </div>
         <div className="col-md-8 input_sw p-0">
             <Reactbootstrap.Form.Control
               as="select"
               name="type"
               value = {periodtype}
               onChange = {(e)=>this.handlePeriodChange(e,'periodtype')}
               >
               <option id  = {1} value = {1} name  = {'+'}>Addition</option>
                <option id  = {2} value = {2} name  = {'-'} >Subtraction</option>
           </Reactbootstrap.Form.Control>
       </div>
       </div>
       <div className="col-md-12 row">
        <div className="col-md-4">
         <span style={{color: '#EC661C'}}>  value: </span>
       </div>
      <div className="col-md-8 input_sw p-0">
        <Reactbootstrap.Form.Control type='text' pattern = "[0-9]+(,[0-9]+)*,?"   onChange={this.changePeriodValue} placeholder = 'Value' value={count}
         />
    </div>
    </div>
    <div className="col-md-12 row">
     <div className="col-md-4">
      <span style={{color: '#EC661C'}}>  category: </span>
    </div>
   <div className="col-md-8 input_sw p-0">
       <Reactbootstrap.Form.Control
         as="select"
         name="type"
         value = {category}
         onChange = {(e)=>this.handlePeriodChange(e,'category')}>
         <option id = {4} value = {4} name  = 'Years'>Years</option>
         <option id = {3}  value = {3} name = 'Months'> Months</option>
         <option id = {2}  value = {2} name = 'Days'> Days</option>
         <option id ={1} value = {1}  name  = 'Hours'> Hours</option>
     </Reactbootstrap.Form.Control>
 </div>
 </div>
          </>)
    }

    getcssobj =(obj)=>{
this.cssobj = obj
    }
    setListOptions =(from = 'NO_DEFAULT')=>{

    let  controlType = from === 'NO_DEFAULT' ? this.state.controlType: this.state.currentElementType;
      let parentId =  this.getparentId(from);
    if(parseInt(controlType) !== window.LISTORG){
    if(parentId !== 0){
        datasave.service(window.GET_PARENTLIST_DATA + '/' +parentId, 'GET').then(
        response =>{
                if(response['child_data'].length){
                const childrens   =  response['child_data'].filter( item =>{ return parseInt(item.hide) === 0});
                if(from === 'DEFAULT'){
                  console.log(childrens);
                  this.setState({
                    child_data_default:childrens
                  })
                }else {
                  this.setState({
                      child_data:childrens, editclick:false,})
                }
        }}
            )}

}else{
    this.getListOrgUnits(from);
}
    }
    getDefaultValueOptions = (type,from = 'DEFAULT') => {
      let controlType = parseInt(type)
      const { defaultValue,defaultValueId } = this.state
      let controlid = from === 'NO_DEFAULT' ? this.state.controlId : this.props.webelement_id;
      let values = [];
      if (controlType === window.DATEFIELD) {

              let controls  = this.state.controls;
              let obj ={}; let type = 1;
              const item = controls.filter( item =>{ return item.id === controlid});
               if(item.length){
                 Object.values(item).map(item =>{
                      obj = JSON.parse(item.json_data);
                      return obj
                 })}
                 type = obj.display_type !== undefined ? obj.display_type:1;
              if( parseInt(type) === 2){
                  this.isDateType = 2
                        values.push(
                              <Reactbootstrap.Form.Group controlId="form">

                                  <DatePicker

                                          selected={ defaultValue !== undefined ? new Date(defaultValue):undefined}
                                          onChange={(date) => this.changeValues(date,0,from)}
                                          showTimeSelect
                                          withPortal = {true}
                                          timeCaption="time"
                                          dateFormat="dd-MM-yyyy h:mm aa"
                                  />

                                  </Reactbootstrap.Form.Group>
                        )
              }else{
                  this.isDateType = 1;
                  values.push(<Reactbootstrap.Form.Control
                  type="date" name="date" onChange={(e)=>this.changeValues(e,from,1)} style={{ }} value={defaultValue}>
                  </Reactbootstrap.Form.Control>)
              }
      }
      if (controlType === window.TEXTBOX) {
          values.push(
              <Reactbootstrap.Form.Control as="textarea" onChange={(e)=>this.changeValues(e,from,1)} value={defaultValue} rows="3" />
          )
      }
      if (controlType === window.DATABASELIST || controlType === window.TEXTFIELD || controlType === window.DECIMALFIELD || controlType === window.NUMERICFIELD  || controlType === window.DATABASELIST_MULTISELECT) {
          values.push(
              <Reactbootstrap.Form.Control type='text' pattern = {(controlType === window.DECIMALFIELD || controlType === window.NUMERICFIELD) ? "[0-9]+(,[0-9]+)*,?":true} style={{  }} onChange={(e)=>this.changeValues(e,from,1)} placeholder = 'Value' value={defaultValue === undefined ?"":defaultValue} />
          )
      }
      if(controlType === Window.LIST || controlType === window.RADIO_BUTTON || controlType === Window.CHECKBOX || controlType === window.LISTORG){
          if(this.state.child_data_default.length>0){
            console.log('greater');
              let options = [];
              Object.values(this.state.child_data_default).map(item => {
                return   options.push(<option  key = {item.id} id={item.id} name  = {item.name} value = {item.id}> {item.name}</option>)
              })
              if(controlType !== window.LISTORG){
                  if(this.NAoption){
                      options.push(<option key = {-1} value  = {-1} name = "N/A" id = {-1}>N/A</option>)
                  }
              }
              values.push(
                  <Reactbootstrap.Form.Control style={{  }} as="select" name="outype" value={defaultValueId} onChange={(e)=>this.changeValues(e,from,1)} >
                      <option>---Select---</option>
                      {options}
                  </Reactbootstrap.Form.Control>
              )
          }
      }
      console.log(values);
      if (values.length === 0) {
          values.push(
              <h6>No values  assigned for current element </h6>
          )
      }
      this.track = 0

      return values;


  }


} export default translate(SubAction)
