import React, { Component,Suspense } from 'react'
import { translate } from '../../language'
import * as Reactbootstrap from 'react-bootstrap'
import { datasave } from '../../_services/db_services'
import { store } from '../../store'
import '../webform.css'
import SubActions from './SubActions'
import { OCAlert } from '@opuscapita/react-alerts';
import { filter } from './ActionFilter';
const DisplayRules = React.lazy(() => import('../WebElements/DisplayRules'));
const _allowedtypes = [ 18,16, 15, 21];
const NOCSS = [10,8,13,18]
const ENABLE = window.WEBFORM_Enable
const SHOW = window.WEBFORM_Show
const HIDE = window.WEBFORM_Hide
const REQUIRD = window.WEBFORM_Required
const DEFAULT = window.WEBFORM_DefaultValue
const EMPTY = window.WEBFORM_Empty
const COLOR = window.WEBFORM_COLOR;
var SUBACTIONSDATA = '';
class Actions extends Component {
    parentid = 0; clonerule = '';
    openNodes; nodeAdded = false;
    constructor(props) {
        super(props)
        this.state =
            {
                t: props.t,
                actions: [],
                treeData: [],
                Enable: [],
                Disable: [],
                Show: [],
                Hide: [],
                Required: [],
                Default: [],
                Empty: [],
                Css:[],
                clickitem: 9999999991,
                type: undefined,
                ruleclick: false,
                condition: { action: 1, orgunit: 1, workflow: 1, control: 1 },
                clickid: undefined,
                orgArrayIds: window.WEBFORM_ORG_ID,
                currentclickitem: 'Enable',
                EnableOpenNodes: [],
                DisableOpenNodes: [],
                ShowOpenNodes: [],
                HideOpenNodes: [],
                RequiredOpenNodes: [],
                DefaultOpenNodes: [],
                EmptyOpenNodes: [],
                CssOpenNodes:[],
                webelementid: this.props.webelement_id === undefined ? 2 : this.props.webelement_id,
                editclick: false,
                deleteclick: false,
                webformid: this.props.webform_id === undefined ? 2 : this.props.webform_id,
                orclick: true,
                activeKey: undefined,
                openNodes: [],
                Color:[],
                isLoading:true,
                loadingtext:"We're building the rules as fast as we can ....",
                showcss:1,
                showblocbox:1,
            }
    }
    UNSAFE_componentWillMount() {
        this.getDataApi()
        datasave.service(window.GET_ORG_UNITS + '/' + this.props.webform_id, 'GET').then(res=>{
            this.SUBACTIONSDATA = res
        })
    }
    componentDidUpdate(prevProps, prevState) {
        if (this.props.webelement_id != prevProps.webelement_id) {
            this.setState({isLoading:true},()=>{this.getDataApi()})
        }
    }
    getDataApi = () => {
        let storage = store.getState();
        let actions = storage.UserData.webform_actions;
        let controlTypes = storage.UserData.webform_controls;
        let id = this.props.webelement_id
        let url = window.GET_WEBFORM_ACTIONS + id+'/'+this.props.webform_id;
        datasave.service(url, 'GET').then(
            response => {
                if (response.length === 1) {
                    let obj = filter.latestdata(response.data, controlTypes)
                    response = obj[id]
                    this.setState({
                        Enable: response[0]['tree_data'],
                        treeData: response[0]['tree_data'],
                        Disable: response[1]['tree_data'],
                        Show: response[2]['tree_data'],
                        Hide: response[3]['tree_data'],
                        Required: response[4]['tree_data'],
                        Default: response[5]['tree_data'],
                        Empty: response[6]['tree_data'],
                        Css:   response.length === 9 || response.length === 8 ? response[7]['tree_data']:[],
                        actions: actions,
                        EnableOpenNodes: JSON.parse(response[0]['normal_data']),
                        DisableOpenNodes: JSON.parse(response[1]['normal_data']),
                        ShowOpenNodes: JSON.parse(response[2]['normal_data']),
                        HideOpenNodes: JSON.parse(response[3]['normal_data']),
                        RequiredOpenNodes: JSON.parse(response[4]['normal_data']),
                        DefaultOpenNodeslt: JSON.parse(response[5]['normal_data']),
                        EmptyOpenNodes: JSON.parse(response[6]['normal_data']),
                        CssOpenNodes: response.length === 9 || response.length === 8 ? JSON.parse(response[7]['normal_data']):[],
                        isLoading:false
                    },()=>{
                        this.actionClick(9999999991, 'Enable')
                    })
                } else {

                    this.setState({
                        actions: actions,
                        Enable: [],
                        Disable: [],
                        Show: [],
                        Hide: [],
                        Required: [],
                        Default: [],
                        Empty: [],
                        treeData: [],
                        ruleclick: false,
                        editclick: false,
                        deleteclick: false,
                        clickid: undefined,
                        clickitem:ENABLE,
                        isLoading:false,
                        Css:[],
                    }, () => {
                        this.actionClick(9999999991, 'Enable')
                    })
                }
            }
        )
    }
    handleRule(e, type) {
        const {showcss, clickitem,showblocbox} =  this.state
        this.setState({
            ruleclick: true,
            type: type,
            showcss:0,
            showblocbox:0,
        })
        if(showcss === 1 && clickitem === window.WEBFORM_COLOR && type !== 1 ){
                this.setState({showcss: 1})
        }

    }
    actionClick(e, type) {
        if (e === window.WEBFORM_DefaultValue) {
            type = 'Default'
            this.setState({ clickitem: e, treeData: this.state.Default, currentclickitem: type, clickid: undefined, ruleclick: false })
        } else {

            this.setState({ clickitem: e, treeData: this.state[type], currentclickitem: type, clickid: undefined, ruleclick: false })
        }
        let item = type;
        let openNodes = item == 'Enable' ? this.state.EnableOpenNodes : item == 'Disable' ? this.state.DisableOpenNodes : item == 'Show' ? this.state.ShowOpenNodes : item == 'Hide' ? this.state.HideOpenNodes : item == 'Required' ? this.state.RequiredOpenNodes : item == 'Default' ? this.state.DefaultOpenNodes : this.state.EmptyOpenNodes;
        if(e === window.WEBFORM_COLOR){
            this.setState({showcss:1})
        }

        this.setState({
            openNodes: openNodes,
        })
    }
    changeComponent = (saved, obj = {}) => {
        const {clickitem } =  this.state
        if (saved) {
            obj = this.createRule(obj);
            if (this.state.treeData.length == 0) {
                  obj.showcss =1
                this.setState({ editclick: false, ruleclick: false, [this.state.currentclickitem]: [obj], treeData: [obj], }, () => {
                    this.handleSaveRule(1);
                })
                return
            }
            this.nodeAdded = false;
            this.createTreeStructure(obj, this.state.clickid);
            let array = this.state.treeData;
            this.setState({ ruleclick: false, editclick: false, [this.state.currentclickitem]: array, }, () => {
                this.handleSaveRule(1);
            })
            this.updateActiveNodes(obj)
        } else {
            this.setState({
                ruleclick: false,
                editclick: false,
                showcss:clickitem === window.WEBFORM_COLOR ?1:0,
            })
        }
    }
    updateActiveNodes = (obj) => {
        let key1; const { key,  } = obj;
        if (this.nodeAdded) {
            key1 = this.state.activeKey + '/' + key;
        } else {
            var removedIndex = this.state.activeKey.substring(this.state.activeKey.lastIndexOf("/"));
            var active = this.state.activeKey.replace(removedIndex, "");
            if (active != '') {
                key1 = active + '/' + key
            } else {
                key1 = key
            }
        }
        this.handleTreeClick(obj, key1);
    }
    handleTreeClick = (e, activekey = undefined) => {
        const { index, key, action, control, operator, orgid, value, workflow, orgname, type,
             name, controlType, workflowid, controlid, operatorId,valueType ,valueId,isDateType, showcss,showblocbox, css,count,category,periodtype,defaultValue,defaultValueId} = e;
        let item = this.state.currentclickitem
        let nameofcurrentarray = item == 'Enable' ? 'EnableOpennodes' : item == 'Disable' ? 'DisableOpenNodes' : item == 'Show' ? 'ShowOpenNodes' : item == 'Hide' ? 'HideOpenNodes' : item == 'Required' ? 'RequiredOpenNodes' : item == 'Default' ? 'DefaultOpenNodes' : 'EmptyOpenNodes'
        let openNodes = item == 'Enable' ? this.state.EnableOpenNodes : item == 'Disable' ? this.state.DisableOpenNodes : item == 'Show' ? this.state.ShowOpenNodes : item == 'Hide' ? this.state.HideOpenNodes : item == 'Required' ? this.state.RequiredOpenNodes : item == 'Default' ? this.state.DefaultOpenNodes : this.state.EmptyOpenNodes;
        let node = activekey === undefined ? key : activekey
        if (openNodes.includes(node)) {
            var i = openNodes.indexOf(node);
            if (i !== -1) openNodes.splice(i, 1);
        } else {
            openNodes.push(node)
        }

        this.setState({
            clickid: index, editaction: action,
            editcontrol: control, editoperator: operator, editorgname: orgname,
            editorgid: orgid, editvalue: value, editworkflow: workflow,
            editworkflowid: workflowid,
            edittype: parseInt(type), editauthor: name, editcontroltype: controlType,
            editcontrolid: parseInt(controlid),
            editoperatorid: parseInt(operatorId),
            activeKey: activekey !== undefined ? activekey : key,
            openNodes: openNodes,
            [nameofcurrentarray]: openNodes,
            editvalueType :valueType,
            editvalueid:valueId,
            editisDateType:isDateType,
            showcss:showcss,
            editshowcss:showcss,
            editcss:css,
            editcount:count,
            editperiodtype:periodtype,
            editcategory:category,
            editdefaultValue:defaultValue,
            editdefaultValueId:defaultValueId
        })
    }
    createTreeStructure(obj = '', index = '', nameofcurrentarray = '') {
        Object.values(this.state.treeData).map((item, at) => {
            if (item.index == this.state.clickid) {
                // if delete click
                if (this.state.deleteclick) {


                    this.state.treeData.splice(at, 1);
                    this.setState({ deleteclick: false,[this.state.currentclickitem]: this.state.treeData }, () => { this.handleSaveRule(1); })


                    return;
                } else {
                    let index = this.state.editclick ? at : this.state.treeData.length;
                    obj.nodes = this.state.editclick ? item.nodes : [];
                    if (this.state.type === 1) { // if clicked and rule
                        if (item.nodes.length) { // if already and rule present
                            obj.label = this.clonerule // modify label from AND to OR type
                            obj.type = 0;  // modify node type as OR
                            item.nodes[item.nodes.length] = obj; // append at last position
                        } else {
                            // let openNodes    = this.state.openNodes
                            //  this.openNodes = item.key;
                            this.nodeAdded = true;
                            item.nodes[0] = obj // if no nodes add at o index
                        }
                    } else {
                        obj.showcss = 1
                        this.state.treeData[index] = obj
                    }
                    // (this.state.type === 1) ? item.nodes[0] = obj : this.state.treeData[index] = obj;
                    (this.state.type === 1) ? (item).nodes[0].parent = this.state.clickid : (this.state.treeData[index]).parent = 12;

                }
                return
            }
            this.checkNode(item.nodes, obj, nameofcurrentarray)
        })
    }
    // Check for inner nodes
    checkNode = (nodes, obj = '', nameofcurrentarray = '') => {
        Object.values(nodes).map((item1, at) => {
            // if inner nodes contains again nodes loop them
            if (Object.values(item1.nodes).length >= 1) {
                if (item1.index == this.state.clickid) {
                    if (this.state.deleteclick) {
                        nodes.splice(at, 1);
                        this.setState({ deleteclick: false }, () => { this.handleSaveRule(1); })
                        return
                    } else {
                        let index = this.state.editclick === true ? at : nodes.length;
                        obj.nodes = this.state.editclick ? item1.nodes : [];

                        if (this.state.type === 1) {
                            if (Object.values(item1.nodes.length) >0) {
                                obj.label = this.state.editclick ? obj.label : this.clonerule
                                obj.type = this.state.editclick ? obj.type : 0;


                                item1.nodes[item1.nodes.length] = obj;
                            } else {
                                // let openNodes    = this.state.openNodes
                                // this.openNodes = this.openNodes+'/'+item1.key;
                                this.nodeAdded = true;
                                item1.nodes[0] = obj
                            }
                        } else {
                            nodes[index] = obj;
                        }
                        // (this.state.type === 1) ? item1.nodes[0] = obj : nodes[index] = obj;
                        (this.state.type === 1) ? item1.nodes[0].parent = this.state.clickid : (nodes[index]).parent = item1.parent;
                        (this.state.type === 1) ? this.parentid = this.state.clickid : this.parentid = item1.parent;
                        return
                    }
                }
                // loop inner nodes
                Object.values(item1.nodes).map((node, i) => {
                    if (node.index == this.state.clickid) {
                        // check if user clicked delete


                        if (this.state.deleteclick) {
                            item1.nodes.splice(i, 1);
                            this.setState({ deleteclick: false }, () => { this.handleSaveRule(1); })
                            return
                        } else {
                            // check if user clicked creation or edit rule
                            let index = this.state.editclick ? i : (item1.nodes).length;
                            // assign inner nodes if he clicked edit mode bcz for edit node might have childrens
                            obj.nodes = this.state.editclick ? node.nodes : [];
                            if (this.state.type === 1) {
                                if (node.nodes.length) {
                                    obj.label = this.state.editclick ? obj.label : this.clonerule
                                    obj.type = this.state.editclick ? obj.type : 0;
                                    node.nodes[node.nodes.length] = obj
                                } else {
                                    this.nodeAdded = true;
                                    // let openNodes    = this.state.openNodes
                                    //  this.openNodes = this.openNodes+'/'+node.key;
                                    node.nodes[0] = obj
                                }
                            } else {
                                item1.nodes[index] = obj;
                            }
                            // (this.state.type === 1) ? node.nodes[0] = obj : item1.nodes[index] = obj;
                            (this.state.type === 1) ? node.nodes[0].parent = this.state.clickid : (item1.nodes[index]).parent = node.parent;
                            (this.state.type === 1) ? this.parentid = this.state.clickid : this.parentid = node.parent;
                        }
                        return
                    }
                    //  call again if nodes present
                    if (node.nodes.length) {
                        this.checkNode(node.nodes, obj, nameofcurrentarray);
                    }
                })
            } else {
                if (item1.index === this.state.clickid) {
                    if (this.state.deleteclick) {
                        nodes.splice(at, 1);
                        this.setState({ deleteclick: false }, () => { this.handleSaveRule(1); })
                        return
                    } else {
                        let index = this.state.editclick ? at : nodes.length;
                        obj.nodes = this.state.editclick ? item1.nodes : [];
                        if (this.state.type === 1) {
                            if (item1.nodes.length) {
                                obj.label = this.clonerule;
                                obj.type = 0;
                                item1.nodes[item1.nodes.length] = obj;
                            } else {
                                // let openNodes    = this.state.openNodes
                                // this.openNodes = this.openNodes+'/'+item1.key;
                                this.nodeAdded = true;
                                item1.nodes[0] = obj
                            }

                        } else {
                            nodes[index] = obj;
                        }
                        // (this.state.type === 1) ? item1.nodes[0] = obj : nodes[index] = obj;
                        (this.state.type === 1) ? item1.nodes[0].parent = this.state.clickid : (nodes[index]).parent = item1.parent;
                        (this.state.type === 1) ? this.parentid = this.state.clickid : this.parentid = item1.parent;
                        return
                    }
                }
            }
        }
        )
    }

    createRule(obj) {
        let data;
        const { orgArrayIds, type, clickid, edittype } = this.state
        let rule = this.state.editclick ? ((parseInt(edittype) === 1) ? 'And' : 'OR') : ((type === 1) ? 'And' : 'OR');
        let name = obj.author; let label; let label2;
        if (orgArrayIds.includes(parseInt(obj.action))) {
            this.clonerule = 'OR' + ' ' + name + ' Equals ' + obj.orgunit
            label = rule + ' ' + name + ' Equals ' + obj.orgunit;
        } else {
            name = parseInt(obj.action) === window.WEBFORM_CALCULATION ? obj.control : 'Workflow';
            let operator = parseInt(obj.action) === window.WEBFORM_CALCULATION ? obj.operator : 'Equals';
            let value = parseInt(obj.action) === window.WEBFORM_CALCULATION ? (obj.valueType === 3 ? 'empty' : obj.value) : obj.workflow;
            this.clonerule = 'OR' + ' ' + name + ' ' + operator + ' ' + value;
            label2 = rule + ' ' + name + ' ' + operator + ' ' + value;
        }
         data = {
            label: orgArrayIds.includes(parseInt(obj.action)) ? label : label2,
            key: 'N' + Math.floor(Math.random() * 10000) + 1,
            index: (this.state.editclick) ? clickid : Math.floor(Math.random() * 1000) + 1,
            parent: 12,
            action: obj.action,
            orgname: obj.orgunit,
            orgid: obj.orgid,
            control: obj.control,
            controlType: obj.controlType,
            controlid: obj.controlid,
            operator: obj.operator,
            operatorId: obj.operatorId,
            workflow: obj.workflow,
            workflowid: obj.workflowid,
            value: obj.value,
            type: this.state.editclick ? edittype : type,
            name: name,
            valueId: obj.valueId,
            valueType:obj.valueType,
            isDateType:obj.isDateType,
            nodes: [],
            css:obj.css,
            showcss:0,
            showblocbox:0,
            count:obj.count,
            periodtype:obj.periodtype,
            category:obj.category,
            defaultValue:obj.defaultValue,
            defaultValueId:obj.defaultValueId
        }
        return data

    }
    handleEditDeleRule(e, type) {

        if (type) {
            this.setState({ editclick: true, ruleclick: true, type: 0 })
        } else {
            this.setState(prevState => ({
                deleteclick: true
            }), () => {
                this.createTreeStructure();
            });
        }
    }
    handleInspect = (event) => {
        document.addEventListener('keydown', function () {
            if (event.keyCode == 123) {

                return false;
            } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {

                return false;
            } else if (event.ctrlKey && event.keyCode == 85) {

                return false;
            }
        }, false);

        if (document.addEventListener) {
            document.addEventListener('contextmenu', function (e) {
                e.preventDefault();
            }, false);
        } else {
            document.attachEvent('oncontextmenu', function () {

                window.event.returnValue = false;
            });
        }
    }
    handleSaveRule(e) {
        const { t } = this.state;
        let data = this.getDataToPost();



        let url = window.POST_ACTIONS;
        datasave.service(url, 'POST', data).then(
            response => {
                if (response['status'] == 200) {
                    OCAlert.alertSuccess(t('Rules has been updated successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
                } else {
                    OCAlert.alertError(t('Error occured while storing rules !'), { timeOut: window.TIMEOUTNOTIFICATION });
                }
            })
    }
    getDataToPost = () => {


        return {
            'enableRule': this.state.EnableOpenNodes,
            'disableRule': this.state.DisableOpenNodes,
            'showRule': this.state.ShowOpenNodes,
            'hide': this.state.HideOpenNodes,
            'required': this.state.RequiredOpenNodes,
            'default': this.state.DefaultOpenNodes,
            'empty': this.state.EmptyOpenNodes,
            'css'  :this.state.CssOpenNodes,
            'webelementid': this.props.webelement_id,
            'enableTree': this.state.Enable,
            'disableTree': this.state.Disable,
            'showTree': this.state.Show,
            'hideTree': this.state.Hide,
            'requireTree': this.state.Required,
            'defaultTree': this.state.Default,
            'emptyTree': this.state.Empty,
            'CssTree'  :  this.state.Css,
            'webformid': this.props.webform_id,
        }
    }
    render() {
        const { t, clickitem, ruleclick, treeData, condition, clickid, editclick,
            activeKey,isLoading, loadingtext, showcss,showblocbox} = this.state

        let showButton = treeData.length >= 1;
        if(isLoading){
            return (
                <div className="col-md-12 row">
                    <div style={{ marginLeft: "80px",marginTop:'80px'}} className='col-md-11' >
                        <h5>{t("loadingtext")}</h5>
                    </div>
                </div>
            )
        }else{
            return (
                <div className="" onClick={this.handleInspect}>
                    <div className='col-md-12 mb-3 mt-2 p-0'>
                        <div style={{ border: '1px solid gray' }} className='card'>
                            <div className="row mt-1" style={{ paddingRight: '15px', paddingLeft: '15px'}}>
                                <Reactbootstrap.Col lg={4}>
                                    <div className="text-center">
                                        <Reactbootstrap.Table responsive bordered hover>
                                            <thead>
                                                <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
                                                    <th>{t('Actions')}</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                {this.state.actions.map(action => {

                                                    let className = (clickitem === action.typeid ? 'actionactive' : 'inactive');
                                                  return(  <tr key={1} style={{ cursor: 'pointer' }}>

                                                         {_allowedtypes.includes(this.props._eletype) && action.typeid !== DEFAULT && action.typeid !== EMPTY &&
                                                            ((this.props._eletype ===15||this.props._eletype ===16) && action.typeid !== REQUIRD) &&
                                                            <td key={action.typeid} id={action.typeid} className={className} onClick={(e) => this.actionClick(action.typeid, action.name)}>
                                                                  <div className="col-md-12 row"><div style={{paddingLeft: '2rem'}} className="col-md-4 pr-0"><span style={{ marginRight: '10px' }}>{this.getIcons(action.typeid)} </span></div> <div style={{textAlign: 'left',}} className="col-md-8">{t(action.name)}</div></div>
                                                            </td>}

                                                          {(this.props._eletype === 19 &&action.typeid !== DEFAULT && action.typeid !== EMPTY && action.typeid !== COLOR ) &&
                                                                 <td key={action.typeid} id={action.typeid} className={className} onClick={(e) => this.actionClick(action.typeid, action.name)}>
                                                                      <div className="col-md-12 row"><div style={{paddingLeft: '2rem'}} className="col-md-4 pr-0"><span style={{ marginRight: '10px' }}>{this.getIcons(action.typeid)} </span></div> <div style={{textAlign: 'left',}} className="col-md-8">{t(action.name)}</div></div>
                                                                   </td>}
                                                            {((this.props._eletype === 21) && (action.typeid === SHOW || action.typeid === HIDE || action.typeid !== COLOR )) &&
                                                                  <td key={action.typeid} id={action.typeid} className={className} onClick={(e) => this.actionClick(action.typeid, action.name)}>
                                                                         <div className="col-md-12 row"><div style={{paddingLeft: '2rem'}} className="col-md-4 pr-0"><span style={{ marginRight: '10px' }}>{this.getIcons(action.typeid)} </span></div> <div style={{textAlign: 'left',}} className="col-md-8">{t(action.name)}</div></div>
                                                                   </td>}
                                                                   {(NOCSS.includes(this.props._eletype) && (action.typeid !== COLOR )) &&
                                                                  <td key={action.typeid} id={action.typeid} className={className} onClick={(e) => this.actionClick(action.typeid, action.name)}>
                                                                         <div className="col-md-12 row"><div style={{paddingLeft: '2rem'}} className="col-md-4 pr-0"><span style={{ marginRight: '10px' }}>{this.getIcons(action.typeid)} </span></div> <div style={{textAlign: 'left',}} className="col-md-8">{t(action.name)}</div></div>
                                                                   </td>}
                                                            {( !_allowedtypes.includes(this.props._eletype)&& !NOCSS.includes(this.props._eletype) && this.props._eletype !== 19 ) &&
                                                            <td key={action.typeid} id={action.typeid} className={className} onClick={(e) => this.actionClick(action.typeid, action.name)}>
                                                                  <div className="col-md-12 row"><div style={{paddingLeft: '2rem'}} className="col-md-4 pr-0"><span style={{ marginRight: '10px' }}>{this.getIcons(action.typeid)} </span></div> <div style={{textAlign: 'left',}} className="col-md-8">{t(action.name)}</div></div>
                                                                </td>}
                                                    </tr>)

                                                })}
                                            </tbody>
                                        </Reactbootstrap.Table>
                                        <div className="pg col-md-12">
                                        </div>
                                    </div>
                                </Reactbootstrap.Col>
                                <Reactbootstrap.Col lg={8} style={{}}>
                                    <div className="text-center mt-2 mb-2">
                                        <div className='mt-2 mb-2' onClick={this.handleInspect}></div>
                                        {!ruleclick &&
                                            <td className="p-2"><Reactbootstrap.Button variant="outline-primary" disabled={this.state.treeData.length == 0 ? false : (clickid === undefined)} onClick={(e) => this.handleRule(e, 0)}>{t("Add OR")}</Reactbootstrap.Button>
                                                &nbsp;{showButton && <Reactbootstrap.Button variant="outline-success" onClick={(e) => this.handleRule(e, 1)} disabled={clickid === undefined}> {t("Add AND")}</Reactbootstrap.Button>}
                                                &nbsp;{showButton && <Reactbootstrap.Button variant="outline-warning" disabled={clickid === undefined} onClick={(e) => this.handleEditDeleRule(e, 1)}> {t("Edit")}</Reactbootstrap.Button>} &nbsp;
                                            {showButton && <Reactbootstrap.Button variant="outline-danger" disabled={clickid === undefined} onClick={(e) => this.handleEditDeleRule(e, 0)}>{t("Remove")}</Reactbootstrap.Button>}</td>}
                                    </div>
                                    {ruleclick && <SubActions changeComponent={this.changeComponent.bind(this)}
                                    type={condition} edit={editclick} data={this.sendEditData()} webelement_id={this.props.webelement_id}
                                    webform_id={this.props.webform_id}
                                    apidata = {this.SUBACTIONSDATA} from = {'actions'}
                                    currentClickitem = {clickitem}
                                    SHOWCSS = {clickitem === window.WEBFORM_COLOR && showcss === 1}
                                    fromManageElements = {this.props.fromManageElements}
                                    />}
                                    {!ruleclick &&
                                          <Suspense fallback={<div>Loading...</div>}>
                                            <DisplayRules
                                             data={treeData}
                                             handleTreeClick={this.handleTreeClick} active={activeKey}
                                             openNodes={this.state.openNodes} />
                                          </Suspense>
                                    }
                                </Reactbootstrap.Col>
                            </div>
                        </div>
                    </div>
                    {/* </div> */}
                </div>
            )
        }


    }
    getIcons = (type) => {
        const { Enable, Disable, Show, Hide, Required, Default, Empty, Css } = this.state
        switch (type) {
            case window.WEBFORM_Enable:
                return Enable.length > 0 ? <i class="webform-sprite webform-sprite-enable"></i> : <i class="webform-sprite webform-sprite-enablec"></i>;

            case window.WEBFORM_Disable:
                return Disable.length > 0 ? <i class="webform-sprite webform-sprite-disable"></i> : <i class="webform-sprite webform-sprite-disablec"></i>;

            case window.WEBFORM_Show:
                return Show.length > 0 ? <i class="webform-sprite webform-sprite-viewlist"></i> : <i class="webform-sprite webform-sprite-viewlistc"></i>;

            case window.WEBFORM_Hide:
                return Hide.length > 0 ? <i class="webform-sprite webform-sprite-viewaction"></i> : <i class="webform-sprite webform-sprite-viewactionc"></i>;

            case window.WEBFORM_Required:
                return Required.length > 0 ? <i class="webform-sprite webform-sprite-required"></i> : <i class="webform-sprite webform-sprite-requiredc"></i>;

            case window.WEBFORM_DefaultValue:
                return Default.length > 0 ? <i class="webform-sprite webform-sprite-default"></i> : <i class="webform-sprite webform-sprite-defaultc"></i>;
             case EMPTY:
                return Empty.length > 0 ? <i class="webform-sprite webform-sprite-empty"></i> : <i class="webform-sprite webform-sprite-emptyc"></i>;
            case window.WEBFORM_COLOR:
                return Css.length > 0 ? <i class="ActionCss ActionCss-css-active"></i>: <i class="ActionCss ActionCss-cssinactive"></i>;

        }


    }
    sendEditData = () => {
        const { editaction, editauthor, editorgname, editorgid,
            editcontrol, editoperator, editvalue, editworkflow, editcontroltype, editworkflowid, editcontrolid, editoperatorid ,
            editvalueType,editvalueid, editisDateType, editshowcss, editcss,editcount,editperiodtype,editcategory
           ,editdefaultValue, editdefaultValueId} = this.state
        if (this.state.editclick) {
            return {
                action: editaction,
                author: editauthor,
                orgid: editorgid,
                orgunit: editorgname,
                workflow: editworkflow,
                workflowid: editworkflowid,
                controlid: editcontrolid,
                control: editcontrol,
                controlType: editcontroltype,
                valueId: editvalueid,
                value: editvalue,
                operatorId: editoperatorid,
                operator: editoperator,
                valueType :editvalueType,
                isDateType:editisDateType,
                editshowcss:editshowcss,
                editcss :editcss,
                count:editcount,
                periodtype:editperiodtype,
                category:editcategory,
                defaultValue:editdefaultValue,
                defaultValueId:editdefaultValueId
            }
        }
        return {};
    }
}
export default translate(Actions)
