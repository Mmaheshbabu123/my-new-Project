import React,{useState ,useEffect} from 'react'
import * as Reactbootstrap from 'react-bootstrap'
import { datasave } from '../../_services/db_services'
import { translate } from '../../language'
import { OCAlert } from '@opuscapita/react-alerts'
import FieldForm from './FieldForm';
import ChartForm from './ChartForm';
import {CommonAggregationFunc} from './CommonAggregationFunc';

const MainCustomWindow = props => {
const t = props.t;
const intialState = {id: 0, chartName: '', activeTab: props.activeTab !== undefined ? parseInt(props.activeTab) : 0,
webformId: 0, labelIds: [], labelObj: {}, valueIds: [], valueObj: {},
subListData: {}, listData: {}, submitDetails: {}, elementDetails: {}, elementWithType: {},
dateFieldFilter: 0, dateChoice: 0, fromDate: '', toDate: '', dateSelect: 0,
chartType: window.PIE_CHART_TYPE,  chartTitle: '',  chartXTitle: '', chartYTitle: '',
showChart: 0, showGraph: 1, showTable: 1, status: false, quality_fiscal:{}, orderBy: 'ascending', labelFilterSelect: [], labelData: {}, valueData: {}, callElementDataSave: 0, originalLabelData: {}, originalValueData: {}, total: 0, elementOrList: 0, searchText: '', lockFilter: 0, completeWebformDetails: {}};
const [state, setState] = useState(intialState);
const { status, activeTab, chartType, chartName, chartTitle, chartXTitle, chartYTitle, dateFieldFilter,
  	dateSelect, showChart, showGraph, showTable, dateChoice, fromDate, toDate, subListData, listData, labelIds, valueIds,
	labelObj, valueObj, elementWithType, elementDetails, labelElementDetails, valueElementDetails,
	originalLabelElementDetails, originalValueElementDetails, submitDetails, originElementDetails,
	quality_fiscal, dateListOptions, labelFilterSelect, labelData, valueData, callElementDataSave, originalLabelData, originalValueData, total, elementOrList, lockFilter, completeWebformDetails} = state;
const [count, setCount] = useState(0);
const [webformId, setWebformId] = useState(props.webformId !== undefined ? props.webformId : props.match.params.webformId);
const [id, setId] = useState(props.id !== undefined ? props.id : props.match.params.id);
useEffect(()=>{
  const fetchData = async () => {
   await fetchListData();
   //await getAllElementDetailsWithDates();
  }
  fetchData();
}, [props.id])
console.log(state);
	console.log('state');
	async function fetchListData(){
 if(Object.keys(quality_fiscal).length === 0 && Object.keys(subListData).length === 0){
 const lang_code = await (localStorage.getItem('Applang'));
 await datasave.service(window.GET_LIST_AND_SUBLIST + '/' + 0 + '/' + lang_code , 'GET').then(
   async response => {
     let dateQualityFiscal = await getQualityFiscal();
     checkForIdAndCallService({subListData: response['sublists'], listData: response['lists'], status: true, dateListOptions: dateQualityFiscal['date_list'], quality_fiscal: dateQualityFiscal['quality_fiscal']});
   });
 }else{
     checkForIdAndCallService({subListData: subListData, listData: listData, status: true, dateListOptions: dateListOptions, quality_fiscal: quality_fiscal});
 }
}
async function getQualityFiscal(){
  let result = {};

  //await datasave.service(window.GET_QUALITY_FISCAL, 'GET').then(
  await datasave.service(window.GET_WEBFORM_DATES + '/' + (props.webformId !== undefined ? props.webformId : props.match.params.webformId), 'GET').then(
    async response => {
      if(response['status'] === 200){
        result['date_list'] = response['data']['date_list'];
        result['quality_fiscal'] = response['data']['quality_fiscal'];
      }
    });
    return result;
}

async function checkForIdAndCallService(setObj){
 let id = props.id !== undefined ? props.id : id;
 if(parseInt(id) !== 0){
      //setObj['completeWebformDetails'] = await getAllElementDetailsWithDates();
      await getCustomReportById(setObj);
 }else{
   setState({...state, ...setObj});
 }

}
async function getCustomReportById(setObj){
  await datasave.service(window.GET_CUSTOM_REPORT_BY_ID + '/' + (props.id !== undefined ? props.id : id) + '/' + (props.webformId !== undefined ? props.webformId : webformId), 'GET').then(
    async response => {
      if(response['status'] == 200){
        if(Object.keys(response['data']).length > 0){
          let data = response['data'];
          setObj['chartName'] = data['name'] !== undefined ? data['name'] : '';
          setObj['labelIds'] = data['labelIds'] !== undefined ? data['labelIds'] : [];
          setObj['valueIds'] = data['valueIds'] !== undefined ? data['valueIds'] : [];
          setObj['dateFieldFilter'] =  data['date_field_filter'] !== undefined ? data['date_field_filter'] : 0;
          setObj['dateChoice'] = data['date_choice'] !== undefined ? parseInt(data['date_choice']) : 0;
          setObj['fromDate'] = data['from_date'] !== undefined ? data['from_date'] : '';
          setObj['toDate'] = data['to_date'] !== undefined ? data['to_date'] : '';
          setObj['dateSelect'] = data['date_select'] !== undefined ? parseInt(data['date_select']) : 0;
          setObj['chartType'] = data['chart_details'] !== undefined ? data['chart_details']['chartType'] : 0;
          setObj['chartTitle'] = data['chart_details'] !== undefined ? data['chart_details']['chartTitle'] : '';
          setObj['chartXTitle'] = data['chart_details'] !== undefined ? data['chart_details']['chartXTitle'] : '';
          setObj['chartYTitle'] = data['chart_details'] !== undefined ? data['chart_details']['chartYTitle'] : '';
          setObj['labelObj'] = data['labelObj'] !== undefined ? data['labelObj'] : {};
          setObj['valueObj'] = data['valueObj'] !== undefined ? data['valueObj'] : {};
          setObj['elementWithType'] = data['elementWithType'] !== undefined ? data['elementWithType'] : {};
          setObj['showTable'] = data['show_table'] !== undefined ? parseInt(data['show_table']) : 0;
          setObj['showChart'] = data['show_chart'] !== undefined ? parseInt(data['show_chart']) : 0;
          setObj['showGraph'] = data['show_graph'] !== undefined ? parseInt(data['show_graph']) : 0;
	  setObj['total'] = data['total'] !== undefined ? parseInt(data['total']) : 0;
          setObj['labelFilterSelect'] = data['labelFilterSelect'] !== undefined ? data['labelFilterSelect'] : {};
          setObj['lockFilter'] = data['lock_filter'] !== undefined ? data['lock_filter'] : 0;
	 if(data['show_chart'] === 1){
           await getSelectedElementSubmitDetails(setObj, setObj);
          }else{
            setState({...state, ...setObj});
          }
        }else{
          setState({...state, ...setObj});
        }
      }else{
        setState({...state, ...setObj});
        OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
      }
    });
  }



const getFilterSelectedValue = (type, value, labelOrValue) =>{
  if(type === window.LIST || type === window.CHECKBOX ||
    type === window.RADIO_BUTTON || type === window.LIST_STATIC_TYPE){
      return value.map(key=>{ return parseInt(labelOrValue) === 1 ? key['label'] :  key['value']});
    }else{
        return value;
    }
}
const getToFromDateAccordingToDateSelect = (tempDateSelect, tempDateFieldFilter, tempDateListMinMaxObj, toDate, fromDate) =>{
if(Object.keys(tempDateListMinMaxObj).length > 0 && parseInt(tempDateSelect) === window.ALL){
let  selectDateObj = tempDateListMinMaxObj[tempDateFieldFilter] !== undefined ? tempDateListMinMaxObj[tempDateFieldFilter] : {};
  return  {toDate: selectDateObj['max'] !== 0 ? new Date(selectDateObj['max']) : '',
	 fromDate: selectDateObj['min'] !== 0 ? new Date(selectDateObj['min']) : ''};
}else{
  return { toDate: toDate !== '' ? new Date(toDate) : '', fromDate: fromDate !== '' ? new Date(fromDate) : '' };
}
}

const getLabelValueData = (dataObj) =>{
  const {labelIds, labelElementDetails, valueIds, valueElementDetails, valueAggregation, labelObj} = dataObj;
	let isList = (labelIds.filter(id=>{ return labelObj[id]['islist'] !== undefined && parseInt(labelObj[id]['islist']) === 1})).length > 0 ? 1 : 0;
	return CommonAggregationFunc.getArrangedAggregatedData(dataObj, isList);
}

const smallFuncToFilterAccType = (type, value, filterValue) =>{
  switch(parseInt(type)){
	  case window.LIST: case window.CHECKBOX: case window.RADIO_BUTTON:
          case window.LIST_STATIC_TYPE:
            return filterValue.length > 0 && value != '' ?  (filterValue.indexOf(value) !== -1 ? 1 : 0) : 1;
	  break;
	  case window.DATEFIELD:
            return 1;
	  break;
	  default:
            return value !== '' && filterValue !=='' && filterValue !== null ? (filterValue.localeCompare(value) !== -1 ? 1 : 0): 1;
	  break;
  }
}

const getFilteredIndex = (tempLabelIds, tempLabelElementDetails, tempElementWithFilters, tempElementWithTypes) =>{
  let labelId = tempLabelIds.length > 0 ? tempLabelIds[0] : 0;
  let singleLabelDetails = tempLabelElementDetails[labelId] !== undefined ? tempLabelElementDetails[labelId] : [];
  return singleLabelDetails.map((key, index)=>{
   return tempLabelIds.map(id=>{ return tempElementWithTypes[id]  !== undefined && tempElementWithFilters[id] !== undefined ?
     smallFuncToFilterAccType(tempElementWithTypes[id], tempLabelElementDetails[id][index], tempElementWithFilters[id])
     : 1 }).indexOf(0) === -1 ? index : -1;
   }).filter(key=>{ return key !== -1 });
}

const commonFuncGetOnlyGivenIndex = (ids, details, indexes) =>{
   let resDetails = CommonAggregationFunc.arrayOfIdsToObj(ids);
 if(indexes.length > 0){
  indexes.map(index=>{ ids.map(id=>{ resDetails[id].push(details[id][index]) })});
  return resDetails;
 }else{
  return resDetails;
 }
}

const getAggrAndFilterWithOutDataSave = () =>{
  let valueAggregation = {};
  let setObj = {};
  let tempElementWithFilters = {};
  let tempElementWithTypes = {};
  let tempLabelElementDetails = replaceElementBySelectedOption(labelIds, labelObj, Object.assign({}, labelElementDetails));
  let labelIsList = labelIds.filter(id=>{ return labelObj[id]['islist'] !== undefined && parseInt(labelObj[id]['islist']) === 1}).length > 0 ? 1 : 0;
  labelIds.map(key=>{
    tempElementWithFilters[key] = getFilterSelectedValue(elementWithType[key], labelObj[key]['filter'], parseInt(labelIsList) === 1 ? 0 : 1)
    tempElementWithTypes[key] = labelObj[key]['type']
  });
  let indexes = getFilteredIndex(labelIds, tempLabelElementDetails, tempElementWithFilters, tempElementWithTypes);
	valueIds.map(key => valueAggregation[key] = valueObj[key]['value_settings']);
	let labelValueData = getLabelValueData({labelIds: labelIds, labelObj: labelObj, labelElementDetails: parseInt(labelIsList) !== 1 ?
	commonFuncGetOnlyGivenIndex(labelIds, tempLabelElementDetails, indexes) :  getSubListOfList(labelIds, subListData, CommonAggregationFunc.arrayOfIdsToObj(labelIds), tempElementWithFilters), valueIds: valueIds, valueElementDetails: parseInt(labelIsList) !== 1 ? commonFuncGetOnlyGivenIndex(valueIds, valueElementDetails, indexes) : valueElementDetails, valueAggregation: valueAggregation, subListData: subListData});
        setObj['labelData'] = labelValueData['resLabelElementDetails'];
        setObj['valueData'] = labelValueData['resValueElementDetails'];
	setObj['showChart'] = 1;
        setState({...state, ...setObj});
}
const switchForDateType = (displayType, date) =>{
  const day = ['Monday', 'Tuesday', 'Wednesday' , 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const Month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  let dateObj = new Date(date);
  switch(parseInt(displayType)){
	  case window.CUSTOM_REPORT_DAY:
           return day[dateObj.getDay()];
		  break;
	  case window.CUSTOM_REPORT_MONTH:
           return Month[dateObj.getMonth()];
		  break;
	  case window.CUSTOM_REPORT_YEAR:
           return dateObj.getFullYear();
		  break;
	  default:
	  return (dateObj.getDate() + ' ' + Month[dateObj.getMonth()]) + ' (' + dateObj.getFullYear()+ ')';
	  break;

  }
}

const replaceAccordingToEleType = (type, valueArr, displayType) =>{
 switch(parseInt(type)){
	 case window.DATEFIELD:
         return valueArr.map(value=>{ return  value ? switchForDateType(displayType, value) : null })
	 break;
	 default:
	 return valueArr;
	 break;
 }
}

const replaceElementBySelectedOption = (tempLabelIds, tempLabelObj, tempLabelElementDetails) =>{
   if(tempLabelIds.length > 0){
     tempLabelIds.map(id=>{ tempLabelElementDetails[id] = replaceAccordingToEleType(tempLabelObj[id]['type'] , tempLabelElementDetails[id], tempLabelObj[id]['filter']) });
     return tempLabelElementDetails;
   }else{
   return tempLabelElementDetails;
   }
}

async function getAllElementDetailsWithDates(){
  let result = {};
  await datasave.service(window.GET_ALL_ELEMENT_SUBMIT_DETAILS + '/' + (props.webformId !== undefined ? props.webformId : props.match.params.webformId) , 'GET').then(
    async response => {
	    if(response['status'] == 200){
		    result = response['data'];
	    //setState({...state, ...{completeWebformDetails: response['data']}});
	    }else{
	    OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
	    }
    }
  )
  return result;
}
async function getSelectedElementSubmitDetails(dataObj, setObj){
  const {labelIds, valueIds, elementWithType, fromDate, toDate, labelObj, valueObj, dateFieldFilter, subListData} = dataObj;
  let elementWithFilters = {};
  let elementIds = await [...new Set(valueIds.concat(labelIds))].map(key=>{
      if(labelIds.indexOf(key) !== -1){
        elementWithFilters[key] = getFilterSelectedValue(elementWithType[key], labelObj[key]['filter'], 0);
      }
      return key;});
  let data = { webform_id: props.webformId !== undefined ? props.webformId : webformId, webelements: elementIds,
     webelements_with_types: elementWithType, webelements_with_filters: elementWithFilters,
   fromDate:  fromDate, toDate: toDate, dateFieldFilter: dateFieldFilter};
  await datasave.service(window.GET_CUSTOM_ELEMENT_DETAILS, 'POST', data).then(
    async response => {
      if(response['status'] == 200){
	let chartValueAggregate = {};
	valueIds.map(key=>{ chartValueAggregate[key] = valueObj[key]['value_settings'] });
        dataObj['elementIds'] = elementIds;
        dataObj['elementWithFilters'] = elementWithFilters;
        let elementDetails = Object.keys(response['data']).length > 0 ?
         await getElementDetails(Object.keys(response['data']), response['data'], dataObj) : {};
         setObj['submitDetails'] = response['data'];
         setObj['elementDetails'] = elementDetails['resultElementDetails'] !== undefined ? elementDetails['resultElementDetails'] : {};
	 setObj['originElementDetails'] = setObj['elementDetails'];
         setObj['labelElementDetails'] = elementDetails['labelElementDetails'] !== undefined ? elementDetails['labelElementDetails'] : {};
         setObj['valueElementDetails'] = elementDetails['valueElementDetails'] !== undefined ? elementDetails['valueElementDetails'] : {};
	 setObj['originalLabelElementDetails'] = setObj['labelElementDetails'];
	 setObj['originalValueElementDetails'] = setObj['valueElementDetails'];
	 setObj['showChart'] = 1;
         let labelValueData = getLabelValueData({labelIds: labelIds, valueIds: valueIds, labelElementDetails: replaceElementBySelectedOption(labelIds, labelObj, Object.assign({}, setObj['labelElementDetails'])), valueElementDetails: setObj['valueElementDetails'], valueAggregation: chartValueAggregate, labelObj: labelObj, subListData: subListData});
	 setObj['labelData'] = labelValueData['resLabelElementDetails'];
	 setObj['valueData'] = labelValueData['resValueElementDetails'];
	 setObj['originalLabelData'] = setObj['labelData'];
	 setObj['originalValueData'] = setObj['valueData'];
	 setObj['callElementDataSave'] = 0;
        setState({...state, ...setObj});
      }else{
        setObj['showChart'] = 0;
	 setObj['callElementDataSave'] = 0;
        setState({...state, ...setObj});
        OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
      }
    });
}


const getElementDetails = async(submitIds, submitDetails, dataObj) =>{
	const {labelIds, valueIds, elementIds, elementWithType, elementWithFilters, labelObj, valueObj, subListData, dateFieldFilter} = dataObj;
  let resultElementDetails = CommonAggregationFunc.arrayOfIdsToObj(elementIds);
  let labelElementDetails = CommonAggregationFunc.arrayOfIdsToObj(labelIds);
  let valueElementDetails = CommonAggregationFunc.arrayOfIdsToObj(valueIds);
  let labelIsList = labelIds.filter(id=>{ return labelObj[id]['islist'] !== undefined && parseInt(labelObj[id]['islist']) === 1}).length > 0 ? 1 : 0;
  if(submitIds.length > 0){
    await submitIds.map( async key=>{
     const webElementObj =  labelIsList !== 1 ? await applyFilterAccordingToType(submitDetails[key]['webelementobj'], elementWithType, elementWithFilters) : submitDetails[key]['webelementobj'];
      if(Object.keys(webElementObj).length > 0){
        await (elementIds).map(id=>{
          let value = webElementObj[id] !== undefined ? webElementObj[id]['value'] : '';
          const type = elementWithType[id];
          const listId = labelIds.indexOf(id) !== -1 ? labelObj[id]['list_id'] : valueObj[id]['list_id'];
          value = implodeAccordingToType(type, value, listId, subListData);
          resultElementDetails[id].push(value);
          if(labelIds.indexOf(id) !== -1 && parseInt(labelIsList) !== 1){
            labelElementDetails[id].push( value ? value : null );
          }
	  if(valueIds.indexOf(id) !== -1 ){
            valueElementDetails[id].push(parseInt(labelIsList) !== 1 ?  (!isNaN(parseInt(value)) ?  parseInt(value) : 0) : value);
          }
        })
      }
    })
  }

  return {resultElementDetails:resultElementDetails, labelElementDetails: parseInt(labelIsList) !== 1 ? labelElementDetails : getSubListOfList(labelIds, subListData, labelElementDetails, elementWithFilters) , valueElementDetails: valueElementDetails}
}

const getSubListOfList = (labelIds, subListData, labelElementDetails, elementWithFilters) =>{
	labelIds.map(id=>{
              labelElementDetails[id] = Object.keys(subListData[id]).map(id2=>{ return (elementWithFilters[id] !== undefined && elementWithFilters[id].length === 0) || (elementWithFilters[id].indexOf(parseInt(id2)) !== -1) ? subListData[id][id2]['name'] : '' }).filter(key=>{ return key !== ''})
            });

	return labelElementDetails;
   }

 const applyFilterAccordingToType = async (webElementObj, elementWithType, elementWithFilters) =>{
     let result = await Object.keys(elementWithFilters).map(key=>{
     let filterValue = elementWithFilters[key];
     let type = parseInt(elementWithType[key]);
     let value = webElementObj[key] !== undefined ? webElementObj[key]['value'] : undefined
     if(type === window.RADIO_BUTTON || type === window.CHECKBOX || type === window.LIST){
       if(value !== undefined && filterValue !== undefined && filterValue.length > 0){
         return filterValue.map(key=>{ return value.indexOf(key) !== -1 ? 1 : 0; }).indexOf(1) !== -1 ? 1 : 0;
       }else{
         return 1;
       }
     }else{
       if(filterValue !== null && filterValue.length > 0 ){
         return filterValue === value ? 1 : 0;
       }else{
         return 1;
       }
     }
   });
   return result.indexOf(0) !== -1 ? {} : webElementObj;
 }


const implodeAccordingToType = (type, value, listId, subListData) =>{
 switch(parseInt(type)){
   case window.LIST: case window.CHECKBOX:
   case window.RADIO_BUTTON:
   let subLists = subListData[listId] !== undefined ? subListData[listId] : {};
   if(value.length > 0 && Object.keys(subLists).length > 0){
   return value.map(key=> {return subLists[key] !== undefined && subLists[key]['name'] !== undefined ? subLists[key]['name'] :''}).join();
   }else{ return ''; }
    break;
    case window.LIST_ORGANISATIONAL_UNITS:
    return value.join();
    break;
    default
			 :
    return value;
    break;
 }
}



const handleSave = () =>{
  if(chartName.length > 0 && valueIds.length > 0 && labelIds.length > 0){
    let data = {id: props.id !== undefined ? props.id : id, chartName: chartName,
     webformId: props.webformId !== undefined ? props.webformId : webformId, labelIds: labelIds, labelObj: labelObj,
     valueIds: valueIds, valueObj: valueObj, dateFieldFilter: dateFieldFilter, dateChoice: dateChoice,
     fromDate: fromDate, toDate: toDate, dateSelect: dateSelect, showChart: showChart, showTable: showTable,
     showGraph: showGraph, total: total, chart_details: {chartType: chartType, chartTitle: chartTitle, chartXTitle: chartXTitle,
     chartYTitle: chartYTitle}, labelFilterSelect: labelFilterSelect, lockFilter: lockFilter };
    datasave.service(window.INSERT_CUSTOM_REPORT, 'POST', {'data':data}).then(
      async response => {
        if(response['status'] == 200){
          setId(response['data']);
          OCAlert.alertSuccess('Saved successfully', { timeOut: window.TIMEOUTNOTIFICATION });
         // setId(id);
          // setTimeout(() => { window.close(); }, 500);
      //    props.history.push("/reports?q=Webform_report");
        }else{
          OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
        }
      });
  }else{
    OCAlert.alertError(chartName.length > 0 ?'Please select label and value' : 'Please enter the chart name', { timeOut: window.TIMEOUTNOTIFICATION });
  }
}
  const handleAciveTab = (name ,value) =>{
    setState({...state, ...{[name]: parseInt(value)}});
  }

  const arrangeIds = (id, targetId, idsArray) =>{
    id = parseInt(id);
    targetId = parseInt(targetId);
    let idIndex = idsArray.indexOf(id);
    let targetIdIndex = idsArray.indexOf(targetId);
    idsArray.splice(idIndex, 1);
        if(targetIdIndex !== 0){
          idsArray.splice(targetIdIndex, 0, id);
        }else{
          idsArray.unshift(id);
        }
      return idsArray;
  }
  const getFieldForm = () =>{
    return (
      <FieldForm
      state = {state}
      setState = {setState}
      count = {count}
      activeTab = {activeTab}
      webformId = {props.webformId !== undefined ? props.webformId : webformId}
      setWebformId = {setWebformId}
      setCount = {setCount}
      arrangeIds = {arrangeIds}
      />
    );
  }

  const getChartForm = () =>{
    if(parseInt(activeTab) === 1){
      return(
      <ChartForm
        state = {state}
        setState = {setState}
        activeTab = {activeTab}
        webformId = {props.webformId !== undefined ? props.webformId : webformId}
        handleSave = {handleSave}
        arrangeIds = {arrangeIds}
        getSelectedElementSubmitDetails = {getSelectedElementSubmitDetails}
	getAggrAndFilterWithOutDataSave = {getAggrAndFilterWithOutDataSave}
        disableFields = {props.disableFields}
      />);
    }
  }

return (
    <div className='container py-10'>
    {status ?
      <div>
      {props.disableFields === undefined &&<Reactbootstrap.Tabs  activeKey={activeTab} onSelect={(k) => handleAciveTab('activeTab', k)}>
       <Reactbootstrap.Tab eventKey={0} title="Field">
      {getFieldForm()}
      </Reactbootstrap.Tab>
      <Reactbootstrap.Tab eventKey={1} title="Chart">
      {getChartForm()}
      </Reactbootstrap.Tab>
      </Reactbootstrap.Tabs>}
      {props.disableFields !== undefined && getChartForm()}
      </div>
      : <div>{'....Loading'}</div>}
      </div>
  );





}
export default translate(MainCustomWindow)
