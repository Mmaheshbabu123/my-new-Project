import React, { useState, useEffect, } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import WebElementDragAndDrop from './WebElementDragAndDrop';
import ListDragAndDrop from './ListDragAndDrop';
import CheckBox from '../../CheckBox.js';
import MultiSelect from './../../_components/MultiSelect';
import { GithubPicker } from 'react-color';
import { translate } from '../../language';
import './customreports.css';


const AggreagationOptions = [
  { label: 'Sum', value: window.SUM },
  { label: 'Average', value: window.AVERAGE },
  { label: 'Median', value: window.MEDIAN },
  { label: 'Min', value: window.MIN },
  { label: 'Max', value: window.MAX },
  { label: 'Count', value: window.COUNT },
  { label: 'Standard deviation', value: window.STANDARD_DEVIATION },
  { label: 'Product', value: window.PRODUCT }
];


let orderLabelId = 0;
let elementDrag = 0;

const FieldForm = props => {
  const t = props.t;
  const { state, setState, webformId, setWebformId, count, arrangeIds } = props;
  const { subListData, listData, labelIds, valueIds, labelObj, valueObj, elementWithType, showChart, callElementDataSave, elementOrList, searchText } = state;


  const onDragStart = (e, elementObj) => {
    e.dataTransfer.setData("elementObj", JSON.stringify(elementObj));
    elementDrag = 1;
  }

  const onDragEnd = () => {

  }
  const allowDropLabel = (e) => {
    e.preventDefault();
    if (parseInt(elementDrag) === 1) {
      return true;
    } else {
      return false;
    }
  }

  const allowDropValue = (e) => {
    e.preventDefault();
    if (parseInt(elementDrag) === 1) {
      return true;
    } else {
      return false;
    }
  }

  const onDropLabel = (e) => {
    e.preventDefault();
    if (parseInt(elementDrag) === 1) {
      let data = JSON.parse(e.dataTransfer.getData("elementObj"))
      elementDrag = 0;
      if (parseInt(elementOrList) === 0) {
        commonDropLabValFunc(1, data);
      } else {
        dropedListAsLabel(data);
      }
    }
  }

  const dropedListAsLabel = (data) => {
    if (data !== undefined && data['value'] !== undefined) {
      let tempLabelObj = Object.assign({}, labelObj);
      let tempLabelIds = labelIds;
      let tempElementWithType = Object.assign({}, elementWithType);
      let type = parseInt(data['type']);
      let id = parseInt(data['value']);
      tempLabelObj[id] = {
        id: id,
        name: data['label'],
        typename: '',
        type: type,
        webform_id: props.webformId,
        list_id: id,
        custom_name: data['label'],
        filter: [],
        only_filter: 0,
        lock: 0,
        value_settings: '',
        color: '',
        hide_from_graph: 0,
        label: 1,
        islist: 1
      }
      tempLabelIds.push(id);
      tempElementWithType[id] = type;
      let setObj = { labelIds: tempLabelIds, labelObj: tempLabelObj, elementWithType: tempElementWithType, showChart: 0, callElementDataSave: 1 };
      setState({ ...state, ...setObj });
    }
  }
  const onDropValue = (e) => {
    e.preventDefault();
    if (parseInt(elementDrag) === 1 && parseInt(elementOrList) === 0) {
      let data = JSON.parse(e.dataTransfer.getData("elementObj"));
      elementDrag = 0;
      commonDropLabValFunc(0, data);
    } else {
      elementDrag = 0;
    }
  }

  const commonDropLabValFunc = (labelOrValue, data) => {
    labelOrValue = parseInt(labelOrValue);
    let ids = labelOrValue === 1 ? labelIds : valueIds;
    let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
    let labValIdsKeyName = labelOrValue === 1 ? 'labelIds' : 'valueIds';
    let labeValObjKeyName = labelOrValue === 1 ? 'labelObj' : 'valueObj';
    let tempElementWithType = Object.assign({}, elementWithType);
    if (data !== undefined && data !== {} && labelValueObj[data['id']] === undefined) {
      let elementId = data['id'];
      let type = parseInt(data['type']);
      let filterValue = labelOrValue === 1 && (type === window.LIST || type === window.CHECKBOX || type === window.RADIO_BUTTON ||
        type === window.CHECKBOX) ? [] : '';
      ids.push(elementId);
      labelValueObj[elementId] = {
        id: elementId,
        name: data['name'],
        typename: data['typename'],
        type: type,
        webform_id: data['webform_id'],
        list_id: data['list_id'],
        custom_name: data['name'],
        filter: filterValue,
        only_filter: 0,
        lock: 0,
        value_settings: labelOrValue === 1 ? '' : (window.NUMERICFIELD === type || window.DECIMALFIELD === type) ? window.SUM : window.COUNT,
        color: '',
        hide_from_graph: 0,
        label: labelOrValue,
        islist: 0
      }
      tempElementWithType[elementId] = type;
      let setObj = { [labValIdsKeyName]: ids, [labeValObjKeyName]: labelValueObj, elementWithType: tempElementWithType, showChart: 0, callElementDataSave: 1 };
      setState({ ...state, ...setObj });
    }
  }

  const getSelectedValueTable = () => {
    return (<reactbootstrap.Table>
      <thead>
        <tr>
          <th>{t('Values (y-axis)')}</th>
          <th>{t('Custom value name')}</th>
          <th>{t('Value settings')}</th>
          <th>{t('Color')}</th>
          <th>{t('Hide from graph')}</th>
          <th>{t('Delete')}</th>
        </tr>
      </thead>
      <tbody>
        {getSelectValueElements()}
      </tbody>
    </reactbootstrap.Table>);
  }

  const getSelectValueElements = () => {
    return valueIds.map(key => {
      return (<tr id={key} draggable="true" onDrop={(e) => { onDropOrder(e, 0) }} onDragOver={(e) => dragOverOrder(e)} onDragStart={(e) => dragStartOrder(e)} >
        <td><p style={{ margin: '0px', padding: '0px' }}>{t(valueObj[key]['name'])}</p><p style={{ margin: '0px', padding: '0px' }}>({t(valueObj[key]['typename'])})</p></td>
        <td>{getInputBox('custom_name', valueObj[key]['custom_name'], key, 0, 0)}</td>
        <td>{getDropDownField('value_settings', valueObj[key]['value_settings'], AggreagationOptions, 0, key, 0, 1)}</td>
        <td>{getColorPicker('color', valueObj[key]['color'], key, 0)}</td>
        <td>{getCheckBox('hide_from_graph', valueObj[key]['hide_from_graph'], key, 0)}</td>
        <td onClick={(e) => handleDelete(0, key)}>{t('Delete')}</td>
      </tr>)
    })
  }


  const getSelectedLabelTable = () => {
    return (<reactbootstrap.Table>
      <thead>
        <tr>
          <th>{t('Labels (x-axis)')}</th>
          <th>{t('Custom label name')}</th>
          <th>{t('Filter')}</th>
          <th>{t('Only filter')}</th>
          <th>{t('Lock')}</th>
          <th>{t('Delete')}</th>
        </tr>
      </thead>
      <tbody>
        {getSelectLabelElements()}
      </tbody>
    </reactbootstrap.Table>);
  }


  const dragStartOrder = (e) => {
    e.dataTransfer.setData("orderElementId", e.currentTarget.id); // Thanks to bqlou for their comment.
    e.dataTransfer.dropEffect = "move";
  }




  const dragOverOrder = (e, labelOrValue) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  }

  const onDropOrder = (e, labelOrValue) => {
    if (parseInt(elementDrag) === 0) {
      labelOrValue = parseInt(labelOrValue);
      let labelValueIds = JSON.parse(JSON.stringify(labelOrValue === 1 ? labelIds : valueIds));
      let labValIdsKeyName = labelOrValue === 1 ? 'labelIds' : 'valueIds';
      let orderLabelId = e.dataTransfer.getData("orderElementId");
      labelValueIds = arrangeIds(orderLabelId, e.currentTarget.id, labelValueIds);
      setState({ ...state, ...{ [labValIdsKeyName]: labelValueIds } });
    }
  }

  const getFilterFieldAccordingToType = (type, name, value, options, key, labelOrValue, hideChart) => {
    switch (type) {
      case window.LIST: case window.CHECKBOX: case window.RADIO_BUTTON:
      case window.CHECKBOX: case window.LIST_STATIC_TYPE:
        return getMultiSelectDropDown(name, value, options, key, hideChart);
        break;
      case window.DATEFIELD:
        return getDropDownField(name, value, window.CUSTOM_REPORT_DATEFIELD_OPTION, 1, key, labelOrValue, hideChart);
        break;
      default:
        return getInputBox(name, value, key, labelOrValue, hideChart);
        break;
    }
  }
  const getSelectLabelElements = () => {
    return labelIds.map(key => {
      let type = parseInt(labelObj[key]['type']);
      return (<tr id={key} draggable="true" onDrop={(e) => { onDropOrder(e, 1) }} onDragOver={(e) => dragOverOrder(e)} onDragStart={(e) => dragStartOrder(e)}>
        <td><p style={{ margin: '0px', padding: '0px' }}>{labelObj[key]['name'] + ' '}</p>{labelObj[key]['typename'] !== '' && <p style={{ margin: '0px', padding: '0px' }}>({t(labelObj[key]['typename'])})</p>}</td>
        <td>{getInputBox('custom_name', labelObj[key]['custom_name'], key, 1, 0)}</td>
        <td accessKey={key}>{getFilterFieldAccordingToType(type, 'filter', labelObj[key]['filter'], getListOptions(labelObj[key]['list_id']), key, 1, 1)}</td>
        <td>{getCheckBox('only_filter', labelObj[key]['only_filter'], key, 1)}</td>
        <td>{getCheckBox('lock', labelObj[key]['lock'], key, 1)}</td>
        <td onClick={(e) => handleDelete(1, key)}>{t('Delete')}</td>
      </tr>)
    })
  }

  //--------- common tag fields and functions --------------

  const getListOptions = (listId) => {
    let subListObj = subListData[listId] !== undefined ? subListData[listId] : {};
    let subListIds = Object.keys(subListObj);
    if (subListIds.length > 0) {
      return subListIds.map(key => {
        return { value: subListObj[key]['id'], label: subListObj[key]['name'] };
      })
    } else {
      return [];
    }

  }
  const getMultiSelectDropDown = (name, value, optionData, id, hideChart) => {
    return <MultiSelect
      options={optionData}
      standards={value}
      isMulti={true}
      style={{ width: "100%" }}
      handleChange={(e) => handleMultiSelect(name, e, id, hideChart)}
    />
  }
  const handleColorChange = (name, value, id) => {
    let tempValueObj = Object.assign({}, valueObj);
    tempValueObj[id][name] = value;
    setState({ ...state, ...{ valueObj: tempValueObj } });
  }
  const getColorPicker = (name, value, id, labelOrValue) => {
    return <input type="color" value={value} onChange={(e) => handleColorChange(name, e.target.value, id)} />
  }

  const handleMultiSelect = (name, value, id, hideChart) => {
    let tempLabelObj = Object.assign({}, labelObj);
    tempLabelObj[id][name] = value;
    setState({ ...state, ...{ labelObj: tempLabelObj, showChart: parseInt(hideChart) === 1 ? 0 : showChart } });
  }


  const getInputBox = (name, value, id, labelOrValue, hideChart) => {
    return <input type={'text'} value={value} onChange={(e) => handleInputField(name, e.target.value, id, labelOrValue, hideChart)} />
  }

  const handleInputField = (name, value, id, labelOrValue, hideChart) => {
    if (parseInt(id) !== 0) {
      labelOrValue = parseInt(labelOrValue);
      let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
      let labeValObjKeyName = labelOrValue === 1 ? 'labelObj' : 'valueObj';
      labelValueObj[id][name] = value;
      setState({ ...state, ...{ [labeValObjKeyName]: labelValueObj, showChart: parseInt(hideChart) === 1 ? 0 : showChart } });
    } else {
      setState({ ...state, ...{ [name]: value } });
    }
  }
  const handleRadio = (name, value) => {
    setState({ ...state, ...{ [name]: value } });
  }
  const getRadioButton = (label, name, value, checkValue) => {
    return (<label>{label}<input type="radio" checked={parseInt(value) === parseInt(checkValue) ? true : false} onChange={(e) => handleRadio(name, checkValue)} /></label>);
  }
  const getCheckBox = (name, value, id, labelOrValue) => {
    return <div>
      <CheckBox
        tick={parseInt(value) === 1 ? true : false}
        onCheck={e => handleCheckBox(name, e.target.checked, id, labelOrValue)}
      /></div>;

  }

  const handleCheckBox = (name, value, id, labelOrValue) => {
    labelOrValue = parseInt(labelOrValue);
    let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
    let labeValObjKeyName = labelOrValue === 1 ? 'labelObj' : 'valueObj';
    labelValueObj[id][name] = value ? 1 : 0;
    setState({ ...state, ...{ [labeValObjKeyName]: labelValueObj } });
  }

  const getDropDownField = (name, value, optionData, needSelectOption, id, labelOrValue, hideChartTable) => {
    return (
      <select value={value} onChange={(e) => handleSingleSelectChange(name, e.target.value, id, labelOrValue, hideChartTable)}>
        {getOptions(optionData, needSelectOption)}
      </select>
    )
  }

  const getOptions = (optionValue, needSelectOption) => {
    let optionData = optionValue.map(key => {
      return <option value={key['value']}>{t(key['label'])}</option>
    });
    parseInt(needSelectOption) === 1 && optionData.unshift(<option value={0}>{t('---Select----')}</option>);
    return optionData;
  }

  const handleSingleSelectChange = (name, value, id, labelOrValue, hideChartTable) => {
    labelOrValue = parseInt(labelOrValue);
    let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
    let labeValObjKeyName = labelOrValue === 1 ? 'labelObj' : 'valueObj';
    labelValueObj[id][name] = value;
    setState({ ...state, ...{ [labeValObjKeyName]: labelValueObj, showChart: parseInt(hideChartTable) === 1 ? 0 : showChart } });
  }

  const handleDelete = (labelOrValue, id) => {
    labelOrValue = parseInt(labelOrValue);
    let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
    let tempElementWithType = Object.assign({}, elementWithType);
    let ids = labelOrValue === 1 ? labelIds : valueIds;
    let oppositeIds = labelOrValue === 1 ? valueIds : labelIds;
    let labValIdsKeyName = labelOrValue === 1 ? 'labelIds' : 'valueIds';
    let labeValObjKeyName = labelOrValue === 1 ? 'labelObj' : 'valueObj';
    delete labelValueObj[id];
    ids = ids.filter(key => { return parseInt(key) !== parseInt(id) })
    let setObj = { [labValIdsKeyName]: ids, [labeValObjKeyName]: labelValueObj, showChart: 0, callElementDataSave: 1 };
    if (ids.indexOf(parseInt(id)) === -1 && oppositeIds.indexOf(parseInt(id)) === -1) {
      delete tempElementWithType[id];
      setObj['elementWithType'] = tempElementWithType;
    }
    setState({ ...state, ...setObj });
  }


  return (
    <div className="container customreport-container">
      <div className="row">
        <div className='col-md-9'>
          <div id="div1" className="customreports" style={{ width: '815px', height: '300px', border: '3px solid grey', overflowY: "auto" }}
            droppable='true' onDragOver={(e) => allowDropLabel(e)} onDrop={(e) => onDropLabel(e)} >
            {getSelectedLabelTable()}
          </div>
          <div id="div2" className="customreports" style={{ width: '815px', height: '300px', border: '3px solid grey', overflowY: "auto" }}
            droppable='true' onDragOver={(e) => allowDropValue(e)} onDrop={(e) => onDropValue(e)} >
            {getSelectedValueTable()}
          </div>
        </div>
        <div className='col-md-3' style={{ float: 'right' }}>
          {getRadioButton('Elements', 'elementOrList', state['elementOrList'], 0)}
          {getRadioButton('Lists', 'elementOrList', state['elementOrList'], 1)}
          {state['elementOrList'] === 0 ?
            <div><WebElementDragAndDrop
              webformId={webformId}
              setWebformId={setWebformId}
              onDragStart={onDragStart}
              onDragEnd={onDragEnd}
              selectedWebElements={labelIds.filter(id => valueIds.includes(id))}
              edit={false}
              handleInputField={handleInputField}
              searchText={searchText} /></div> :
            <div><ListDragAndDrop
              listData={listData}
              onDragStart={onDragStart}
              onDragEnd={onDragEnd}
              handleInputField={handleInputField}
              searchText={searchText}
              selectedIds={labelIds}
            /></div>}
        </div>
      </div>
    </div>
  )
}


export default translate(FieldForm);
