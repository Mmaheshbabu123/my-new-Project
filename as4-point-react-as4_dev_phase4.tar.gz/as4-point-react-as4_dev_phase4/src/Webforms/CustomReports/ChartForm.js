import React, { useState, useEffect, } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import WebElementDragAndDrop from './WebElementDragAndDrop';
import CheckBox from '../../CheckBox.js';
import MultiSelect from './../../_components/MultiSelect';
import { reportFilter } from '../WebReports/CustomFilterFunctions';
import CommonChartComponent from './CommonChartComponent';
import Plot from 'react-plotly.js';
import TableComponent from './TableComponent';
import './customreports.css';
import { CommonAggregationFunc } from './CommonAggregationFunc';
import { translate } from '../../language';


const ChartForm = props => {
  const t = props.t;
  const { state, setState, arrangeIds,getToFromDateAccordingToDateSelect } = props;
  const { chartType, chartName, chartTitle, chartXTitle, chartYTitle, dateFieldFilter, dateSelect, showChart,
    showGraph, showTable, dateChoice, fromDate, toDate, elementDetails, labelElementDetails, valueElementDetails,
    labelIds, valueIds, labelObj, valueObj, quality_fiscal, orderBy, originalLabelElementDetails,
    originalValueElementDetails, originElementDetails, dateListOptions, labelFilterSelect, labelData,
    valueData, callElementDataSave, originalLabelData, originalValueData, total, lockFilter,dateListMinMaxObj } = state;

  const valueDetails = (data) => {
    return data.map(key => { return !isNaN(parseInt(key)) ? parseInt(key) : 0 });
  }

  const handleSort = async (sortColumn, sortDirection) => {
    const comparer = (a, b) => {
      if (sortDirection === "ASC") {
        return a[sortColumn] > b[sortColumn] ? 1 : -1;
      } else if (sortDirection === "DESC") {
        return a[sortColumn] < b[sortColumn] ? 1 : -1;
      }
    };
    if (sortDirection !== "NONE") {
      let resLabelData = {};
      let resValueData = {};
      let sortedRows = [...(arrangeTableRow(labelIds, labelData, valueIds, valueData, 0))].sort(comparer);
      let allDetails = sortedRows.length > 0 ? CommonAggregationFunc.arrayOfIdsToObj(Object.keys(sortedRows[0])) : {};
      await sortedRows.map(singleObj => { Object.keys(singleObj).map(key => { allDetails[key].push(singleObj[key]) }) });
      await Object.keys(allDetails).map(key => {
        if (key.indexOf('-') === -1) {
          if (labelIds.indexOf(parseInt(key)) !== -1) {
            resLabelData[key] = allDetails[key];
          } else {
            resValueData[key] = allDetails[key];
          }
        }
        else {
          key = parseInt((key.replace('-', '')).trim());
          resValueData[key] = allDetails[key];
        }
      })
      setState({ ...state, ...{ labelData: resLabelData, valueData: resValueData } });
    } else {
      setState({ ...state, ...{ labelData: originalLabelData, valueData: originalValueData } });
    }

  }
  const handleTextField = (name, value, setMethod) => {
    setState({ ...state, ...{ [name]: value } });
  }

  const handleRadioField = (name, value, hideChart) => {
    setState({ ...state, ...{ [name]: value } });
  }

  const handleCheckBox = (name, value) => {
    setState({ ...state, ...{ [name]: parseInt(value) } });
  }

  const handleDateField = (name, value, hideChart) => {
    setState({ ...state, ...{ [name]: value, showChart: parseInt(hideChart) === 1 ? 0 : showChart, callElementDataSave: parseInt(hideChart) === 1 ? 1 : callElementDataSave } });
  }

  const convertDateObjToString = (dateObj) => {
    let month = dateObj.getMonth() + 1;
    let fullYear = dateObj.getFullYear();
    let date = dateObj.getDate() * 10 >= 100 ? dateObj.getDate() : '0' + (dateObj.getDate());
    return fullYear + '-' + ((month * 10) >= 100 ? month : '0' + month) + '-' + date;
  }
  const handleSingleSelectChange = (name, value, setDate, hideChart) => {
    let setObj = { [name]: value, showChart: parseInt(hideChart) === 1 ? 0 : showChart, callElementDataSave: parseInt(hideChart) === 1 ? 1 : callElementDataSave };
    if (parseInt(setDate) === 1) {
      // let resFromToDate = parseInt(value) !== 0 ? reportFilter.dateFilterSwitch(value, quality_fiscal) : {};
      let resFromToDate = parseInt(value['value']) !== window.FROM_TO_DATE && Object.keys(value).length > 0 ?
      (parseInt(value['value']) === window.ALL ?
      getToFromDateAccordingToDateSelect(value['value'], dateFieldFilter['value'], dateListMinMaxObj, fromDate, toDate) :
      reportFilter.dateFilterSwitch(value['value'], quality_fiscal)) : {};
      let fromDate = resFromToDate['fromDate'] !== undefined &&
        resFromToDate['fromDate'] !== '' ? convertDateObjToString(resFromToDate['fromDate']) : '';
      let toDate = resFromToDate['toDate'] !== undefined &&
        resFromToDate['toDate'] !== '' ? convertDateObjToString(resFromToDate['toDate']) : '';
      setObj['fromDate'] = fromDate;
      setObj['toDate'] = toDate;
      setState({ ...state, ...setObj });
    } else {
      setState({ ...state, ...setObj });
    }
  }
  const handleMultiSelectChange = (name, id, value) => {
    let tempObj = Object.assign({}, state[name]);
    tempObj[id] = value;
    setState({ ...state, ...{ [name]: tempObj } });
  }



  const getTextField = (labelName, name, value) => {
    return (
      <div>
        <label>
          <div className="title-label">{t(labelName)}</div>
          <div className="input-field"><input type={'text'} value={value} onChange={(e) => handleTextField(name, e.target.value)} /></div>
        </label>
      </div>
    )
  }

  const getRadioField = (labelName, name, value, propsValue, hideChart) => {
    return <div>
      <label>
        <input type='radio' value={value} checked={parseInt(propsValue) === parseInt(value) ? true : false} onChange={(e) => handleRadioField(name, e.target.value, hideChart)} />
        {labelName}
      </label>
    </div>
  }

  const getCheckBox = (labelName, name, value) => {
    return <div>
      <label className="showtable-section">
        <div className="checkbox-label">{t(labelName)}</div>
        <CheckBox
          tick={parseInt(value) === 1 ? true : false}
          onCheck={e => handleCheckBox(name, e.target.checked ? 1 : 0)}
        />
      </label></div>;

  }
  const getDateField = (labelName, name, value, hideChart) => {
    return <div>
      <label>
        {t(labelName)}
        <input type='date' value={value} onChange={(e) => handleDateField(name, e.target.value, hideChart)} />
      </label>
    </div>
  }

  const getDropDownField = (labelName, name, value, optionData, needSelectOption, setDate, hideChart) => {
    return (<div className="row">
      <div className="col-md-4">{t(labelName)}</div>
      <div className="col-md-8">
        <select value={value} onChange={(e) => handleSingleSelectChange(name, e.target.value, setDate, hideChart)}>
          {getOptions(optionData, needSelectOption)}
        </select>
      </div>
    </div>
    )
  }

  const getOptions = (optionValue, needSelectOption) => {
    let optionData = optionValue.map(key => {
      return <option value={key['value']}>{t(key['label'])}</option>
    });
    parseInt(needSelectOption) === 1 && optionData.unshift(<option value={0}>{t('---Select----')}</option>);
    return optionData;
  }

  const getMultiSelectDropDown = (name, id, value, optionsData) => {
    return <div >
      <MultiSelect
        options={optionsData}
        standards={value}
        disabled={false}
        handleChange={(e) => handleMultiSelectChange(name, id, e)}
        placeholder={t('search')}
      /> </div>
  }

  const handleShowChart = (e) => {
    if (labelIds.length > 0 && valueIds.length > 0) {
      if ((fromDate === '' && toDate === '') || (fromDate !== '' && toDate !== '' && (new Date(toDate)).valueOf() >= (new Date(fromDate)).valueOf())) {
        parseInt(callElementDataSave) === 1 ? props.getSelectedElementSubmitDetails(state, {}) : props.getAggrAndFilterWithOutDataSave();
      } else {
        OCAlert.alertWarning(t('Please select valid from-to date'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    } else {
      OCAlert.alertWarning(t('Please select label and value'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
  }

  const onDragStartFunc = (e) => {
    e.dataTransfer.setData("chartOrderElementId", e.currentTarget.id);
    e.dataTransfer.dropEffect = "move";
  }

  const onDragOverFunc = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  }


  const onDropFunc = (e, labelOrValue) => {
    labelOrValue = parseInt(labelOrValue);
    let labelValueIds = JSON.parse(JSON.stringify(labelOrValue === 1 ? labelIds : valueIds));
    let labValIdsKeyName = labelOrValue === 1 ? 'labelIds' : 'valueIds';
    let orderLabelId = e.dataTransfer.getData("chartOrderElementId");
    labelValueIds = arrangeIds(orderLabelId, e.currentTarget.id, labelValueIds);
    setState({ ...state, ...{ [labValIdsKeyName]: labelValueIds } });
  }
  const arrangeTableRow1 = async (tempLabelIds, labelData, valueIds, valueData) => {
    let firstLabel = tempLabelIds.length > 0 ? labelData[tempLabelIds[0]] : [];
    let result = [];
    if (firstLabel.length > 0) {
      await firstLabel.map(async (key, index) => {
        let temp1 = {}; let temp2 = {};
        await tempLabelIds.map(id => { temp1[id] = labelData[id][index] })
        await valueIds.map(id => {
          if (tempLabelIds.indexOf(id) !== -1) {
            temp2[id + '-'] = valueData[id][index]
          } else {
            temp2[id] = valueData[id][index]
          }
        });
        result.push({ ...temp1, ...temp2 });
      });
      return result;
    } else {
      return [];
    }
  }
  const arrangeTableRow = (tempLabelIds, labelData, valueIds, valueData, includeTotal) => {
    let firstLabel = tempLabelIds.length > 0 ? labelData[tempLabelIds[0]] : [];
    let result = [];
    if (firstLabel.length > 0) {
      let valueTotal = {};
      let labelTotal = {};
      tempLabelIds.map(id => { return labelTotal[id] = 'Total' });
      firstLabel.map((key, index) => {
        let temp1 = {}; let temp2 = {};
        tempLabelIds.map(id => { temp1[id] = labelData[id][index] })
        valueIds.map(id => {
          if (tempLabelIds.indexOf(id) !== -1) {
            temp2[id + '-'] = valueData[id][index]
            valueTotal[id + '-'] = (valueTotal[id + '-'] !== undefined ? parseInt(valueTotal[id + '-']) : 0) + valueData[id][index]
          } else {
            temp2[id] = valueData[id][index]
            valueTotal[id] = (valueTotal[id] !== undefined ? parseInt(valueTotal[id]) : 0) + valueData[id][index]
          }
        });
        result.push({ ...temp1, ...temp2 });
      });
      if (parseInt(includeTotal) === 1 && parseInt(total) === 1) {
        result.push({ ...labelTotal, ...valueTotal });
      }
      return result;
    } else {
      return [];
    }
  }
  const aggNameSwitch = (agg) => {
    switch (agg) {
      case 'sum':
        return '(Sum)';
        break;
      case 'avg':
        return '(Avg)';
        break;
      case 'median':
        return '(Median)';
        break;
      case 'min':
        return '(Min)';
        break;
      case 'max':
        return '(Max)';
        break;
      case 'count':
        return '(Count)';
        break;
      default:
        return '(Sum)';
        break;
    }
  }
  const arrangeTableCol = (tempLabelIds, valueIds) => {
    return tempLabelIds.map(key => { return { key: key, name: labelObj[key]['custom_name'], sortable: true } }).concat(valueIds.map(key => { return { key: tempLabelIds.indexOf(key) === -1 ? key : key + '-', name: (valueObj[key]['custom_name'] + (t(aggNameSwitch(valueObj[key]['value_settings'])))) } }));
  }

  const arrangeOptionData = (data) => {
    return data.map(key => { return { label: key, value: key } });
  }
  const aggregateCallFunc = (dataObj, tempLabelIds, tempValueIds, chartValueAggregate, onlyFilterApplied) => {
    return parseInt(onlyFilterApplied) === 1 ? CommonAggregationFunc.getArrangedAggregatedData({ labelElementDetails: dataObj['resLabelElementDetails'], valueElementDetails: dataObj['resLabelElementDetails'], labelIds: tempLabelIds, valueIds: tempValueIds, valueAggregation: chartValueAggregate }) : dataObj;
  }
  const getFilteredDetails = (tempLabelIds, tempLabelElementDetails, tempLabelFilterSelect, tempValueIds, tempValueElementDetails) => {
    if (tempLabelIds.length > 0 && Object.keys(tempLabelFilterSelect).map(key => { return tempLabelFilterSelect[key].length > 0 ? 1 : 0 }).indexOf(1) !== -1) {
      let resLabelElementDetails = CommonAggregationFunc.arrayOfIdsToObj(tempLabelIds);
      let resValueElementDetails = CommonAggregationFunc.arrayOfIdsToObj(tempValueIds);
      Object.keys(tempLabelFilterSelect).map(key => { tempLabelFilterSelect[key] = tempLabelFilterSelect[key].map(value => { return value['value'] }) });
      let firstLabel = tempLabelElementDetails[tempLabelIds[0]];
      firstLabel.map((key, index) => {
        if (tempLabelIds.map(id => { return tempLabelFilterSelect[id] !== undefined && tempLabelFilterSelect[id].length > 0 ? (tempLabelFilterSelect[id].indexOf(tempLabelElementDetails[id][index]) !== -1 ? 1 : 0) : 1 }).indexOf(0) === -1) {
          tempLabelIds.map(id => { resLabelElementDetails[id].push(tempLabelElementDetails[id][index]) });
          tempValueIds.map(id => { resValueElementDetails[id].push(tempValueElementDetails[id][index]) });
        }
      })
      return { resLabelElementDetails: resLabelElementDetails, resValueElementDetails: resValueElementDetails };
    } else {
      return { resLabelElementDetails: tempLabelElementDetails, resValueElementDetails: tempValueElementDetails };
    }
  }



  const getChart = () => {
    let allElementIds = Object.keys(elementDetails).map(key => { return parseInt(key) });
    if (parseInt(showChart) === 1 && allElementIds.length > 0) {
      let allElementValues = [];
      let chartValueColor = [];
      let chartValueName = [];
      let chartValueAggregate = {};
      let tempValueIds = valueIds.filter(key => { return valueObj[key] !== undefined && valueObj[key]['hide_from_graph'] !== undefined && parseInt(valueObj[key]['hide_from_graph']) === 0 })
      let onlyFilterApplied = labelIds.map(key => { return parseInt(labelObj[key]['only_filter']) }).indexOf(1) !== -1 ? 1 : 0;
      tempValueIds.map(key => {
        chartValueColor.push(valueObj[key]['color']);
        chartValueName.push(valueObj[key]['custom_name']);
        chartValueAggregate[key] = valueObj[key]['value_settings']
      })
      let tempLabelIds = labelIds.filter(key => labelIds.length === 1 || parseInt(labelObj[key]['only_filter']) !== 1);
      let filteredDetails = getFilteredDetails(labelIds, labelData, Object.assign({}, labelFilterSelect), valueIds, valueData);
      filteredDetails = parseInt(onlyFilterApplied) !== 1 ? filteredDetails : CommonAggregationFunc.getArrangedAggregatedData({ labelIds: tempLabelIds, valueIds: valueIds, labelElementDetails: filteredDetails['resLabelElementDetails'], valueElementDetails: filteredDetails['resValueElementDetails'], valueAggregation: chartValueAggregate });
      let resLabelDetails = filteredDetails['resLabelElementDetails'];
      let resValueDetails = filteredDetails['resValueElementDetails'];
      let chartLabel = tempLabelIds.map(key => { return resLabelDetails[key] !== undefined ? resLabelDetails[key] : []; });
      let chartValue = tempValueIds.map(key => { return resValueDetails[key] !== undefined ? resValueDetails[key] : []; });
      return (
        <div className='Container'>
          <div className="row">
            {(parseInt(showChart) === 1 && (parseInt(showGraph) === 1 || parseInt(showTable) === 1)) && <div className="col-md-12">
              {labelIds.map(key => {
                return <div style={parseInt(lockFilter) === 1 ? { 'pointer-events': 'none' } : {}}>{getMultiSelectDropDown('labelFilterSelect', key, labelFilterSelect[key], arrangeOptionData(

                  [...new Set(labelData[key])]))}</div>
              })}
            </div>}
          </div>
          <div className="row" style={{ 'margin-bottom': '10px' }}>
            {(parseInt(showChart) === 1 && parseInt(showGraph) === 1) && <div className="col-md-12">
              <CommonChartComponent
                id={'chartFormPlot1'}
                chartType={chartType}
                chartLabel={chartLabel}
                chartValue={chartValue}
                chartValueName={chartValueName}
                chartValueColor={chartValueColor}
                chartValueAggregate={chartValueAggregate}
                chartTitle={chartTitle}
                chartXTitle={chartXTitle}
                chartYTitle={chartYTitle}
                sort={orderBy}
                style={{
                  width: '100%',
                  height: '100%'
                }}
              />
            </div>}
          </div>
          <div className="row">
            {(parseInt(showChart) === 1 &&
              parseInt(showTable) === 1) &&
              <div className="col-md-12" >
                {/* <div className = "row">
          <div className = "col-md-6">
          <ul>
          {labelIds.map(key=>{
            return <li id = {key} draggable="true" onDrop = {(e)=>onDropFunc(e, 1)} onDragOver={(e)=>onDragOverFunc(e)} onDragStart= {(e)=>onDragStartFunc(e)}>{labelObj[key]['custom_name']}</li>
          })}
          </ul>
          </div>
          <div className = "col-md-6">
          <ul>
          {valueIds.map(key=>{
            return <li id = {key} draggable="true" onDrop = {(e)=>onDropFunc(e, 0)} onDragOver={(e)=>onDragOverFunc(e)} onDragStart= {(e)=>onDragStartFunc(e)}>{valueObj[key]['custom_name']}</li>
          })}
          </ul>
          </div>
          </div>*/}
                <TableComponent
                  columns={arrangeTableCol(tempLabelIds, valueIds)}
                  rows={arrangeTableRow(tempLabelIds, resLabelDetails, valueIds, resValueDetails, 1)}
                  handleSort={handleSort}
                />
              </div>}
          </div>
        </div>);
    } else {
      return <div>{parseInt(showChart) === 1 && <h3>{t('No data')}</h3>}</div>
    }
  }



  const dateOption = Object.keys(window.DATE_DEFAULT_FILTER_KEY_LABEL).map(key => { return { 'label': window.DATE_DEFAULT_FILTER_KEY_LABEL[key], 'value': key } });
  return (
    <div className='container py-10' style={{ marginTop: '10px' }}>
      <div className='row'>
        <div className='col-md-3 filterbydate'>{getDropDownField('Filter by datefield', 'dateFieldFilter', dateFieldFilter, dateListOptions, 1, 0, 1)}</div>
        <div className='col-md-6'>
          <div className="row">
            <div className='col-md-4'>
              {getRadioField('From - to date :', 'dateChoice', 0, dateChoice, 1)}
              {getRadioField('Filter by options :', 'dateChoice', 1, dateChoice, 1)}
            </div>
            <div className={'col-md-6'}>
              {parseInt(dateChoice) === 0 ? <div className="row">
                <div className="col-md-6">{getDateField('', 'fromDate', fromDate, 1)}</div>
                <div className="col-md-6">{getDateField('', 'toDate', toDate, 1)}</div>
              </div> :
                <div className="row">
                  <div className='col-md-12'>
                    <div className="filterbydate">{getDropDownField('', 'dateSelect', dateSelect, dateOption, 0, 1, 1)}</div>
                  </div>
                </div>}
            </div>
          </div>
        </div>
        <div className='col-md-2'>
          <reactbootstrap.Button onClick={(e) => handleShowChart(e)}>
            {t('Show chart')}
          </reactbootstrap.Button>
        </div>
        {props.disableFields === undefined && <div className='col-md-1'>
          <reactbootstrap.Button onClick={(e) => props.handleSave(e)}>
            {t('Save')}
          </reactbootstrap.Button>
        </div>}
      </div>
      {props.disableFields === undefined && <div className="row">
        <div className="col-md-3">
          {getTextField('Chart name', 'chartName', chartName)}
        </div>
        <div className="col-md-3 filterbydate" >
          {getDropDownField('Select chart', 'chartType', chartType, window.WEBFORMREPORTTYPES, 0, 0, 0)}
        </div>
        <div className="col-md-2">
          {getCheckBox('Show table', 'showTable', showTable)}
        </div>
        <div className="col-md-2">
          {getCheckBox('Show graph', 'showGraph', showGraph)}
        </div>
        <div className='col-md-2'>
          {getCheckBox('Total', 'total', total)}
        </div>
      </div>}
      {props.disableFields === undefined && <div className="row">
        <div className='col-md-3'>
          {getTextField('Title', 'chartTitle', chartTitle)}
        </div>
        <div className='col-md-3'>
          {parseInt(chartType) !== window.PIE_CHART_TYPE && getTextField('X-title', 'chartXTitle', chartXTitle)}
        </div>
        <div className='col-md-3'>
          {parseInt(chartType) !== window.PIE_CHART_TYPE && getTextField('Y-title', 'chartYTitle', chartYTitle)}
        </div>
        <div className='col-md-3'>
          {getCheckBox('Lock filter', 'lockFilter', lockFilter)}
        </div>
      </div>}
      {getChart()}
    </div>
  );

}

export default translate(ChartForm);
