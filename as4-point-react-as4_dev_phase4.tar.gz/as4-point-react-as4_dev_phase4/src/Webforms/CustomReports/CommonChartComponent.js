import React, { useState ,useEffect,} from 'react';
import * as Reactbootstrap from 'react-bootstrap'
import { datasave } from '../../_services/db_services'
import { translate } from '../../language'
import { OCAlert } from '@opuscapita/react-alerts'
import Plot from 'react-plotly.js';
const CommonChartComponent = props =>{
  const {chartType, chartTitle, chartXTitle, chartYTitle, chartLabel, chartValue, chartValueName, chartValueColor, chartValueAggregate, style, labelFilterSelect} = props;
  const [plotAttributes, setPlotAttributes] = useState({data:[], layout:{}, frames:[], chartType: '', status: false});
	useEffect(()=>{
    updateChartData();
  }, [chartType, chartTitle, chartXTitle, chartYTitle, chartValue, chartValueName, chartValueColor, chartValueAggregate, labelFilterSelect]);

   const updateChartData = () =>{
	   
     let tempPlotAttributes = Object.assign({}, plotAttributes);
      if(parseInt(plotAttributes['chartType']) !==  parseInt(chartType)){
       tempPlotAttributes['data'] = getDataAccordingToChartType(chartType);
       tempPlotAttributes['layout'] = getLayoutAccordingToTypeNew(chartType, chartLabel); 
       tempPlotAttributes['chartType'] = chartType;
       tempPlotAttributes['status'] = true;
       setPlotAttributes(tempPlotAttributes);
     }else{
       tempPlotAttributes['data'] = getDataAccordingToChartType(chartType);
       tempPlotAttributes['layout'] = Object.assign({}, getLayoutAccordingToChartType(chartType, tempPlotAttributes['layout'], chartLabel));
       tempPlotAttributes['status'] = true;
       setPlotAttributes(tempPlotAttributes);
     }
  }

const constructXYAxisData = (xAxisData, yAxisData, yAxisName, yAxisColor, yAxisAggregate, orientation, mode, type, stackgroup) =>{
    
    let xAxisValue = xAxisData.length === 1 ?  xAxisData[0] : xAxisData;
    let groups = xAxisData.length === 1 ? xAxisData[0] : xAxisData[1];
    let data =  yAxisData.map((key,index)=>{
        let trace = { x: orientation === 'v' ? xAxisValue : key, y: orientation === 'v' ? key : xAxisValue, type: type, name: yAxisName[index],
        marker: {color: yAxisColor[index]}, orientation: orientation, mode: mode,
      };
     /* if(xAxisData.length === 1){
        trace['transforms'] = [{type:'aggregate', groups: groups , aggregations: [{func: yAxisAggregate[index], target: orientation === 'v' ? 'y' : 'x', enabled:true}]}]
      }*/

      if(stackgroup == 1){
       trace['fill'] = 'tozeroy';
        //trace['stackgroup'] = 'one';
      }
        return trace  ;
    })
    return data;
  }

const constructPieTypeChartData = (chartLabel, chartValue, chartValueName, type) =>{
  chartLabel = chartLabel.length > 0 ? chartLabel[0] : chartLabel;
  chartValue = chartValue.length > 0 ? chartValue[0] : chartValue;
  chartValueName = chartValueName.length > 0 ? chartValueName[0] : chartValueName;
  if((chartValue.filter(key=>{ return key !== 0})).length > 0){
  return [{labels: chartLabel, values: chartValue, name: chartValueName, type: type, hoverinfo: 'label+percent+name'}];
  } else{  
  return [{labels: chartLabel, name: chartValueName, type: type, hoverinfo: 'label+percent+name'}];
  }
}

const constructGaugeChartdata = (chartLabel, chartValue, type) =>{
  chartLabel = chartLabel.length > 0 ? chartLabel[0] : chartLabel;
  chartValue = chartValue.length > 0 ? chartValue[0] : chartValue;

  let result = [];
  let row = 0;
  let column = 0;
  for(var i = 1; i <= chartLabel.length; i++){
     result.push({
         domain: { row: row, column:column },
         value: chartValue[i - 1],
         title: { text: chartLabel[i - 1]},
         type: type,
         mode: "gauge+number"
        });
     column++;
    if(i%2 === 0){
      row++;
      column = 0;
     }
  }
  return result;
}


const getDataAccordingToChartType = (chartType) =>{
  switch(parseInt(chartType)){
    case window.PIE_CHART_TYPE :
    return constructPieTypeChartData(chartLabel, chartValue, chartValueName, 'pie');
    break;
    case window.COL_CHART_TYPE :
    return constructXYAxisData(chartLabel, chartValue, chartValueName, chartValueColor, chartValueAggregate, 'h', 'markers', 'bar', 0);
    break;
    case window.BAR_CHART_TYPE :
    return  constructXYAxisData(chartLabel, chartValue, chartValueName, chartValueColor, chartValueAggregate, 'v', 'markers', 'bar', 0);
    break;
    case window.LINE_CHART_TYPE :
    return constructXYAxisData(chartLabel, chartValue, chartValueName, chartValueColor, chartValueAggregate, 'v', 'lines', 'scatter', 0);
    break;
    case window.AREA_CHART_TYPE :
    let data =  constructXYAxisData(chartLabel, chartValue, chartValueName, chartValueColor, chartValueAggregate, 'v', 'lines', 'scatter', 1);
    console.log('data');
    console.log(data);
		 return data;
		  break;
    case window.GAUGE_CHART_TYPE:
    return constructGaugeChartdata(chartLabel, chartValue, 'indicator'); 
    break;
    default:
    return [];
    break;
  }

  return
}

const getLayoutAccordingToTypeNew = (chartType, chartLabel) =>{
	
  switch(parseInt(chartType)){
    case window.PIE_CHART_TYPE : case window.TABLE_CHART_TYPE :
    return {title: chartTitle, hovermode: "closest", showlegend: true, legend:{"orientation": "h"}};
    break;
    case window.COL_CHART_TYPE : case window.BAR_CHART_TYPE : case window.LINE_CHART_TYPE :
    case window.AREA_CHART_TYPE :
    return {title:chartTitle, xaxis:{title:{text: chartXTitle}}, yaxis:{title:{text: chartYTitle}}, hovermode: "closest"};
    break;
    case window.GAUGE_CHART_TYPE:
    let rowsLength = chartLabel.length > 0 ? Math.ceil(chartLabel[0].length/2) : 0;
    return {grid:{rows: rowsLength, columns: 2}}
	    //, width: 600, height: 500};	  
    break;
    default:
    break;
  }
}
const getLayoutAccordingToChartType = (chartType, layout, chartLabel) =>{

  switch(parseInt(chartType)){
    case window.PIE_CHART_TYPE : case window.TABLE_CHART_TYPE :
    layout['title'] = chartTitle;
    return layout;
    break;
    case window.COL_CHART_TYPE : case window.BAR_CHART_TYPE : case window.LINE_CHART_TYPE :
    case window.AREA_CHART_TYPE :
    layout['xaxis']['title'] = {text:chartXTitle};
    layout['yaxis']['title'] = {text:chartYTitle};
    layout['title'] = chartTitle;
    return layout;
    break;
    case window.GAUGE_CHART_TYPE:
    let rowsLength = chartLabel.length > 0 ? Math.ceil(chartLabel[0].length/2) : 0;
    layout['grid'] = {rows: rowsLength, columns: 2};
   // layout['width'] = 600;
   // layout['height'] = 500;
    return layout;
    break;
    default:
    break;
    break;
  }
}

const handleRender = (e) =>{
  let tempPlotAttributes = Object.assign({}, plotAttributes);
  tempPlotAttributes['data'] = e['data'] !== undefined ? e['data'] : [];
  tempPlotAttributes['layout'] = e['layout'] !== undefined ? e['layout'] : [];
  tempPlotAttributes['frames'] = e['frames'] !== undefined ? e['frames'] : [];
  tempPlotAttributes['chartType'] = chartType;
  console.log('called');
	console.log(e);
  setPlotAttributes(tempPlotAttributes);
}

return (
  <div id ={props.id}>
    {plotAttributes['status'] ? <Plot
      data = {plotAttributes['data']}
      layout = {plotAttributes['layout']}
      frames = {plotAttributes['frames']}
      onUpdate = {(e)=>handleRender(e)}
      style = {style}
      divId = {props.id}
      /> : <div>{'...Loading'}</div>}
  </div>
)

}
export default CommonChartComponent;
