import ReactDataGrid from "react-data-grid-defaultvalue";
import React, { useState ,useEffect,} from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';

const TableComponent = props =>{
const grid = {};
const rowGetterFunc = (i, rows) =>{
return rows[i];
}

return (<div>
	 <ReactDataGrid
                 ref={(grid) => { grid = grid; }}
                 columns={props.columns}
                 rowGetter={i=>rowGetterFunc(i, props.rows)}
                 rowsCount={props.rows.length}
	         onGridSort={(sortColumn, sortDirection) => props.handleSort(sortColumn, sortDirection)}
	/>
	</div>)
}
export default TableComponent;
