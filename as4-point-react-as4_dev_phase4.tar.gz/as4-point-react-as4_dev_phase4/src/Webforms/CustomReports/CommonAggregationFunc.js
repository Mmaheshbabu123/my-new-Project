export const CommonAggregationFunc = {
getArrangedAggregatedData,
arrayOfIdsToObj
}

  function arrayOfIdsToObj(ids){ 
    let temp = {}; 
    ids.map(key=>{  temp[key] = []; }); 
    return temp;  
  } 

function median(numbers) {
    const sorted = numbers.slice().sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);

    if (sorted.length % 2 === 0) {
        return (sorted[middle - 1] + sorted[middle]) / 2;
    }

    return sorted[middle];
}
function numOr0(n, defaultVal){ return isNaN(n) ? defaultVal : n};
      
function sumFunc(data){
        return data.reduce((a, b)=>{ return numOr0(a, 0) + numOr0(b, 0)});
}
function productFunc(data){
        return data.reduce((a, b)=>{ return numOr0(a, 1) * numOr0(b, 1)});
}
function stdDev(data){
  let n = data.length;
  let mean = avgFunc(data);
  return Math.sqrt(data.map(x => Math.pow(x-mean,2)).reduce((a,b) => a+b)/n);
}


function avgFunc(data){
   return sumFunc(data)/data.length;
}
      function commonAggregationFunc(agg, data){
         switch(agg){
         case 'sum':
         return sumFunc(data);
         break;
	 case 'avg':
         return avgFunc(data);
         break;
	 case 'median':
	 return median(data);
	 break;
         case 'min':
	 return  Math.min(...data);
	 break;
	 case 'max':
	 return Math.max(...data);
	 break;
	 case 'count':
	 return data.length;
	 break;
         case 'stddev':
	 return stdDev(data);
	 break;
	 case 'product':
	 return productFunc(data); 
	 break;
         default:
         return sumFunc(data);
         break;
         }
        }

   function calcValueAggr(valueArr, paramObj){
     const {valueAggregation} = paramObj;
        return Object.keys(valueArr).map(key=>{
           return {key: key, value: commonAggregationFunc(valueAggregation[key], valueArr[key])};
        });
   }

    function arrangeAndCalc(data, paramObj){
    const {labelIds, labelElementDetails, valueIds, valueElementDetails} = paramObj;
    let labelData = arrayOfIdsToObj(labelIds);
    let valueData = arrayOfIdsToObj(valueIds);
    Object.keys(data).map(key=>{
     key.split('--').map((labVal, index)=>{labelData[labelIds[index]].push(labVal)});
     calcValueAggr(data[key], paramObj).map((valObj, index)=>{ valueData[valObj['key']].push(valObj['value'])});
    });
     return {resLabelElementDetails: labelData, resValueElementDetails: valueData};
    }

   function arrangeData(paramObj){
    const {labelIds, labelElementDetails, valueIds, valueElementDetails} = paramObj;
      let labelLength = labelIds.length > 0 ? (labelElementDetails[labelIds[0]]).length : 0;
      let dataObj = {};
      for(var i = 0; i < labelLength; i++){
        let keyName = labelIds.map(key=>{ return labelElementDetails[key][i]}).join('--');
        dataObj[keyName] = dataObj[keyName] !== undefined ? dataObj[keyName] : arrayOfIdsToObj(valueIds);
        valueIds.map(key=>{ dataObj[keyName][key].push(valueElementDetails[key][i]) });
       }
       return dataObj;
    }
  
  function generalizeValueWithLabelIsList(labelsValueKeyObj, valueArr){
	 console.log('labels');
	  console.log(labelsValueKeyObj);
	  console.log(valueArr);
	  valueArr.map(value=>{ 
		  if(labelsValueKeyObj[value] !== undefined){
		   labelsValueKeyObj[value].push(value);
		  }
	  })
	  return labelsValueKeyObj;
  }

   function arrangeAndCalcofIsList(paramObj){
   const {labelIds, labelElementDetails, valueIds, valueElementDetails, subListData, valueAggregation} = paramObj;
	   let labelData =  Object.assign({}, labelElementDetails);
	 let valueData =  arrayOfIdsToObj(valueIds);
         labelIds.map(labelId=>{
         valueIds.map(valueId=>{ valueData[valueId] = aggreagateIsList(generalizeValueWithLabelIsList(arrayOfIdsToObj(labelData[labelId]), valueElementDetails[valueId]), valueAggregation[valueId])})
	 })
	   return {resLabelElementDetails: labelData, resValueElementDetails: valueData};
   }
   function aggreagateIsList(labelsValueKeyObj, agg){
    return Object.keys(labelsValueKeyObj).map(key=>{ return commonAggregationFunc('count', labelsValueKeyObj[key])}) 
   }
   function getArrangedAggregatedData(paramObj, isList){
       const {labelIds, labelElementDetails, valueIds, valueElementDetails, subListData} = paramObj;
	   if(labelIds.length > 0 && Object.keys(labelElementDetails).length > 0 && valueIds.length > 0 && Object.keys(valueElementDetails).length > 0){
	if(parseInt(isList) === 0){
        return arrangeAndCalc(arrangeData(paramObj), paramObj);
	}else{
	 return arrangeAndCalcofIsList(paramObj);
        return {resLabelElementDetails: {}, resValueElementDetails: {}};	     
	}
	   }else{
           return {resLabelElementDetails: {}, resValueElementDetails: {}};	     
	   }
   }
