import React, { useState, useEffect, } from 'react';
import * as Reactbootstrap from 'react-bootstrap'
import { datasave } from '../../_services/db_services'
import { translate } from '../../language'
import { OCAlert } from '@opuscapita/react-alerts'
import Plot from 'react-plotly.js';
const CommonChartComponent = props => {
  const { chartType, chartTitle, chartXTitle, chartYTitle, chartLabel, chartValue, chartValueName, chartValueColor, chartValueAggregate, style, labelFilterSelect, labelIds, valueIds, activeTab, xLegendPos, yLegendPos, hideLegend } = props;
  const [plotAttributes, setPlotAttributes] = useState({
    data: [], layout: {}, frames: [], chartType: '', status: false, tempLabelIds: [],
    tempValueIds: []
  });
  useEffect(() => {
    updateChartData();
  }, [chartType, chartTitle, chartXTitle, chartYTitle, chartValue, chartValueName, chartValueColor, chartValueAggregate, labelFilterSelect, labelIds, valueIds, activeTab, xLegendPos, yLegendPos, hideLegend]);
  const updateChartData = () => {
    let tempPlotAttributes = Object.assign({}, plotAttributes);
    if (parseInt(plotAttributes['chartType']) !== parseInt(chartType) || tempPlotAttributes['tempLabelIds'].length !== labelIds.length
      || tempPlotAttributes['tempValueIds'].length !== valueIds.length) {
      tempPlotAttributes['data'] = getDataAccordingToChartType(chartType);
      tempPlotAttributes['layout'] = getLayoutAccordingToTypeNew(chartType, chartLabel);
      tempPlotAttributes['chartType'] = chartType;
      tempPlotAttributes['tempLabelIds'] = [...labelIds];
      tempPlotAttributes['tempValueIds'] = [...valueIds];
      tempPlotAttributes['status'] = true;
      setPlotAttributes(tempPlotAttributes);
    } else {
      tempPlotAttributes['data'] = getDataAccordingToChartType(chartType);
      tempPlotAttributes['layout'] = Object.assign({}, getLayoutAccordingToChartType(chartType, tempPlotAttributes['layout'], chartLabel));
      tempPlotAttributes['status'] = true;
      setPlotAttributes(tempPlotAttributes);
    }
  }

  const constructXYAxisData = (xAxisData, yAxisData, yAxisName, yAxisColor, yAxisAggregate, orientation, mode, type, stackgroup) => {
    let xAxisValue = xAxisData.length === 1 ? xAxisData[0] : xAxisData;
    let groups = xAxisData.length === 1 ? xAxisData[0] : xAxisData[1];
    let data = yAxisData.map((key, index) => {
      let trace = {
        x: orientation === 'v' ? xAxisValue : key, y: orientation === 'v' ? key : xAxisValue, type: type, name: yAxisName[index],
        marker: { color: yAxisColor[index] }, orientation: orientation, mode: mode
      };
      /* if(xAxisData.length === 1){
         trace['transforms'] = [{type:'aggregate', groups: groups , aggregations: [{func: yAxisAggregate[index], target: orientation === 'v' ? 'y' : 'x', enabled:true}]}]
       }*/

      if (stackgroup == 1) {
        trace['fill'] = 'tozeroy';
        //trace['stackgroup'] = 'one';
      }
      return trace;
    })
    return data;
  }

  const constructPieTypeChartData = (chartLabel, chartValue, chartValueName, type) => {
    chartLabel = chartLabel.length > 0 ? chartLabel[0] : chartLabel;
    chartValue = chartValue.length > 0 ? chartValue[0] : chartValue;
    chartLabel.map((val, i) => { chartLabel[i] = val ? val : null })
    chartValueName = chartValueName.length > 0 ? chartValueName[0] : chartValueName;
    if ((chartValue.filter(key => { return key !== 0 })).length > 0) {
      return [{ labels: chartLabel, values: chartValue, name: chartValueName, type: type, hoverinfo: 'label+percent+name' }];
    } else {
      return [{ labels: chartLabel, name: chartValueName, type: type, hoverinfo: 'label+percent+name' }];
    }
  }

  const constructGaugeChartdata = (chartLabel, chartValue, type) => {
    chartLabel = chartLabel.length > 0 ? chartLabel[0] : chartLabel;
    chartValue = chartValue.length > 0 ? chartValue[0] : chartValue;

    let result = [];
    let row = 0;
    let column = 0;
    for (var i = 1; i <= chartLabel.length; i++) {
      result.push({
        domain: { row: row, column: column },
        value: chartValue[i - 1],
        title: { text: chartLabel[i - 1]},
        type: type,
        mode: "gauge+number"
      });
      column++;
      if (i % 2 === 0) {
        row++;
        column = 0;
      }
    }
    return result;
  }


  const getDataAccordingToChartType = (chartType) => {
    switch (parseInt(chartType)) {
      case window.PIE_CHART_TYPE:
        return constructPieTypeChartData(chartLabel, chartValue, chartValueName, 'pie');
        break;
      case window.COL_CHART_TYPE:
        return constructXYAxisData(chartLabel, chartValue, chartValueName, chartValueColor, chartValueAggregate, 'h', 'markers', 'bar', 0);
        break;
      case window.BAR_CHART_TYPE:
        return constructXYAxisData(chartLabel, chartValue, chartValueName, chartValueColor, chartValueAggregate, 'v', 'markers', 'bar', 0);
        break;
      case window.LINE_CHART_TYPE:
        return constructXYAxisData(chartLabel, chartValue, chartValueName, chartValueColor, chartValueAggregate, 'v', 'lines', 'scatter', 0);
        break;
      case window.AREA_CHART_TYPE:
        let data = constructXYAxisData(chartLabel, chartValue, chartValueName, chartValueColor, chartValueAggregate, 'v', 'lines', 'scatter', 1);
        return data;
        break;
      case window.GAUGE_CHART_TYPE:
        return constructGaugeChartdata(chartLabel, chartValue, 'indicator');
        break;
      default:
        return [];
        break;
    }

    return
  }

  const getLayoutAccordingToTypeNew = (chartType, chartLabel) => {

    switch (parseInt(chartType)) {
      case window.PIE_CHART_TYPE: case window.TABLE_CHART_TYPE:
        return { title: chartTitle, hovermode: "closest", showlegend: true, legend: { "orientation": "h" } };
        break;
      case window.COL_CHART_TYPE: case window.BAR_CHART_TYPE: case window.LINE_CHART_TYPE:
      case window.AREA_CHART_TYPE:
        return {
          title: chartTitle, xaxis: { autorange: true, automargin: true, title: { text: chartXTitle } }, yaxis: { autorange: true, automargin: true, title: { text: chartYTitle } }, hovermode: "closest", showlegend:
            parseInt(hideLegend) !== 1 ? true : false,
          legend: parseInt(hideLegend) !== 1 ? { x: parseInt(xLegendPos) / 10, y: parseInt(yLegendPos) / 10 } : {}
        };
        break;
      case window.GAUGE_CHART_TYPE:
        let rowsLength = chartLabel.length > 0 ? Math.ceil(chartLabel[0].length / 2) : 0;
        return { grid: { rows: rowsLength, columns: 2, ygap: 0.3} }
        //, width: 600, height: 500};
        break;
      default:
        break;
    }
  }
  const getLayoutAccordingToChartType = (chartType, layout, chartLabel) => {

    switch (parseInt(chartType)) {
      case window.PIE_CHART_TYPE: case window.TABLE_CHART_TYPE:
        layout['title'] = chartTitle;
        return layout;
        break;
      case window.COL_CHART_TYPE: case window.BAR_CHART_TYPE: case window.LINE_CHART_TYPE:
      case window.AREA_CHART_TYPE:
        layout['xaxis']['title'] = { text: chartXTitle };
        layout['xaxis']['automargin'] = true;
        layout['xaxis']['autorange'] = true;
        layout['yaxis']['automargin'] = true;
        layout['yaxis']['autorange'] = true;
        layout['yaxis']['title'] = { text: chartYTitle };
        layout['showlegend'] = parseInt(hideLegend) !== 1 ? true : false;
        layout['legend'] = { x: parseInt(xLegendPos) / 10, y: parseInt(yLegendPos) / 10 };
        layout['title'] = chartTitle;
        return layout;
        break;
      case window.GAUGE_CHART_TYPE:
        let rowsLength = chartLabel.length > 0 ? Math.ceil(chartLabel[0].length / 2) : 0;
        layout['grid'] = { rows: rowsLength, columns: 2, ygap: 0.3 };
        // layout['width'] = 600;
        // layout['height'] = 500;
        layout['margin'] = { t: 70, r: 0, l: 0, b: 0 }
        return layout;
        break;
      default:
        break;
        break;
    }
  }

  const handleRender = (e) => {
    let tempPlotAttributes = Object.assign({}, plotAttributes);
    tempPlotAttributes['data'] = e['data'] !== undefined ? e['data'] : [];
    tempPlotAttributes['layout'] = e['layout'] !== undefined ? e['layout'] : [];
    tempPlotAttributes['frames'] = e['frames'] !== undefined ? e['frames'] : [];
    tempPlotAttributes['chartType'] = chartType;
    setPlotAttributes(tempPlotAttributes);
  }

  return (
    <div id={props.id}>
      {plotAttributes['status'] ? <Plot
        data={plotAttributes['data']}
        layout={plotAttributes['layout']}
        frames={plotAttributes['frames']}
        onUpdate={(e) => handleRender(e)}
        style={style}
        divId={props.id}
        useResizeHandler={true}
      /> : <div>{'...Loading'}</div>}
    </div>
  )

}
export default CommonChartComponent;
