import React from 'react';
import * as reactbootstrap from 'react-bootstrap';
import WebElementDragAndDrop from './WebElementDragAndDrop';
import ListDragAndDrop from './ListDragAndDrop';
import CheckBox from '../../CheckBox.js';
import MultiSelect from './../../_components/MultiSelect';
import { translate } from '../../language';
import './customreports.css';
import { Resizable, ResizableBox } from 'react-resizable';

let elementDrag = 0;
let orderLabelId = 0;

const FieldForm = props => {
  const t = props.t;
  const { state, setState, webformId, setWebformId, arrangeIds, staticColors } = props;
  const { subListData, listData, searchText, elementOrList, labelObj, valueObj, labelIds, valueIds, elementWithType, colors, labelSort,
    valueSort, parentElementsWithSource, rowLinkedElements,  listOrgSubmitData} = state;
  const AggreagationOptions = [
    { label: 'Sum', value: window.SUM },
    { label: 'Average', value: window.AVERAGE },
    { label: 'Median', value: window.MEDIAN },
    { label: 'Min', value: window.MIN },
    { label: 'Max', value: window.MAX },
    { label: 'Count', value: window.COUNT },
    { label: 'Standard deviation', value: window.STANDARD_DEVIATION },
    { label: 'Product', value: window.PRODUCT }
  ];


  const allowDropLabel = (e) => {
    e.preventDefault();
    return parseInt(elementDrag) === 1 ? true : false;
  }

  const allowDropValue = (e) => {
    e.preventDefault();
    return parseInt(elementDrag) === 1 ? true : false;
  }

  const onDropLabel = (e) => {
    e.preventDefault();
    if (parseInt(elementDrag) === 1) {
      let data = JSON.parse(e.dataTransfer.getData("elementObj"))
      elementDrag = 0;
      if (parseInt(elementOrList) === 0) {
        commonDropLabValFunc(1, data);
      } else {
        dropedListAsLabel(data);
      }
    }
  }

  const onDropValue = (e) => {
    e.preventDefault();
    if (parseInt(elementDrag) === 1 && parseInt(elementOrList) === 0) {
      let data = JSON.parse(e.dataTransfer.getData("elementObj"));
      elementDrag = 0;
      commonDropLabValFunc(0, data);
    } else {
      elementDrag = 0;
    }
  }

  const assignOrderNoForId = (id, ids) => {
    id = parseInt(id);
    let filteredArray = ids.filter(key => { return parseInt(key.split('-')[0]) === id });
    return id + '-' + (filteredArray.length > 0 ?
      (parseInt(filteredArray.map(key => { return parseInt(key.split('-')[1]) }).sort().pop())) + 1 : 0);
  }


  const getRandomColor = () => {
    return "#000000".replace(/0/g, function () { return (~~(Math.random() * 16)).toString(16); });
  }

  const commonDropLabValFunc = (labelOrValue, data) => {
    labelOrValue = parseInt(labelOrValue);
    if (labelOrValue === 0 || (labelOrValue === 1 && labelIds.length === 0 || labelOrValue === 1 &&
      labelIds.map(key => { return parseInt(labelObj[key]['type']) }).indexOf(70) === -1)) {

      let ids = labelOrValue === 1 ? labelIds : valueIds;
      let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
      let labValIdsKeyName = labelOrValue === 1 ? 'labelIds' : 'valueIds';
      let labeValObjKeyName = labelOrValue === 1 ? 'labelObj' : 'valueObj';
      let tempColors = colors;
      let sortName = labelOrValue === 1 ? 'labelSort' : 'valueSort';
      let tempElementWithType = Object.assign({}, elementWithType);
      if (data !== undefined && data !== {} && labelValueObj[data['id']] === undefined) {
        let elementId = data['id'];
        let type = parseInt(data['type']);
        let filterValue = labelOrValue === 1 && (type === window.LIST || type === window.CHECKBOX || type === window.RADIO_BUTTON ||
          type === window.CHECKBOX || type === window.ROWGENERATOR || type === window.LIST_ORGANISATIONAL_UNITS) ? [] : '';
        let elementIdWithOrderNo = assignOrderNoForId(elementId, ids);
        labelValueObj[elementIdWithOrderNo + (labelOrValue === 1 ? '-L' : '-V')] = {
          id: elementId,
          name: data['name'],
          typename: data['typename'],
          type: type,
          webform_id: data['webform_id'] !== undefined ? data['webform_id'] : webformId,
          list_id: data['list_id'] !== undefined ? data['list_id'] : 0,
          custom_name: data['name'],
          filter: filterValue,
          only_filter: 0,
          lock: 0,
          value_settings: labelOrValue === 1 ? '' : (window.NUMERICFIELD === type || window.DECIMALFIELD === type) ? window.SUM : window.COUNT,
          // color: getRandomColor(),
          color: '',
          //labelOrValue !== 1 ? (props.staticColors[ids.length] !== undefined ? props.staticColors[ids.length] : getRandomColor()): '',
          hide_from_graph: 0,
          label: labelOrValue,
          islist: type === window.CURRENT_STEP ? 2 : 0,
          isRowElement: data['isRowElement']
        }
        if (labelOrValue !== 1 && tempColors[ids.length] === undefined) {
          tempColors.push(staticColors[ids.length] !== undefined ? staticColors[ids.length] : getRandomColor());
        }
        ids.push(elementIdWithOrderNo + (labelOrValue === 1 ? '-L' : '-V'));
        tempElementWithType[elementIdWithOrderNo] = type;
        let setObj = {
          [labValIdsKeyName]: ids, [labeValObjKeyName]: labelValueObj, elementWithType: tempElementWithType, colors: tempColors,
          [sortName]: 0
        };
        setState({ ...state, ...setObj, sortedTableData: [] });
      }
    }
  }

  const dropedListAsLabel = (data) => {
    if (data !== undefined && data['value'] !== undefined) {
      // let tempLabelObj = Object.assign({}, labelObj);
      // let tempLabelIds = labelIds;
      let tempLabelObj = {};
      let tempLabelIds = [];
      let type = parseInt(data['type']);
      let id = parseInt(data['value']);
      let tempElementWithType = Object.assign({}, elementWithType);
      //   let elementIdWithOrderNo = assignOrderNoForId(id, labelIds);
      let elementIdWithOrderNo = assignOrderNoForId(id, []);
      tempElementWithType[elementIdWithOrderNo + ('-L')] = type;
      tempLabelIds.push(elementIdWithOrderNo + ('-L'));
      tempLabelObj[elementIdWithOrderNo + ('-L')] = {
        id: id,
        name: data['label'],
        typename: '',
        type: type,
        webform_id: props.webformId,
        list_id: id,
        custom_name: data['label'],
        filter: [],
        only_filter: 0,
        lock: 0,
        value_settings: '',
        color: '',
        hide_from_graph: 0,
        label: 1,
        islist: 1
      }
      let setObj = { labelIds: tempLabelIds, labelObj: tempLabelObj, elementWithType: tempElementWithType };
      setState({ ...state, ...setObj });
    }
  }

  const onDragStart = (e, elementObj) => {
    e.dataTransfer.setData("elementObj", JSON.stringify(elementObj));
    elementDrag = 1;
  }

  const onDragEnd = () => {
  }

  //--------- dynamic field handle methods ------------

  const handleInputField = (name, value, id, labelOrValue, hideChart) => {
    if (parseInt(id) !== 0) {
      labelOrValue = parseInt(labelOrValue);
      let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
      let labeValObjKeyName = labelOrValue === 1 ? 'labelObj' : 'valueObj';
      labelValueObj[id][name] = value;
      setState({ ...state, ...{ [labeValObjKeyName]: labelValueObj } });
    } else {
      setState({ ...state, ...{ [name]: value } });
    }
  }

  const handleRadio = (name, value) => {
    setState({ ...state, ...{ [name]: value } });
  }

  const handleCheckBox = (name, value, id, labelOrValue) => {
    labelOrValue = parseInt(labelOrValue);
    let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
    let labeValObjKeyName = labelOrValue === 1 ? 'labelObj' : 'valueObj';
    labelValueObj[id][name] = value ? 1 : 0;
    setState({ ...state, ...{ [labeValObjKeyName]: labelValueObj } });
  }

  const handleSingleSelectChange = (name, value, id, labelOrValue, hideChartTable) => {
    labelOrValue = parseInt(labelOrValue);
    let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
    let labeValObjKeyName = labelOrValue === 1 ? 'labelObj' : 'valueObj';
    labelValueObj[id][name] = value;
    setState({ ...state, ...{ [labeValObjKeyName]: labelValueObj } });
  }

  const handleMultiSelect = (name, value, id, hideChart) => {
    let tempLabelObj = Object.assign({}, labelObj);
    tempLabelObj[id][name] = value;
    setState({ ...state, ...{ labelObj: tempLabelObj } });
  }

  const handleColorChange = (name, value, id) => {
    let tempColors = colors;
    tempColors[id] = value;
    // let tempValueObj = Object.assign({}, valueObj);
    // tempValueObj[id][name] = value;
    // setState({ ...state, ...{ valueObj: tempValueObj } });
    setState({ ...state, ...{ [name]: tempColors } });
  }
  // ---------------------------------------------------

  //--------- dynamic field creation method -------------
  const getInputBox = (name, value, id, labelOrValue, hideChart) => {
    return <reactbootstrap.Form.Control style={{width:'100%', margin:'3px 0 3px 0'}}  value={value} onChange={(e) => handleInputField(name, e.target.value, id, labelOrValue, hideChart)} />
  }

  const getRadioButton = (label, name, value, checkValue) => {
    return (<label>{label}<input type="radio" checked={parseInt(value) === parseInt(checkValue) ? true : false} onChange={(e) => handleRadio(name, checkValue)} /></label>);
  }

  const getCheckBox = (name, value, id, labelOrValue) => {
    return <div>
      <CheckBox
        tick={parseInt(value) === 1 ? true : false}
        onCheck={e => handleCheckBox(name, e.target.checked, id, labelOrValue)}
      /></div>;
  }

  const getOptions = (optionValue, needSelectOption) => {
    let optionData = optionValue.map(key => {
      return <option value={key['value']}>{t(key['label'])}</option>
    });
    parseInt(needSelectOption) === 1 && optionData.unshift(<option value={0}>{t('---Select----')}</option>);
    return optionData;
  }

  const getDropDownField = (name, value, optionData, needSelectOption, id, labelOrValue, hideChartTable) => {
    return (
      <select value={value} style={{ width: '100%', height: '35px'}} onChange={(e) => handleSingleSelectChange(name, e.target.value, id, labelOrValue, hideChartTable)}>
        {getOptions(optionData, needSelectOption)}
      </select>
    )
  }

  const getMultiSelectDropDown = (name, value, optionData, id, hideChart) => {
    return <MultiSelect
      options={optionData}
      standards={value}
      isMulti={true}
      style={{ width: "100%" }}
      handleChange={(e) => handleMultiSelect(name, e, id, hideChart)}
    />
  }
  const getColorPicker = (name, value, id, labelOrValue) => {
    return <input type="color" value={value} onChange={(e) => handleColorChange(name, e.target.value, id)} />
  }

  //--------------------------------------------------------------

  const dragOverOrder = (e, labelOrValue) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  }

  const dragStartOrder = (e) => {
    e.dataTransfer.setData("orderElementId", e.currentTarget.id); // Thanks to bqlou for their comment.
    e.dataTransfer.dropEffect = "move";
  }

  const onDropOrder = (e, labelOrValue) => {
    if (parseInt(elementDrag) === 0) {
      labelOrValue = parseInt(labelOrValue);
      let labelValueIds = JSON.parse(JSON.stringify(labelOrValue === 1 ? labelIds : valueIds));
      let labValIdsKeyName = labelOrValue === 1 ? 'labelIds' : 'valueIds';
      let orderLabelId = e.dataTransfer.getData("orderElementId");
      let sortName = labelOrValue === 1 ? 'labelSort' : 'valueSort';
      labelValueIds = arrangeIds(orderLabelId, e.currentTarget.id, labelValueIds);
      setState({ ...state, ...{ [labValIdsKeyName]: labelValueIds, [sortName]: 0 }, sortableData:[] });
    }
  }




  const getFilterFieldAccordingToType = (type, name, value, options, key, labelOrValue, hideChart) => {
    switch (type) {
      case window.LIST: case window.CHECKBOX: case window.RADIO_BUTTON: case window.ROWGENERATOR: case window.LIST_ORGANISATIONAL_UNITS:
      case window.LIST_STATIC_TYPE:
        return getMultiSelectDropDown(name, value, options, key, hideChart);
        break;
      case window.DATEFIELD:
        return getDropDownField(name, value, window.CUSTOM_REPORT_DATEFIELD_OPTION, 1, key, labelOrValue, hideChart);
        break;
      default:
        return getInputBox(name, value, key, labelOrValue, hideChart);
        break;
    }
  }
  const getListOptions = (listId, type = 0, id = 0) => {
    if (type === window.ROWGENERATOR)
      return parentElementsWithSource[id];
    if(type === window.LIST_ORGANISATIONAL_UNITS)
       return listOrgSubmitData[id] ? Object.values(listOrgSubmitData[id]).map(value => {return { label:value, value: value }}) : [];
    let subListObj = subListData[listId] !== undefined ? subListData[listId] : {};
    let subListIds = Object.keys(subListObj);
    if (subListIds.length > 0) {
      return subListIds.map(key => {
        return { value: subListObj[key]['id'], label: subListObj[key]['name'] };
      })
    } else {
      return [];
    }
  }
  const handleDelete = (labelOrValue, id, index) => {
    labelOrValue = parseInt(labelOrValue);
    let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
    let tempColors = colors;
    let tempElementWithType = Object.assign({}, elementWithType);
    let ids = labelOrValue === 1 ? labelIds : valueIds;
    let oppositeIds = labelOrValue === 1 ? valueIds : labelIds;
    let labValIdsKeyName = labelOrValue === 1 ? 'labelIds' : 'valueIds';
    let labeValObjKeyName = labelOrValue === 1 ? 'labelObj' : 'valueObj';
    delete labelValueObj[id];
    ids = ids.filter(key => { return key !== id })
    if (labelOrValue !== 1) { tempColors.pop(); }
    let setObj = { [labValIdsKeyName]: ids, [labeValObjKeyName]: labelValueObj, colors: tempColors };
    if (ids.indexOf(id) === -1 && oppositeIds.indexOf(id) === -1) {
      delete tempElementWithType[id];
      setObj['elementWithType'] = tempElementWithType;
    }
    setState({ ...state, ...setObj });
  }


  const getSelectLabelElements = () => {
    return labelIds.map(key => {
      let type = parseInt(labelObj[key]['type']);
      return (<tr key={key} id={key} draggable="true" onDrop={(e) => { onDropOrder(e, 1) }} onDragOver={(e) => dragOverOrder(e)} onDragStart={(e) => dragStartOrder(e)}>
        <td><p style={{ margin: '0px', padding: '0px' }}>{labelObj[key]['name'] + ' '}</p>{labelObj[key]['typename'] !== '' && <p style={{ margin: '0px', padding: '0px' }}>({t(labelObj[key]['typename'])})</p>}</td>
        <td>{getInputBox('custom_name', labelObj[key]['custom_name'], key, 1, 0)}</td>
        <td accessKey={key}>{getFilterFieldAccordingToType(type, 'filter', labelObj[key]['filter'], getListOptions(labelObj[key]['list_id'], type, labelObj[key]['id']), key, 1, 1)}</td>
        <td>{getCheckBox('only_filter', labelObj[key]['only_filter'], key, 1)}</td>
        <td>{getCheckBox('lock', labelObj[key]['lock'], key, 1)}</td>
        <td><i title="Delete" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec"
          onClick={(e) => handleDelete(1, key, 0)}></i></td>
      </tr>);
    })
  }
  const handleSortCustomName = (labelOrValue, name, sortOrder) => {
    let ids = labelOrValue === 1 ? labelIds : valueIds;
    let labelValueObj = Object.assign({}, labelOrValue === 1 ? labelObj : valueObj);
    let idsName = labelOrValue === 1 ? 'labelIds' : 'valueIds';
    sortOrder = parseInt(sortOrder);
    const comparer = (a, b) => {
      if (sortOrder === 2) {
        return labelValueObj[a]['custom_name'] < labelValueObj[b]['custom_name'] ? 1 : -1;
      } else if (sortOrder === 1) {
        return labelValueObj[a]['custom_name'] > labelValueObj[b]['custom_name'] ? 1 : -1;
      }
    }

    setState({ ...state, ...{ [name]: sortOrder, [idsName]: ids.sort(comparer) } });
  }


  const getSymbolAccToSort = (sortVal) => {
    switch (parseInt(sortVal)) {
      case 1:
        return 'Asc';
        break;
      case 2:
        return 'Desc';
        break;
      default:
        return 'None';
        break;
    }
  }

  const getSelectedLabelTable = () => {
    return (<reactbootstrap.Table>
      <thead>
        <tr>
          <th>{t('Labels (x-axis)')}</th>
          <th onClick={(e) => handleSortCustomName(1, 'labelSort', labelSort == 1 ? 2 : 1)}>{t('Custom label name')}
            {' (' + getSymbolAccToSort(labelSort) + ')'}</th>
          <th>{t('Filter')}</th>
          <th>{t('Only filter')}</th>
          <th>{t('Lock')}</th>
          <th>{t('Delete')}</th>
        </tr>
      </thead>
      <tbody>
        {getSelectLabelElements()}
      </tbody>
    </reactbootstrap.Table>);
  }
  const getSelectValueElements = () => {
    return valueIds.map((key, index) => {
      return (<tr id={key} draggable="true" onDrop={(e) => { onDropOrder(e, 0) }} onDragOver={(e) => dragOverOrder(e)} onDragStart={(e) => dragStartOrder(e)} >
        <td><p style={{ margin: '0px', padding: '0px' }}>{t(valueObj[key]['name'])}</p><p style={{ margin: '0px', padding: '0px' }}>({t(valueObj[key]['typename'])})</p></td>
        <td>{getInputBox('custom_name', valueObj[key]['custom_name'], key, 0, 0)}</td>
        <td>{getDropDownField('value_settings', valueObj[key]['value_settings'], AggreagationOptions, 0, key, 0, 1)}</td>
        {/*<td>{getColorPicker('color', valueObj[key]['color'], key, 0)}</td>*/}
        <td>{getColorPicker('colors', colors[index], index, 0)}</td>
        <td>{getCheckBox('hide_from_graph', valueObj[key]['hide_from_graph'], key, 0)}</td>
        <td><i title="Delete" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={(e) => handleDelete(0, key, index)}></i></td>
      </tr>)
    })
  }
  const getSelectedValueTable = () => {
    return (<reactbootstrap.Table>
      <thead>
        <tr>
          <th>{t('Values (y-axis)')}</th>
          <th onClick={(e) => handleSortCustomName(0, 'valueSort', valueSort == 1 ? 2 : 1)}>{t('Custom value name')}
            {' (' + getSymbolAccToSort(valueSort) + ')'}</th>
          <th>{t('Value settings')}</th>
          <th>{t('Color')}</th>
          <th>{t('Hide from graph')}</th>
          <th>{t('Delete')}</th>
        </tr>
      </thead>
      <tbody>
        {getSelectValueElements()}
      </tbody>
    </reactbootstrap.Table>);
  }

  return (
    <div className="customreport-container">
      <div className="row">
        <div className='col-md-9'>
          <ResizableBox width={'90%'} height={300} axis={'y'} >
            <div id="div1" className="customreports" style={{height: '100%', border: '1px solid grey', overflowY: "auto" }}
              droppable='true' onDragOver={(e) => allowDropLabel(e)} onDrop={(e) => onDropLabel(e)} >
              {getSelectedLabelTable()}
            </div>
          </ResizableBox>
          <ResizableBox width={'90%'} height={300} axis={'y'} >
            <div id="div2" className="customreports" style={{height: '100%', border: '1px solid grey', overflowY: "auto" }}
              droppable='true' onDragOver={(e) => allowDropValue(e)} onDrop={(e) => onDropValue(e)} >
              {getSelectedValueTable()}
            </div>
          </ResizableBox>
        </div>
        <div className='col-md-3' style={{ float: 'right' }}>
          {getRadioButton('Elements', 'elementOrList', state['elementOrList'], 0)}
          {getRadioButton('Lists', 'elementOrList', state['elementOrList'], 1)}
          {state['elementOrList'] === 0 ? <div>
            <WebElementDragAndDrop
              webformId={webformId}
              setWebformId={setWebformId}
              onDragStart={onDragStart}
              onDragEnd={onDragEnd}
              selectedWebElements={[]}
              edit={false}
              handleInputField={handleInputField}
              searchText={searchText}
              listData={listData}
              rowLinkedElements={rowLinkedElements}
            /></div> :
            <div>
              <ListDragAndDrop
                listData={listData}
                onDragStart={onDragStart}
                onDragEnd={onDragEnd}
                handleInputField={handleInputField}
                searchText={searchText}
                selectedIds={[]} />
            </div>}
        </div>
      </div>
    </div>);
}
export default translate(FieldForm);
