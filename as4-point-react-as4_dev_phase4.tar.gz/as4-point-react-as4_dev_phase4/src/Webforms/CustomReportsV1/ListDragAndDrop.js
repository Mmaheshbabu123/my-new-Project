
import React, { useState ,useEffect,} from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import Select from 'react-select';

const ListDragAndDrop = props =>{
  const {listData, onDragStart, onDragEnd, handleInputField, searchText, selectedIds} = props;
  const displayLists = () =>{
   return listData.map(listObj=>{
           if((searchText.length === 0 || listObj['label'].toLowerCase().indexOf(searchText.toLowerCase()) !== -1) && (selectedIds.length === 0 || selectedIds.indexOf(parseInt(listObj['value'])) === -1)){
           return ( <p id = {listObj['value']} draggable="true" onDragStart={(e)=> onDragStart(e, listObj)} onDragEnd={(e) => onDragEnd(e)}>{listObj['label']}</p> )
           }

           });
  }
  return (<div>
           <input type = {'text'} value = {searchText} onChange = {(e)=>handleInputField('searchText', e.target.value, 0, 0, 0)} />
          {displayLists()}
          </div>);
}
export default ListDragAndDrop;
