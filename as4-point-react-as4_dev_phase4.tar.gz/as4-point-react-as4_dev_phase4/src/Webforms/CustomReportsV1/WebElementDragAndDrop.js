import React, { useState, useEffect, } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import Select from 'react-select';
import './customreports.css';

const WebElementDragAndDrop = props => {
  const t = props.t;
  const [count, setCount] = useState(0)
  const [webformData, setWebformData] = useState([])
  const [allWebElements, setAllWebElements] = useState([])
  const { webformId, setWebformId, onDragStart, onDragEnd, selectedWebElements, edit, searchText, handleInputField, listData, elementOrList, handleElementOrListRadio, rowLinkedElements } = props;
  const webElements = async () => {
    await getWebformWebelements();
  }

  useEffect(() => {
    if (parseInt(webformId) !== 0) {
      webElements();
    }
  }, [webformId])

  const allWeborms = async () => {
    await getAllWebforms();
  }

  useEffect(() => {
    allWeborms();
  }, [count])

  async function getAllWebforms() {
    let url = window.GET_ALL_WEBFORMS + '/' + window.ACTIVE_WEBFORM;
    datasave.service(url, 'GET')
      .then(response => {
        if (response['status'] == 200) {
          setWebformData(response['data']);
        }
      })
  }

  async function getWebformWebelements() {
    await datasave.service(window.FETCH_ALL_WEBELEMENTS_FOR_REPORTS + '?webform_id=' + (webformId), 'POST').then(
      async response => {
        if (response['status'] == 200) {
          setAllWebElements(response['data'].concat(window.CUSTOM_CHART_ADDITIONAL_ENTITIES));
        }
      }
    )
  }

  const getWebformList = () => {
    if (webformData.length > 0) {
      const options = webformData.map(key => {
        return <option key={key['id']} value={key['id']}> {key['name']} </option>
      });
      options.unshift(<option key={0}>{'------select------'}</option>)
      return <select value={webformId} onChange={(e) => setWebformId(e.target.value)} disabled={!edit}> {options} </select>
    }
  }

  const getWebElementList = () => {
    if (allWebElements.length > 0) {
      let webElements = allWebElements.filter(key => !selectedWebElements.includes(parseInt(key['id'])));
      return webElements.map(key => {
        key = { ...key, isRowElement: rowLinkedElements.includes(key['id']) ? 1 : 0 }
        if (searchText.length === 0 || (key['alias'].toLowerCase()).indexOf(searchText.toLowerCase()) !== -1) {
          return (<p key={key['id']} id={key['id']} draggable="true" onDragStart={(e) => onDragStart(e, key)} onDragEnd={(e) => onDragEnd(e)}>
            {key['alias']}{key['typename'] !== undefined ? ' ( ' + key['typename'] + ' )' : ''}
          </p>);
        }
      })
    }
  }
  return (
    <div>
      <div className="customreport-select">
        {getWebformList()}
      </div>
      <div>
        <reactbootstrap.Form.Control style={{width:'100%', margin:'3px 0 3px 0'}} type={'text'} value={searchText} onChange={(e) => handleInputField('searchText', e.target.value, 0, 0, 0)} />
      </div>
      <div className='header draggable customreport-drag'>

        {getWebElementList()}
      </div>
    </div>
  )
}


export default WebElementDragAndDrop;
