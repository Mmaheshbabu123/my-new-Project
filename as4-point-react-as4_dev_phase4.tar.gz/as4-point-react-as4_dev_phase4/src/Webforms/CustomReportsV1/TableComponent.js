import ReactDataGrid from "react-data-grid-defaultvalue";
import React, { useRef, useEffect, useState } from 'react';
import ReactDOM from 'react-dom';

const TableComponent = props =>{
	const rowGetterFunc = (i, rows) =>{
		return rows[i];
	}
	const grid  = useRef(null);
	const [gridWidth, setGridWidth] = useState(750);
	const gridHeight = props.rows.length > 10 ? 480 : 350;

	useEffect(() => {
	  	let interval = setInterval(() => resizeGrid(), 1000)
	  	return () => { if(gridWidth !== 100){ clearInterval(interval) }
	  }
  })

	const resizeGrid = () => {
		if(grid.current){
			const domNode = ReactDOM.findDOMNode(grid.current)
			if (domNode && domNode.parentElement) {
				const container = domNode.parentElement
				setGridWidth(Math.max(100, container.offsetWidth))
			}
		}
	}

	return (
		<div className='container py-4 pl-0'>
	  	<div className='col-md-12' id='custom_chart_data_grid' style={{marginBottom: '30px', padding: 0}}>
		    <ReactDataGrid
					ref={(dataGrid) => { grid.current = dataGrid }}
					columns={props.columns}
					rowGetter={i=>rowGetterFunc(i, props.rows)}
					rowsCount={props.rows.length}
					onGridSort={(sortColumn, sortDirection) => {props.handleSort(props.rows, sortColumn, sortDirection)}}
					minHeight={gridHeight}
					minWidth={gridWidth}
				/>
			</div>
		</div>
	)
}
export default TableComponent;
