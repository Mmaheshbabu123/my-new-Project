import React, { useState, useEffect } from 'react'
import * as Reactbootstrap from 'react-bootstrap'
import { datasave } from '../../_services/db_services'
import { translate } from '../../language'
import { OCAlert } from '@opuscapita/react-alerts'
import FieldForm from './FieldForm';
import ChartForm from './ChartForm';
import { reportFilter } from '../WebReports/CustomFilterFunctions';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
import { CanPermissions } from '../../_components/CanComponent/CanPermissions';
//import {CommonAggregationFunc} from './CommonAggregationFunc';

let webformSubmitData = {};
let chunkSize = 200;
const MainCustomWindow = props => {
  const t = props.t;
  const staticColors = ['#004586', '#ff420e', '#ffd320', '#579d1c', '#7e0021', '#83caff', '#314004', '#aecf00', '#4b1f6f', '#ff950e'];
  const todaysDate = new Date();
  const dateOptionObj = Object.keys(window.DATE_DEFAULT_FILTER_KEY_LABEL).map(key => { return { 'label': window.DATE_DEFAULT_FILTER_KEY_LABEL[key], 'value': key } });
  dateOptionObj.splice(1, 0, { label: 'From and to date', value: window.FROM_TO_DATE });
  const [state, setState] = useState({
    accessDenied : 0, status: false, activeTab: 0, responseText: '...Loading', execute_list_service: 1, subListData: {}, listData: {}, submitDetails: {}, quality_fiscal: {}, dateListOptions: [], searchText: '', elementOrList: 0, labelIds: [], valueIds: [], labelObj: {}, valueObj: {}, elementWithType: {}, dateFieldFilter: { label: 'Start date', value: "99991||" + window.START_DATE }, dateSelect: { label: 'All', value: window.ALL }, dateOption: dateOptionObj, fromDate: todaysDate.getFullYear() + '-' + '01' + '-' + '01', toDate: todaysDate.getFullYear() + '-' + (todaysDate.getMonth() + 1) + '-' + todaysDate.getDate(), chartName: '', showTable: 0, showGraph: 1, total: 0, chartType: { 'label': 'PieChart', 'value': window.PIE_CHART_TYPE }, chartTitle: '', chartXTitle: '', chartYTitle: '', lockFilter: 0, labelFilterSelect: [], dateListMinMaxObj: {}, filterObj: {}, xLegendPos: 0, yLegendPos: 0, hideLegend: 0, colors: [], labelSort: 0, valueSort: 0,
    parentElementsWithSource: {}, parentWithChildElements: {}, rowLinkedElements: [], generatedRowsLength: 0, sourceIdLinkedEle: {}, sortedTableData: [], accessChecked:1, done: [], includeFalseValues: 0, listOrgSubmitData: {},
  });
  const [count, setCount] = useState(0);
  const { status, activeTab, responseText, execute_list_service, subListData, listData, dateListOptions, quality_fiscal, submitDetails,
    searchText, dateFieldFilter, fromDate, toDate, chartType, chartTitle, chartXTitle, chartYTitle, lockFilter, chartName, showTable,
    showGraph, total, labelIds, valueIds, labelObj, valueObj, dateSelect, labelFilterSelect, dateListMinMaxObj, xLegendPos, yLegendPos,
    hideLegend, colors, filterObj, parentElementsWithSource, parentWithChildElements, rowLinkedElements, generatedRowsLength, sourceIdLinkedEle, accessDenied, accessChecked, done, includeFalseValues, listOrgSubmitData } = state;
  const [reportId, setReportId] = useState(0);
  const webformId = props.webformId !== undefined ? props.webformId : props.match.params.webformId;
  const overview = window.location.href.includes('q=groundplan=1') !== true ? props.disableFields : 1;
  const getLabelValueByOnlyValue = (value, options) => {
    let res = {};
    let numberOrString = !isNaN(value) ? 1 : 0;
    options.map(keyObj => {
      keyObj['value'] = numberOrString === 1 ? parseInt(keyObj['value']) : keyObj['value']
      if (keyObj['value'] === value) {
        res = keyObj;
      }
    });
    return res;
  }
  const findingMinAndMaxDateOfObj = (dataObj) => {
    let resObj = {};
    Object.keys(dataObj).map(key => { resObj[key] = { 'min': 0, 'max': 0 } });
    Object.keys(dataObj).map(key => {
      resObj[key]['min'] = dataObj[key].length > 0 ? Math.min(...(dataObj[key])) : 0
      resObj[key]['max'] = dataObj[key].length > 0 ? Math.max(...(dataObj[key])) : 0
    })
    return resObj;
  }

  const convertDateObjToString = (dateObj) => {
    let month = dateObj.getMonth() + 1;
    let fullYear = dateObj.getFullYear();
    let date = dateObj.getDate() * 10 >= 100 ? dateObj.getDate() : '0' + (dateObj.getDate());
    return fullYear + '-' + ((month * 10) >= 100 ? month : '0' + month) + '-' + date;
  }

  const selectedDateTypeMinMaxObj = (tempDateList, tempSubmitDetails) => {
    let tempSubmitIds = Object.keys(tempSubmitDetails);
    let resultObj = {};
    if (tempDateList.length > 0 && tempSubmitIds.length > 0) {
      tempDateList.map(key => { resultObj[key['value']] = [] });
      tempDateList.map(key => {
        tempSubmitIds.map(submitId => {
          let valueDate = tempSubmitDetails[submitId][key['value']];
          resultObj[key['value']].push(valueDate !== undefined &&
            valueDate !== '' ? new Date(valueDate).valueOf() : 0)
        });
      });
    }
    return findingMinAndMaxDateOfObj(resultObj);
  }

  const getToFromDateAccordingToDateSelect = (tempDateSelect, tempDateFieldFilter, tempDateListMinMaxObj, toDate, fromDate) => {
    if (Object.keys(tempDateListMinMaxObj).length > 0 && parseInt(tempDateSelect) === window.ALL) {
      let selectDateObj = tempDateListMinMaxObj[tempDateFieldFilter] !== undefined ? tempDateListMinMaxObj[tempDateFieldFilter] : {};
      return {
        toDate: selectDateObj['max'] !== 0 ? new Date(selectDateObj['max']) : '',
        fromDate: selectDateObj['min'] !== 0 ? new Date(selectDateObj['min']) : ''
      };
    } else {
      return { toDate: toDate !== '' ? new Date(toDate) : '', fromDate: fromDate !== '' ? new Date(fromDate) : '' };
    }
  }

  const preFillSavedDetails = (setObj, details) => {
    if (Object.keys(details).length > 0) {
      setObj['labelIds'] = details['labelIds'] !== undefined ? details['labelIds'] : [];
      setObj['valueIds'] = details['valueIds'] !== undefined ? details['valueIds'] : [];
      setObj['labelObj'] = details['labelObj'] !== undefined ? details['labelObj'] : {};
      setObj['valueObj'] = details['valueObj'] !== undefined ? details['valueObj'] : {};
      setObj['colors'] = details['colors'] !== undefined ? details['colors'] : [];
      setObj['chartName'] = details['name'] !== undefined ? details['name'] : [];
      setObj['dateFieldFilter'] = details['date_field_filter'] !== undefined ? getLabelValueByOnlyValue(details['date_field_filter'], setObj['dateListOptions']) : {};
      setObj['fromDate'] = details['from_date'] !== undefined ? details['from_date'] : '';
      setObj['toDate'] = details['to_date'] !== undefined ? details['to_date'] : '';
      setObj['dateSelect'] = details['date_select'] !== undefined ? getLabelValueByOnlyValue(details['date_select'], dateOptionObj) : {};
      setObj['showGraph'] = details['show_graph'] !== undefined ? details['show_graph'] : 0;
      setObj['showTable'] = details['show_table'] !== undefined ? details['show_table'] : 0;
      setObj['total'] = details['total'] !== undefined ? details['total'] : 0;
      setObj['lockFilter'] = details['lock_filter'] !== undefined ? details['lock_filter'] : 0;
      setObj['chartType'] = details['chart_details']['chartType'] !== undefined ? getLabelValueByOnlyValue(details['chart_details']['chartType'], window.WEBFORMREPORTTYPES) : {};
      [setObj['filterObj'], setObj['done'], setObj['includeFalseValues']] = getFilterObject(details['filter_obj'], setObj);
      setObj['submitDetails'] = updateSubmitDetails(setObj['done']);
      setObj['chartTitle'] = details['chart_details']['chartTitle'] !== undefined ? details['chart_details']['chartTitle'] : '';
      setObj['chartXTitle'] = details['chart_details']['chartXTitle'] !== undefined ? details['chart_details']['chartXTitle'] : '';
      setObj['chartYTitle'] = details['chart_details']['chartYTitle'] !== undefined ? details['chart_details']['chartYTitle'] : '';
      setObj['xLegendPos'] = details['xlegendpos'] !== undefined ? details['xlegendpos'] : 8;
      setObj['yLegendPos'] = details['ylegendpos'] !== undefined ? details['ylegendpos'] : 12;
      setObj['hideLegend'] = details['hide_legend'] !== undefined ? details['hide_legend'] : 0;
      let resultFromToDateObj = parseInt(setObj['dateSelect']['value']) !== window.FROM_TO_DATE && Object.keys(setObj['dateSelect']).length > 0 ?
        (parseInt(setObj['dateSelect']['value']) === window.ALL ?
          getToFromDateAccordingToDateSelect(setObj['dateSelect']['value'], setObj['dateFieldFilter']['value'], setObj['dateListMinMaxObj'], setObj['toDate'], setObj['fromDate']) :
          reportFilter.dateFilterSwitch(setObj['dateSelect']['value'], setObj['quality_fiscal'])) : {};
      setObj['fromDate'] = resultFromToDateObj['fromDate'] ? convertDateObjToString(resultFromToDateObj['fromDate']) : setObj['fromDate'];
      setObj['toDate'] = resultFromToDateObj['toDate'] ? convertDateObjToString(resultFromToDateObj['toDate']) : setObj['toDate'];
      setState({ ...state, ...setObj });
    } else {
      setState({ ...state, ...setObj });
    }
  }

  const getFilterObject = (filterObj, setObj) => {
    if(!filterObj){
      return [{},[], 0];
    }
    let done = [], falseValues = 0;
    if(filterObj['done']){
      done = filterObj['done'] ? filterObj['done']: [];
      delete filterObj['done'];
    }
    if(filterObj['includeFalseValues'] !== undefined){
      falseValues = filterObj['includeFalseValues'];
      delete filterObj['includeFalseValues'];
    }
    return [filterObj, done, falseValues];
  }

  function getLisrOrgSubmitData(listOrgElements) {
    let result = {};
    Object.values(webformSubmitData).map(val => {
      listOrgElements.map(listOrgId => {
        if(val['webElementObj'] && val['webElementObj'][listOrgId])
           if(result[listOrgId])
              result[listOrgId][val['webElementObj'][listOrgId]] = val['webElementObj'][listOrgId];
           else { result[listOrgId] = {};  result[listOrgId][val['webElementObj'][listOrgId]] = val['webElementObj'][listOrgId]}
      })
    })
    return result;
  }

  const updateSubmitDetails = (doneObj = {}, render = 0) => {
    let finished = doneObj ?.value ?? 0;
    let resultData = [];
    if(finished === 1) {
      resultData = convertToObj(Object.values(webformSubmitData), finished)
    }else if (finished === 2 ) {
      resultData = convertToObj(Object.values(webformSubmitData), finished)
    }else{
      resultData = webformSubmitData;
    }
    if(render) {
      setState({...state, done: doneObj, submitDetails: resultData})
      return;
    }
    return resultData;
  }

  const convertToObj = (array, finished) => {
    let obj = {}
    array.map(val => {
      if((finished === 1 && val.step_type === 0) || (finished === 2 && val.step_type !== 0))
        obj[val.submit_id] = val;
    })
    return obj;
  }

  useEffect(() => {
    fetchData();
  }, [props.id !== undefined ? props.id : props.match.params.id])

  const fetchData = async (loadCount = 0) => {
    const lang_code = await (localStorage.getItem('Applang'));
    let data = { id: (props.id !== undefined ? props.id : props.match.params.id), webformId: props.webformId !== undefined ? props.webformId : props.match.params.webformId, webform_id: props.webformId !== undefined ? props.webformId : props.match.params.webformId, execute_list_service: execute_list_service, lang_code: lang_code,
      offset: chunkSize * loadCount,
      limit: chunkSize,
    };
    await datasave.service(window.GET_CUSTOMREPORT_COMPLETEDETAILS, 'POST', data, loadCount > 0 ? 0 : 1).then(
      async response => {
        if (response['status'] == 200) {
          webformSubmitData = {...webformSubmitData, ...response['data']['submitDetails'] !== undefined ? response['data']['submitDetails'] : submitDetails};
          let setObj = {};
          let rowGeneratorData = response['data']['rowGeneratorData'];
          setObj['subListData'] = parseInt(execute_list_service) === 1 && response['data']['sublists'] !== undefined ?
            response['data']['sublists'] : subListData;
          setObj['listData'] = parseInt(execute_list_service) === 1 && response['data']['lists'] !== undefined ?
            response['data']['lists'] : listData;
          setObj['dateListOptions'] = response['data']['date_list'] !== undefined ? response['data']['date_list'] : dateListOptions;
          setObj['quality_fiscal'] = response['data']['quality_fiscal'] !== undefined ? response['data']['quality_fiscal'] : quality_fiscal;
          setObj['submitDetails'] = webformSubmitData;
          setObj['dateListMinMaxObj'] = selectedDateTypeMinMaxObj(setObj['dateListOptions'], setObj['submitDetails']);
          setObj['status'] = response['data']['dataLoaded'] ? true : false;
          setObj['dataLoaded'] = response['data']['dataLoaded'];
          setObj['execute_list_service'] = 0;
          setObj['parentElementsWithSource'] = rowGeneratorData['parentElementsWithSource'] ? rowGeneratorData['parentElementsWithSource'] : [];
          setObj['parentWithChildElements'] = rowGeneratorData['parentWithChildElements'] ? rowGeneratorData['parentWithChildElements'] : [];
          setObj['rowLinkedElements'] = rowGeneratorData['rowLinkedElements'] ? rowGeneratorData['rowLinkedElements'] : [];
          setObj['sourceIdLinkedEle'] = rowGeneratorData['sourceIdLinkedEle'] ? rowGeneratorData['sourceIdLinkedEle'] : {};
          setObj['generatedRowsLength'] = rowGeneratorData['generatedRowsLength'] ? rowGeneratorData['generatedRowsLength'] : 0;
          setObj['accessChecked'] = response['accessChecked'] ?  response['accessChecked']['checked'] : 1;
          setObj['accessDenied'] = 0;
          setObj['listOrgSubmitData'] = getLisrOrgSubmitData(response['data']['listOrgElements']);
          if (parseInt(props.id !== undefined ? props.id : props.match.params.id) !== 0) {
            preFillSavedDetails(setObj, response['data']['custom_report_details']);
          } else {
            let resultFromToDateObj = getToFromDateAccordingToDateSelect(dateSelect['value'], dateFieldFilter['value'],
              setObj['dateListMinMaxObj'], '', '');
            setObj['fromDate'] = resultFromToDateObj['fromDate'] !== '' ? convertDateObjToString(resultFromToDateObj['fromDate']) : '';
            setObj['toDate'] = resultFromToDateObj['toDate'] !== '' ? convertDateObjToString(resultFromToDateObj['toDate']) : '';
            setState({ ...state, ...setObj });
          }
          await fetchDataInChunkWise(response, loadCount);
        } else if(response['status'] == 410 ) {
            setState({ ...state, ...{ responseText:'', accessDenied: 1}});
        } else {
          setState({ ...state, ...{ responseText: 'Error please try again' } });
        }
      });
  }

  const fetchDataInChunkWise = async (response, loadCount) => {
    if(response['data']['dataLoaded'] === 0){
      await fetchData(loadCount + 1);
    }
  }

  const setWebformId = () => {
  }

  const arrangeIds = (id, targetId, idsArray) => {
    id = id;
    targetId = targetId;
    let idIndex = idsArray.indexOf(id);
    let targetIdIndex = idsArray.indexOf(targetId);
    idsArray.splice(idIndex, 1);
    if (targetIdIndex !== 0) {
      idsArray.splice(targetIdIndex, 0, id);
    } else {
      idsArray.unshift(id);
    }
    return idsArray;
  }

  const getFieldForm = () => {
    return (
      <FieldForm
        state={state}
        setState={setState}
        count={count}
        activeTab={activeTab}
        webformId={props.webformId !== undefined ? props.webformId : props.match.params.webformId}
        setWebformId={setWebformId}
        setCount={setCount}
        arrangeIds={arrangeIds}
        staticColors={staticColors}
      />
    );
  }

  const getChartForm = () => {
    return <ChartForm
      state={state}
      setState={setState}
      activeTab={activeTab}
      webformId={props.webformId !== undefined ? props.webformId : props.match.params.webformId}
      getToFromDateAccordingToDateSelect={getToFromDateAccordingToDateSelect}
      convertDateObjToString={convertDateObjToString}
      colors={colors}
      disableFields={overview}
      accessChecked={accessChecked}
      updateSubmitDetails={updateSubmitDetails}
    />
  }
  const handleSave = () => {
    if (chartName.length > 0 && valueIds.length > 0 && labelIds.length > 0) {
      let data = {
        id: reportId ? reportId : (props.id !== undefined ? props.id : props.match.params.id), chartName: chartName,
        webformId: props.webformId !== undefined ? props.webformId : props.match.params.webformId, labelIds: labelIds, labelObj: labelObj,
        valueIds: valueIds, valueObj: valueObj, dateFieldFilter: Object.keys(dateFieldFilter).length > 0 ? dateFieldFilter['value'] : 0,
        fromDate: fromDate, toDate: toDate, dateSelect: Object.keys(dateSelect).length > 0 ? dateSelect['value'] : 0, showTable: showTable,
        showGraph: showGraph, total: total, chart_details: { chartType: Object.keys(chartType).length > 0 ? chartType['value'] : 0, chartTitle: chartTitle, chartXTitle: chartXTitle, chartYTitle: chartYTitle }, lockFilter: lockFilter, labelFilterSelect: labelFilterSelect,
        xLegendPos: xLegendPos, yLegendPos: yLegendPos, hideLegend: hideLegend, colors: colors, filter_obj: {...filterObj, done: done, includeFalseValues: includeFalseValues}
      };
      datasave.service(window.INSERT_CUSTOM_REPORT, 'POST', { 'data': data }).then(
        async response => {
          if (response['status'] === 200) {
            setReportId(response['data']);
            OCAlert.alertSuccess(t('Save successfull'));
          } else {
            OCAlert.alertError(t('Error, please try again'));
          }
        })
    } else {
      OCAlert.alertError(chartName.length > 0 ? 'Please select label and value' : 'Please enter the chart name', { timeOut: window.TIMEOUTNOTIFICATION });
    }
  }

  const handleAciveTab = (name, value) => {
    setState({ ...state, ...{ [name]: parseInt(value) } });
  }


  return (
     <div className='fluid pl-5 py-10'>
      {!status && <div className="container-fluid pl-5">{responseText}</div>}
      {accessDenied === 1 && <AccessDeniedPage />}
      {status &&
        <div className='container-fluid pl-5 '>
          {overview === undefined &&
            <Reactbootstrap.Button onClick={(e) => handleSave()} style={{ float: 'right' }}>{'Save'}</Reactbootstrap.Button>}
          {overview === undefined && <Reactbootstrap.Tabs activeKey={activeTab} onSelect={(k) => handleAciveTab('activeTab', k)}>
            <Reactbootstrap.Tab eventKey={0} title="Field">
              {getFieldForm()}
            </Reactbootstrap.Tab>
            <Reactbootstrap.Tab eventKey={1} title="Chart">
              {getChartForm()}
            </Reactbootstrap.Tab>
          </Reactbootstrap.Tabs>}
          {overview !== undefined && getChartForm()}
        </div>}
    </div>
  );
}
export default translate(MainCustomWindow);
