import React, { useState, useEffect, } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import WebElementDragAndDrop from './WebElementDragAndDrop';
import CheckBox from '../../CheckBox.js';
import MultiSelect from './../../_components/MultiSelect';
import { reportFilter } from '../WebReports/CustomFilterFunctions';
import CommonChartComponent from './CommonChartComponent';
import TableComponent from './TableComponent';
import './customreports.css';
import { CommonAggregationFunc } from './CommonAggregationFunc';
import { translate } from '../../language';
let totalLabelKey = 0;
let sortedResultData = {};
const ChartForm = props => {
  const t = props.t;
  const { state, setState, getToFromDateAccordingToDateSelect, convertDateObjToString, updateSubmitDetails } = props;
  const { dateFieldFilter, dateSelect, quality_fiscal, dateListOptions, dateOption, fromDate, toDate, chartName, showTable, showGraph, total,
    chartType, chartTitle, chartXTitle, chartYTitle, lockFilter, labelIds, valueIds, labelObj, valueObj, submitDetails, dateListMinMaxObj, activeTab, filterObj, xLegendPos, yLegendPos, hideLegend, colors, subListData, parentWithChildElements, sortedTableData, done, includeFalseValues } = state;
  const Days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const Months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  let rowIterationCount = 0;
  const getOptions = (optionValue, needSelectOption) => {
    let optionData = optionValue.map(key => {
      return <option value={key['value']}>{t(key['label'])}</option>
    });
    parseInt(needSelectOption) === 1 && optionData.unshift(<option value={0}>{t('---Select----')}</option>);
    return optionData;
  }


  const handleSingleSelectChange = (name, value, setDate, hideChart) => {
    let setObj = { [name]: value };
    if (parseInt(setDate) === 1) {
      let resFromToDate = parseInt(value['value']) !== window.FROM_TO_DATE && Object.keys(value).length > 0 ?
        (parseInt(value['value']) === window.ALL ?
          getToFromDateAccordingToDateSelect(value['value'], dateFieldFilter['value'], dateListMinMaxObj, fromDate, toDate) :
          reportFilter.dateFilterSwitch(value['value'], quality_fiscal)) : {};
      let fromDate = resFromToDate['fromDate'] !== undefined &&
        resFromToDate['fromDate'] !== '' ? convertDateObjToString(resFromToDate['fromDate']) : '';
      let toDate = resFromToDate['toDate'] !== undefined &&
        resFromToDate['toDate'] !== '' ? convertDateObjToString(resFromToDate['toDate']) : '';
      setObj['fromDate'] = fromDate;
      setObj['toDate'] = toDate;
      setState({ ...state, ...setObj });
    } else if (name === 'done') {
       updateSubmitDetails(value, 1);
    }else {
      setState({ ...state, ...setObj });
    }
  }

  const handleFilterDropDown = (name, value, id) => {
    let tempFilterObj = Object.assign({}, filterObj);
    tempFilterObj[id] = value;
    setState({ ...state, ...{ filterObj: tempFilterObj } });
  }


  const getFilterDropDown = (name, value, optionData, id) => {
    let uniqueOptions = Array.isArray(optionData) && optionData.length ? [...new Map(optionData.map((item) => [item["value"], item])).values()] : [];
    return <MultiSelect
      options={uniqueOptions}
      standards={value}
      isMulti={true}
      disabled={labelObj[id] && labelObj[id]['lock'] === 1 ? true : false}
      style={{ width: "100%" }}
      handleChange={(e) => handleFilterDropDown(name, e, id)}
    />
  }

  const getDropDownField = (labelName, name, value, optionData, needSelectOption, setDate, hideChart) => {
    let disable = !['Done', 'Select chart'].includes(labelName) ? (parseInt(lockFilter) === 1 ? true : false) : props.disableFields === 1 ? true : false;
    return <MultiSelect
      options={optionData}
      standards={value}
      isMulti={false}
      style={{ width: "100%" }}
      disabled={disable}
      handleChange={(e) => handleSingleSelectChange(name, e, setDate, 0)}
    />
    /* return (<div>
        <select value={value} onChange={(e) => handleSingleSelectChange(name, e.target.value, setDate, hideChart)}>
          {getOptions(optionData, needSelectOption)}
        </select>
       </div>)*/
  }
  const handleDateField = (name, value, hideChart) => {
    setState({ ...state, ...{ [name]: value } });
  }

  const getDateField = (labelName, name, value, hideChart, disableDateField) => {
    return <div>
      <input type='date' value={value} onChange={(e) => handleDateField(name, e.target.value, hideChart)} disabled={(disableDateField === 1 || parseInt(lockFilter) === 1) ? true : false} />
    </div>
  }

  const handleTextField = (name, value) => {
    setState({ ...state, ...{ [name]: value } });
  }

  const handleNumberField = (name, value) => {
    setState({ ...state, ...{ [name]: value } });
  }

  const getTextField = (labelName, name, value) => {
    return (
      <div> <reactbootstrap.Form.Control style={{width:'100%', margin:'3px 0 3px 0'}} disabled={props.disableFields} type={'text'} value={value} onChange={(e) => handleTextField(name, e.target.value)} placeholder={labelName} /></div>
    )
  }

  const getNumberField = (name, value) => {
    return (
      <input class="css-bg1rzq-control" style={{width:'45%', margin:'0 auto'}} type={'number'} value={value} onChange={(e) => handleNumberField(name, e.target.value)} />
    )
  }

  const handleCheckBox = (name, value) => {
    setState({ ...state, ...{ [name]: parseInt(value) } });
  }

  const getCheckBox = (labelName, name, value) => {
    return(
        <CheckBox
          tick={parseInt(value) === 1 ? true : false}
          name={labelName}
          onCheck={e => handleCheckBox(name, e.target.checked ? 1 : 0)}
          customStyle={{padding: 0}}
        />
    )
  }
  const getDetailsWithinDates = () => {
    let tempFromDate = new Date(fromDate);
    tempFromDate = new Date(tempFromDate.getFullYear() + '-' + (tempFromDate.getMonth() + 1) + '-' + tempFromDate.getDate() + ' 00:00:00');
    let tempToDate = new Date(toDate);
    tempToDate = new Date(tempToDate.getFullYear() + '-' + (tempToDate.getMonth() + 1) + '-' + tempToDate.getDate() + ' 23:59:59');
    let tempDateFilter = Object.keys(dateFieldFilter).length > 0 ? dateFieldFilter['value'] : undefined;
    if (tempFromDate.valueOf() <= tempToDate.valueOf() && tempDateFilter !== undefined) {
      return Object.keys(submitDetails).filter(key => {
        let temp = submitDetails[key][tempDateFilter] !== '' ? new Date(submitDetails[key][tempDateFilter]).valueOf() : 0;
        return temp !== 0 && temp >= tempFromDate.valueOf() && temp <= tempToDate.valueOf() ? 1 : 0
      });
    } else {
      OCAlert.alertError(dateFieldFilter === undefined ? t('Select date type') : t('Entered from - to date is wrong'));
      return [];
    }
  }

  const intializeEmptyArr = (ids) => {
    let res = {};
    ids.map(key => { res[key] = [] });
    return res;
  }

  const filterAccordingToType = (type, filterValue, value) => {
    switch (parseInt(type)) {
      case window.LIST: case window.CHECKBOX: case window.RADIO_BUTTON: case window.ROWGENERATOR: case window.LIST_ORGANISATIONAL_UNITS:
      case window.LIST_STATIC_TYPE:
        return filterValue.length > 0 && value != '' ? (filterValue.map(keyObj => { return keyObj['label'] }).indexOf(value) !== -1 ? 1 : 0) : 1;
        break;
      case window.DATEFIELD:
        return 1;
        break;
      default:
        return value !== '' && filterValue !== '' && filterValue !== null ? (filterValue.localeCompare(value) !== -1 ? 1 : 0) : 1;
        break;
    }
  }

  const filterTheData = (singleRowObj, filterKeys, filterObj) => {
    return (filterKeys.map(key => {
      return filterAccordingToType(filterObj[key]['type'], filterObj[key]['filter'], singleRowObj[key]);
    })).indexOf(0) === -1 ? 1 : 0;
  }
  const getDateNameBySelectedFilter = (type, dateValue) => {
    dateValue = dateValue.split(' ');
    dateValue = new Date(dateValue[0].split("-").reverse().join("-"));
    switch (parseInt(type)) {
      case window.CUSTOM_REPORT_DAY:
        return Days[dateValue.getDay()] + '(' + dateValue.getFullYear() + ')'
        break;
      case window.CUSTOM_REPORT_MONTH:
        return Months[dateValue.getMonth()] + '(' + dateValue.getFullYear() + ')';
        break;
      case window.CUSTOM_REPORT_YEAR:
        return dateValue.getFullYear();
        break;
      case window.CUSTOM_REPORT_WEEK:
        return `Week ${CommonAggregationFunc.getWeekNumber(dateValue)}(${dateValue.getFullYear()})`;
        break;
      default:
        return dateValue;
        break;
    }
  }
  const getElementValueByTypeForLabel = (type, id, value, labelKeyObj) => {
    switch (parseInt(type)) {
      case window.DATEFIELD:
        return value !== '' ? getDateNameBySelectedFilter(labelKeyObj['filter'], value) : value;
        break;
      default:
        return value;
        break;

    }
  }
  const addRemainingLabelList = (tempLabelId, tempLabelObj, tableData, subListValArray, firstValueId) => {
    if (subListValArray !== 0 && tableData.length !== 0) {
      let filterData = tempLabelObj['filter'].length > 0 ?
        tempLabelObj['filter'].map(key => { return key['label'] }) : [];
      subListValArray = filterData.length > 0 ? subListValArray.filter(key => { return filterData.indexOf(key) !== -1 ? 1 : 0 }) :
        subListValArray;
      let firstLabelIdValArr = subListValArray.length > 0 ? tableData.map(keyObj => { return keyObj[tempLabelId] }) : [];
      subListValArray = subListValArray.filter(subVal => { return firstLabelIdValArr.indexOf(subVal) === -1 ? 1 : 0 });
      if (subListValArray.length > 0) {
        subListValArray.map(subVal => { tableData.push({ [tempLabelId]: subVal, [firstValueId]: '' }); })
      }
      return tableData;
    } else {
      return tableData;
    }
  }

  const getChartData = (submitIds, listOrNot) => {
    let tempLabelArray = listOrNot !== 1 ? intializeEmptyArr(labelIds) : { [labelIds[0]]: [] };
    let tempValueArray = listOrNot !== 1 ? intializeEmptyArr(valueIds) : { [valueIds[0]]: [] };
    let generatedRowArray = [];
    let tableData = [];
    let firstLabelSubList = subListData[labelObj[labelIds[0]]['id']] !== undefined ?
      Object.keys(subListData[labelObj[labelIds[0]]['id']]).map(key => { return subListData[labelObj[labelIds[0]]['id']][key]['name'] })
      : [];
    if(sortedTableData && sortedTableData.length) {
       if(!parseInt(includeFalseValues)){
         tableData = CommonAggregationFunc.removeEmptyRows(sortedTableData);
         CommonAggregationFunc.removeEmptyRows(tableData, tempLabelArray);
         CommonAggregationFunc.removeEmptyRows(tableData, tempValueArray);
       }
       return { 'label_array': tempLabelArray, 'value_array': tempValueArray, 'table_data': tableData };
    }
    submitIds.map(id => {
      let mainObj = submitDetails[id];
      let tempObj = submitDetails[id]['webElementObj'];
      let singleRowObj = {};
      let value = 0;
      if (listOrNot !== 1) {
        labelIds.map(key => {
          if(labelObj[key]['type'] == window.ROWGENERATOR){
            let childArray = parentWithChildElements[labelObj[key]['id']] ? parentWithChildElements[labelObj[key]['id']] : [];
            rowIterationCount = childArray.length > rowIterationCount ? childArray.length : rowIterationCount;
          }
          value = parseInt(labelObj[key]['islist']) == 2 ?
            (mainObj[parseInt(labelObj[key]['id'])] !== undefined ? mainObj[parseInt(labelObj[key]['id'])] : '') :
            (tempObj[parseInt(labelObj[key]['id'])] !== undefined ? getElementValueByTypeForLabel(labelObj[key]['type'], labelObj[key]['type'], tempObj[parseInt(labelObj[key]['id'])], labelObj[key]) : '');
	           value = labelObj[key]['type'] == window.DECIMALFIELD ? replaceString(value, ',', '.') : value;
	           tempLabelArray[key].push(value)
             singleRowObj[key] = value
        });
      }
      if (listOrNot !== 1) {
        valueIds.map(key => {
          value = tempObj[parseInt(valueObj[key]['id'])] !== undefined ? tempObj[parseInt(valueObj[key]['id'])] : 0
	    value = valueObj[key]['type'] == window.DECIMALFIELD ? replaceString(value, ',', '.') : value;
            tempValueArray[key].push(value)
            singleRowObj[key] = value;
        });
      } else {
        [valueIds[0]].map(key => {
          value = tempObj[parseInt(valueObj[key]['id'])] !== undefined ? tempObj[parseInt(valueObj[key]['id'])] : 0
          if (firstLabelSubList.indexOf(value) !== -1) {
            tempValueArray[key].push(value);
            tempLabelArray[labelIds[0]].push(value);
            singleRowObj[key] = value
            singleRowObj[labelIds[0]] = value
          }
        });
      }
      generatedRowArray = getGeneratedRowsData(singleRowObj, tempLabelArray, tempValueArray, tempObj, generatedRowArray);
      generatedRowArray.map(singleObj => {
        if (filterTheData(singleObj, listOrNot !== 1 ? labelIds : [labelIds[0]], labelObj) === 1) {
          tableData.push(singleObj);
        }
      })
      generatedRowArray = [];
    });
    if(!parseInt(includeFalseValues)){
      tableData = CommonAggregationFunc.removeEmptyRows(tableData);
      CommonAggregationFunc.removeEmptyRows(tableData, tempLabelArray);
      CommonAggregationFunc.removeEmptyRows(tableData, tempValueArray);
    }
    tableData = listOrNot === 1 ? addRemainingLabelList(labelIds[0], labelObj[labelIds[0]], tableData, firstLabelSubList, valueIds[0]) : tableData;
    return { 'label_array': tempLabelArray, 'value_array': tempValueArray, 'table_data': tableData };
  }

  const singleLabelValueArrange = (rowLength, tempLabelKeys, tempValueKeys, tableData) => {
    let singleLabelObjRes = {};
    for (let i = 0; i < rowLength; i++) {
      singleLabelObjRes[tableData[i][tempLabelKeys[0]]] = singleLabelObjRes[tableData[i][tempLabelKeys[0]]] !== undefined ?
        singleLabelObjRes[tableData[i][tempLabelKeys[0]]] : {};
      tempValueKeys.map(valueKey => {
        if (singleLabelObjRes[tableData[i][tempLabelKeys[0]]][valueKey] !== undefined) {
          singleLabelObjRes[tableData[i][tempLabelKeys[0]]][valueKey].push(tableData[i][valueKey]);
        } else {
          singleLabelObjRes[tableData[i][tempLabelKeys[0]]][valueKey] = [tableData[i][valueKey]];
        }
      })
    }
    return singleLabelObjRes;
  }


  const multiLabelValueArrange = (rowLength, tempLabelKeys, tempValueKeys, tableData) => {
    let multiLabelObjRes = {};
    for (let i = 0; i < rowLength; i++) {
      multiLabelObjRes[tableData[i][tempLabelKeys[0]]] = multiLabelObjRes[tableData[i][tempLabelKeys[0]]] !== undefined ?
        multiLabelObjRes[tableData[i][tempLabelKeys[0]]] : {};
      multiLabelObjRes[tableData[i][tempLabelKeys[0]]][tableData[i][tempLabelKeys[1]]] = multiLabelObjRes[tableData[i][tempLabelKeys[0]]][tableData[i][tempLabelKeys[1]]] !== undefined ? multiLabelObjRes[tableData[i][tempLabelKeys[0]]][tableData[i][tempLabelKeys[1]]] : {};
      tempValueKeys.map(valueKey => {
        if (multiLabelObjRes[tableData[i][tempLabelKeys[0]]][tableData[i][tempLabelKeys[1]]][valueKey] !== undefined) {
          multiLabelObjRes[tableData[i][tempLabelKeys[0]]][tableData[i][tempLabelKeys[1]]][valueKey].push(tableData[i][valueKey]);
        } else {
          multiLabelObjRes[tableData[i][tempLabelKeys[0]]][tableData[i][tempLabelKeys[1]]][valueKey] = [tableData[i][valueKey]];
        }
      })
    }
    return multiLabelObjRes;
  }

  const arrangeTableColumn = (tempLabelIds, tempValueIds) => {
    let resultColumn = [];
    tempLabelIds.map(key => { resultColumn.push({ name: labelObj[key]['custom_name'], key: key, resizable:true, sortable: false }) });
    tempValueIds.map(key => { resultColumn.push({ name: valueObj[key]['custom_name'], key: key, resizable:true, sortable: false }) });
    return resultColumn;
  }

  const getArrangedData = (data, tempLabelKeys, tempValueKeys, chartValueAggregate) => {
    let labelData = intializeEmptyArr(tempLabelKeys);
    let valueData = intializeEmptyArr(tempValueKeys);
    let resultTableData = [];
    let tempObj = {};
    let totalObj = {};
    tempValueKeys.map(key => { totalObj[key] = 0 });
    if (tempLabelKeys.length > 1) {
      Object.keys(data).map(key1 => {
        Object.keys(data[key1]).map(key2 => {
          tempObj[tempLabelKeys[0]] = key1;
          tempObj[tempLabelKeys[1]] = key2
          labelData[tempLabelKeys[0]].push(key1);
          labelData[tempLabelKeys[1]].push(key2);
          tempValueKeys.map(valueKey => {
            let valueRes = CommonAggregationFunc.commonAggregationFunc(chartValueAggregate[valueKey], data[key1][key2][valueKey]);
            tempObj[valueKey] = valueRes;
            totalObj[valueKey] += parseInt(valueRes);
            valueData[valueKey].push(valueRes);
          })
          resultTableData.push(tempObj);
          tempObj = {};
        });
      })
    } else {
      Object.keys(data).map(key1 => {
        tempObj[tempLabelKeys[0]] = key1;
        labelData[tempLabelKeys[0]].push(key1);
        tempValueKeys.map(valueKey => {
          let valueRes = CommonAggregationFunc.commonAggregationFunc(chartValueAggregate[valueKey], data[key1][valueKey]);
          tempObj[valueKey] = valueRes;
          totalObj[valueKey] += parseInt(valueRes);
          valueData[valueKey].push(valueRes);
          //tempObj[valueKey] = data[key1][valueKey];
          //valueData[valueKey].push(data[key1][valueKey]);
        })
        resultTableData.push(tempObj);
        tempObj = {};
      });
    }
    if (parseInt(total) === 1 && resultTableData.length > 0) {
      // totalLabelKey = tempLabelKeys[0];
      totalObj[tempLabelKeys[0]] = 'Total';
      resultTableData.push(totalObj);
    }
    return { labelData: labelData, valueData: valueData, resultTableData: resultTableData, resultColumnData: arrangeTableColumn(tempLabelKeys, tempValueKeys) };
  }

  const getCalcultedData = (labelArray, valueArray, tableData, chartValueAggregate) => {
    let tempLabelKeys = Object.keys(labelArray);
    let tempValueKeys = Object.keys(valueArray);
    let rowLength = tempLabelKeys.length > 0 ? tableData.length : 0;
    if (tempLabelKeys.length > 1) {
      return getArrangedData(multiLabelValueArrange(rowLength, tempLabelKeys, tempValueKeys, tableData), tempLabelKeys, tempValueKeys, chartValueAggregate);
    } else {
      return getArrangedData(singleLabelValueArrange(rowLength, tempLabelKeys, tempValueKeys, tableData), tempLabelKeys, tempValueKeys, chartValueAggregate);
    }
  }
  const getArrayOfGivenNumber = (num) => {
    let i = 0;
    let res = [];
    while (i < num) {
      res.push(i);
      i++;
    }
    return res;
  }

  const getChart = () => {
    if (fromDate !== '' && toDate !== '' && labelIds.length > 0 && valueIds.length > 0 && Object.keys(submitDetails).length > 0) {
      let chartValueAggregate = {};
      let chartValueColor = [];
      let chartValueName = [];
      let tempFilterObj = {};
      Object.keys(filterObj).map(key => { tempFilterObj[key] = filterObj[key].map(value => { return value['value'] }) });
      let labelIsList = labelIds.map(key => { return parseInt(labelObj[key]['type']) }).indexOf(70) !== -1 ? 1 : 0;
      let tempLabelIds = labelIds.filter(key => { return labelObj[key]['only_filter'] === 0 ? 1 : 0 });
      let tempValueIds = labelIsList !== 1 ? valueIds.filter(key => { return valueObj[key]['hide_from_graph'] === 0 ? 1 : 0 }) : [valueIds[0]];
      valueIds.map(key => { chartValueAggregate[key] = valueObj[key]['value_settings'] });
      tempValueIds.map((key, index) => {
        // chartValueColor.push(valueObj[key]['color']);
        chartValueColor.push(colors[index]);
        chartValueName.push(valueObj[key]['custom_name']);
      });
      let submitIds = getDetailsWithinDates();
      if (submitIds.length > 0) {
        let labelValueArray = getChartData(submitIds, labelIsList);
        let resultData = getCalcultedData(labelValueArray['label_array'], labelValueArray['value_array'], labelValueArray['table_data'], chartValueAggregate);
        // if(sortedTableData && !sortedTableData.length){ sortedResultData = resultData }
        // else { resultData = {...resultData, labelData: sortedResultData['labelData'], valueData: sortedResultData['valueData'] } }
        let labelLengthArray = tempLabelIds.length > 0 ? getArrayOfGivenNumber(resultData['labelData'][tempLabelIds[0]].length) : [];
        let filteredIndex = Object.keys(filterObj).length > 0 ? labelLengthArray.filter(i => {
          return tempLabelIds.map(key => {
            return (tempFilterObj[key] && tempFilterObj[key].length > 0) ? tempFilterObj[key].indexOf(resultData['labelData'][key][i]) !== -1 ? 1 : 0 : 1
          }).indexOf(0) === -1 ? 1 : 0
        }) : labelLengthArray;
        return (<div>
          {props.disableFields !== 1 || (props.disableFields === 1 && props.accessChecked === 1) ? tempLabelIds.map((key) => {
            return getFilterDropDown('filterObj', filterObj[key] !== undefined ? filterObj[key] : [],
              resultData['labelData'][key].map(key => { return { label: key, value: key } }), key)
          }) : null}
          {parseInt(showGraph) === 1 && <CommonChartComponent
            id={'chartFormPlot1'}
            chartType={chartType['value']}
            chartLabel={tempLabelIds.map(key => {
              return resultData['labelData'][key].filter((key1, index) => {
                return filteredIndex.indexOf(index) !== -1 ? 1 : 0
              })
            })}
            chartValue={tempValueIds.map(key => {
              return resultData['valueData'][key].filter((key1, index) => {
                return filteredIndex.indexOf(index) !== -1 ? 1 : 0
              })
            })}
            chartValueName={chartValueName}
            chartValueColor={chartValueColor}
            chartValueAggregate={chartValueAggregate}
            chartTitle={chartTitle}
            chartXTitle={chartXTitle}
            chartYTitle={chartYTitle}
            labelIds={tempLabelIds}
            valueIds={tempValueIds}
            xLegendPos={xLegendPos}
            yLegendPos={yLegendPos}
            hideLegend={hideLegend}
            activeTab={activeTab}
            style={{
              width: '100%',
              height: '100%'
            }} />}
          {parseInt(showTable) === 1 &&
            <TableComponent
              columns={resultData['resultColumnData']}
              rows={resultData['resultTableData']}
              handleSort = {handleSort}
            />}</div>);
      } else {
        return <div>{t('No data')}</div>
      }
    }
  }

  //------------------------------ROW-GENERATOR-RELATED-CODE---------------------------------------------------//
  const getGeneratedRowsData = (singleRowObj, tempLabelArray, tempValueArray, submitData, generatedRowArray) => {
    let lableOrValueObj = {};
    generatedRowArray = [...generatedRowArray, singleRowObj];
    for (let i = 0; i < checkRowGeneratorElementOrNot(); i++) {
      let generatedRowSingleObj = {};
      Object.keys(singleRowObj).map(key => {
        lableOrValueObj = labelObj[key] ? labelObj[key] : valueObj[key] ? valueObj[key] : {};
        let parentEleId = lableOrValueObj['id'] ? parseInt(lableOrValueObj['id']) : 0;
        let childEleId = (parentWithChildElements[parentEleId] && parentWithChildElements[parentEleId][i]) ? parentWithChildElements[parentEleId][i] : 0;
        let value = submitData[childEleId] !== undefined ? submitData[childEleId] : '';
        value = lableOrValueObj['type'] == window.DECIMALFIELD ? replaceString(value, ',', '.') : value;
        value = key.includes('-L') ? getElementValueByTypeForLabel(lableOrValueObj['type'], lableOrValueObj['type'], value, lableOrValueObj) : value;
            generatedRowSingleObj[key] = value;
            if (key.includes('-L'))
              tempLabelArray[key].push(value)
            else
              tempValueArray[key].push(value)
        return 1;
      })
      if(!isEmpty(generatedRowSingleObj)) generatedRowArray = [...generatedRowArray, generatedRowSingleObj];
    }
    return generatedRowArray;
  }

  const checkRowGeneratorElementOrNot = () => {
    let isLabelRow = labelIds.filter(key => !parentWithChildElements[labelObj[key]['id']]);
    let isValueRow = valueIds.filter(key => !parentWithChildElements[valueObj[key]['id']]);
    return !isValueRow.length && !isLabelRow.length ? rowIterationCount : 0;
  }

  const replaceString = (string = '', character = '', replaceWith = '') => {
    string = string + '';
    return string.replace(character, replaceWith);
  }

  const handleSort = (initialRows, sortColumn, sortDirection) => {
    // let [sortableData, totalObj] = [[],[]];
    // if(totalLabelKey){
    //   sortableData = initialRows.filter(val => val[totalLabelKey] && val[totalLabelKey] !== 'Total');
    //   totalObj = initialRows.filter(val => val[totalLabelKey] && val[totalLabelKey] === 'Total');
    //   totalObj = [totalObj.pop()];
    // }
    const comparer = (a, b) => {
       if (sortDirection === "ASC") {
	  return a[sortColumn] > b[sortColumn] ? 1 : -1;
       } else if (sortDirection === "DESC") {
	  return a[sortColumn] < b[sortColumn] ? 1 : -1;
       }
     };
   setState({...state, sortedTableData: sortDirection === "NONE" ? initialRows : [...initialRows].sort(comparer) });
  }

  //------------------------------------ **** ---------------------------------------------------//

  const disableDateField = Object.keys(dateSelect).length > 0 && parseInt(dateSelect['value']) !== window.FROM_TO_DATE ? 1 : 0;
  const showXYtitle = Object.keys(chartType).length > 0 && parseInt(chartType['value']) !== window.PIE_CHART_TYPE ? 1 : 0;
  return (
    <div>
      <div className='py-10' style={{ marginTop: '10px' }}>
        <div className='row'>
          <div className='col-md-9'>
            {getChart()}
          </div>
          <div className='col-md-3' style={{ float: 'right' }}>
            {props.disableFields !== 1 && <div>{getTextField('Chart name', 'chartName', chartName)}</div>}
            <div> {getDropDownField('Filter by datefield', 'dateFieldFilter', dateFieldFilter, dateListOptions, 1, 0, 1)} </div>
            <div className="filterbydate">{getDropDownField('', 'dateSelect', dateSelect, dateOption, 0, 1, 1)}</div>
            <div>{getDateField('', 'fromDate', fromDate, 1, disableDateField)}</div>
            <div>{getDateField('', 'toDate', toDate, 1, disableDateField)}</div>
            {props.disableFields !== 1 && <>
            <div className='row'>
              {props.disableFields !== 1 && <div className='col-md-12 mt-2 mb-0 row pr-0'>
                 <div className="col-md-3 pr-0">
                     <label className="pt-1" id="basic-addon1">{t('Done')}</label>
                 </div>
                 <div className="col-md-9 p-0">
                    {getDropDownField('Done', 'done', done, window.ALL_YES_NO, 0, 0, 0)}
                 </div>
                 <div className="col-md-12 pr-0">
                   {getCheckBox('Include false values', 'includeFalseValues', includeFalseValues)}
                 </div>
              </div>}
              <div className="col-md-6 pr-0">
                {getCheckBox('Show graph', 'showGraph', showGraph)}
              </div>
              <div className="col-md-6 p-0">
                {getCheckBox('Show table', 'showTable', showTable)}
              </div>
            </div>
            <div className='row'>
              {props.disableFields !== 1 && <div className='col-md-8 pr-0'>
                {getCheckBox('Lock date settings', 'lockFilter', lockFilter)}
              </div>}
              {parseInt(showTable) === 1 && <div className='col-md-6'>
                {getCheckBox('Total', 'total', total)}
              </div>}
            </div>
            {parseInt(showGraph) === 1 && <div className="filterbydate" >
              {getDropDownField('Select chart', 'chartType', chartType, window.WEBFORMREPORTTYPES, 0, 0, 0)}
            </div>}
            {parseInt(showGraph) === 1 && <div>{getTextField('Title', 'chartTitle', chartTitle)}</div>}
            {parseInt(showGraph) === 1 && <div>{showXYtitle == 1 && getTextField('X-title', 'chartXTitle', chartXTitle)}</div>}
            {parseInt(showGraph) === 1 && <div>{showXYtitle == 1 && getTextField('Y-title', 'chartYTitle', chartYTitle)}</div>}
            {parseInt(showGraph) === 1 && <div>{getCheckBox('Hide legend', 'hideLegend', hideLegend)}</div>}
            {parseInt(showGraph) === 1 && parseInt(hideLegend) !== 1 &&
              <div className='col-md-12 row'> {getNumberField('xLegendPos', xLegendPos)}{getNumberField('yLegendPos', yLegendPos)} </div>}
            </>}
          </div>
        </div>
      </div>
    </div>
  );
}
export default translate(ChartForm);

function isEmpty(obj) {
    for(var key in obj) {
        if(obj.hasOwnProperty(key))
            return false;
    }
    return true;
}
