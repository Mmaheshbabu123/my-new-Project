import { datasave } from '../../../_services/db_services'
export const run = {
    OnchangeQueryelement,
    onLoadQueryCheck,
    getDataForExecuteQueryOnchangeApi
};
let stateObj ={}
let queryobj = {}
let elementtype = ''
let onchangeid = '';
let sublistswithname ={};
let finalobj = {
  status:401,
  result:undefined,
  targetid:undefined,
  exception:undefined,
};
let targetid = ''
var calculations = ''
let submitidtopost = 0;
let parentidtopost = 0;
var deeplinkedquerys = [];
var domVisibleElements = 0;
var domVisibleElementCount = 0;

/** Queryelement
 * Params statevalues from simulation page, queryelementobj , on change element id
 * get execute element query if added and
 * TYPE = 1 i,e  to differenciate onchange query or on load query
 * return query result based on element type
 * Developed  by 0157 start time(23-1-2020)
 */
async function OnchangeQueryelement(statedata,queryelementobj,onchangeelementid,elementcategory= undefined,objforquery,sublists, submitid, parentid){
  stateObj = statedata
  queryobj = queryelementobj
  onchangeid = onchangeelementid
  elementtype = elementcategory
  calculations = objforquery.calculation
  sublistswithname  = sublists
  submitidtopost = submitid
  parentidtopost = parentid
  domVisibleElements = [];

deeplinkedquerys = [];
    if(queryobj.query[onchangeid] !== undefined && queryobj.query[onchangeid].query == true){
        await checkQueryInBackend(queryobj.query[onchangeid],1);
    }else{
       finalobj = {
        status:401,
        result:undefined,
        targetid:undefined,
        exception:undefined,
      };
    }



      return finalobj
}
var chunkLength = 200;
var copyDeepLinkedIds= [];
var dbObj= [];
var dbelementIds = [];
let webelementTypeObj = {};
/** onLoadQueryCheck(component mount)
 * Params object which contains parent id means target element to effect
 * update query result in global object
 * Developed by 0153(24-1-2020)
 */
async function onLoadQueryCheck(statedata,queryelementobj,fullstatedata,submitid, parentid, dbIds = [], typeObj = {}, loadedElement = []){

  stateObj = statedata
  queryobj = queryelementobj
  sublistswithname = fullstatedata
  submitidtopost = submitid
  parentidtopost = parentid
  deeplinkedquerys = [];
  domVisibleElements = loadedElement
  domVisibleElementCount = loadedElement.length;
  dbelementIds = dbIds;
  webelementTypeObj = typeObj;

  if(dbelementIds.length){
    await checkQueryInBackend(queryelementobj, 3)
  }else{

    await filterdata();
    // let combined = [...queryelementobj.targetids,...queryelementobj.nosourceids];
    // findparentids(combined)
    // let deeplinkedquerysTemp = checkStateExists(deeplinkedquerys)
    // if(queryelementobj.targetids.length < chunkLength && queryelementobj.nosourceids.length < chunkLength && deeplinkedquerysTemp.length < chunkLength) {
      // let querywithsource  = queryelementobj.targetids
      // let querynosource  =  queryelementobj.nosourceids
      // copyDeepLinkedIds = deeplinkedquerysTemp;
      if(nosourceidsLatest.length >0|| sourceidsLatest.length >0){
        await checkQueryInBackend(queryelementobj,2)
      }
      // } else{
        //   let nosourceidsTemp = splitArrayIntoChunks(queryelementobj.nosourceids)
        //   let sourceidsTemp = splitArrayIntoChunks(queryelementobj.targetids)
        //   deeplinkedquerysTemp = splitArrayIntoChunks(deeplinkedquerysTemp)
        //   await runOnLoadQueryChunkWise(nosourceidsTemp, 0, queryelementobj);
        //   await runOnLoadQueryChunkWise(sourceidsTemp, 1, queryelementobj);
        //   await runOnLoadQueryChunkWise(deeplinkedquerysTemp, 2, queryelementobj);
        // }
  }

    return finalobj
}

async function runOnLoadQueryChunkWise(array, type, data){
  let copyData = Object.assign({}, data);
  for (var i = 0; i < array.length; i++) {
    let chunk = array[i];
    copyData = updatepostData(copyData, chunk, type)
    if(chunk.length) {
      await checkQueryInBackend(copyData,2)
    }
  }
}

function updatepostData(data, chunk, type){
  if(type === 0){
    data['nosourceids'] = chunk;
    data['targetids'] = [];
    copyDeepLinkedIds = [];
  }
  if(type === 1) {
    data['nosourceids'] = [];
    data['targetids'] = chunk;
    copyDeepLinkedIds = [];
  }
  if(type === 2) {
    data['targetids'] = [];
    data['nosourceids'] = [];
    copyDeepLinkedIds = chunk;
  }
  return data;
}

async function getDataForExecuteQueryOnchangeApi(statedata,queryelementobj,fullstatedata,submitid, parentid){
    stateObj = statedata
  queryobj = queryelementobj
  sublistswithname = fullstatedata
  submitidtopost = submitid
  parentidtopost = parentid
  deeplinkedquerys = [];
    let querywithsource  = queryelementobj.targetids
  let querynosource  =  queryelementobj.nosourceids
    await filterdata();
   if(querynosource.length >0|| querywithsource.length >0){
    return await getDataToPost(queryelementobj, 2)
    }else{
    return finalobj;
    }

}

/** checkQueryInBackend
 * Params object which contains parent id means target element to effect , type = 1 0r 2 (1 =>i,e on chnage 2=> on load )
 * update query result in global object
 * Developed by 0153(24-1-2020)
 */
 async function checkQueryInBackend(obj,type){
   // let latestObj = type === 2 ? checkOnlyForVisibleElements(obj, domVisibleElements) : obj;
    let arrangedData = await getDataToPost(obj, type);
    if(type === 3 && arrangedData.linkedIds.length === 0) return;
      await datasave.service(window.EXECUTE_QUERY, 'POST', arrangedData).then(async Response=>{
              await checkStatusAndSendObj(Response,type)
          })
}
/** checkStatusAndSendObj
 * Params response from api i,e executed query result,
 * return array
 * Developed by 0153(24-1-2020)
 */
function checkStatusAndSendObj(response,type){
  // if(type === 2){
  //   assignStateObj(response);
  // }

      finalobj.result = response['data']
      finalobj.status = response['status'];
    if(type == 2){
      return
    }
  let backendresponse = '',queryresult = '';
      if(response['status'] === 200){
          backendresponse = response['data'];
          queryresult = backendresponse
      }
        finalobj = {
          status:response['status'],
          result:queryresult,
          targetid:targetid,
          exception: response['status'] === 500 ? response['msg']:undefined
        }
}

function assignStateObj(data){
  if(data['status'] === 200){
    stateObj = {...stateObj, ...data['data']['post']}
    dbObj = {...dbObj, ...data['data']['db']}
  }
}

/** checkStatusAndSendObj
 * Params response from response from backend i,e executed query result,
 * return array
 * Developed by 0153(24-1-2020)
 */
 async function getDataToPost(obj,type){
    let postdata = {}
      if(type === 1){
          let elements = {};  Object.values(calculations).map(item=>{ return elements[item.id] = item.type})
       let query  =  await createobjTopost(obj)
          postdata = {
             query:query,
             source:obj.addedids,
             state:stateObj,
             type:type,
             elements:elements,
             queryobj:queryobj,
             sublists:sublistswithname,
             deeplinkedquerys:deeplinkedquerys,
             submitid:submitidtopost,
             parentid:parentidtopost,
           }
      }else if (type === 3) {
        postdata = postDataForDblistElements(obj);
      } else {
        let combined = [...sourceidsLatest,...nosourceidsLatest];
                findparentids(combined)
                let deeplyLinkedIds = checkStateExists(deeplinkedquerys);
                postdata  ={
                  queryobj:obj,
                  state:stateObj,
                  type:type,
                  fullobj: sublistswithname,
                  submitid:submitidtopost,
                  parentid:parentidtopost,
                  deeplinkedquerys: domVisibleElementCount ? domVisibleElements.filter(id => deeplyLinkedIds.includes(id)) : deeplyLinkedIds,
                  webelementTypeObj: webelementTypeObj,
                }
      }


      return postdata
}
function createobjTopost(obj){
    let parentids = Object.values(obj.parentid)
     let queries = queryobj.combined
     let fianlquery = {};
     findparentids(parentids);
      parentids.map(id =>{
              return fianlquery[id] =  queries[id].json_query
      })

    return  fianlquery
}
function findparentids(ids){
  let queries = queryobj.combined
    ids.map(id=>{
      Object.values(queries).map(item=>{
        if(item.addedids.includes(id) && !deeplinkedquerys.includes(id)){
            deeplinkedquerys.push(item.target);
	if (item.target != id) {
            checkRecuesively(item.target);
	}
        }
      })
    })
}
function checkRecuesively(target){
  let queries = queryobj.combined
  Object.values(queries).map(item=>{
    if(item.addedids.includes(target) && !deeplinkedquerys.includes(item.target)){
        deeplinkedquerys.push(item.target);
        checkRecuesively(item.target);
    }
  })
}

let nosourceidsLatest = [];
let sourceidsLatest = [];
function filterdata(){
     queryobj.nosourceids  = checkStateExists(queryobj.nosourceids);
     queryobj.targetids  = checkStateExists(queryobj.targetids);
     nosourceidsLatest = domVisibleElementCount ? domVisibleElements.filter(id => queryobj.nosourceids.includes(id)) : queryobj.nosourceids;
     sourceidsLatest   = domVisibleElementCount ? domVisibleElements.filter(id => queryobj.targetids.includes(id)) : queryobj.targetids;
}

function checkStateExists(ids, takeDb = 1){
 let obj = queryobj.combined;
  let state = stateObj;
  let newids = [];
  let type ='';
  ids.map(id=>{
    type = obj[id]['type'];
      if (type == window.DATEFIELD) {
            newids.push(id)
      }
      if(type == window.TEXTFIELD || type  == window.TEXTBOX){
          if(state[id] == undefined || state[id] == ""){
            newids.push(id)
         }
      }
      /* For decimal fields sometimes value it self less than 0**/
      if(type == window.DECIMALFIELD || type == window.NUMERICFIELD){
        //|| (state[id] && parseInt(state[id].replace(',', '')) === 0)
        if(state[id] == undefined || state[id] == "") {
          newids.push(id)
        }
      }
      /*For multiselect db it is either empty or unset in state by defualt i,e not from db **/
      if(type == window.DATABASELIST || type == window.DATABASELIST_MULTISELECT){
        if(takeDb === 1 || state[id] == undefined || state[id] == "" || state[id].length == 0 ||  state[id]['label'] == 'select' || state[id]['label'] == 'Select'){
          newids.push(id)
        }
      }
  })
  return newids;
}

function splitArrayIntoChunks(array){
  var i,j, temporary = [];
  for (i = 0, j = array.length; i < j; i += chunkLength) {
    temporary.push(array.slice(i, i + chunkLength));
  }
  return [...new Set(temporary)];
}


function checkOnlyForVisibleElements(queryData, filterIds = [], type = 2){
  let queryDup = {...queryData}
  queryDup['nosourceids'] = [];
  if(filterIds.length){
    var combinedLatest = {}
    var queryLatest = {}
    filterIds.map(ele => {
      if(queryDup['combined'][ele]) {
        combinedLatest[ele] = queryDup['combined'][ele];
        queryDup['nosourceids'].push(ele)
      }
      if(queryDup['query'][ele])
        queryLatest[ele] = queryDup['query'][ele];
    })
    queryDup['combined'] = combinedLatest;
    queryDup['query'] = queryLatest;
    queryDup['nosourceids'] = type !== 3 ? nosourceidsLatest : queryDup['nosourceids'];
    queryDup['targetids'] = type !== 3 ? sourceidsLatest : [];
  }
  return queryDup;
}


function postDataForDblistElements(obj){
  // let parentDbids = [];
  // dbelementIds.map(id => {
  //   if(obj.query[id] && obj.query[id]['parentid'])
  //     parentDbids = [...parentDbids, ...obj.query[id]['parentid']]
  // })
  findparentids(dbelementIds)
  let deeplyLinkedIds = checkStateExists(deeplinkedquerys, 0);
  let dbQueryObj = checkOnlyForVisibleElements(obj, [...dbelementIds, ...deeplyLinkedIds], 3)
  dbQueryObj['nosourceids'] = checkStateExists(dbQueryObj['nosourceids'], 0);
  return {
    queryobj:dbQueryObj,
    state:stateObj,
    type:2,
    fullobj: sublistswithname,
    submitid:submitidtopost,
    parentid:parentidtopost,
    linkedIds: (dbQueryObj['nosourceids'].length || deeplyLinkedIds.length) ? 1 : 0,
    deeplinkedquerys: deeplyLinkedIds,
    webelementTypeObj: webelementTypeObj
  }
}
