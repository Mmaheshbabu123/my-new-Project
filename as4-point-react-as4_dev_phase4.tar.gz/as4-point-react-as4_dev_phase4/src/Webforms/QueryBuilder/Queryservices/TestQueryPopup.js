import { translate } from '../../../../src/language'
import React from 'react'
import * as Reactbootstrap from 'react-bootstrap'

class TestQueryPopUp extends React.Component{
    constructor(props) {
        super(props)
        this.initialState()
    }
    initialState =()=>{
        this.state ={
            showpop : false,
            t:this.props.t,
            stringquery:'',
            queryvalues:this.props.filteredobj ? Object.keys(this.props.filteredobj).reduce((acc,curr)=> (acc[curr]=null,acc),{}) : {},
        }
    }
    async componentDidMount(){
             let data = await this.alterReadOnlyQueryEdit()
        this.setState({stringquery:data})
    }
    handleInput(e){
        const {name, value} = e.target
        this.state.queryvalues[name] = value ? value: null;
    }
    handleTestClick(e){
         this.props.testquery(this.alterReadOnlyQueryEdit())
    }
    render(){
        return(
                <>
                {this.displayPopup()}
                </>
        )
      }
      displayPopup =()=>{
        return(
            <Reactbootstrap.Modal show={true}>
                <Reactbootstrap.Modal.Body>
                    {this.createBodyContent()}
                </Reactbootstrap.Modal.Body>
            </Reactbootstrap.Modal>
        )
      }
      createBodyContent =()=>{
          const {t}=  this.state
            let obj = this.props.filteredobj;
            let buttons = (
                    <>
                    <Reactbootstrap.Button variant="outline-info" onClick = {(e)=> this.handleTestClick(e)}>Test query</Reactbootstrap.Button>
                    <a  className="mr-3" style={{ float: 'right',paddingTop: '7px' }} href="#"   onClick = {()=>this.props.cancel()} > {t("Cancel")} &nbsp;&nbsp;&nbsp; </a> &nbsp;&nbsp;&nbsp;
                    </>
                )
          let html =(
          <div className=" col-md-12 mt-4 btnn">
            <Reactbootstrap.Form>
            {
                Object.values(obj).map( item=> {
             return(
                <Reactbootstrap.Form.Group as='Row' controlId="formPlaintextPassword">
                        <Reactbootstrap.Form.Label column sm="12">
                        {item.name}
                        </Reactbootstrap.Form.Label>
                        <Reactbootstrap.Col sm="7">
                        <Reactbootstrap.Form.Control type="text" placeholder="value" name = {'#'+item.id+'#'} id = {item.id}  onInput ={(e)=>{this.handleInput(e)}} />
                        </Reactbootstrap.Col>
                    </Reactbootstrap.Form.Group>
                    )})
                }
            </Reactbootstrap.Form>
                    {React.createElement(
                        'div',{'className' : 'mt-3'},
                        buttons
                    )}
           </div>
          )
        return html
      }
alterReadOnlyQueryEdit = ()=>{
    const {queryvalues} =  this.state
     const {queryobj} =  this.props
                let final = this.props.stringquery
                    if(Object.keys(queryobj).length>0){
                    var RE = new RegExp(Object.keys(queryvalues).join("|"), "g");
                    final = this.props.stringquery.replace( RE, matched => {
                            return  queryvalues[matched]
                        });
            }
            return final
    }
}
export default translate(TestQueryPopUp)
