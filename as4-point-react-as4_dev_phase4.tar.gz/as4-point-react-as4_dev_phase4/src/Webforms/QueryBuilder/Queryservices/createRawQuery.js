export const query = {
    generateQuery,
    createobject,
};
let querystring = '';
let groupbycolumns =[];
var joinedornot = false
let selectstring = '';
let fromtables = '';
let wherestring =''
let  sortedstring  = '';
var stateObj = '';
var finaltables = {};
var stringtemp = {};
function createobject(data){
    stateObj = data;
    groupbycolumns =[];
        if(Object.values(data.droppedtables).length >0){
            let id  =data.droppedtables[0]['id'];
            data.jointablesobj[id]['cid2'] = data.jointablesobj[id]['cid1']
        }

        createTableObj(data)
        createSelectObj(data)
        createfilterObj(data)
        createSortingObj(data)

            return generateQuery(finaltables)
}
function createTableObj(data){
    var tablesobj = [];
     const {tablesforquery } =  data

    joinedornot = Object.values(data.joincolumns).length >0 &&Object.values(data.tablesforquery).length>0;
             if(joinedornot){
                Object.values(tablesforquery).map(item=>{
                    if(item.jointype !== false){
                        let obj = {}
                        obj = {
                            jointype:getJoinType(parseInt(item.jointype)),
                            jointable :item.tableonname,
                            relation: getRelation(item)
                        }
                      return  tablesobj.push(obj);
                    }
                })
        }
    finaltables.table = tablesobj
    return tablesobj

}
function createSelectObj(data){
    var selectedcolumnsobj  =[];
        var columns =  Object.values(data.droppedselectedcolumns);
        var columnfunction =  data.selectedcolumnidwithvalue;
        columns.map(column=>{
            let obj ={}
             obj ={
                column:column.selectcolumn,
                function:columnfunction[column.id]
            }
          return  selectedcolumnsobj.push(obj);
        })
        finaltables.selectedcolumns = selectedcolumnsobj
    return selectedcolumnsobj;
}

function createfilterObj(data){

    var filteredobj = [];
    var columns = [];
    var obj = {};
    var filters  = Object.values(data.droppedfilteredcolumns);
    var values = data.filtercolumnidwithvalue

                filters.map(column=>{
                    let obj = {}
                    obj ={
                        name: column.selectcolumn,
                        operator:values[column.id].operator !== undefined ? values[column.id].operator:'',
                        value:values[column.id].value !== undefined?values[column.id].value:'',
                    }
                  return  columns.push(obj)
                })
            obj.columns = columns
            obj.childrens = [];
            obj.condition = parseInt(data.condition)
                filteredobj.push(obj)
            finaltables.filters = filteredobj
}
function createSortingObj(data){
    var sortingObj = [];
    var sortedcolumns = Object.values(data.droppedsortedcolumns);
    var orderby = data.sortingcolumnidwithvalue
        sortedcolumns.map(column =>{
            let obj ={}
            obj ={
                column:column.selectcolumn,
                sorting:orderby[column.id].order,
                priority:orderby[column.id].priority,
            }
          return  sortingObj.push(obj)
        })
        finaltables.sorting = sortingObj;
        return sortingObj
}

 function getTablesData(id){


    let data = {
        type:false,
        jointable:null,
        columnfrom:null,
        columnon:null,
        tableon:null
    }
      var joinedcolumns = Object.values(stateObj.joincolumns);

    Object.values(stateObj.tablesforquery).some(item=>{
        if(item.tablefrom == id){
        data ={
            type: parseInt(item.jointype),
            jointable:item.tableonname,
            tableon: parseInt(item.tableon)
            }
            return true}})
            if(data.type !== false){
        joinedcolumns.some(item=>{
            if(id == item.tableid){
                data.columnfrom = item.name
                return false
            }
            joinedcolumns.some(item=>{
                if(data.tableon == item.tableid){
                    data.columnon = item.name
                }
            })
        })
    }

return data;
}

function generateQuery(jsonobj){
    var tables =  jsonobj.table
    var selected = jsonobj.selectedcolumns
    var filters = jsonobj.filters
    var sorting = jsonobj.sorting



    generateSelectedColumns(selected)
    generatefromTables(tables)
    generatewhereString(filters)
    generatesorting(sorting)
    let groupby= generateGroupBy();

    querystring = selectstring+fromtables+wherestring+sortedstring+groupby;


return querystring


}

function generateSelectedColumns(data){
        let columns = [];
    Object.values(data).map(item =>{
                if(item.function !== false){
              return  columns.push(getColumnFunction(item.function,item.column))
                }else{
                columns.push(item.column)
                }
    })
  selectstring = 'SELECT '+columns.toString();
  if(columns.length === 0){
  selectstring = 'SELECT * '
}
}
function getColumnFunction(type,column){

    switch (type) {
        case 36:
                groupbycolumns.push(column)
            return 'MAX('+column+')'
        case 37:
                groupbycolumns.push(column)
            return 'SUM('+column+')'
        case 35:
                groupbycolumns.push(column)
            return 'MIN('+column+')'
        case 34:
                groupbycolumns.push(column)
            return 'AVG('+column+')'
        case 33:
                groupbycolumns.push(column)
            return 'COUNT('+column+')'
        case 1:
            return column
        case 38:
            return "strftime('%Y-%m', "+column+")"
        case 39:
            return "strftime('%d', "+column+")"
        case 40:
           return "strftime('%Y-%m-%d', "+column+")"
        case 41:
           return "strftime('%m', "+column+")"
        case 42:
           return "strftime('%Y',"+ column+") || ',' || ((strftime('%m',"+column+" ) * 1 + 2) / 3)"
    }
}
function generatefromTables(tables){
        let column = [];

    let string = '';
    if(joinedornot){
    Object.values(tables).map(table=>{
         string  = table.jointype+' '+table.jointable+' '+table.relation
      return  column.push(string)
    })
    string = ' from '+ stateObj.droppedtables[0]['name']+' '+column.toString().replace(/,/g,' ');
    }else{
        Object.values(stateObj.droppedtables).map(item=>{
            return column.push(item.name)
        })
        string = ' from '+column.toString().replace(/,/g,' ');
    }
    fromtables =  string
    if(column.length === 0){
        fromtables = ''
    }
}
function generatewhereString(filters){
    var columns = []; let operator = ''
    Object.values(filters).map(item=>{
        operator = item.condition === 1 ? ' AND ':' OR ';
      return   Object.values(item.columns).map(column=>{
           let string =  createColumnString(column.operator,column.name,column.value)
            return columns.push(string)
        })
    })
    let temp = '';
    columns.map((item,index)=>{
                let data  = columns.length-1 === index ? item :item+' '+operator+' '
              return  temp+= data
    })
    wherestring =   ' WHERE ('+temp+' ) ';

    if(columns.length === 0){
    wherestring =''}
}
function generatesorting(sorting){
        var sortingstring = [];
        var obj = Object.values(sorting).sort(function(a,b){
                return a.priority - b.priority
        })
        obj.map(item=>{
            let string = item.column+getSortingtype(item.sorting);
          return  sortingstring.push(string);
        })
        sortedstring = 'ORDER BY '+sortingstring.toString();
        if(sortingstring.length === 0)
            sortedstring = ''


}

function getJoinType(type){
        switch (type) {
            case 1:
               return 'INNER JOIN'
            case 2:
                return 'LEFT JOIN'
            case 3:
                return 'RIGHT JOIN'
            case 0:
                return 'NONE'

            default:
                break;
        }
}
function getSortingtype(type){
    switch (type) {
        case 1:
            return ' ASC '
        case 2:
            return ' DESC '
        default:
            return ' ASC '
    }
}
function createColumnString(type,column,value){
    switch (type) {
     case 700:
         return  column+' = '+value
      case 701:
        return  column+' != '+value
      case 702:
        return  column+' < '+value
      case 703:
        return  column+' <= '+value
      case 704:
        return column+' > '+value
      case 705:
        return column+' >= '+value
      case 706:
          let data = value.split(',');
          if(data.length ==2){
        return column+' BETWEEN '+  data[0]+' AND '+data[1]}
        return column+' BETWEEN '+ column +' AND '
      case 707:
            let data2 = value.split(',');
            if(data2.length ==2){
        return column+' NOT BETWEEN '+  data2[0]+' AND '+data2[1]}
        return column+' NOT BETWEEN '+ value +' AND '
      case 708:
          return 'NOT '+column+' LIKE '+ "'%"+value+"%'"
      case 709:
          return column+' LIKE '+ "'%"+value+"%'"
      case 710:
          return  column+" LIKE '"+value+"%'"
      case 711:
         return ' NOT '+column+" LIKE '"+value+"%'"
      case 712:
         return column+' IS NULL'
      case 713:
         return column+' IS NOT NULL'
      case 714:
         return column+' IN ('+value+')'
      case 715:
         return column+' NOT IN ('+value+')'

    }
}
function generateGroupBy(){
    let string = '';
   if(groupbycolumns.length >0){
        string = " GROUP BY ("+groupbycolumns.toString()+")";
    return string;
   }else{
    return string;
   }

}
function getRelation(item){
    const { jointablesobj,} =  stateObj;
    let string  = 'on ';
    if(jointablesobj[item.tableon] !== undefined && jointablesobj[item.tablefrom] !== undefined ){

        string +=  item.tableonname+'.'+ jointablesobj[item.tableon].cid1+'='+ item.tablefromname+'.'+jointablesobj[item.tablefrom].cid2;
    }
return string;





}
