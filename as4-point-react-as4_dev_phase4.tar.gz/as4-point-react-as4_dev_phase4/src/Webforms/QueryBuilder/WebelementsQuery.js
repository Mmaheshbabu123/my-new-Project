import { translate } from '../../language'
import React from 'react'
import * as Reactbootstrap from 'react-bootstrap'
import { datasave } from '../../_services/db_services'
import {query} from './Queryservices/createRawQuery'
import Select from 'react-select';
import { OCAlert } from '@opuscapita/react-alerts'
import TestQueryPopUp from './Queryservices/TestQueryPopup'

var FILTERS = [window.TEXTFIELD,window.NUMERICFIELD,window.DECIMALFIELD,
    window.TEXTBOX,window.LIST,window.CHECKBOX,
    window.DATEFIELD,window.RADIO_BUTTON,window.LIST_ORGANISATIONAL_UNITS, window.DATABASELIST, window.ROWGENERATOR, window.CURRENT_LANGUAGE];
var CLONEOBJFORTEST = {}
const listoperators = [
  {
     'label': "Equals",
     'value': 1,
   },
   {
     'label':"Not equals",
     'value':2,
   }
]
const SHOWOPTIONS = [window.LIST,window.CHECKBOX,window.RADIO_BUTTON];
/** WebelementsQuery
 * Developer 0154
 */
class WebelementsQuery extends React.Component {

    constructor(props) {
        super(props)
        this.initialState();
    }
    initialState = () => {
        this.state = {
            t:this.props.t,
            addToken: false,
            webelements:[],
            technicalqueryvalue:this.props.Query,
            readonlyquery:'',
            displayoptions:[],
            onlyidstring:{},
            clicked:false,
            queryresult:[],
            showduration:false,
            duration:undefined,
            objfortestquery :{},
            showpop:false,
            isLoading:false,
            selectedtoken:[],
            sublistsoptions:[],
            showAdd:false,
            onlysublistswithids:{},
            prevAddedQuery: this.props.Query,
        }
    }
    UNSAFE_componentWillMount() {

        if(this.props._webelementid !==undefined){
            this.getApiData();
        }
        if(this.props.id !== undefined && this.props.id !=='chart'){
            this.getQueryForCustomReport()
        }
    }
    getQueryForCustomReport=()=>{
      const {t} =this.state;
      if(parseInt(this.props.id) !== 0){
        datasave.service(window.GET_TECHNICAL_QUERY + '/' + this.props.id + '/' + this.props._webformid,'GET','').then( (response)=>{
          if(response['status'] === 200){
            this.setState({
              technicalqueryvalue: response['data']
            })
          }else{
            OCAlert.alertError(t(response['Msg']) , { timeOut: window.TIMEOUTNOTIFICATION });
          }
        })
      }
    }
    componentDidUpdate(prevProps) {
        if (this.props._webelementid !== undefined && this.props._webelementid !== prevProps._webelementid){
          this.setState({
            addToken: false,
            technicalqueryvalue:'',
            readonlyquery:'',
            onlyidstring:{},
            queryresult:[],
            showduration:false
          },()=>this.getQueryDataAPi(),
          )
        }
        if(this.props.setQuery !== '' && this.props.setQuery !== prevProps.setQuery ){
          this.setState({
              technicalqueryvalue:this.props.setQuery,
              readonlyquery:this.props.setQuery,
          })
        }
      }
      UNSAFE_componentWillReceiveProps(prevProps){
          // if(this.props._webelementid !== undefined){
        let string = query.createobject(this.props.parentstate)
        if(string.length > 9){
          this.setState({
              technicalqueryvalue:string,
              readonlyquery:string,
          })

          if(this.props.query2sibling !== undefined){
              this.props.query2sibling(string)
          }
          }
      }
    getApiData =()=>{
        datasave.service(window.FETCH_ALL_WEBELEMENTS+'?webform_id='+this.props._webformid,'POST').then(Response=>{
            if(parseInt(Response.status) === 200){
                const options = []; const testquery = {};
                Response.data.map(element=>{
                    if(FILTERS.includes(element.type)){
                    let obj = {}
                    obj={
                        value:element.id,
                        label:element.alias,
                        type:element.type,
                        json:element.json_data,
                    }
                    options.push(obj)
                    obj ={
                        value:element.id,
                        label:element.alias,
                        type:element.type
                    }
                    testquery['#'+element.id+'#'] = obj;
                }
                })
                this.setState({webelements:Response.data,displayoptions:options,objfortestquery:testquery},()=>this.getQueryDataAPi())
            }
        })
    }
    handleAddControl =()=>{
        this.setState({
            addToken:true,
            selectedtoken:'',
            selectedsublist:undefined,
            selectedoperator:undefined,
            sublistsoptions:undefined,
            showAdd:false
        })
    }
    handleSelectControl =(e)=>{

      if(SHOWOPTIONS.includes(e.type)){
        this.showListOptions(e)
      }else{
        this.setState({
            addToken:false,
            showAdd:false,
            selectedtoken:e},() => {this.setTokenInTextBox()})
          }
    }
    handleTechnicalQueryedit(e){
        const {value} = e.target
        let moodifiedString = this.alterReadOnlyQueryEdit(value)
        this.setState({
            technicalqueryvalue:value,
            readonlyquery:moodifiedString
        })
        if(this.props.query2sibling !== undefined){
            this.props.query2sibling(value)
        }
    }
     async handleExecuteQueryClick(e){
        e.preventDefault()
        await this.saveQueryClick(1);
        let show =  await this.showTestQuerypopup();
        show ? this.setState({showpop:true,isLoading:false}):this.setState({isLoading:true},()=>{this.getQueryResult()});
       }
       getQueryResult = (type = 1)=>{
        let data = {
            query:type === 1? this.state.readonlyquery : type,
            connection:this.props.connection
       }
       this.setState({isLoading:false})
       datasave.service(window.SHOW_RAW_QUERY_RESULT,'POST',data).then(Response=>{
                if(Response.status === 500){
                OCAlert.alertError( Response.msg , { timeOut: 10000 });
                this.setState({isLoading:false})
                }else{
                    this.setState({queryresult:Response.data, showduration:true,showpop:false,
                        duration:Response.duration,isLoading:false})
                }
       })
       }
       async saveQueryClick (fromTestQuery = 0){
        const {technicalqueryvalue,t} = this.state
         if(technicalqueryvalue.includes('as value') === false && (technicalqueryvalue.length !== 0 && technicalqueryvalue != 'null') ){
          if(technicalqueryvalue.includes('as label') === false && technicalqueryvalue.includes('as label') === false || technicalqueryvalue.includes('as value') === false ){
              OCAlert.alertWarning(t('Your query should contains as value or as value and as label for lists.'),{ timeOut: 4000});
              return
          }
         }

         let data = await this.getDataTOPost();

        if(data !== false){
           datasave.service(window.STORE_QUERY,'POST',data).then(Response=>{
               if(Response.status === 500){
                   this.setState({isLoading:false})
                   OCAlert.alertError(t('We were sorry,Internal server occured while storing') , { timeOut: window.TIMEOUTNOTIFICATION });
               }
                if(Response.status === 200){
                    if(this.props._eletype === window.ROWGENERATOR) {
                      this.setState({isLoading:false, prevAddedQuery: data.query})
                    }else{
                      this.setState({isLoading:false})
                    }
                }
                if(fromTestQuery === 0)
                  OCAlert.alertSuccess(t('Saved query.'), { timeOut: window.TIMEOUTNOTIFICATION });
           })
        }else{
        OCAlert.alertWarning
        (this.getDatatoshow(),
        { timeOut: 7000});
        }
       }
    async getDataTOPost (){
        const {technicalqueryvalue,} =  this.state
        const {connection} = this.props;
        let tempvariable  = await this.checkstringqueryelementspresentinobj();
        if(technicalqueryvalue.length === 0){
            return {
                query :technicalqueryvalue,
                destination:tempvariable,
                element :this.props._webelementid,
                webformid  :this.props._webformid,
                connection:connection,
                isQueryChanged: technicalqueryvalue !== this.state.prevAddedQuery,
                prevQuery: this.state.prevAddedQuery,
                _eletype: this.props._eletype,
                rowgeneratorWebelements: this.props.rowgeneratorEleObj[this.props._webelementid] ? this.props.rowgeneratorEleObj[this.props._webelementid] : [],
            }
        }
    if(await this.validateQuery(tempvariable)){
         return {
            query :technicalqueryvalue,
            destination:tempvariable,
            element :this.props._webelementid,
            webformid  :this.props._webformid,
            connection:connection,
            prevQuery: this.state.prevAddedQuery,
            isQueryChanged: technicalqueryvalue !== this.state.prevAddedQuery ? 1 : 0,
            _eletype: this.props._eletype,
            rowgeneratorWebelements: this.props.rowgeneratorEleObj[this.props._webelementid] ? this.props.rowgeneratorEleObj[this.props._webelementid] : [],
        }
    }
        return false
    }
    checkstringqueryelementspresentinobj =()=>{
        const {technicalqueryvalue,onlyidstring} =  this.state

        let tempvariable = Object.keys(onlyidstring)
                    .filter(item=>  technicalqueryvalue.includes(item)).reduce((obj,key)=>{
                obj[key] = onlyidstring[key];
                return obj;
    },{});
    return tempvariable
    }
   async validateQuery (query){

        const {technicalqueryvalue} =  this.state
          const {connection} = this.props;
        let value = undefined
        let data ={query:technicalqueryvalue,connection:connection}
        if(Object.values(query).length == 0){
             let Response =  await this.executeTestQuery(data)
            if(Response['status'] == 200){
                let length =  Response['data'].length
                if(length  == 1){
                 value =  Response['data'][0]['value']
                }
                 if(length > 1){
                    let keys = Object.keys(Response['data'][0])
                 if(keys.includes('label') && keys.includes('value') ){
                        value = Response['data'][0]['value']
                    }
            }
            }
    }else{
          await this.executeTestQuery(data)
        value = true
    }
        return (value !== undefined || value == null)

    }
  async  executeTestQuery(data){
      let response = ''
    await datasave.service(window.SHOW_RAW_QUERY_RESULT,'POST',data).then(Response=>{
        response = Response
    })
    return response
    }
    getDatatoshow(){
      const {t}=this.state;
        let html = (
            <div>
                <p>{t("Query cannot be saved due to  query is not in any of the following reasons")}</p>
                <p>1)Select query in form of "Select now() as value"</p>
                <p>2)Select query in form of "Select webelement+webelement as value"</p>
                <p>3)Select query in form of "Select id as value name as label  from table"</p>
                <p>{t("Or")}</p>
                <p>4)Entered query  is syntax wrong if so, test query before save</p>
            </div>
        )
        return html
    }
    handleSelectsublistandoperator(e,type){
      if(type === 1){
        this.setState({
          selectedsublist:e
        })
      }else{
        this.setState({
          selectedoperator:e
        })
      }
    }
    handleAdd = ()=>{
     const {selectedtoken, selectedoperator, selectedsublist} =  this.state
     let operator  = selectedoperator ? (selectedoperator.value === 1 ? '=' : '!=') : undefined;
     let string = '';
     if(operator && selectedsublist && selectedsublist.value){
        string  = '#'+selectedtoken.value+'#' + ' ' + operator + ' ' + selectedsublist.value + ' ';
      }else{
        string  = '#'+selectedtoken.value+'#';
      }
     this.setState({
       selectedlisttoken:string,
       addToken:false,
       },()=>{this.setTokenInTextBox()})
    }
    render() {
        const { addToken ,showduration,showpop,objfortestquery,technicalqueryvalue, isLoading, t} = this.state
        return (
            <>
                <div className='webelementsquery mt-2'>
                    <div className='col-md-12  mt-2'>
                        {addToken && this.displayPopup()}
                        <div className = 'd-flex my-3'>
                            <div className='col-md-3 pl-0'>
                           {this.props._webelementid !== undefined && <Reactbootstrap.Button variant="outline-info" onClick = {this.handleAddControl}>{t("Controls")}</Reactbootstrap.Button>}
                            </div>
                            <div className = 'col-md-3 ml-auto pr-0'>
                                <Reactbootstrap.Button style={{float:'right', marginRight:'10px'}} variant="outline-info" onClick = {(e)=>this.handleExecuteQueryClick(e)} disabled ={isLoading}>{isLoading ? t('Testing ....') : t("Test query")}</Reactbootstrap.Button>
                            </div>
                            <div className = 'col-md-2 p-0'>
                           {this.props._webelementid !== undefined && <Reactbootstrap.Button variant="outline-success"  onClick = {()=>this.saveQueryClick()} disabled ={isLoading}>{isLoading ? t('Saving ....') : t("Save query")}</Reactbootstrap.Button>}
                            </div>
                        </div>
                    </div>
                    <div className='col-md-12 row'>
                    {this._showTextboxForTechnialQuery()}
                    </div>
                    <div className='row col-md-12'>
                    {this.props._webelementid !== undefined && this._showTextboxForReadableQuery()}
                    </div>
                    <div className = 'row col-md-12 mb-2 d-flex ml-auto'>
                        {showduration &&this.displayResultPage()}
                        {showpop &&
                            <TestQueryPopUp
                              queryobj = {objfortestquery}
                              testquery = {this.getQueryResult}
                              cancel = {this.cancelpopup}
                              filteredobj ={this.CLONEOBJFORTEST}
                              stringquery = {technicalqueryvalue}
                           />}
                    </div>
                </div>
            </>
        )
    }
    displayPopup = () => {
        const { addToken, displayoptions, selectedtoken, selectedoperator, showAdd ,t} = this.state
        return (<Reactbootstrap.Modal show={addToken}  onHide= {()=>this.setState({addToken:false})}>
            <Reactbootstrap.Modal.Header closeButton>
             <Reactbootstrap.Modal.Body>
             <Reactbootstrap.Form>
              <Reactbootstrap.Form.Group controlId="Controls">
                <Reactbootstrap.Form.Label>{t("Controls")}</Reactbootstrap.Form.Label>
                <Select
                    onChange = {this.handleSelectControl}
                    value = {selectedtoken}
                    options =  {displayoptions}
                 />
                </Reactbootstrap.Form.Group>
                  <Reactbootstrap.Form.Group controlId="operators">
                    <Reactbootstrap.Form.Label>{t("Operator")}</Reactbootstrap.Form.Label>
                    <Select
                        onChange = {(e)=>this.handleSelectsublistandoperator(e,2)}
                        value = {selectedoperator}
                        options =  {listoperators}
                     />
                    </Reactbootstrap.Form.Group>
                    <Reactbootstrap.Form.Group controlId="value">
                      <Reactbootstrap.Form.Label>{t("value")}</Reactbootstrap.Form.Label>
                      {this.getOptionValues()}
                      </Reactbootstrap.Form.Group>
                      {showAdd && <Reactbootstrap.Form.Group controlId="button">
                        <Reactbootstrap.Button variant="outline-success" onClick={this.handleAdd}> {t("Add")} </Reactbootstrap.Button>
                        </Reactbootstrap.Form.Group>}
                    </Reactbootstrap.Form>

             </Reactbootstrap.Modal.Body>
            </Reactbootstrap.Modal.Header>
        </Reactbootstrap.Modal>
        );
    }
    _showTextboxForTechnialQuery = () => {
        const {technicalqueryvalue ,t} = this.state
        return (
            <div className = 'col-md-12'>
            <Reactbootstrap.Form >
                <Reactbootstrap.Form.Group controlId="exampleForm.ControlInput1">
                    <Reactbootstrap.Form.Group controlId="exampleForm.ControlTextarea1">

                        <Reactbootstrap.Form.Label>{t("Technical Query")}</Reactbootstrap.Form.Label>
                        <Reactbootstrap.Form.Control
                            style={{ height: '1%' }} as="textarea" rows="6" col='5'
                            id= 'technical'
                            value={technicalqueryvalue} onInput={(e) => this.handleTechnicalQueryedit(e)} />
                    </Reactbootstrap.Form.Group>
                </Reactbootstrap.Form.Group>
            </Reactbootstrap.Form>
            </div>
        )

    }
    _showTextboxForReadableQuery = () => {
        const {readonlyquery,t} =  this.state
        return (
            <div className = 'col-md-12 readonlyquery'>
            <Reactbootstrap.Form >
                <Reactbootstrap.Form.Group controlId="readonly query">
                    <Reactbootstrap.Form.Group controlId="heading">
                        <Reactbootstrap.Form.Label>{t("Readable Query")}</Reactbootstrap.Form.Label>
                        <Reactbootstrap.Form.Control
                            id = 'readable'
                            style={{ height: '1%' }} as="textarea" rows="8" col='5'
                            value={readonlyquery}
                             />
                    </Reactbootstrap.Form.Group>
                </Reactbootstrap.Form.Group>
            </Reactbootstrap.Form>
            </div>
        )

    }
    setTokenInTextBox = ()=>{
        const {selectedtoken,onlyidstring,technicalqueryvalue,showAdd, selectedlisttoken} =  this.state
        var dom = document.getElementById('technical');
        let string = ''; let string2 =''
             string =  showAdd ?  selectedlisttoken:'#'+selectedtoken.value+'#'
             onlyidstring['#'+selectedtoken.value+'#'] = { name :selectedtoken.label,id:selectedtoken.value}
             string2= this.alterReadOnlyQuery()
            let start  = dom.selectionStart;
            let end  = dom.selectionEnd;
            var before = technicalqueryvalue.substring(0, start)
            var after  = technicalqueryvalue.substring(end, technicalqueryvalue.length)
            var text   = before + string + after
            this.setState({
                technicalqueryvalue:text,
                readonlyquery:string2
            })
    }
alterReadOnlyQuery =(string)=>{
    const {selectedtoken,readonlyquery,  showAdd,  selectedsublist, selectedoperator} = this.state
    var dom = document.getElementById('technical');
    let start  = dom.selectionStart+5;
    let end  = dom.selectionEnd+5;
    var before = readonlyquery.substring(0, start)
    var after  = readonlyquery.substring(end, readonlyquery.length)
    let operator  =  showAdd ? selectedoperator ? selectedoperator.value === 1 ? '=':'!=':'':'';
    let sublistsLabel = (selectedsublist && selectedsublist.label) ? selectedsublist.label : '';
    string = showAdd ? selectedtoken.label + ' '+ operator + ' ' + sublistsLabel + ' ' : selectedtoken.label;
    var text   = before + string + after
    return text

}
alterReadOnlyQueryEdit = (value)=>{
    const {onlyidstring, onlysublistswithids}=  this.state
            let final = value
                if(Object.keys(onlyidstring).length>0){
                var RE = new RegExp(Object.keys(onlyidstring).join("|"), "g");
                final = value.replace(RE, function(matched) {
                        return onlyidstring[matched].name;
                    });
        }
        if(Object.keys(onlysublistswithids).length >0 ){
          var RE = new RegExp(Object.keys(onlysublistswithids).join("|"), "g");
          final = final.replace(RE, function(matched) {
                  return onlysublistswithids[matched];
              });
        }
        return final
}
displayResultPage =()=>{
    const {queryresult,duration,t} = this.state
   var keys = queryresult.length>0? Object.keys(queryresult[0]):[];
    return(
        <div className = 'col-md-12 mt-5' style = {{overflow:'scroll'}}>
        <div> <p>{t("Result")}</p>
          <h6 id = 'duration'> Fetched {queryresult.length} records in {duration}ms</h6>
           </div>
        <Reactbootstrap.Table striped bordered hover>
            <thead>
                <tr>
                    {keys.map(item=>{
                   return <td>{item}</td>
                    })}
                </tr>
            </thead>
            <tbody>
                    {
                        queryresult.map(item=>{
                        return<tr> {keys.map(key=>{
                           return <td>{item[key]}</td>
                            })}
                            </tr>
                        })
                    }
            </tbody>
        </Reactbootstrap.Table>
        </div>
    )
}
getQueryDataAPi =()=>{
    var data = {
        webformid:this.props._webformid,
        elementid:this.props._webelementid
    }
    const {t}=this.state;
    datasave.service(window.GET_ELEMENT_QUERY,'POST',data).then(Response=>{
        if(Response.status === 200){
        this.setState({
               technicalqueryvalue :  Response.data.json_query !== null ? JSON.parse(Response.data.json_query):'',
               prevAddedQuery: Response.data.json_query !== null ? JSON.parse(Response.data.json_query):'',
               onlyidstring:Response.data.json_query_target !== null? {... JSON.parse(Response.data.json_query_target)}:{}
        },()=> this.setState({readonlyquery:this.alterReadOnlyQueryEdit(this.state.technicalqueryvalue)}))}
        if(Response.status === 500){
        OCAlert.alertError(t('We were sorry,Internal server occured while fetching.') , { timeOut: window.TIMEOUTNOTIFICATION });}
    })
}
showTestQuerypopup =()=>{
    const {objfortestquery} =  this.state
  let sample = JSON.parse(JSON.stringify(objfortestquery));
  let result = this.checkstringqueryelementspresentinobj(sample);
  this.CLONEOBJFORTEST =  result
  let length = Object.values(result).length
    return length > 0
}
cancelpopup = ()=>{
    this.setState({showpop:false,isLoading:false})
}
getOptionValues =()=>{
  const { selectedsublist, sublistsoptions} =  this.state
  const html = (
    <>
    <Select
        onChange = {(e) =>this.handleSelectsublistandoperator(e,1)}
        value = {selectedsublist}
        options =  {sublistsoptions}
     />
    </>
  )
  return html
}
showListOptions = (e)=>{
  const {t}=this.state;
  let json  = e.json !==  null && e.json !=='null' ? JSON.parse(e.json): undefined;
  if(json !== undefined && parseInt(json.list) != 0){
      datasave.service(window.GET_PARENTLIST_DATA + '/' +parseInt(json.list), 'GET').then(
        response =>{
          let onlysublistswithids = {};
        const sublists  =  Object.values(response.child_data).map(child=>{
          onlysublistswithids[child.id] = child.name
                return{
                  label:child.name,
                  value:child.id,
                  parentid:child.parent_id
                }
            })
            this.setState({
              sublistsoptions:sublists,
              selectedtoken:e,
              showAdd:true,
              onlysublistswithids:onlysublistswithids
            })
        }
      )
  }else{
     OCAlert.alertError(t("hm, looks like you have'nt chosen list"),{ timeOut: window.TIMEOUTNOTIFICATION })
  }
}

}
export default translate(WebelementsQuery)
