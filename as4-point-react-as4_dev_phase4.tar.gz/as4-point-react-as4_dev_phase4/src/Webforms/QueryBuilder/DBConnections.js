import React from 'react'
import * as Reactbootstrap from 'react-bootstrap'
import Select from 'react-select';
import { datasave } from '../../_services/db_services'
import { translate } from '../../language'
import './querybuilder.css'
import { OCAlert } from '@opuscapita/react-alerts'
const base64 = require('base-64');
class DBConnections extends React.Component{

    constructor(props){
        super(props)
        this.state = {
          listofconnections: [],
          currentconnection:{value:1,label:'Internal connection'},
          t:this.props.t,
        }
        this.initialState();
    }
    /**
     * [initialState description]
     *
     * @return {[NONE]} [default state values]
     */
    initialState =()=>{
      this.setState({
            showpopup:false,
            connection:undefined,
            currentconnectionType:undefined,
            portnumber:undefined,
            hostnumber:undefined,
            username:undefined,
            schema:undefined,
            database:undefined,
            databasepassword:undefined,
            connectionerror:undefined,
            currentconnectionTypeerror:undefined,
            portnumbererror:undefined,
            hostnumbererror:undefined,
            usernameerror:undefined,
            schemaerror:undefined,
            databaseerror:undefined,
            databasepassworderror:undefined,
        })
    }
    /**
     * [UNSAFE_componentWillMount Fetch listofconnections]
     */

    async UNSAFE_componentWillMount(){
    await  this.getListOfConnections();
    await this.setCurrentConnection();
    }
    /**
     * [getListOfConnections description]
     *
     * @return {[NONE]} [Fetch from DB and setState values]
     */

    getListOfConnections =()=>{
      const {t}= this.state
      datasave.service(window.GET_ALL_CONNECTIONS,'GET').then(response =>{
            if(response['status'] ===200){
              Object.values(response.data).map(con=>{
                con['value'] =  con['id'];
                con['label'] = con['name'];
                delete con['id'];
                delete con['name'];
                return response.data
              })
              this.setState({listofconnections:response.data})
              this.props.setSate(1,1,2)
            }else{
        OCAlert.alertError(t('We were sorry,Internal server occured while fetching connections.'), { timeOut: window.TIMEOUTNOTIFICATION });
            }
      })
    }
    handleConnectionChange =(e)=>{

      this.setState({
        currentconnection:e
      },()=>{
        // if(e.value !==1){
        this.props.setSate(e)
      // }
      })
    }
    handleFieldChange =(e) =>{
        const {name, value} = e.target
            if(value.length === 0){
              this.setState({[name+'error']:true,[name]:value})
            }else{
            this.setState({[name+'error']:false,[name]:value})
          }
    }
    selectConnectionType =(e)=>{
        this.setState({currentconnectionType:e,currentconnectionTypeerror:false})
    }
    async handleSubmit(){
        const {t,edit,editid}=  this.state
        if(this.validateFields()){
        let data = await this.createPostData();
        let postdata  ={
            data:data,
            key:editid
        }
        let url = edit == true ? window.UPDATE_CON_DATA:window.POST_CON_DATA;
           datasave.service(url,'POST',postdata).then(
               response =>{
                    if(response['status'] === 200){
            OCAlert.alertSuccess('Saved connection data.', { timeOut: window.TIMEOUTNOTIFICATION });
            this.setState({
              showpopup:false,
            },()=>{this.getListOfConnections();this.initialState()})
                    }else{
            OCAlert.alertError(t('We were sorry,Internal server occured while storing.'), { timeOut: window.TIMEOUTNOTIFICATION });
                    }
               })
            }
    }
    setCurrentConnection(){
      const {webformid,webelement_id} = this.props;
      var data = {
          webformid:webformid,
          elementid:webelement_id
      }
      datasave.service(window.GET_ELEMENT_QUERY,'POST',data).then(Response=>{
        if(Response.status === 200){
        var con = Response.data.json_query !== null ? Response.data.connection_id:undefined;
        if(con != 1 && con !== undefined && con != 0){
            this.handleConnectionChange(this.state.listofconnections.find(item => item.value == con))
        }else{
          this.handleConnectionChange({value:1,label:'Internal connection'})
        }
      }
      if(Response.status === 500){
      OCAlert.alertError('We were sorry,Internal server occured while fetching.' , { timeOut: window.TIMEOUTNOTIFICATION });}
      })
    }
  async  componentDidUpdate(prevProps, prevState){
        if (this.props.webelement_id !== prevProps.webelement_id){
        await  this.setCurrentConnection();
        }
    }

    render(){
        const {showpopup} =  this.state
        return(
            <>
            {this.showListOfConnections()}
            {showpopup && this.dataBaseFormToConnect()}
            </>
        )
    }
    showListOfConnections =()=>{
        const {listofconnections,currentconnection} =  this.state
        let options  =(
            <>
            <div className = 'col-md-7 pl-0 mb-3 pt-3'>
            <Select
                    onChange = {this.handleConnectionChange}
                    value = {currentconnection}
                    options =  {listofconnections}
                 />
            </div>
            <div className = 'col-md-5 px-0 mb-3  pt-3 text-center iconscon'>
            <Reactbootstrap.Button className="mr-2" onClick ={()=>this.setState({showpopup:true,edit:false})}>
            <i class="webnews-sprite webnews-sprite-linkb" style={{padding: '10px 9px !important'}} title ="Create"></i>
            </Reactbootstrap.Button>
            <span class ="pt-2"></span>
            <Reactbootstrap.Button variant="outline-primary" class ="mt-2" onClick = {(e)=>this.handleEditCon(e)}>Edit</Reactbootstrap.Button>
            </div>
            </>
        )
        return options
    }
    dataBaseFormToConnect =()=>{
        const {showpopup} =  this.state
        return (<Reactbootstrap.Modal show={showpopup}  size ="md" onHide= {this.initialState}>
            <Reactbootstrap.Modal.Header closeButton >
             <Reactbootstrap.Modal.Body>
               {this.createBody()}
                </Reactbootstrap.Modal.Body>
                </Reactbootstrap.Modal.Header>
            </Reactbootstrap.Modal>
        );

    }
    createBody = ()=>{
        const {connectionerror, currentconnectionType, portnumbererror, hostnumbererror, usernameerror,
            schemaerror,databasepassworderror, databaseerror,connection, portnumber, hostnumber, schema, databasepassword,
            database, username,currentconnectionTypeerror
        }=  this.state
        let body =(
            <>
            <Reactbootstrap.Form>
                <Reactbootstrap.Form.Group controlId="formBasicEmail">
                    <Reactbootstrap.Form.Label>Connection</Reactbootstrap.Form.Label>
                    <Reactbootstrap.Form.Control type="text" id  ={1} placeholder="Name"
                     onInput = {this.handleFieldChange}
                     name  = "connection"
                     value = {connection}
                    />
                    {connectionerror && this.prepareHtmlErrorMsg("Connection name is required")}
                </Reactbootstrap.Form.Group>
                <Reactbootstrap.Form.Group controlId="formBasicEmail">
                <Reactbootstrap.Form.Label>Connection type</Reactbootstrap.Form.Label>
                    <Select
                     onChange = {this.selectConnectionType}
                     value = {currentconnectionType}
                     options =  {this.props.LISTOFCONTYPES}
                    />
                    {currentconnectionTypeerror&& this.prepareHtmlErrorMsg("Connection name is required")}
                </Reactbootstrap.Form.Group>
                <Reactbootstrap.Form.Group controlId="formBasicEmail">
                    <Reactbootstrap.Form.Label>Port number</Reactbootstrap.Form.Label>
                    <Reactbootstrap.Form.Control type="text" id ={2} pattern ="[0-9]"  placeholder="Number"
                    onInput = {this.handleFieldChange}
                    name  = "portnumber"
                    value = {portnumber}
                    />
                    {portnumbererror&& this.prepareHtmlErrorMsg("Port number is required")}
                </Reactbootstrap.Form.Group>
                <Reactbootstrap.Form.Group controlId="formBasicEmail">
                    <Reactbootstrap.Form.Label>Host number</Reactbootstrap.Form.Label>
                    <Reactbootstrap.Form.Control type="text" id  ={3}pattern ="[0-9]" placeholder="Number"
                     onInput = {this.handleFieldChange}
                     name  = "hostnumber"
                     value  ={hostnumber}
                    />
                    {hostnumbererror&& this.prepareHtmlErrorMsg("Host number is required")}
                </Reactbootstrap.Form.Group>
                <Reactbootstrap.Form.Group controlId="formBasicEmail">
                    <Reactbootstrap.Form.Label>User name</Reactbootstrap.Form.Label>
                    <Reactbootstrap.Form.Control type="text" id  ={4}  placeholder="Username"
                     onInput = {this.handleFieldChange}
                     name  = "username"
                     value = {username}
                    />
                    {usernameerror&& this.prepareHtmlErrorMsg("User name is required")}
                </Reactbootstrap.Form.Group>
                <Reactbootstrap.Form.Group controlId="formBasicEmail">
                    <Reactbootstrap.Form.Label>Schema name</Reactbootstrap.Form.Label>
                    <Reactbootstrap.Form.Control type="text" id  ={5}  placeholder="Schema"
                     onInput = {this.handleFieldChange}
                     name  = "schema"
                     value ={schema}
                    />
                    {schemaerror&& this.prepareHtmlErrorMsg("Schema is required")}
                </Reactbootstrap.Form.Group>
                <Reactbootstrap.Form.Group controlId="formBasicEmail">
                    <Reactbootstrap.Form.Label>Database name</Reactbootstrap.Form.Label>
                    <Reactbootstrap.Form.Control type="text" id  ={4}  placeholder="Database"
                     onInput = {this.handleFieldChange}
                     name  = "database"
                     value ={database}
                    />
                    {databaseerror&& this.prepareHtmlErrorMsg("Database name is required")}
                </Reactbootstrap.Form.Group>
                <Reactbootstrap.Form.Group controlId="formBasicEmail">
                    <Reactbootstrap.Form.Label>Database password</Reactbootstrap.Form.Label>
                    <Reactbootstrap.Form.Control type="password" id  ={4}  placeholder="Password"
                     onInput = {this.handleFieldChange}
                     name  = "databasepassword"
                     value ={databasepassword}
                    />
                    <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                    {databasepassworderror&& this.prepareHtmlErrorMsg("Database password is required")}
                </Reactbootstrap.Form.Group>
            </Reactbootstrap.Form>
                <div className = 'row '>
                        <div className = 'col-md-6'>
                        <Reactbootstrap.Button  variant="info" onClick = {()=>this.handleTest()}>
                        Test Connection
                        </Reactbootstrap.Button>
                        </div>
                        <div className = 'col-md-6'>
                        <Reactbootstrap.Button variant="outline-primary" style ={{marginLeft:'26.0%'}} onClick = {()=>this.handleSubmit()}>
                        Save
                        </Reactbootstrap.Button>
                        <Reactbootstrap.Button variant="outline-light" onClick ={this.initialState}>
                        Cancel
                        </Reactbootstrap.Button>
                        </div>
                     </div>
            </>
        )
        return body
    }
    prepareHtmlErrorMsg =(msg)=>{
        return(
            <Reactbootstrap.Form.Text style={{ color: 'red' }} className=" error-block">
                    {msg}
            </Reactbootstrap.Form.Text>
        )
    }
    encrypt =(string) =>{
        return base64.encode(string)
    }
    createPostData = ()=>{
        const {connection, portnumber, hostnumber, username, schema, database, databasepassword, currentconnectionType} =  this.state
            let data  ={};
            data ={
                68:this.encrypt(connection),
                81:this.encrypt(portnumber),
                73:this.encrypt(hostnumber),
                681:this.encrypt(currentconnectionType.value),
                86:this.encrypt(username),
                84:this.encrypt(schema),
                69:this.encrypt(database),
                691:this.encrypt(databasepassword)
            }
            return data;

    }
    validateFields = ()=>{
      const { connection, currentconnectionType, portnumber, hostnumber, username, schema, database, databasepassword,

              } = this.state
          let status = true
          let setStateobj = {};

      if(this.checklength(connection)){
        setStateobj['connectionerror'] = true
        status = false
      }
      if(this.checklength(portnumber)){
        setStateobj['portnumbererror'] = true
        status = false
      }
      if(this.checklength(hostnumber)){
        setStateobj['hostnumbererror'] = true
        status = false
      }
      if(this.checklength(username)){
        setStateobj['usernameerror'] = true
        status = false
      }
      if(this.checklength(schema)){
        setStateobj['schemaerror'] = true
        status = false
      }
      if(this.checklength(database)){
        setStateobj['databaseerror'] = true
        status = false
      }
      if(this.checklength(databasepassword)){
        setStateobj['databasepassworderror'] = true
        status = false
      }
      if(currentconnectionType === undefined || Object.values(currentconnectionType).length === 0){
        setStateobj['currentconnectionTypeerror'] = true
        status = false
      }
      this.setState(setStateobj)
      return status;
    }

    checklength =(value)=>{
      let status =  false;
      if(value === undefined || value.length ==0){
        status = true
      }
      return status
    }
     handleTest = async ()=>{
      datasave.service(window.TESTDBCONNECTION,'POST',await this.getPostData()).then(response =>{
        if(response['status'] == 200){
          OCAlert.alertSuccess('Connection established.', { timeOut: window.TIMEOUTNOTIFICATION });
        }else{
          OCAlert.alertError(response['msg'], { timeOut: 5000 });
        }
      })
    }
    getPostData =()=>{
      const {portnumber,hostnumber,username,schema,database,databasepassword,
        currentconnectionType
      } = this.state
      return{
        con_type:currentconnectionType,
        name :this.state.connection.value,
        portnumber:portnumber,
        hostnumber:hostnumber,
        username:username,
        schema:schema,
        database:database,
        databasepassword:databasepassword,

      }
    }
    handleEditCon(e){
      const{currentconnection} = this.state;
      if(currentconnection.value !==1){
        datasave.service('/api/get-con-details/'+currentconnection.value,'GET').then(response =>{
          if(response['status'] == 200){
            let params = JSON.parse(response['data']['parameters']);
            let con = parseInt(base64.decode(params[681]))
            let label = Object.values(this.props.LISTOFCONTYPES).filter(connection=>{ return connection.value === con;})
            let data = response['data'];
            this.setState({
              connection:data['name'],
              portnumber:base64.decode(params[81]),
              hostnumber:base64.decode(params[73]),
              currentconnectionType:label[0],
              username:base64.decode(params[86]),
              schema:base64.decode(params[84]),
              database:base64.decode(params[69]),
              databasepassword:base64.decode(params[691]),
              showpopup:true,
              edit:true,
              editid:data['id']
            })
          }else{
            OCAlert.alertError('Internal server error occured.', { timeOut: 3000 });
          }
        })
    }else{
      OCAlert.alertError("Internal connection can't be edited.", { timeOut: 3000 });
    }
    }
}
export default translate(DBConnections)
