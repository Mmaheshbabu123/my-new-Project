import React ,{Suspense} from 'react'
import * as Reactbootstrap from 'react-bootstrap'
import { translate } from '../../language'
import { datasave } from '../../_services/db_services'
import { OCAlert } from '@opuscapita/react-alerts'
import WebelementsQuery from './WebelementsQuery';
import Select from 'react-select';
const DBConnections = React.lazy(() => import('./DBConnections'));
const JOINS = 1
const FILTERS = 2
const SORTING = 3
const SELECTCOLUMNS = 4
const ASC = 1
const DESC = 2
const OR = 111
const AND = 112
const FILTERNAMES = window.FILTERNAMESWITHIDS;
const ALLOWTABLEIDS = [10];
const TOKENSUBMIT = "#submit_id#";
var SUBQUERY = "select id from documents where doc_ref_version_id in (select doc_ref_version_id from documents where id in ($IDS$))"
class QueryBuilder extends React.Component {
  columnobj;
  constructor(props) {
    super(props)
    this.intialstate();
  }


  intialstate = () => {
     this.state = {
      t: this.props.t,
      treeData: [],
      clonetreeData:[],
      hasError: false,
      droppedtables: [],
      tableclickid: undefined,
      Loading: true,
      droppedfilteredcolumns: [],
      droppedselectedcolumns: [],
      droppedsortedcolumns: [],
      columnclicked: false,
      filteredcolumndetails: [],
      selectedcolumndetails: [],
      sortedcolumndetails: [],
      joincolumns: {},
      tablesforquery: {},
      tablenameswithids: {},
      selectedcolumnidwithvalue: {},
      sortingcolumnidwithvalue: {},
      condition: 0,
      filtercolumnidwithvalue: {},
      connectiontypes:{},
      isLoading:true,
      jointablesobj:{},
      loadingtext:"We're building the tables as fast as we can ....",
      setQuery:this.props.setQuery,
      dbrelation:[],
      dboptions:[],
      selectedItems:{}
    }
    this.columnobj = {
      condition: 'equals to',
      value: undefined
    }
  }
  UNSAFE_componentWillMount(postdata = {type:1}) {
    const { t } = this.state
    datasave.service(window.FETCH_ALL_TABLES, 'POST',postdata).then(
      data => {
        if (data.status === 200){
          this.setState({
            treeData: data.data.tables,clonetreeData: data.data.tables,columnswithtableids: data.data.columns,
             tablenameswithids: data.data.tableswithid, columnnameswithtid:data.data.colwithids,
             connectiontypes:data.data.cons,isLoading :false,
             dbrelation:data.data.relation,
             currentconnection:postdata
          })}
        if (data.status === 500){
          OCAlert.alertError(t('We were sorry,Internal server occured while fetching.'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      })
  }

  componentDidUpdate(prevProps, prevState){
    if(prevState.selectedcolumnid !== this.state.selectedcolumnid){
      this.getClickedTableDataFromAPI();
    }
    if (this.props.webelement_id !== prevProps.webelement_id){
           this.setState({
            droppedtables: [],
           tableclickid: undefined,
           droppedfilteredcolumns: [],
           droppedselectedcolumns: [],
           droppedsortedcolumns: [],
           selectedcolumnidwithvalue: {},
          sortingcolumnidwithvalue: {},
          condition: 0,
          filtercolumnidwithvalue: {},
          joincolumns:{},
          tablesforquery: {},
          columnclicked:false,
          searchTerm:undefined
           })
          }
  }
  onDrop = (ev, type, dropedat) => {


    ev.preventDefault();
    const { selectedcolumnidwithvalue, sortingcolumnidwithvalue, filtercolumnidwithvalue } = this.state
    var data = ev.dataTransfer.getData("text");
    var dataJson = JSON.parse(data);
    if (type != dataJson['type']) {
      return false;
    } else {

      let data = this.constructButtons(dataJson.name, dataJson.id, parseInt(dataJson.type), dataJson.datatype, dataJson.parentid, dropedat)
      if (dropedat === JOINS || dropedat === FILTERS) {
        if (dataJson['type'] === 1) {
          this.state.droppedfilteredcolumns.push(data)
          this.state.selectedItems[dataJson.id] = [];
          if(this.checksubmitColumn(dataJson.parentid,dataJson.id)){
          filtercolumnidwithvalue[dataJson.id] = { operator: 700, value: TOKENSUBMIT }
        }else{
            filtercolumnidwithvalue[dataJson.id] = { operator: this.checkWebformIdColumn(dataJson.parentid,dataJson.id) ? 714 :700, value: '' }
        }
        } else {
         this.state.jointablesobj[dataJson.id]  ={
            tid:dataJson.id,
            cid1: undefined,
            cid2: undefined,
            type:undefined
          }
          this.state.droppedtables.push(data)
        }
      } else {
        if (dropedat === SORTING) {
          sortingcolumnidwithvalue[dataJson.id] = { order: ASC, priority: 1 }
          this.state.droppedsortedcolumns.push(data)
        }
        if (dropedat === SELECTCOLUMNS) {
          selectedcolumnidwithvalue[dataJson.id] = 1;
          this.state.droppedselectedcolumns.push(data)
        }
      }
      if (dataJson.type == 0) {
        this.modifydraggableProperty(parseInt(dataJson.id)); this.getJoinsList();
      }
      this.setState({})
    }
  }
  constructButtons = (data, id, type, datatype, parentid, dropedat, createdtableid,obj1= undefined, length = undefined) => {
    const { tablenameswithids } = this.state

    let obj = (
      <li style={{ backgroundColor: '#FFF', display: 'inline-block', padding: '4px' }}>
        <Reactbootstrap.Button id={id} variant="primary" size="sm" onClick={type === 1 ? (e) => this.columnclick(data, id, datatype, parentid, dropedat) : null}>
          {dropedat !== JOINS && tablenameswithids[parentid] + '.' + data }
          {dropedat == JOINS && data}
        </Reactbootstrap.Button>
        &nbsp;&nbsp;
        {type !== 1 && this.getTableColumnsByid(parseInt(id),1)}
        &nbsp;&nbsp;
        {(type !== 1 && length >2 && datatype === 0) && this.getTableColumnsByid(parseInt(id),2)}
        &nbsp;&nbsp;
        {(type !== 1 && datatype === 0) && this.displayJoinsPop(id, createdtableid)}
        {dropedat === FILTERS && obj1 !== undefined &&this.getLatestFilterDataForColumn()}
        <Reactbootstrap.Button variant="outline-danger" size="sm" onClick={(e) => this.removeDroppedButtons(data, id, type, dropedat)}>
          X
        </Reactbootstrap.Button>
      </li>
    )
    let obj2 = {
      id: id,
      name: data,
      parentid: parentid,
      dropedat: dropedat,
      selectcolumn: tablenameswithids[parentid] + '.' + data,
      datatype:datatype
    }
    let obj3 = { ...obj, ...obj2 }

    return obj3
  }
  searchData =(e)=>{
    const {value} =  e.target
    const {clonetreeData}= {...this.state}
    const data = [];


    Object.values(clonetreeData).map(item => {
    	if(item.table.toLowerCase().search(value.toLowerCase())!==-1) {
    		data.push(item)
    	}
      Object.values(item.nodes).filter(item1 => {
          if(item1.label.toLowerCase().search(value.toLowerCase())!==-1 ){
      			if(!data.includes(item)){
      			data.push(item)}
          }
        })
    })
    // const data  =  Object.values(clonetreeData).filter(item=>{
    //    return item.table.toLowerCase().search(value.toLowerCase())!==-1
    // })

    // if(data.length === 0) {
    //   Object.keys(clonetreeData).map(item => {
    //         Object.values(clonetreeData[item].nodes).filter(item1 => {
    //               if(item1.label.toLowerCase().search(value.toLowerCase())!==-1){
    //                 data.push(clonetreeData[item]);
    //               }
    //           })
    //   })
    // }
      this.setState({treeData:data,searchTerm:value})
  }
  onDragStart = (ev, type, datatype = undefined, parentid = undefined) => {
    let obj = {
      name: ev.target.innerText,
      id: ev.target.id,
      type: type,
      datatype: datatype,
      parentid: parentid
    }
    ev.dataTransfer.setData("text", JSON.stringify(obj));
  }

  onDragEnd = (ev, name) => {



  }
  allowDrop = (ev, type) => {


    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    var dataJson = JSON.parse(data);

    if (type !== dataJson['type']) {
      return false;
    }

  }
  removeDroppedButtons = (data, id, type, dropedat) => {
    const { selectedcolumnidwithvalue, sortingcolumnidwithvalue, filtercolumnidwithvalue, joincolumns, jointablesobj, tablesforquery } = this.state
    let name = dropedat === FILTERS ? 'droppedfilteredcolumns' : dropedat === JOINS ? 'droppedtables' : dropedat === SELECTCOLUMNS ? 'droppedselectedcolumns' : 'droppedsortedcolumns';

    const final = this.state[name].filter(item => { return item.id != id })
        this.setState({[name]:final})
    this.setState({
      [name]: final,
      columnclicked: false
    }, () => {
      if (type === 0) this.modifydraggableProperty(parseInt(id), 0)

      if (dropedat === SELECTCOLUMNS){
        delete selectedcolumnidwithvalue[id];
      }
      if (dropedat === SORTING){
        delete sortingcolumnidwithvalue[id];
      }
      if (dropedat === FILTERS){
        delete filtercolumnidwithvalue[id];
      }
      if (dropedat === JOINS){
        delete joincolumns[id]
        delete jointablesobj[id]
        delete tablesforquery[id]
      }
    })
  }
  columnclick = (name, id, type, parentid, droppedat) => {
    this.setState({
      columnclicked: true,
      selectedcolumns: name,
      selectedcolumnid: id,
      selectedDatatype: type,
      columnclickedorigin: droppedat,
      currentClickedTableid:parentid
    })
  }

  modifydraggableProperty = (id, type = 1) => {

    const { treeData } = this.state
    Object.values(treeData).some(data => {
      if (parseInt(data.id) === parseInt(id)) {
        Object.values(data.nodes).map(item => {
           return item.draggable = type === 1 ? true : false
        })
        return true
      }
    })
  }
  getJoinsList(type) {
    const { droppedtables } = this.state
    let leng = droppedtables.length - 2
    if (droppedtables.length >= 2) {
      let data = this.constructButtons(droppedtables[leng].name, droppedtables[leng].id, 0, 0, 0, JOINS, droppedtables[droppedtables.length - 1].id,'',droppedtables.length);
      droppedtables[leng] = data
    }
  }
  handleConnections =(e)=>{

  }
  handleSelect = (e)=>{
    const {filtercolumnidwithvalue, selectedcolumnid, t} =  this.state

    if(filtercolumnidwithvalue[selectedcolumnid]!== undefined && filtercolumnidwithvalue[selectedcolumnid].operator !== undefined && filtercolumnidwithvalue[selectedcolumnid].operator >= 714){
      let ids  = Object.values(e).map(item=> {return item.value});
      let string = SUBQUERY;
      let final  = this.checkWebformIdColumn(undefined,selectedcolumnid) ? string.replace("$IDS$",ids.toString()):ids.toString();
      filtercolumnidwithvalue[selectedcolumnid].value = final;
      this.modifyButtonDataForFilterValues();
      this.state.selectedItems[selectedcolumnid] =e;
    this.setState({
    })
    }else{
        OCAlert.alertWarning(t('Hm, filter must be In or Not in selected !.'), { timeOut: window.TIMEOUTNOTIFICATION });
    }

  }
  modifyButtonDataForFilterValues =()=>{
    const { filtercolumnidwithvalue, selectedcolumnid ,droppedfilteredcolumns} = this.state
    const index = droppedfilteredcolumns.findIndex(column=>column.id === selectedcolumnid)
    if(index !==-1){
      let obj = droppedfilteredcolumns[index];
      let data = this.constructButtons(obj.name,obj.id,1,obj.datatype,obj.parentid,FILTERS,'',obj);
       droppedfilteredcolumns[index] = data
 }
  }
  render() {
    const { hasError, t, columnclicked,connectiontypes} = this.state;
    if (hasError) {
      return <h1>Error :- Internal server occured.</h1>;
    } else {
      return (
        <div  class="ml-0">
          <Reactbootstrap.Tabs id="tabs" defaultActiveKey = 'Query' id = {1}>
            <Reactbootstrap.Tab   eventKey= 'Builder' title={"Builder"} >

              <div className='row mt-2 '>
              <Suspense fallback = {<div><h5>...Loading</h5></div>}>
                <div className='col-md-6 sidenav table' style={{ height: '500px', overflowY: 'auto' }}>
                <div style = {{position: 'sticky', top: '0', zIndex: '999',backgroundColor:'#fff'}} >
                  <div className = 'row col-md-12'>
                    <DBConnections
                    setSate = {this.setStateTablesData}
                    LISTOFCONTYPES = {connectiontypes}
                    webformid = {this.props.webform_id}
                    webelement_id = {this.props.webelement_id}
                    />
                  </div>
                  <div className = 'row col-md-12'>
                  <input type="text" className="search-input form-control mb-2" style={{ borderRadius: "5px", borderColor: "#EC661C"}}  value ={this.state.searchTerm} placeholder={t("What are you looking for ?")} autoFocus onChange={this.searchData} />
                  </div>
                  </div>
                  {this.displayTablesForDragOnDrop()}
                </div>
                </Suspense>
                {this.getDroppableArea()}
                {columnclicked && this.showDroppedDetails()}
              </div>

            </Reactbootstrap.Tab>
            <Reactbootstrap.Tab eventKey='Query' title={"Query"} >
              <WebelementsQuery
                parentstate={this.state}
                _webformid = {this.props.webform_id}
                _webelementid = {this.props.webelement_id}
                query2sibling ={this.props.callBackforQuery}
                setQuery = {this.props.setQuery}
                id = {this.props.id}
                connection = {this.state.currentconnection}
                _eletype = {this.props._eletype}
                rowgeneratorEleObj = {this.props.rowgeneratorEleObj}
              />
            </Reactbootstrap.Tab>
          </Reactbootstrap.Tabs>
        </div>

      )
    }

  }
  handleTableclick = (id) => {
    const { tableclickid } = this.state
    id === tableclickid ? this.setState({ tableclickid: undefined }) : this.setState({ tableclickid: id })
  }

  displayTablesForDragOnDrop = () => {
    const { treeData, tableclickid,isLoading} = this.state
    if(isLoading){
        return (
                <div className="col-md-12 row">
                    <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
                    <div style={{ marginLeft: '-0.5rem' }} className='col-md-11' >
                        <h5>Loading ...</h5>
                    </div>
                </div>
            )
    }else{

    return (
      Object.values(treeData).map(item => {
        return (
          <div key={item.id} className='mb-2' style={{ boxShadow: '7px 3px 6px #888' }}>
            <div key={item.id} onClick={(e) => this.handleTableclick(item.id)} className='header draggable' style={HEADERCSS}>
              <p key={item.id} className={0} style={{ cursor: 'move' }} id={item.id} draggable={item.draggable} onDragStart={(e) => this.onDragStart(e, 0)} onDragEnd={(e) => this.onDragEnd(e, item.id)} >{item.table}</p>
            </div>
            {tableclickid === item.id ? (
              <div className='content ' style={CHILDRENCSS} >
                <Reactbootstrap.Table striped bordered hover>
                  <tbody>
                    {Object.values(item.nodes).map(children => {
                      return (
                        <tr key={children.id} className={1} style={{ cursor: !children.draggable ? 'not-allowed' : 'move' }} id={children.id} draggable={children.draggable} onDragStart={(e) => this.onDragStart(e, 1, children.type, children.parentid)}
                          onDragEnd={(e) => this.onDragEnd(e)}>
                          <span id={children.id} className={1} draggable={children.draggable}
                          >{children.label} </span>
                        </tr>
                      )
                    })}
                  </tbody>
                </Reactbootstrap.Table>
              </div>
            ) : null}
          </div>
        )
      })
    )
    }
  }

  displayJoinsPop = (previousid, nextid) => {
    return (
      <select id="join" onChange={(e) => this.handleJoinschange(e, previousid, nextid)}>
        <option value={0}>none</option>
        <option value={1}>inner-join</option>
        <option value={2}>left-join</option>
        <option value={3}>right-join</option>
      </select>
    )
  }
  handleJoinschange(e, jointableid, ontableid) {
    const { value } = e.target
    const { tablesforquery, tablenameswithids } = this.state
    let obj = {
      tablefrom: jointableid,
      tableon: ontableid,
      jointype: value,
      tablefromname: tablenameswithids[jointableid],
      tableonname: tablenameswithids[ontableid],
    }
    tablesforquery[jointableid] = obj;


    if (parseInt(value) === 0) {
      delete tablesforquery[jointableid]

    }

  }
  getDroppableArea = () => {
    const { droppedtables,  droppedselectedcolumns, droppedsortedcolumns } = this.state;
    return (
      <div className='col-md-6' style={{ overflowY: 'auto' }}>
        Tables
                <div className="mt-2 mb-3" data-placeholder='Drop Tables' droppable='true' style={{ height: droppedtables.length > 4 ? '100px' : 'auto' }} style={style} id={JOINS} onDragOver={(e) => this.allowDrop(e, 0)} onDrop={(e) => this.onDrop(e, 0, JOINS)}>
          <span>
            {droppedtables}
          </span>

          {droppedtables.length === 0 && <span style={{ opacity: 0.5 }}> Drop tables here.</span>}
        </div>
        Selected columns
        <div className=" mt-2 mb-3" id={SELECTCOLUMNS} droppable='true' style={{ height: droppedselectedcolumns.length > 4 ? '100px' : 'auto' }} style={style} onDragOver={(e) => this.allowDrop(e, 1)} onDrop={(e) => this.onDrop(e, 1, SELECTCOLUMNS)} >
          <span>
            {droppedselectedcolumns}
          </span>
          {droppedselectedcolumns.length === 0 && <span style={{ opacity: 0.5 }}> Drop columns to select.</span>}

        </div>
        Filters
          <div className="mb-3"> {this.getFilterDroppableArea()} </div>
        Sorting
         <div className="mb-3 mt-2" id={SORTING} droppable='true' style={{ height: droppedsortedcolumns.length > 4 ? '100px' : 'auto' }} style={style} onDragOver={(e) => this.allowDrop(e, 1)} onDrop={(e) => this.onDrop(e, 1, SORTING)}  >
          <span>
            {droppedsortedcolumns}
          </span>
          {droppedsortedcolumns.length === 0 && <span style={{ opacity: 0.5 }}> Drop columns  to sort.</span>}

        </div>

      </div>
    )
  }
  showDroppedDetails ()  {
    const { columnclickedorigin, selectedDatatype } = this.state
    return (
      <div className='col-md-2'>
        <Reactbootstrap.Tabs id="tabs">
          <Reactbootstrap.Tab eventKey={1} title={"Details"} >
            <p>{this.state.selectedcolumns}</p>
            <Reactbootstrap.Tabs id="subtabs">
              <Reactbootstrap.Tab eventKey={2} title={"Value"} >
                {columnclickedorigin === SELECTCOLUMNS && this.getfilteroptionsforSelected()}
                {columnclickedorigin === FILTERS && this.getfilteroptions()}
                {columnclickedorigin === SORTING && this.getsortingOptionsForcolumn()}
              </Reactbootstrap.Tab>
                {(columnclickedorigin === FILTERS && selectedDatatype !== window.QUERY_BUILDER_DATE_DATA_TYPE )  &&  <Reactbootstrap.Tab eventKey={3} title = {"List"}>
                  {this.getDBDataForSelectedColumn()}
              </Reactbootstrap.Tab>}
            </Reactbootstrap.Tabs>
          </Reactbootstrap.Tab>
        </Reactbootstrap.Tabs>
      </div>
    )
  }
  getTableColumnsByid(id,type) {
    const { columnswithtableids } = this.state
    return (
      <select id="join" onChange={(e) => this.handleTableColumnChange(e, id,type)}>
        <option id={0} key={0}>none</option>
        {
          columnswithtableids[id].map(item => {

            return (<option id={item.id}  key = {item.id} >{item.label}</option>)
          })
        }
      </select>
    )
  }
  handleTableColumnChange =
  (e, id,type) => {


    const { value, selectedIndex, childNodes } = e.target
    const { joincolumns, jointablesobj, columnnameswithtid } = this.state
    let valueId = parseFloat(childNodes[selectedIndex].getAttribute('id'))
    if(jointablesobj[id] === undefined){
    let obj  ={
      tid:id,
      cid1: type === 1 ? columnnameswithtid[valueId]: undefined,
      cid2:type === 2? columnnameswithtid[valueId]:undefined,
      type:type
    }
   jointablesobj[id] = obj
  }else{
    jointablesobj[id].cid1 = type === 1 ? columnnameswithtid[valueId] :jointablesobj[id].cid1;
    jointablesobj[id].cid2 = type === 2 ? columnnameswithtid[valueId] :jointablesobj[id].cid2;
    jointablesobj[id].type = type;
  }
    joincolumns[id] = { id: valueId, name: value, tableid: id }
    if (valueId === 0){
      delete joincolumns[id]
    }
    this.setState({jointablesobj:jointablesobj})


  }
  getfilteroptions = () => {
    const {  selectedDatatype } = this.state
    switch (selectedDatatype) {
      case window.QUERY_BUILDER_INT_DATA_TYPE:
        return this.getDataTypeOptions('int')

      case window.QUERY_BUILDER_STRING_DATA_TYPE:
        return this.getDataTypeOptions('string')

      case window.QUERY_BUILDER_DATE_DATA_TYPE:
        return this.getDataTypeOptions('date')
    }
  }
  getDataTypeOptions = (keytype) => {
    const { filtercolumnidwithvalue, selectedcolumnid, t, currentClickedTableid } = this.state
    let selection = filtercolumnidwithvalue[selectedcolumnid].operator
    let disabled = false
     disabled = this.checksubmitColumn(currentClickedTableid,selectedcolumnid);
     disabled = this.checkWebformIdColumn(currentClickedTableid,selectedcolumnid);

    return (
      <div>
        <select id="datatypes" style={{ width: '100%' }} disabled = {disabled} value={filtercolumnidwithvalue[selectedcolumnid].operator} onChange={(e) => this.handlefilterselect(e)}>
          {window.Query_builder_FILTER_OPTIONS.map(item => {
            if (item[keytype]) {
              return (<option key={item.id} id={item.id} value={item.id}> {item.label}</option>)
            }
          })}
        </select> &nbsp; &nbsp;
       {(selection !== 712 && selection !== 713) && <input type="text" className="search-input form-control mb-2" disabled = {disabled} style={{ borderRadius: "5px", borderColor: "#EC661C" }} placeholder={selection === 706 || selection === 707 ? t("1,2") : t("Value")} value={filtercolumnidwithvalue[selectedcolumnid].value} onInput={this.handlevalueForFilterColumn} />}
      </div>
    )
  }

  handlePriorityForColumn = (e) => {
    const { sortingcolumnidwithvalue, selectedcolumnid } = this.state
    const { value, validity } = e.target
    sortingcolumnidwithvalue[selectedcolumnid].priority = validity.valid ? value : sortingcolumnidwithvalue[selectedcolumnid].priority;
    this.setState({})
  }
  handlevalueForFilterColumn = (e) => {
    const { value } = e.target
    const { filtercolumnidwithvalue, selectedcolumnid } = this.state
    filtercolumnidwithvalue[selectedcolumnid].value = value
      this.modifyButtonDataForFilterValues();
    this.setState({})
  }
  getsortingOptionsForcolumn = () => {
    const { sortingcolumnidwithvalue, selectedcolumnid, t } = this.state
    return (
      <>
        <div>
          <td> <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={1} name='radio' value='ASC' checked={sortingcolumnidwithvalue[selectedcolumnid].order === ASC} onChange={(e) => { this.handleRadiosForSortingColumn(e, ASC) }} />ASC</td><br></br>
          <td> <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={2} name='radio' value='DESC' checked={sortingcolumnidwithvalue[selectedcolumnid].order === DESC} onChange={(e) => { this.handleRadiosForSortingColumn(e, DESC) }} />DESC</td><br></br>
          <input type="text" className="search-input form-control mb-2" style={{ borderRadius: "5px", borderColor: "#EC661C" }} value={sortingcolumnidwithvalue[selectedcolumnid].priority} placeholder={t("Priority")} pattern="[0-9]*" onInput={this.handlePriorityForColumn} />
        </div>
      </>
    )
  }
  getLatestFilterDataForColumn = () => {
    const {filtercolumnidwithvalue,selectedcolumnid} =  this.state
    return (
      <span>
        {FILTERNAMES[filtercolumnidwithvalue[selectedcolumnid].operator]}     {filtercolumnidwithvalue[selectedcolumnid].value}
      </span>
    )
  }
  handlefilterselect = (e) => {
    const { filtercolumnidwithvalue, selectedcolumnid,droppedfilteredcolumns } = this.state
    const {  selectedIndex, childNodes } = e.target
    let valueId = childNodes[selectedIndex].getAttribute('id')
    filtercolumnidwithvalue[selectedcolumnid].operator = parseInt(valueId);
    filtercolumnidwithvalue[selectedcolumnid].value = '';
            const index = droppedfilteredcolumns.findIndex(column=>column.id === selectedcolumnid)
     if(index !==-1){
          let obj = droppedfilteredcolumns[index];
          let data = this.constructButtons(obj.name,obj.id,1,obj.datatype,obj.parentid,FILTERS,'',obj);
           droppedfilteredcolumns[index] = data
     }
    this.setState({})
  }

  getFilterDroppableArea = () => {
    const {  droppedfilteredcolumns } = this.state;

    return (
      <div droppable='true' title='Drop columns here' id={FILTERS} style={{ height: droppedfilteredcolumns.length > 4 ? '100px' : 'auto' }} style={style} onDragOver={(e) => this.allowDrop(e, 1)} onDrop={(e) => this.onDrop(e, 1, FILTERS)} onClick={this.handleFilterDivClick}>
        <p> <select id={1} onChange={this.handleRuleChange} >
          <option key={2} id={OR}>
            OR
     </option>
          <option key={3} id={AND}>
            AND
     </option>
        </select>
        </p>
        <span>
          {droppedfilteredcolumns}
        </span>
        {droppedfilteredcolumns.length === 0 && <span style={{ opacity: 0.5 }}> Drop columns to filter.</span>}

      </div>
    )
  }
  handleRuleChange = (e) => {
    const { value } = e.target
    let type = value === 'AND' ? 1 : 2;
    this.setState({
      condition: type
    })
  }
  getfilteroptionsforSelected = () => {
    const { selectedDatatype } = this.state
    return (
      <>
        {selectedDatatype === window.QUERY_BUILDER_STRING_DATA_TYPE && this.getselectedoptionsForString()}
        {selectedDatatype === window.QUERY_BUILDER_INT_DATA_TYPE && this.getselectedoptionsForInt()}
        {selectedDatatype === window.QUERY_BUILDER_DATE_DATA_TYPE && this.getselectedoptionsForDate()}
      </>
    )
  }
  getselectedoptionsForString = () => {
    const { selectedcolumnidwithvalue, selectedcolumnid } = this.state
    return (
      <div>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={1} name='radio' value='value' checked={selectedcolumnidwithvalue[selectedcolumnid] === 1} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Value<br></br>
        <span><p>AGGREGATION FUNCTIONS </p></span>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} name='radio' checked={selectedcolumnidwithvalue[selectedcolumnid] === 33} id={33} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} value='Count' />Count
      </div>
    )
  }
  getselectedoptionsForInt = () => {
    const { selectedcolumnidwithvalue, selectedcolumnid } = this.state
    return (
      <div>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} name='radio' id={1} checked={selectedcolumnidwithvalue[selectedcolumnid] === 1} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} value='value' />
        <span><p>AGGREGATION FUNCTIONS </p></span>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} name='radio' id={34} value='Avg' checked={selectedcolumnidwithvalue[selectedcolumnid] === 34} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Avg<br></br>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} name='radio' id={33} checked={selectedcolumnidwithvalue[selectedcolumnid] === 33} value='Count' onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Count<br></br>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} name='radio' id={35} value='Min' checked={selectedcolumnidwithvalue[selectedcolumnid] === 35} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Min<br></br>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} name='radio' id={36} value='Max' checked={selectedcolumnidwithvalue[selectedcolumnid] === 36} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Max<br></br>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} name='radio' id={37} value='Sum' checked={selectedcolumnidwithvalue[selectedcolumnid] === 37} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Sum<br></br>
      </div>
    )
  }
  getselectedoptionsForDate = () => {
    const { selectedcolumnidwithvalue, selectedcolumnid } = this.state
    return (
      <div>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={1} name='radio' checked={selectedcolumnidwithvalue[selectedcolumnid] === 1} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} value='value' />
        <span><p>AGGREGATION FUNCTIONS </p></span>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={33} name='radio' value='Count' checked={selectedcolumnidwithvalue[selectedcolumnid] === 33} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Count<br></br>
        <span> EXPRESSION FUNCTION</span>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={38} name='radio' value='Month' checked={selectedcolumnidwithvalue[selectedcolumnid] === 38} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Month<br></br>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={39} name='radio' value='Day of month' checked={selectedcolumnidwithvalue[selectedcolumnid] === 39} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Day of month<br></br>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={40} name='radio' value='Day' checked={selectedcolumnidwithvalue[selectedcolumnid] === 40} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Day<br></br>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={41} name='radio' value='month of year' checked={selectedcolumnidwithvalue[selectedcolumnid] === 41} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Month of year<br></br>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={43} name='radio' value='year' checked={selectedcolumnidwithvalue[selectedcolumnid] === 43} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Year<br></br>
        <input type='radio' style={{ backgroundColor: '1px solid #EC661C' }} id={42} name='radio' value='Quarter' checked={selectedcolumnidwithvalue[selectedcolumnid] === 42} onChange={(e) => { this.handleRadiosForSelectedColumn(e) }} />Quarter<br></br>
      </div>
    )
  }
  handleRadiosForSelectedColumn = (e) => {
    const {  id } = e.target
    const { selectedcolumnidwithvalue, selectedcolumnid } = this.state;
    selectedcolumnidwithvalue[selectedcolumnid] = parseInt(id)
    this.setState({
      selectedcolumnidwithvalue: selectedcolumnidwithvalue
    })
  }
  handleRadiosForSortingColumn = (e, type) => {
    const { sortingcolumnidwithvalue, selectedcolumnid } = this.state
    sortingcolumnidwithvalue[selectedcolumnid].order = type
    this.setState({})
  }
  setStateTablesData = (obj,type =1,from = 1)=>{
    if(from == 1){
    obj.type =2;
    if(obj.value === 1){
      obj.type =1;
    }
    this.setState({
      currentconnection:obj
    })
    this.UNSAFE_componentWillMount(obj);
  }else{
    this.setState({
      from:from
    })
  }
  }
  getClickedTableDataFromAPI = async()=> {
 const {currentClickedTableid,tablenameswithids, dbrelation, selectedcolumns} =  this.state;
 let status = false; let obj ={};
  Object.values(dbrelation).some(table =>{
 if(table.source === tablenameswithids[currentClickedTableid] && table.sourcecolumn  === selectedcolumns){
   status = true;
   obj = {
     table:table.target,
     column:table.targetcolumn,
     webform_id:this.props.webform_id !== undefined && parseInt(this.props.webform_id) !== 0 ?
     this.props.webform_id : 0
   }
   return true;
 }
 })
 let response = [];

 if(status){
  await  datasave.service(window.FETCHTABLEDATA, 'POST',obj).then(respons=>{
    if(respons['status'] === 200){
      response = respons['data']
    }
    })
  }
  this.setState({
    dboptions:response
  })
}
   getDBDataForSelectedColumn =()=>{
    const  {dboptions, selectedItems,selectedcolumnid} =  this.state
    return (
      <Select
         onChange = {this.handleSelect}
         value = {selectedItems[selectedcolumnid]}
         options =  {dboptions}
         isMulti
         closeMenuOnSelect={false}
          />
    )
  }
  checksubmitColumn = (tid,cid)=>{
    let tables  = [10,11,12,];
    let columns  = [10.9,11.5,11.2,12.11];
    if(tables.includes(parseInt(tid)) && columns.includes(parseFloat(cid))){
      return true;
    }
    return false
  }
  checkWebformIdColumn = (tid,cid)=>{
    var webformidcids = [7.15,10.13,11.13,12.15,13.17];
    if(webformidcids.includes(parseFloat(cid))) return true
    return false
  }

}
export default translate(QueryBuilder)

const HEADERCSS = {
  'cursor': 'pointer',
  'border': 'solid 1px #f2f2f2',
  'padding': '15px',
  'backgroundColor': '#ec661c',
  'color': '#FFF',
  'fontFamily': 'verdana',
  'fontWeight': 'bold',
  'wordWrap': 'break-word',
  borderRadius: '5px'
}
const CHILDRENCSS = {
  'cursor': 'pointer',
  'padding': '15px',
  'fontFamily': 'verdana',
  'font-size': '16px',
  'height': 'auto',
  'backgroundColor': 'white'
}
const style = {
  width: '100%',
  padding: '15px',
  border: '1px solid #feb389',
  borderRadius: '5px'
}
