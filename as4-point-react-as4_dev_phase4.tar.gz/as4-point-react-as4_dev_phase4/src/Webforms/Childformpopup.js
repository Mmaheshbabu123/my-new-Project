import React, { Component } from 'react';
import axios from 'axios';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import SecondCycleComonent from './../_components/DocumentCycleComponent/SecondCycleComonent';
// import Iframe from 'react-iframe'

class Childformpopup extends Component {
    constructor(props) {
        super(props)
        this.state = {
            showpopup: false,
            t: props.t,
            eventcancel: false,
        }
        this.cancelPopup = this.cancelPopup.bind(this);
        this.showPopup = this.showPopup.bind(this);
    }
    
    
    cancelPopup() {
        this.setState({ showpopup: false, eventcancel: true });
        this.props.changeStatus(false)
    }
    showPopup() {
        this.setState({ showpopup: true });
    }
    componentDidMount () {
      console.log(this.props.url)
      this.setState({
        showpopup: this.props.status,
      }, () => {
          if (document.getElementById('controlled-tab-example-tab-general') !== null)
                    document.getElementById('controlled-tab-example-tab-general').click();
          if (document.getElementById('controlled-tab-example-tab-Dutch') !== null)
                    document.getElementById('controlled-tab-example-tab-Dutch').click();

      });
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.import !== this.props.import) {
            this.setState({
                showpopup: true,
            }, () => {
                 if (document.getElementById('controlled-tab-example-tab-general') !== null)
                    document.getElementById('controlled-tab-example-tab-general').click();
                 if (document.getElementById('controlled-tab-example-tab-Dutch') !== null)
                    document.getElementById('controlled-tab-example-tab-Dutch').click();
            });
        }
     }
      render() {
        const { t, description, loading, updateImageUpload, use_existing_file_edit_img, memo_data, error, id } = this.state;
        return (
            <reactbootstrap.Modal show={this.state.showpopup} onHide={this.cancelPopup}  aria-labelledby="example-custom-modal-styling-title" size='xl'>
                <reactbootstrap.Modal.Header closeButton>
                  <reactbootstrap.Modal.Title id="contained-modal-title-vcenter" />
                </reactbootstrap.Modal.Header >
                <reactbootstrap.Modal.Body col-md-12 pr-0>
                  <SecondCycleComonent doc_id={this.props.doc_id} />
                </reactbootstrap.Modal.Body>
                <reactbootstrap.Modal.Footer>
                  <reactbootstrap.Button onClick={() => this.cancelPopup()}>{'Close'}</reactbootstrap.Button>
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );
    }
}
export default translate(Childformpopup)
