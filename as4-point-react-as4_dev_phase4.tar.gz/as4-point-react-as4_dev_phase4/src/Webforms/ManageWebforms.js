import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { translate, t } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import Pagination from 'react-bootstrap/Pagination';
class ManageWebforms extends Component {
    constructor(props) {
        super(props);
        this.state = {
          active_tab:1,
          t: props.t,
          locked_webforms:[],
          webforms:[],
          edited_webforms:[],
          page: 10,
          count: 0,
          active: 1,
          activePage: 1,
          items: [],
        }
        this.handleTabs = this.handleTabs.bind(this);
        this.changePage = this.changePage.bind(this);
      }
      async componentDidMount() {
        await this.fetchWebformdata();

      }
      async handleTabs(key) {
        let tab_key=Number(key);
        const {active_tab,locked_webforms,webforms,edited_webforms} = this.state;
        const data = (tab_key === 1 ? locked_webforms :(tab_key === 2 ? webforms : (tab_key === 3 ?edited_webforms:'')));
        const pageData = this.getPageData(1, data);
        const count = this.getCountPage(data);
        await this.setState({
              active_tab: tab_key,
              count: count,
              items: pageData,
              active:1,
              activePage:1

          });
      }
      fetchWebformdata(){
        const {active_tab}=this.state;
        const data = active_tab === 1 ? 'locked_webforms' :(active_tab === 2 ? 'webforms' : 'edited_webforms');
        datasave.service(window.FETCH_LOCKED_OPENED_WEBFORMS, 'GET')
          .then(async response => {
            if(response.status===200){
              const pageData = this.getPageData(this.state.active, response.result[data]);
              const count = this.getCountPage(response.result[data]);
              await this.setState({
              locked_webforms: response.result['locked_webforms'],
              webforms:response.result['webforms'],
              edited_webforms:response.result['edited_webforms'],
              count: count,
              items: pageData,

            })
          }
          });
      }
      async changePage(e, id) {
        const {active_tab,locked_webforms,webforms,edited_webforms}=this.state;
        const list = (active_tab == 1 ? locked_webforms :(active_tab == 2 ? webforms : edited_webforms));
        const page_data = this.getPageData(id, list);
        const count = this.getCountPage(list);
        await  this.setState({
          items: page_data,
          active: id,
          activePage:id,
          count:count
        });

      }
      getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : '';
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;
      }
      getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
      }
      deleteWebform(id,table_name){
        const data = {
          id : id,
          table_name : table_name,
        }
        datasave.service(window.CLOSE_WEBFORM_CONNECTION, 'POST',data)
        .then(async response => {
          if(response.status==200) {
            OCAlert.alertSuccess(t('Connection closed successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
            this.fetchWebformdata();
          }
          else {
            OCAlert.alertWarning(t('Connection is not closed!'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
        });
      }
      showLockedWebforms(data,table_name) {
        const { t,items } = this.state;
        let table = items.length > 0 && items.map((key) => {
        // let table = (data).length >0 && data.map((key) => {
          return (
            <tr style={{ borderBottom: "1px solid #dee2e6" }} >
              <td style={{ cursor: 'pointer', hover: 'color:#007bf8' }} ><span>{key.doc_name}</span></td>
              <td style={{ cursor: 'pointer', hover: 'color:#007bf8' }} ><span>{key.doc_code}</span></td>
              <td style={{ cursor: 'pointer', hover: 'color:#007bf8' }} ><span>{key.version}</span></td>
              <td style={{ cursor: 'pointer', hover: 'color:#007bf8' }} ><span>{key.person_name}</span></td>
              <td style={{ display: "flex", justifyContent: 'center', borderTop: '0px', borderBottom: '0px', borderLeft: '0px' }}>
                  <reactbootstrap.Button type="submit" name="delete" className="btn btn-primary" onClick={(e) => this.deleteWebform(key.id,table_name)}>{t('Close connection')}</reactbootstrap.Button>
              </td>
            </tr>)
        })
        return table;
      }
      render(){
        const {t,active_tab,count}=this.state;
        let pages = [];
        if (this.state.count > 0) {
          for (let number = 1; number <= count; number++) {
            pages.push(
              <Pagination.Item key={number} active={number === this.state.active} id={number} onClick={(e) => this.changePage(e, number)}>
                {number}
              </Pagination.Item>,
            );
          }
        }
        return(
          <div className=" row col-md-12">
              <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
              <div style={{  }} className='col-md-11' >
              <reactbootstrap.Tabs id='controlled-tab-example' style={{border:'none'}} activeKey={active_tab} onSelect={(k) => this.handleTabs(k)}>
                  <reactbootstrap.Tab eventKey={1} title={t("Open webform todo’s")}>
                  </reactbootstrap.Tab>
                  <reactbootstrap.Tab eventKey={2} title={t("Opened Webforms")}>
                  </reactbootstrap.Tab>
                  <reactbootstrap.Tab eventKey={3} title={t("Opened documents")}>
                  </reactbootstrap.Tab>
              </reactbootstrap.Tabs>
              <div className="mt-5 mr-3">
              <reactbootstrap.Table responsive bordered hover>
                  <thead>
                    <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
                      <th>{t('Document name')}</th>
                      <th>{t('Code')}</th>
                      <th>{t('Version')}</th>
                      <th>{t('Person')}</th>
                      <th>{t('Action')}</th>
                    </tr>
                  </thead>
                  {active_tab===1 &&  <tbody>
                    {this.showLockedWebforms(this.state.locked_webforms,'webform_todo')}
                    </tbody>}
                  {active_tab===2 &&  <tbody>
                      {this.showLockedWebforms(this.state.webforms,'webform')}
                      </tbody>}
                  {active_tab===3 &&  <tbody>
                      {this.showLockedWebforms(this.state.edited_webforms,'locks')}
                      </tbody>}
              </reactbootstrap.Table>
              </div>
              <div className="pg col-md-12">
                {pages.length > 0 && <Pagination style={{ width: '300px', overflow: 'auto' }} size="md">{pages}</Pagination>}
              </div>
          </div>
        </div>
        )
      }
    }
    export default translate(ManageWebforms)
