import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../../language';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';

class Export extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t            : props.t,
      credentials  : this.props.credentials,
      webform_id   : this.props.credentials.webform_id,
      showpopup    : true,
    }
    this.cancelPopup = this.cancelPopup.bind(this);
    this.showPopup   = this.showPopup.bind(this);
  }
  componentDidUpdate(prevProps, prevState) {
      if (prevProps.showExportWebform !== this.props.showExportWebform) {
          this.setState({
              showpopup: true,
          });
      }
  }
  cancelPopup() {
      this.props.hideExportWebform();
  }
  showPopup() {
      this.setState({ showpopup: true });
  }

  getdataToPost = async () => {
     let data = {
       webform_id : this.state.webform_id,
     }
     return data;
  }

  handleExport = async () => {
    const { t } = this.state;
    let data = await this.getdataToPost();
      datasave.service(window.EXPORT_WEBFORM, 'POST', data).
      then(response => {
        if(response.status === '200') {
              var a      = document.createElement("a");
              a.href     = response.data.url;
              a.download = response.data.name;
              document.body.appendChild(a);
              a.click();
              a.remove();
              this.cancelPopup();
        } else {
             OCAlert.alertError(t('Error occured while downloading webform..!'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      });
  }
  render() {
    const {showpopup, t } = this.state;
    return (
        <reactbootstrap.Modal show={showpopup} onHide={this.cancelPopup}>
            <reactbootstrap.Modal.Header closeButton />
            <reactbootstrap.Container>
                <reactbootstrap.Modal.Body>
                <p>{t('Do you want to export webform?')}</p>
                </reactbootstrap.Modal.Body>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Modal.Footer></reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.cancelPopup} >{t('Cancel')}</reactbootstrap.Button>
                    <reactbootstrap.Button type="submit" onClick={this.handleExport} color="primary">{t('Export')}</reactbootstrap.Button>
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Container>
        </reactbootstrap.Modal>
    );
  }
}
export default translate(Export);
