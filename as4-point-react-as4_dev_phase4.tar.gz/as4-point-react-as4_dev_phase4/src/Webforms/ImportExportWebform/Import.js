import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../../language';
import { OCAlert } from '@opuscapita/react-alerts';
import CheckBox from '../../CheckBox';
import axios from 'axios';
import Spinner from 'react-bootstrap/Spinner';

class Import extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t : props.t,
      webform_id   : this.props.credentials.webform_id,
      manual_id    : this.props.credentials.manual_id,
      fileName     : '',
      showpopup    : true,
      fileWarning  : false,
      changeName   : false,
      nameWarning  : false,
      name         : '',
      fileData     : '',
      isLoading    : false,
      sizeWarning  : false,
    }
    this.cancelPopup      = this.cancelPopup.bind(this);
    this.showPopup        = this.showPopup.bind(this);
    this.handleFileChange = this.handleFileChange.bind(this);
    this.updateFolder     = this.updateFolder.bind(this);
  }
  componentDidUpdate(prevProps, prevState) {
      if (prevProps.showImportWebform !== this.props.showImportWebform) {
          this.setState({
              showpopup: true,
              file_details: '',
          });
      }
  }
  cancelPopup() {
      this.props.hideImportWebform();
  }
  showPopup() {
      this.setState({ showpopup: true });
  }
  updateFolder() {
    this.props.updateFolder(this.state.manual_id);
  }
  handleFileChange = (e) => {
    let files      = e.target.files;
    let name       = files[0].name;
    let size       = files[0].size/1000; //calculating file size in kilobytes
    this.setState({
      fileName    : name,
      fileWarning : false,
      fileData    : files[0],
      sizeWarning : size > 4000 ? true : false,
    });
  }
  getData = () => {
    let data = {
      fileName      : this.state.fileName,
      webform_id    : this.state.webform_id,
      changeName    : (this.state.changeName === true ? 1 : 0),
      webform_name  : this.state.name,
      fileData      : this.state.fileData,
    }
    return data;
  }
  changeNameValidation = () => {
    let status = true;
    const {changeName, name} = this.state;
    if(changeName && name == '') {
      this.setState({ nameWarning : true });
      status = false
    }
    return status;
  }
  handleSubmit = async () => {
    this.setState({ isLoading : true })
    const {t, fileName} = this.state;
    let data = JSON.stringify( await this.getData() );
    if(fileName !=='') {
      let status = await this.changeNameValidation();
      if(status){
      const formData = new FormData();
      formData.append('file', this.state.fileData);
      formData.append('details',data);
      const url = window.IMPORT_WEBFORM;
      axios.post(window.backendURL + url, formData)
          .then(response => {
            this.setState({ isLoading : false })
              if(response['data'].status === '200'){
              OCAlert.alertSuccess(t('Webform imported successfully.!'), { timeOut: window.TIMEOUTNOTIFICATION });
              this.cancelPopup()
              if(this.state.changeName) {
                this.updateFolder();
              }
              } else{
                this.setState({ isLoading : false })
                OCAlert.alertError(t('Error occured while importing webform please try with another file.'), { timeOut: window.TIMEOUTNOTIFICATION });
              }
          })
     }
   } else {
     this.setState({ fileWarning : true });
   }
  }
  handleName = (e) => {
    this.setState({
      name : e.target.value,
    });
  }
  handleCheckBox = (e) => {
      const { name, checked } = e.target
      this.setState({ [name]: checked })
  }
  render() {
    const { t, fileName, showpopup, fileWarning,
      changeName, nameWarning, name, isLoading, sizeWarning} = this.state;

    const loadingAttributes = {
          'position':'absolute',
          'top':'50%',
          'left':'50%',  }

    return (
        <reactbootstrap.Modal style ={{}} show={showpopup} onHide={this.cancelPopup}>
            <reactbootstrap.Modal.Header closeButton>
                <reactbootstrap.Modal.Title>{t('Import webform')}</reactbootstrap.Modal.Title>
            </reactbootstrap.Modal.Header>
            <reactbootstrap.Container>
                <reactbootstrap.Modal.Body>
                    <reactbootstrap.FormGroup>
                        <reactbootstrap.InputGroup.Prepend>{t('Upload file')}</reactbootstrap.InputGroup.Prepend>
                        <input
                            type = "file"
                            name = {fileName}
                            onChange = {this.handleFileChange}
                            accept  = {".sql"}
                         />
                    </reactbootstrap.FormGroup>
                    {fileWarning && <reactbootstrap.Form.Text style={{ color: 'red' }}>
                        {t('Select file to Import the webform.')}
                    </reactbootstrap.Form.Text>}
                    <reactbootstrap.FormGroup>
                    <reactbootstrap.Col className="col-md-10">
                        <reactbootstrap.Form.Group as='changeName'>
                            <CheckBox
                                tick={changeName}
                                style={{ paddingLeft: '0px' }}
                                onCheck={this.handleCheckBox}
                                name="Change name"
                                classification="changeName"
                            />
                        </reactbootstrap.Form.Group>
                    </reactbootstrap.Col>
                    </reactbootstrap.FormGroup>
                    {changeName && <reactbootstrap.Col className="col-md-10">
                        <reactbootstrap.Form.Group controlId="formName" className="row ">
                            <reactbootstrap.Form.Label style={{ alignSelf: 'center' }} className="col-md-6">
                                {t('Save webform As:')}<span style={{ color: "red" }}> *</span>
                            </reactbootstrap.Form.Label>
                            <reactbootstrap.Form.Control className="col-md-6  " as="input"
                                type="text"
                                required
                                name='name'
                                value={name}
                                onChange={this.handleName} />
                            {nameWarning && <reactbootstrap.Form.Text style={{ color: "red" }} >
                                {t('Enter webform name.')}
                            </reactbootstrap.Form.Text>}
                        </reactbootstrap.Form.Group>
                    </reactbootstrap.Col>}
                    { isLoading &&
                      <Spinner style = {loadingAttributes} animation="border" variant="primary"/>
                    }
                </reactbootstrap.Modal.Body>
                {sizeWarning && <reactbootstrap.Form.Text style={{ color: 'red', fontSize: 'smaller' }}>
                {t('File contains large amount of data, importing may take more than usual time.')}
                </reactbootstrap.Form.Text>}
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Modal.Footer></reactbootstrap.Modal.Footer>
                      <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.cancelPopup} >{t('Cancel')}</reactbootstrap.Button>
                      <reactbootstrap.Button type="submit" onClick={this.handleSubmit} color="primary">{t('Import')}</reactbootstrap.Button>
                </reactbootstrap.Modal.Footer>
                {/* </reactbootstrap.Form> */}
            </reactbootstrap.Container>
        </reactbootstrap.Modal>
    );
  }
}
export default translate(Import);
