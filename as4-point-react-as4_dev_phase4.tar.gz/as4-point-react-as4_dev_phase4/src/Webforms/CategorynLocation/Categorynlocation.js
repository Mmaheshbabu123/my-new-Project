import React, { Component } from 'react';
import MultiSelect from '../../_components/MultiSelect';
import { datasave } from '../../_services/db_services';
import * as reactbootstrap from 'react-bootstrap';



class Categorynlocation extends Component {
        constructor(props){
          super(props)
          this.state = {
            category_list :[],
            location_list :[],
            c_value: '',
            l_value: '',

          }
   }

    componentDidMount(){
      let listOrSublists = this.props.comingFrom ? 1 : 0;
       datasave.service(window.CATEGORY_LOCATION + window.CATEGORY + '/' + listOrSublists,'GET').then(
         response => {
              this.setState({
                category_list : response
              })
         }
       )
         datasave.service(window.CATEGORY_LOCATION + window.LOCATION + '/' + listOrSublists ,'GET').then(
               response => {
                  this.setState({
                    location_list : response
                  })
               }
          )
    }


  render(){
    let category = this.state.category_list.filter(ele => ele.value != this.props.category_id);
    let location = this.state.location_list.filter(ele =>ele.value != this.props.Location_id);

    return (
            <reactbootstrap className="row" >
            <div className="col-md-12">
                      <reactbootstrap.Row className="row col-md-12 mt-3">
                        {(this.props.categoryOrLocation === 3 || this.props.comingFrom !== window.ROWGENERATOR) &&
                        <reactbootstrap.Col className={this.props.comingFrom === window.ROWGENERATOR ? "col-md-6" : "col-md-4"}>
                        <reactbootstrap.Form.Group className="row ">
                            <reactbootstrap.Form.Label className = "col-md-5 common-color ">
                               {'Category'}:
                            </reactbootstrap.Form.Label>
                                  <div className = "col-md-7 p-0 ">
                                  <reactbootstrap.Form.Group>
                                  <MultiSelect
                                      options= {category}
                                      standards={this.props.category_id ? this.state.category_list.find(ele => ele.value == this.props.category_id) : ''}
                                      handleChange={this.props.handleChangeCategory}
                                      isMulti = {false}
                                  />
                                    </reactbootstrap.Form.Group>
                                  </div>
                                  </reactbootstrap.Form.Group>
                                </reactbootstrap.Col>}
                      {(this.props.categoryOrLocation === 4 || this.props.comingFrom !== window.ROWGENERATOR) &&
                         <reactbootstrap.Col className={this.props.comingFrom === window.ROWGENERATOR ? "col-md-6" : "col-md-4"}>
                           <reactbootstrap.Form.Group className="row ">
                                <reactbootstrap.Form.Label className = "col-md-5 common-color">{'Location'}:</reactbootstrap.Form.Label>
                                <div className = 'col-md-7 p-0'>
                                <reactbootstrap.Form.Group>
                                      <MultiSelect
                                        options = {location}
                                        name = "location"
                                        standards={this.props.Location_id ? this.state.location_list.find(ele => ele.value == this.props.Location_id) : ''}
                                        handleChange  = {this.props.handleChangeLocation}
                                        isMulti = {false}
                                      /*  value = {this.props.category_value} */
                                      />
                                    </reactbootstrap.Form.Group>
                               </div>
                            </reactbootstrap.Form.Group>
                        </reactbootstrap.Col>}
                      </reactbootstrap.Row>
                  </div>
                  </reactbootstrap>

    );
  }
}
export default Categorynlocation
