import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import language, { translate } from '../language';
import { Link } from "react-router-dom";
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from '../store';
import { datasave } from '../_services/db_services';


class AlertPopUpComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            t: props.t,
        }
    }



    render() {

        const { t } = this.state;
        return (
            <div>
                <reactbootstrap.Modal show={this.props.show} onHide={this.props.handleClose}>
                    <reactbootstrap.Modal.Header closeButton>
                        <reactbootstrap.Modal.Title>{this.props.titleName}</reactbootstrap.Modal.Title>
                    </reactbootstrap.Modal.Header>
                    <reactbootstrap.Modal.Body>{this.props.displayMsg}</reactbootstrap.Modal.Body>
                    <reactbootstrap.Modal.Footer>
                        <reactbootstrap.Button variant="secondary" onClick={this.props.handleClose}>
                            {this.props.closeButtonName}
                        </reactbootstrap.Button>
                        <reactbootstrap.Button variant="primary" onClick={this.props.handleSave}>
                            {this.props.saveButtonName}
                        </reactbootstrap.Button>
                    </reactbootstrap.Modal.Footer>
                </reactbootstrap.Modal>
            </div>
        )


    }

}

export default translate(AlertPopUpComponent);