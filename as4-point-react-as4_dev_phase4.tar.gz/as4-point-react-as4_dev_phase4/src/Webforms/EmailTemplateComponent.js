import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import language, { translate } from '../language';
import { Button, FormGroup } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from '../store';
import { datasave } from '../_services/db_services';
import { Editor } from 'react-draft-wysiwyg';
import draftToHtml from 'draftjs-to-html';
import htmlToDraft from 'html-to-draftjs';
import { EditorState, convertToRaw, ContentState,convertFromRaw } from 'draft-js';
import '../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css';

// const contentBlock = htmlToDraft(this.state.description);
// if (contentBlock) {
//   const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks);
//   const editorState = EditorState.createWithContent(contentState);
//   return editorState;
// }

class EmailTemplateComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            t: props.t,
            id: this.props.webelement_id,
            webform_id: this.props.webform_id,
            language_list: [],
            activeTab: 1,
            language_data: [],
            Name_1: '',
            name_error: '',
            status: this.props.editStatus,
        }
    }

    handleText(name, value) {
        this.setState({ [name]: value, name_error: '' })
    }

     getEditableData() {
        if (this.props.webelement_id != undefined && this.props.webelement_id != 0 && this.props.editStatus == true) {
             datasave.service(window.GET_EMAILTEMPLATE_BY_ID + '/' + this.props.webelement_id, 'GET')
                .then(async response => {
                    if (response['status'] == 200) {
                      let language_data = response['data']['language_data'];
                      console.log(language_data);
                      this.convertContentToEditorObj(language_data);
                      console.log(language_data);
                        this.setState({
                            Name_1: response['data']['Name_1'],
                            language_data: language_data,
                            status: false
                        })
                    }
                });
        } else {
            if (this.props.addStatus) {
                this.handleCancel();
            }
        }
    }


    async convertContentToEditorObj(language_data){
      if(Object.keys(language_data).length > 0){
         await Object.keys(language_data).map(key=>{
          if(key.indexOf('body') !== -1){
            let contentBlock = htmlToDraft(language_data[key]);
            if (contentBlock) {
              const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks);
              language_data[key] = EditorState.createWithContent(contentState);
            }
          }
        })
      }
    }
    render() {
        const { t } = this.state;
        return (
            <reactbootstrap.Container style={{}}>
                {this.getEditableData()}
                <div class="row mb-5">
                    <div class="col-md-12 row">
                        <div class={(this.props.tokenDisplay == false ? "col-md-12" : "col-md-8 p-0")}>
                            {this.displayTabs()}
                            <reactbootstrap.Form>
                                <div className="col-md-12 row p-0 mt-2">
                                    <div style={{color: '#EC661C'}} className="col-md-2">
                                        <reactbootstrap.Form.Label>{t('Name:')}<span style={{color: 'red'}}>*</span></reactbootstrap.Form.Label>
                                    </div>
                                    <div className="col-md-10 pr-0">
                                        <reactbootstrap.Form.Group>
                                            <reactbootstrap.Form.Control type={'text'} placeholder={t('Name')} value={this.state.Name_1} onChange={(e) => this.handleText('Name_1', e.target.value)} disabled={this.props.viewStatus}></reactbootstrap.Form.Control>
                                            <span style={{ color: 'red' }}>{this.state.name_error}</span>
                                        </reactbootstrap.Form.Group>

                                    </div>
                                </div>
                                {this.displaySubjectBody()}

                            </reactbootstrap.Form>

                            {this.displayButton()}
                        </div>

                        <div class="col-md-4" style={{ 'padding-top': '2.8rem', 'display': (this.props.tokenDisplay == true ? 'block' : 'none') }} >
                            <reactbootstrap.Form.Label><h4>{t('Tokens:')}</h4></reactbootstrap.Form.Label>
                            <ul style={{paddingLeft: '17px', backgroundColor: '#FFF', fontSize: '12px'}}>

                              {this.displayTokens()}
                            </ul>

                        </div>

                    </div>
                </div>

            </reactbootstrap.Container>
        )
    }

    displayTokens(){
      let tokensData = this.props.tokensData;
      if(Object.keys(tokensData).length > 0){
        return Object.keys(tokensData).map(key=>{
          return (<li>{key}</li>);
        })
      }
    }

    //-----------tabs-----------------
    handleTab(key) {
        this.setState({ activeTab: key });
    }

    displayTabs() {
        let table = [];

        if (this.state.language_list.length > 0) {
            table.push(<reactbootstrap.Tabs defaultActiveKey={this.state.activeTab} id="uncontrolled-tab-example" onSelect={(k) => this.handleTab(k)}>
                {this.getTab()}
            </reactbootstrap.Tabs>)
        }
        return table;
    }

    getTab() {
        let language_list = this.state.language_list;
        let table = [];
      const { t } = this.state;
        language_list.map(key => {
            table.push(
                <reactbootstrap.Tab eventKey={key['id']} title={t(key['language'])} >
                </reactbootstrap.Tab>
            )
        })
        return table;
    }

    //----------------------------------------


    //--------------subject body------------------


    handleSubBody(name, value) {
        const obj = { [name]: value };
        const tempObj = { ...this.state.language_data, ...obj }
        console.log(tempObj);
        this.setState({ language_data: tempObj });
    }


    displaySubjectBody() {
        let table = [];
        const { t } = this.state;
        let subject = this.state.language_data['subject_' + this.state.activeTab];
        let body = this.state.language_data['body_' + this.state.activeTab];
        let disabled = this.props.viewStatus;
        table.push(
            <div>
                <div className="col-md-12 row p-0">
                <div style={{color: '#EC661C'}} className="col-md-2">
                <reactbootstrap.Form.Label>{t('Subject:')}</reactbootstrap.Form.Label>
                </div>
                <div className="col-md-10 pr-0">
                  <reactbootstrap.Form.Group>
                      <reactbootstrap.Form.Control type={'text'} placeholder={t('New webform') + ' !revision'} value={subject != undefined ? subject : ''} onChange={(e) => this.handleSubBody('subject_' + this.state.activeTab, e.target.value)} disabled={disabled}></reactbootstrap.Form.Control>
                  </reactbootstrap.Form.Group>
                </div>
                </div>
                <div className="col-md-12 row p-0">
                <div style={{color: '#EC661C'}} className="col-md-2">
                <reactbootstrap.Form.Label>{t('Body:')}</reactbootstrap.Form.Label>
                </div>
                <div className="col-md-10 pr-0">

                <Editor
                  editorState={body != undefined ? body : EditorState.createEmpty()}
                  toolbarClassName="toolbarClassName"
                  wrapperClassName="wrapperClassName"
                  editorClassName="editorClassName"
                  editorStyle={{fontSize: '12px'}}
                  onEditorStateChange={(editorState) => this.handleSubBody('body_' + this.state.activeTab, editorState)}
                  toolbar={{
                    options: ['inline', 'blockType', 'fontFamily','fontSize', 'colorPicker', 'list', 'textAlign', 'history', 'link','remove'],
                  }}
                />
                </div>
                </div>
            </div >
        )
        return table;

        // <reactbootstrap.Form.Group>
        //     <reactbootstrap.Form.Control as='textarea' placeholder={this.getBodyPlaceHolder()} value={body != undefined ? body : ''} onChange={(e) => this.handleSubBody('body_' + this.state.activeTab, e.target.value)} rows={5} cols={100} disabled={disabled}></reactbootstrap.Form.Control>
        // </reactbootstrap.Form.Group>

    }
    getBodyPlaceHolder() {
        const { t } = this.state;
        let placeHolder = t('Dear') + ' !user' + '\n' +
            '\n' +
            t('A new form') + ' !revision ' + t('is waiting for you') + ', ' + '\n' +
            t('This form needs to be filled out') + '\n' +
            t('Go to your portal to access this form') + ' !url';
        return placeHolder;
    }




    //----------------------------------------------

    //----------------------Buttons----------------
    displayButton() {
        const { t } = this.state;
        if (this.props.webelement_id != undefined && this.props.webelement_id != 0) {
            return (
              <div className="mr-3 mt-3" style={{float: 'right'}}><reactbootstrap.Button onClick={(e) => this.handleUpdate()} disabled={this.props.viewStatus}>
                {t('Save changes')}
            </reactbootstrap.Button>
          </div>);
        } else {
            // return (<div>
            //     <reactbootstrap.Button onClick={(e) => this.handleCancel()}>
            //         {t('Cancel')}
            //     </reactbootstrap.Button>
            //     <reactbootstrap.Button onClick={(e) => this.handleSave()}>
            //         {t('Save')}
            //     </reactbootstrap.Button></div>);


            return (<div style={{ float: 'right' }} className="organisation_list mt-3 pr-3">
                <a onClick={(e) => this.handleCancel()} > {t('Cancel')} </a>
                &nbsp;&nbsp;&nbsp;
             <Button type="submit" name="save" className="btn btn-primary" onClick={(e) => this.handleSave()}>{t('Save')}</Button>

            </div>);



        }
    }

    handleCancel() {
        let language_data = this.state.language_data;
        language_data = {};
        this.setState({ language_data: language_data, Name_1: '' });
    }

    async handleSave() {
        const { t } = this.state;
        let language_data = this.state.language_data;
        await this.convertEditorObjToContent(language_data);
        let data = {
            user_id: 871,
            Name_1: this.state.Name_1,
            language_data: language_data,
            webform_id: this.props.webform_id,
            tokensData: this.props.tokensData
        }
        if (this.state.Name_1.length > 0) {
            await datasave.service(window.INSERT_WEB_EMAILTEMPLATE, 'POST', data)
                .then(async response => {
                    if (response['status'] == 200) {
                        if (response['NameExist'] == 0) {
                            OCAlert.alertSuccess(t('Save successfull'), { timeOut: window.TIMEOUTNOTIFICATION });
                            await this.convertContentToEditorObj(this.state.language_data);
                            this.props.handleAfterSave(1);
                        } else {
                            await this.convertContentToEditorObj(this.state.language_data);
                            OCAlert.alertError(t('Name exist'), { timeOut: window.TIMEOUTNOTIFICATION });
                        }
                    } else if (response['status'] == 400) {
                        OCAlert.alertError(t('Error saving template, Please try again!'), { timeOut: window.TIMEOUTNOTIFICATION });
                    } else {
                        OCAlert.alertError(t(response['Msg']), { timeOut: window.TIMEOUTNOTIFICATION });
                    }
                });
        } else {
            await this.convertContentToEditorObj(this.state.language_data);
            this.setState({ name_error: 'Name field is mandatory' })
        }
    }

    async convertEditorObjToContent(language_data){
      if(Object.keys(language_data).length > 0){
      await Object.keys(language_data).map(key=>{
        console.log(key);
          if(key.indexOf('body') !== -1){
            language_data[key] = this.convToEditObjSubFunc(language_data[key]);
          }
        })
      }
    }

    convToEditObjSubFunc(data){
      if(data != undefined){
        return draftToHtml(convertToRaw(data.getCurrentContent()));
      }else{
        return {};
      }
    }

    async handleUpdate() {
        let language_data = this.state.language_data;
        await this.convertEditorObjToContent(this.state.language_data);
        const { t } = this.state;
        let data = {
            Name_1: this.state.Name_1,
            language_data: language_data,
            id: this.props.webelement_id,
            webform_id: this.props.webform_id,
            tokensData: this.props.tokensData
        }

        if (this.state.Name_1.length > 0) {
            await datasave.service(window.UPDATE_WEB_EMAIL, 'POST', data)
                .then(async response => {
                    if (response['status'] == 200) {
                        if (response['NameExist'] == 0) {
                            OCAlert.alertSuccess(t('Updated successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
                            await this.convertContentToEditorObj(this.state.language_data);
                            this.props.handleAfterSave(0);
                        } else {
                            await this.convertContentToEditorObj(this.state.language_data);
                            OCAlert.alertError(t('Name exist'), { timeOut: window.TIMEOUTNOTIFICATION });
                        }
                    } else if (response['status'] == 400) {
                        OCAlert.alertError(t('Error saving template, Please try again!'), { timeOut: window.TIMEOUTNOTIFICATION });
                    } else {
                        OCAlert.alertError(t(response['Msg']), { timeOut: window.TIMEOUTNOTIFICATION });
                    }
                });
        } else {
            await this.convertContentToEditorObj(this.state.language_data);
            this.setState({ name_error: 'Name field is mandatory' })
        }


    }
    //---------------------------------------------------

    componentDidMount() {
        datasave.service(window.GET_TRANSLATION, 'GET')
            .then(response => {
                this.setState({ language_list: response, status: true })
            });

    }
}

export default translate(EmailTemplateComponent);
