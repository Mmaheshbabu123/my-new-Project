import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import language, { translate } from '../language';
import { Link } from "react-router-dom";
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from '../store';
import { datasave } from '../_services/db_services';


class EmailTemplateManageComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            t: props.t,
            webform_id: this.props.webform_id,
            emailTemplateList: [],
            status: false
        }
    }

    handleOnClick(id, editStatus, viewStatus) {
        this.props.handleEmailTemplateList(id, editStatus, viewStatus);
    }
    displayEmailTemplateList() {
        let table = [];
        const { t } = this.state;
        let emailTemplates = this.state.emailTemplateList;
        if (emailTemplates.length > 0) {
            emailTemplates.map(key => {
                table.push(<div style={{ borderBottom: '0.5px solid lightgray' }} className="row pt-3 pb-3"><div className="col-md-6">{key['name']}</div>
                    <div style={{ display: 'flex', justifyContent: 'center' }} className="col-md-6">
                        <reactbootstrap id={key['id']} onClick={(e) => this.handleOnClick(key['id'], true, false)}><i title="Edit" class="overall-sprite overall-sprite-myeditc"></i></reactbootstrap>&nbsp;&nbsp;
                    <reactbootstrap id={key['id']} onClick={(e) => this.handleOnClick(key['id'], true, true)}><i title="View" class="overall-sprite overall-sprite-gridopenc"> </i></reactbootstrap>&nbsp;&nbsp;
                    <reactbootstrap><i id={key['id']} onClick={this.props.handleDeletePopUP} title="Delete" class="overall-sprite overall-sprite-mtdeletec"></i></reactbootstrap>
                    </div>
                </div>);
            })
        }
        return table;
    }

    render() {

        const { t } = this.state;
        console.log('Manage');
        if (this.state.status) {
            return (
                <reactbootstrap.Container className="" style={{height: '400px',overflow: 'auto'}}>
                    {this.displayEmailTemplateList()}
                    {this.props.callDidMount == true ? this.componentDidMount() : ''}
                </reactbootstrap.Container>
            )
        } else {
            return (
                <h5>
                    {t('.....Loading')}
                </h5>

            )
        }

    }
    componentDidMount() {
      console.log('manage did mount is called');
        datasave.service(window.MANAGE_EMAIL_TEMPLATE + '/' + this.state.webform_id, 'GET')
            .then(response => {
                if (response['status'] == 200) {
                    this.setState({
                        emailTemplateList: response['data'],
                        status: true,
                    })
                } else {
                    OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
                }
            });

    }
}

export default translate(EmailTemplateManageComponent);
