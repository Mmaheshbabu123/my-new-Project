import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import language, { translate } from '../language';
import { Link } from "react-router-dom";
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from '../store';
import { datasave } from '../_services/db_services';
import EmailTemplateManageComponent from '../Webforms/EmailTemplateManageComponent';
import EmailTemplateComponent from '../Webforms/EmailTemplateComponent';

class EmailTemplateWindow extends Component {
    constructor(props) {
        super(props)
        this.state = {
            t: props.t,
            status: true,
            webelement_id: 0,
            webform_id: this.props.webform_id == undefined ?
                this.props.match.params.webform_id : this.props.webform_id,
            editStatus: false,
            didUpdate: true,
            emailTemplateCompStatus: false,
            viewStatus: false,
            addStatus: false,
            callDidMount: false,
            showPopUp: false,
            deleteId: 0,
            tokensData:{}
        }
    }
    handleEmailTemplateList(id, editStatus, viewStatus) {

        this.setState({
            webelement_id: parseInt(id), editStatus: editStatus, viewStatus: viewStatus, didUpdate: true, emailTemplateCompStatus: true
        });
    }

    handleAdd() {
        this.setState({
            webelement_id: undefined,
            editStatus: false,
            viewStatus: false,
            addStatus: true,
            didUpdate: true,
            emailTemplateCompStatus: true
        })
    }
    handleDeletePopUP(id) {
        console.log(id);
        console.log('delete');
        this.setState({ deleteId: id, showPopUp: true });
    }

    deleteService(id) {
        datasave.service(window.REMOVE_WEBEMAIL_TEMPLATE + '/' + id, 'GET')
            .then(response => {
                if (response['status'] == 200) {
                    this.setState({ callDidMount: true, addStatus: true, viewStatus: false, didUpdate: true, webelement_id: undefined, showPopUp: false })
                } else {
                    OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });

                }
            })
    }

    handleAfterSave(save) {
      console.log('after save');
        let Obj = parseInt(save) == 1 ? {
            webelement_id: undefined, editStatus: false, viewStatus: false,
            addStatus: true, didUpdate: true, callDidMount: true
        } : {
                didUpdate: true, callDidMount: true
            };
        this.setState(Obj);

    }

    render() {
        const { t } = this.state;
        console.log('window');
        if (this.state.status) {
            return (
                <reactbootstrap>

                    <div class="row col-md-12 mt-3 mb-3">

                        <div class="col-md-4">
                            <div style={{ display: 'flex', borderBottom: '1px solid lightgray' }} >
                                <span><h4>{t('Manage email templates')}</h4></span>
                                <div style={{ alignSelf: 'center' }} className="ml-3">
                                    <reactbootstrap style={{ cursor: 'pointer' }} title={t("Add email")} onClick={(e) => this.handleAdd()}><i class="webform-sprite webform-sprite-addemailc"></i></reactbootstrap>
                                </div>
                            </div>

                            <EmailTemplateManageComponent webform_id={this.state.webform_id} handleEmailTemplateList={this.handleEmailTemplateList.bind(this)} handleDeletePopUP={(e) => this.handleDeletePopUP(e.target.id)} callDidMount={this.state.callDidMount} ></EmailTemplateManageComponent>
                        </div>
                        <div class="col-md-8 p-0">
                            <div style={{ borderBottom: '1px solid lightgray' }} >
                                <span><h4>{t('Create email template')}</h4></span>
                            </div>
                            <div>
                                {this.state.emailTemplateCompStatus && <EmailTemplateComponent webform_id={this.state.webform_id} webelement_id={this.state.webelement_id} editStatus={this.state.editStatus}
                                    tokenDisplay={true} viewStatus={this.state.viewStatus} addStatus={this.state.addStatus}
                                    handleAfterSave={this.handleAfterSave.bind(this)} tokensData={this.state.tokensData}></EmailTemplateComponent>}
                            </div>
                        </div>

                    </div>
                    <div>{this.displayPopUp()}</div>
                </reactbootstrap >
            )
        } else {
            return (
                <h5>
                    {t('.....Loading')}
                </h5>
            )
        }
    }
    displayPopUp() {
        const { t } = this.state;
        return (
            <reactbootstrap.Modal show={this.state.showPopUp} onHide={(e) => this.handlePopUpClose()}>
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title>{t('Alert')}</reactbootstrap.Modal.Title>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Modal.Body>{t('Do you want to delete respective template!')}</reactbootstrap.Modal.Body>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button variant="secondary" onClick={(e) => this.handlePopUpClose()}>
                        {t('No')}
                    </reactbootstrap.Button>
                    <reactbootstrap.Button variant="primary" onClick={(e) => this.deleteService(this.state.deleteId)}>
                        {t('Yes')}
                    </reactbootstrap.Button>
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        )
    }
    handlePopUpClose() {
        this.setState({ showPopUp: false })
    }

    componentDidUpdate() {
        if (this.state.didUpdate) {
            this.setState({
                editStatus: false,
                didUpdate: false,
                addStatus: false,
                callDidMount: false
            })
        }
    }

    componentDidMount(){
      datasave.service(window.GET_WEBEMAIL_TOKENS + '/' + this.state.webform_id, 'GET')
          .then(response => {
            console.log(response);
            if(response['status'] == 200){
              this.setState({tokensData:response['data']});
            }
          });
    }



}

export default translate(EmailTemplateWindow);
