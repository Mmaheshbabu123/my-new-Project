import React,{Component} from 'react';
import * as reactbootstrap from "react-bootstrap";
import WebFormBuild from './Views/WebformBuildAction';
import { OCAlert } from '@opuscapita/react-alerts';
import { datasave } from '../_services/db_services';
import { translate } from '../language';


 class ChildformSimulate extends Component {
   constructor(props) {
     super(props);
     this.state = {
       show: false,
       webformid:this.props.childwebform,
       data: this.props.data,
       todo_id: this.props.todo_id,
       simulate:this.props.simulate,
       refid: this.props.refid,
       submit_id : this.props.submit_id,
       webform_id: this.props.childwebform,
       stepid:  this.props.step_id,
       parent_id:this.props.parent_id,
       child_form_id:this.props.id,
       parent_details_id:0,
       // parent_id:0,
       simulatechildform: this.props.simulate,
       loadContent : true,
       iddUpdatedByRecentSave:false,
       childform_newtab : false,
       showparent : true,
       show_last_filled_webform : true,
       t:props.t
     }
        this.showPopup = this.showPopup.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.generateForm  = this.generateForm.bind(this);
        this.parentStateObj = {};
   }

   handleHide = async () => {
     this.setState({ show: false });
   };

   componentDidMount(){
     //
   }

   async showPopup(){
    var main_webform_id = window.location.pathname.split('/');
     if (this.props.target==2){
        let { webform_id, refid, stepid, child_form_id} = this.state;
	let parentState = this.props.getParentUpdateState();
	let child_linked_unique_id = parentState.state.child_linked_unique_id !== undefined ? Object.assign({}, parentState.state.child_linked_unique_id) : {};
	     let resultObj = await this.props.handleSubmit(undefined, {stepid: stepid, webform_id: webform_id, child_form_id: child_form_id, refid: refid, child_type: 14, create_unique_id: 1});
           if(child_linked_unique_id[child_form_id] !== undefined){
	   child_linked_unique_id[child_form_id].push(resultObj['created_unique_id']);
	   }else{
	    child_linked_unique_id[child_form_id] =  [resultObj['created_unique_id']];
     }

    //  let goback = window.location.search.replace('?q=', '');
    //  console.log(goback);
       await this.props.parentSaved({ submit_details_id: resultObj['parent_details_id'],submit_id: resultObj['parent_id'],parent_details_id: resultObj['parent_details_id'], parent_id: resultObj['parent_id'], child_linked_unique_id : child_linked_unique_id}, false, '', '', '');
       var goto_parent = window.location.search!=''?window.location.pathname:window.location.pathname;
       var pathname = window.location.search!=''?'?q='+'/notifications':'?q='+window.location.pathname;
       var search_path = window.location.search!=''?btoa(window.location.search):0;
        var main_webform_id = window.location.pathname.split('/');
	     window.open(window.location.origin + '/' + 'webformaction' + '/' + this.state.webformid + '/' + parentState.state.notDirectSimulation + '/' + 4 + '/' + 1 + '/' + (resultObj['created_unique_id']) + '/' + (resultObj['parent_id']) + '/' + child_form_id + '/0' + '/'+1+'/'+main_webform_id[2]+'/'+search_path+'/'+btoa(goto_parent)+'/0/' + pathname, '_blank');
      }
      else {
        this.parentStateObj = this.props.getParentUpdateState();
       let { webform_id, refid, stepid, child_form_id} = this.state;
        let resultObj = await this.props.handleSubmit(undefined, {stepid: stepid, webform_id: webform_id, child_form_id: child_form_id, refid: refid, child_type: 14, create_unique_id: 0});
        let parent_id = resultObj['parent_id'];
        let parent_details_id = resultObj['parent_details_id'];
        datasave.service(window.FETCH_CHILDFORM_SETTINGS+'/'+main_webform_id[2],'GET')
        .then(async response=>{
            await this.setState({
                showparent : response[0]['showparent'],
                show_last_filled_webform : response[0]['show_last_filled_webform'],
                parentDepending_ele_array : resultObj['parentDepending_ele_array'],
            })
        })
        // if(parseInt(refid) === 0){
        //   await this.props.parentSaved({submit_details_id:parent_details_id,submit_id:parent_id,parent_details_id:parent_details_id, parent_id:parent_id},true,child_form_id,child_submit_id,'submit_childform_id');
        // }else{
          await this.props.parentSaved({ submit_details_id:parent_details_id,submit_id:parent_id,parent_details_id:parent_details_id, parent_id:parent_id},false,'','','');
        // }
       this.setState({
         show:true,
         parent_id:parent_id,
         parent_details_id:parent_details_id,
         // refid: parseInt(child_submit_id) !== 0 ? child_submit_id : refid,
         refid: 0,
         // iddUpdatedByRecentSave:parseInt(child_submit_id) !== 0 ? true : false,
       })
     }
   }
   handleClose(){
     const {refid, child_form_id, parent_id} = this.state;
     if(this.state.iddUpdatedByRecentSave){
        datasave.service(window.DELETE_UPDATE_CHILDSUBMIT + '/' + refid + '/' + child_form_id + '/' + parent_id, "GET")
         .then(response => {
           if(response['status'] == 200){
            this.props.parentSaved({},true,child_form_id,0,'submit_childform_id');
            this.setState({show:false,refid:0});
           }else{
             OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
           }
         });
    }else{
      this.setState({show:false});
    }
   }

   async handleElementSaveSubmit(id,submit_id){
     await this.props.parentSaved({}, true, id, submit_id, 'submit_childform_id');
     this.setState({show:false});
     this.props.updateParentAfterChildSendSave(this.parentStateObj.state, this.parentStateObj.queryObj);
     // this.handleClose();
   }

   async generateForm(){
     let resultObj = await this.props.handleSubmit();
     let parent_id = resultObj['parent_id'];
     let parent_details_id = resultObj['parent_details_id'];
     await this.props.parentSaved({submit_id:parent_id,submit_details_id:parent_details_id,parent_id:parent_id,parent_details_id:parent_details_id},false,'','','');
     this.props.autoGenerateChildform(this.props.id,this.props.childwebform,parent_id);
   }

   render() {
     let { webform_id, todo_id, refid, simulate, stepid,child_form_id,parent_id,simulatechildform,loadContent,t} = this.state;
     const popupData = (
       <reactbootstrap.Modal
         show={this.state.show}
         onHide={this.handleHide}
         aria-labelledby="example-custom-modal-styling-title"
         dialogClassName = 'modal-90w_childform-simulate'
         size='xl'
         dialogClassName = 'modal-90w_childform-simulate'
       >
       <reactbootstrap.Modal.Header closeButton>
           <reactbootstrap.Modal.Title id="contained-modal-title-vcenter" />
           {this.state.showparent==true &&<a onClick = {this.handleClose}  style ={{cursor:"pointer",textDecoration:"underline",color:'blue'}}>{t("Go to parent")}</a>}
           </reactbootstrap.Modal.Header>
           <reactbootstrap.Modal.Body col-md-12 pr-0>
             <WebFormBuild stepAction={window.COMING_FROM_CASE4_todos} {...this.props} todoid = {todo_id}  simulate = {simulate} refid = {refid} webform_id = {webform_id} stepid = {1} childform_simulate = {true} handleElementSaveSubmit={this.handleElementSaveSubmit.bind(this)} refid = {parseInt(refid) !== 0 ? refid : this.props.submit_id} child_form_id = {child_form_id} parent_id={parent_id} simulatechildform = {simulatechildform} loadContent={loadContent} callMount={true}
              parentSaved = {this.props.parentSaved} childform_newtab= {this.state.childform_newtab} childCaption = {this.props.childform_name}/>
           </reactbootstrap.Modal.Body>
        {/*<reactbootstrap.Modal.Footer>
            <reactbootstrap.Button onClick={() => this.handleClose()}>{t('Close')}</reactbootstrap.Button>
            </reactbootstrap.Modal.Footer>*/}
    </reactbootstrap.Modal>
      );

     return (

       <div>
      { this.props.childautogenerate === false && (this.props.caption == "" || this.props.caption == null) &&
       <span onClick = {this.props.disable_field?'':this.showPopup} style ={this.props.disable_field?{cursor:'none',textDecoration:"underline",color:'grey'}:{cursor:"pointer",textDecoration:"underline",color:'blue'}} disabled = {this.props.disable_field}> {this.props.childform_name} </span>}
       {this.props.childautogenerate === false && (this.props.caption)&&
       <reactbootstrap.Button onClick={() =>this.showPopup()} disabled = {this.props.disable_field}>{this.props.caption}</reactbootstrap.Button>}
      {popupData}
      { this.props.childautogenerate === true &&
      <a onClick = {this.generateForm} style ={this.props.disable_field?{cursor:'none',textDecoration:"underline",color:'blue'}:{cursor:"pointer",textDecoration:"underline",color:'blue'}}> {t("Autogeneration")}</a>}
       </div>

     );
   }
 }
 export default translate(ChildformSimulate);
