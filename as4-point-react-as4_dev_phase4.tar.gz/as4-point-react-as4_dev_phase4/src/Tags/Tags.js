import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import Pagination from 'react-bootstrap/Pagination'
import {translate} from '../language';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';

class Tags extends Component {
  constructor(props) {
    super(props)
    this.state = {
      getTagDetails: window.SHOW_TAG,
      tagUpdateUrl: window.UPDATE_TAG,
      name: '',
      description: '',
      available_in_masterdata: true,
      active_tag: true,
      submitted: false,
      loading: false,
      name_error: '',
      component: '',
      doc_data: [],
      folder_data: [],
      manual_data: [],
      alert: '',
      malert: '',
      show: '',
      falert: '',
      currentPage: 1,
      todosPerPage: 4,
      tabId: '',
      fcurrentPage: 1,
      mcurrentPage: 1,
      t:props.t,
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.validate = this.validate.bind(this);
  }


  async componentDidMount() {
    if (this.props.id) {
      const id = this.props.id;
      const url = this.state.getTagDetails + this.props.id;
      datasave.service(url, 'GET', '')
        .then(response => {
          this.setState({
            name: response[0]['name'],
            clonename: response[0]['name'],
            description: response[0]['description'],
            clonedescription:response[0]['description'],
            active_tag: response[0]['status'],
            available_in_masterdata: response[0]['available_in_masterdata'],
          })
        });
    }
  }
    componentDidUpdate(prevProps,prevState) {
      let tid  = this.props.id;
      // alert(tid);
      if(tid !== undefined && prevProps.id !== this.props.id){
        const id = this.props.id;
        const url = this.state.getTagDetails + this.props.id;
        datasave.service(url, 'GET', '')
          .then(response => {
            if(response[0]['description'] !== null){
            this.setState({
              name: response[0]['name'],
              clonename: response[0]['name'],
              description: response[0]['description'],
              clonedescription:response[0]['description'],
              active_tag: response[0]['status'],
              available_in_masterdata: response[0]['available_in_masterdata'],
              error:'',
              name_error:'',
            })
          }
          else{
            this.setState({
              description:'',
              clonedescription:'',
              name: response[0]['name'],
              clonename: response[0]['name'],
              error:'',
              name_error:'',
            });
          }
        });
      }
      if(tid===undefined && prevProps.id !== this.props.id){

        this.setState({
          name:'',
          description:'',
          error:'',
          name_error:'',
        });
      }
    }
  handleChange(event) {
    const { name,description, value } = event.target;
    this.setState({
      [name]: value,
      [description]:value,
      name_error: '',
      error: '',
    });
  }
  handleCancel(e) {
    this.props.updateComponent(1);
  }
  handleSubmit(event) {
    const {t} = this.state;
    event.preventDefault();
    this.setState({ submitted: true });
    const details = {
      id:this.props.id,
      name:  this.state.name.replace(/\s+/g,' ').trim(),
      description: this.state.description,
      available_in_masterdata: this.state.available_in_masterdata,
      status: this.state.active_tag,
      clone:this.state.clonename,
      namechange:this.state.name !== this.state.clonename

    }
    if (this.validate()) {
      if (this.props.id) {
        const {name,clonename,clonedescription,description}= this.state
        {clonename === name&&description ===clonedescription && this.props.updateComponent(1)}
        datasave.service(window.CHECK_TAGS, 'post', details).then(
          response => {

         if(response==1){
          this.setState({
            name_error: t('Tag name had already been taken!')
          })
         }else{
          const id = this.props.id;
          const url = window.GET_MASTER_DATA_TAGS + id;
          datasave.service(url, 'GET', id).then(
            response => {
                if(response.length>0){
              this.setState({ doc_data: response, id: id, show: true, alert: '' })
                }else{

                  const tagId = this.props.id;
                  const url = this.state.tagUpdateUrl + tagId;
                  datasave.service(url, 'PUT', details)
                    .then(response => {
                      if (response.name) {
                        this.setState({
                          name_error: response.name
                        })
                      } else {
                        if(response!==1){
                          this.props.created(this.state.name)
                        this.props.updateComponent(1);}else{
                          this.setState({
                            name_error: t('Tag name had already been taken!')
                          })
                        }
                      }
                    })
                }
              if (this.state.doc_data.length == 0) {
                this.setState({ alert: 'true' })
              }
            }
          )
       /* const furl = window.FETCH_TAGS_FOLDER + id;
          datasave.service(furl, 'GET', id).then(
            response => {
              this.setState({ folder_data: response, falert: '' })
              if (this.state.folder_data.length == 0) {
                this.setState({ falert: 'true' })
              }
            }
          ) */
        /* const murl = window.FETCH_TAGS_MANUAL + id;
          datasave.service(murl, 'GET', id).then(
            response => {
              this.setState({ manual_data: response, malert: '' })
              if (this.state.manual_data.length == 0) {
                this.setState({ malert: 'true' })
              }
            }namechange:this.state.name === this.state.clonename
          ) */
         }
          })
      }
      else {
        datasave.service(window.INSERT_TAGS, 'POST', details)
          .then(response => {
            if (response.name) {
              this.setState({
                name_error: response.name
              })
            }
            else {
              if(response!==1){

                this.props.created(this.state.name)
              this.props.updateComponent(1);
            }else{
              this.setState({
                name_error: t('Tag name had already been taken!')
              })
            }
            }
          })
      }
    }
  }
  validate() {
    var name_valid = this.state.name.replace(/\s+/g,' ').trim();
    let formIsValid = true;
    const {t} = this.state;
    if (name_valid =='') {
      formIsValid = false;
      this.setState(
        {
          error: t('Tag name field required!')
        }
      )
    }
    return formIsValid;
  }
  handlehide = () => {
    this.setState(
      { show: false }
    )
  }

  handleCancelp() {
    this.setState(
      { show: false }
    )
  }

  handleExport() {
    var url = window.EXPORT_TAGS + this.props.id;
    var details = {
      name:this.state.name,
      clone:this.state.clonename,
      olddescription:this.state.clonedescription,
      description:this.state.description
    }

    datasave.service(url,'PUT',details)
    .then(response =>{
      window.open(response)
    })
    }
  handleOk() {

    this.setState(
      { show: false }
    )
    const {t} = this.state;
    this.setState({ submitted: true });
    const details = {
      name: this.state.name.replace(/\s+/g,' ').trim(),
      description: this.state.description,
      available_in_masterdata: this.state.available_in_masterdata,
      status: this.state.active_tag,
      clone :this.state.clonename,
      namechange:this.state.name !== this.state.clonename
    }

    if (this.props.id) {
      const tagId = this.props.id;
      const url = this.state.tagUpdateUrl + tagId;
      datasave.service(url, 'PUT', details)
        .then(response => {
          if (response.name) {
            this.setState({
              name_error: response.name
            })
          } else {
            if(response!==1){
              this.props.created(this.state.name)
            this.props.updateComponent(1);}else{
              this.setState({
                name_error: t('Tag name had already been taken!')
              })
            }
          }
        })
        .catch(error => {
          this.setState({
            errors: error.response.data.errors
          })
        })
    }
    else {
      datasave.service(window.INSERT_TAGS, 'POST', details)
        .then(response => {
          if (response.name) {
            this.setState({
              name_error: response.name
            })
          }
          else {


            this.props.updateComponent(1);

          }
        })
    }
  }
  handlePageClick(event) {
    this.setState({
      currentPage: Number(event.target.id)
    });
  }
  handleFolderPageClick(event) {
    this.setState({
      fcurrentPage: Number(event.target.id)
    });
  }
  handleManualPageClick(event) {
    this.setState({
      mcurrentPage: Number(event.target.id)
    });
  }
  componentWillReceiveProps(){
    if(this.props.id === undefined){
    this.setState({name_error:'',error:''})}
  }
  render() {
    // const { name, description, available_in_masterdata, active_tag, submitted, loading, name_error } = this.state;
    const { error,t, id, doc_data, alert, todosPerPage, currentPage, folder_data, manual_data, mcurrentPage, clonename, fcurrentPage, malert, falert, name, description, available_in_masterdata, active_tag, submitted, loading, name_error,clonedescription } = this.state;
    const indexOfLastTodo = currentPage * todosPerPage;
    const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
  /*  //folder
    const indexOfLastFolder = fcurrentPage * todosPerPage;
    const indexOfFirstFolder = indexOfLastFolder - todosPerPage;
    //manual
    const indexOfLastManual = mcurrentPage * todosPerPage;
    const indexOfFirstManual = indexOfLastManual - todosPerPage;*/

    const currentTodos = doc_data.slice(indexOfFirstTodo, indexOfLastTodo);
    const pagerender = currentTodos.map(doc => {
      return <tr><td>{doc.code}</td>
        <td>{doc.name}</td>
        <td>{doc.folder}</td>
        <td>{doc.manual}</td>
      </tr>
    });
   /* const folderdata = folder_data.slice(indexOfFirstFolder, indexOfLastFolder);
    const folders = folderdata.map(folder => {
      return <tr><td>{folder.code}</td>
        <td>{folder.name}</td>
      </tr>
    });
    const manualsdata = manual_data.slice(indexOfFirstManual, indexOfLastManual);
    const manuals = manualsdata.map(manual => {
      return <tr><td>{manual.code}</td>
        <td>{manual.name}</td>
      </tr>
    });*/

    const pageNumbers = [];
    if(doc_data.length > 5){
    for (let i = 1; i <= Math.ceil(doc_data.length / todosPerPage); i++) {
      pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
        {i}
      </Pagination.Item>);
    }
  }
     /*const folderPageNumbers = [];
    for (let i = 1; i <= Math.ceil(folder_data.length / todosPerPage); i++) {
      folderPageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handleFolderPageClick(e, this)} key={i} active={i === fcurrentPage}>
        {i}
      </Pagination.Item>);
    }
    const manualPageNumbers = [];
    for (let i = 1; i <= Math.ceil(manual_data.length / todosPerPage); i++) {
      manualPageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handleManualPageClick(e, this)} key={i} active={i === mcurrentPage}>
        {i}
      </Pagination.Item>);
    }*/
    const popup = (
      <reactbootstrap.Modal
        size="lg"
        show={this.state.show}
        onHide={this.handlehide}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title">
        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
          </reactbootstrap.Modal.Title>
          <reactbootstrap.Modal.Body>
            {/* <reactbootstrap.Tabs id="controlled-tab-example"> */}
              {/* <reactbootstrap.Tab eventKey={1} title="Documents"> */}
                <reactbootstrap.Table responsive striped bordered hover size="sm">
                  <thead>
                    <tr>
                      <td>{t('Document code')}</td>
                      <td>{t('Document name')}</td>
                      <td>{t('Folder name')}</td>
                      <td>{t('Manual name')}</td>
                    </tr>
                  </thead>
                  <tbody>
                    {pagerender}
                  </tbody>
                  {alert && <span className=" alert text-center">{t('No  Record found !')}</span>}
                </reactbootstrap.Table>
                <Pagination  style={{width: '530px', overflow: 'auto'}} size="sm">{pageNumbers}</Pagination>
              {/* </reactbootstrap.Tab> */}
              {/* <reactbootstrap.Tab eventKey={2} title="Folder">
                <reactbootstrap.Table striped bordered hover variant="dark">
                  <thead>
                    <tr>
                      <td>{t('Code')}</td>
                      <td>{t('Folder name')}</td>
                    </tr>
                  </thead>
                  <tbody>
                    {folders}

                  </tbody>
                  {falert && <span className=" alert text-center">{t('No  Record found !')}</span>}
                </reactbootstrap.Table>
                <Pagination size="sm">{folderPageNumbers}</Pagination>
              </reactbootstrap.Tab> */}
              {/* <reactbootstrap.Tab eventKey={3} title="Manuals">
                <reactbootstrap.Table striped bordered hover variant="dark">
                  <thead>
                    <tr>
                      <td>{t('Code')}</td>
                      <td>{t('Manual name')}</td>
                    </tr>
                  </thead>
                  <tbody>
                    {manuals}
                  </tbody>
                  {malert && <span className=" alert text-center">{t('No  Record found !')}</span>}
                </reactbootstrap.Table>
                <Pagination size="sm">{manualPageNumbers}</Pagination>
              </reactbootstrap.Tab> */}

            {/* </reactbootstrap.Tabs> */}
            <reactbootstrap.Table responsive striped bordered hover size="sm">
            <thead>
            {clonename!==name &&
            <tr>
              <th className ="taghead" style ={{width: '30%'}}>{t('Previous tag Name')}</th>
              <td>{clonename}</td>
              </tr>
            }
            {clonename!==name &&
              <tr>
              <th className ="taghead">{t('Updated tag name')}</th>
              <td>{name}</td>
              </tr>
            }
            {clonedescription !== description &&
              <tr>
              <th className ="taghead" style ={{width: '30%'}}>{t('Previous description')}</th>
              <td>{clonedescription}</td>
              </tr>
            }
            {clonedescription !== description &&
              <tr>
              <th className ="taghead" style ={{width: '30%'}}>{t('Updated description')}</th>
              <td>{description}</td>
            </tr>
          }
          </thead>
          <tbody>
          <tr>
          </tr>
          </tbody>
          </reactbootstrap.Table>
          </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={() => this.handleCancelp()}>{t('Cancel')}</reactbootstrap.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
        <reactbootstrap.Button onClick={() => this.handleOk()}>{t('Edit')}</reactbootstrap.Button>
        <reactbootstrap.Button onClick={() => this.handleExport()}>{t('Export')}</reactbootstrap.Button>

        </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
    );

    return (
      <Can
        perform = "E_tags"
        yes = {() => (
          <div className='container' >
            <div className='row justify-content-center ' >
              <div className='col-md-12 pl-0' >
                <div className='card' >
                  <div className='card-header' > {t('Create tag')} </div>
                  <div className='card-body' >
                    <Container className="p-1">
                      <Form onSubmit={this.handleSubmit}>
                        <FormGroup>
                        <div className=" input-overall-sec ">
                          <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
                            <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup  style={{ background: 'none', border: '0px', color: '#EC661C',padding: '8px' }} id="basic-addon1">{t('Name')} :<span style={{ color: "red" }}>*</span></InputGroup>
                              </InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd">
                              <FormControl
                                name="name"
                                autoFocus
                                placeholder={t("Tag")}
                                aria-label="Tags"
                                aria-describedby="basic-addon1"
                                value={name}
                                onChange={this.handleChange}
                                className="input_sw "
                              />

                            <div style={{ color: 'red' }} className="error-block mt-2 ">{name_error}</div>
                            <div style={{ color: 'red' }} className="error-block mt-2 ">{error}</div>
                              </div>
                              </InputGroup>

                          </div>
                          </div>
                        </FormGroup>
                        <FormGroup>

                        <div className=" input-overall-sec ">
                        <reactbootstrap.InputGroup className="">
                        <div className="col-md-4">
                          <InputGroup.Prepend>
                            <InputGroup  style={{ background: 'none', border: '0px', color: '#EC661C',padding: '8px' }} id="basic-addon1">{t('Description')} :</InputGroup>
                          </InputGroup.Prepend>
                          </div>
                          <div class="col-md-8 input-padd">
                          <FormControl
                            style={{ height: '200px' }}
                            as="textarea" rows="3"
                            name="description"
                            placeholder={this.props.placeholder}
                            value={description}
                            id="description"
                            onChange={this.handleChange}
                            className="input_sw"
                          />
                          </div>
                          </reactbootstrap.InputGroup>
                          </div>

                        </FormGroup>
                        <FormGroup>
                          <div style={{float: 'right'}} className="organisation_list mt-3">
                          <a   onClick={this.handleCancel} >{t('Cancel')}</a>
                          &nbsp;&nbsp;&nbsp;
                            <Button style={{fontSize: '14px'}} type="submit" className="btn btn-primary" disabled={loading}>{t('Save')}</Button>
                          </div>
                          {popup}
                        </FormGroup>
                      </Form>
                    </Container>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        no = {() =>
          <AccessDeniedPage />
        }
      />
    );
  }
}
export default translate(Tags)
