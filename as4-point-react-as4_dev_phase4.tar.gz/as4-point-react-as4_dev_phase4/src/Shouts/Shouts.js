
import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { filterArray } from '../_helpers/filter-array';
import { translate } from '../language';
//import CKEditor from '@ckeditor/ckeditor5-react';
//import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
//import DecoupledEditor from '@ckeditor/ckeditor5-build-decoupled-document';
//import Highlight from '@ckeditor/ckeditor5-highlight/src/highlight';
import { EditorState, convertToRaw, ContentState,convertFromRaw } from 'draft-js';
import { Editor } from 'react-draft-wysiwyg';
import draftToHtml from 'draftjs-to-html';
import htmlToDraft from 'html-to-draftjs';
import '../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';


import './Shouts.css';
class Shouts extends Component {
  constructor(props) {
    super(props)
    this.state = {
      shout_store_url: window.SHOUTS,
      name: '',
      name_error: '',
      status: 1,
      tasks: [],
      clone: '',
      items: [],
      types: [],
      credentials: {},
      details: {},
      error: '',
      description: '',
      description_error: '',
      namerequire_error: '',
      checked: true,
      t: props.t,
      editorState: EditorState.createEmpty(),
    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handlechange = this.handlechange.bind(this);
    this.handleCheck = this.handleCheck.bind(this);

        const contentBlock = htmlToDraft(this.state.description);
        if (contentBlock) {
          const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks);
          const editorState = EditorState.createWithContent(contentState);
          this.setState({
            editorState,
          });
        }
  }
  onEditorStateChange: Function = (editorState) => {
   this.setState({
     editorState,
   });
 };
  componentDidMount() {
    const shout_id = this.props.id;
    if (this.props.id) {
      const geturl = window.SHOUTS + '/' + shout_id;
      datasave.service(geturl, 'GET').then(
        response => {
          const contentBlock = htmlToDraft(response[0].description);
          if (contentBlock) {
            const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks);
            const editorState = EditorState.createWithContent(contentState);
            this.setState({
              editorState,
            });
          }
          this.setState({
            name: response[0]['name'],
            clone: response[0]['name'],
            status: response[0]['status'],
          })
        }
      )
    }
  }
  componentDidUpdate(prevProps, prevState) {
    let shout_id = this.props.id;
    if (shout_id !== '' && prevProps.id !== this.props.id) {
      if (shout_id !== undefined) {
        this.setState({
          description_error: '',
          name_error: '',
        })
        this.getShoutDetails(shout_id);
      }
      else {
        this.setState({
          name: '',
          name_error: '',
          description: '',
          description_error: '',
        })
      }
    }
  }
  getShoutDetails(shout_id) {
    const geturl = window.SHOUTS + '/' + shout_id;
    if (shout_id !== undefined) {
      datasave.service(geturl, 'GET').then(
        response => {
          const contentBlock = htmlToDraft(response[0].description);
          if (contentBlock) {
            const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks);
            const editorState = EditorState.createWithContent(contentState);
            this.setState({
              editorState,
            });
          }
          this.setState({
            name: response[0]['name'],
            clone: response[0]['name'],
            status: response[0]['status'],
          })
        }
      )
    }
  }
  handleCancel(event) {
    this.props.updateComponent(1);
  }

  handlechange(event) {
    const { name, value } = event.target
    this.setState({
      [name]: value,
    })
  }


  handleSubmit(event) {
    event.preventDefault()
    const { history } = this.props
    const data = {
      description: draftToHtml(convertToRaw(this.state.editorState.getCurrentContent())),
      name: this.state.name.replace(/\s+/g, ' ').trim(),
      status: this.state.status,
      clone: this.state.clone,
    }

    if (this.props.id) {
        const details = {
          name: this.state.name.replace(/\s+/g, ' ').trim(),
          id: this.props.id,
          status: this.state.status,
          description: draftToHtml(convertToRaw(this.state.editorState.getCurrentContent())),
          clone: this.state.clone.replace(/\s+/g, ' ').trim(),
        }

        const editurl = window.SHOUTS + '/' + this.props.id;
        datasave.service(editurl, 'PUT', details)
                .then(response => {
                    if (response.description || response.name) {
                        this.setState({
                            description_error: response.description,
                            name_error: response.name,
                        })
                    }
                    else {
                      if (response == "success") {
                        this.props.updateComponent(1);
                      }
                    }
                })
                .catch(error => {
                    this.setState({
                      //  errors: error.response.data.errors
                    })
                })
      }
     else {
          const url = window.SHOUTS;
          datasave.service(window.SHOUTS, 'POST', data)
                .then(response => {
                    if (response.description || response.name) {
                        this.setState({
                            description_error: response.description,
                            name_error: response.name,
                        })
                    }
                    else {
                        this.props.updateComponent(1);
                    }
                })
                .catch(error => {
                    this.setState({
                    })
                })
      }
    }
  componentWillReceiveProps() {
    if (this.props.id !== undefined) {
      this.setState({
        name_error: '',
        description_error: '',
      })
    }
  }
  handleCheck(e) {
    this.setState({ checked: !this.state.checked });
    var msg;
    if (this.state.checked) {
      msg = "checked";
      this.state.status = 0
    } else {
      this.state.status = 1
    }
  }
  render() {
  //  const { name, t, name_error, require_error, shouts, status, shout_error, namerequire_error } = this.state
    const { description_error, loading, t, name_error, status , description , name, editorState } = this.state
    return (
      <div className='container '>
        <div className='row ' >
          <div className='col-md-12' >
            <div className='card'>
              {this.props.id && <div className='card-header' >{t('Update shout')} </div>}
              {this.props.id === undefined && <div className='card-header' > {t('Create shout')} </div>}

              <div className='card-body mb-3' >
                <reactbootstrap.Container className="">
                  <reactbootstrap.Form onSubmit={this.handleSubmit}>
                    <reactbootstrap.FormGroup>
                      <div className=" row input-overall-sec ">
                        <reactbootstrap.InputGroup className="">
                          <div className="col-md-4">
                            <reactbootstrap.InputGroup.Prepend>
                              <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Shout name')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                            </reactbootstrap.InputGroup.Prepend>
                          </div>
                          <div class="col-md-8 input-padd">
                            <reactbootstrap.FormControl
                              name='name'
                              autoFocus
                              placeholder="Shout name"
                              aria-label="Functionname"
                              aria-describedby="basic-addon1"
                              value={name}
                              onChange={this.handlechange}
                              className="input_sw"
                            />
                          </div>
                        </reactbootstrap.InputGroup>
                        <div style={{ color: 'red' }} className="error-block">{name_error}</div>
                      </div>
                    </reactbootstrap.FormGroup>
                    <div className=" row input-overall-sec ">
                      <div className="col-md-4">
                        <reactbootstrap.FormLabel style={{ padding: '8px', color: '#EC661C' }}>{t('Description')}:<span style={{ color: "red" }}>*</span></reactbootstrap.FormLabel>
                      </div>
                      <div class="col-md-8 input-padd shouts">
                      <Editor
                        editorState={editorState}
                        toolbarClassName="toolbarClassName"
                        wrapperClassName="wrapperClassName"
                        editorClassName="editorClassName"
                        onEditorStateChange={this.onEditorStateChange.bind(this)}
                        toolbar={{
                          options: ['inline', 'blockType', 'fontFamily','fontSize', 'colorPicker', 'list', 'textAlign', 'history', 'link','remove'],
                        }}
                      />

                    {/*    <CKEditor
                          type="textarea"
                          // style = {{resize:"both"}}
                          editor={DecoupledEditor}
                          data={
                            this.state.description
                          }

                          config={{
                          //  removePlugins: ['Image', 'ImageCaption', 'ImageStyle', 'ImageToolbar', 'ImageUpload', 'MediaEmbed'],
                            //resize:['100%', 450, true ]
                        //    toolbar: [ 'highlight', ... ]

                          }}
                          onInit={ editor => {

                              // Insert the toolbar before the editable area.
                              editor.ui.getEditableElement().parentElement.insertBefore(
                                editor.ui.view.toolbar.element,
                                editor.ui.getEditableElement()
                              );
                          } }
                          onChange={(event, editor) => {
                            const data = editor.getData();
                            var test = editor.config.get('resize');
                            var shouts = 'shouts';
                            var temp = this.state.description;
                            this.setState({ description: data })
                          }}

                        />
*/}

                        <div style={{ color: 'red' }} className="error-block">{description_error}</div>
                      </div>
                    </div>
                    <reactbootstrap.FormGroup className="p-3">
                      <reactbootstrap.FormCheck style={{ padding: '8px', color: '#EC661C' }}
                        onChange={e => this.setState({ status: !status })}
                        name='active'
                        checked={status}
                        label={t('Active shout')}
                        defaultChecked={true}
                      />
                    </reactbootstrap.FormGroup>
                    {/* <div className="mt-3">
                      <reactbootstrap.Button type="submit" color="primary">{t('Save')}</reactbootstrap.Button>&nbsp;&nbsp;&nbsp;
                    <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.handleCancel}>{t('Cancel')}</reactbootstrap.Button>
                    </div> */}
                    <FormGroup>
                      <div style={{float: 'right'}} className="organisation_list mt-3">
                      <a   onClick={this.handleCancel} >{t('Cancel')}</a>
                      &nbsp;&nbsp;&nbsp;
                        <Button style={{fontSize: '14px'}} type="submit" className="btn btn-primary"disabled={loading} >{t('Save')}</Button>
                      </div>
                    </FormGroup>

                  </reactbootstrap.Form>
                </reactbootstrap.Container>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default translate(Shouts);
