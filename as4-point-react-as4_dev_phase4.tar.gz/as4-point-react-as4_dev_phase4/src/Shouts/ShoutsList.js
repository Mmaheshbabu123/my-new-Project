import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { translate } from '../language';

class ShoutsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            shouts: [],
            t: props.t,

        }
        //this.changeStatus = this.changeStatus.bind(this)
        this.handledelete = this.handledelete.bind(this)

    }

    componentDidMount() {
        var url = window.SHOUTS;
        datasave.service(url, 'GET', '')
            .then(response => {
                this.setState({
                    shouts: response,
                })
            });
    }
    componentDidUpdate(prevProps) {
        if (this.props !== prevProps) {
            var url = window.SHOUTS;
            datasave.service(url, 'GET', '')
                .then(response => {
                    this.setState({
                        shouts: response,
                    })
                });
        }
    }
    /* changeStatus(id, status, e) {
         var url = window.SHOUTS_CHANGE_STATUS + '/' + id + '/' + status;
         const details = {
             status: status ? 0 : 1
         }
         datasave.service(url, 'PUT', details)
             .then(response => {
                 if (response) {
                 }
             })
             .catch(error => {
                 this.setState({
                     errors: error.response.data.errors
                 })
             })
     }*/
    handledelete(id, e) {
        this.setState(
            { show: false }
        )
        var url = window.DROP_SHOUT + '/' + id;
        datasave.service(url, 'PUT', id)
            .then(response => {
                this.setState(
                     this.props.updateComponent(1)
                    //  { persons: response }
                )
            })
    }
    render() {
        const { shouts, t } = this.state
        return (
            <div className='container py-4' >
                <div className='row justify-content-center' >
                    <div className='col-md-12' >
                        <div className='card' >
                            <form method='POST'>
                                <reactbootstrap.Table responsive>
                                    <thead>
                                        <tr>
                                            <th>{t('Shout')}</th>
                                            <th>{t('Actions')}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <div style={{ textAlign: 'center' }} className="error-block">{this.state.error}
                                        </div>
                                        {shouts.map(
                                            function (shout) {
                                                return (
                                                    <tr>
                                                        <td>{shout.name}</td>
                                                        <td>
                                                            <Link
                                                                to={`/shouts/${shout.id}`}
                                                                key={shout.id}
                                                            >
                                                                <i title="Edit" class="overall-sprite overall-sprite-myeditc"></i>
                                                            </Link>
                                                            <br></br>
                                                            <a href='#'
                                                                onClick={this.handledelete.bind(this, shout.id)}
                                                            >
                                                                <i title="Delete" class="overall-sprite overall-sprite-mtdeletec"></i>
                                                            </a>

                                                        </td>
                                                    </tr>
                                                )
                                            }, this)
                                        }
                                    </tbody>
                                </reactbootstrap.Table>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        )
    }
}
export default translate(ShoutsList);