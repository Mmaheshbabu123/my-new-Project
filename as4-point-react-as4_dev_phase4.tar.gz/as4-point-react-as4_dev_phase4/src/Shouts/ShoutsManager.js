import React, { Component } from 'react';
import Pagination from 'react-bootstrap/Pagination'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import SearchInput, { createFilter } from 'react-search-input';
import Shouts from '../Shouts/Shouts';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import managedelete from '../MasterDataManagement/manage-delete.png';
import manageedit from '../MasterDataManagement/manage-edit.png';
import archived from './archived.png';
import { translate } from '../language';
import contents from '../settings/document.json';
import { OCAlert } from '@opuscapita/react-alerts';
import './ShoutsManager.css';
import { ConsoleView } from 'react-device-detect';
import CheckBox from '../CheckBox';
const KEYS_TO_FILTERS = ['name', 'id']

class ShoutsManager extends Component {
    constructor(props) {
        super(props)
        this.state = {
            shoutlist: [],
            showshoutpop: '',
            searchTerm: '',
            clone: [],
            popid: '',
            showpopup: '',
            alert: '',
            malert: '',
            falert: '',
            currentPage: 1,
            todosPerPage: 5,
            tabId: '',
            fcurrentPage: 1,
            mcurrentPage: 1,
            scurrentPage: 1,
            shoutePerPage: 5,
            didupdate: '',
            page: 5,
            active: 1,
            id: '',
            count: 0,
            items: [],
            filterFullList: [],
            searchTerm: '',
            active: false,
            mouse: false,
            created_shout: '',
            t: props.t,
            contents: contents,
            showDayAudit : true,
        }
        this.searchData = this.searchData.bind(this);
        this.handledelete = this.handledelete.bind(this);
        this.changeComponent = this.changeComponent.bind(this);
        this.handleShoutTrack = this.handleShoutTrack.bind(this);
        this.handleDateChange = this.handleDateChange.bind(this);
        this.handleShow = this.handleShow.bind(this);

    }
    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.shoutlist;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;
    }
    componentDidMount() {
        const details = {
            id: 1,
          };
          datasave.service(window.GETSETTINGS, 'POST', details).then(result => {
            console.log(result);
            if (result != '') {
              var temp = this.state.contents;
              result.map(key => {
                console.log(key);
                if (key['value'] === "0" || key['value'] === "1") {
                  temp[key['entity_id']]['value'] = parseInt(key['value']);
                  temp[key['entity_id']]['display'] = key['display'];

                } else {
                  temp[key['entity_id']]['value'] = key['value'];
                  temp[key['entity_id']]['display'] = key['display'];

                }
              })
              this.setState({
                contents: temp,
                status: true
              })
            } else {
              this.setState({
                status: true
              })
            }
          });
        const url = window.SHOUTS;
        datasave.service(url, 'GET', '')
            .then(response => {
                const pageData = this.getPageData(1, response);
                const count = this.getCountPage(response);
                this.setState({
                    shoutlist: response,
                    clone: response,
                    count: count,
                    items: pageData,
                })
            })
    }
    componentDidUpdate(prevProps, prevState) {
        if (prevState.component !== this.state.component || prevState.didupdate !== this.state.didupdate) {
            const url = window.SHOUTS;
            datasave.service(url, 'GET')
                .then(response => {
                    const pageData = this.getPageData(this.state.active, response);
                    const count = this.getCountPage(response);
                    this.setState({
                        shoutlist: response,
                        clone: response,
                        items: pageData,
                        count: count,
                        didupdate: 'true'
                    })
                })
        }
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }
    componentWillMount() {
        this.setState({ items: this.state.shoutlist, active: 1 })
    }
    searchData(e) {
        var list = [...this.state.shoutlist];
        list = list.filter(function (item) {
            if (item.name !== null) {
                return item.name.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
        });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    handlehide = () => {
        this.setState(
            { show: false, showshoutpop: false }
        )
    }
    handleCancel() {
        this.setState(
            { show: false }
        )
    }
    handledelete(id) {
        this.setState({ currentPage: 1, mcurrentPage: 1, fcurrentPage: 1, popid: id, show: true, showpopup: 'true', didupdate: 'true' })
    }
    updateComponent(e) {
        if (e) {
            this.setState({
                component: 'false',
                saveComponent: 1,
            })
        }
        this.saveSettingAsPerType();
    }
    update(e) {
        if (e !== this.state.tabId) {
            this.setState({
                tabId: e,
            });
        }
    }
    changeComponent(e, id) {
        this.setState({
            component: 'true',
            formId: (id !== '') ? id : '',
        });
    }
    handlepopok() {
        this.setState({ didupdate: '1' })
        const { popid } = this.state;
        const url = window.DROP_SHOUT + '/' + popid;
        datasave.service(url, 'put').then(
            response => {
                this.setState({ show: false, showpopup: '' })
                const geturl = window.SHOUTS;
                datasave.service(geturl, 'GET')
                    .then(response => {
                        const pageData = this.getPageData(this.state.active, response);
                        const count = this.getCountPage(response);
                        this.setState({
                            shoutlist: response,
                            clone: response,
                            items: pageData,
                            count: count,
                            didupdate: 'true'
                        })
                    })
            }
        )
    }
    changePage(e, id = 1) {
        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });
    }
    handleShoutTrack(shout) {
        this.setState({ created_shout: shout });
    }
    handleDateChange(e) {
        const {id,value} = e.target;
        let contents = this.state.contents;
        for (var key in contents) {
          let item = this.state.contents[key];
          if (item.sqeid === id) {
              console.log(item,item.value);
            item.value = value;
          }
        }
        this.setState({
          contents: contents,
        });
        // this.sendDataToSave(this.state.contents, 1);

        this.saveSettingAsPerType();
      }
    saveSettingAsPerType() {
        const {t} = this.state;
          if (this.state.contents != '') {
              const details = {
                  data: this.state.contents,
                  id: parseInt(1)
              }
              datasave.service(window.DOCUMENT, 'POST', details)
                  .then(result => {
                    console.log("Next audit data saved");
                    // OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION});
                    // window.location.reload();
                    // alert("Save Successfull");
                  });
          }

      }

      handleShow(e){
            const { id, value } = e.target;

            // let result = ( == true)? "1": "0";
            // console.log(result);
            let contents = this.state.contents;
            for (var key in contents) {
              let item = this.state.contents[key];
              if (item.sqeid === id) {
                let checked = (item.value == "1" ? "0" : "1" );
                  console.log(checked);
                item.value = checked;
              }
            }
            this.setState({
              contents: contents,
            });

            console.log(this.state.contents, this.state.showDayAudit);
            this.saveSettingAsPerType();
      }
    render() {
        console.log(contents);
        const { t } = this.state;
        const node = contents["38"];
        const node1 = this.state.contents["46"];
        console.log(node1);
        const { showpopup, alert, currentPage, mcurrentPage, fcurrentPage, malert, falert, shoutlist, scurrentPage, shoutePerPage, spacepop, clone } = this.state;
        const popup = (
            <reactbootstrap.Modal
                size="lg"
                show={this.state.show}
                onHide={this.handlehide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title">
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                    </reactbootstrap.Modal.Title>
                    <reactbootstrap.Modal.Body>
                        <reactbootstrap.Table striped bordered hover variant="dark">
                            <tbody>
                                <div>{t('Please confirm')}</div>
                            </tbody>
                        </reactbootstrap.Table>
                    </reactbootstrap.Modal.Body>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button onClick={() => this.handleCancel()}>{t('Cancel')}</reactbootstrap.Button>
                    &nbsp;&nbsp; &nbsp;&nbsp;
                <reactbootstrap.Button onClick={() => this.handlepopok()}>{t('Delete')}</reactbootstrap.Button>
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );
        const filtered = this.state.items;
        const shouts = filtered.map(shout => {
            return <tr>
                <td>
                    <div>
                        {shout.status === 0 &&
                            <div>
                                <img title="Achived" src={archived} style={{ width: '20px', height: '20px' }}></img>
                            </div>
                        }
                        <span>{shout.name}</span>
                    </div>
                </td>
                <td style={{}}>
                    <div style={{ display: 'flex', justifyContent: 'center' }}>
                        <Can
                            perform="E_shout"
                            yes={() => (
                                <div className="p-2" variant="link">
                                  <i title="Edit "style={{cursor: "pointer"}} onClick={(e) => this.changeComponent(e, shout.id)} class="overall-sprite overall-sprite-myeditc"></i>
                                </div>
                            )}
                        />
                        {this.state.component !== 'true' &&
                            <Can
                                perform="D_shout"
                                yes={() => (
                                    <div className="p-2">

                                       <i title="Delete" href="#" style={{cursor: "pointer"}}  onClick={() => this.handledelete(shout.id)} class="overall-sprite overall-sprite-mtdeletec"></i>
                                    </div>
                                )}
                            />
                        }
                    </div>
                </td>
            </tr>
        })
        let active = this.state.active;
        let pages = [];
        if (this.state.count > 0)
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }
        return (
          <div className="  col-md-12 pr-1 pl-0">
            {/*  <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>*/}
              <div style={{ }} className='col-md-12' >
                    <Can
                        perform="R_shout,E_shout,D_shout"
                        yes={() => (
                            <div className='row'>
                                <div className=' col-md-12 mt-5 mb-5 p-0'>
                                    <div className='card pb-3'>
                                        <div className="row col-md-4 mt-3 document-tab5">
                                            <div className="col-md-5" style={{margin:'auto'}}>
                                            <span style={{color:'rgb(236, 102, 28)'}}>{t(node.title)}:</span>
                                            </div>
                                            <div className="col-md-7" style={{padding:'0px'}}>
                                            <input
                                                type="date"
                                                name={node.title}
                                                id={node.sqeid}
                                                defaultValue={node.value}
                                                onChange={this.handleDateChange}

                                            />
                                            </div>
                                            <div className="col-md-12 document-tab6">
                                            {node.title2}
                                            </div>
                                            <reactbootstrap.Form.Group as='showDayAudit' className="mb-0 show-audit">
                                                <CheckBox
                                                    tick={node1.value == 1 ? true : false}
                                                    style={{ paddingLeft: '0px' }}
                                                    id={46}
                                                    onCheck={this.handleShow}
                                                    name={t("Show audit day")}
                                                    classification="showDayAudit"
                                                    className="checkBoxWrapper"
                                                />
                                                </reactbootstrap.Form.Group>
                                        </div>

                                        {/*<reactbootstrap.Form.Group as='na' >
                                            <CheckBox
                                                tick={na}
                                                style={{ paddingLeft: '0px' }}
                                                onCheck={(e) => this.handleNACheckBox(e.target.checked == true ? 1 : 0)}
                                                name={t("NA")}
                                                classification="na"
                                            />*/}
                                        {/* <div className='card-body'></div> */}
                                        {showpopup && popup}

                                        <div className="row container mt-3">
                                            <reactbootstrap.Col lg={4}>
                                                <div className="text-center">
                                                    <div style={{ display: 'flex' }} className="mb-3">
                                                        <input type="text" className="search-input form-control" style={{ 'border-radius': "5px", 'border-color': "#EC661C" }} placeholder={t("What are you looking for ?")} autoFocus onChange={this.searchData} /><br />
                                                        {/* <reactbootstrap.Button onClick={(e) => this.changeComponent(e)} variant="link">{t('Create shout')}</reactbootstrap.Button> */}
                                                        <Can
                                                            perform="E_shout"
                                                            yes={() => (
                                                              <reactbootstrap.Button style={{ paddingTop: '0px' }} onClick={(e) => this.changeComponent(e)} variant="link"> <i title="Create shout" class="overall-sprite overall-sprite-shoutc"></i></reactbootstrap.Button>
                                                            )}
                                                        />
                                                    </div>
                                                    <Can
                                                        perform="R_shout,E_shout,D_shout"
                                                        yes={() => (
                                                        <reactbootstrap.Table esponsive bordered hover className="main-data-table">
                                                            {/* <div className="shout-table-response"> */}
                                                            {/* <div> */}
                                                                <thead>
                                                                    <tr>
                                                                        <th>{t('Name')}</th>
                                                                        <th>{t('Actions')}</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {shoutlist.length == 0 && <div> {t('No records found')}</div>}
                                                                    {shouts}
                                                                </tbody>
                                                            {/* </div> */}
                                                        </reactbootstrap.Table>
                                                    )}
                                                  />

                                                  { pages.length > 1 &&
                                                    <Can
                                                        perform="R_shout,E_shout,D_shout"
                                                        yes={() => (
                                                          <Pagination size="md">{pages}</Pagination>
                                                        )}
                                                    />
                                                  }
                                            </div>
                                            </reactbootstrap.Col>
                                            {this.state.component === 'true' && <div className="col-8"><Shouts updateComponent={this.updateComponent.bind(this)} id={this.state.formId} saved={this.handleShoutTrack} /></div>}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        no={() =>
                            <AccessDeniedPage />
                        }
                    />
                </div>
            </div>

        );
    }
}

export default translate(ShoutsManager);

{/* <i class="overall-sprite overall-sprite-shoutc"></i>
<i class="shout-sprite shout-sprite-SHOT_blue"></i> */}
