import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../language';
import { datasave } from '../_services/db_services';
import ImportFileDetails from './ImportFileDetails';
import Pagination from 'react-bootstrap/Pagination';
import { confirmAlert } from 'react-confirm-alert';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';

class ManageImportFiles extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t: props.t,
      action: '',
      import_files: [],
      popUpData: [],
      file: '',
      file_details: '',
      show: false,
      filePath: '',
      table_name: '',
      row_id: 0,
      fileId: 0,
      import_type: 0,
      page: 5,
      count: 0,
      active: 1,
      activePage: 1,
      Submitted: false,
      items: [],
      searchTerm: '',
      filterFullList: [],
      Valid: false,
      showComponent:true
    }
    this.searchData = this.searchData.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  async componentDidMount() {
    await this.fetchImportFiles();

  }
  async fetchImportFiles() {
    datasave.service(window.FETCH_IMPORT_FILES, 'GET')
      .then(async response => {
        const pageData = this.getPageData(this.state.active, response.result);
        const count = this.getCountPage(response.result);
        await this.setState({
          import_files: response.result,
          count: count,
          items: pageData,

        })
      });
  }
  updateManageImportFiles(data, action = '') {
    if (action === 'edit' || action === 'create') {
      this.setState({
        action: action === 'create' ? 'view' : 'edit',
        fileId: data.fileId,
        table_name: data.table_name,
        file: data.file,
        filePath: data.filePath,
        import_type: data.import_type,
        row_id: data.row_id,
        file_details: data.file_details,
        popUpData: data.popUpData,
        Submitted: data.Submitted,
        Valid: data.Valid
      })
      this.fetchImportFiles();
    }
    else if(action === 'close_component'){
      this.setState({
        showComponent:false
      })

    }
  }
  searchData(e) {
    var list = [...this.state.import_files];
    let res = '';
    list = list.filter(function (item) {
      if (item.table_name !== null) {
        res = item.table_name.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
      return res;
    });
  }
  async handleDelete(id, action) {
    const { t } = this.state;
    datasave.service(window.DELETE_IMPORT_FILE + '/' + id, 'POST')
      .then(response => {
        if (response.status == 200) {
          OCAlert.alertSuccess(t('Import file deleted successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
          this.fetchImportFiles();
          this.handleCreateImportFile();
        }
        else {
          OCAlert.alertWarning(this.state.t('Import file is not deleted'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      });

  }
  async handleChange(action, data) {
    this.setState({
      action: action,
      row_id: data.id,
      fileId: data.file_id,
      table_name: data.table_name,
      file: data.file_name,
      ref_id: data.ref_id,
      filePath: data.file_path,
      import_type: data.import_type,
      Submitted: false,
      showComponent:true
    })
  }
  handleCreateImportFile() {
    this.setState({
      action: 'create',
      row_id: 0,
      fileId: 0,
      table_name: '',
      import_type: 1,
      file: '',
      ref_id: 0,
      filePath: '',
      Submitted: false,
      showComponent:true
    })
  }
  async searchFilter(e) {
    var list = this.state.import_files;
    let res = '';
    list = list.filter(function (item) {
      if (item.table_name !== null) {
        res = item.table_name.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
      if (res) {
        return res;
      }
    });
    const page_data = this.getPageData(1, list);
    const count = this.getCountPage(list);
    await this.setState({
      items: page_data,
      count: count,
      active: 1,
      searchTerm: e.target.value,
      filterFullList: list,
    });
  }
  changePage(e, id) {
    const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
    const page_data = this.getPageData(id, list);
    this.setState({
      items: page_data,
      active: id,
      activePage: id
    });

  }
  getPageData(id, list = '') {
    const page = this.state.page;
    const items = (list !== '') ? list : this.state.import_files;
    const page_data = items.slice(page * (id - 1), page * id);
    return page_data;
  }
  getCountPage(items) {
    const itemLength = items.length;
    return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }
  deleteImportFile(id, action) {
    const { t } = this.state;
    confirmAlert({
      title: t('Confirm to submit'),
      message: t('Do you want to delete the Import file?'),
      buttons: [
        {
          label: t('Yes'),
          onClick: () => this.handleDelete(id, action)
        },
        {
          label: t('No'),
          onClick: () => this.handlcancel()
        }
      ]
    });
  }
  handlcancel() {

  }
  showImportFiles() {
    const { t } = this.state;
    let table = this.state.items != undefined && this.state.items.map((key) => {
      return (
        <tr style={{ borderBottom: "1px solid #dee2e6" }} >
          <td style={{ cursor: 'pointer', hover: 'color:#007bf8' }} onClick={(e) => this.handleChange('view', key)}><span>{key.table_name}</span></td>
          <td style={{ display: "flex", justifyContent: 'center', borderTop: '0px', borderBottom: '0px', borderLeft: '0px' }}>
            <Can
              perform="E_database"
              yes={() => (
                <div style={{ paddingLeft: '10px' }}>
                  <span className="" variant="link">
                    <i title={t("Edit")} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc" onClick={(e) => this.handleChange('edit', key)}></i>
                  </span>
                </div>
              )}
            />
            <Can
              perform="D_database"
              yes={() => (
                <div style={{ paddingLeft: '10px' }}>
                  <span className="" variant="link" onClick={(e) => this.deleteImportFile(key.id, 'Delete')}>
                    <i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec"></i>
                  </span>
                </div>
              )}
            />
          </td>
        </tr>)
    })
    return table;

  }
  render() {
    let pages = [];
    if (this.state.count > 0) {
      for (let number = 1; number <= this.state.count; number++) {
        pages.push(
          <Pagination.Item key={number} active={number === this.state.active} id={number} onClick={(e) => this.changePage(e, number)}>
            {number}
          </Pagination.Item>,
        );
      }
    }
    const { t } = this.state;
    return (
      <Can
        perform="E_database,V_database,D_database"
        yes={() => (
          <div className='container'>
            <div className="card-body mb-3">
              <div className='row'>
                <div className='col-md-12 mb-3'>
                  <div className='card'>
                    <div className="row container mt-3">
                      <reactbootstrap.Col lg={4} >
                        <div className="text-center">
                          <div style={{ display: 'flex' }} className="mb-2">
                            <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C" }} placeholder={t("What are you looking for ?")} autoFocus onChange={(e) => this.searchFilter(e)} /><br />
                            <Can
                              perform="E_database"
                              yes={() => (
                                <reactbootstrap.Button onClick={(e) => this.handleCreateImportFile()} variant="link">
                                  <i title={t('create import file')} class="webform-sprite webform-sprite-createlistc"></i>
                                </reactbootstrap.Button>
                              )}
                            />
                          </div>
                          <reactbootstrap.Table responsive bordered hover>
                            <thead>
                              <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
                                <th>{t('Name')}</th>
                                <th>{t('Actions')}</th>
                              </tr>
                            </thead>
                            <tbody>
                              {this.showImportFiles()}
                            </tbody>
                          </reactbootstrap.Table>
                          <div className="pg col-md-12">
                            {pages.length > 0 && <Pagination style={{ width: '200px', overflow: 'auto' }} size="md">{pages}</Pagination>}
                          </div>
                          {/*<div className="pg col-md-12">
                            {pages.length > 1 && <Pagination style={{ width: '200px', overflow: 'auto' }} size="md">{pages}</Pagination>}
                          </div>*/}
                        </div>
                      </reactbootstrap.Col>
                      <Can
                        perform="E_database"
                        yes={() => (
                          <reactbootstrap.Col log={8}>
                            {this.state.action !== '' && this.state.showComponent &&
                              <ImportFileDetails data={this.state} updateManageImportFiles={this.updateManageImportFiles.bind(this)} />
                            }
                          </reactbootstrap.Col>
                        )}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        no={ () =>
          <AccessDeniedPage/>
        }
      />
    );
  }


}
export default translate(ManageImportFiles)
