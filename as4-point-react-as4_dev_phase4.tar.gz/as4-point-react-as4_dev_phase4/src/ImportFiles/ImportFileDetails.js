import React, { useState, useEffect, useRef } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../language';
import axios from 'axios';
import {store } from '../store';
import $ from 'jquery';
import { datasave } from '../_services/db_services';
import ProgressBar from '../ProgressBar';
const path = require('path')

const ImportFileDetails=(props)=>{
  const t = props.t;
  const [importData,setImportData] = useState({
    file:props.data.file !== undefined ? props.data.file :'',
    file_details: '',
    show:false,
    popUpData:[],
    filePath:'',
    table_name:props.data.table_name !== undefined ? props.data.table_name :'' ,
    fileId:0,
    action:'',
    row_id:0,
    import_type:0,
    progressPopup:false,
    progressValue :10,
    progressMax:0,
    isDisable:false,
    Submitted:false,
    Valid:false
  });
  const {file,file_details,show,popUpData,table_name}=importData;
  // useEffect(() => {
  //   const baseState =async ()=>{
  //     setImportData({
  //       ...importData,
  //       file:props.filename,
  //       file_details: '',
  //       show:false,
  //       popUpData:'',
  //       filePath:props.filePath,
  //       fileId:props.fileId,
  //     })
  //   }
  //   baseState();
  // },[])
  function setVariables (data){
    setImportData({...importData,
      action:props.data.action,
      fileId:props.data.fileId,
      table_name:props.data.table_name,
      file:props.data.file,
      filePath:window.backendURL + props.data.filePath,
      isDisable:props.data.action === 'view' ? 'false' :'true',
      import_type:props.data.import_type,
      row_id:props.data.row_id,
      Submitted:props.data.Submitted,
      Valid:props.data.Valid
    })
  }
  useEffect (() =>{
    setVariables (props.data);
  },[props])

  useEffect (() =>{
    if(importData.Submitted === true){
      props.updateManageImportFiles(importData,importData.action);
    }
  },[importData.Submitted])
  // console.log(props);
  // console.log(importData);
  const handleChange = async(e)=>{
    const formData = new FormData();
    formData.append('file', e.target.files[0])
    const url = window.UPLOAD_FILE + '/' + window.GROUND_PLAN_FILES;
    let fileData = e.target.files[0];
    // document.getElementById("loding-icon").setAttribute("style", "display:block;");
    // await axios.post(window.backendURL + url, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
    //     .then(response => {
    //         document.getElementById("loding-icon").setAttribute("style", "display:none;");
    //         let res = response.data;
    //         if(res.status ===1){
    //            setImportData({
    //             ...importData,
    //             file:res.originalfname,
    //             filePath:res.filepath,
    //             fileId:res['file_id'][0],
    //             file_details: fileData,
    //           })
    //         }
    // })
    // .catch(error => {
    //   document.getElementById("loding-icon").setAttribute("style", "display:none;");
    //   OCAlert.alertError('Error occured while importing planning', { timeOut: window.TIMEOUTNOTIFICATION });
    // })
    setImportData({
      ...importData,
      file:e.target.files[0]['name'],
      file_details: e.target.files[0]
    })
  }


  const uploadFile =async (e)=>{
    console.log(file_details)
    if(file_details!=='' && file_details.name.split('.').pop() === 'csv'&& table_name.toString().replace(/\s+/g, ' ').trim()){
      const formData = new FormData();
      let Userdata = store.getState();
      var details = {
        file: file_details,
        loginPerson_Id :Userdata.UserData.user_details.person_id,
        table_name:importData.table_name,
        import_type:importData.import_type,
        action_type:importData.action === 'create' ? 1 : (importData.action === 'edit' ? 2 :0),
        row_id:importData.row_id,
        file_id:importData.fileId,
        file_path:importData.filePath,
        file_name:importData.file,
      }
      for (var key in details) {
        formData.append(key, details[key]);
      }
      console.log(formData)
      // formData.append('file', file_details);
      document.getElementById("loding-icon").setAttribute("style", "display:block;");
      await axios.post(window.backendURL + window.IMPORT_FILE_DETAILS, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
      .then(async response => {
        let data = response.data;
        document.getElementById("loding-icon").setAttribute("style", "display:none;");
        if(data.status===200 && data.result.status === 200){
          if(data.large_file === 1) {
            uplaodLargeFileUpload(data);
          }
          else{
          responseStatus(data);
        }

         //  setImportData({
         //   ...importData,
         //   Submitted:true
         // })
        }else{
          if(data.result.exception.message !== undefined && data.result.exception.message.includes("Invalid text representation")) {
            OCAlert.alertError(t('Id should be numeric values or try with correct format values file'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
          else{
          OCAlert.alertError(t('Something went wrong please try with correct  file '), { timeOut: window.TIMEOUTNOTIFICATION });
        }
        }
      });
    }
    else {
        OCAlert.alertError(t('Something went wrong please try with correct  file'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
  }
const uplaodLargeFileUpload = async(data) => {
  var chuksize = 2000;
  var rawRows = data.total_rows;
  console.log(rawRows);
let response;
  for(var start_row = 2; start_row < rawRows;start_row +=chuksize ) {
      var details = {
        start_row:start_row,
        table_name:data.table_name,
        table_headers:data.headers,
        chunkSize:chuksize,
        inputFileName:data.inputFileName,
        import_type:importData.import_type,
        action_type:importData.action === 'create' ? 1 : (importData.action === 'edit' ? 2 :0),
        row_id:importData.row_id,
        file_id:importData.fileId,
        file_path:data.inputFileName,
        file_name:importData.file,
       }
    response = await uploadDataByChunks(details);
    if(response.result === true) {
      showProgressBar(true,start_row,rawRows);
    //  OCAlert.alertWarning(t('Still uploading please wait....'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
    else{
      showProgressBar(false,start_row,rawRows);
      responseStatus(response);
      break;
    }
  }

    if(start_row > rawRows) {
      const interval = setInterval(() => {
                showProgressBar(true,rawRows,rawRows);
                responseStatus(response);
                clearInterval(interval);
          }, 1000);


    }



}
const showProgressBar = async (show,start_row,rawRows)=> {
  setImportData({
    ...importData,
    progressPopup:show,
    progressValue:start_row,
    progressMax:rawRows,
  })
}
const uploadDataByChunks = async(details) => {
console.log(data);
    var data = [];
  await  datasave.service(window.STORE_LARGEFILES_BY_CHUNKS, 'POST',details)
   .then(async response=>{
     data = response;
     // console.log(response)
     // if(response.result === true){
     //  OCAlert.alertWarning(t('Still uploading please wait....'), { timeOut: window.TIMEOUTNOTIFICATION });
     // }
   })
   return data;
}
  const responseStatus=async(result)=>
  {
    let data = result.validation;
    let warning =0;
   if(data.columns === 0) {
     OCAlert.alertWarning(t('Rows and columns are not equal'), { timeOut: window.TIMEOUTNOTIFICATION });
     warning++
   }
   else if(data.count === 0) {
     OCAlert.alertWarning(t('There is no data to import'), { timeOut: window.TIMEOUTNOTIFICATION });
     warning++
   }
   else if(data.emptyRows === 0){
      OCAlert.alertWarning(t('Empty row without column are there '), { timeOut: window.TIMEOUTNOTIFICATION });
      warning++
   }
   else if(data.fields === 0){
     OCAlert.alertWarning(t('Id field is mandatory '), { timeOut: window.TIMEOUTNOTIFICATION });
     warning++
  }
  else if(data.tableExist === 0) {
    OCAlert.alertWarning(t('give table name already exist'), { timeOut: window.TIMEOUTNOTIFICATION });
    warning++
  }
  else if (importData.action === 'edit' && (importData.import_type !== 2 && importData.import_type !== 3)) {
    OCAlert.alertWarning(t('Select all required fields'), { timeOut: window.TIMEOUTNOTIFICATION });
    warning++
  }
  else if (importData.file === '') {
    OCAlert.alertWarning(t('Select all required fields'), { timeOut: window.TIMEOUTNOTIFICATION });
    warning++
  }
  else{
    OCAlert.alertSuccess(t('Import file saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
  }
  if(warning === 0){
    setImportData({
     ...importData,
     Submitted:true,
     progressPopup:false,
   })
  }
   // else {
   //  // props.saveImportPlanning(result,importData);
   //   OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
   // }
    // switch (number) {
    //   case 1:
    //   OCAlert.alertWarning(t('Please import correct format file'), { timeOut: window.TIMEOUTNOTIFICATION });
    //   break;
    //   case 2:
    //   OCAlert.alertWarning(t('There is no data to import'), { timeOut: window.TIMEOUTNOTIFICATION });
    //   break;
    //   case 3:
    //   OCAlert.alertWarning(t('Email should be unique for each person'), { timeOut: window.TIMEOUTNOTIFICATION });
    //   break;
    //   case 4:
    //   OCAlert.alertWarning(t('Barcode should be unique for each person'), { timeOut: window.TIMEOUTNOTIFICATION });
    //   break;
    //   case 5:
    //   OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
    //   break;
    //   case 6:
    //   // setImportData({
    //   //   ...importData,
    //   //   show:true,
    //   //   popUpData:data
    //   // });
    //   break;
    // }
  }
  const openClosePopup=()=>{
    setImportData({
      ...importData,
      show:false,
      popUpData:[]
    });
  }
  const exampleDownLoad = ()=>{
    let userAgentString = navigator.userAgent;
    let chromeAgent = userAgentString.indexOf("Chrome") > -1;// Detect Chrome
    if(chromeAgent){
      window.open('https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/61376d7cebb502.611061961631022460.csv', '_blank');
    }else {
      var a = document.createElement('a');
      a.title = t("Download");
      a.href = 'https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/61376d7cebb502.611061961631022460.csv';
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
  }
  const handleChangeName = (event) =>{
    const { name, value } = event.target;
    setImportData({
      ...importData,
      [name]: value,
     });
   }

  const clearForm =()=>{
    const {file_details,file,table_name,action}=importData;
    if(file_details==='' && file === '' && table_name === '' || action === 'edit'){
          props.updateManageImportFiles(importData,'close_component');
          setImportData({
            ...importData,
            show:false,
            popUpData:[],
            file:'',
            file_details: '',
            filePath:'',
            table_name:'' ,
            fileId:0,
            action:'create',
            row_id:0,
            import_type:1,
          });
     }else {
      setImportData({
        ...importData,
        show:false,
        popUpData:[],
        file:'',
        file_details: '',
        filePath:'',
        table_name:'' ,
        fileId:0,
        action:'create',
        row_id:0,
        import_type:1,
      });
    }

  //  props.openCloseUploadPopup();
  }
  const popUp = ()=>{
    let data = popUpData &&Object.values(popUpData).map(item=>{
      return(
        <tr style={{ textAlign: 'center' }}>
        <td>{item.name}</td>
        <td>{item.email}</td>
        <td>{item.barcode}</td>
        </tr>
      );
    })
    return(
      <reactbootstrap.Modal
      show={show}
      onHide={(e) => openClosePopup()}
      dialogClassName="modal-90w"
      aria-labelledby="example-custom-modal-styling-title"
      >
      <reactbootstrap.Modal.Header closeButton>
      <reactbootstrap.Modal.Title>{t('Please verify this users and import again')}</reactbootstrap.Modal.Title>
      </reactbootstrap.Modal.Header>
      <reactbootstrap.Modal.Body>
      <reactbootstrap.Table responsive striped bordered hover size="sm">
      <thead style={{ backgroundColor: '#EC661C', color: '#fff', position: 'sticky', top: '0', textAlign: 'center' }}>
      <tr style={{ textAlign: 'center' }}>
      <th>{t('Name')}</th>
      <th>{t('Email')}</th>
      <th>{t('Barcode')}</th>
      </tr>
      </thead>
      <tbody>
      {data}
      </tbody>
      </reactbootstrap.Table>
      </reactbootstrap.Modal.Body>
      </reactbootstrap.Modal>)
    }

    const formDisable = (importData.Submitted === true && (importData.action==='edit'))? true:(  (props.data.action === 'create'||props.data.action === 'edit') ? false : true);

    return(
      <reactbootstrap.Container className='mt-3'>
      <fieldset disabled={formDisable}>
      <reactbootstrap.Row className='pl-4'>
      <reactbootstrap.Col className='col-md-2 pt-4 ml-2'>
      <reactbootstrap.FormLabel>{t('Table name')}:<span style={{ color: "red" }}>*</span></reactbootstrap.FormLabel>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-6 pt-4'>
      <reactbootstrap.InputGroup className="input_sw">
          <reactbootstrap.FormControl
                name="table_name"
                type = "text"
                placeholder={("Name")}
                aria-label="title"
                aria-describedby="basic-addon1"
                value={table_name}
                disabled={importData.action === 'edit'}
                onChange = {(e) => handleChangeName(e)}
                className="input_sw"
            />
            </reactbootstrap.InputGroup>
            </reactbootstrap.Col>
            </reactbootstrap.Row>
      <reactbootstrap.Row className='pl-4'>
      <reactbootstrap.Col className='col-md-2 pt-4 ml-2'>
      <reactbootstrap.FormLabel>{t('Upload File')}</reactbootstrap.FormLabel>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-6'>
      <reactbootstrap.InputGroup className="custom-file input_sw">
      <reactbootstrap.FormControl
      type="file"
      className="custom-file-input"
      id="inputGroupFile01"
      name='image'
      accept={".csv"}
      onChange={(e) => handleChange(e)}
      onClick={(event)=> event.target.value = null}
      />
      <reactbootstrap.FormLabel className="custom-file-label" htmlFor="inputGroupFile01">
      {file !== null && file}
      </reactbootstrap.FormLabel>
      </reactbootstrap.InputGroup>
      <p>{t('Upload only csv format files.')}</p>
      {importData.action === 'edit' &&  <div class="col-md-8 input-padd" >
           <div class="custom-control custom-radio">
                <input type="radio" class="custom-control-input" id="update" value ="2" disabled={false} checked={importData.import_type === 2} onChange={(e) => setImportData({ ...importData, import_type:2  })}  name="import_type"/>
                <label class="custom-control-label" for="update">Update</label>
           </div>
           <div class="custom-control custom-radio">
                <input type="radio" class="custom-control-input" id="merge" value ="3" disabled={false} checked={importData.import_type === 3} onChange={(e) => setImportData({ ...importData, import_type:3  })}  name="import_type"/>
                <label class="custom-control-label" for="merge">Merge</label>
           </div>
           {<div style={{ color: 'red' }} className="error-block">{t('')}</div>}
      </div>}
      {importData.action === 'create' &&<p onClick={(e)=>exampleDownLoad()} style={{color: '#EC661C',padding:'0px',margin:'0px'}}>{t('Download example csv file')}</p>}
      {importData.action === 'edit' && <p><a href={importData.filePath} download>{t('Download table as csv file')}</a></p>}
      </reactbootstrap.Col>
      </reactbootstrap.Row>
{importData.progressPopup && <ProgressBar value= {importData.progressValue} color={"#ff7979"} width={"150px"} max={importData.progressMax}/>}
      <reactbootstrap.FormGroup className='pl-4 float-right'>
      <div className="organisation_list mt-4">
      <a  type="submit" name="cancel" onClick={(e) => clearForm()}>{t('Cancel')}</a>&nbsp;&nbsp;&nbsp;
      <reactbootstrap.Button type="submit" name="save" className="btn btn-primary" onClick={(e) => uploadFile(e)}>{t('Save')}</reactbootstrap.Button>{popUp()}
      </div>
      </reactbootstrap.FormGroup>
      </fieldset>
      </reactbootstrap.Container>
    )

  }
  export default translate(ImportFileDetails);
