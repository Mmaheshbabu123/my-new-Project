import React ,{Component}from 'react';
import ReactCrop from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import { translate } from '../language';
class ImageCropper extends Component {
  constructor(props) {
    super(props);
    this.state = {
    src: null,
    t:props.t,
    crop: {
      unit: '%',
      width: 100,
      // aspect: 16 / 9,
      height: 100,
    },
    croppedImageUrl:null
  }
};
async componentDidMount() {
  if(this.props.disableCroping){
  this.setState({
    croppedImageUrl:'',
    src:this.props.src,
    crop:this.props.cropingData
  })
}else {
  this.setState({
    croppedImageUrl:'',
    src:this.props.src
  })
}
}
  // If you setState the crop in here you should return false.
  onImageLoaded = image => {
    this.imageRef = image;
  };
  onCropComplete = crop => {
    this.makeClientCrop(crop);
  };
  onCropChange = (crop, percentCrop) => {
    // You could also use percentCrop:
    // this.setState({ crop: percentCrop });
    this.setState({ crop });
  };
  async makeClientCrop(crop) {
    if (this.imageRef && crop.width && crop.height) {
      const croppedImageUrl = await this.getCroppedImg(
        this.imageRef,
        crop,
        'newFile.jpeg'
      );
     this.props.cropedData(croppedImageUrl,crop);
      // this.setState({
      //   croppedImageUrl:croppedImageUrl
      // })
    }
  }
  getCroppedImg(image, crop, fileName) {
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = crop.width;
    canvas.height = crop.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(
      image,
      crop.x * scaleX,
      crop.y * scaleY,
      crop.width * scaleX,
      crop.height * scaleY,
      0,
      0,
      crop.width,
      crop.height
    );
    return canvas.toDataURL('image/jpeg');
  }

  render() {
    let { crop, src ,croppedImageUrl,t} = this.state;
    src = this.props.fromZones === 1 ? this.props.src : src;
    crop = this.props.fromZones === 1 ? this.props.cropingData : crop;
    return (
      <>
        {src &&
          <div className='col-md-12 justify-content-md-center'>
          <ReactCrop
            src={src}
            crop={crop}
            ruleOfThirds
            onImageLoaded={this.onImageLoaded}
            onComplete={this.onCropComplete}
            onChange={this.onCropChange}
            crossorigin={'anonymous'}
            disabled={this.props.disableCroping}
          />
          </div>}
      </>
    );
  }
}
export default translate(ImageCropper);
