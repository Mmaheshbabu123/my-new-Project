import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../src/_services/db_services';
import { connect } from "react-redux";
import { translate } from "../src/language";
import { OCAlert } from '@opuscapita/react-alerts';
import TreeMenu from 'react-simple-tree-menu';
import { ListGroup, ListGroupItem } from 'reactstrap';
import CheckBox from './CheckBox';
class PractiseDynamicComments extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t : props.t,
      comment:'',
      replay:'',
      showComment:true,
      replayCommentTree:[],
      openNodes:[],
      activeOpenNode:'',
      replayToId:0,
      replayToCommentId:0,
      todoId:1,
      showCloseComment:false,
    }
  }
  async componentDidMount(){
    const {t} =this.state;
    await datasave.service(window.GET_COMMENT_REPLAYS+'/'+1,'GET')
      .then(async response=>{
        if(response['status']===200){
          this.setState({
            replayCommentTree:response['data']['commentStracture'],
            openNodes:response['data']['openNodes'],
            replay:'',
            comment:'',
          })
        }else{
          OCAlert.alertError(t('Something went wrong please try  again later'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
      }
    )
  }
  commentOnChange=(e)=>{
    this.setState({
      comment:e.target.value
    })
  }
  replayOnChange=(e)=>{
    this.setState({
      replay:e.target.value
    })
  }
  saveComment=async(e)=>{
    const {comment,t,todoId} = this.state;
    if(comment.length<1){
      OCAlert.alertWarning(t('Please enter Comment'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }else{
      let data ={
        comment:comment,
        todoId:todoId
      }
      await datasave.service(window.STORE_TODO_COMMENTS,'POST',data)
        .then(async response=>{
          if(response['status']===200){
            await this.setState({
              replayCommentTree:response['data']['commentStracture'],
              openNodes:response['data']['openNodes'],
              replay:'',
              comment:'',
            })
          }
        })
    }
  }
  saveReplay=async(e)=>{
    const {replay,t,replayToId,replayToCommentId,todoId} = this.state;
    if(replay.length<1){
      OCAlert.alertWarning(t('Please enter Replay'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }else{
      let data ={
        replay:replay,
        replayToId:replayToId,
        replayToCommentId:replayToCommentId,
        todoId:todoId
      }
      await datasave.service(window.STORE_TODO_COMMENTS_REPLAYS,'POST',data)
        .then(async response=>{
          if(response['status']===200){
            await this.setState({
              replayCommentTree:response['data']['commentStracture'],
              openNodes:response['data']['openNodes'],
              replay:'',
              comment:'',
              showComment:true
            })
          }
        })
    }
  }
  onClickNode = async (key, label, props) => {
    const {openNodes} =this.state;
    var openNodeArray = openNodes;
    if (openNodeArray && openNodeArray.includes(key)) {
      var index = openNodeArray.indexOf(key);
      if (index !== -1) openNodeArray.splice(index, 1);
    } else {
      openNodeArray.push(key);
    }
    this.setState({
      activeOpenNode: key,
      openNodes: openNodeArray
    })
  }
  toggleCommentReplay=(id,type,commentId)=>{
    this.setState({
      showComment:false,
      comment:'',
      replay:'',
      replayToId:type==='comment'?-1:id,
      replayToCommentId:commentId
    })
  }
  handleShowCloseComment=()=>{
    this.setState({
      showCloseComment:!this.state.showCloseComment,
      showComment:true
    })
  }
  showCommentSection=(e)=>{
    console.log(e.target.name);
    this.setState({
      showComment:e.target.name==='comment'?true:false
    })
  }
  render(){
    const {t,comment,replay,showComment,replayCommentTree,activeOpenNode,openNodes,showCloseComment} =this.state;
    const DEFAULT_PADDING = 5;
    const ICON_SIZE = 8;
    const LEVEL_SPACE = 16;
    const WIDTH_DYNAMIC = 33;
    {/**const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }}>{on ? '-' : '+'}</span>;*/}
    const ListItem = ({
      level = 0,
      hasNodes,
      isOpen,
      searchTerm,
      openNodes,
      childrens,
      id,
      image_path,
      user_name,
      updated_at,
      message,
      user_id,
      ref_id,
      replayedToPerson,
      type,
      commentId,
      replayId,
      ...props
    }) => (
        <reactbootstrap.Col className="folder-manual-section">
          <ListGroupItem
            {...props}
            style={{ paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE, cursor: 'pointer' }}
            key={id}
          >
            <reactbootstrap.Col className="list-items-structure" style={{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
              {/*hasNodes && <ToggleIcon on={isOpen} />*/}
              {/**!hasNodes && <span style={{ marginRight: 8 }}> &nbsp;</span>*/}
              {type==='comment' &&
              <>
                <img src={image_path} name='comment' onClick={e=>this.showCommentSection(e)} style={{ marginRight: '5px' ,width:'50px',height:'50px'}}/>
                <p className="row mt-3 result-label">{user_name}<br/>{updated_at}<br/>{message}</p>
              </>}
              {type==='replay' &&
              <>
                <img src={image_path} name='replay' onClick={e=>this.showCommentSection(e)}style={{ marginRight: '5px' ,width:'50px',height:'50px'}}/>
                <p className="row mt-3 result-label">{user_name}<br/>{updated_at}<br/>@{replayedToPerson}-- {message}</p>
              </>}
              <reactbootstrap.Col>
                <p style={{marginLeft: '10px', float: 'right' }} onClick={e=>this.toggleCommentReplay(id,type,commentId)}>{t("Reply")}</p>
              </reactbootstrap.Col>
            </reactbootstrap.Col>
          </ListGroupItem>
        </reactbootstrap.Col>
      );
    return(
      <reactbootstrap.Container>
      <reactbootstrap.Row>
      <reactbootstrap.Col className='col-md-1'>
      <CheckBox
          tick={showCloseComment}
          onCheck={(e) => this.handleShowCloseComment()}

      />
      </reactbootstrap.Col>
      <reactbootstrap.FormLabel className='pt-1'>{t('Show comments')}</reactbootstrap.FormLabel>
      </reactbootstrap.Row>
        {showCloseComment && Object.keys(replayCommentTree).length>0 && <reactbootstrap.Row>
          <reactbootstrap.Col className='col-md-12 pt-2'>
          <TreeMenu
            data={replayCommentTree}
            hasSearch='false'
            onClickItem={({ key, label, ...props }) => { this.onClickNode(key, label, props); }}
            debounceTime={125}
            activeKey={activeOpenNode}
            openNodes={openNodes}
          >
            {({ search, items }) => (
              <>
              {/**<Input onChange={e => search(e.target.value)} placeholder={t("Type and search")} />*/}
                <ListGroup className="folder-left-list-group">
                  {items.map(props => (<ListItem {...props} />))}
                </ListGroup>
              </>
            )}
          </TreeMenu>
          </reactbootstrap.Col>
        </reactbootstrap.Row>}
        {showComment && <reactbootstrap className='col-md-12  mt-2 d-flex'>
          <reactbootstrap.FormControl
            className="col-md-11"
            as='textarea'
            placeholder={t('Comment...')}
            onChange={(e) => this.commentOnChange(e)}
            value={comment}/>
          <reactbootstrap.Col className='col-md-1'>
            <reactbootstrap.Button  onClick={e=>this.saveComment()}>{t("Submit")}</reactbootstrap.Button>
          </reactbootstrap.Col>
        </reactbootstrap>}
        {!showComment && <reactbootstrap className='col-md-12  mt-2 d-flex'>
          <reactbootstrap.FormControl
            className="col-md-11"
            as='textarea'
            placeholder={t('Replay...')}
            onChange={(e) => this.replayOnChange(e)}
            value={replay}/>
          <reactbootstrap.Col className='col-md-1'>
            <reactbootstrap.Button  onClick={e=>this.saveReplay()}>{t("Reply")}</reactbootstrap.Button>
          </reactbootstrap.Col>
        </reactbootstrap>}
      </reactbootstrap.Container>
    )
  }
}
export default translate(PractiseDynamicComments);
