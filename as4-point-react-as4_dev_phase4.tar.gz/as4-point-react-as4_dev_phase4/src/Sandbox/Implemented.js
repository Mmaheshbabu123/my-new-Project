import React, { Component } from 'react';
import { translate } from '../language';
import * as reactbootstrap from 'react-bootstrap';
import *  as Reactbootstrap from 'react-bootstrap';
import BlancoCan from '../_components/CanComponent/BlancoCan';
import { Input, ListGroup, ListGroupItem } from 'reactstrap';
import Can from '../_components/CanComponent/Can';
import { datasave } from '../_services/db_services';
import { persistor, store } from '../store';
import { OCAlert } from '@opuscapita/react-alerts';
import axios from 'axios';
import _ from "lodash";
import Pagination from 'react-bootstrap/Pagination';
import { confirmAlert } from 'react-confirm-alert';





class Implemented extends Component {
    constructor(props) {
        super(props)
        this.state = {
            strings: [],
            count :0,
            t: props.t,
            page: 5,
            activePage: 1,
            error: "",
            items: [],
            empty: "",
            searchTerm: '',
            filterFullList : [],
            active :1,
            count_todo : 0

        }
        this.searchData = this.searchData.bind(this);
        this.handlePageChange = this.handlePageChange.bind(this)

        this.addtotodo = this.addtotodo.bind(this);
    }
    componentDidMount(){
        var url = window.IMPLEMENTED;
        datasave.service(url, "GET")
            .then(result => {
              const pageData = this.getPageData(1, result);
              const count = this.getCountPage(result);
                this.setState({
                    strings: result,
                    count: count,
                    items: pageData,
                    active:1
                })
                const data = ({
                    manual_id : this.props.manual_id,
                    web_id :localStorage.getItem('web_id'),
                    status :window.IMPLEMENTED_DOCUMENT
                })
                datasave.service(window.SANDBOX_COUNT,'POST',data)
                .then(result=>{
                    this.setState({
                        count_todo: result,
                    })
                })
            });
    }
    addtotodo(unique_key,stdid) {
      const {t} = this.state;
        confirmAlert({
            title: t('Confirm to submit'),
            message: t('Do you want to add the document into todo list?'),
            buttons: [
                {
                    label: t('Yes'),
                    onClick: () => this.activatetodo(unique_key,stdid)
                },
                {
                    label: t('No'),
                    onClick: () => this.handlcancel()
                }
            ]
        });
    }
    activatetodo(unique_key,stdid) {
      const data ={
          status : window.TODO,
          web_id : localStorage.getItem('web_id'),
          secret_doc_id : unique_key,
          std : stdid
      }
      datasave.service(window.archived,'POST',data)
      .then(response=>{
          if(response==="Success") {
              var url = window.IMPLEMENTED;
              datasave.service(url, "GET")
                  .then(result => {
                    const pageData = this.getPageData(1, result);
                    const count = this.getCountPage(result);
                      this.setState({
                          strings: result,
                          count: count,
                          items: pageData,
                          active:1
                      })
                    const data = ({
                        manual_id : this.props.manual_id,
                        web_id :localStorage.getItem('web_id'),
                        status :window.ARCHIVED
                    })
                    datasave.service(window.SANDBOX_COUNT,'POST',data)
                    .then(result=>{
                        this.setState({
                            count_todo: result,
                        })
                    })
                  });
                  // this.props.fetchManualslist(false)
          }

      })

    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }
    searchData(e) {
        var list = [...this.state.strings];
        list = list.filter(function (item) {
            if (item.name !== null) {
                return item.name.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
            else if (item.code !== null ) {
              return item.code.toLowerCase().search(
                  e.target.value.toLowerCase()) !== -1;
            }
        });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    changePage(e, id = 1) {
        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });
    }
    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.strings;
        const page_data = items.slice(page * (id - 1), page * id);
        console.log(page_data);
        return page_data;
    }

    handlePageChange(pageNumber) {
        this.setState({ activePage: pageNumber });
        document.getElementById("loding-icon").setAttribute("style", "display:block;");
        axios.get(process.env.REACT_APP_serverURL + '/api/get_strings?page=' + pageNumber).then(response => {
            document.getElementById("loding-icon").setAttribute("style", "display:none;");

            this.setState({
                strings: response.data[0].data,
                activePage: pageNumber
            })
        });
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.droppable_status!==this.props.droppable_status) {
            var url = window.IMPLEMENTED;
            datasave.service(url, "GET")
                .then(result => {
                  const pageData = this.getPageData(1, result);
                  const count = this.getCountPage(result);
                    this.setState({
                      strings: result,
                      count: count,
                      items: result,
                      active:1
                    })
                    const data = ({
                        manual_id : this.props.manual_id,
                        web_id :localStorage.getItem('web_id'),
                        status :window.IMPLEMENTED_DOCUMENT
                    })
                    datasave.service(window.SANDBOX_COUNT,'POST',data)
                    .then(result=>{
                        this.setState({
                            count_todo: result,
                        })
                    })
            });
        }

    }
    searchUpdated(term) {
        this.setState({
            searchTerm: term,
        })
    }

    Preview(id) {
        var url = window.DOC_PREVIEW + '/1' + '/' + id + '/general/Dutch';
        axios.get(process.env.REACT_APP_serverURL+window.GET_META_DATA + '/' + id)
        .then(result => {
            console.log(result);
            console.log(result.data);
            if (result.data.docpath[0].doc_type_id <= 3) {
                window.open(window.location.origin + '/previewrevisionentities/' +1+'/'+ id+'/'+0, '_blank');
            }
            else{
                window.open(window.location.origin+'/previewrevisionentities/' +1+'/'+ id+'/'+'general','_blank');

                // window.open(window.location.origin+'/Common/' +1+'/'+ id,'_blank');
              }
        })
    }


    render () {
      const { t } = this.state;
      const filtered = this.state.items;
      let active = this.state.active;
      const page_data = this.state.strings.slice(this.state.page - 5, this.state.page);
      let pages = [];
      if (this.state.count > 0) {
          for (let number = 1; number <= this.state.count; number++) {
              pages.push(
                  <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                      {number}
                  </Pagination.Item>,
              );
          }
      }

        return(
            <div>
                <div className='' >
                    <div className='row col-md-12 pr-0 justify-content-center' >
                        <div className='row col-md-12 pl-0'>
                            <div className='col-md-6 pl-0'>
                                <input className="form-control search-box-border col-md-6 mb-2 mt-3" placeholder={t("Search")} onChange={this.searchData} /><br />
                            </div>
                            <div className="col-md-6" >
                                <span style={{float: 'right', marginLeft: '-20px', border: '1px solid orange', padding: '0px 5px', marginTop: '10px'}}>{t('Implemented count:')}{' '+this.state.count_todo}</span>
                            </div>
                        </div>
                        <div className='col-md-12 p-0 mt-3' >

                        <form method='POST'>
                          <div style={{}}>
                            {/* <reactbootstrap.Table responsive>
                            <reactbootstrap.Table className="site-table-main" >*/}
                            <Reactbootstrap.Table striped bordered hover variant="">
                                <thead>
                                  <tr style={{backgroundColor: '#EC661C',color: '#fff'}}>
                                    <th>{t('Document')}</th>
                                    <th>{t('Standard')}</th>
                                    <th>{t('Implemented by')}</th>
                                    <th>{t('Date')}</th>
                                    <th>{t('Preview')}</th>
                                    <th>{t('Add to todo')}</th>
                                  </tr>
                                </thead>
                                  {filtered.map(function(item){
                                      return(
                                      <>
                                      <tr style={{ borderBottom: '1px solid #dee2e6' }}>

                                             <td>{item.code}{' '}{item.name}{' '}{item.version}</td>
                                              <td>{item.standard}</td>
                                              <td>{item.person_name}</td>
                                              <td>{item.updated_at}</td>
                                              <td><i class="sandbox-sprite sandbox-sprite-Preview"   alt="Logo" title={t("Preview")} style={{ display: 'inline-flex', marginLeft: '3px', marginRight: '3px' ,alignSelf: 'center' }} onClick={this.Preview.bind(this,item.id)}></i></td>
                                              <td><i class="sandbox-sprite sandbox-sprite-MarkArchive" alt="Logo" title={t("Add to todo")} style={{display: 'inline-flex', marginLeft: '3px', marginRight: '3px' }} onClick={() => this.addtotodo(item.unique_key,item.stdid)}></i></td>

                                              <br/><br/>
                                            </tr>

                                        </>
                                      )

                                    },this)}
                                </Reactbootstrap.Table>

                              </div>
                              <div className="page-nation-sec col-md-12">
                                  <Pagination style={{ width: '500px', overflow: 'auto',scrollbarWidth: 'thin' }} size="md">{pages}</Pagination>
                              </div>

                            </form>

                        </div>


                    </div>
                </div>

            </div>
        )

    }
}
export default translate(Implemented)
