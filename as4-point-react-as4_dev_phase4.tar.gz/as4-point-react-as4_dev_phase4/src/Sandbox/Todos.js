import React, { Component } from 'react';
import { translate } from '../language';
import * as reactbootstrap from 'react-bootstrap';
import TreeMenu from 'react-simple-tree-menu'
import BlancoCan from '../_components/CanComponent/BlancoCan';
import { Input, ListGroup, ListGroupItem } from 'reactstrap';
import Can from '../_components/CanComponent/Can';
import SandboxCan from '../_components/CanComponent/SandboxCan';
import DocumentHeader from '../_components/DocumentHeader';
import { datasave } from '../_services/db_services';
import { persistor, store } from '../store';
import _ from "lodash";
import { Draggable, Droppable } from 'react-drag-and-drop'
// import documentlogo from '../blanco/document.png';
// import Archived from './Archived';
import { confirmAlert } from 'react-confirm-alert'; // Import
import { OCAlert } from '@opuscapita/react-alerts';
import axios from 'axios';
import './Sandbox.css';

function arr_diff(a1, a2) {

    var a = [], diff = [];

    for (var i = 0; i < a1.length; i++) {
        a[a1[i]] = true;
    }

    for (var i = 0; i < a2.length; i++) {
        if (a[a2[i]]) {
            delete a[a2[i]];
        } else {
            a[a2[i]] = true;
        }
    }

    for (var k in a) {
        diff.push(k);
    }

    return diff;
}


let clickEventPrevent = false;
class Todos extends Component {
    constructor(props) {
        super(props);
        this.state = {
            t:props.t,
            active_tab: 1,
            disabled : false,
            disableFields : false,
            sandbox : true,
            blanco_data: {},
            unique_key : '',
            web_id : parseInt(localStorage.getItem('web_id')),
            manualStandards : [],
            manualtabkey: '',
            openNodeManuals: [],
            nodeList:[],
            // sanbox_rights : [],
        }
        this.onClickNode = this.onClickNode.bind(this)

    }
    componentDidMount(){

        let userData = store.getState();
        let mainsiteurl = userData.UserData.mainsiteurl
        console.log(mainsiteurl);
        this.setState({
            openNodeManuals: JSON.parse(localStorage.getItem('openNodeManuals')),
        })
        // var url = window.FETCH_MANUALS + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id+ '&sandbox=' + this.state.sandbox+'&web_id='+this.state.web_id+'&url='+window.backendURL;
        // axios.get(process.env.REACT_APP_serverURL + url)
        //     .then(result => {
        //         this.setState({
        //             folderDetails: result.data.folderdata,
        //         })
        //         this.updateTodoCount()
        //         this.displayFolder(result.data.folderdata)
        //     });
        const data = {
          id : this.props.manual_id
        }
        datasave.service(window.GET_MANUAL_STANDARDS, "POST",data)
        .then(result=>{
          console.log(result[0]);
            this.setState({
              manualStandards : result,
              manualtabkey :(result.length!==0)?result[0]['id']:0
            })
            let userData = store.getState();

            var url = window.FETCH_MANUAL_SANDBOX + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id +'&sandbox='+this.state.sandbox+'&web_id='+this.state.web_id+'&url='+window.backendURL+'&std='+((result.length!==0)?result[0]['id']:0);
            axios.get(process.env.REACT_APP_serverURL + url)
            .then(result => {
                    this.setState({
                        folderDetails: result.data.folderdata,
                        nodeList : result.data.opennodesfilter,
                    })
                    this.updateTodoCount()
                    this.displayFolder(result.data.folderdata)
            });
        })

    }
    componentDidUpdate(prevProps, prevState) {
      let userData = store.getState();
      if(prevProps.manual_id!==this.props.manual_id) {
        var url = window.FETCH_MANUAL_SANDBOX + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id+ '&sandbox=' + this.state.sandbox+'&web_id='+this.state.web_id+'&url='+window.backendURL+'&std='+this.state.manualtabkey ;
        axios.get(process.env.REACT_APP_serverURL + url)
        .then(result => {
            this.setState({
                folderDetails: result.data.folderdata,
            })
            this.updateTodoCount()
            this.displayFolder(result.data.folderdata)
        });
      }
        if(prevProps.archived_status !== this.props.archived_status) {
            var url = window.FETCH_MANUAL_SANDBOX + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id+ '&sandbox=' + this.state.sandbox+'&web_id='+this.state.web_id+'&url='+window.backendURL+'&std='+this.state.manualtabkey;
            axios.get(process.env.REACT_APP_serverURL + url)
            .then(result => {
                this.setState({
                    folderDetails: result.data.folderdata,
                })
                this.updateTodoCount()
                this.displayFolder(result.data.folderdata)
            });
            this.props.fetchManualslist(false)
        }

        if (this.props.droppable_status !== undefined) {
            if (prevProps.droppable_status !== this.props.droppable_status) {
                    var url = window.FETCH_MANUAL_SANDBOX + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id+ '&sandbox=' + this.state.sandbox+'&web_id='+this.state.web_id+'&url='+window.backendURL+'&std='+this.state.manualtabkey;
                    axios.get(process.env.REACT_APP_serverURL + url)
                    .then(result => {
                        this.setState({
                            folderDetails: result.data.folderdata,
                        })
                        this.updateTodoCount()
                        this.displayFolder(result.data.folderdata)
                    });
                    this.props.change_droppable_status(false)
            }
        }
    }

    updateTodoCount(){
        const data = ({
            manual_id : this.props.manual_id,
            web_id :localStorage.getItem('web_id'),
            status :window.TODO,
            std : this.state.manualtabkey,
        })
        datasave.service(window.SANDBOX_TOTAL_COUNT,'POST',data)
        .then(result=>{
            this.setState({
                count: result,
            })
        })
        this.props.updatecount();
    }
    updateFolder(manual_id) {

        let userData = store.getState();
        var url = window.FETCH_MANUAL_SANDBOX + '/' + manual_id + '?pid=' + userData.UserData.user_details.person_id+ '?sandbox=' +this.state.sandbox+'&web_id='+this.state.web_id+'&url='+window.backendURL+'&std='+this.state.manualtabkey;
        axios.get(process.env.REACT_APP_serverURL + url)
            .then(result => {
                this.setState({
                    folderDetails: result.data.folderdata,
                })
                this.updateTodoCount()
                this.displayFolder(result.data.folderdata)
            });
    }
    displayFolder(data) {
        let finalData = {};
        let folderData = data;
        var touched_ids = [];
        var linked_folders = [];
        var not_linked_folders = [];
        Object.keys(folderData).map(function (key) {
            // if(folderData[key].childrens.length !== undefined){
                Array.from(Object.values(folderData[key].childrens)).forEach(function (id) {
                  linked_folders.push('F' + folderData[id].parent);
                    folderData[key].nodes[id] = folderData[id];
                    touched_ids.push(id);
                });
            // }

            finalData[key] = folderData[key];

        });

        touched_ids.forEach(function (id) {
            delete finalData[id];
        });

        this.openNodesFilter(linked_folders, not_linked_folders);

        this.setState({
            blanco_data: finalData,
        })
    }
    openNodesFilter(linked_folders, not_linked_folders) {
        linked_folders = [...new Set(linked_folders)];
        not_linked_folders = [...new Set(linked_folders)];
        var result = not_linked_folders.filter(value => -1 !== linked_folders.indexOf(value));
        var finalresult = arr_diff(not_linked_folders, result);
        var filter_nodes = this.state.nodeList;
        filter_nodes.forEach(function (value, index, array) {
            var inner_key = value.explode('/', '');
            inner_key.forEach(function (value1, index1, array) {
                if (finalresult.includes(value1)) {
                    filter_nodes.splice(index);
                }

            });

        });
        this.setState({
            openNodeManuals: filter_nodes
        });
        localStorage.setItem('openNodeManuals', JSON.stringify(filter_nodes));

    }
    onClickNode(key, label, props) {
        this.setState({
            activeOpenNode:key,
        });
       if(props.current_type === 'document'){
        localStorage.setItem('docID',props.key_type);
       }
        if (clickEventPrevent) {
          clickEventPrevent = false;
          return false;
        }
        if(localStorage.getItem('openNodeManuals') !==null){
        var opennodes = JSON.parse(localStorage.getItem('openNodeManuals'));
      }
      else{
        var opennodes =[];
      }
      if(opennodes!==null && opennodes.includes(key)){
        var index = opennodes.indexOf(key);
        if (index !== -1) opennodes.splice(index, 1);
      }else{
        opennodes.push(key);
      }
        localStorage.setItem('openNodeManuals', JSON.stringify(opennodes));
        this.setState({
            openNodeManuals: opennodes,
            activeOpenNode:key,
        });
          // return false;
          this.debouncedClickEvents = this.debouncedClickEvents || [];

          // Each click we store a debounce (a future execution scheduled in 250 milliseconds)
          const callback = _.debounce(_ => {
              // YOUR ON CLICKED CODE

              this.debouncedClickEvents = [];
          }, 500);
          this.debouncedClickEvents.push(callback);

          // We call the callback, which has been debounced (delayed)
          callback();
          // We call the callback, which has been debounced (delayed)
      }
    onDoubleClickNode(key, label, props) {
      const {t} = this.state;
        if (this.debouncedClickEvents.length > 0) {
            _.map(this.debouncedClickEvents, (debounce) => debounce.cancel());
            this.debouncedClickEvents = [];
        }
        OCAlert.alertWarning(t('Double click!'), { timeOut: window.TIMEOUTNOTIFICATION1});

        // alert('double click');
    }
    actionHeader(id, parent_type, action, addtype, manual_id, label) {
      const {t} = this.state;
        clickEventPrevent = true;
        const credentials = {};
        credentials.parent_type = parent_type;
        credentials.parent_id = id;
        credentials.addtype = addtype;
        credentials.blanco_id = this.state.blanco_id;
        credentials.manual_id = manual_id;
        credentials.manual_flag = 1;
        credentials.action = action;
        this.setState({
            showFolder: false,
            showDocument: false,
            showMemo: false,
        })
        this.removeEditorFrame();
        if (addtype === 'folder') {
          this.removeEditorFrame();
            this.setState({
                credentials: credentials,
                showFolder: true,
                showDocument: false,
                showMemo: false,
                showEditor: false,
            })
        }
        else if (addtype === 'editor') {
            datasave.service(window.GET_META_DATA + '/' + id, "GET")
                .then(result => {
                  if(result.docpath.length === 0){
                      datasave.service(window.ADD_DOC_DATA + '/' + id, "GET")
                      .then(response =>{
                          if(result.templates.length < 2){
                            OCAlert.alertWarning(t('No layouts are added!'), { timeOut: window.TIMEOUTNOTIFICATION1});

                            // alert('No layouts are added');
                          }
                      })
                  }
                  else if (result.templates.length < 2) {
                    OCAlert.alertError(t('Layouts are not properly configured. Try again!'), { timeOut: window.TIMEOUTNOTIFICATION1});

                    // alert('Layouts are not properly configured. Try again.');
                  }
                  else {
                      this.updateEditorFrame();
                      this.setState({
                        credentials: credentials,
                        showDocument: false,
                        showFolder: false,
                        showMemo: false,
                        showEditor: true,
                        standards: result.standards,
                        templates: result.templates,
                        docPath: result.docpath[0].doc_path,
                        editorDocId: id,
                        doc_type: result.docpath[0].doc_type_id,
                      });
                  }
                })
        }

        else {
            this.removeEditorFrame();
            this.setState({
                credentials: credentials,
                showDocument: true,
                showFolder: false,
                showMemo: false,
                showEditor: false,
            })
        }
    }
    archived(unique_key) {
        const {t} = this.state;
        confirmAlert({
            title: t('Confirm to submit'),
            message: t('Do you want to archive the document?'),
            buttons: [
                {
                    label: t('Yes'),
                    onClick: () => this.handleArchived(unique_key)
                },
                {
                    label: t('No'),
                    onClick: () => this.handlcancel()
                }
            ]
        });
    }

    markasimplemented(unique_key) {
        const {t} = this.state;
        confirmAlert({
            title: t('Confirm to submit'),
            message: t('Do you want to mark the document as implemented?'),
            buttons: [
                {
                    label: t('Yes'),
                    onClick: () => this.handlemarkimplemented(unique_key)
                },
                {
                    label: t('No'),
                    onClick: () => this.handlcancel()
                }
            ]
        });
    }
    handleArchived(unique_key) {
        const data ={
            status : window.ARCHIVED,
            web_id : localStorage.getItem('web_id'),
            secret_doc_id : unique_key,
            std:this.state.manualtabkey,
        }
        datasave.service(window.archived,'POST',data)
        .then(response=>{
            if(response==="Success") {
                this.props.addtoArchived()
                let userData = store.getState();
                var url = window.FETCH_MANUAL_SANDBOX + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id +'&sandbox='+this.state.sandbox+'&web_id='+this.state.web_id+'&url='+window.backendURL+'&std='+this.state.manualtabkey;
                axios.get(process.env.REACT_APP_serverURL + url)
                .then(result => {
                        this.setState({
                            folderDetails: result.data.folderdata,
                        })
                        this.updateTodoCount()
                        this.displayFolder(result.data.folderdata)
                });
            }

        })
    }

    handlemarkimplemented(unique_key) {
        const data ={
            status : window.IMPLEMENTED_DOCUMENT,
            web_id : localStorage.getItem('web_id'),
            secret_doc_id : unique_key,
            std:this.state.manualtabkey,
        }
        datasave.service(window.archived,'POST',data)
        .then(response=>{
            if(response==="Success") {
               // this.props.addtoArchived()
                let userData = store.getState();
                var url = window.FETCH_MANUAL_SANDBOX + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id +'&sandbox='+this.state.sandbox+'&web_id='+this.state.web_id+'&url='+window.backendURL+'&std='+this.state.manualtabkey;
                axios.get(process.env.REACT_APP_serverURL + url)
                .then(result => {
                        this.setState({
                            folderDetails: result.data.folderdata,
                        })
                        this.updateTodoCount()
                        this.displayFolder(result.data.folderdata)
                });
            }

        })
    }
    handlcancel() {
    }


    Preview(id, parent_type, action, addtype, manual_id, label = '', code = '') {
      console.log(id);
      let userData = store.getState();
      let mainsiteurl = userData.UserData.mainsiteurl
      axios.get(process.env.REACT_APP_serverURL+window.GET_META_DATA + '/' + id)
        .then(result => {
          console.log(result);
          console.log(result.data);
            if (result.data.docpath[0].doc_type_id <= 3) {
                window.open(window.location.origin + '/previewrevisionentities/' +1+'/'+ id+'/'+this.state.manualtabkey, '_blank');
            }
            else{
                window.open(window.location.origin+'/previewrevisionentities/' +1+'/'+ id+'/'+'general','_blank');
              }
            }
        );
    }



    getNodes () {

    }
    handleManualStandard (key) {
      this.setState({
        manualtabkey : key
      })
      let userData = store.getState();
      var url = window.FETCH_MANUAL_SANDBOX + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id +'&sandbox='+this.state.sandbox+'&web_id='+this.state.web_id+'&url='+window.backendURL+'&std='+key;
      axios.get(process.env.REACT_APP_serverURL + url)
      .then(result => {
              this.setState({
                  folderDetails: result.data.folderdata,
              })
              this.updateTodoCount()
              this.displayFolder(result.data.folderdata)
      });
    }
    // onclick(unique_key){
    //     console.log(this.state.folderDetails)
    //     this.setState({
    //         unique_key : unique_key,
    //     })
    // }
    eventLogger = (e: MouseEvent, data: Object) => {
       console.log('Event: ', e);
       console.log('Data: ', data);
     };

    render () {
        // const data = {
        //     unique_key : this.state.unique_key,
        //     folderdate : this.state.folderDetails
        // }
        const DEFAULT_PADDING = 5;
        const ICON_SIZE = 8;
        const LEVEL_SPACE = 16;
        const WIDTH = '25px';
        const HEIGHT = '25px';
        const DISPLAY = 'inline-flex';
        const WIDTH_DYNAMIC = '20' ;
        const {t} = this.state;
        const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }}>{on ? '-' : '+'}</span>;
        const ListItem = ({
            level = 0,
            key,
            doc_type,
            status,
            rights,
            sandbox_rights,
            owner,
            hasNodes,
            isOpen,
            type_id,
            current_type,
            manual_id,
            label,
            version,
            searchTerm,
            openNodes,
            unique_key,
            ...props
        })=> (
            <div className="folder-manual-section">
                <SandboxCan
                   perform={sandbox_rights}
                   type="view"
                   yes={() => (
                        <ListGroupItem
                            className="left-border"
                            {...props}
                            style={{
                                paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
                                cursor: 'pointer',
                            }}
                            key={key}
                            // onMouseEnter={this.getButton.bind(key, props, props)}
                            // onMouseLeave={this.removeButton}
                        >
                            <div className="list-items-structure" style = {{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
                                {hasNodes && <ToggleIcon on={isOpen} />}
                                {!hasNodes && <span style={{ marginRight: 8 }}> &nbsp;</span>}

                                {current_type !== 'document' &&
                                    // <img src={folderlogo} style={{ width: WIDTH, paddingLeft: 5, paddingRight: 5, height: HEIGHT }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id)} />
                                    <i class="folder-icons folder-icons-folder" title="Folder"  style={{ marginRight: '5px' }} > </i>

                                }

                                {current_type === 'document' &&
                                    <i class={'folder-icons folder-icons-' + doc_type} title={doc_type} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} />
                                }
                                {/* {current_type === 'document' &&
                                    <i class={'sprite-document2 sprite-document2-Activate_or_Published'} title='Activated' style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} />
                                } */}
                                {current_type === 'folder' &&
                                    <>
                                        <span className='folderstructure-label sandbox-label'>
                                            <Draggable  isDragDisabled ={(sandbox_rights.includes(window.SandboxVIEW_ID)) ? (sandbox_rights.includes(window.SandboxUPDATE_IDS) ? false : true) : true} className='folderstructure-label'  type="document" data={[unique_key,this.state.manualtabkey]}>
                                            {label}
                                            </Draggable>
                                        </span>
                                    </>
                                }
                                {current_type === 'document' &&
                                    <span className='folderstructure-label sandbox-label'>
                                        <Draggable isDragDisabled ={(sandbox_rights.includes(window.SandboxVIEW_ID)) ? (sandbox_rights.includes(window.SandboxUPDATE_IDS) ? false : true) : true} className='folderstructure-label'  type={"document"} data={[unique_key,this.state.manualtabkey]}>
                                        {label}
                                        </Draggable>

                                    </span>
                                }
                                {current_type !== 'document' && current_type !== 'folder' &&
                                    <span className='folderstructure-label sandbox-label'>
                                    <span> {label} </span>
                                    </span>
                                }
                                {current_type === 'document' &&
                                            <span className="version-wrapper">
                                                V-{version}
                                            </span>
                                        }

                                {current_type === 'document' &&
                                <div className="one version-folder-wrapper-sandbox">
                                    {/* <i class="overall-sprite overall-sprite-mseditc"   alt="Logo" title="preview" style={{display: 'inline-flex', marginLeft: '3px', marginRight: '3px' }} onClick={this.Preview.bind(this, props.key_type, current_type, 'create', 'document', manual_id)}></i>
                                    <i class="overall-sprite overall-sprite-msfolderc"   alt="Logo" title="archived" style={{display: 'inline-flex', marginLeft: '3px', marginRight: '3px' }} onClick={this.archived.bind(this, unique_key)}></i> */}

                                  <Can
                                      perform="Preview_doc_in_sandbox"
                                      yes={() => (
                                        <i class="sandbox-sprite sandbox-sprite-Preview"   alt="Logo" title="Preview" style={{ display: 'inline-flex', marginLeft: '3px', marginRight: '3px' ,alignSelf: 'center' }} onClick={this.Preview.bind(this, props.key_type, current_type, 'create', 'document', manual_id)}></i>
                                      )}
                                  />
                                  <Can
                                      perform="Archive_doc_in_sandbox"
                                      yes={() => (
                                        <i class="sandbox-sprite sandbox-sprite-Archive"   alt="Logo" title="Archived" style={{ display: 'inline-flex', marginLeft: '3px', marginRight: '3px'  }} onClick={this.archived.bind(this, unique_key)}></i>
                                      )}
                                  />
                                  <Can
                                      perform="Archive_doc_in_sandbox"
                                      yes={() => (
                                        <i class="sandbox-sprite sandbox-sprite-Archive"   alt="Mark as implemented in system" title="Mark as implemented in system" style={{ display: 'inline-flex', marginLeft: '3px', marginRight: '3px'  }} onClick={this.markasimplemented.bind(this, unique_key)}></i>
                                      )}
                                  />

                                </div>

                                }
                                {current_type !== 'document' &&
                                    <Can
                                        perform="E_folder"
                                        yes={() => (
                                            <SandboxCan
                                                perform={sandbox_rights}
                                                type="curd"
                                                // yes={() => (
                                                //     // <img src={addfolder} alt="Logo" title="Add Folder" style={{ height: HEIGHT, width: WIDTH, paddingLeft: 5, paddingRight: 5 }} onClick={this.actionHeader.bind(this, props.key_type, current_type, 'create', 'folder', manual_id)} />
                                                //     // <i class="overall-sprite overall-sprite-msfolderc"   alt="Logo" title="Add Folder" style={{ marginLeft: '10px', marginTop: '5px' }} onClick={this.actionHeader.bind(this, props.key_type, current_type, 'create', 'folder', manual_id)}></i>
                                                // )}
                                            />
                                        )}
                                    />
                                }
                                {current_type === 'folder' &&
                                    <Can
                                        perform="E_folder"
                                        yes={() => (
                                            <SandboxCan
                                                perform={sandbox_rights}
                                                type="curd"
                                                // yes={() => (
                                                //     // <img src={adddocument} alt="Logo" title="Add Document" style={{ height: HEIGHT, width: WIDTH, paddingLeft: 5, paddingRight: 5 }} onClick={this.actionHeader.bind(this, props.key_type, current_type, 'create', 'document', manual_id)} />
                                                //     <i class="overall-sprite overall-sprite-msdocumentc" alt="Logo" title="Add Document" style={{marginTop: '5px'}} onClick={this.actionHeader.bind(this, props.key_type, current_type, 'create', 'document', manual_id)}></i>
                                                //     )}
                                            />
                                        )}
                                    />
                                }

                                {/* {this.state.showDocHeader === props.key_type && */}
                                    {/* <DocumentHeader propsData={label} id={props.key_type} current_type={current_type} addtype={type_id} manual_id={manual_id} actionEdit={this.actionEdit} memoId={this.memoId} actionHeader={this.actionHeader} rights={rights} owner={owner} /> */}
                                {/* } */}
                            </div>
                        </ListGroupItem>
                    )}
                  />
            </div>
        );
        return(
            <div className='container py-0 px-0 sanbox-container'>
                <div className='row justify-content-center'>
                    <div className='col-md-12' >
                      <reactbootstrap.Tabs
                       id="controlled-tab-example" className="header_tabs"
                       activeKey={this.state.manualtabkey}
                       onSelect={this.handleManualStandard.bind(this)}
                      >
                       
                      {Object.values(this.state.manualStandards).map(function(values,key) {
                        return(
                          <reactbootstrap.Tab eventKey = {values.id} title={values.name}>

                            <TreeMenu
                                data={this.state.blanco_data}
                                hasSearch='false'
                                onClickItem={({ key, label, ...props }) => {
                                    this.onClickNode(key, label, props);
                                }}
                                onDoubleClickItem={({ key, label, ...props }) => {
                                    this.onClickNode(key, label, props);
                                }}
                                debounceTime={125}
                                activeKey={this.state.activeOpenNode}
                                openNodes={this.state.openNodeManuals}
                            >
                                {({ search, items }) => (
                                    <>

                                        <Input style={{}} onChange={e => search(e.target.value)} placeholder={t("Type and search")} />
                                        <div class="sandbox-todo-count">
                                        {t('Todo count: ')} {' '+this.state.count}
                                        </div>
                                        <div className="sim">
                                            <Can
                                                perform="R_sandbox,E_sandbox"
                                                yes={() => (

                                                    <ListGroup className="folder-left-list-group">

                                                        {items.map(props => (
                                                            <ListItem {...props} />
                                                        ))}


                                                    </ListGroup>

                                                )}

                                            />
                                            <div style={{ height: '170px', visibility: 'hidden', }}></div>

                                        </div>
                                    </>
                                )}
                            </TreeMenu>
                            </reactbootstrap.Tab>
                          )}, this)}
                          </reactbootstrap.Tabs>

                      </div>

                </div>
            </div>
        )
    }
}
export default translate(Todos)
