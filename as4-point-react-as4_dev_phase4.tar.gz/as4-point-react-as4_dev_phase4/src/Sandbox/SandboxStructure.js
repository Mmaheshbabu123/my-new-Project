import React, { Component } from 'react';
import { translate } from '../language';
import * as reactbootstrap from 'react-bootstrap';
import Sandboxtab from './Sandbox';
import { persistor, store } from '../store';
import { datasave } from '../_services/db_services';
import Sandboxsettings from './Sandboxsettings';
import Can from '../_components/CanComponent/Can';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';
import './Sandbox.css';

// import Sandboxtab from './sandboxtabs';

class Sandbox extends Component {
    constructor(props) {
        super(props)
        this.state = {
          t:props.t,
          active_tab: 1,
          sandbox: this.props.sandbox,

        }
    }
    componentDidMount(){
      let userData = store.getState();
      let mainsiteurl = userData.UserData.mainsiteurl
      console.log(mainsiteurl);
      console.log(window.location.origin);
    }

    componentDidUpdate(prevProps, prevState) {

    }
    render=()=>{
        const {t} = this.state;
        const sandbox_setting_rights = CanPermissions("R_sandbox,E_sandbox", "");
        let sandbox_setting_access = (sandbox_setting_rights) ? '' : 'disabled';

        return(
            <div className='container py-0 px-0 sanbox-container-main'>
                <div className='row justify-content-center' >
                    <div className='col-md-12' >
                    <reactbootstrap.Tabs activeKey={this.state.active_tab} onSelect={active_tab => this.setState({ active_tab })} id="controlled-tab-example">
                        <reactbootstrap.Tab eventKey={1} title={t("Sandbox")}>
                            <Sandboxtab blanco_id = {this.props.blanco_id} manual_id={this.props.manual_id} droppable_status={this.props.droppable_status} change_droppable_status={this.props.change_droppable_status} updatecount={this.props.updatecount}/>
                            {/* <reactbootstrap.Tabs activeKey={this.state.active_tab} onSelect={active_tab => this.setState({ active_tab })} id="controlled-tab-example">
                                <reactbootstrap.Tab eventKey={1} title="Filter on doc code, name,# days open">
                                </reactbootstrap.Tab>
                            </reactbootstrap.Tabs> */}
                        </reactbootstrap.Tab>
                        <reactbootstrap.Tab disabled = {sandbox_setting_access} eventKey={2} title={t("Sandbox settings")}>
                            <Sandboxsettings/>
                        </reactbootstrap.Tab>
                    </reactbootstrap.Tabs>
                    </div>
                </div>
            </div>


        );
    }
}
export default translate(Sandbox)
