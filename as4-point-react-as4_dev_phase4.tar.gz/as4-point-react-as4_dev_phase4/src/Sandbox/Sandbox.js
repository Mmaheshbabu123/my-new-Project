import React, { Component } from 'react';
import { translate } from '../language';
import * as reactbootstrap from 'react-bootstrap';
import _ from "lodash";
import Archived from './Archived';
import Todos from './Todos';
import Implemented from './Implemented';
import { datasave } from '../_services/db_services';
import './Sandbox.css';


class Sandbox extends Component {
    constructor(props) {
        super(props);
        this.state = {
            t:props.t,
            active_tab: 1,
            disabled : false,
            archived_status : false,
            folderdata : '',
            todo_to_archive_status :false,
            blancoList : []
        }
    }
    componentDidMount() {
      datasave.service(window.SITE_MANUALS, 'GET')
        .then(result => {
          console.log(result);
          this.setState({
            blancoList: result
          })
        });
    }
    fetchManualslist(list){
        if(list === false) {
            this.setState({
                archived_status : false,
            })
        }
        this.setState({
            archived_status : true,
            // folderdata : list
        })
    }
    addtoArchived(state) {
        if (state === false) {
            this.setState ({
                todo_to_archive_status : state
            })
        }
        else{
            this.setState({
                todo_to_archive_status : true
            })
        }

    }
    handleManualStandard (key) {
      this.setState({
        manualid : key
      })
    }

    render () {
      const {t} = this.state;
        return(
            <div className='container py-0 px-0 sanbox-container'>
                <div className='row justify-content-center'>
                    <div className='col-md-12' >
                        <reactbootstrap.Tabs activeKey={this.state.active_tab} onSelect={active_tab => this.setState({ active_tab })} id="controlled-tab-example">
                            <reactbootstrap.Tab eventKey={1} title={t("To do")}>
                              < reactbootstrap.Tabs id="controlled-tab-example" className="header_tabs" activeKey={this.state.manualid} onSelect={this.handleManualStandard.bind(this)}>
                              {Object.values(this.state.blancoList).map(function(values,key) {
                                return(
                                  <reactbootstrap.Tab eventKey = {values.value} title={values.label}>
                                    <Todos blanco_id = {this.props.blanco_id} manual_id={values.value} droppable_status={this.props.droppable_status} archived_status={this.state.archived_status} addtoArchived = {this.addtoArchived.bind(this)} fetchManualslist = {this.fetchManualslist.bind(this)} change_droppable_status={this.props.change_droppable_status} updatecount={this.props.updatecount}/>
                                  </reactbootstrap.Tab>
                                )}, this)}
                              </reactbootstrap.Tabs>
                            </reactbootstrap.Tab>
                            <reactbootstrap.Tab eventKey={2} title={t("Implemented in system")}>
                            <Implemented droppable_status={this.props.droppable_status} manual_id={this.props.manual_id}/>
                            </reactbootstrap.Tab>
                            <reactbootstrap.Tab eventKey={3} title={t("Archived")}>
                                <Archived fetchManualslist = {this.fetchManualslist.bind(this)} manual_id={this.props.manual_id} status ={this.state.todo_to_archive_status} addtoArchived = {this.addtoArchived.bind(this)}/>
                            </reactbootstrap.Tab>
                        </reactbootstrap.Tabs>
                    </div>
                </div>
            </div>
        )
    }
}
export default translate(Sandbox)
