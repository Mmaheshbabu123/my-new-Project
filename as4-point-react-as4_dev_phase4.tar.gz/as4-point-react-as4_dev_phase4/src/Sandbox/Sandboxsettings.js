import React, { Component } from 'react';
import { datasave } from '../_services/db_services';
import DragnDrop from './dragndrop';
import { filterArray } from '../_helpers/filter-array';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import { persistor, store } from '../store';
import Can from '../_components/CanComponent/Can';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { translate } from '../language';
// import { exists } from 'fs';
// import Can from '../CanComponent/Can';
// import {CanPermissions} from '../CanComponent/CanPermissions';

class Sandboxsettings extends Component {
  constructor(props) {
    super(props)
    this.handleActiveTab = this.handleActiveTab.bind(this);
    this.updateSelected = this.updateSelected.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleSubmitsandbox = this.handleSubmitsandbox.bind(this);
    this.state = {
      tasks: [],
      items: [],
      types: ["persons", "departments", "jobs"],
      selected: [],
      disableFields: false,
      update: 1,
      selected: [],
      status : false,
      active:false,
      t:props.t
    }
  }
  async componentDidMount() {
    var url = window.GET_ALL_SANDBOX_DETAILS

    datasave.service(url, "GET")
      .then(result => {
        this.setState({
          tasks: result.jgd,
          items: result.jgd,
          // types: result.types,
          // selected: [],
          active: true
        })
      });
    // if(this.state.active === true) {
    datasave.service(window.GET_SANDBOX_PERMISSIONS, 'GET')
      .then(result => {
        this.setState({
          selected: Object.values(result)
        })
      })
    // }


  }

  handleActiveTab(key) {
    this.setState({
      active_tab: key,
    });
  }
  updateSelected = (latestDropped, result, type, id = '') => {
    var array = [...this.state['selected']]; // make a separate copy of the array
    if (result.type === 'remove') {
      var filterArray = array.filter(selected => (selected.id !== latestDropped.id));
    }
    if (result.type === 'remove') {
      this.setState({
        selected: filterArray,
      })
    }

    else {
      this.setState(prevState => ({
        selected: [...prevState['selected'], latestDropped]
      }));
    }
  }
  updateSelectedRights = (latestList) => {
    this.setState({
      selected: latestList,
    })
  }
  handleCancel(event) {
    this.setState({
      status: true,
      selected: []
    })
    datasave.service(window.GET_SANDBOX_PERMISSIONS, 'GET')
      .then(result => {
        this.setState({
          selected: Object.values(result)
        })
    })
  }
  handleSubmitsandbox(event) {
    event.preventDefault()
    const details = {
      "all_list": this.state.selected
    }
    datasave.service(window.SAVE_SANDBOX_DETAILS, "POST", details)
      .then(result => {


      })

  }

  render() {
    const {t} = this.state;
    var pack_func = this.state.tasks;
    const allowDrag = CanPermissions("E_sandbox", "") ? false : true;
    // const linkTabs = function(){
    if (this.state.selected.length > 0) {
      pack_func = filterArray(this.state.tasks, this.state.selected)
    }
    return (
      <Can
        perform="R_sandbox,E_sandbox"
        yes={() => (
          <div>
            <DragnDrop
              types={this.state.types}
              details={this.props.details}
              tasks={pack_func}
              active_tab={this.state.active_tab}
              type={window.tabs.rights}
              details={this.state.disableFields}
              selected={this.state.selected}
              {...this}
              updateSelectedRights={this.updateSelectedRights}
              updateSelectedChild={this.updateSelected}
              activeKey={this.state.active_tab}
              onSelect={this.state.handleActiveTab}
              tab={window.tabs.approval_cycle}
              type="sandbox"
              updateProps={1}
              credentials={this.props.credentials}
              dragDisable={allowDrag}
            // disable_based_on_right = {disable_based_on_right}
            />
            <div className='row justify-content-center' >
              <div className='col-md-12' >
                {/* <div className='card' > */}
                {/* <div className='card-header' > Create job </div> */}
                <div className='card-body float-right' >
                  <Container className="">
                  <div style={{ float: 'right' }} className="organisation_list">
                  <a onClick={this.handleCancel} > {t('Cancel')} </a>
                  &nbsp;&nbsp;&nbsp;
                      <Button type="submit" className="btn btn-primary" onClick={this.handleSubmitsandbox}>{t('Save')}</Button>
                    </div>
                  </Container>
                </div>
                {/* </div> */}
              </div>
            </div>
          </div>
        )}
        no={() =>
          <AccessDeniedPage />
        }
      />
    );
    // }
    // else {
    //   return (
    //     <div> ....loading </div>
    //   );
    // }
  }

}
export default translate(Sandboxsettings);
