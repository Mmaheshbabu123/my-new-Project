import React, { Component } from 'react'
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd'
import * as reactbootstarp from 'react-bootstrap'
import SearchInput, { createFilter } from 'react-search-input'
import { datasave } from '../_services/db_services';
import CheckBox from '../CheckBox';
import TextField from '../_components/TextField'
import PersonImg from '../images/personc.png';
import JobImg from '../images/jobc.png';
import DepartmentImg from '../images/departmentsc.png';
import GroupImg from '../images/groupc.png';
import DeleteImg from '../images/delete1.png';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';
import { translate } from '../language';
import '../DragnDrop.css';
// import wname from './wname.png';
// import wview from './wview.png';
// import wverify from './wverify.png';
// import wremove from './wremove.png';
// import winitiate from './winitiate.png';
// import wcrud from './wcrud.png';
// import wauthorise from './wauthorise.png';



/**
 * Moves an item from one list to another list.
 */
const move = (source, destination, droppableSource, droppableDestination, draggableId) => {

    const sourceClone = Array.from(source);
    const destClone = Array.from(destination);
    const [removed] = sourceClone.filter(items => items.id === draggableId);
    destClone.splice(destination.length, 0, removed);
    const result = {};
    result[droppableSource.droppableId] = sourceClone.filter(items => items.id !== draggableId);
    result[droppableDestination.droppableId] = destClone;
    result['latestDropped'] = removed;
    result['type'] = (droppableDestination.droppableId === 'droppable') ? 'remove' : 'add';
    return result;
};

const grid = 8;
/*const getItemStyle = (isDragging, draggableStyle) => ({
    // some basic styles to make the items look a bit nicer
    userSelect: 'none',
    padding: grid * 2,
    margin: `0 0 ${grid}px 0`,

    // change background colour if dragging
    background: isDragging ? 'lightgreen' : 'grey',

    // styles we need to apply on draggables
    ...draggableStyle
});*/

const commonTdStyle = ({
  backgroundColor: '#fff',
  color: '#212529',
  border: '1px solid #fff',
  fontSize: '14px',
  paddingLeft: '32px',
  verticalAlign: 'middle',
  zIndex:'0px'
});

const getListStyle = isDraggingOver => ({
    background: isDraggingOver ? 'lightblue' : '#fff',
    padding: grid,
    width: 750
});

const getFlexStyle = ({
    display: 'flex',
    backgroundColor: '#fff',//added
});

const imageStyle = ({
    width: 20,
    cursor: "default",
});
const TextCurser = ({
    cursor: "default",
});

const textinline = ({
    display: '-webkit-inline-flex',
});

/*const tooltipStyle = ({
    height: 150,
    width: 200,
    overflow: 'auto'
});*/

class DragnDropsettings extends Component {

    constructor(props) {

        super(props);
        this.searchUpdated = this.searchUpdated.bind(this)

        this.state = {
            KEYS_TO_FILTERS: window.search_fields,
            items: [],
            selected: [],
            types: [],
            searchData: [],
            searchTerm: [],
            searchType: '',
            type: '',
            html: window.HTML_OBJECT,
            html_right: window.HTML_RIGHT,
            updated: 1,
            persons: [],
            curently_hovered_item: [],
            show: false,
            isTooltipActive: false,
            parent: "tooltip",
            checkboxes:[],
            status:false,
            t:props.t,
        }
        this.handleCheck = this.handleCheck.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleChangeOrder = this.handleChangeOrder.bind(this);
        this.handleClicktr = this.handleClicktr.bind(this);
        this.handlePersons = this.handlePersons.bind(this);
        // this.showTooltip = this.showTooltip.bind(this);
        // this.hideTooltip = this.hideTooltip.bind(this);


    }

    handleClicktr(resultObj) {
        if (this.props.details.disableFields || this.props.dragDisable) {
            return;
        }
        var selected = this.state.selected;
        var remove = selected.filter(item => (item.name !== resultObj.name && item.id !== resultObj.id));
        const result = {};
        result['latestDropped'] = resultObj;
        result['type'] = 'remove';
        this.setState(prevState => ({
            items: [...prevState.items, resultObj],
            selected: remove,
        }), () => {
            this.props.updateSelectedChild(result.latestDropped, result, this.props.tab, this.props.notify_id);
        });
    }

    async componentDidMount() {
        if (this.props.items !== undefined) {
            this.setState({
                types: this.props.types,
                items: this.props.items,
                selected: this.props.selected,
                type: this.props.type,
            });
        }
    }

    /**
     * A semi-generic way to handle multiple lists. Matches
     * the IDs of the droppable container to the names of the
     * source arrays stored in the state.
     */
    id2List = {
        droppable: 'items',
        droppable2: 'selected'
    };

    handleDragSelectedChange = (result) => {
        this.setState({
            items: result.droppable,
            selected: result.droppable2
        }, () => {

            this.props.updateSelectedChild(result.latestDropped, result, this.props.tab, this.props.notify_id);
        });
    }
    getList = id => this.state[this.id2List[id]];

    onDragEnd = resultObj => {
        const { source, destination, draggableId } = resultObj;
        // dropped outside the list
        if (!destination) {
            return;
        }
        if (source.droppableId === destination.droppableId) {
            return;
            /*const items = reorder(
                this.getList(source.droppableId),
                source.index,
                destination.index
            );

            let state = { items };

            if (source.droppableId === 'droppable2') {
                state = { selected: items };
            }

            this.setState(state);*/
        } else {
            const result = move(
                this.getList(source.droppableId),
                this.getList(destination.droppableId),
                source,
                destination,
                draggableId
            );
            this.handleDragSelectedChange(result);
        }
    };
    searchUpdated(term, itemlist) {
        const items = { ...this.state.searchTerm };
        items[itemlist] = term;
        this.setState({
            searchTerm: items,
            searchType: itemlist,
        })
    }
    handleCheck = (id, checked, category) => {
        this.handleUpdateState(id, checked, "checkboxes", "checked", category, "flag")
    }
    handleUpdateState(id, value, type, action, pid, flag) {
        let selected = this.state.selected;
        this.state.selected.map((functions,key) => {
            Object.values(functions[type]).map(function (item, index) {
                if (item.id === id && functions.id === pid) {
                    item[action] = value;
                    item[flag] = 1;
                    return;
                }
            })
        });
        this.setState({
            selected : selected,
        }, () => {
            this.props.updateSelectedRights(this.state.selected);

        })
    }
    handleChange(id, value, type_id, type) {
        const re = /^(?:[0-9]*)$/;
        if (value === '' || re.test(value)) {
            this.handleUpdateState(id, value, "textfield", type, type_id, "flag");
        }
    }
    handleChangeOrder(id, value, type_id, type) {
        const re = /^(?:[0-9])$/;
        if (value === '' || re.test(value)) {
            this.handleUpdateState(id, value, "textfield", type, type_id, "flag");
        }
    }
    handlePersons(item) {

        if (item.category_id != window.PERSON_ENTITY) {
            this.setState({ show: true });
            if (this.state.persons[item.id]) {
                this.setState({
                    curently_hovered_item: this.state.persons[item.id]
                })
            }
            else {
                const loaded_persons = this.state.persons;

                const url = window.GetAllLinkedPersons + '/' + item.id + '/' + item.entity_type_id
                datasave.service(url, "GET", '')
                    .then(result => {
                        const all_persons = {
                            ...loaded_persons,
                            ...result
                        }
                        this.setState({
                            persons: all_persons,
                            curently_hovered_item: result[item.id]
                        })
                    })
                    .catch(error => {

                    })
            }
        }

    }
    handleHide = () => {
        this.setState({ show: false });
    }
    componentDidUpdate(prevProps, prevState) {

        if (prevState.items !== this.props.tasks) {
            this.setState({
                items: this.props.tasks,
            })
        }
    }

    // Normally you would want to split things out into separate components.
    // But in this example everything is just done in one place for simplicity
    render() {
      const {t}=this.state;
        let checkbox = Object.values(this.state.checkboxes);
        var Tab_selected;
        const disableDrag = this.props.dragDisable;
        const disableEdit = CanPermissions("E_sandbox", "") ? '' : 'diabled';

        const popupContent = (
            <reactbootstarp.Modal
                show={this.state.show}
                onHide={this.handleHide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title"
            >
                <reactbootstarp.Modal.Header closeButton>
                    <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
                        {t("Persons")}
                </reactbootstarp.Modal.Title>
                    <reactbootstarp.Modal.Body>
                        <ul>
                            {this.state.curently_hovered_item.length != 0 &&
                                this.state.curently_hovered_item.map(person =>
                                    <li>{person.name}</li>
                                )
                            }
                            {this.state.curently_hovered_item.length === 0 &&
                                t('No persons are linked')
                            }
                        </ul>
                    </reactbootstarp.Modal.Body>
                </reactbootstarp.Modal.Header>
            </reactbootstarp.Modal>
        );
        if (this.props.types !== undefined && this.state.items !== undefined) {
            // const type = this.props.type;
            const types = this.props.types;
            /*if ((this.props.tasks !== undefined && this.props.tasks.length > 0) && this.state.items.length === 0) {
                this.setState({
                    items: this.props.tasks
                });
            }*/
            if (this.props.selected !== undefined && this.props.selected.length === 0 && this.props.updateProps === 1 && this.state.updated > 0) {
                this.setState({
                    selected: this.props.selected,
                    updated: 0,
                });
            }
            else if (this.props.selected !== undefined && this.props.selected.length > 0 && this.props.updateProps === 1 && this.state.selected.length === 0) {
                this.setState({
                    selected: this.props.selected,
                    updated: 2,
                });
            }
            if (this.props.selected.length>=0) {
                Tab_selected=this.props.selected
            }
            var filteredNames = [];
            var dragObject = <reactbootstarp.Tabs activeKey={this.props.activeKey} onSelect={this.props.onSelect} id="controlled-tab-example">
                {Object.values(types).map(
                    function (itemlist, key) {
                        var search = '';
                        if (this.state.searchTerm && this.state.searchType) {
                            search = this.state.searchTerm[itemlist];
                            search = (search !== undefined) ? search : '';
                        }
                        filteredNames[itemlist] = this.state.items.filter(createFilter(search, this.state.KEYS_TO_FILTERS));
                        return (
                            <reactbootstarp.Tab className="input-right-field" id="dashdragndrop" eventKey={itemlist} title={t(itemlist.charAt(0).toUpperCase() + itemlist.slice(1))}>
                                <reactbootstarp.Table responsive  striped hover >
                                    <thead style={{position: 'sticky',top: '0',backgroundColor: '#fff'}}>
                                        <tr>
                                            <td style={{padding: '0.25rem'}} colSpan="3">
                                                <SearchInput style={{colour: 'red', border: '0px', color: '#EC661C', fontSize: '13px', }} className="search-input" onChange={(e) => this.searchUpdated(e, itemlist)} />
                                            </td>
                                        </tr>
                                        <tr>
                                            {this.state.html_right[0][itemlist].map(rights =>
                                                <th style={{backgroundColor: '#EC661C', fontSize: '14px', color: '#fff', padding: '0.25rem' }} title={t(rights.name)}>{rights.name}</th>
                                            )}
                                        </tr>
                                    </thead>
                                    <tbody style={{backgroundColor: '#fff', border: '0px'}}>
                                        {Object.values(filteredNames[itemlist]).map(

                                            function (item, index) {
                                                item.category_id = (item.entity_type_id !== undefined) ? item.entity_type_id : item.category_id;
                                                if (item !== undefined && item.id !== undefined && item.category === itemlist) {
                                                    return (
                                                        <Draggable
                                                            isDragDisabled={this.props.details.disableFields || disableDrag}
                                                            key={item.id}
                                                            draggableId={item.id}
                                                            type={item.category}
                                                            index={index}>
                                                            {(provided, snapshot) => (
                                                                <tr
                                                                    ref={provided.innerRef}
                                                                    {...provided.draggableProps}
                                                                    {...provided.dragHandleProps}
                                                                >
                                                                    <td style={{border: 'none',borderTop: '1px solid #dee2e6'}}>
                                                                        <div style={textinline} onClick={(e) => this.handlePersons(item)}>
                                                                            <div>
                                                                                {/* <p onClick={(e) => this.handlePersons(item)}> */}
                                                                                    {item.category != 'spaces' &&
                                                                                    <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                                                                }
                                                                                    &nbsp;
                                                                                {/* </p> */}
                                                                            </div>
                                                                            &nbsp;
                                                                            <div>
                                                                                {item.name}
                                                                            </div>
                                                                        </div>
                                                                        {popupContent}
                                                                        {/* { item.category != 'spaces' &&
                                                                            <img style = {imageStyle} src={ item.category === 'persons' ? PersonImg : (item.category ==='jobs'? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" onClick={(e) => this.handlePersons(item)} />
                                                                        }
                                                                        {popupContent}
                                                                        &nbsp; &nbsp;
                                                                        {item.name} */}
                                                                    </td>
                                                                    {item.category != 'persons' &&
                                                                        <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6', textAlign:'center',wordBreak: 'break-word'}}>
                                                                            {item.abbrevation}
                                                                        </td>
                                                                    }
                                                                </tr>
                                                            )}
                                                        </Draggable>
                                                    )
                                                }

                                            }, this)}
                                    </tbody>
                                </reactbootstarp.Table>
                            </reactbootstarp.Tab>
                        )
                    }, this)}
            </reactbootstarp.Tabs>
        }
        return (
            <div className="col-md-12 p-0"  style={getFlexStyle}>
                <DragDropContext onDragEnd={this.onDragEnd}>
                    <Droppable droppableId="droppable2">
                        {(provided, snapshot) => (
                            <div className="selected-item-header-section"
                                ref={provided.innerRef}
                                style={getListStyle(snapshot.isDraggingOver)}>
                                <p>Selected items</p>
                                <div className='border-remove' style={{ width: '100%', overflowX: 'auto',  }}>
                                <reactbootstarp.Table style={{ width: '100%', overflowX: 'auto', margin: '0' }} striped bordered responsive hover variant="dark">
                                <thead  style={{ backgroundColor: '#EC661C',position: 'sticky',top: '0' }}>
                                        <tr >
                                            {this.state.html[0][this.props.type].map(commons =>
                                                <th style={{ paddingTop: '20px', border: '0px' }}  className ={commons.class} title={t(commons.name)}></th>
                                            )}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {/* { this.props.itemlist === window.MEMBER_OF &&
                                            {
                                                Tab_selected = this.state.selected.filter(items => (items.category_id === window.job_memberof_one || items.category_id === window.job_memberof_two))
                                            }
                                        }
                                        { this.props.itemlist === window.MEMBER &&
                                            {
                                                Tab_selected = this.state.selected.filter(items => (items.category_id === window.job_member_one))
                                            }
                                        }
                                                */}
                                        {Tab_selected !== undefined && Tab_selected.map(
                                            function (item, index) {
                                                if (this.props.type === "sandbox") {
                                                    return (
                                                        <tr style={commonTdStyle}>
                                                            <td style={{borderColor: '#aca6a6'}}>
                                                                <div style={textinline} onClick={(e) => this.handlePersons(item)}>
                                                                    <div>
                                                                        {item.category !== 'spaces' &&
                                                                            <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                                                        }
                                                                    </div>
                                                                    &nbsp;
                                                                    <div style={TextCurser}>
                                                                        <span style={{cursor: 'default', wordBreak: 'break-word',width: '5rem'}}>{item.name}</span>
                                                                    </div>
                                                                </div>
                                                                {popupContent}
                                                            </td>
                                                            {item.checkboxes.map(function (check) {
                                                                return (
                                                                    <td style={{ verticalAlign: 'middle' }}>
                                                                        <CheckBox
                                                                            key={check.id}
                                                                            name={''}
                                                                            value={check.id}
                                                                            disabled={disableEdit}
                                                                            tick={check.checked}
                                                                            classification={check.name}
                                                                            onCheck={(e) => this.handleCheck(check.id, e.target.checked, item.id)}
                                                                            keyvalue={check.id}
                                                                        />
                                                                    </td>
                                                                )
                                                            }, this)}
                                                            <td style={{textAlign: 'center'}} disabled={this.props.details.disableFields}>
                                                                <img style={imageStyle} src={DeleteImg} disabled={disableEdit} alt="delete" onClick={(e) => this.handleClicktr(item)}></img>
                                                            </td>
                                                        </tr>
                                                    )
                                                }
                                            }, this)}
                                        {provided.placeholder}
                                    </tbody>
                                </reactbootstarp.Table>
                            </div>
                            </div>
                        )}
                    </Droppable>
                    <Droppable droppableId="droppable">
                        {(provided, snapshot) => (
                            <div className="avialble-filed-person "
                                ref={provided.innerRef}
                                style={getListStyle(snapshot.isDraggingOver)}
                            >
                                <p>{t("Available items")}</p>
                                {provided.placeholder}
                                {dragObject}
                            </div>

                        )}
                    </Droppable>
                </DragDropContext>
            </div>
        );
    }
}
export default translate(DragnDropsettings);
