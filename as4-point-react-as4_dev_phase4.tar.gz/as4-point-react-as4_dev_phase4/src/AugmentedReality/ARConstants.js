window.AR_API = '/arapi';

window.GET_AR_IMAGE_OVERVIEW_DATA = '/arapi/getArImageOverviewData';
window.STORE_AR_IMAGE_DATA = '/arapi/storeArImageData';
window.INSERT_AR_IMAGE_PIN_LINKING_DATA = '/arapi/insertARimageLinkingData';
window.UPDATE_INSERT_AR_IMAGE_RETAKE_PROCESS = '/arapi/upDateInsertARimageRetakeProcess';
window.DELETE_AR_IMAGE_DATA_BY_ID = '/arapi/deleteArImageOverallDataById';
window.UPDATE_AR_IMAGE_NAME_BY_ID = '/arapi/updateArImageNameById';
window.UPDATE_AR_IMAGE_GP_LINKING_BY_OVERVIEW_ID = '/arapi/updateArImageGpLinkingByOverview';
window.CLONE_IMAGE_DATA_BY_ID_AND_GET_ID = '/arapi/cloneImageDataByIdAndGetId';
window.ADD_CROPPED_IMAGE_ITEM = '/arapi/addCropedImageItem';
window.AR_GROUNDPLAN_DATA = '/arapi/ar_groundplan_data';
window.AR_GROUNDPLAN_ZONE_DATA = '/arapi/getGroundPlanDataForZone';

window.AR_CREATE_UPDATE_ZONES = '/arapi/createUpdateZones';
window.AR_DELETE_ZONES = '/arapi/deleteZone';
window.AR_SAVE_GROUNDPLAN_ZONES = '/arapi/saveGroundPlanZonesData';
window.UPDATE_CROPPED_IMAGE_ITEM = '/arapi/updateCropedImageItem';
window.DELTE_ITEM_FROM_OVERVIEW = '/arapi/deleteItemFromOverView';
window.CLONE_IMAGE_OVERALL_DATA = '/arapi/cloneImageOverallData';
window.GET_RECOGNISED_PINS_DETAILS = '/arapi/getGroundPlanFloorDetails'

//------Other Constants--------//
window.defaultZoneColor = '#999999';
window.AR_URL_CONSTANT = 'AR606462c34b06f';
window.AR_IFRAME_URL = 'ARiFrame607272deb4cb2';

//--------------------------------//
window.AR_ROUTING_ELEMENTS = '/arapi/getArRoutingsDetails';
