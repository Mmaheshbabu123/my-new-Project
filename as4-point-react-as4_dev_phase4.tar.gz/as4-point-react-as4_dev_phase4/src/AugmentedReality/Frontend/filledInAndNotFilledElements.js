export const filledInAndNotFilledElements = {
    check,
    webelementTypeCase,
};

let statusWithARId = {};
let currentArIndexLength = 0;
let filledElementsCount = 0;

function check(stepLinked_elements, stateObj, typeObj){
  Object.keys(stepLinked_elements).map(arIndex => {
    currentArIndexLength = stepLinked_elements[arIndex].length;
    stepLinked_elements[arIndex].forEach((item) => {
      webelementTypeCase(item, stateObj, typeObj);
    });
    updateStatusByARindexId(arIndex);
    return 1 ;
  })
  return statusWithARId;
}

function webelementTypeCase(element, stateObj, typeObj){
  switch (typeObj[element]) {
    case window.TEXTFIELD:
    case window.TEXTBOX:
    case window.NUMERICFIELD:
    case window.DECIMALFIELD:
    case window.DATEFIELD:
    case window.DIGITAL_SIGNATURE:
      if(stateObj[element])
         filledElementsCount++;
      break;
    case window.RADIO_BUTTON:
      if(stateObj[element] && stateObj[element] !== '0' && stateObj[element] !== 0)
         filledElementsCount++;
      break;
    case window.CHECKBOX_ELEMENT:
      if(stateObj[element].length > 1)
         filledElementsCount++;
      else if (stateObj[element].length === 1 && stateObj[element][0] && stateObj[element][0] !== '-2' && stateObj[element][0] !== -2) {
        filledElementsCount++;
      }
      break;
    case window.LIST:
    case window.DATABASELIST:
    case window.LIST_ORGANISATIONAL_UNITS:
      if(Array.isArray(stateObj[element]) && stateObj[element].length > 0)
        filledElementsCount++;
      else if (stateObj[element] && stateObj[element].value && stateObj[element].value !== -2 && stateObj[element].value !== '-2' && stateObj[element].label !== 'Select') {
        filledElementsCount++;
      }
      break;
    case window.ATTACHMENTS:
      if(stateObj[element] && stateObj[element].length > 0)
        filledElementsCount++;
      break;
    default:
       break;
  }
}

function updateStatusByARindexId(arIndex){
  if(currentArIndexLength === filledElementsCount){
     statusWithARId[arIndex] = { color: 'GREEN', filledStatus: 1 }
  }else if (filledElementsCount > 0) {
    statusWithARId[arIndex] = { color: 'GRAY', filledStatus: 2 }
  }else{
    statusWithARId[arIndex] = { color: 'RED', filledStatus: 0 }
  }
  filledElementsCount = 0;
  return;
}
