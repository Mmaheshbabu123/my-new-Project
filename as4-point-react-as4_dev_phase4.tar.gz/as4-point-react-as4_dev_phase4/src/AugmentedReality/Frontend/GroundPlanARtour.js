import React, { useState, useEffect, useRef } from 'react';
import L from 'leaflet';
import { Map, Marker, ImageOverlay, Popup } from "react-leaflet";
import * as reactbootstrap from 'react-bootstrap'
import { translate } from '../../language';
import map_marker from '../../images/marker-icon-2x-green.png';
import CheckBox from '../../CheckBox';
import { OCAlert } from '@opuscapita/react-alerts';
import ARSimulation from '../../Webforms/Simulation/ARSimulation';
import { datasave } from '../../_services/db_services';
import '../../GroundPlan/GroundPlanEditor/GroundPlanEditor.css';
import filled from '../../images/marker-icon-green.png';
import not_fullyFilled from '../../images/marker-icon-grey.png';
import not_filled from '../../images/marker-icon-red.png';
import shadow_marker from '../../images/marker-shadow.png'
var MAP_DEFAULT_BOUNDS = L.latLngBounds(L.latLng(-140, -275), L.latLng(140, 275));

const GroundPlanARtour = (props) => {
  const t = props.t;
  const inputRef  = useRef({});
  const [state, setState] = useState({
    groundPlanSource: '',
    currentPin: [{coordinate_x:0, coordinate_y:0}],
    savedPins: [],
    dataLoaded: false,
    pinLinkedElements: [],
    recognisedId: 0,
  });

  useEffect(()=>{
    getGroundPlanData();
  },[props.zoneId])

  const getGroundPlanData = () => {
    datasave.service(window.GET_RECOGNISED_PINS_DETAILS, 'POST', getData())
    .then(response => {
      if(response.status === 200){
        let currentPin = response.data.pinsData.length > 0 ? (response.data.pinsData.filter(val => val.currentPin === 1).length ? response.data.pinsData.filter(val => val.currentPin === 1)[0] : response.data.pinsData[0])
        :[{coordinate_x:0, coordinate_y:0}];
        let floorData = response.data.floor_data;
        setState({...state,
          savedPins: response.data.pinsData,
          groundPlanSource: floorData ? floorData.file_path : '',
          floorLabel: `${floorData.floor_code}-${floorData.floor_name}`,
          buildingLabel: `${floorData.building_code}-${floorData.building_name}`,
          dataLoaded: true,
          currentPin: {...currentPin, currentPin: 1},
          linked_elements: props.stepLinked_elements,
          linked_items_ids: props.stepLinked_item_ids,
        })
      }
    }).catch(error => {
      console.log(error);
    })
  }
  useEffect(() => {
    setState({...state, recognisedId: props.recognised_ar_linkingId})
  },[props.recognised_ar_linkingId])

  const getData = () => {
    return {
      linked_ar_ids: props.stepLinked_ar_ids,
      recognised_ar_linkingId: props.recognised_ar_linkingId ? props.recognised_ar_linkingId : 0,
    }
  }
  const groundPlanContent = () => {
    return (
      <div
         className={'groundPlan_artour'} id={'floorId_' + props.ar_linked_id}>
          {state.groundPlanSource !== '' &&
          <Map ref = {map => inputRef.current[props.ar_linked_id] = map}
            center = {[state.currentPin.coordinate_x, state.currentPin.coordinate_y]}
            zoom   = {1}
            minZoom  = {1}
            maxZoom  = {4}
            dragging = {true}
            // onClick={(evt) => addPintoGroundPlan(evt)}
            maxBoundsViscosity = {1.0}
            maxBounds  = {MAP_DEFAULT_BOUNDS}
            attributionControl = {false}
            crs             = {L.CRS.Simple}
            zoomControl     = {true}
            touchZoom       = {true}
            doubleClickZoom = {true}
            scrollWheelZoom = {true}
            >
            <ImageOverlay
              minZoom = {1}
              maxZoom = {4}
              bounds  = {MAP_DEFAULT_BOUNDS}
              url     = {state.groundPlanSource}
            />
          {markerJsx(props.ar_linked_id)}
        </Map>}
      </div>
    );
  }
// console.log(props);
// console.log(state);
  /*------CREATING CUSTOM MARKERS USING LEAFLET ICON OBJECT----*/
  const markerJsx = (val) => {
    let markerObj = [...state.savedPins];
    if(props.filledInNotFilledStatus){
      markerObj = markerObj.map(val => {return{...val, ...props.filledInNotFilledStatus[val.id]}});
    }
     const customMarkers = (
       markerObj.map((marker, index) => {
         let url = marker.color === 'GREEN' ? filled : marker.color === 'RED' ? not_filled : not_fullyFilled;
         let editor = L.icon({
           iconUrl     : url,
           shadowUrl   : shadow_marker,
           iconSize    : [18, 34],
           iconAnchor  : [9, 34],
           popupAnchor : [1, -34],
           shadowSize  : [34, 34],
           className   : markerObj.length === 1 ? 'current_position' : (marker.color === 'RED') ? 'current_position' : '',
         })
           let coordsY = marker.coordinate_y;
           let coordsX = marker.coordinate_x;
           return (
             <Marker icon={editor} draggable={false} key = {`marker-${index}`} position={[coordsX, coordsY]}
               onClick={()=> setState({...state, pinLinkedElements: state.linked_elements[marker.id].sort(function(a, b) {return a - b}), showpopup: true }) }>
              <Popup autoPan={true} >
                <div style={{ width: 'auto', height: 'auto', textAlign: 'center' }}>
                   <h6> {t('current user position')} </h6> <br />
                </div>
             </Popup>
             </Marker>
           );
       })
     );
     return customMarkers;
   }
   const simulationPopUp = () => {
     return(
       <reactbootstrap.Modal
            show={state.showpopup === true}
            onHide={() => setState({...state, showpopup:false})}
            aria-labelledby="example-custom-modal-styling-title"
            size='lg'>
          <reactbootstrap.Modal.Header closeButton />
            <reactbootstrap.Modal.Body>
              {callSimulationComponent()}
           </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal>
     );
   }

   const callSimulationComponent = () => {
     let stateObj = {...props.stateObj}
     return(
       <ARSimulation {...props}
          childform_simulate = {stateObj.childform_simulate}
          child_form_id = {stateObj.child_form_id}
          child_newtab = {stateObj.child_newtab}
          corporate_url={stateObj.corporate_url}
          corporate={stateObj.corporate}
          data = {stateObj.validData}
          disable_field = {stateObj.disabled}
          linked_elements={state.pinLinkedElements}
          parent_step_id = {stateObj.parent_step_id}
          refid = {stateObj.refid}
          simulate = {stateObj.simulate }
          simulateUser = {stateObj.simulateUser}
          step_id={stateObj.stepid}
          stepAction={stateObj.stepAction}
          simulationTriggerMails={stateObj.simulationTriggerMails}
          todo_id = {stateObj.todo_id}
          view = {stateObj.view}
          webform_id = {stateObj.webform_id}
      />
     );
   }

  return(
    <div style={{marginBottom: '50px'}}>
       {(state.dataLoaded && state.savedPins.length) ? <label style={{marginTop:'10px'}}> <strong>{t('Building')}</strong> : {state.buildingLabel}, <strong>{t('Floor')}</strong> : {state.floorLabel}</label> : null}
       {(state.dataLoaded && state.savedPins.length) ? groundPlanContent() : null}
       {(state.dataLoaded && !state.savedPins.length) ? callSimulationComponent() : null}
       {simulationPopUp()}
    </div>
  );
}

export default translate(React.memo(GroundPlanARtour));
