import React, { useEffect, useState, useRef } from 'react'
import * as reactbootstrap from 'react-bootstrap'
import { translate } from '../../language';
import camera_on from '../../images/camera_on.png';
import camera_off from '../../images/camera_off.png'
// import nftData from './NftJson';
import ARSimulation from '../../Webforms/Simulation/ARSimulation';

const SimulateWebformWithAR = (props) => {
  const t = props.t;
  var iframeRef = useRef({});
  const[state, setState] = useState({
    showpopup: false,
    nft: Object.values(props._nftObject),
    webform_id: 11439,
    is_opened: false,
    linkedElementIds: [],
    ar_linked_id: null,
    linked_elements: [],
    _isIframeLoaded: false,
    cameraOn: false,
  })
  useEffect(()=>{
    window.addEventListener("message", (e) => imageRecognised(e));
    return(() => {
      window.removeEventListener("message", (e) => imageRecognised(e));
    })
  },[])
  const imageRecognised = (e) => {
    let recognisedId = e.data;
    console.log(recognisedId)
    if(Array.isArray(recognisedId)){
      postDataToIframeComponent()
    }else{
      if(recognisedId !== 0){
         let recognisedId = props.stepLinked_elements[recognisedId] ? recognisedId : props.stepLinked_ar_ids[0] ? props.stepLinked_ar_ids[0] : 0;
         console.log(recognisedId);
         props.updateRecognisedPinId(recognisedId);
         setState({...state,
           showpopup: true,
           is_opened: !state.is_opened,
           linked_elements: props.stepLinked_elements[recognisedId] ? props.stepLinked_elements[recognisedId].sort(function(a, b) {return a - b}) : [],
           recognised_ar_linkingId: recognisedId,
           cameraOn: true,
         })
      }else{
         console.error('not proper id');
      }
    }
  }

  const postDataToIframeComponent = () => {
    if(iframeRef && iframeRef.current && iframeRef.current.contentWindow && state._isIframeLoaded !== true){
      iframeRef.current.contentWindow.postMessage(
        state.nft,
        // `https://${process.env.REACT_APP_baseURL}`, // for security purpose add any unique key
      )
      setState({...state, _isIframeLoaded: true, cameraOn: true,})
    }else{
      console.error('iframe not found');
    }
  }

  const modal = () => {
    let stateObj = {...props.stateObj}
    return(
      <reactbootstrap.Modal
           show={state.showpopup === true}
           onHide={() => setState({...state, showpopup:false, is_opened:false })}
           aria-labelledby="example-custom-modal-styling-title"
           size='lg'>
         <reactbootstrap.Modal.Header closeButton />
           <reactbootstrap.Modal.Body>
             {<ARSimulation {...props} view = {stateObj.view} todo_id = {stateObj.todo_id}  simulate = {stateObj.simulate } refid = {stateObj.refid} webform_id = {stateObj.webform_id} data = {stateObj.validData} simulateUser = {stateObj.simulateUser}  step_id={stateObj.stepid} parent_step_id = {stateObj.parent_step_id} childform_simulate = {stateObj.childform_simulate} disable_field = {stateObj.disabled}
               handleElementSaveSubmit={props.handleElementSaveSubmit  ? props.handleElementSaveSubmit.bind() : null} child_form_id = {stateObj.child_form_id} parent_id ={props.parent_id} stepAction={stateObj.stepAction} callMount = {props.callMount} parentSaved = {props.parentSaved}
               child_newtab = {stateObj.child_newtab} corporate_url={stateObj.corporate_url} corporate={stateObj.corporate} simulationTriggerMails={stateObj.simulationTriggerMails}
               updateElementStatusInGroundPlan = {props.updateElementStatusInGroundPlan.bind()}
               linked_elements={state.linked_elements}
               recognised_ar_linkingId={state.recognised_ar_linkingId}
            />}
          </reactbootstrap.Modal.Body>
       </reactbootstrap.Modal>
     );
   }

   const mountIframe = () => {
     return(
       <iframe
          ref={(iframe) => iframeRef.current = iframe}
          id={window.AR_IFRAME_URL}
          width="100%"
          height="430"
          scrolling="no"
          frameBorder="no"
          onLoad={()=>{console.log('Iframe loaded')}}
          src={'/' + window.AR_IFRAME_URL}>
       </iframe>
     );
   }
 return(
    <React.Fragment>
      <div><a href="javascript:;" className='goback-btn-kpi-dashboard-btn' onClick={() => setState({...state, cameraOn: !state.cameraOn})}>{t('Camera')}</a>
      {state.cameraOn === false ?
        <img src = {camera_off} width="50px" style={{cursor:'pointer'}} onClick={()=> setState({...state, cameraOn: !state.cameraOn})}/>:
        <img src= {camera_on} width="50px" style={{cursor:'pointer'}} onClick={()=> setState({...state, cameraOn: !state.cameraOn})}/>
      }</div>
      {state.cameraOn === true && <div>
        {mountIframe()}
      </div>}
      {modal()}
    </React.Fragment>
 );
}

export default translate(React.memo(SimulateWebformWithAR));
