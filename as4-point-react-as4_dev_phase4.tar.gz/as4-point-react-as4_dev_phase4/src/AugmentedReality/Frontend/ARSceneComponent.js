import React, { useState, useEffect } from 'react'
import * as reactbootstrap from 'react-bootstrap'
import { translate } from '../../language';

const ARSceneComponent = (props) => {
  const t = props.t;
  const [state, setState] = useState({
    nftDataArray: [],
  })

  useEffect(() => {
    window.addEventListener("message", (e) => getParentComponentData(e));
    window.AFRAME.registerComponent('registerevents', {
  	init: function () {
  		var marker = this.el;
  		marker.addEventListener('markerFound', function() {
        let recognisedId = parseInt(marker.getAttribute('id'));
        window.parent.postMessage(recognisedId);
  		});
  	 }
  	})
    return(() => {
      window.removeEventListener("message", (e) => getParentComponentData(e))
    })
  },[])

  useEffect( () => {
    if(document.getElementsByClassName('arjs-loader').length === 1){
      window.parent.postMessage([1]);
    }
  },[Object.keys(document.getElementsByClassName('arjs-loader')).length])

  function getParentComponentData(e){
    // if(e.origin === `https://${process.env.REACT_APP_baseURL}`){
    // }
    let parentComponentData = e.data ? e.data : [];
    setState({...state, nftDataArray: parentComponentData})
  }
 return(
   <React.Fragment>
     <div style={{"margin" : "0px", "overflow": "hidden"}}>
       <div class="arjs-loader">
         <div>{t('Loading, please wait')}...</div>
       </div>
       <a-scene
         vr-mode-ui="enabled: false;"
         renderer="antialias: true; alpha: true; precision: mediump;"
         embedded
         arjs="trackingMethod: best; sourceType: webcam; debugUIEnabled: false;"
       >
       {state.nftDataArray.map(val => {
         return(
           <a-nft
             registerevents
             type="nft"
             id={val.ar_linked_id}
             name = 'generotor'
             url={val.url}
             smooth="true"
             smoothount="10"
             smoothtolerance="0.01"
             smooththreshold="5"
           ></a-nft>
         )})}
         <a-entity camera></a-entity>
       </a-scene>
     </div>
   </React.Fragment>
 );
}

export default translate(React.memo(ARSceneComponent));
