const nft_object = {
         "1": {
            "ar_linked_id":1,
            "url":"https://arjs-cors-proxy.herokuapp.com/https://raw.githack.com/Mmaheshbabu123/GENERTOR_400_NFT/main/IMAGES/GENERATOR",
           },
         "78": {
            "ar_linked_id":78,
            "url":"https://arjs-cors-proxy.herokuapp.com/https://raw.githack.com/Mmaheshbabu123/GENERTOR_400_NFT/main/IMAGES/GENERATOR",
	 },
};

export default nft_object;
