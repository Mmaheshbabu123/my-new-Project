import React, { useState, useEffect, useRef } from 'react';
import { FeatureGroup } from 'react-leaflet';
import { EditControl } from 'react-leaflet-draw';
import { SketchPicker } from 'react-color';
// import { store } from '../../store';
import L from 'leaflet';
import { Map, Marker, ImageOverlay } from "react-leaflet";
// import { Tooltip } from "react-leaflet";
import Can from '../../_components/CanComponent/Can';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
import { CanPermissions } from '../../_components/CanComponent/CanPermissions';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../../language';
import { datasave } from '../../_services/db_services';
import * as reactbootstrap from "react-bootstrap";
import '../../GroundPlan/GroundPlanEditor/GroundPlanEditor.css';
import map_marker from '../../images/marker-icon-2x-green.png';
import latest_marker from '../../images/marker-icon-2x-red.png';
import shadow_marker from '../../images/marker-shadow.png'
// import json from './dummyjson';
// import CheckBox from '../../CheckBox';
import MultiSelect from '../../_components/MultiSelect';
import ItemPopUp from '../../AR0166/ItemPopUp';

var MAP_DEFAULT_BOUNDS = [];
var reactFeatureGroupRef = {};
var cloneStateObj = {};

/**
 * [GroundPlanZones description]
 *
 * @param {Object} props [description]
 */
const GroundPlanZones = (props) => {
  const t = props.t;
  const inputRef  = useRef({});
  const overview  = 1;
  const [state, setState] = useState({
    buildings            : [],
    floors               : [],
    floorIcons           : [],
    selectedBuildings    : [], selectedFloors : [],
    showCreateZones      : false, zoneWarning : false,
    zones    : {},
    zoneName : '',
    editZoneId : 0,
    selectedZoneName : '',
    selectedZoneID   : 0,
    customColor  : window.defaultZoneColor,
    floorOptions : [],
    selectedBuildingOptions : [],
    selectedFloorOptions : [],
    gpLinkedData : [],
    arItemData   : [],
    zoneLinkedItems : {},
    overviewRowId: 0,
    overviewData: {},
    currentItem: {},
    imageItems: [],
    showItemOverview: false,
  });

  useEffect(() => {
    dataLoad();
  }, [])

  async function dataLoad(data) {
    await datasave.service(`${window.AR_GROUNDPLAN_ZONE_DATA}/${props.webform_id}`, 'GET')
    .then(async response => {
      if(response.status === 200){
        await setStateResponseValues(response.data, data);
      }else{
        OCAlert.alertError(t('Unable to fetch zones data.'), { timeOut: window.TIMEOUTNOTIFICATION })
      }
    });
  }

  const setStateResponseValues = (data, propsData) => {
    let firstZone = 0;
    let color = window.defaultZoneColor;
    let selectedFloors; let selectedBuildings;
    if(Object.keys(data.zones).length > 0){
      firstZone = Object.values(data.zones)[0] ? Object.values(data.zones)[0].id : 0;
      color = Object.values(data.zones)[0] ? Object.values(data.zones)[0].color : 0;
      [selectedBuildings, selectedFloors] = getZoneBuildingAndFloor(Object.values(data.zones)[0].floor_id, data.floors, data.buildings);
    }
    setState({
      ...state,
      buildings:    data.buildings    ? data.buildings    : [],
      floors:       data.floors       ? data.floors       : [],
      floorIcons:   data.floor_icons  ? data.floor_icons  : [],
      gpLinkedData: data.gpLinkedData ? data.gpLinkedData : [],
      arItemData:   data.arItemData   ? data.arItemData   : [],
      zones:        data.zones        ? data.zones        : [],
      zoneLinkedItems : data.zoneLinkedItems ? data.zoneLinkedItems : [],
      selectedZoneID : firstZone,
      customColor : color,
      selectedFloors : [...state.selectedFloors, selectedFloors ? selectedFloors.value : 0],
      selectedBuildings : [...state.selectedBuildings, selectedBuildings ? selectedBuildings.value : 0],
      selectedFloorOptions : selectedFloors ? [selectedFloors] : [],
      selectedBuildingOptions : selectedBuildings ? [selectedBuildings] : []
    });
  }
  const getZoneBuildingAndFloor = (floor_id, floors, buildings) => {
    let buildingObj;
    let floorObj;
    if(!floor_id){
      return [0 , 0];
    }else{
      Object.values(floors).map(floor => {
        Object.values(floor).map(val =>{
          if(val.value === floor_id){
            buildingObj = buildings[val.parent_id];
            floorObj = val;
          }
          return true;
        })
        return true })
      return [buildingObj, floorObj];
    }
  }

  function getDataToPost(){
    const { zones, zoneLinkedItems} = state;
    let data = {
      webform_id  : props.webform_id,
      zones : zones,
      zoneLinkedItems : zoneLinkedItems
    }
    return data;
  }
  const handleSave = () => {
    datasave.service(window.AR_SAVE_GROUNDPLAN_ZONES, 'POST', getDataToPost())
    .then(response => {
      response.status === 200 ? OCAlert.alertSuccess(t('Zones data saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION })
      : OCAlert.alertError(t('Unable to save the data.'), { timeOut: window.TIMEOUTNOTIFICATION });
    })
  }

  const handleCancel = () => {
    props.closeGroundPlanZone();
  }

  const onDragOver = (event) => {
    if (overview) { return false }
    event.preventDefault();
  }

  const updateCoordinates = (target, marker) => {
    let latlng     = target._latlng;
    let newCoordsX = latlng.lat;
    let newCoordsY = latlng.lng;
    marker = [{ ...marker, coordinate_x: newCoordsX, coordinate_y: newCoordsY, latest : 1 }];
  }

  /*------ADDING FLOORS IMAGES ONTO REACT-LEAFLET MAP CONATINER----*/
  const showSelectedFloors = () => {
    let selected = [];
    var southWest = overview !== 1 ? L.latLng(-110, -190) : L.latLng(-140, -275);
    var northEast = overview !== 1 ? L.latLng(110, 190)   : L.latLng(140, 275);
    MAP_DEFAULT_BOUNDS = L.latLngBounds(southWest, northEast);
    state.selectedBuildings.forEach((item) => {
      if (state.floors[item] !== undefined) {
        Object.values(state.floors[item]).map(val => {
          let shapeOptions = { color: state.customColor, fillOpacity : 0.4, weight : 1 }
          let source = state.floorIcons[val.value] !== undefined ? state.floorIcons[val.value].file_path : '';
          let marker = 1;//state.saveDetails[val.value] !== undefined ? 1 : 0;
          let buildingId = state.buildings[item].value;
          if (state.selectedFloors.indexOf(val.value) !== -1) {
            return (
              selected.push(
                <div>
                  <div className = 'col-md-7'> <strong>{t('Building')}</strong> : {state.buildings[item].label}, <strong>{t('Floor')}</strong> : {val.label}</div>
                  <div
                    onDragOver={(event) => onDragOver(event)}
                    className={'groundPlan_overview'} id={'floorId_' + val.value} parent_id={item} >
                    <Map ref = {map => inputRef.current[val.value] = map}
                      center = {[0, 0]}
                      zoom   = {1}
                      minZoom  = {1}
                      maxZoom  = {4}
                      dragging = {true}
                      maxBoundsViscosity = {1.0}
                      maxBounds  = {MAP_DEFAULT_BOUNDS}
                      attributionControl = {false}
                      crs             = {L.CRS.Simple}
                      zoomControl     = {true}
                      touchZoom       = {true}
                      doubleClickZoom = {true}
                      scrollWheelZoom = {true}
                      >
                      <FeatureGroup ref={(reactFGref) => {_onFeatureGroupReady(reactFGref, val.value)}}>
                        {state.selectedZoneID !== 0 && <EditControl
                          position  = 'topright'
                          onCreated = {(e) => _onCreateZone(e, val.value)}
                          onEdited  = {(e) => _onEditZone(e)}
                          onDeleted = {(e) => _onDeleteZone(e)}
                          draw={{
                            circlemarker : false,
                            polyline  : { shapeOptions : shapeOptions },
                            polygon   : { shapeOptions : shapeOptions },
                            circle    : false,//{ shapeOptions : shapeOptions },
                            rectangle : { shapeOptions : shapeOptions },
                            marker    : false,
                          }}
                          edit = {{ featureGroup : L.featureGroup }}
                        />}
                      </FeatureGroup>
                      <ImageOverlay
                        minZoom = {1}
                        maxZoom = {4}
                        bounds  = {MAP_DEFAULT_BOUNDS}
                        url     = {source}
                      />
                      {marker === 1 && markerJsx(val, buildingId)}
                    </Map>
                  </div>
                </div>
              ));
          }
        })}
    });
    return selected;
  }

 /*------CREATING CUSTOM MARKERS USING LEAFLET ICON OBJECT----*/
  const markerJsx = (val, buildingId) => {
   let markerObj = state.gpLinkedData[val.value] ? state.gpLinkedData[val.value] : [];
    const customMarkers = (
      markerObj.map((marker, index) => {
        let url = marker.latest === 1 ? latest_marker : map_marker;
        let editor = L.icon({
          iconUrl     : url,
          shadowUrl   : shadow_marker,
          iconSize    : [24, 41],
        	iconAnchor  : [12, 41],
        	shadowSize  : [41, 41],
          className   : marker.latest === 1 ? 'blinking' : '',
        })
        let coordsX = marker.groundplan_coordinates_x;
        let coordsY = marker.groundplan_coordinates_y;
        if(coordsX && coordsY){
          return (
            <Marker
              onClick   = {(e) => showItemModal(marker)}
              icon      = {editor}
              draggable = {marker.latest === 1 ? true : false}
              onDragend = {e => updateCoordinates(e.target, marker)}
              key       = {`marker-${index}`}
              position  = {[coordsX, coordsY]} >
              {/*<Tooltip> {} </Tooltip>*/}
            </Marker>
          );
        }
      })
    );
    return customMarkers;
  }

    const _onFeatureGroupReady = async (reactFGref, floorRef) => {
      removeLayers();
      let zones = {...state.zones};
      if(reactFGref){
        reactFeatureGroupRef = {...reactFeatureGroupRef, [floorRef] : reactFGref.leafletElement};
        let zoneData = Object.values(zones).find(val => (val.value === state.selectedZoneID));
        let floorId = zoneData ? zoneData.floor_id ? zoneData.floor_id : 0 : 0;
        let leafletFG = reactFeatureGroupRef[floorId] ? reactFeatureGroupRef[floorId] : 0;
        if (leafletFG) {
           let leafletGeoJSON = new L.GeoJSON(zoneData.geo_json);
           leafletGeoJSON.eachLayer( (layer) => {
           layer.options = {...layer.options, ...layer.feature.properties}
           leafletFG.addLayer(layer);
         });
        }
      }
    }

  const _onCreateZone = async (e, floorId) => {
    let zoneLinkedItems = {...state.zoneLinkedItems};
    let zones = {...state.zones};
    let addedLayer = e.layer;
    let linkedItems = [];
    let geoJsonObj = addedLayer.toGeoJSON();
    geoJsonObj = {...geoJsonObj, properties : {...addedLayer.options }}
    zones = {...zones, [state.selectedZoneID] :{...zones[state.selectedZoneID], geo_json: geoJsonObj, floor_id: floorId }}
    linkedItems = getLinkedItems(floorId, addedLayer);
    zoneLinkedItems = {...zoneLinkedItems, [state.selectedZoneID] : linkedItems}
    setState({...state, zoneLinkedItems : zoneLinkedItems, zones : zones })
  }

  function removeLayers(){
    Object.values(state.floors).map((item) => {
      Object.values(item).map(floor => {
        let leafletFG = reactFeatureGroupRef[floor.value] ? reactFeatureGroupRef[floor.value] : 0;
        if(leafletFG){
          leafletFG.clearLayers();
        }
        return true;
      })
      return true;
    });
  }

  const _onEditZone = (e) => {
    let zoneLinkedItems = {...cloneStateObj.zoneLinkedItems};
    var layers = e.layers;
    let zones = {...cloneStateObj.zones};
    let properties = (zones[cloneStateObj.selectedZoneID].geo_json  && zones[cloneStateObj.selectedZoneID].geo_json['properties'] ) ?  zones[cloneStateObj.selectedZoneID].geo_json['properties']
                     : { color: cloneStateObj.customColor, fillOpacity : 0.4, weight : 1 };
    let linkedItems = [];
     layers.eachLayer(function (layer) {
       let geoJsonObj = layer.toGeoJSON();
       linkedItems = getLinkedItems(zones[cloneStateObj.selectedZoneID].floor_id, layer);
       // geoJsonObj = {...geoJsonObj, properties : {...properties }}
       // zones = {...zones, [cloneStateObj.selectedZoneID] : {
       //   ...zones[cloneStateObj.selectedZoneID], geo_json : geoJsonObj }}
       // zoneLinkedItems = {...zoneLinkedItems, [cloneStateObj.selectedZoneID] : linkedItems}
       geoJsonObj['properties'] = properties;
       zones[cloneStateObj.selectedZoneID]['geo_json'] = geoJsonObj;
       zoneLinkedItems[cloneStateObj.selectedZoneID] = linkedItems;
       setState({...cloneStateObj, zoneLinkedItems : zoneLinkedItems, zones : zones })
     });
  }

  function getLinkedItems(floorId, addedLayer){
    let gpLinkedData = state.gpLinkedData[floorId] ? state.gpLinkedData[floorId] : [];
    let linkedItems = [];
    var cuttentId = -999;
    gpLinkedData.map(val =>{
     if(cuttentId !== parseInt(val.id)){
       cuttentId = parseInt(val.id);
      let latLng = {lat: val.groundplan_coordinates_x, lng: val.groundplan_coordinates_y};
       if(addedLayer._bounds.contains(latLng)){
         linkedItems = [...linkedItems, ...state.arItemData[val.id]];
        }
        return 1;
      }
      })
    return linkedItems;
  }
  const _onDeleteZone = (e) => {
    let zoneLinkedItems = {...cloneStateObj.zoneLinkedItems};
    let zones = {...cloneStateObj.zones};
    zones = {...zones, [cloneStateObj.selectedZoneID] : {...zones[cloneStateObj.selectedZoneID], geo_json : '' }}
    zoneLinkedItems = {...zoneLinkedItems, [cloneStateObj.selectedZoneID] : []}
    setState({...cloneStateObj, zoneLinkedItems : zoneLinkedItems, zones : zones })
  }

  const handleAddZones = (flow) => {
    let existingZones = {...state.zones};
    datasave.service(window.AR_CREATE_UPDATE_ZONES, 'POST', {
         id         : flow === 'create' ? 0 : state.editZoneId,
         name       : state.zoneName,
         geo_json   : flow === 'create' ? null : existingZones[state.editZoneId].geo_json,
         floor_id   : flow === 'create' ? null : existingZones[state.editZoneId].floor_id,
         webform_id : props.webform_id,
         color      : state.customColor,
     }).then(response => {
      if(response.status === 200){
        OCAlert.alertSuccess(t(`Zone ${flow === 'create' ? 'created' : 'updated'} successfully.`), { timeOut: window.TIMEOUTNOTIFICATION })
        if(flow === 'create'){
          let newlyAddedZone = { label : state.zoneName, value : response.data, color : state.customColor }
          existingZones = {...existingZones, [response.data] : newlyAddedZone}
        }else{
          existingZones = {...existingZones, [state.editZoneId] : {...existingZones[state.editZoneId], label: state.zoneName, color: state.customColor }}
        }
        setState({...state, selectedZoneName : state.zoneName, zones: existingZones,
          showCreateZones : false, zoneName : '', zoneWarning: false, editZoneId: 0, selectedZoneID : flow === 'create' ? response.data : state.editZoneId
        })
      }else{
        OCAlert.alertError(t('Unable to create zone.'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    })
  }

   const getRenderContent = () => {
     return(
       <reactbootstrap className="px-0 col-md-12">
        <div className ='col-md-12 row'>
          {/* <i className = 'col-md-6' title="Create zone" style={{cursor:'pointer', marginRight : '15px'}} class="webform-sprite webform-sprite-createlistc"
            onClick={() => setState({...state, showCreateZones : true, customColor: window.defaultZoneColor, selectedZoneID : 0})}></i> */}
          {zoneTableView()}
        </div>
        {(CanPermissions("Access_groundplan,V_groundplan_editor,E_groundplan_editor", "") === true) &&
          <div style={{display : 'inline-block', paddingTop:'10px'}} className='col-md-12 pl-0'>
            {showSelectedFloors()}
          </div>
        }
       </reactbootstrap>
     );
   }

   const handleBuildingChange = async (e) => {
     let ids = e.map(obj => { return obj['value'] });
     let floors = await handleFilter(ids, state.floors);
     let selectedFloors = modifySelectedFloors(ids);
     setState({...state,
       selectedBuildings: e.map(arr => arr.value),
       selectedBuildingOptions : e,
       floorOptions     : floors,
       selectedFloorOptions : selectedFloors,
       selectedFloors   : selectedFloors.map(arr => arr.value),
     });
   }

   const handleFilter = (selctIds,dataObj) =>{
        let data = [];
        for(var i = 0 ; i<selctIds.length;i++){
        if(dataObj[selctIds[i]]!== undefined){
        Array.prototype.push.apply(data, Object.values(dataObj[selctIds[i]]))
     }}
     return data;
  }

  const modifySelectedFloors = (buildingIds) => {
    let selectedFloors = [];
    state.selectedFloorOptions.map((floor) => {
      if(buildingIds.includes(floor.parent_id)){
        selectedFloors.push(floor);
      }
    })
    return selectedFloors;
  }

  const onZoneChange = (val) => {
    let [selectedBuildings, selectedFloors] = getZoneBuildingAndFloor(val.floor_id, state.floors, state.buildings);
    setState({...state,
      selectedZoneName : val.label,
      selectedZoneID : val.value,
      customColor: val.color,
      selectedFloors : [selectedFloors ? selectedFloors.value : 0],
      selectedBuildings : [selectedBuildings ? selectedBuildings.value : 0],
      selectedFloorOptions : selectedFloors ? [selectedFloors] : [],
      selectedBuildingOptions : selectedBuildings ? [selectedBuildings] : []
    })
  }

  useEffect(() => {
    cloneStateObj = {...state};
  },[state])

   const zoneTableView = () => {
     const { zones, selectedZoneID, zoneLinkedItems } = state;
     let zonesExists = Object.keys(zones).length;
     return(
       <div className = 'col-md-12 row p-0' style={{ }}>
         <div className = 'p-0 m-0' style={{height: '250px', 'overflowY': 'auto', 'scrollbar-width': 'thin', width:'37%' }}>
           <reactbootstrap.Table bordered variant="" >
             <thead style={{backgroundColor: '#EC661C', color: '#fff',position: 'sticky',top: '0', zIndex: 100,textAlign: 'center' }}>
               <tr> <th style={{  }} >{t('Zones')}</th> </tr>
             </thead>
             <tbody>
                {zonesExists > 0 ? Object.values(zones).map(val =>
                  <tr id = {val.value}>
                  <td className='col-md-12 row' style={{backgroundColor: selectedZoneID === val.value ? '#D3D3D3' : '', margin: 0}}>
                    <span className='col-md-10' id = {'zoneName_' + val.id} style = {{width : '60%', cursor: 'pointer' }} onClick = {() => onZoneChange(val)} > {val.label} </span>
                    <span className='col-md-1' id = {'zoneColor_' + val.id} title={t('color')} style={{ 'cursor': 'pointer', height:'12px', marginTop:'5px', backgroundColor:val.color }} onClick ={() => setState({...state, showColorPicker: true, editZoneId: val.value, zoneName: val.label, customColor: val.color })}></span>
                    <span className='col-md-1' id = {'zoneAddColor_' + val.id}> <i title={t('Add color')} style={{ 'cursor': 'pointer' }} onClick ={() => setState({...state, showColorPicker: true, editZoneId: val.value, zoneName: val.label, customColor: val.color })} class="ActionCss ActionCss-cssinactive" ></i></span>
                   </td>
                  </tr>
                ) : <p style={{margin:'20px'}}> {t('No zones to show - create the zones in the routing property section of the 4th tab')} </p>}
             </tbody>
           </reactbootstrap.Table>
         </div>
         <div className = 'm-0 p-0' style={{height: '250px', 'overflowY': 'auto', scrollbarWidth: 'thin', width:'31%' }}>
           <reactbootstrap.Table bordered variant="" style={{ }}>
             <thead style={{backgroundColor: '#EC661C', color: '#fff',position: 'sticky',top: '0', zIndex: 100,textAlign: 'center' }}>
               <tr> <th style={{  }} >{t('Linked items of ')}{zones[selectedZoneID] ? zones[selectedZoneID].label : ''}</th> </tr>
             </thead>
             <tbody>
                {zoneLinkedItems[selectedZoneID] ? zoneLinkedItems[selectedZoneID].map(val => {
                  if(val.item_name){
                    return(
                      <tr id = {val.value}>
                      <td className='col-md-12 row' style={{backgroundColor: selectedZoneID === val.value ? '#D3D3D3' : '', margin: 0}}
                          onClick={() => setState({...state,
                            itemPopUp: true,
                            overviewRowId: val.ref_id,
                            currentItem: val,
                            overviewData: state.gpLinkedData[state.zones[selectedZoneID]['floor_id']] ? state.gpLinkedData[state.zones[selectedZoneID]['floor_id']] : [] })}
                       >
                        <span className='col-md-8' id = 'zoneName' style = {{width : '60%', cursor: 'pointer' }} title = {val.item_name ? val.item_name : `${t('no name')}`} > {val.item_name ? val.item_name : `${' "" '}`} </span>
                       </td>
                      </tr>
                    )
                  }}) : <p style={{margin:'20px'}}> {t('Link items by clicking on a zone and drawing areas on the ground plan below')} </p>}
             </tbody>
             </reactbootstrap.Table>
           </div>
         <div className = 'm-0 p-0'  style={{width:'32%'}}>
         <div className='col-md-12 m-0 p-0'>
             <reactbootstrap.InputGroup className="col-md-12 p-0" style = {{marginTop:'15px'}}>
                <div className="col-md-3">
                    <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ color: '#EC661C' }} id="basic-addon1">{t('Buildings:')}</reactbootstrap.InputGroup>
                    </reactbootstrap.InputGroup.Prepend>
                </div>
                <div class="col-md-9 input-padd">
                    <MultiSelect
                    options={Object.values(state.buildings)}
                    standards={state.selectedBuildingOptions}
                    disabled={false}
                    handleChange={(e) => handleBuildingChange(e)}
                    isMulti={true}
                    />
                </div>
            </reactbootstrap.InputGroup>
            <reactbootstrap.InputGroup className="col-md-12 p-0" style = {{marginTop:'15px'}}>
              <div className="col-md-3">
                  <reactbootstrap.InputGroup.Prepend>
                      <reactbootstrap.InputGroup style={{ color: '#EC661C' }} id="basic-addon1">{t('Floors:')}</reactbootstrap.InputGroup>
                  </reactbootstrap.InputGroup.Prepend>
              </div>
              <div class="col-md-9 input-padd">
                  <MultiSelect
                  options={state.floorOptions}
                  standards={state.selectedFloorOptions}
                  disabled={false}
                  handleChange={(e) => setState({...state, selectedFloors : e.map(arr => arr.value), selectedFloorOptions: e })}
                  isMulti={true}
                  />
              </div>
           </reactbootstrap.InputGroup>
           </div>
           <reactbootstrap.FormGroup style={{paddingTop : '25px'}}>
               <div style={{ float: 'right' }} className="organisation_list">
                   <a type="submit" name="cancel" onClick={handleCancel} > {t('Cancel')} </a>
                   &nbsp;&nbsp;&nbsp;
                <reactbootstrap.Button type="submit" name="save" className="btn btn-primary" onClick={handleSave} >{t('Save')}</reactbootstrap.Button>
               </div>
           </reactbootstrap.FormGroup>
         </div>
       </div>
     );
   }

   const zonePopUp = () => {
     const { editZoneId } = state;
     return (
       <reactbootstrap.Modal
         show={state.showCreateZones}
         onHide={() => setState({ ...state, showCreateZones : false, zoneWarning: false })}
         aria-labelledby="example-custom-modal-styling-title">
        <reactbootstrap.Modal.Header closeButton>
           <p className='common-color' style={{textAlign : 'center', width:'100%', fontSize : 'large' }}> {t('Create zones')} </p>
        </reactbootstrap.Modal.Header>
         <reactbootstrap.Modal.Body>
           <reactbootstrap.Col>
               <reactbootstrap.Form.Group className="col-md-12 row">
                   <reactbootstrap.Form.Label className="col-md-4">
                       {t('Name')}:<span style={{ color: "red" }}>*</span>
                   </reactbootstrap.Form.Label>
                   <reactbootstrap.Form.Control className="col-md-8"
                       type="text"  id="_zoneName"
                       value={state.zoneName} autoFocus = {true}
                       onChange={(e) => {
                         setState({...state, zoneName : e.target.value, zoneWarning : e.target.value.length >  0 ? false : true })
                       }}
                       onKeyDown = {(e) => e.key === 'Enter' ? (e.target.value.length >  0 ?  handleAddZones(editZoneId !== 0 ? 'edit' : 'create') : setState({...state, zoneWarning : true })) : null}
                       placeholder={t("Enter Name")}
                   />
                   {state.zoneWarning === true &&
                      <reactbootstrap.Form.Text style={{ color: "red", textAlign: 'center', width: ' 100%' }} >
                         {t('Name is required field')}
                      </reactbootstrap.Form.Text>}
               </reactbootstrap.Form.Group>
           </reactbootstrap.Col>
           <reactbootstrap.Col>
               <reactbootstrap.Form.Group className="col-md-12 row">
               <reactbootstrap.Form.Label className="col-md-4">
                   {t('Color')}
               </reactbootstrap.Form.Label>
               <reactbootstrap.Form.Control className="col-md-4" style={{marginRight: '10px'}}
                    type="text"
                    id='_zoneColorTag'
                    value={state.customColor}
                    disabled = {true}
                    placeholder={t("Color")}
                  />
                <reactbootstrap.Button className = 'col-md-3' variant="outline-success" onClick = {()=>setState({...state, showColorPicker: true})} >
                    {t('Add here')}
                </reactbootstrap.Button>
               </reactbootstrap.Form.Group>
           </reactbootstrap.Col>
         </reactbootstrap.Modal.Body>
         <reactbootstrap.Modal.Footer>
           <div>
               <reactbootstrap.Button onClick={()=> setState({...state, showCreateZones : false})} variant="primary">
                   {t('Close')}
               </reactbootstrap.Button> <span style={{ marginRight: '10px' }}></span>
               <reactbootstrap.Button onClick={() => handleAddZones(editZoneId !== 0 ? 'edit' : 'create')} variant="primary">
                   {t('Add')}
               </reactbootstrap.Button>
           </div>
         </reactbootstrap.Modal.Footer>
       </reactbootstrap.Modal>
     );
   }

   const colorPicker = () => {
     return(
       <reactbootstrap.Modal show={state.showColorPicker} onHide = {()=> setState({...state, showColorPicker:false}) }>
          <reactbootstrap.Modal.Header closeButton>
            <p className='common-color' style={{textAlign : 'center', width:'100%', fontSize : 'large' }}> {t('Choose color for')}: {state.zoneName} </p>
          </reactbootstrap.Modal.Header>
           <reactbootstrap.Modal.Body>
             <SketchPicker className="picker-sketch" color={state.customColor} onChangeComplete={(e) => {
               let zones = {...state.zones}
               zones[state.editZoneId] = {...zones[state.editZoneId], color: e.hex}
               setState({...state, customColor : e.hex, zones:zones })
             }} />
           </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal>
     );
   }

   const closeItemPopUp = (item_name = '', item_id = 0) => {
     let zoneLinkedItems = {...state.zoneLinkedItems};
     if(item_name){
       let zoneItems = zoneLinkedItems[state.selectedZoneID];
       zoneItems.map(val => {
         if(val.id === item_id)  val.item_name = item_name;
       })
       setState({...state, itemPopUp : false, zoneLinkedItems: zoneLinkedItems})
     }else {
       setState({...state, itemPopUp:false})
     }
   }

   const showItemPopUp = () => {
     return(
       <reactbootstrap.Modal show={state.itemPopUp} onHide = {()=>  closeItemPopUp()}>
          <reactbootstrap.Modal.Header closeButton>
            <p className='common-color' style={{textAlign : 'center', width:'100%', fontSize : 'large' }}> {t('Image item')} </p>
          </reactbootstrap.Modal.Header>
           <reactbootstrap.Modal.Body>
             <ItemPopUp  closePopUp = {closeItemPopUp.bind()} itemData = {state.currentItem} overviewData = {state.overviewData} rowId={state.overviewRowId} />
           </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal>
     );
   }

   useEffect(() => {
     if(state.showCreateZones){
       document.getElementById('_zoneName').focus();
     }
   })

   const showItemModal = async (obj) => {
     await datasave.service(window.GET_AR_IMAGE_OVERVIEW_DATA  + '?ar_gp_image_linking=' + obj.id, 'GET').then(async response => {
       let data = response.status === 200 ? (response ?.data ?.imgOverviewData ?? []) : [];
       setState({...state, imageItems: data.filter(val => val.id === obj.id), showItemOverview: true});
     })
   }

   const overviewDetails = () => {
     const {imageItems} = state;
     return(
       <reactbootstrap.Modal size = "xl" show={state.showItemOverview} onHide = {()=> setState({...state, showItemOverview:false, imageItems: []}) }>
          <reactbootstrap.Modal.Header closeButton>
            <p className='common-color' style={{textAlign : 'center', width:'100%', fontSize : 'large' }}> {t('Linked details')}</p>
          </reactbootstrap.Modal.Header>
           <reactbootstrap.Modal.Body>
           <reactbootstrap.Table responsive bordered hover>
           <thead style={{ backgroundColor: '#EC661C', color: '#fff', position: 'sticky', top: '0', textAlign: 'center' }}>
           <tr style={{ textAlign: 'center' }}>
           <th>{t('Images')}</th>
           <th>{t('User')}</th>
           <th>{t('Date and time')}</th>
           <th>{t('Items')}</th>
           </tr>
           </thead>
           <tbody>
           {imageItems && imageItems.map(value=>{
             return <tr style={{textAlign:'center'}} >
             <td><span><img src={window.backendURL + value.filePath} style={{ width: '5rem' }}/></span></td>
             <td>{value.userName}</td>
             <td>{value.updated_at}</td>
             <td>{getItems(value.items)}</td>
             </tr>})}
             </tbody>
             </reactbootstrap.Table>
           </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal>
     )
   }

   const getItems=(itemsData)=>{
     let table = [];
     Object.values(itemsData).map(value=>{
     table.push(
         <tr className="remove-border" >
             <td><img src={window.backendURL + value.filePath} style={{width: "1rem"}}/></td>
             <td>{value.itemName}</td>
             <td>{value.webFormCode}-{value.webFormName}-{value.webFormVersion}</td>
         </tr>
     );
     return 1;
   });
     return table;
   }

  return (
    <Can
       perform = "Access_groundplan,E_groundplan_editor,V_groundplan_editor"
       yes = {() => (
       <React.Fragment>
        <reactbootstrap className="" style={{width:'100%', display:'block', marginBottom:'5%', marginTop :'2%'}}>
           {getRenderContent()}
           {zonePopUp()}
           {colorPicker()}
           {showItemPopUp()}
           {overviewDetails()}
        </reactbootstrap>
       </React.Fragment>
      )}
      no={() =>
          <AccessDeniedPage />
      }
    />
  );
}
export default translate(React.memo(GroundPlanZones));
