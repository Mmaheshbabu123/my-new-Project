import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import * as reactbootstrap from 'react-bootstrap';
import { Link } from 'react-router-dom';
import TreeMenu from 'react-simple-tree-menu'
import renderhtml from 'react-render-html';
import { datasave } from '../_services/db_services';
import Select from 'react-select';
import Edit from '../images/edit_icon.png'
import View from '../images/view-file.png'
import Memo from '../Memo/Memo';
import MemoPrivate from '../images/memoprivate.png';
import MemoGeneral from '../images/memogeneral.png';
import Can from '../_components/CanComponent/Can';
import BlancoCan from '../_components/CanComponent/BlancoCan';
//import './DocumentHeader.css';

// import folderlogo from './folder-icon.png';
// import documentlogo from './document-logo.png';
// import addfolder from './addfolder.png';
// import adddocument from './adddocument.png';
class TagsReports extends Component {
  constructor(props) {
    super(props)
    // this.getButton = this.getButton.bind(this)

    this.state = {
      blanco_data: {},
      testdata: "testdata",
      type: this.props.type,
      id: this.props.id,
      tags:'',


    }

  }
  componentDidMount() {
    var url = window.Linkedtags + '/' + this.props.id + '/' + this.props.current_type + '/' + window.TAGS_ENTITY;
    datasave.service(url, "GET")
        .then(result => {

        });
  }

  render() {
    const DISPLAY = 'inline-flex';
    return (
      <div className="icon-items">

        {/* <reactbootstrap.FormGroup> */}
        {/* <div  > */}
        {/* <reactbootstrap.Button className="btn btn-primary" type='button' color="primary"> Open </reactbootstrap.Button >
                        &nbsp;&nbsp;&nbsp; */}
        {/* <reactbootstrap.Button  > Revise </reactbootstrap.Button>  &nbsp;&nbsp;&nbsp; */}
        {/* <reactbootstrap.Button onClick={() => this.props.actionEdit(this.props.id,this.props.current_type,"edit",this.props.addtype,this.props.manual_id)} > Edit </reactbootstrap.Button>  &nbsp;&nbsp;&nbsp; */}
        {/* <img src={Edit} alt="Logo" style={{ width: WIDTH }} onClick={() => this.props.actionEdit(this.props.id, this.props.current_type, "edit", this.props.addtype, this.props.manual_id)} /> */}
        {this.props.addtype !== 'document' &&
          <BlancoCan
            perform={this.props.rights}
            type="curd"
            owner={this.props.owner}
            yes={() => (

              <div style={{ marginLeft: '3px', marginRight: '3px' }}><i class="overall-sprite overall-sprite-mseditc" alt="Logo" title="Edit" onClick={() => this.props.actionEdit(this.props.id, this.props.current_type, "edit", this.props.addtype, this.props.manual_id)}></i>
              </div>
            )} />
        }
        {/* <img src={View} alt="Logo" style={{ width: WIDTH }} onClick={() => this.props.actionEdit(this.props.id, this.props.current_type, "view", this.props.addtype, this.props.manual_id)} /> */}
        {/*<div style={{ marginLeft: '3px', marginRight: '3px' }}>
                    <i class="sprite-manual sprite-memopersonal" alt="Logo" title="View" onClick={() => this.props.actionEdit(this.props.id, this.props.current_type, "view", this.props.addtype, this.props.manual_id)}></i>
                </div>*/}
        {this.props.addtype === 'document' &&
          <BlancoCan
            perform={this.props.rights}
            type="curd"
            owner={this.props.owner}
            yes={() => (
              <div class="dropdown">
                <span class="dropbtn"><i style={{ marginLeft: '5px' }} class="folder-icons folder-icons-menu"></i></span>
                <div class="dropdown-content">
                  <div style={{ marginLeft: '3px', marginRight: '3px', display: 'inline-flex', alignItems: 'center', width: '100%', borderBottom: '1px solid #e6e6e6' }}>
                    <div onClick={() => this.props.actionEdit(this.props.id, this.props.current_type, "edit", this.props.addtype, this.props.manual_id)} className="drop-down-text" style={{ width: '85%', fontSize: '12px' }} >Edit </div>
                    <div><i class="overall-sprite overall-sprite-mseditc" alt="Logo" title="Edit" onClick={() => this.props.actionEdit(this.props.id, this.props.current_type, "edit", this.props.addtype, this.props.manual_id)}></i>
                    </div>
                  </div>
                  {/* <img src={MemoGeneral} alt="general memo" style={{ width: WIDTH }} onClick={() => this.props.memoId(window.public_memo, this.props.id,this.props.addtype,this.props.current_type, "public memo",this.props.manual_id)} /> */}
                  <div className="two " style={{ marginLeft: '3px', marginRight: '3px', display: 'inline-flex', alignItems: 'center', width: '100%', borderBottom: '1px solid #e6e6e6' }}>
                    <div onClick={() => this.props.memoId(window.public_memo, this.props.id, this.props.addtype, this.props.current_type, "public memo", this.props.manual_id)} className="drop-down-text" style={{ width: '85%', fontSize: '12px' }}>General memo </div>
                    <div><i class="status-sprite status-sprite-gmemoc" alt="general memo" title="General Memo" onClick={() => this.props.memoId(window.public_memo, this.props.id, this.props.addtype, this.props.current_type, "public memo", this.props.manual_id)}></i></div>
                  </div>
                  {/* <img src={MemoPrivate} alt="private memo" style={{ width: WIDTH }} onClick={() => this.props.memoId(window.private_memo, this.props.id,this.props.addtype,this.props.current_type, "private memo",this.props.manual_id)} /> */}
                  <div style={{ marginLeft: '3px', marginRight: '3px', display: 'inline-flex', alignItems: 'center', width: '100%', borderBottom: '1px solid #e6e6e6' }}>
                    <div onClick={() => this.props.memoId(window.private_memo, this.props.id, this.props.addtype, this.props.current_type, "private memo", this.props.manual_id)} className="drop-down-text" style={{ width: '85%', fontSize: '12px' }}>Private memo </div>
                    <div><i class="folder-icons folder-icons-pmemo" alt="private memo" title="Private Memo" onClick={() => this.props.memoId(window.private_memo, this.props.id, this.props.addtype, this.props.current_type, "private memo", this.props.manual_id)}></i></div>
                  </div>
                  <Can
                    perform="CLONE_DOC"
                    yes={() => (
                      <div style={{ marginLeft: '3px', marginRight: '3px', display: 'inline-flex', alignItems: 'center', width: '100%', borderBottom: '1px solid #e6e6e6' }}>
                        <div onClick={() => this.props.actionHeader(this.props.id, this.props.current_type, 'create', 'document', this.props.manual_id)} className="drop-down-text" style={{ width: '85%', fontSize: '12px' }}>Clone </div>
                        <div> <i class="status-sprite status-sprite-webformc" alt="private memo" title='clone' onClick={() => this.props.actionHeader(this.props.id, this.props.current_type, 'create', 'document', this.props.manual_id)}></i></div>
                      </div>
                    )}
                  />
                  {this.props.doc_type <= 3 &&
                    <div style={{ marginLeft: '3px', marginRight: '3px', display: 'inline-flex', alignItems: 'center', width: '100%', borderBottom: '1px solid #e6e6e6' }}>
                      <div onClick={() => this.props.actionHeader(this.props.id, this.props.current_type, 'create', 'editor', this.props.manual_id, this.props.propsData, this.props.code)} className="drop-down-text" style={{ width: '85%', fontSize: '12px' }}>Open in Editor</div> <div> <i class="folder-icons folder-icons-oinedit" alt="Editor" title='Open in editor' onClick={() => this.props.actionHeader(this.props.id, this.props.current_type, 'create', 'editor', this.props.manual_id, this.props.propsData, this.props.code)}></i> </div>
                    </div>
                  }
                  {this.props.doc_type <= 3 &&
                    <div style={{ marginLeft: '3px', marginRight: '3px', display: 'inline-flex', alignItems: 'center', width: '100%',borderBottom: '1px solid #e6e6e6' }}>
                      <div onClick={() => this.props.actionHeader(this.props.id, this.props.current_type, 'preview', 'preview', this.props.manual_id, this.props.propsData, this.props.code)} className="drop-down-text" style={{ width: '85%', fontSize: '12px' }}>Preview</div> <div> <i class="status-sprite status-sprite-previewc" alt="Editor" title='Preview' onClick={() => this.props.actionHeader(this.props.id, this.props.current_type, 'create', 'editor', this.props.manual_id, this.props.propsData, this.props.code)}></i> </div>
                    </div>
                  }
                  {this.props.doc_type <= 3 &&
                    <div style={{ marginLeft: '3px', marginRight: '3px', display: 'inline-flex', alignItems: 'center', width: '100%',borderBottom: '1px solid #e6e6e6' }}>
                      <div onClick={() => this.props.uploadDocument(this.props.id, this.props.doc_type)} className="drop-down-text" style={{ width: '85%', fontSize: '12px' }}>Import Document</div> <div> <i class="status-sprite status-sprite-importc" alt="Import document" title='Import document' onClick={() => this.props.uploadDocument(this.props.id, this.props.doc_type)}></i> </div>
                    </div>
                  }
                  {this.props.status <= 2 &&
                    <div style={{ marginLeft: '3px', marginRight: '3px', display: 'inline-flex', alignItems: 'center', width: '100%',borderBottom: '1px solid #e6e6e6' }}>
                      <div onClick={() => this.props.deleteDocument(this.props.id, this.props.status, this.props.manual_id)} className="drop-down-text" style={{ width: '85%', fontSize: '12px' }}>Delete Document</div> <div> <i class="overall-sprite overall-sprite-msdeletec" alt="Delete document" title='Delete document' onClick={() => this.props.deleteDocument(this.props.id, this.props.status, this.props.manual_id)}></i> </div>
                    </div>
                  }
                  <div style={{ marginLeft: '3px', marginRight: '3px', display: 'inline-flex', alignItems: 'center', width: '100%', }}>
                    <div  onClick={() => this.props.openDocument(this.props.id) } className="drop-down-text" style={{ width: '85%', fontSize: '12px' }}>Object</div>
                    {/* <div> <i class="folder-icons folder-icons-oinedit" alt="Import document" title='Import document' onClick={() => this.props.openDocument(this.props.id, this.props.doc_type)}></i> </div> */}
                  </div>

                </div>
              </div>
            )}
          />
        }
      </div>
    );
  }
}

export default TagsReports
