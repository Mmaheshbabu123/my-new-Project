import React, { Component } from 'react';
import TreeMenu from 'react-simple-tree-menu'
import renderhtml from 'react-render-html';
import { datasave } from '../_services/db_services';
import TagsReports from './TagsReports';
import FolderStructure from '../Folder/Folder';
import DocumentStructure from '../Document/Document';
import Memo from '../Memo/Memo';
import { Input, ListGroup, ListGroupItem } from 'reactstrap';
import folderlogo from '../Blanco/folder-icon.png';
import documentlogo from '../Blanco/document.png';
import addfolder from '../Blanco/addfolder.png';
import adddocument from '../Blanco/adddocument.png';
import '../Blanco/BlancoStructure.css';
import Can from '../_components/CanComponent/Can';
import BlancoCan from '../_components/CanComponent/BlancoCan';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';

import '../Css/DocumentIcons.css';
import { persistor, store } from '../store';
import _ from "lodash";
import { translate } from '../language';
import Pdf from '../_components/ObjectComponents/Pdf';
import { browserHistory } from 'react-router';
import { OCAlert } from '@opuscapita/react-alerts';



class ManualStructure extends Component {
    constructor(props) {
        super(props)
        this.actionHeader = this.actionHeader.bind(this)
        this.getButton = this.getButton.bind(this)
        this.actionEdit = this.actionEdit.bind(this)
        this.updateFolder = this.updateFolder.bind(this)
        this.onClickNode = this.onClickNode.bind(this)
        this.handleCycle = this.handleCycle.bind(this)
        this.onDoubleClickNode = this.onDoubleClickNode.bind(this)
        this.deleteDocument = this.deleteDocument.bind(this);
        this.memoId = this.memoId.bind(this)
        this.openDocument = this.openDocument.bind(this);
        this.deleteFolder = this.deleteFolder.bind(this);
        if (this.props.match !== undefined) {
            var blancoid = this.props.match.params.id;
        }
        else {
            var blancoid = this.props.blanco_id;
        }
        this.state = {
            blanco_data: {},
            folderDetails: {},
            testdata: "testdata",
            showDocHeader: false,
            showFolder: false,
            showMemo: false,
            showpdf: false,
            blanco_id: blancoid,
            credentials: {},
            openNode: [],
            activeOpenNode: '',
            t: props.t,
            doc_type: '',
            initialOpenNodes: [],
        }
    }
    componentDidMount() {
        let userData = store.getState();
        if (this.props.match !== undefined) {
            var url = window.FETCH_FOLDER + '/' + this.props.match.params.id + '?pid=' + userData.UserData.user_details.person_id;
        }
        else {
            var url = window.FETCH_MANUALS + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id;
        }
        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    folderDetails: result,
                })
                this.displayFolder(result)
            });

    }
    componentDidUpdate(prevProps, prevState) {
        let userData = store.getState();
        if (this.props.blanco_id !== undefined) {
            this.state.blanco_id = this.props.blanco_id;
        }
        if (prevProps.manual_id !== this.props.manual_id) {
            var url = window.FETCH_MANUALS + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id;
            datasave.service(url, "GET")
                .then(result => {
                    this.setState({
                        folderDetails: result,
                    })
                    this.displayFolder(result)
                });
        }
    }
    getButton(key, props, keys) {
        this.setState({
            showDocHeader: props.key_type,
        })
    }
    updateFolder(manual_id) {
        let userData = store.getState();
        var url = window.FETCH_MANUALS + '/' + manual_id + '?pid=' + userData.UserData.user_details.person_id;
        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    folderDetails: result,
                })
                this.displayFolder(result)
            });
    }
    memoId(type_id, ref_id) {
        const credentials = {};
        credentials.type_id = type_id;
        credentials.ref_id = ref_id;
        this.setState({
            credentials: credentials,
            showMemo: true,
        })
    }
    deleteDocument(doc_id, status, manual_id) {
      let url = window.DELETE_DOC + '/' + doc_id;
      datasave.service(url, "POST")
          .then(result => {
            this.updateFolder(manual_id);
            OCAlert.alertSuccess('Document deleted successfully!', { timeOut: window.TIMEOUTNOTIFICATION});

            // alert('Document deleted successfully');
          });
    }
    deleteFolder(fol_id, manual_id) {
      let url = window.FOLDER_DELETE + '/' + fol_id;
      datasave.service(url, "PUT")
          .then(result => {
            this.updateFolder(manual_id);
            OCAlert.alertSuccess('Folder deleted successfully!', { timeOut: window.TIMEOUTNOTIFICATION});

            // alert('Folder deleted successfully');
          });
    }
    actionEdit(id, parent_type, action, addtype, manual_id,rights= '', priority = '') {
        const credentials = {};
        credentials.parent_type = parent_type;
        credentials.parent_id = id;
        credentials.manual_id = manual_id;
        credentials.manual_flag = 1;
        credentials.blanco_id = this.state.blanco_id;
        credentials.action = action;
        credentials.addtype = addtype;
        credentials.rights = rights;
        credentials.priority = priority;
        if (addtype === 'folder') {
            this.setState({
                credentials: credentials,
                showFolder: true,
                showDocument: false,
                showMemo: false,
            })
        }
        else {
            this.setState({
                credentials: credentials,
                showDocument: true,
                showFolder: false,
                showMemo: false,
            })
        }
    }
    handleCycle(id, parent_type, action, addtype, manual_id,rights='', priority = '') {
        this.updateFolder(manual_id);
        this.actionEdit(id, parent_type, action, addtype, manual_id,rights, priority);
    }
    actionHeader(id, parent_type, action, addtype, manual_id, label = '', code = '',rights='', priority = '') {
        const credentials = {};
        credentials.parent_type = parent_type;
        credentials.parent_id = id;
        credentials.addtype = addtype;
        credentials.blanco_id = this.state.blanco_id;
        credentials.manual_id = manual_id;
        credentials.manual_flag = 1;
        credentials.action = action;
        credentials.label = label;
        credentials.code = code;
        credentials.rights = rights;
        credentials.priority = priority;
        this.setState({
            showFolder: false,
            showDocument: false,
            showMemo: false,
        })
        if (addtype === 'folder') {
            this.setState({
                credentials: credentials,
                showFolder: true,
                showDocument: false,
                showMemo: false,
            })
        }

    }
    /*
    * @param data takes the folder object which is to be created.
    * Creates an object with the childrens which is specified in data param and sets to the blanco state.
    */
    displayFolder(data) {
        let finalData = {};
        let folderData = data;
        var touched_ids = [];
        Object.keys(folderData).map(function (key) {
            folderData[key].childrens.forEach(function (id) {
                folderData[key].nodes[id] = folderData[id];
                touched_ids.push(id);
            });
            finalData[key] = folderData[key];
        });
        touched_ids.forEach(function (id) {
            delete finalData[id];
        });
        this.setState({
            blanco_data: finalData,
        })
    }
    onClickNode(key, label, props) {
        // return false;
        this.debouncedClickEvents = this.debouncedClickEvents || [];

        // Each click we store a debounce (a future execution scheduled in 250 milliseconds)
        const callback = _.debounce(_ => {
            // YOUR ON CLICKED CODE

            this.debouncedClickEvents = [];
        }, 500);
        this.debouncedClickEvents.push(callback);

        // We call the callback, which has been debounced (delayed)
        callback();
        // We call the callback, which has been debounced (delayed)
    }
    onDoubleClickNode(key, label, props) {
        if (this.debouncedClickEvents.length > 0) {
            _.map(this.debouncedClickEvents, (debounce) => debounce.cancel());
            this.debouncedClickEvents = [];
        }
        OCAlert.alertWarning('Double click!', { timeOut: window.TIMEOUTNOTIFICATION1});

        // alert('double click');
    }

    openDocument(doc_id){
        const credentials = {};
        credentials.doc_id = doc_id;
        const url = window.GET_S3OBJECT_URL+'/'+doc_id;
        datasave.service(url, 'GET', 'doc_id')
            .then(response => {
               this.checkIfDocExist(response[0]["file_path"],doc_id)
            });
    }
    checkIfDocExist(response,doc_id)
    {
        if(response !== null){
            window.open('/previewrevisionentities/'+doc_id)
        }else{
            OCAlert.alertWarning('There is no object available!', { timeOut: window.TIMEOUTNOTIFICATION1});

            // alert("There is no object available");
        }
    }

    render() {
        const { t } = this.state;
        const DEFAULT_PADDING = 5;
        const ICON_SIZE = 4;
        const LEVEL_SPACE = 8;
        const WIDTH = '25px';
        const HEIGHT = '25px';
        const DISPLAY = 'inline-flex';
        const WIDTH_DYNAMIC = 25;
        const ToggleIcon = ({ on }) => <span style={{ marginRight: 4 }}>{on ? '-' : '+'}</span>;
        const ListItem = ({
            level = 0,
            key,
            doc_type,
            doc_type_id,
            status,
            rights,
            priority,
            owner,
            hasNodes,
            isOpen,
            type_id,
            current_type,
            manual_id,
            label,
            code,
            searchTerm,
            openNodes= true,
            doc_status,
            childrens,
            initialOpenNodes = true,
            ...props
        }) => (
                <div className="folder-manual-section">
                    <BlancoCan
                        perform={rights}
                        owner={owner}
                        type="view"
                        yes={() => (
                            <ListGroupItem
                                className="left-border list-zindex"
                                {...props}
                                style={{
                                    paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
                                    paddingRight: 0,
                                    cursor: 'pointer',
                                }}
                                key={key}
                            >
                                <div className="list-items-structure" style = {{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
                                    {hasNodes && <ToggleIcon on={isOpen} />}
                                    {!hasNodes && <span style={{ marginRight: 4 }}> &nbsp;</span>}
                                    {current_type === 'manual' &&
                                        <i class="folder-icons folder-icons-accounts" title="Manual" style={{ marginRight: '5px' }}> </i>
                                    }
                                    {current_type === 'folder' &&
                                        <i class="folder-icons folder-icons-folder" title="Folder" style={{ marginRight: '5px' }}> </i>
                                    }
                                    {current_type === 'document' &&
                                        <i class={'folder-icons folder-icons-' + doc_type} title={doc_type} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id)} />
                                    }
                                    {current_type === 'document' &&
                                        <i class={'sprite-document2 sprite-document2-' + status} title={status} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id)} />
                                    }

                                    <span title={label} className={'folderstructure-label-' + current_type} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id,rights, priority)} >
                                        {label}
                                    </span>
                                    {current_type !== 'document' &&
                                        <Can
                                            perform="E_folder"
                                            yes={() => (
                                                <BlancoCan
                                                    perform={rights}
                                                    owner={owner}
                                                    type="curd"
                                                    yes={() => (
                                                        <i class="overall-sprite overall-sprite-msfolderc" alt="Logo" title="Add Folder" onClick={this.actionHeader.bind(this, props.key_type, current_type, 'create', 'folder', manual_id, '', '')}></i>
                                                    )}
                                                />
                                            )}
                                        />
                                    }
                                    {current_type === 'folder' &&
                                        <Can
                                            perform="E_folder"
                                            yes={() => (
                                                <BlancoCan
                                                    perform={rights}
                                                    owner={owner}
                                                    type="curd"
                                                    yes={() => (
                                                        <i class="overall-sprite overall-sprite-msdocumentc" alt="Logo" title="Add Document" style={{ marginTop: '5px' }} onClick={this.actionHeader.bind(this, props.key_type, current_type, 'create', 'document', manual_id, '', '')}></i>
                                                    )}
                                                />
                                            )}
                                        />
                                    }
                                    {current_type === 'folder' && childrens.length === 0 &&
                                      <>
                                      <div> <i class="overall-sprite overall-sprite-msdeletec" alt="Delete folder" title='Delete folder' onClick={() => this.deleteFolder(props.key_type, manual_id)}></i> </div>
                                      </>
                                    }
                                    <TagsReports
                                      status = {doc_status}
                                      code = {code}
                                      propsData={label}
                                      id={props.key_type}
                                      current_type={current_type}
                                      addtype={type_id}
                                      manual_id={manual_id}
                                      actionEdit={this.actionEdit}
                                      memoId={this.memoId}
                                      actionHeader={this.actionHeader}
                                      rights={rights}
                                      priority={priority}
                                      owner={owner}
                                      doc_type={doc_type_id}
                                      deleteDocument = {this.deleteDocument}
                                      openDocument ={this.openDocument}
                                    />
                                    {/* } */}
                                </div>
                            </ListGroupItem>
                        )}
                    />
                </div>
            );
        return (
            <div style={{}} className="container-fluid mb-5 pt-2">
                <div className="row">
                    <div id ="editor-extra-wrapper" className="col-md-1 col-lg-1">
                        <h3 style={{ display: 'none' }}>simple</h3>
                    </div>
                    <>
                        <Can
                            perform="R_manual,E_manual,R_folder,E_folder"
                            yes={() => (
                                <>
                                    <Can
                                        perform="R_folder,E_folder,R_manual,E_manual"
                                        yes={() => (
                                            <>
                                                <>
                                                    <div id="manualstructure" className="col-lg-3 col-md-3">
                                                        {/* <div className="col-md-12"> */}
                                                        <div className="manualstructure">
                                                            <div className="card">
                                                                <div className="manual-title-wrapper header">
                                                                    <div class="d-flex">
                                                                        <div class="mr-auto p-0"><span class="head py-1 px-2">{t('Manual structure')}</span></div>
                                                                    </div>
                                                                </div>
                                                                <TreeMenu
                                                                    data={this.state.blanco_data}
                                                                    hasSearch='false'
                                                                    initialOpenNodes={this.state.blanco_data}
                                                                    //openNodes={this.state.blanco_data}
                                                                    onClickItem={({ key, label, ...props }) => {
                                                                        this.onClickNode(key, label, props);
                                                                    }}
                                                                    onDoubleClickItem={({ key, label, ...props }) => {
                                                                        this.onClickNode(key, label, props);
                                                                    }}
                                                                    debounceTime={125}
                                                                // activeKey={this.state.activeOpenNode}
                                                                //openNodes={this.state.openNode}
                                                                >
                                                                    {({ search, items }) => (
                                                                        <>

                                                                            <Input style={{}} onChange={e => search(e.target.value)} placeholder={t("Type and search")} />
                                                                            <div className="sim">
                                                                                <Can
                                                                                    perform="R_manual,E_manual,E_folder"
                                                                                    yes={() => (

                                                                                        <ListGroup className="folder-left-list-group">

                                                                                            {items.map(props => (
                                                                                                <ListItem {...props} />
                                                                                            ))}


                                                                                        </ListGroup>

                                                                                    )}

                                                                                />
                                                                                <div style={{ height: '170px', visibility: 'hidden', }}></div>

                                                                            </div>
                                                                        </>
                                                                    )}
                                                                </TreeMenu>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div id="fde-wrapper" style={{ backgroundColor: '#f4f4f4' }} className="col-lg-8 col-md-8 float-left px-0 pt-0">
                                                        {this.state.showFolder &&
                                                            <FolderStructure credentials={this.state.credentials}
                                                                updateFolder={this.updateFolder.bind(this)}
                                                            />
                                                        }
                                                        {this.state.showDocument &&
                                                            <DocumentStructure credentials={this.state.credentials}
                                                                updateFolder={this.updateFolder.bind(this)}
                                                                handleCycle={this.handleCycle.bind(this)}

                                                            />
                                                        }
                                                        {this.state.showMemo &&
                                                            <Memo credentials={this.state.credentials}
                                                                memoId={this.memoId.bind(this)}
                                                            />

                                                        }
                                                    </div>
                                                </>
                                            </>
                                        )}
                                    />
                                </>
                            )}
                            no={() =>
                                <AccessDeniedPage />
                            }
                        />
                    </>
                </div>
            </div>
        );
    }
}



export default translate(ManualStructure)
