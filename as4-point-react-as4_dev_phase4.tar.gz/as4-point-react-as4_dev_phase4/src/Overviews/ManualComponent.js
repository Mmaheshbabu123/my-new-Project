import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import BlancoStructure from '../Blanco/BlancoStructure'
import { PrivateRoute } from '../_components/PrivateRoute';
import ManualList from '../Overviews/ManualList';
import ManualStructure from '../Overviews/ManualStructure';
import { translate } from '../language';

class ManualComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            manual_id: '',
            blanco_id: '',
            addmanual: true,
        }
        this.handleChange = this.handleChange.bind(this);
    }
    handleChange(e) {
        var result = e.split('-');
        this.setState({
            manual_id: result[0],
            blanco_id: result[1],
        })
    }
    componentDidMount() {
        var url = window.FETCH_MANUAL_NAMES;
        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    manual_id: result[0]['id'],
                    blanco_id: result[0]['blanco_id'],
                })
            });
    }
    render() {

        return (
            <>
              <ManualList handleChange={this.handleChange.bind(this)} />
              <ManualStructure manual_id={this.state.manual_id} blanco_id={this.state.blanco_id} />
            </>
        );
    }
}

export default translate(ManualComponent)
