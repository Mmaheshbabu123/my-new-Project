import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { translate } from '../language';

class ManualList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            manual_list: [],
            manual_id: this.props.manual_id,
            handleChange: this.props.handleChange,
        }

    }
    componentDidMount() {
        var url = window.FETCH_MANUAL_NAMES;
        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    manual_list: result,
                })
            });
    }
    render() {

        return (
                    <div style={{marginLeft: '4.4rem'}} className="container input-padd">
                        <div className="col-3 input-padd">
                            <reactbootstrap.Form.Control as="select" name="manual_id"
                                value={this.state.manual_id}
                                onChange={e => this.props.handleChange(e.target.value)} >
                                {this.state.manual_list.map(manuals => <option value={manuals.id + '-' + manuals.blanco_id} >{manuals.name}</option>)}
                            </reactbootstrap.Form.Control>
                        </div>
                    </div>
        );
    }
}

export default translate(ManualList)
