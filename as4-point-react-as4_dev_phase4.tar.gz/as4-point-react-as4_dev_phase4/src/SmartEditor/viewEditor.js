import React from 'react';
import {translate} from '../language';
import  SmartEditor from  './SmartEditor';
class viewEditor extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      insertmasterdata:true
    }
  }
removeEditorFrame =(status)=>{
  const {history} = this.props
  this.props.history.push('/manuals/management');
}
addmasterdata =()=> {
    document.getElementById('editor-frame-wrapper').setAttribute("class", "col-md-8 col-lg-8 px-0 py-0");
    document.getElementById('fmd-wrapper').setAttribute("style", "display:block;");
    document.getElementById('office_frame').setAttribute("style", "margin-left:-181px");
    this.setState({ insertmasterdata: false });
}
closemasterdata = ()=> {
    document.getElementById('editor-frame-wrapper').setAttribute("class", "col-md-11 col-lg-11 px-0 py-0");
    document.getElementById('fmd-wrapper').setAttribute("style", "display:none;");
    document.getElementById('office_frame').setAttribute("style", "margin-left:-224px");
    this.setState({ insertmasterdata: true });
}
  render(){
    const {insertmasterdata} =  this.state
      const obj = JSON.parse(this.props.match.params.docobj)
      return(
        <>
        <div className = 'col-md-12 row'>
        <div className = 'col-md-1'>
        </div>
        <div className = 'col-md-11'>
        <SmartEditor type={obj.doc_type} fileexists = {obj.fileexists}
          path={obj.docPath} standards={obj.standards} templates={obj.templates}
          did={obj.editorDocId} code={obj.credentials.code} name={obj.credentials.label.replace(obj.credentials.code + '-', '')}
          minimize={true} removeeditor={this.removeEditorFrame} minimizeeditor={undefined}
          addmasterdata={this.addmasterdata} closemasterdata={this.closemasterdata}
          updateeditor={this.updateEditorFrame}
          insertmasterdata={insertmasterdata}
        />
        </div>
        </div>
        </>
      );
  }

}
export default translate(viewEditor)
