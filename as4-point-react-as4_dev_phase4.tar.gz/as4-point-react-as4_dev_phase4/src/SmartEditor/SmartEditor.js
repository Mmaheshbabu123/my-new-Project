import React from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import axios from 'axios';
import {translate} from '../language';
import FMDSmartEditor from '../FrameMasterData/FMDSmartEditor';
import { PagePermissions } from '../_components/CanComponent/PagePermissions';
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from '../store';

class SmartEditor extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      no_of_tabs: '',
      tab_key: 'general',
      language: [],
      showEditor: false,
      langId: 3,
      lang: 'Dutch',
      previewObj: {},
      previewsrc: false,
      previewurl: '',
      langs:[],
      t:props.t,
      langPicked:'Dutch',
      langPicker: false,
      standPicked: 'general',
      langConfirmYes: 0,
      standId: 0,
    }
    this.handleLanguage = this.handleLanguage.bind(this);
  }
  componentDidMount() {
    let langs;
    datasave.service(window.DOCLANGS + '/' + this.props.did, 'GET')
      .then(response =>{
        langs = response;
        datasave.service(window.GET_ALL_LANGUAGES, 'GET')
          .then(response => {
            const language = response[0].language;
            const languageId = response[0].id;
            this.setState({
              language: response,
              langs:langs
            });
            this.openEditorOnLoad(this.state.tab_key, this.props.path, language, languageId);
          });
      });
  }
  componentDidUpdate(prevProps, prevState){
    if(this.state.lang !== prevState.lang ){
      datasave.service(window.DOCLANGS + '/' + this.props.did, 'GET')
        .then(response =>{
          this.setState({
            langs: response,
          });
        });
    }

  }
  setLanguage(event){
    let prevObj = this.state;
    let title = this.state.title;
    var id = this.state.langId;
    var lang = this.state.lang;
    this.setState(
      {
        title: title,
        lang: lang,
        langId: id,
        previewObj: prevObj,
        langPicked: event.target.value,
        //langPicker:false,
      });

  }
  setStandards(event) {
    let prevObj = this.state;
    let title = this.state.title;
    var lid = this.state.langId;
    var lang = this.state.lang;
    var index = event.target.selectedIndex;
    var optionElement = event.target.childNodes[index]
    var id = optionElement.getAttribute('id');
    this.setState(
      {
        title: title,
        lang: lang,
        langId: lid,
        previewObj: prevObj,
        standPicked: id,
        //langPicker:false,
      });

  }
  openEditor(event, title, path) {
    console.log(title);
    console.log(path);
    let prevObj = this.state;
    let buildPath = buildTitle(path, title, event.target.value);
    var index = event.target.selectedIndex;
    var optionElement = event.target.childNodes[index]
    var id = optionElement.getAttribute('id');
    var lang = event.target.value ;
    this.setState({
      title: title,
      lang: lang,
      langId: id,
      previewObj: prevObj,
      langConfirmYes: 0,
    });
  }
  copyEditorContent(event, title, path) {
    this.setState({
      langPicker: true,
      langConfirmYes: 0,
    });
  }

  openEditorOnLoad(title, path, language, languageId) {
    let prevObj = this.state;
    let buildPath = buildTitle(path, title, language);
    var id = languageId;
    var lang = language;
    this.setState(
      {
        title: title,
        lang: lang,
        langId: id,
        previewObj: prevObj,
        langPicker: false,
      });
  }
  openPreview(e) {
    datasave.service(window.DOC_PREVIEW + '/3' + '/' + this.props.did + '/general/Dutch' + '?lang=' + this.state.lang,'GET')
      .then(response =>{
        if(response.status === 200){
            window.open(window.location.origin + '/previewrevision/' + this.props.did + '?content=' + response.content, '_blank');
        }
        else{
          OCAlert.alertError(response.message, { timeOut: window.TIMEOUTNOTIFICATION1});

          // alert(response.message);
        }

      });
      }
  handleLanguage(tab_key) {
    console.log(this.state.langId);
    this.setState({
      tab_key: tab_key,
      title: tab_key,
      standPicked: tab_key,
      standId: (tab_key === 'general') ? 0 : parseInt(tab_key),
      langPicked: this.state.lang,
      lang: this.state.lang,
    })
  }

  previewDocument(e, lang, props, standard = 'general') {
    let type = props.type;
    let stand = standard;
    let did = props.did;
    let language = lang;
    window.open(window.location.origin + '/previewrevisionentities/' + did, '_blank');
    /*if (type === 3) {
      datasave.service(window.DOC_PREVIEW + '/6' + '/' + did + '/general/Dutch','GET')
        .then(response =>{
          let url = window.location.origin + '/previewrevision/' + did + '?content=' + response[0] + '&header=' + response['header'] + '&footer=' + response['footer'];
          window.open(url, '_blank');
        });
    } else {
      window.open(window.location.origin + '/previewrevisionentities/' + did, '_blank');
    }*/

  }
  hidelangPickerNo(){
    let prevObj = this.state;
    let title = this.state.title;
    var id = this.state.langId;
    var lang = this.state.lang;
    console.log('after lang pick no');
    this.setState(
      {
        title: title,
        lang: lang,
        langId: id,
        previewObj: prevObj,
        langPicker:false,
        langConfirmYes: 0,
      });

  }
  hidelangPickerYes(){
    let prevObj = this.state;
    let title = this.state.title;
    var id = this.state.langId;
    var lang = this.state.lang;
    console.log('after lang pick yes');
    this.setState(
      {
        title: title,
        lang: lang,
        langId: id,
        previewObj: prevObj,
        langPicker:false,
        langConfirmYes: 1,
      });

  }

  render() {
    const { t } = this.state;
    const stand_show = PagePermissions();
    console.log(stand_show);
    var showgeneral = (stand_show) ? 'header_tabs' : 'hidegeneral header_tabs';  
    console.log(this.state.langId);
    if(this.state.langPicker){
    return(
      <reactbootstrap.Modal
          size="lg"
          show={this.state.langPicker}
          onHide={(e)=>this.hidelangPickerNo(e, this.state.tab_key, this.props.path)}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
            <reactbootstrap.Modal.Header closeButton>
                <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                </reactbootstrap.Modal.Title>
             </reactbootstrap.Modal.Header>
                <reactbootstrap.Modal.Body>
                 <h5>{t('Do you want to copy content from existing content?')}</h5>
                 <div className="row language-dropdown">
                 <div className="col-md-6">
                 <span>{t('Language')}</span>
                 <reactbootstrap.Form.Control as="select" onChange={(e)=>this.setLanguage(e,this.state.tab_key, this.props.path)}>
                       <option id='0'>{t('-Select-')}</option>
                       {this.state.langs.map(function(lang){
                         return(
                             <option id={lang.language}>{lang.language}</option>
                         );
                       },this)
                     }
                 </reactbootstrap.Form.Control>
                 </div>
                 <div className="col-md-6">
                 <span>{t('Standard')}</span>
                 {stand_show && this.props.standards.length !== 0 &&
                 <reactbootstrap.Form.Control as="select" onChange={(e)=>this.setStandards(e,this.state.tab_key, this.props.path)}>
                       <option id='0'>{t('-Select-')}</option>
                       <option id='general'>{t('General')}</option>
                      {this.props.standards.map(function(stand){
                         return(
                             <option id={stand.id}>{stand.name}</option>
                         );
                       },this)
                     }
                 </reactbootstrap.Form.Control>
                 }
                 </div>
                </div>
                </reactbootstrap.Modal.Body>
             <reactbootstrap.Modal.Footer>
                  <reactbootstrap.Button className="btn btn-primary preview-btn" onClick={(e)=>this.hidelangPickerYes(e)}>{t('Yes')}</reactbootstrap.Button>&nbsp;&nbsp; &nbsp;&nbsp;
                  <reactbootstrap.Button className="btn btn-primary preview-btn" onClick={(e)=>this.hidelangPickerNo(e)}>{t('No')}</reactbootstrap.Button>
             </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
    );
    }
    else{
      return (
        <>
        {/*{this.props.type === 3 &&
          <div className="smart-editor row">
          <>
          <div className="details-wrap-excel">
          <div className="code-name-smarteditor">
              <reactbootstrap.Button className="btn btn-primary preview-btn-excel" onClick={(e) => this.previewDocument(e,this.state.lang, this.props)}>{t('Preview')}</reactbootstrap.Button>
              </div>
              <div className="code-name-smarteditor">
                  <div className="doc-code">{t('Code')}: {this.props.code}</div>
                  <div className="doc-label">{t('Name')}: {this.props.name}</div>
              </div>
              {this.props.minimize &&
                  <div className="actions-remove-mini">
                      <div id="removeeditor" aria-hidden="true" onClick={()=>this.props.removeeditor(1)}>{t('Close editor')}</div>
                      {this.props.insertmasterdata && <div id="addmasterdata" aria-hidden="true" onClick={this.props.addmasterdata}>{t('Insert masterdata')}</div>}
                      {!this.props.insertmasterdata && <div id="minimizemasterdata" aria-hidden="true" onClick={this.props.closemasterdata}>{t('Minimize masterdata')}</div>}
                      <div id="minimizeeditor" aria-hidden="true" onClick={this.props.minimizeeditor}>{t('Minimize editor')}</div>
                  </div>
              }
              {!this.props.minimize && <div id="expandeditor" aria-hidden="true" onClick={this.props.updateeditor}>{t('Maximize editor')}</div>}

          </div>
          </>
              <Editor {...this.props} langConfirmYes = {this.state.langConfirmYes} standPicked = {this.state.standPicked} langPicked = {this.state.langPicked} langId={this.state.langId} lang={this.state.lang} did = {this.props.did} type = {this.props.type} temps = {this.props.templates} path={this.props.path}/>
              <FMDSmartEditor postmessage = {process.env.REACT_APP_baseURL_office_visio} did = {this.props.did} stateObj = {this.state} />
          </div>
        }*/}
        {/*{this.props.type === 2 &&
          <div className="smart-editor">
          { this.props.type !== 3 && <>
          <div className="details-wrap-excel">
              <div className="code-name-smarteditor">
                  <div className="doc-code">{t('Code')}: {this.props.code}</div>
                  <div className="doc-label">{t('Name')}: {this.props.name}</div>
              </div>
              {this.props.minimize &&
                  <div className="actions-remove-mini">
                      <div id="removeeditor" aria-hidden="true" onClick={()=>this.props.removeeditor(1)}>{t('Close editor')}</div>
                      {this.props.insertmasterdata && <div id="addmasterdata" aria-hidden="true" onClick={this.props.addmasterdata}>{t('Insert masterdata')}</div>}
                      {!this.props.insertmasterdata && <div id="minimizemasterdata" aria-hidden="true" onClick={this.props.closemasterdata}>{t('Minimize masterdata')}</div>}
                      <div id="minimizeeditor" aria-hidden="true" onClick={this.props.minimizeeditor}>{t('Minimize editor')}</div>
                  </div>
              }
              {!this.props.minimize && <div id="expandeditor" aria-hidden="true" onClick={this.props.updateeditor}>{t('Maximize editor')}</div>}

          </div>
          </>
          }
          <div className="col-md-1 lang-label"><reactbootstrap.Form.Label>{t('Language')}</reactbootstrap.Form.Label></div>
          <div className="col-md-3 language-dropdown"><reactbootstrap.Form.Control as="select" onChange={(e)=>this.openEditor(e,this.state.tab_key, this.props.path)}>
              {
                this.state.language.map(function(lang){
                  return(
                      <option selected={this.state.langId == lang.id} id={lang.id}>{lang.language}</option>
                  );
                }, this)
              }
         </reactbootstrap.Form.Control>
         <div className="code-name-smarteditor">
             <reactbootstrap.Button className="btn btn-primary preview-btn-excel" onClick={(e) => this.previewDocument(e, this.state.lang, this.props)}>Preview</reactbootstrap.Button>
             </div>
         </div>
          <div className="row">
              <Editor {...this.props} langConfirmYes = {this.state.langConfirmYes} standPicked = {this.state.standPicked} langPicked = {this.state.langPicked} langId={this.state.langId} lang={this.state.lang} did = {this.props.did} type = {this.props.type} temps = {this.props.templates} path={this.props.path}/>
              <FMDSmartEditor postmessage = {process.env.REACT_APP_baseURL_office} did = {this.props.did} stateObj = {this.state}/>
          </div>
          </div>
        }*/}
        {<div>

          <reactbootstrap.Tabs id="controlled-tab-example" className={showgeneral}
            activeKey={this.state.tab_key}
            onSelect={tab_key => this.handleLanguage(tab_key)}
          >
            <reactbootstrap.Tab eventKey='general' title='General'>
              {!this.state.showEditor &&
                <reactbootstrap.Form.Group className="language-select row" as={reactbootstrap.Col} controlId="formGridState">
                  {/*<div className="col-md-1 lang-label"><reactbootstrap.Form.Label>{t('Language')}</reactbootstrap.Form.Label></div>*/}
                  <div className="col-md-2 language-dropdown"><reactbootstrap.Form.Control as="select" onChange={(e)=>this.openEditor(e,this.state.tab_key, this.props.path)}>
                      {
                        this.state.language.map(function(lang){
                          return(
                              <option selected={this.state.langId == lang.id} id={lang.id}>{lang.language}</option>
                          );
                        }, this)
                      }
                 </reactbootstrap.Form.Control>
                 </div>
                 {<>
                 <reactbootstrap.Button className="btn btn-primary preview-btn" onClick={(e) => this.previewDocument(e, this.state.lang, this.props, 'general')}>{t('Preview')}</reactbootstrap.Button>&nbsp;&nbsp;
                 {this.props.type !== 3 && <reactbootstrap.Button className="btn btn-primary preview-btn" onClick={(e) => this.copyEditorContent(e)}>{t('Copy')}</reactbootstrap.Button>}
                {/* <div className="details-wrap">*/}
                     <div className="code-name-smarteditor col-md-4 code-name-smarteditor-center">
                         <div className="doc-code">{t('Code')}: {this.props.code}</div>
                         <div className="doc-label">{t('Name')}: {this.props.name}</div>
                     </div>
                     {this.props.minimize &&
                         <div className="actions-remove-mini col-md-3">
                             <div id="removeeditor" aria-hidden="true" onClick={()=>this.props.removeeditor(1)}><i title={t('Close editor')} class="webbuttons-sprite webbuttons-sprite-closewebformc"></i></div>
                             {this.props.insertmasterdata && <div id="addmasterdata" aria-hidden="true" onClick={this.props.addmasterdata}><i title={t('Insert masterdata')} class="webbuttons-sprite webbuttons-sprite-insertmasterc"></i></div>}
                             {!this.props.insertmasterdata && <div id="minimizemasterdata" aria-hidden="true" onClick={this.props.closemasterdata}><i title={t('Minimize masterdata')} class="webbuttons-sprite webbuttons-sprite-minimizemasterdatac"></i></div>}
                             { this.props.minimizeeditor !== undefined && <div id="minimizeeditor" aria-hidden="true" onClick={this.props.minimizeeditor}><i title={t('Minimize editor')} class="webbuttons-sprite webbuttons-sprite-minimizewebformc"></i></div>}
                         </div>
                     }
                     {!this.props.minimize && <div id="expandeditor" aria-hidden="true" onClick={this.props.updateeditor}><i title={t("Maximize editor")} class="webbuttons-sprite webbuttons-sprite-minimizewebformc"></i></div>}

                 {/*</div>*/}
                 </>
                 }
              </reactbootstrap.Form.Group>
            }
            {!this.state.showEditor && this.state.title == 'general' &&
              <div className="smart-editor row mr-0">
              <Editor {...this.props} langConfirmYes = {this.state.langConfirmYes} standPicked = {this.state.standPicked} langPicked = {this.state.langPicked} langId={this.state.langId} did = {this.props.did} type = {this.props.type} temps = {this.props.templates} stand = 'general' path={this.props.path} lang = {this.state.lang}/>
              <FMDSmartEditor postmessage = {process.env.REACT_APP_baseURL_office} did = {this.props.did} stateObj = {this.state}/></div>
  	        }
          </reactbootstrap.Tab>
          {stand_show && this.props.type <= 3 &&
            this.props.standards.map(function(standard){
              return (
                <reactbootstrap.Tab eventKey={standard.id} title={standard.name}>
                    {!this.state.showEditor &&
                      <reactbootstrap.Form.Group className="language-select row" as={reactbootstrap.Col} controlId="formGridState">
                  {/*<div className="col-md-1 lang-label"><reactbootstrap.Form.Label>{t('Language')}</reactbootstrap.Form.Label></div>*/}
                  <div className="col-md-2 language-dropdown"><reactbootstrap.Form.Control as="select" onChange={(e)=>this.openEditor(e,this.state.tab_key, this.props.path)}>
                      {
                        this.state.language.map(function(lang){
                          return(
                              <option selected={this.state.langId == lang.id} id={lang.id}>{lang.language}</option>
                          );
                        }, this)
                      }
                 </reactbootstrap.Form.Control>
                 </div>
                 {<>
                 <reactbootstrap.Button className="btn btn-primary preview-btn" onClick={(e) => this.previewDocument(e, this.state.lang, this.props, standard.id)}>{t('Preview')}</reactbootstrap.Button>&nbsp;&nbsp;
                 {stand_show && this.props.type !== 3 && <reactbootstrap.Button className="btn btn-primary preview-btn" onClick={(e) => this.copyEditorContent(e)}>{t('Copy')}</reactbootstrap.Button>}
                {/* <div className="details-wrap">*/}
                     <div className="code-name-smarteditor col-md-4 code-name-smarteditor-center">
                         <div className="doc-code">{t('Code')}: {this.props.code}</div>
                         <div className="doc-label">{t('Name')}: {this.props.name}</div>
                     </div>
                     {this.props.minimize &&
                         <div className="actions-remove-mini col-md-3">
                             <div id="removeeditor" aria-hidden="true" onClick={()=>this.props.removeeditor(1)}><i title={t('Close editor')} class="webbuttons-sprite webbuttons-sprite-closewebformc"></i></div>
                             {this.props.insertmasterdata && <div id="addmasterdata" aria-hidden="true" onClick={this.props.addmasterdata}><i title={t('Insert masterdata')} class="webbuttons-sprite webbuttons-sprite-insertmasterc"></i></div>}
                             {!this.props.insertmasterdata && <div id="minimizemasterdata" aria-hidden="true" onClick={this.props.closemasterdata}><i title={t('Minimize masterdata')} class="webbuttons-sprite webbuttons-sprite-minimizemasterdatac"></i></div>}
                             <div id="minimizeeditor" aria-hidden="true" onClick={this.props.minimizeeditor}><i title={t('Minimize editor')} class="webbuttons-sprite webbuttons-sprite-minimizewebformc"></i></div>
                         </div>
                     }
                     {!this.props.minimize && <div id="expandeditor" aria-hidden="true" onClick={this.props.updateeditor}><i title={t("Maximize editor")} class="webbuttons-sprite webbuttons-sprite-minimizewebformc"></i></div>}

                {/* </div>*/}
                 </>
                 }
              </reactbootstrap.Form.Group>
            }

            { !this.state.showEditor  && this.state.title == standard.id  &&
                      <div className="smart-editor row mr-0"><Editor {...this.props} langPicked = {this.state.langPicked} langConfirmYes = {this.state.langConfirmYes} standPicked = {this.state.standPicked} langId={this.state.langId} t = {this.state.t} did = {this.props.did} type = {this.props.type} temps = {this.props.templates} stand = {this.state.title} path={this.props.path} lang = {this.state.lang} />
                      <FMDSmartEditor postmessage = {process.env.REACT_APP_baseURL_office} did = {this.props.did} stateObj = {this.state}/></div>
                   }
                </reactbootstrap.Tab>
              );
            },this)
          }
          {/*{stand_show && this.props.type === 1 && this.props.standards.length !== 0 &&
          <reactbootstrap.Tab eventKey='preview' title={t('Preview')}>
              {!this.state.showEditor &&
                <reactbootstrap.Form.Group className="col-md-3" as={reactbootstrap.Col} controlId="formGridState">
                  <div className="lang-label"><reactbootstrap.Form.Label>{t('Language')}</reactbootstrap.Form.Label></div>
                  <reactbootstrap.Form.Control className="lang-dropdown" as="select" onChange={(e) => this.openPreview(e)}>
                    {
                      this.state.language.map(function (lang) {
                        return (
                          <option key={lang.id}>{lang.language}</option>
                        );
                      })
                    }
                  </reactbootstrap.Form.Control>
                </reactbootstrap.Form.Group>
              }
            </reactbootstrap.Tab>
          }*/}
          </reactbootstrap.Tabs>
        </div>}
        </>
      );
    }
  }
}
class Editor extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      t:props.t,
    }
  }
  render() {
    const { t } = this.state;
    let title;
    let file_exists;
    const hashcode = process.env.REACT_APP_baseURL_office_hashcode;
    const loleaflet_src = process.env.REACT_APP_baseURL_office + "/loleaflet/" + hashcode + "/loleaflet.html";
    //const loleaflet_src = "http://office-frontend.local:9980/loleaflet/305832f/loleaflet.html";
    const access_token = "aFPBvqgQZ6g0dnDUKHcSRn5HZhCHJugm";
    let WOPISrc = '';
    let WOPI_src_url = window.backendURL;
    let iframeSource = '';
    let standPicked = this.props.standPicked;
    let langPicked = this.props.langPicked;
    let langConfirmYes = this.props.langConfirmYes;
    let Userdata = store.getState();
    let person_id = Userdata.UserData.user_details.person_id;
    let person_name = Userdata.UserData.user_details.user_name;
    if(this.props.type === 1){
      title = buildTitle(this.props.path, this.props.stand, this.props.lang);

      WOPISrc = WOPI_src_url+"/api/wopi/files/" + title + '$' + 2 + '^' + this.props.langPicked + '/' + langPicked + '/' + standPicked + '/' + langConfirmYes + '/' + person_id + '/' + person_name;
      iframeSource = loleaflet_src+"?access_token="+access_token+"&WOPISrc="+WOPISrc+"&title="+title+"&lang=en&closebutton=1&revisionhistory=1&langPicked=" + langPicked + "&standPicked=" + standPicked + "&langConfirmYes=" + langConfirmYes + "&personname=" + person_name + "&personid=" + person_id;
    }
    if(this.props.type ===2){
      title = buildTitle(this.props.path, this.props.stand, this.props.lang);
      //title = this.props.path;//buildTitle(this.props.path, 'general', this.props.lang);
       WOPISrc = WOPI_src_url+"/api/xlsx/wopi/files/" + title + '$' + 2 + '^' + this.props.langPicked + '/' + langPicked + '/' + standPicked + '/' + langConfirmYes + '/' + person_id + '/' + person_name;
      iframeSource = loleaflet_src+"?access_token="+access_token+"&WOPISrc="+WOPISrc+"&title="+title+"&lang=en&closebutton=1&revisionhistory=1&langPicked=" + langPicked + "&standPicked=" + standPicked + "&langConfirmYes=" + langConfirmYes + "&personname=" + person_name + "&personid=" + person_id;
    }
    if(this.props.type === 3){
      title = buildTitle(this.props.path, this.props.stand, this.props.lang);
      //title = this.props.path;
      file_exists = this.props.fileexists;
      if (file_exists) {
        iframeSource = process.env.REACT_APP_baseURL_office_visio + '/?server=' + window.backendURL + '&fid=' + title + '&token=token' + '&client=1';
      }
      else {
        iframeSource = process.env.REACT_APP_baseURL_office_visio + '/?server=' + window.backendURL + '&fid=' + title + '&token=token#User';

      }
      //iframeSource ='http://visio.local/?server=' + window.backendURL + '&fid=' + this.props.path + '&token=token#User';
    }
    let data = '';
    if (title !=='' && this.props.langId !== '') {
      data = {
          'doc_id':this.props.did,
          'standard':this.props.stand,
          'language':this.props.langId,
          'doc_path':title,
      }
      if(this.props.langId !== ''){
        datasave.service(window.ADD_DOC_STANDARDS,"POST",data)
          .then(result => {
          });
      }
    }
    return(
        <div className='col-md-12 col-lg-12 px-0 py-0' id="editor-frame-wrapper">
          {/*  { this.props.type !== 3 && <>
            <reactbootstrap.Button className="btn btn-primary preview-btn" onClick={(e) => this.previewDocument(e)}>Preview</reactbootstrap.Button>
            <div className="details-wrap">
                <div className="code-name-smarteditor">
                    <div className="doc-code">{t('Code')}: {this.props.code}</div>
                    <div className="doc-label">{t('Name')}: {this.props.name}</div>
                </div>
                {this.props.minimize &&
                    <div className="actions-remove-mini">
                        <div id="removeeditor" aria-hidden="true" onClick={this.props.removeeditor}>{t('Close editor')}</div>
                        {this.props.insertmasterdata && <div id="addmasterdata" aria-hidden="true" onClick={this.props.addmasterdata}>{t('Insert masterdata')}</div>}
                        {!this.props.insertmasterdata && <div id="addmasterdata" aria-hidden="true" onClick={this.props.addmasterdata}>{t('Insert masterdata')}</div>}
                      {/*  <div id="minimizeeditor" aria-hidden="true" onClick={this.props.minimizeeditor}>{t('Minimize editor')}</div>
                    </div>
                }
                {!this.props.minimize && <div id="expandeditor" aria-hidden="true" onClick={this.props.updateeditor}>{t('Maximize editor')}</div>}

            </div>
            </>
          }*/}
            <iframe id="office_frame" width="100%" height="800px" name="office_frame" src={iframeSource}></iframe>
        </div>
    );
  }
}
function buildTitle(path, stand, lang) {
  let standard = stand === '' ? 'general' : stand;
  return path + '_' + standard + '_' + lang;
}
export default translate(SmartEditor)
