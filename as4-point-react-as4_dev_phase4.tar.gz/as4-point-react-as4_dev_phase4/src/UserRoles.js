//import axios from 'axios'
import { Tabs, Tab } from 'react-bootstrap';
import React, { Component } from 'react';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import CheckBoxList from './CheckBoxList';
import './Package.css';
import { datasave } from './_services/db_services';
import {translate} from './language';

class UserRoles extends Component {
  constructor(props) {
    super(props)
    this.handleSelect = this.handleSelect.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.state = {
      save: 'Save',
      savevalue: 'true',
      id: '',
      error: '',
      name: '',
      nametest: '',
      description: '',
      package_details: [],
      functions: [],
      allFunctions: [],
      checkedItems: new Map(),
      checklist: [],
      checkedItems_values: [],
      checkedItems_keys: [],
      active_tab: "User management",
      ItemsChecked: [false, false, false],
      package_functions: [],
      t:props.t,
    }
  }

  handleSelect(key) {
    this.setState({
      active_tab: key,
    })
  }

  async componentDidMount() {

    const role_id = this.props.match.params.id;
    if (this.props.match.params.id) {
      var url = window.USERROLES + '/' + role_id;
      datasave.service(url, "GET")
        // axios.get(process.env.REACT_APP_serverURL + `/api/roles/${role_id}`)
        .then(response => {
          console.log(response.data);
          this.setState({

            name: response[0]['name'],
            //  package_details: response.data,
            //description: response.data[0]['description'],

          })
        })
      var url = window.USERROLES_FUNCTION + '/' + role_id;
      datasave.service(url, "GET")
        .then(response => {
          //axios.get(process.env.REACT_APP_serverURL + `/api/roles_functions/${role_id}`).then(response => {
          this.setState({
            functions: [],
            allFunctions: [],

          });
          console.log(response.data);
          var responsibilites = response;
          this.setState({
            functions: response['function'],
            allFunctions: response['allfunctions'],

          })
          //console.log(this.state.functions)
        })
    }
    else {
      var url = window.FUNCTIONS_CLASSIFICATION;
      datasave.service(url, "GET")
        //axios.get(process.env.REACT_APP_serverURL + '/api/function_classification')
        .then(response => {
          this.setState({

            functions: response['function'],
            allFunctions: response['allfunctions'],
          })
          console.log(this.state.allFunctions)

        })

    }
  }

  handleSubmit(event) {

    event.preventDefault()
    this.setState({
      savevalue: '',
      save: 'Please wait'
    })
    const { history } = this.props

    const details = {
      name: this.state.name,
      description: this.state.description,
      checkedItems: this.state.allFunctions,
    }
    if (this.props.match.params.id) {
      const roleId = this.props.match.params.id;
      var url = window.USERROLES + '/' + roleId;
      datasave.service(url, 'PUT', details)
      //axios.put(process.env.REACT_APP_serverURL + `/api/roles/${roleId}`, details)
      .then(response => {
        if (response.name) {
          this.setState({
            error: response.name
          })
        }
        else {
          history.push('/manageuserroles')
        }
      })
        .catch(error => {
          this.setState({
            error: error.response.errors
          })
        })
    }
    else {
      var url = window.USERROLES;
      datasave.service(url, 'POST', details)
      //axios.put(process.env.REACT_APP_serverURL + `/api/roles/${roleId}`, details)
      .then(response => {
        if (response.name) {
          this.setState({
            error: response.name
          })
        }
        else {
          history.push('/manageuserroles')
        }
      })
        .catch(error => {
          this.setState({
            error: error.response.errors
          })
        })
    }

  }
  onCheckBoxChange(checkName, isChecked, classification) {
    let isAllChecked = (checkName === 'all' && isChecked);
    let isAllUnChecked = (checkName === 'all' && !isChecked);
    var pack_func = this.state.allFunctions;

    const functions = Object.values(this.state.functions).map((city, index) => {
      const ObjectList = Object.values(city['values']).map((value, key) => {
        if ((isAllChecked || value.function_id === checkName) && classification === city.title) {
          city.selectall = isAllChecked;
          value.checked = isChecked;

          pack_func.filter(function (i, key) {
            if (i.function_id == value.function_id) {
              pack_func[key].checked = (isChecked) ? true : false;
            }
          });
          return Object.assign({}, value, {
            value,
          });
        } else if (isAllUnChecked && classification === city.title) {
          city.selectall = false;
          value.checked = false;
          pack_func.filter(function (i, key) {
            if (i.function_id == value.function_id) {
              pack_func[key].checked = (isChecked) ? true : false;
            }
          });
          return Object.assign({}, value, {
            value,
          });
        }
        return value;
      });
      Object.assign({}, city);
      return city;
    });

    this.setState({
      functions,
      allFunctions: pack_func,
    });
  }
  render() {
    const { error,t } = this.state;
    var userres = Object.keys(this.state.functions).map(
      function (key) {
        return (
          <Tab eventKey={this.state.functions[key]['title']} title={t(this.state.functions[key]['title'])}>
            <Form.Group>
              <CheckBoxList
                options={this.state.functions[key]['values']}
                isCheckedAll={this.state.functions[key]['selectall']}
                onCheck={this.onCheckBoxChange.bind(this)}
                category={tthis.state.functions[key]['title']}
              />
            </Form.Group>
          </Tab>
        )
      }, this
    );

    return (
      <div className='container py-4' >
        <div className='row justify-content-center' >
          <div className='col-md-11' >

            <div className='organisation_list'>
              <div className='header'>
                <div className='card-header' > {t('Create default role')} </div>
                {this.state.nametest}
                <div className='card-body' >
                  <Container className="p-5">
                    <Form onSubmit={this.handleSubmit}>
                      <FormGroup>
                        <InputGroup className="mb-3">
                          <InputGroup.Prepend>
                            <InputGroup id="basic-addon1">{t('User role')}<span style={{ color: "red" }}>*</span></InputGroup>
                          </InputGroup.Prepend>
                          <FormControl
                            placeholder={t("User role")}
                            aria-label="Functionname"
                            aria-describedby="basic-addon1"
                            value={this.state.name}
                            onChange={e => this.setState({ name: e.target.value })}
                          />

                        </InputGroup>
                        <div style={{ color: 'red' }} className="error-block">{error}

                        </div>
                      </FormGroup>
                      <InputGroup.Prepend>
                        <InputGroup id="basic-addon1">{t('Roles and responsibilites')}</InputGroup>
                      </InputGroup.Prepend>
                      {<Tabs className="test-tab" activeKey={this.state.active_tab} onSelect={this.handleSelect} id="controlled-tab-example">

                        {userres}
                      </Tabs>}
                      <Button type="submit" disabled={!this.state.savevalue} color="primary">{t('Save')}</Button>
                    </Form>
                  </Container>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    );
  }
}
export default translate(UserRoles)
