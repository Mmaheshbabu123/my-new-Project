import Loader from 'react-loader-spinner'
import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';


class Loading extends Component {
    constructor(props) {
        super(props)


    }

    render() {
        return (
            <div className='loading' id="loding-icon" style={{ display: "none" }}>
                <Loader
                    type="TailSpin"
                    color="#EC661C"
                    height="100"
                    width="100"
                />
            </div>
        );
    }
}

export default Loading;
