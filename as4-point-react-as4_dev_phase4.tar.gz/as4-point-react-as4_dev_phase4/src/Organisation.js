import React, { Component } from 'react';
import { Button, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
//import axios from 'axios';
import { datasave } from './_services/db_services';
import FileUpload from './_components/FileUpload/FileUpload'
import { Input } from 'reactstrap';
import MultiSelect from './_components/MultiSelect';
import Can from './_components/CanComponent/Can';
import { PagePermissions } from './_components/CanComponent/PagePermissions';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import { translate } from './language';
import timezone from './timezone.json';
import './Organisation.css';
import { OCAlert } from '@opuscapita/react-alerts';
import { Tabs, Tab } from 'react-bootstrap';
import * as reactbootstrap from 'react-bootstrap';
import LoginScreenLayout from './LoginScreenLayout';

class Organisation extends Component {
  constructor(props) {
    super(props)
    this.siteDetials = window ?.siteDetials ?? {};
    this.state = {
      nameexist: '',
      checked: true,
      status: 1,
      loading: false,
      validated: false,
      save: props.t('Save'),
      submitted: false,
      edit_img: '',
      savevalue: 'true',
      name: '',
      // description: '',
      logo: '',
      file_id: '',
      name_error: '',
      errors: [],
      package_id: 35,
      country_details: '',
      time_zone: timezone[42]['text'],
      location_id: '',
      language_id: 'en',
      select_database: '',
      no_of_sites: '',
      no_of_sites_error: '',
      packages_data: [],
      locations_data: [],
      sucess: '',
      file_name: props.t('Choose file'),
      organisation_details: [],
      file_url: '',
      default: () => [],
      showError: '',
      website: '',
      hostname: process.env.REACT_APP_baseURL,
      protocol: window.location.protocol,
      language: [],
      standards: [],
      duplicatestandards: [],
      blancoList: [],
      // subdescription: '',
      persons: [],
      siteowner: '',
      multipersonsduplicate: [],
      multistandradsduplicate: [],
      multipersons: [],
      getpersonsUrl: window.GET_Active_nd_Archive,
      mulistandards: [],
      blancos: '',
      t: props.t,
      required: false,
      time_zone_list: timezone,
      sandboxstandards : [],
      sandboxblanco : [],
      sandboxstdlist : [],
      // selected_org_name : 0,
      // org_names : [],
      activeTab: 1,
      activePersonsTab: 1,
      activeUsers: [],
      archivedUsers: [],
      as4Users: [],
      designObject: {
          main_text     : this.siteDetials['main_text']
        , sub_text      : this.siteDetials['sub_text']
        , color         : this.siteDetials['color']
        , login_logo    : this.siteDetials['login_logo']
        , logo_width    : this.siteDetials['logo_width']
        , logo_height   : this.siteDetials['logo_height']
      },
    }
    this.handleCancel = this.handleCancel.bind(this)
    this.handleCheck = this.handleCheck.bind(this)
    this.handleChangeSite = this.handleChangeSite.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleChangeMultiStandard = this.handleChangeMultiStandard.bind(this);
    this.handleChangeName = this.handleChangeName.bind(this);
    this.handleSandboxblanco = this.handleSandboxblanco.bind(this);
    this.handleWebsiteChange = this.handleWebsiteChange.bind(this)
    this.handleChangeMultiPersons = this.handleChangeMultiPersons.bind(this);
    this.handleChangeMultiStandards = this.handleChangeMultiStandards.bind(this);
    this.handleSandboxStandards = this.handleSandboxStandards.bind(this);
    this.handleTabSelect = this.handleTabSelect.bind(this);
    this.handlePersonsSelect = this.handlePersonsSelect.bind(this);
  }

  componentDidMount() {
    const { t } = this.state;
    const organisationId = this.props.id;
    console.log(organisationId);
    if (this.props.id) {
      url = window.ORGANISATIONS + '/' + organisationId;
      datasave.service(url, "GET")
        .then(response => {
          let as4ActiveUsers = response.orgPersons ? (response.orgPersons.Active ? (response.orgPersons.Active.filter(item => (item.as4member == 1))) : []) : [];
          let as4ArchiveUsers = response.orgPersons ? (response.orgPersons.Archived ? (response.orgPersons.Archived.filter(item => (item.as4member == 1))) : []) : [];
          let as4RoleUsers = as4ActiveUsers.concat(as4ArchiveUsers);
          this.setState({
            organisation_details: response,
            name: response[0]['name'],
            package_id: response[0]['package_id'],
            // description: response[0]['description'],
            checked: response[0]['status'],
            status: response[0]['status'],
            language_id: response[0]['language_id'],
            no_of_sites: response[0]['no_of_sites'],
            website: response[0]['website'],
            standards: response['blanco'],
            file_name: response[0]['logo'] ? response[0]['logo'] : this.state.file_name,
            edit_img: response[0]['logo'] ? t('Click here for preview') : '',
            logo: response[0]['logo'],
            multipersons: response['persons'],
            mulistandards: response['standards'],
            time_zone: response[0]['time_zone'],
            multipersonsduplicate : response['persons'],
            multistandradsduplicate : response['standards'],
            duplicatestandards:response['blanco'],
            sandboxstdlist : response['sandboxstandards'],
            sandboxblanco : response['sandboxblanco'],
            // selected_org_name: response[0]['selected_org_name'],
            // siteowner : response[0]['siteowner'],
            // subdescription : response[0]['subdescription'],
            required: true,
            activeUsers: response.orgPersons ? (response.orgPersons.Active ? (response.orgPersons.Active.filter(item => (item.as4member != 1))) : []) : [],
            archivedUsers: response.orgPersons ? (response.orgPersons.Archived ? (response.orgPersons.Archived.filter(item => (item.as4member != 1))) : []) : [],
            as4Users: as4RoleUsers,
            designObject: response['designObject'] && Object.keys(response['designObject']).length ? response['designObject'] : this.state.designObject,
          })
          if (this.state.checked) {
            this.setState({
              checked: true
            })
          }
          else {
            this.setState({
              checked: false
            })
          }
          this.getStandards(response['blanco'],'stdList');
          this.getStandards(response['sandboxblanco'],'sandboxstandards')
        })
    }
    url = window.packages;
    datasave.service(url, "GET").then(response => {
      this.setState({
        packages_data: response,
      })
      /*if (this.state.package_id === '') {
        this.setState({
          package_id: response[0].id
        })
      }*/
    })
    datasave.service(window.GET_BLANCO, 'GET')
      .then(result => {
        this.setState({
          blancoList: result
        })
      });
    // datasave.service(window.GET_ORG_NAMES,'GET')
    //   .then(result=>{
    //     this.setState ({
    //       org_names : result,
    //     })
    //   })
    datasave.service(window.GET_ALL_LANGUAGES, 'GET')
      .then(response => {
        this.setState({
          language: response
        });
      });
    var url = window.PERSONS;
    datasave.service(url, 'GET', '')
      .then(response => {

        this.setState({
          persons: response['Active'],
        })
      });
  }
  handleChange(event) {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
      name_error: '',
      no_of_sites_error: ''
    });

  }
  handleChangeSite(event) {
    // const { name, value } = event.target;
    const re = /^(?:[0-9]*)$/;
    if (re.test(event.target.value)) {
      this.setState({
        no_of_sites: event.target.value,
        name_error: '',
        no_of_sites_error: ''
      })
    }
  }
  handleWebsiteChange(event) {
    event.preventDefault()
    if (/([^0-9a-zA-Z-])/.test(event.target.value)) {
    }
    else {
      this.setState({
        website: event.target.value,
        website_error: ''
      })
    }
  }
  handleChangeName(event) {
    this.setState({
      name: event.target.value,
      name_error: '',
      loading: false
    })
  }
  handleCheck(e) {
    this.setState({ checked: !this.state.checked });
    if (this.state.checked) {
      this.setState({
        status: 0
      })
    } else {
      this.setState({
        status: 1
      })
    }
  }

  updateImageUpload(response) {
    this.setState({
      sucess: window.FILE_UPLOAD_SUCCESS,
      edit_img: '',
      file_id: response.data.file_id[0],
      logo: response.data.filepath
    });
  }
  getTimezoneOptionItems() {
    let temp = [];
    if (this.state.time_zone_list.length >= 1) {
      if (this.state.time_zone_list) {
        temp = this.state.time_zone_list.map((ind) => {
          return (<option value={ind.text} >{ind.text}</option>)
        }
        );
        return temp;
      }
    }
  }

  handleSubmit = (event) => {
    const { t } = this.state;
    event.preventDefault()
    this.setState({ submitted: true });
    const { history } = this.props
    const organisationId = this.props.id;
    const details = {
      name: this.state.name,
      logo: this.state.logo,
      file_id: this.state.file_id,
      package_id: this.state.package_id,
      language_id: this.state.language_id,
      status: this.state.status,
      industry_id: this.state.industry_id,
      no_of_sites: this.state.no_of_sites,
      select_database: this.state.standards,
      website: this.state.website,
      time_zone: this.state.time_zone,
      siteowner: this.state.multipersons,
      sitestandards: this.state.mulistandards,
      hostname: this.state.hostname,
      protocol: this.state.protocol,
      sandboxstandards : this.state.sandboxstdlist,
      sandboxblanco : this.state.sandboxblanco,
      designObject: this.state.designObject,
      // selected_org_name : this.state.selected_org_name,
    }

    if (this.props.id) {
      const data = {
        id: this.props.id,
        ref_type_id: 1,
        website: this.state.website
      }
      if( this.state.website!= '') {

      datasave.service(window.VALIDATE_WEBSITE, 'POST', data)
        .then(response => {
          if (response === 'Failure') {
            this.setState({
              website_error: t("this name has already taken"),
            })
          }
          else {
            this.setState({
              savevalue: '',
              save: t('Please wait')
            })
            var url = window.ORGANISATIONS + '/' + organisationId;
            if ((this.state.standards.length !== 0 && this.state.mulistandards.length === 0)||(this.state.sandboxstdlist.length==0&&this.state.sandboxblanco.length!==0)) {
                console.log("standards mandatory");
            }
            else {
              if (this.state.multipersons.length !== 0) {
              datasave.service(url, 'PUT', details)
                .then(response => {
                  if (response === "Failure") {
                    this.setState({
                      name_error: t("This name has already taken"),
                    })
                  }
                  else {
                    if (response.name) {
                      this.setState({
                        name_error: response.name,
                        no_of_sites_error: response.no_of_sites
                      })
                    }
                    else {
                      OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION })
                      history.push('/managemyorganisation/manageorganisation')
                      window.location.reload();
                    }
                  }
                })
                .catch(error => {
                  this.setState({
                    error: (error.response!==undefined)?error.response.errors:''
                  })
                })
            }
          }
          }
        })
      }
    }
    else {
      const data = {
        website: this.state.website
      }
      if( this.state.website!= '') {
        datasave.service(window.VALIDATE_WEBSITE, 'POST', data)
          .then(response => {
            if (response === 'Failure') {
              this.setState({
                website_error: t("this name has already taken"),
              })
            }
            else {
              var url = window.ORGANISATIONS;
              if ((this.state.standards.length !== 0 && this.state.mulistandards.length === 0)||(this.state.sandboxstdlist.length==0&&this.state.sandboxblanco.length!==0)) {
                  console.log("standards mandatory");
              }
              else {
              if (this.state.multipersons.length !== 0) {
                datasave.service(url, 'POST', details)
                  .then(response => {
                    const details = {
                      name: this.state.name,
                    }
                    if (response === "Failure") {
                      this.setState({
                        name_error: t("this name has already taken"),
                      })
                    }
                    else {
                      if (response.name || response.no_of_sites) {
                        this.setState({
                          name_error: response.name,
                          no_of_sites_error: response.no_of_sites
                        })
                      }
                      else if (response === 'success') {
                        const details = {
                          name: this.state.name,
                          website: this.state.website,
                          select_database: this.state.standards,
                          logo: this.state.logo,
                          // subdescription: this.state.subdescription,
                          // description: this.state.description,
                          siteowner: this.state.multipersons,
                          package_id: this.state.package_id,
                          sitestandards: this.state.mulistandards,
                          language_id: this.state.language_id,
                          hostname: this.state.hostname,
                          protocol: this.state.protocol,
                          designObject: this.state.designObject
                        }
                        datasave.service(window.CREATE_ORGANISATION, 'POST', details)
                          .then(result => {
                            if (result == 'Success') {
                              OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION })
                              history.push('/managemyorganisation/manageorganisation')
                              window.location.reload();
                            }
                            else {
                              OCAlert.alertWarning('This website is not created, please can you try again', { timeOut: window.TIMEOUTNOTIFICATION });
                              history.push('/managemyorganisation/manageorganisation')
                            }
                          });
                      }
                    }
                  })
                  .catch(error => {
                    this.setState({
                      error: error.response.errors
                    })
                  })
              }
            }
            }
          });
      }
    }

  }
  getBlancoOptionItems() {
    let temp = [];
    if (this.state.blancoList.length > 1) {
      if (this.state.blancoList) {
        temp = this.state.blancoList.map((blanco) => {
          return (<option id={blanco.id} value={blanco.id} >{blanco.name}</option>)
        }
        );
        return temp;
      }
    }
  }

  handleCancel(event) {
    const { history } = this.props
    history.push('/managemyorganisation/manageorganisation')
    if (this.props.handleSelect !== undefined)
        this.props.handleSelect(1)
  }
  getLangOptionItems() {
    let temp = [];
    if (this.state.language.length >= 1) {
      if (this.state.language) {
        temp = this.state.language.map((lang) => {
          return (<option id={lang.code_name} value={lang.code_name} >{lang.language}</option>)
        }
        );
        return temp;
      }
    }
  }
  getUserOptions() {
    let temp = [];
    if (this.state.persons.length !== 0) {
      if (this.state.persons) {
        temp = this.state.persons.map((user) => {
          return (<option value={user.id} >{user.name}</option>)
        }
        );
        return temp;
      }
    }
  }
  handleChangeMultiStandard(event) {

    this.handlePreviousvalues(event,this.state.duplicatestandards,"standards",'blanco(s)')

    // if (event.target == undefined) {
    //   const { value } = event;
    //   this.setState({ standards: event });
    // }
    if (event.length !== 0) {
      this.getStandards(event,'stdList');
      // const details = {
      //   blancos: event
      // }
      // datasave.service(window.GET_SITE_STANDARDS, 'POST', details)
      //   .then(result => {
      //     this.setState({
      //       stdList: result
      //     })
      //   })

    }

  }
  handleSandboxblanco(event) {
    if (event.target === undefined) {
      this.setState({ sandboxblanco: event});
    }
    if (event.length !== 0) {
      this.getStandards(event,'sandboxstandards');
    }
    else{
      this.setState({ sandboxstdlist: []});
    }
  }
  handleSandboxStandards(event) {
    if (event.target === undefined) {
      this.setState({
        sandboxstdlist: event,
        loading: false
      });
    }
  }
  handleChangeMultiPersons(event) {
    this.handlePreviousvalues(event,this.state.multipersonsduplicate,"multipersons",'persons(s)')
  }
  handleChangeMultiStandards(event) {
    this.handlePreviousvalues(event,this.state.multistandradsduplicate,"mulistandards",'standard(s)')

    // if (event.target == undefined) {
    //   const { value } = event;
    //   this.setState({ mulistandards: event, loading: false });
    // }
  }
  getStandards(blancos,name) {
    const details = {
      blancos: blancos
    }
    datasave.service(window.GET_SITE_STANDARDS, 'POST', details)
      .then(result => {
        this.setState({
          [name]: Object.values(result)
        })
      })

  }
  handlePreviousvalues(event,duplicatevalues,name,fieldname){
    if(event.length===0) {
      if(this.props.id){
        OCAlert.alertWarning('Used '+fieldname+" can't be deleted", { timeOut: window.TIMEOUTNOTIFICATION });
      }
      this.setState({
        [name]: duplicatevalues, loading: false
      })
    }
    else {
      var count = 0;
      duplicatevalues.map(function (pduplicate) {
        event.map(function (person) {
          if (person.value === pduplicate.value) {
            count++
          }
        });
      })
      if (count===duplicatevalues.length){
        if (event.target === undefined) {
          const { value } = event;
          this.setState({ [name]: event, loading: false });
        }
      }
      else{
        if(this.props.id){
          OCAlert.alertWarning('Used '+fieldname+" can't be deleted", { timeOut: window.TIMEOUTNOTIFICATION });
        }
        this.setState({
          [name]: duplicatevalues, loading: false
        })
      }
    }
  }

failUpload(message,name){
  this.setState({
    sucess:message
  })
}

handleTabSelect(key) {
  this.setState({
    activeTab: key,
  })
}

handlePersonsSelect(key) {
  this.setState({
    activePersonsTab: key,
  })
}


  render() {
    const as4_or_site = PagePermissions()
    const { t } = this.state;
    const { validated, name_error, no_of_sites_error, loading, submitted, name, no_of_sites, activeTab, activePersonsTab, activeUsers, archivedUsers, as4Users} = this.state;
    if (as4_or_site) {
      return (
        <div className="row">

          <div style={{ marginLeft: '0.45rem' }} className='col md-11 pl-2' >
            <Can
              perform="E_organisation"
              yes={() => (
                <div >
                  <div className='col-md-12 pl-0' >
                    <div className='card' >
                    <Tabs activeKey={activeTab} onSelect={this.handleTabSelect} id="controlled-tab-example">
                      <Tab eventKey={1} title={t('Create organisation')}>
                      {/* <div className='card-header' >{t('Create organisation')}</div> */}
                      <div className='card-body' >
                        <Form method='POST'
                          onSubmit={this.handleSubmit}>
                          <Form.Group >
                            <div className=" input-overall-sec ">
                              <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Organisation name')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <Form.Control
                                      name='name'
                                      placeholder={t("Organisation name")}
                                      aria-label="Organisationname"
                                      aria-describedby="basic-addon1"
                                      value={name}
                                      onChange={this.handleChangeName}
                                      className="input_sw "
                                    />
                                    <div style={{ color: 'red' }} className="error-block mt-2">{name_error}</div>
                                    {!this.state.name && submitted && <p style={{ color: 'red', }}>{t('Required')}</p>}
                                  </div>
                                </InputGroup>
                              </div>
                            </div>
                          </Form.Group>
                          <Form.Group >
                            <div className=" row input-overall-sec  py-2">
                              {/* <InputGroup className=""> */}
                              {/* <div className="col-md-6  "> */}
                              <div className="input-group px-3">
                                <FileUpload updateImageUpload={this.updateImageUpload.bind(this)} style={{ fontsize: '1rem' }} file_name={this.state.file_name} {...this} related={'createOragnisation'} failUpload={this.failUpload.bind(this)} />
                              </div>
                              {/* </div> */}
                              {/* <div style={{ textAlign: 'center' }} className="col-md-12 mt-1">
                                <a href={this.state.file_name}>{this.state.edit_img}</a>
                                <span style={{ color: "green", textAlign: 'center', paddingRight: '7rem' }}>{this.state.sucess}</span>
                              </div> */}
                              <div style={{}} className="row col-md-12 mt-2">
                                <div style={{ visibility: 'hidden' }} className="col-md-4">
                                  <h3>{t('Upload')}</h3>
                                </div>
                            {this.state.sucess===window.FILE_UPLOAD_SUCCESS && <div className="col-md-8">
                                  <a href={this.state.file_name}>{this.state.edit_img}</a>
                                  <span  style={{ color: "green" }}>{this.state.sucess}</span>
                                </div>}
                                {this.state.sucess!==window.FILE_UPLOAD_SUCCESS && <div className="col-md-8">
                                    <span  style={{ color: "red" }}>{this.state.sucess}</span>
                                    </div>}
                              </div>
                              {/* </InputGroup> */}
                            </div>
                          </Form.Group>
                          <FormGroup>
                            <div className=" input-overall-sec ">
                              <InputGroup className="">
                                <div className="col-md-4">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Site responsible person')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd ">
                                  <div className="input_sw ">
                                    <MultiSelect

                                      options={this.state.persons}
                                      // disabled={this.state.required}
                                      standards={this.state.multipersons}
                                      handleChange={this.handleChangeMultiPersons}
                                    />
                                  </div>
                                  <div className="mt-2">
                                    {this.state.multipersons === 0 && submitted && <p style={{ color: 'red', }}>{t('Required')}</p>}
                                  </div>
                                </div>
                              </InputGroup>
                            </div>
                          </FormGroup>
                          <FormGroup>
                            <div className=" input-overall-sec">
                              <InputGroup className="">
                                <div className="col-md-4 ">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Select blanco')}:</InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd ">
                                  <div className=" input_sw">
                                    <MultiSelect
                                      options={this.state.blancoList}
                                      // disabled={this.state.required}
                                      standards={this.state.standards}
                                      handleChange={this.handleChangeMultiStandard}
                                    />
                                  </div>
                                </div>
                              </InputGroup>
                            </div>
                          </FormGroup>
                          <FormGroup>
                            <div className=" input-overall-sec ">
                              <InputGroup className="">
                                <div className="col-md-4 ">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Standards')}:{this.state.standards.length !== 0 && <span style={{ color: "red" }}>*</span>}</InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd ">
                                  <div className=" input_sw">
                                    <MultiSelect
                                      // disabled={this.state.required}
                                      options={this.state.stdList}
                                      standards={this.state.mulistandards}
                                      handleChange={this.handleChangeMultiStandards}
                                    />
                                  </div>
                                  <div className="mt-2">
                                    { this.state.standards.length !== 0 && this.state.mulistandards.length === 0 && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                  </div>
                                </div>
                              </InputGroup>
                            </div>
                          </FormGroup>
                          <FormGroup>
                            <div className=" input-overall-sec">
                              <InputGroup className="">
                                <div className="col-md-4 ">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Select sandbox blanco')}:</InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd ">
                                  <div className=" input_sw">
                                    <MultiSelect
                                      options={this.state.blancoList}
                                      standards={this.state.sandboxblanco}
                                      handleChange={this.handleSandboxblanco}
                                    />
                                  </div>
                                </div>
                              </InputGroup>
                            </div>
                          </FormGroup>
                          <FormGroup>
                            <div className=" input-overall-sec ">
                              <InputGroup className="">
                                <div className="col-md-4 ">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Sandbox standards')}:{this.state.sandboxblanco.length !== 0 && <span style={{ color: "red" }}>*</span>}</InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd ">
                                  <div className=" input_sw">
                                    <MultiSelect
                                      // disabled={this.state.required}
                                      options={this.state.sandboxstandards}
                                      standards={this.state.sandboxstdlist}
                                      handleChange={this.handleSandboxStandards}
                                    />
                                  </div>
                                  <div className="mt-2">
                                    { this.state.sandboxblanco.length !== 0 && this.state.sandboxstdlist.length === 0 && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                  </div>
                                </div>
                              </InputGroup>
                            </div>
                          </FormGroup>
                          <FormGroup>
                            <div className="input-overall-sec ">
                              <InputGroup className="">
                                <div className="col-md-4">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Time zone')}:</InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd ">
                                  <FormControl as="select" name="timezone"
                                    className="input_sw"
                                    value={this.state.time_zone}
                                    onChange={e => this.setState({ time_zone: e.target.value, loading: false })}
                                  >
                                    <option>{t('select')}</option>
                                    {this.getTimezoneOptionItems()}
                                  </FormControl>
                                </div>
                              </InputGroup>
                            </div>
                          </FormGroup>
                          {/* {!this.state.time_zone && submitted && <p style={{ color: 'red', textAlign: 'center', paddingRight: '11rem' }}>{t('Required')}</p>} */}
                          <Form.Group>
                            <div className=" input-overall-sec ">
                              <InputGroup className="">
                                <div className="col-md-4 ">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Packages')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd">
                                  <Form.Control as="select" name="package_id"
                                    className="input_sw"
                                    value={this.state.package_id}
                                    onChange={e => this.setState({ package_id: e.target.value })} >
                                    {/* <option>{t('Select')}</option> */}
                                    {this.state.packages_data.map(packages => <option value={packages.id}>{packages.name}</option>)}
                                  </Form.Control>
                                  <div className="mt-2">
                                    {!this.state.package_id && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                  </div>
                                </div>
                              </InputGroup>
                            </div>
                          </Form.Group>
                          <FormGroup>
                            <div className=" input-overall-sec ">
                              <InputGroup className="">
                                <div className="col-md-4 ">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Website')}: <span style={{ color: "red" }}>*</span></InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div className="col-md-1 input-padd">
                                  <Input type="text"
                                    readOnly
                                    className="form-control"
                                    name="website"
                                    value={this.state.protocol}
                                    style={{ backgroundColor: "white" }}
                                    className="input_sw"
                                  >
                                  </Input>
                                </div>
                                <FormControl
                                  className="form-control"
                                  name="website"
                                  value={this.state.website}
                                  onChange={this.handleWebsiteChange}
                                  id="website"
                                  placeholder={t("Enter website name")}
                                  className="input_sw"
                                />
                                <Input type="text"
                                  readOnly
                                  className="form-control"
                                  name="website"
                                  value={this.state.hostname}
                                  style={{ backgroundColor: "white" }}
                                  className="input_sw"
                                >
                                </Input>
                              </InputGroup>
                              <div style={{ textAlign: 'center', paddingRight: '15rem' }} className="mt-2 col-md-12">
                                {!this.state.website && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                              </div>
                              <div style={{ textAlign: 'center', paddingRight: '15rem', color: 'red' }} className="error-block mt-2">{this.state.website_error}</div>
                            </div>
                          </FormGroup>
                          <Form.Group >
                            <div className=" input-overall-sec ">
                              <InputGroup className="">
                                <div className="col-md-4 ">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('No of sites')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd ">
                                  <div className="input_sw ">
                                    <Form.Control
                                      name='no_of_sites'
                                      placeholder={t("No of sites")}
                                      aria-label="NoOfSites"
                                      aria-describedby="basic-addon1"
                                      value={no_of_sites}
                                      onChange={this.handleChangeSite}
                                    />
                                  </div>
                                  <div className="mt-2" style={{ color: 'red' }} className="error-block">{no_of_sites_error}
                                  </div>
                                  <div className="mt-2">
                                    {!this.state.no_of_sites && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                  </div>
                                </div>

                              </InputGroup>
                            </div>
                          </Form.Group>
                          <Form.Group>
                            <div className=" input-overall-sec ">
                              <InputGroup className="">
                                <div className="col-md-4 ">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Language')}:</InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 input-padd input_sw">
                                  <div className="input_sw ">
                                    <Form.Control as="select" name="language_id"
                                      value={this.state.language_id}
                                      onChange={e => this.setState({ language_id: e.target.value })} >
                                      {this.getLangOptionItems()}
                                    </Form.Control>
                                  </div>
                                </div>
                              </InputGroup>
                            </div>
                          </Form.Group>
                          <Form.Group>
                            <Form.Check
                              className="ml-4"
                              onChange={this.handleCheck}
                              checked={this.state.checked}
                              label={t("Active organisation")}
                              feedback={t("You must agree before submitting.")}
                            />
                          </Form.Group>
                          <FormGroup>
                            <div style={{ float: 'right' }} className="organisation_list">
                              <a onClick={this.handleCancel} > {t('Cancel')} </a>
                              &nbsp;&nbsp;&nbsp;
                            <Button type="submit" className="btn btn-primary" disabled={loading}>{t('Save')}</Button>
                              {loading &&
                                <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                              }
                            </div>
                          </FormGroup>
                        </Form>
                      </div>
                      </Tab>
                      <Tab eventKey={3} title={t('Login layout')}>
                      </Tab>
                      {(this.props.id !== null && this.props.id !== undefined) &&
                        <Tab eventKey={2} title={t('Users')}>
                          <Tabs activeKey={activePersonsTab} onSelect={this.handlePersonsSelect} id="controlled-tab-example">
                            <Tab eventKey={1} title={t('Active')}>
                              <reactbootstrap.Table className="site-table-main" >
                                <thead>
                                  <tr>
                                    <th>{t('Name')}</th>
                                    <th>{t('Email')}</th>
                                    <th>{t('Role')}</th>
                                  </tr>
                                </thead>
                                {activeUsers.map((item) => (
                                  <tbody>
                                      <td>{item.name}</td>
                                      <td>{item.email}</td>
                                      <td>{item.roleName}</td>
                                  </tbody>
                                ))}
                              </reactbootstrap.Table>
                            </Tab>
                            <Tab eventKey={2} title={t('Inactive')}>
                              <reactbootstrap.Table className="site-table-main" >
                                <thead>
                                  <tr>
                                    <th>{t('Name')}</th>
                                    <th>{t('Email')}</th>
                                    <th>{t('Role')}</th>
                                  </tr>
                                </thead>
                                {archivedUsers.map((item) => (
                                  <tbody>
                                      <td>{item.name}</td>
                                      <td>{item.email}</td>
                                      <td>{item.roleName}</td>
                                  </tbody>
                                ))}
                              </reactbootstrap.Table>
                            </Tab>
                            <Tab eventKey={3} title={t('As4')}>
                              <reactbootstrap.Table className="site-table-main" >
                                <thead>
                                  <tr>
                                    <th>{t('Name')}</th>
                                    <th>{t('Email')}</th>
                                    <th>{t('Role')}</th>
                                  </tr>
                                </thead>
                                {as4Users.map((item) => {
                                  if(parseInt(item.status) === 1){
                                    return(
                                    <tbody>
                                        <td>{item.name}</td>
                                        <td>{item.email}</td>
                                        <td>{item.roleName}</td>
                                    </tbody>
                                  )}})}
                              </reactbootstrap.Table>
                            </Tab>
                            <Tab eventKey={4} title={t('As4 inactive')}>
                              <reactbootstrap.Table className="site-table-main" >
                                <thead>
                                  <tr>
                                    <th>{t('Name')}</th>
                                    <th>{t('Email')}</th>
                                    <th>{t('Role')}</th>
                                  </tr>
                                </thead>
                                {as4Users.map((item) => {
                                  if(parseInt(item.status) === 0){
                                    return(
                                    <tbody>
                                        <td>{item.name}</td>
                                        <td>{item.email}</td>
                                        <td>{item.roleName}</td>
                                    </tbody>
                                  )}})}
                              </reactbootstrap.Table>
                            </Tab>
                          </Tabs>
                        </Tab>
                      }
                     </Tabs>
                     {parseInt(activeTab) === 3 && this.showLayoutPage()}
                    </div>
                  </div>
                </div>
              )}
              no={() =>
                <AccessDeniedPage />
              }
            />
          </div>
        </div>
      );
    }
    else {
      return (
        <AccessDeniedPage />
      )
    }
  }

  setStateDesignObject = (obj = {}) => {
    let designObj = {...this.state.designObject}
    designObj = {...designObj, ...obj}
    this.setState({ designObject: designObj })
  }

  showLayoutPage = () => {
    return (
      <LoginScreenLayout
        data = {this.state.designObject}
        handleCancel = {this.handleCancel.bind(this)}
        handleSubmit = {this.handleSubmit.bind(this)}
        setStateDesignObject = {this.setStateDesignObject}
        t = {this.props.t}
      />
    );
  }
}
export default translate(Organisation)
