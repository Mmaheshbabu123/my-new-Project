import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from './_services/db_services';
import Can from './_components/CanComponent/Can';
import {PagePermissions} from './_components/CanComponent/PagePermissions';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import Pagination from 'react-bootstrap/Pagination';
import {translate} from './language'
import './PackageList.css';

class PackagessList extends Component {
  constructor(props) {
    super(props)
    this.state = {
      packages: [],
      items:[],
      searchTerm:'',
      id:'',
      page: 5,
      count: 0,
      active: 1,
      filterFullList:[],
      t:props.t,
    }
    this.searchData = this.searchData.bind(this);
  }
  componentDidMount() {
    var url = window.packages;
    datasave.service(url, "GET")
      .then(response => {
        const pageData = this.getPageData(1, response);
        const count = this.getCountPage(response);
        this.setState({
          packages: response,
          count: count,
          items : pageData,
        })
      })
  }
  componentDidUpdate(prevProps, prevState) {
      if (prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
          datasave.service(window.packages, 'GET', '')
              .then(response => {
                      const pageData = this.getPageData(this.state.active, response);
                      const count = this.getCountPage(response);
                      this.setState({
                          packages: response,
                          items :pageData,
                          count: count,
                      })
              });
      }
  }
  getCountPage(items) {
      const itemLength = items.length;
      return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }
  componentWillMount() {
      this.setState({ items: this.state.packages })
  }
  searchData(e) {
      var list = [...this.state.packages];
      list = list.filter(function (item) {
          if (item.name !== null) {
              return item.name.toLowerCase().search(
                  e.target.value.toLowerCase()) !== -1;
          }
      });
      const page_data = this.getPageData(1, list);
      const count = this.getCountPage(list);
      this.setState({
          items: page_data,
          count: count,
          active: 1,
          searchTerm: e.target.value,
          filterFullList: list,
      });

  }
  changePage(e, id = 1) {
      const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
      const page_data = this.getPageData(id, list);
      this.setState({
          items : page_data,
          active: id,
      });
  }
  getPageData(id, list = '') {
      const page = this.state.page;
      const items = (list !== '') ? list : this.state.packages;
      const page_data = items.slice(page * (id - 1), page * id);
      return page_data;
  }


  render() {
    const as4_or_site = PagePermissions()
    const { packages,t } = this.state
    const filtered = this.state.items;
    let active = this.state.active;
    let pages = [];
    if(this.state.count > 0)
    {
        for (let number = 1; number <= this.state.count; number++) {
            pages.push(
                <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                    {number}
                </Pagination.Item>,
            );
        }
    }


    if (as4_or_site) {
      return (
        <div className=" row col-md-12">
            <div style={{visibility: 'hidden'}} className="col-md-1"><p>welcome</p></div>
            <div style={{}} className='col-md-11' >
        <Can
          perform = "E_package,R_package"
          yes = {() => (

            <div className='row'>
              <div className='col-md-12  mt-5 mb-5'>
                <div className='card'>
                  <div className='card-header'>{t('All packages')}</div>
                  <div className='card-body'>
                  <input  className="form-control search-box-border col-md-4 mb-2" placeholder={t("Search")} onChange={this.searchData} /><br />
                  <div style={{}}>
                  <reactbootstrap.Table  className="site-table-main" >
                      <thead style={{borderBottom: '0px'}}>
                        <tr>
                          <th>{t('Name of package')}</th>
                          <th style={{textAlign: 'right'}} colspan="2">{t('Actions')}</th>
                        </tr>
                      </thead  >
                      <tbody>
                        {filtered.map(packageItem => (
                          <tr>
                            <td>
                              {packageItem.name}
                            </td>
                            <td >
                            <Can
                              perform="E_package"
                              yes={() => (
                              <Link style={{float: 'right'}}
                                to={`/packages/${packageItem.id}`}
                                key={packageItem.id}
                              >
                                {/* {t('Edit')} */}
                                <i title={t("Edit")}  class="overall-sprite overall-sprite-myeditc"></i>
                            </Link>
                            )}
                            />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </reactbootstrap.Table>
                    </div>
                    {/* <Pagination size="md">{pages}</Pagination> */}
                    <div className="page-nation-sec col-md-12">
                        <Pagination style={{width: '500px',overflow: 'auto',scrollbarWidth: 'thin'}} size="md">{pages}</Pagination>
                        </div>
                  </div>
                </div>
              </div>
            </div>

          )}
          no = {() =>
            <AccessDeniedPage/>
          }
        />
        </div>
        </div>
      )
    }
    else {
      return(
          <AccessDeniedPage />
      )
    }
  }
}

export default translate(PackagessList)
