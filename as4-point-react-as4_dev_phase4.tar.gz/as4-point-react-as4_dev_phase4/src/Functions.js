import React, { Component } from 'react';
import { datasave } from './_services/db_services';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import {translate} from './language';
class Functions extends Component {
  constructor(props) {
    super(props)
    this.handleSubmit = this.handleSubmit.bind(this);
    this.state = {
      save: 'Save',
      savevalue: 'true',
      name: '',
      description: '',
      unique_key: '',
      classification_id: 1,
      classifications: [],
      where_to_show: 1,
      function_order: '',
      key_error: '',
      order_error : '',
      added_or_not: '',
      added_or_not_error: '',
      public_or_not : '',
      t:props.t,
    }

  }
  componentDidMount() {
    const function_id = this.props.match.params.id;
    var data = '';
    var method = 'GET';
    var url = window.SHOW_CLASSIFICATIONS;
    datasave.service(url, method, data).then(result => {
      this.setState({
        classifications: result
      })
    })
    if (this.props.match.params.id) {
      var functions = window.GET_FUNCTIONS + '/' + function_id;
      datasave.service(functions, "GET")
        .then(response => {
          this.setState({
            name: response[0]['name'],
            //package_details: response.data,
            description: response[0]['description'],
            unique_key: response[0]['constant_key'],
            classification_id: response[0]['classification_id'],
            where_to_show: response[0]['where_to_show'],
            function_order: response[0]['order_of_function'],
            added_or_not: response[0]['added'],
            public_or_not: response[0]['public']
          })
        })
    }
  }
  handleSubmit(event) {
    event.preventDefault()
    this.setState({
      savevalue: '',
      save: 'Please wait'
    })
    const { history } = this.props
    const details = {
      name: this.state.name,
      description: this.state.description,
      constant_key: this.state.unique_key,
      classification_id: this.state.classification_id,
      where_to_show: this.state.where_to_show,
      order_of_function: this.state.function_order,
      added: this.state.added_or_not,
      public : this.state.public_or_not,
    }
    var functions;
    if (this.props.match.params.id) {
      const functionsId = this.props.match.params.id;

      functions = window.GET_FUNCTIONS + '/' + functionsId;
      datasave.service(functions, 'PUT', details)
        .then(response => {

          if (response.constant_key || response.order_of_function || response.added) {
            this.setState({
              key_error: response.constant_key,
              order_error :response.order_of_function,
              added_or_not_error : response.added,
            })
          }
          else {
            history.push('/managefunctions')
          }
        })
        .catch(error => {

          this.setState({
            error: error.response.errors
          })
        })

    }
    else {
      functions = window.GET_FUNCTIONS;
      datasave.service(functions, 'POST', details)
        .then(response => {
          if (response.constant_key || response.order_of_function || response.added) {
            this.setState({
              key_error: response.constant_key,
              order_error :response.order_of_function,
              added_or_not_error : response.added,
            })
          }
          else {
            history.push('/managefunctions')
          }
        })
        .catch(error => {
          this.setState({
            error: error.response.errors
          })
        })
    }
  }
  render() {
    const { t } = this.state;
    return (
      <div className='container py-4' >
        <div className='row justify-content-center' >
          <div className='col-md-6' >
            <div className='card' >
              <div className='card-header' > {t('Create function')} </div>
              <div className='card-body' >
                <Container className="p-5">
                  <Form onSubmit={this.handleSubmit}>
                    <FormGroup>
                      <InputGroup className="mb-3">
                        <InputGroup.Prepend>
                          <InputGroup  id="basic-addon1">{t('Name')}</InputGroup>
                        </InputGroup.Prepend>
                        <FormControl
                          placeholder="Function name"
                          aria-label="Functionname"
                          aria-describedby="basic-addon1"
                          value={this.state.name}
                          onChange={e => this.setState({ name: e.target.value })}
                        />
                      </InputGroup>
                    </FormGroup>
                    <FormGroup>
                      <InputGroup.Prepend>
                        <InputGroup id="basic-addon1">{t('Description')}</InputGroup>
                      </InputGroup.Prepend>
                      <FormControl
                        style={{ height: '200px' }}
                        as="textarea" rows="3"
                        placeholder={this.props.placeholder}
                        value={this.state.description}
                        onChange={e => this.setState({ description: e.target.value })}
                      />
                    </FormGroup>
                    <FormGroup>
                      <InputGroup className="mb-3">
                        <InputGroup.Prepend>
                          <InputGroup id="basic-addon1">{t('Unique key')}</InputGroup>
                        </InputGroup.Prepend>
                        <FormControl
                          placeholder="Unique Key"
                          aria-label="UniqueKey"
                          aria-describedby="basic-addon1"
                          value={this.state.unique_key}
                          onChange={e => this.setState({ unique_key: e.target.value })}
                        />
                      </InputGroup>
                      <div style={{ color: 'red' }} className="error-block mt-2">{this.state.key_error}</div>
                    </FormGroup>
                    <Form.Group>
                    <InputGroup className="mb-3">
                      <InputGroup.Prepend>
                        <InputGroup id="basic-addon1">{t('Select classification')}<span style={{ color: "red" }}>*</span></InputGroup>
                      </InputGroup.Prepend>
                        <Form.Control as="select" name="package_id"
                          required
                          value={this.state.classification_id}
                          onChange={e => this.setState({ classification_id: e.target.value })} >
                          {this.state.classifications.map(classification => <option value={classification.id}>{classification.classification}</option>)}
                        </Form.Control>
                      </InputGroup>
                    </Form.Group>
                    <Form.Group>
                    <InputGroup className="mb-3">
                      <InputGroup.Prepend>
                        <InputGroup id="basic-addon1">{t('Select where and all to show')}<span style={{ color: "red" }}>*</span></InputGroup>
                      </InputGroup.Prepend>
                      <Form.Control as="select" name="where_to_show"
                          value={this.state.where_to_show}
                          onChange={e => this.setState({ where_to_show: e.target.value })} >
                          <option value='1' >{t("Show in sub sites also")} </option>
                          <option value='2' >{t("Show in main site only")}</option>
                      </Form.Control>
                      </InputGroup>
                    </Form.Group>
                    <Form.Group>
                      <InputGroup className="mb-3">
                        <InputGroup.Prepend>
                          <InputGroup id="basic-addon1">{t('Order of functions')}<span style={{ color: "red" }}>*</span></InputGroup>
                        </InputGroup.Prepend>
                        <FormControl
                          aria-describedby="basic-addon1"
                          value={this.state.function_order}
                          onChange={e => this.setState({ function_order: e.target.value })}
                        />
                      </InputGroup>
                      <div style={{ color: 'red' }} className="error-block mt-2">{this.state.order_error}</div>
                    </Form.Group>
                    <Form.Group>
                      <InputGroup className="mb-3">
                        <InputGroup.Prepend>
                          <InputGroup id="basic-addon1">{t('Added')}<span style={{ color: "red" }}>*</span></InputGroup>
                        </InputGroup.Prepend>
                        <FormControl
                          aria-describedby="basic-addon1"
                          value={this.state.added_or_not}
                          onChange={e => this.setState({ added_or_not: e.target.value })}
                        />
                      </InputGroup>
                      <div style={{ color: 'red' }} className="error-block mt-2">{this.state.added_or_not_error}</div>
                    </Form.Group>
                    <Form.Group>
                      <InputGroup className="mb-3">
                        <InputGroup.Prepend>
                          <InputGroup id="basic-addon1">{t('Public')}<span style={{ color: "red" }}></span></InputGroup>
                        </InputGroup.Prepend>
                        <FormControl
                          aria-describedby="basic-addon1"
                          value={this.state.public_or_not}
                          onChange={e => this.setState({ public_or_not: e.target.value })}
                        />
                      </InputGroup>
                    </Form.Group>
                    <Button type="submit" disabled={!this.state.savevalue} color="primary">{t('Save')}</Button>
                  </Form>
                </Container>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default translate(Functions)
