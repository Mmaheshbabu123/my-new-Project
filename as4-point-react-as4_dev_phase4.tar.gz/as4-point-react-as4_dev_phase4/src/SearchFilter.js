export const SearchFilter = {
  getData,
  filterItemByColumn,
  getPageData,
  getCountPage,
  verifyPageNumber,
}
function getData(filledStates, data) {
  switch (filledStates.length) {
    case 1:
      return filterItemByColumn(data, filledStates[0]['name'], filledStates[0]['value'], data);
      break;
    case 2:
      return filterItemBy2Column(data, filledStates);
      break;
    case 3:
      return filterItemBy3Column(data, filledStates);
      break;
    case 4:
      return filterItemBy4Column(data, filledStates);
      break;
    case 5:
      return filterItemBy5Column(data, filledStates);
      break;
    case 6:
      return filterItemBy6Column(data, filledStates);
      break;
    case 7:
      return filterItemBy7Column(data, filledStates);
      break;
    case 8:
      return filterItemBy8Column(data, filledStates);
      break;
    case 9:
      return filterItemBy9Column(data, filledStates);
      break;
    case 10:
      return filterItemBy10Column(data, filledStates);
      break;
    case 11:
      return filterItemBy11Column(data, filledStates);
    break;
    default:
      return data;
  }
}
function filterItemByColumn(items, columnName, value, copyItems) {
  var docItems = '';
  docItems = (copyItems.length > 0) ? (copyItems) : items;
  let res = '';
  return docItems.filter(function (item) {
    if (item[columnName] !== null) {
      res = item[columnName].toLowerCase().search(
        value !== undefined ? value.toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}
function filterItemBy2Column(items, filedColumn) {
  let res = '';
  return items.filter(function (item) {
    if (item[filedColumn[0]['name']] !== null && item[filedColumn[1]['name']] !== null) {
      res = item[filedColumn[0]['name']].toLowerCase().search(
        filedColumn[0]['value'] !== undefined ? filedColumn[0]['value'].toLowerCase() : '') !== -1 && item[filedColumn[1]['name']].toLowerCase().search(
          filedColumn[1]['value'] !== undefined ? filedColumn[1]['value'].toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}
function filterItemBy3Column(items, filedColumn) {
  let res = '';
  return items.filter(function (item) {
    if (item[filedColumn[0]['name']] !== null && item[filedColumn[1]['name']] !== null && item[filedColumn[2]['name']] !== null) {
      res = item[filedColumn[0]['name']].toLowerCase().search(
        filedColumn[0]['value'] !== undefined ? filedColumn[0]['value'].toLowerCase() : '') !== -1 && item[filedColumn[1]['name']].toLowerCase().search(
          filedColumn[1]['value'] !== undefined ? filedColumn[1]['value'].toLowerCase() : '') !== -1 && item[filedColumn[2]['name']].toLowerCase().search(
            filedColumn[2]['value'] !== undefined ? filedColumn[2]['value'].toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}
function filterItemBy4Column(items, filedColumn) {
  let res = '';
  return items.filter(function (item) {
    if (item[filedColumn[0]['name']] !== null && item[filedColumn[1]['name']] !== null &&
      item[filedColumn[2]['name']] !== null && item[filedColumn[3]['name']] !== null) {
      res = item[filedColumn[0]['name']].toLowerCase().search(
        filedColumn[0]['value'] !== undefined ? filedColumn[0]['value'].toLowerCase() : '') !== -1 && item[filedColumn[1]['name']].toLowerCase().search(
          filedColumn[1]['value'] !== undefined ? filedColumn[1]['value'].toLowerCase() : '') !== -1 && item[filedColumn[2]['name']].toLowerCase().search(
            filedColumn[2]['value'] !== undefined ? filedColumn[2]['value'].toLowerCase() : '') !== -1 && item[filedColumn[3]['name']].toLowerCase().search(
              filedColumn[3]['value'] !== undefined ? filedColumn[3]['value'].toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}
function filterItemBy5Column(items, filedColumn) {
  let res = '';
  return items.filter(function (item) {
    if (item[filedColumn[0]['name']] !== null && item[filedColumn[1]['name']] !== null &&
      item[filedColumn[2]['name']] !== null && item[filedColumn[3]['name']] !== null && item[filedColumn[4]['name']] !== null) {
      res = item[filedColumn[0]['name']].toLowerCase().search(
        filedColumn[0]['value'] !== undefined ? filedColumn[0]['value'].toLowerCase() : '') !== -1 && item[filedColumn[1]['name']].toLowerCase().search(
          filedColumn[1]['value'] !== undefined ? filedColumn[1]['value'].toLowerCase() : '') !== -1 && item[filedColumn[2]['name']].toLowerCase().search(
            filedColumn[2]['value'] !== undefined ? filedColumn[2]['value'].toLowerCase() : '') !== -1 && item[filedColumn[3]['name']].toLowerCase().search(
              filedColumn[3]['value'] !== undefined ? filedColumn[3]['value'].toLowerCase() : '') !== -1 && item[filedColumn[4]['name']].toLowerCase().search(
                filedColumn[4]['value'] !== undefined ? filedColumn[4]['value'].toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}
function filterItemBy6Column(items, filedColumn) {
  let res = '';
  return items.filter(function (item) {
    if (item[filedColumn[0]['name']] !== null && item[filedColumn[1]['name']] !== null &&
      item[filedColumn[2]['name']] !== null && item[filedColumn[3]['name']] !== null &&
      item[filedColumn[4]['name']] !== null && item[filedColumn[5]['name']] !== null) {
      res = item[filedColumn[0]['name']].toLowerCase().search(
        filedColumn[0]['value'] !== undefined ? filedColumn[0]['value'].toLowerCase() : '') !== -1 && item[filedColumn[1]['name']].toLowerCase().search(
          filedColumn[1]['value'] !== undefined ? filedColumn[1]['value'].toLowerCase() : '') !== -1 && item[filedColumn[2]['name']].toLowerCase().search(
            filedColumn[2]['value'] !== undefined ? filedColumn[2]['value'].toLowerCase() : '') !== -1 && item[filedColumn[3]['name']].toLowerCase().search(
              filedColumn[3]['value'] !== undefined ? filedColumn[3]['value'].toLowerCase() : '') !== -1 && item[filedColumn[4]['name']].toLowerCase().search(
                filedColumn[4]['value'] !== undefined ? filedColumn[4]['value'].toLowerCase() : '') !== -1 && item[filedColumn[5]['name']].toLowerCase().search(
                  filedColumn[5]['value'] !== undefined ? filedColumn[5]['value'].toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}
function filterItemBy7Column(items, filedColumn) {
  let res = '';
  return items.filter(function (item) {
    if (item[filedColumn[0]['name']] !== null && item[filedColumn[1]['name']] !== null &&
      item[filedColumn[2]['name']] !== null && item[filedColumn[3]['name']] !== null &&
      item[filedColumn[4]['name']] !== null && item[filedColumn[5]['name']] !== null && item[filedColumn[6]['name']] !== null) {
      res = item[filedColumn[0]['name']].toLowerCase().search(
        filedColumn[0]['value'] !== undefined ? filedColumn[0]['value'].toLowerCase() : '') !== -1 && item[filedColumn[1]['name']].toLowerCase().search(
          filedColumn[1]['value'] !== undefined ? filedColumn[1]['value'].toLowerCase() : '') !== -1 && item[filedColumn[2]['name']].toLowerCase().search(
            filedColumn[2]['value'] !== undefined ? filedColumn[2]['value'].toLowerCase() : '') !== -1 && item[filedColumn[3]['name']].toLowerCase().search(
              filedColumn[3]['value'] !== undefined ? filedColumn[3]['value'].toLowerCase() : '') !== -1 && item[filedColumn[4]['name']].toLowerCase().search(
                filedColumn[4]['value'] !== undefined ? filedColumn[4]['value'].toLowerCase() : '') !== -1 && item[filedColumn[5]['name']].toLowerCase().search(
                  filedColumn[5]['value'] !== undefined ? filedColumn[5]['value'].toLowerCase() : '') !== -1 && item[filedColumn[6]['name']].toLowerCase().search(
                    filedColumn[6]['value'] !== undefined ? filedColumn[6]['value'].toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}
function filterItemBy8Column(items, filedColumn) {
  let res = '';
  return items.filter(function (item) {
    if (item[filedColumn[0]['name']] !== null && item[filedColumn[1]['name']] !== null &&
      item[filedColumn[2]['name']] !== null && item[filedColumn[3]['name']] !== null &&
      item[filedColumn[4]['name']] !== null && item[filedColumn[5]['name']] !== null &&
      item[filedColumn[6]['name']] !== null && item[filedColumn[7]['name']] !== null) {
      res = item[filedColumn[0]['name']].toLowerCase().search(
        filedColumn[0]['value'] !== undefined ? filedColumn[0]['value'].toLowerCase() : '') !== -1 && item[filedColumn[1]['name']].toLowerCase().search(
          filedColumn[1]['value'] !== undefined ? filedColumn[1]['value'].toLowerCase() : '') !== -1 && item[filedColumn[2]['name']].toLowerCase().search(
            filedColumn[2]['value'] !== undefined ? filedColumn[2]['value'].toLowerCase() : '') !== -1 && item[filedColumn[3]['name']].toLowerCase().search(
              filedColumn[3]['value'] !== undefined ? filedColumn[3]['value'].toLowerCase() : '') !== -1 && item[filedColumn[4]['name']].toLowerCase().search(
                filedColumn[4]['value'] !== undefined ? filedColumn[4]['value'].toLowerCase() : '') !== -1 && item[filedColumn[5]['name']].toLowerCase().search(
                  filedColumn[5]['value'] !== undefined ? filedColumn[5]['value'].toLowerCase() : '') !== -1 && item[filedColumn[6]['name']].toLowerCase().search(
                    filedColumn[6]['value'] !== undefined ? filedColumn[6]['value'].toLowerCase() : '') !== -1 && item[filedColumn[7]['name']].toLowerCase().search(
                      filedColumn[7]['value'] !== undefined ? filedColumn[7]['value'].toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}

function filterItemBy9Column(items, filedColumn) {
  let res = '';
  return items.filter(function (item) {
    if (item[filedColumn[0]['name']] !== null && item[filedColumn[1]['name']] !== null &&
      item[filedColumn[2]['name']] !== null && item[filedColumn[3]['name']] !== null &&
      item[filedColumn[4]['name']] !== null && item[filedColumn[5]['name']] !== null &&
      item[filedColumn[6]['name']] !== null && item[filedColumn[7]['name']] !== null && item[filedColumn[8]['name']] !== null) {
      res = item[filedColumn[0]['name']].toLowerCase().search(
        filedColumn[0]['value'] !== undefined ? filedColumn[0]['value'].toLowerCase() : '') !== -1 && item[filedColumn[1]['name']].toLowerCase().search(
          filedColumn[1]['value'] !== undefined ? filedColumn[1]['value'].toLowerCase() : '') !== -1 && item[filedColumn[2]['name']].toLowerCase().search(
            filedColumn[2]['value'] !== undefined ? filedColumn[2]['value'].toLowerCase() : '') !== -1 && item[filedColumn[3]['name']].toLowerCase().search(
              filedColumn[3]['value'] !== undefined ? filedColumn[3]['value'].toLowerCase() : '') !== -1 && item[filedColumn[4]['name']].toLowerCase().search(
                filedColumn[4]['value'] !== undefined ? filedColumn[4]['value'].toLowerCase() : '') !== -1 && item[filedColumn[5]['name']].toLowerCase().search(
                  filedColumn[5]['value'] !== undefined ? filedColumn[5]['value'].toLowerCase() : '') !== -1 && item[filedColumn[6]['name']].toLowerCase().search(
                    filedColumn[6]['value'] !== undefined ? filedColumn[6]['value'].toLowerCase() : '') !== -1 && item[filedColumn[7]['name']].toLowerCase().search(
                      filedColumn[7]['value'] !== undefined ? filedColumn[7]['value'].toLowerCase() : '') !== -1 && item[filedColumn[8]['name']].toLowerCase().search(
                        filedColumn[8]['value'] !== undefined ? filedColumn[8]['value'].toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}

function filterItemBy10Column(items, filedColumn) {
  let res = '';
  return items.filter(function (item) {
    if (item[filedColumn[0]['name']] !== null && item[filedColumn[1]['name']] !== null &&
      item[filedColumn[2]['name']] !== null && item[filedColumn[3]['name']] !== null &&
      item[filedColumn[4]['name']] !== null && item[filedColumn[5]['name']] !== null &&
      item[filedColumn[6]['name']] !== null && item[filedColumn[7]['name']] !== null &&
      item[filedColumn[8]['name']] !== null && item[filedColumn[9]['name']] !== null) {
      res = item[filedColumn[0]['name']].toLowerCase().search(
        filedColumn[0]['value'] !== undefined ? filedColumn[0]['value'].toLowerCase() : '') !== -1 && item[filedColumn[1]['name']].toLowerCase().search(
          filedColumn[1]['value'] !== undefined ? filedColumn[1]['value'].toLowerCase() : '') !== -1 && item[filedColumn[2]['name']].toLowerCase().search(
            filedColumn[2]['value'] !== undefined ? filedColumn[2]['value'].toLowerCase() : '') !== -1 && item[filedColumn[3]['name']].toLowerCase().search(
              filedColumn[3]['value'] !== undefined ? filedColumn[3]['value'].toLowerCase() : '') !== -1 && item[filedColumn[4]['name']].toLowerCase().search(
                filedColumn[4]['value'] !== undefined ? filedColumn[4]['value'].toLowerCase() : '') !== -1 && item[filedColumn[5]['name']].toLowerCase().search(
                  filedColumn[5]['value'] !== undefined ? filedColumn[5]['value'].toLowerCase() : '') !== -1 && item[filedColumn[6]['name']].toLowerCase().search(
                    filedColumn[6]['value'] !== undefined ? filedColumn[6]['value'].toLowerCase() : '') !== -1 && item[filedColumn[7]['name']].toLowerCase().search(
                      filedColumn[7]['value'] !== undefined ? filedColumn[7]['value'].toLowerCase() : '') !== -1 && item[filedColumn[8]['name']].toLowerCase().search(
                        filedColumn[8]['value'] !== undefined ? filedColumn[8]['value'].toLowerCase() : '') !== -1 && item[filedColumn[9]['name']].toLowerCase().search(
                          filedColumn[9]['value'] !== undefined ? filedColumn[9]['value'].toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}
function filterItemBy11Column(items, filedColumn) {
  let res = '';
  return items.filter(function (item) {
    if (item[filedColumn[0]['name']] !== null && item[filedColumn[1]['name']] !== null &&
      item[filedColumn[2]['name']] !== null && item[filedColumn[3]['name']] !== null &&
      item[filedColumn[4]['name']] !== null && item[filedColumn[5]['name']] !== null &&
      item[filedColumn[6]['name']] !== null && item[filedColumn[7]['name']] !== null &&
      item[filedColumn[8]['name']] !== null && item[filedColumn[9]['name']] !== null && item[filedColumn[10]['name']] !== null){
      res = item[filedColumn[0]['name']].toLowerCase().search(
        filedColumn[0]['value'] !== undefined ? filedColumn[0]['value'].toLowerCase() : '') !== -1 && item[filedColumn[1]['name']].toLowerCase().search(
          filedColumn[1]['value'] !== undefined ? filedColumn[1]['value'].toLowerCase() : '') !== -1 && item[filedColumn[2]['name']].toLowerCase().search(
            filedColumn[2]['value'] !== undefined ? filedColumn[2]['value'].toLowerCase() : '') !== -1 && item[filedColumn[3]['name']].toLowerCase().search(
              filedColumn[3]['value'] !== undefined ? filedColumn[3]['value'].toLowerCase() : '') !== -1 && item[filedColumn[4]['name']].toLowerCase().search(
                filedColumn[4]['value'] !== undefined ? filedColumn[4]['value'].toLowerCase() : '') !== -1 && item[filedColumn[5]['name']].toLowerCase().search(
                  filedColumn[5]['value'] !== undefined ? filedColumn[5]['value'].toLowerCase() : '') !== -1 && item[filedColumn[6]['name']].toLowerCase().search(
                    filedColumn[6]['value'] !== undefined ? filedColumn[6]['value'].toLowerCase() : '') !== -1 && item[filedColumn[7]['name']].toLowerCase().search(
                      filedColumn[7]['value'] !== undefined ? filedColumn[7]['value'].toLowerCase() : '') !== -1 && item[filedColumn[8]['name']].toLowerCase().search(
                        filedColumn[8]['value'] !== undefined ? filedColumn[8]['value'].toLowerCase() : '') !== -1 && item[filedColumn[9]['name']].toLowerCase().search(
                          filedColumn[9]['value'] !== undefined ? filedColumn[9]['value'].toLowerCase() : '') !== -1 && item[filedColumn[10]['name']].toLowerCase().search(
                            filedColumn[10]['value'] !== undefined ? filedColumn[10]['value'].toLowerCase() : '') !== -1;
    }
    if (res) {
      return res;
    }
  });
}
function getPageData(id, currentPage, list, allData) {
  const items = (list.length > 0) ? list : allData;
  return items.slice(currentPage * (id - 1), currentPage * id);
}

function getCountPage(items, currentPage) {
  return (items.length > currentPage) ? Math.ceil(items.length / currentPage) : 0;
}

function verifyPageNumber(initialId, propsId, resonstructedData, currentPage) {
  let pageData = getPageData(initialId, currentPage, resonstructedData, resonstructedData);
  let result = pageData.map(value => { return value.id });
  if (result.includes(propsId)) {
    return [pageData, initialId];
  } else {
    initialId = initialId + 1;
    return verifyPageNumber(initialId, propsId, resonstructedData, currentPage);
  }

}
