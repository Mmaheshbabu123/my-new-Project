import React, { Component, Suspense } from 'react'
import { translate } from '../../language'
import * as Reactbootstrap from 'react-bootstrap'
import { datasave } from '../../_services/db_services'
import {store } from '../../store'
import '../../Webforms/webform.css'
import CheckBox from '../../CheckBox';
import { OCAlert } from '@opuscapita/react-alerts';
import * as moment from 'moment/moment';
import DatePicker from 'react-datepicker';
import { SketchPicker } from 'react-color';
const CusomCss = React.lazy(() => import('../../Webforms/Actions/CssAction/CustomCss'));

const ALLSTEPS = 777777;
class GroundPlanActions extends Component {
    child_data = []; track = 0; NAoption = false;
    cssobj = {};
    constructor(props) {
        let storage = store.getState();
        let actions = storage.UserData.webform_authors
        const operators = storage.UserData.webform_operator_linking
        let isDateType = undefined
        super(props)
        this.state = {
            t: props.t,
            actions: actions !== undefined ? actions : [],
            author: 'Person',
            control: 12,
            orgname: undefined,
            operators: operators !== undefined ? operators : [],
            type: this.props.type,
            selectedType: parseInt(this.props.action) === window.WEBFORM_CALCULATION ? window.WEBFORM_CALCULATION : (parseInt(this.props.action) === window.WEBFORM_WORKFLOW ? window.WEBFORM_WORKFLOW : window.PERSON_ENTITY),
            orgArrayIds: window.WEBFORM_ORG_ID,
            allOrgUnits: {},
            webformid: this.props.webform_id,
            controls: [],
            controlType: '',
            workflowsteps: [],
            value: undefined,
            getValueOptions: [],
            child_data: [],
            startDate: '',
            enter:false,
            leave:true,
            flag:this.props.flag,
            selectvaluetype:undefined,
            periodtype:1,
            category:4,
            task_id:this.props.task_id,
            count:undefined,
            PJDG: [],
            color:undefined,
            background:undefined,
            clickorigin:undefined,
            popUpShow:false,
            customcss:'',
            border:'',
        }
        this.getchild = React.createRef();
    }
    // changeActions = (e) => {
    //     const {  value, childNodes, selectedIndex } = e.target;
    //     var id = childNodes[selectedIndex].getAttribute('id')
    //
    //     this.setState({
    //         author: value,
    //         selectedType: id,
    //         operator:undefined,
    //         operatorId:undefined,
    //         controlType:undefined,
    //         controlId:undefined,
    //         controller:undefined,
    //     })
    // }
    changeOperators = (e) => {
        const { value, childNodes, selectedIndex } = e.target;
        var id = childNodes[selectedIndex].getAttribute('id')
        this.setState({ operatorId: id, operator: value })
        this.props.handleGPActionOptions(id,value,'operators');

    }
    handlePickerChange =(color,type)=>{
      let string = type === 1 ?'color':'background'

        this.setState({
            [string]:color.hex
        })
        this.props.handleGPActionOptions(string,color.hex,'css');
    }
    handleadd(type){
      console.log(type)
        this.setState({clickorigin:type,popUpShow:true})
    }
    handleCheckBox = (e,type)=>{
        const {target} =  e;
        type === 0 ? this.setState({enter:target.checked}):this.setState({leave:target.checked})
    }
    handleorg = (e) => {
        const {  value, childNodes, selectedIndex } = e.target
        let id = childNodes[selectedIndex].getAttribute('id')
        let name = childNodes[selectedIndex].getAttribute('name')
        this.setState({
            orgid: id,
            orgname: name

        })
    }
    async componentDidMount() {
        const { orgArrayIds } = this.state
        const { edit, data, apidata, from } = this.props
        if(apidata !== undefined) {
            let contr = [];
            if(from === 'actions'){
            await  datasave.service(window.FETCH_ALL_WEBELEMENTS + '?webform_id=' + this.props.webform_id, 'POST').then(res =>{
                if(parseInt(res['status']) === 200){
                     let ids = apidata['controls'].map( i=> i.id);
                    res['data'].map(item=>{
                        if(ids.includes(item.id)){
                            contr.push(item)
                        }
                    })
                }
            })}
            apidata['controls'] =  contr.length >0 ?contr:apidata['controls'];
            let response = apidata

            if(this.props.action_flow === 'edit' &&  this.props.details.flag === 1) {

              //this.setStateWorkflowAndCalculation(this.props.details);
          //  }
              //  orgArrayIds.includes(parseInt(data.action)) ? this.setStateOrgData(response) : this.setStateWorkflowAndCalculation(response);
            } else {
                this.setState({
                    allOrgUnits: response,
                    controls: response['controls'],
                    workflowsteps: response['workflow']
                })
            }
        } else {
           this.getDataFromApi();
        }
        if(this.props.action_flow === 'edit' &&  this.props.details.flag === 1) {
          var url = window.POST_TASK_PLANNER_DETAILS + '/' + this.props.task_id;
                  datasave.service(url, 'GET')
                    .then(resultObj => {
                     this.setStateWorkflowAndCalculation(resultObj.action_data);
                    })
        //  this.setStateWorkflowAndCalculation(this.props.details);
      //  }
          //  orgArrayIds.includes(parseInt(data.action)) ? this.setStateOrgData(response) : this.setStateWorkflowAndCalculation(response);
        }
    }
//     componentWillReceiveProps(nextProps) {
//  console.log('componentWillReceiveProps', nextProps);
//  if (this.props !== nextProps) {
//   // if(prevProps.task_id !== this.props.task_id) {
//        if(this.props.action_flow === 'edit' && this.props.details.flag === 1) {
//          var url = window.POST_TASK_PLANNER_DETAILS + '/' + this.props.task_id;
//          datasave.service(url, 'GET')
//            .then(resultObj => {
//             this.setStateWorkflowAndCalculation(resultObj);
//            })
//          console.log(this.props.details)
//
//        }
//    //}
//  }
// }
    getDataFromApi=()=>{
        const { orgArrayIds } = this.state
        const { edit, data } = this.props

        datasave.service(window.GET_ORG_UNITS + '/' + this.props.webform_id, 'GET')
            .then(response => {
                if (edit) {

                    orgArrayIds.includes(parseInt(data.action)) ? this.setStateOrgData(response) : this.setStateWorkflowAndCalculation(response);
                } else {
                    this.setState({
                        allOrgUnits: response,
                        controls: response['controls'],
                        workflowsteps: response['workflow']
                    })
                }
            })
    }
    setStateOrgData = (response) => {
        const { data } = this.props
        this.setState({
            allOrgUnits: response,
            controls: response['controls'],
            workflowsteps: response['workflow'],
            author: data.author,
            orgname: data.orgunit,
            orgid: data.orgid,
            selectedType: parseInt(data.action),
        })
    }
    setStateWorkflowAndCalculation = (response) => {
      console.log(response)
        const { data} = this.props
        let selected = []
        selected = Object.values(this.props.controls).filter(({id})=>id===response.web_element_id);
        this.setState({
            operator:response.operator_id,
            value:response.list_value,
            controlType: (selected.length > 0)?selected[0].type:'',
            controlId:response.web_element_id,
            selectvaluetype:response.list_value_type,
            valueId:response.list_value_id,
            count:response.list_value,
            periodtype:response.custom_period,
            category:response.custom_category,
            color:(response.css_id !== null)?response.css_id:undefined,
        })
this.props.details.flag = 0;
        this.isDateType = parseInt(data.isDateType)

    }
    changeControls = (e) => {
        const { value, childNodes, selectedIndex } = e.target
        let id = childNodes[selectedIndex].getAttribute('id')
        let name = childNodes[selectedIndex].getAttribute('name')
        let typeid = childNodes[selectedIndex].getAttribute('type')
        this.NAoption = false
        this.setState({
            controlId: parseInt(id),
            controller: name,
            selectedController: name,
            controlType: typeid,
            value: undefined,
            child_data:[],
            selectvaluetype:1,
            valueId:undefined,
        })
        this.props.handleGPActionOptions(name,parseInt(id),'controll');
    }
    changeValues = (e,type = 1) => {
        const{controlType} =  this.state
        let value = type ===1 ?e.target.value: e
        let name  =  undefined
        let valueId = 0
          if([window.NUMERICFIELD,window.DECIMALFIELD].includes(parseInt(controlType))){
          value =   e.target.validity.valid ? value: this.state.value!== undefined?this.state.value:''
        }
        name = value
        if([11,12,9,10,7,8].includes(parseInt(controlType))){
            const {  childNodes, selectedIndex } = e.target
            valueId = childNodes[selectedIndex].getAttribute('id')
            name  = childNodes[selectedIndex].getAttribute('name')
        }
        this.setState({
            value: name,
            valueId:valueId
        })
      this.props.handleGPActionOptions(name,valueId,'changevalues');
    }

    cancelrule = (e) => {
        this.props.changeComponent(false)
    }

    changeWorkflow = (e) => {
        const { value, childNodes, selectedIndex } = e.target
        let id = childNodes[selectedIndex].getAttribute('id')
        let name = childNodes[selectedIndex].getAttribute('name')
        this.setState({
            workflowid: parseInt(id),
            workflow: name
        })
    }

    getValueOptions = (type) => {
        let controlType = parseInt(type)
        const { value, valueId } = this.state
        let values = [];
        if (controlType === window.DATEFIELD) {

                let controls  = this.props.controls;
                let obj ={}; let type = 1;
                const item = controls.filter( item =>{ return item.id === this.state.controlId});
                 if(item.length){
                   Object.values(item).map(item =>{
                        obj = JSON.parse(item.json_data);
                        return obj
                   })}
                   type = obj.display_type !== undefined ? obj.display_type:1;
                if( parseInt(type) === 2){
                    this.isDateType = 2
                          values.push(
                                <Reactbootstrap.Form.Group controlId="form">

                                    <DatePicker

                                            selected={ value !== undefined ? new Date(value):undefined}
                                            onChange={(date) => this.changeValues(date,0)}
                                            showTimeSelect
                                            withPortal = {true}
                                            timeCaption="time"
                                            dateFormat="dd-MM-yyyy h:mm aa"
                                    />

                                    </Reactbootstrap.Form.Group>
                          )
                }else{
                    this.isDateType = 1;
                    values.push(<Reactbootstrap.Form.Control
                    type="date" name="date" onChange={this.changeValues} style={{ }} value={value}>
                    </Reactbootstrap.Form.Control>)
                }
        }
        if (controlType === window.TEXTBOX) {
            values.push(
                <Reactbootstrap.Form.Control as="textarea" onChange={this.changeValues} value={value} rows="3" />
            )
        }
        if (controlType === window.DATABASELIST || controlType === window.TEXTFIELD || controlType === window.DECIMALFIELD || controlType === window.NUMERICFIELD  || controlType === window.DATABASELIST_MULTISELECT) {
            values.push(
                <Reactbootstrap.Form.Control type='text' pattern = {(controlType === window.DECIMALFIELD || controlType === window.NUMERICFIELD) ? "[0-9]+(,[0-9]+)*,?":true} style={{  }} onChange={this.changeValues} placeholder = 'Value' value={value === undefined ?"":value} />
            )
        }
        if(controlType === Window.LIST || controlType === window.RADIO_BUTTON || controlType === Window.CHECKBOX || controlType === window.LISTORG){
            if(this.state.child_data.length>0){
                let options = [];
                Object.values(this.state.child_data).map(item => {
                  return   options.push(<option  key = {item.id} id={item.id} name  = {item.name} value = {item.id}> {item.name}</option>)
                })
                if(controlType !== window.LISTORG){
                    if(this.NAoption){
                        options.push(<option key = {-1} value  = {-1} name = "N/A" id = {-1}>{t("N/A")}</option>)
                    }
                }
                values.push(
                    <Reactbootstrap.Form.Control style={{  }} as="select" name="outype" value={valueId} onChange={this.changeValues} >
                        <option>{t("---Select---")}</option>
                        {options}
                    </Reactbootstrap.Form.Control>
                )
            }
        }
        if (values.length === 0) {
            values.push(
                <h6>No values  assigned for current element </h6>
            )
        }
        this.track = 0

        return values;


    }
    getparentId =()=>{
            let controls  = this.props.controls;
            let obj ={}; let id = 0;
             const item = controls.filter( item =>{ return item.id === this.state.controlId});
                if(item.length){
                   Object.values(item).map(item =>{
                      return  obj = JSON.parse(item.json_data);
                   })}
                  if(obj !== null){
                    this.NAoption = obj.na !== undefined ?(parseInt(obj.na) === 1 ? true:false) :false;
                    id = obj.list !== undefined ? obj.list :id;
                  }

            return id;

    }
    getListOrgUnits =()=>{
        let controls  = this.props.controls;
        let obj ={};
        const item = controls.filter( item =>{ return item.id === this.state.controlId});
        let selectedItemsOfLou = [];

        if(item.length){
            Object.values(item).map(item =>{
              return obj = item.json_data!= null? JSON.parse(item.json_data):undefined;
           })
        if(obj!== undefined && obj !== null) {
          let allPJDG = this.state.PJDG;
          if(obj.selectAll === 1) {
            selectedItemsOfLou = allPJDG.filter(itemOfPjdg => (itemOfPjdg.category === obj.orgUnit));
          } else {
            selectedItemsOfLou = obj.selectedItems;
          }
           if(obj.showAllPersons == true) {
              this.getPersonsInorg(selectedItemsOfLou);
           } else {
             this.setState({
                 child_data: selectedItemsOfLou,
             })
           }
        }
    }
    }
    getPersonsInorg = (data)=>{
      const {t}=this.state;
        let obj ={
            org:data
        }
        datasave.service(window.GET_PERSONS_ACTIONS, 'POST',obj).then(
            response =>{
              if(response['status'] == 500){
                OCAlert.alertWarning(t("error occured form our side, we're unable to process"), { timeOut: 2000 });
                this.setState({
                  child_data:[]
                })
              }else{
                this.setState({
                    child_data:response['data']
                })
              }
            })
    }
    handleRadioSelect =(e,type)=>{
        this.setState({
            selectvaluetype:type,
            valueId:undefined,
            value:undefined
        })
      this.props.handleGPActionOptions(1,type,'radio');
    }
    handlePeriodChange(e,from){
      const {  childNodes, selectedIndex } = e.target
      let valueId = childNodes[selectedIndex].getAttribute('id')
        this.setState({
          [from]:parseInt(valueId),
        },()=>{this.setState({
          value:this.prepareString()
        })})
        this.props.handleGPActionOptions(this.prepareString(),parseInt(valueId),from.toString());
    }
    changePeriodValue =(e)=>{
      const{target}= e
      const {periodtype,category} =  this.state
      let value = target.validity.valid ? target.value :this.state.count!== undefined? this.state.value:''
      this.setState({
        count:value,
        valueId:900009,
      },()=>{this.setState({
        value:this.prepareString()
      })})
this.props.handleGPActionOptions(this.prepareString(),value,'custom_date_value',900009);
    }
    prepareString =()=>{
      const {periodtype,category,count} =  this.state

      let symbol = periodtype === 1 ? " + " : " - ";
      let type  = category === 4 ? ' Year': category === 3 ? ' Months':category === 2 ? ' Days': category === 1 ?' Hours':' Minutes';
      return "Now "+ symbol + count + type;
    }
    render() {
          const { SHOWCSS } =  this.props
            if(SHOWCSS){
             return  this.getCssRender()
            }else{
                return this.getRenderContent()
            }


    }
    getRenderContent =()=>{

        const { author, operators, selectedType, orgArrayIds, allOrgUnits, t,workflowsteps,
            type, controller, operator,color,background, popUpShow, border, workflow, controlType, orgname, controls,controlId,
            selectvaluetype, orgid, workflowid} = this.state;
            const { SHOWCSS } =  this.props
          //   if(this.props.action_flow === 'edit' &&  this.props.details.flag === 1) {
          //     this.setStateWorkflowAndCalculation(this.props.details);
          // //  }
          //     //  orgArrayIds.includes(parseInt(data.action)) ? this.setStateOrgData(response) : this.setStateWorkflowAndCalculation(response);
          //   }
        let options = []; let operatorOptions = []; let orgOptions = []; let controlOptions = []; let workflowOptions = [];

        this.state.actions.forEach(element => options.push(<option key = {element.typeid} id={element.typeid}>{element.name}</option>))
        Object.keys(operators).map((item) => {
            if (item == controlType) {
                let arr = operators[item]
                return arr.forEach(ele =>  operatorOptions.push(<option id ="" key ="" value = {ele.typeid} > {ele.name} </option>))

            }
        })
        let string = parseInt(selectedType) === window.PERSON_ENTITY ? 'person' : parseInt(selectedType) === 2 ? 'jobs' : parseInt(selectedType) === 3 ? 'departments' : 'groups';
        let obj = allOrgUnits[string] === undefined ? [] : allOrgUnits[string];
        obj.map(item => {
            return orgOptions.push(<option key={item.id} value = {item.id} name = {item.name} id={item.id}>{item.name}</option>)
        })
        let controlsdata = this.props.controls;
        controlsdata.map(item => {
          let namewithtype = item.name+'('+item.typename+')';
            controlOptions.push(<option key = {item.id} name= {namewithtype}  value  = {item.id} type={item.type} id={item.id}> {item.name}({item.typename}) </option>)
        })
        workflowsteps.map(item => {
            workflowOptions.push(<option  key = {item.id} value  = {item.id} name={item.step_name} id={item.id}> {item.step_name} </option>)
        })
        return (
            <div className='container '>
                <div className='row ' >
                    <div className='col-md-12' >
                        {((parseInt(selectedType) === window.WEBFORM_CALCULATION) && type.control === 1) &&
                          <div>
                          <div className="col-md-12 row mb-3">
                            <div className="col-md-4">
                              <span style={{color: '#EC661C'}}>
                                {t("Controls:")}
                               </span>
                            </div>
                          <div className="col-md-8 p-0 input_sw">
                             <Reactbootstrap.Form.Control
                                as="select"
                                name="type"
                                value={controlId}
                                onChange={this.changeControls}
                                style={{  }} >
                                <option > {t("---Select---")} </option>
                                {controlOptions}
                            </Reactbootstrap.Form.Control>
                            </div>
                          </div>
                          {/*<div className="col-md-12 row mb-3 ">
                            <div className="col-md-4">
                             <span style={{color: '#EC661C'}}>Operators:</span>
                            </div>
                            <div className="col-md-8 p-0 input_sw">
                              <Reactbootstrap.Form.Control
                                as="select"
                                name="type"
                                value={operator}
                                onChange={this.changeOperators}
                                style={{ }} >
                                <option value = {0}> ---Select--- </option>
                                {operatorOptions}
                            </Reactbootstrap.Form.Control>
                          </div>
                        </div>*/}
                         <div className="col-md-12 row mb-3 ">
                             <div className="col-md-4">
                                <span style={{color: '#EC661C'}}>
                                   {t("Value:")}
                                </span>
                              </div>
                            <div className="col-md-8 p-0 ">
                              <td>
                                <input type='radio'   name='radio'   checked = {selectvaluetype === 1} onChange = {(e)=>this.handleRadioSelect(e,1)} /> Value &nbsp;&nbsp;
                                {/* <input type='radio'   name='radio'    checked = {selectvaluetype === 0} onChange = {(e)=>this.handleRadioSelect(e,0)} /> Webelement*/} &nbsp;&nbsp;
                                {(parseInt(controlType) === window.DATEFIELD) && <span> <input type='radio'   name='radio'    checked = {selectvaluetype === 2} onChange = {(e)=>this.handleRadioSelect(e,2)} />Custom date </span>}
                              </td>
                              {(controlType !== undefined && selectvaluetype === 1) && this.getValueOptions(controlType)}
                              {(controlType !== undefined && selectvaluetype === 0) && this.getWebElemetns(controlOptions)}
                              {( parseInt(controlType) ===  window.DATEFIELD && selectvaluetype === 2) && this.getCustomdate()}
                            </div>

                          </div>
                        {/*  <Reactbootstrap.Form.Group controlId="formBasicEmail">

                             <div className = 'row col-md-12 row mb-3'>
                                 <Reactbootstrap.Form.Label className="col-md-4" style = {{color: 'rgb(236, 102, 28)'}} >Color:</Reactbootstrap.Form.Label>
                              <div style={{marginLeft: '-5px'}} className = 'col-md-4 p-0 input_sw'>
                                  <Reactbootstrap.Form.Control type="text" id ={2}  col='4'  placeholder="Color"
                                  name  = "border"
                                  value = {color}
                                  onInput = {false}
                                  readonly
                                  disabled
                                  />
                              </div>
                              <div className = 'col-md-4'>
                              <Reactbootstrap.Button  variant="outline-primary" onClick = {(e)=>this.handleadd(1)}>
                                  Add here
                              </Reactbootstrap.Button>
                              </div>
                             </div>
                          </Reactbootstrap.Form.Group>*/}
                        </div>

                        }
                    </div>
                </div>
            </div>
        )
    }

    componentDidUpdate(prevProps, prevState) {
        if(this.state.controlType !== undefined && this.state.controlType !== prevState.controlType){
              let parentId =  this.getparentId();


            if(parseInt(this.state.controlType) !== window.LISTORG){
            if(parentId !== 0){
                datasave.service(window.GET_PARENTLIST_DATA + '/' +parentId, 'GET').then(
                response =>{
                        if(response['child_data'].length){
                        const childrens   =  response['child_data'].filter( item =>{ return parseInt(item.hide) === 0});
                    this.setState({
                        child_data:childrens})
                }}
                    )}

        }else{
            this.getListOrgUnits();
        }
      }
        if(prevProps.task_id !== this.props.task_id) {
            if(this.props.action_flow === 'edit' && this.props.details.flag === 1) {
              var url = window.POST_TASK_PLANNER_DETAILS + '/' + this.props.task_id;
                      datasave.service(url, 'GET')
                        .then(resultObj => {
                         this.setStateWorkflowAndCalculation(resultObj.action_data);
                        })
              //console.log(this.props.details)
            //  this.setStateWorkflowAndCalculation(this.props.details);
            }
        }
    }
    Webelement = (options)=>{
        const {controlId,valueId} =  this.state
        let filteredoptions = Object.values(options).filter(option=>{return parseInt(option.key) !== parseInt(controlId)})

        return(
                <Reactbootstrap.Form.Control className = 'input_sw'
                    as="select"
                    name="type"
                    value={valueId}
                    onChange={this.changeWebElementsValue}
                    style={{ }} >
                    <option id = {0} >----Select----</option>
                    {filteredoptions}
                </Reactbootstrap.Form.Control>
        )
    }
    changeWebElementsValue = (e)=>{
        const { value, childNodes, selectedIndex } = e.target
        let id = childNodes[selectedIndex].getAttribute('id')
        let name = childNodes[selectedIndex].getAttribute('name')
        this.setState({
            valueId:id,
            value:name
        })
  this.props.handleGPActionOptions(name,id,'changeWebElementsValue');
    }
    getCustomdate = ()=>{
      const  {category,periodtype,count,t} =  this.state
      // return(<>
      //   <Reactbootstrap.Form.Control className = 'input_sw'
      //       as="select"
      //       name="type"
      //       >
      //       <option id = {0} >----Upcoming feature----</option>
      //   </Reactbootstrap.Form.Control>
      //   </>)
        return(<>
          <div className="col-md-12 row">
           <div className="col-md-4">
          </div>
         <div className="col-md-8 input_sw p-0">
             <Reactbootstrap.Form.Control
               as="select"
               name="type"
               >
               <option>{t("Now")}</option>
           </Reactbootstrap.Form.Control>
       </div>
       </div>
          <div className="col-md-12 row">
           <div className="col-md-4">
            <span style={{color: '#EC661C'}}>  {t("period:")} </span>
          </div>
         <div className="col-md-8 input_sw p-0">
             <Reactbootstrap.Form.Control
               as="select"
               name="type"
               value = {periodtype}
               onChange = {(e)=>this.handlePeriodChange(e,'periodtype')}
               >
               <option id  = {1} value = {1} name  = {'+'}>{t("Addition")}</option>
                <option id  = {2} value = {2} name  = {'-'} >{t("Subtraction")}</option>
           </Reactbootstrap.Form.Control>
       </div>
       </div>
       <div className="col-md-12 row">
        <div className="col-md-4">
         <span style={{color: '#EC661C'}}>  {t("value:")} </span>
       </div>
      <div className="col-md-8 input_sw p-0">
        <Reactbootstrap.Form.Control type='text' pattern = "[0-9]+(,[0-9]+)*,?"   onChange={this.changePeriodValue} placeholder = {t('Value')} value={count}
         />
    </div>
    </div>
    <div className="col-md-12 row">
     <div className="col-md-4">
      <span style={{color: '#EC661C'}}>  {t("category:")} </span>
    </div>
   <div className="col-md-8 input_sw p-0">
       <Reactbootstrap.Form.Control
         as="select"
         name="type"
         value = {category}
         onChange = {(e)=>this.handlePeriodChange(e,'category')}>
         <option id = {4} value = {4} name  = 'Years'>{t("Years")}</option>
         <option id = {3}  value = {3} name = 'Months'> {t("Months")}</option>
         <option id = {2}  value = {2} name = 'Days'> {t("Days")}</option>
         <option id ={1} value = {1}  name  = 'Hours'> {t("Hours")}</option>
     </Reactbootstrap.Form.Control>
 </div>
 </div>
          </>)
    }

    getcssobj =(obj)=>{
this.cssobj = obj
    }
    showPopup =()=>{
        const {popUpShow, color, clickorigin,background} = this.state
        return (<Reactbootstrap.Modal show={popUpShow} onHide = {()=>{this.setState({popUpShow:false})}}>
             <Reactbootstrap.Modal.Header closeButton>
            <Reactbootstrap.Modal.Body>
                {clickorigin === 1 &&  <SketchPicker  className="picker-sketch"
                            color={color}
                            onChangeComplete={(e) =>this.handlePickerChange(e,clickorigin) }
                        />}
                {clickorigin === 2 &&
                 <SketchPicker  className="picker-sketch"
                 color={background}
                 onChangeComplete={(e) =>this.handlePickerChange(e,clickorigin) }
             />
                }
            </Reactbootstrap.Modal.Body>
            </Reactbootstrap.Modal.Header>
        </Reactbootstrap.Modal>

        );
    }

} export default translate(GroundPlanActions)
