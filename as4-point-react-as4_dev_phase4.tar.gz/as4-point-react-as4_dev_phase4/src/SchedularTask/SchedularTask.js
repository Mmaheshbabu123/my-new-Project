
import React, { Component } from 'react'
import { datasave } from '../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import 'moment-timezone/builds/moment-timezone-with-data-2012-2022';
import moment from 'moment';
import SchedularComponent from '../_components/SchedularComponents/schedularComponent';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { connect } from "react-redux";
import { translate } from '../language';
import { store } from '../store';
import { filter } from '../Webforms/Actions/ActionFilter';
class SchedularTask extends Component {
  constructor(props) {
    super(props)
    this.handleSubmit = this.handleSubmit.bind(this)
    this.handleChange = this.handleChange.bind(this)
    this.handleSelect = this.handleSelect.bind(this)
    this.handleSelectRadio = this.handleSelectRadio.bind(this)
    this.handleCancel = this.handleCancel.bind(this)
    this.updateSelected = this.updateSelected.bind(this)
    this.filterArray = this.filterArray.bind(this);
    this.handleChangenum = this.handleChangenum.bind(this)
    this.handleChangestartDate = this.handleChangestartDate.bind(this);
    this.handleChangeendDate = this.handleChangeendDate.bind(this);
    this.onTimeChange = this.onTimeChange.bind(this);
    this.getCurrentTimeSeconds = this.getCurrentTimeSeconds.bind(this);
    this.handleEditdata = this.handleEditdata.bind(this);
    this.handleTaskDaysSelect = this.handleTaskDaysSelect.bind(this);
    this.handleChangeunRecurrentstartDate = this.handleChangeunRecurrentstartDate.bind(this);
    this.handleChangeunRecurrentendDate = this.handleChangeunRecurrentendDate.bind(this);
    this.handleChangedueDate = this.handleChangedueDate.bind(this)
    this.state = {
      get_insert_url: window.POST_TASK_PLANNER_DETAILS,
      title: '',
      descriprtion: '',
      type_id: '',
      types: [],
      sub_types: [],
      sub_type_id: '',
      documents: [],
      document_id: 0,
      active: 1,
      notification: 1,
      auto_increment_lessthan: 1,
      auto_increment_greaterthan: 1,
      tor_email: 1,
      tor_dashboard: 1,
      start_webform: 1,
      template_needed: 0,
      recurrent_task: 1,
      task_id: '',
      startDate: '',
      endDate: '',
      setStartDate: '',
      interval: '',
      task_periods: [],
      task_days: [],
      task_period_id: 1,
      timeSeconds: '12:34:01',
      run_task_option: 1,
      run_task_type_id: '1',
      ips_type_id:'1',
      duedate_period_days:'',
      duedate_period_type:'days',
      responsible_amount_all:0,
      verify_amount_all:0,
      responsible_amount:1,
      verify_amount:1,
      t: props.t,
      webforms: [],
      webform_id: 0,
      [window.tabs.verifier]: [],
      [window.tabs.responsible]: [],
      disableFields: false,
      action: this.props.action,
      errorTitle: '',
      errorSelectWebform: '',
      erroRecurrentTask: '',
      unRecurrentInterval: '',
      duration_type: 'days',
      holidays_count: 1,
      start_date_time: '12:34:01',
      recurrent_due_date: '',
      countDays: 1,
      taskplan_actor_type:350,
      copyTask_days1: [],
      errorSelectDocument: '',
      resultData: [],
      auto_increment_greaterthan_day: '',
      auto_increment_lessthan_day: '',
      selected_webform: '',
      selected_document : '',
      OrgUnits : [],
      OrgunitOptions:[],
      taskplan_actor_type_id:0,
      webform_actor_amount:1,
      webform_actor_amount_all:0,
      controlId:undefined,
      operator_id:undefined,
      selectvaluetype:1,
      valueId:undefined,
      value: undefined,
      periodtype:1,
      category:4,
      count:undefined,
      task_id:0,
      css:undefined,
      flag:1,
      element_flag:1,
      controlls_data:[],
      cssTree:[],
      credentials:this.props,
    }
    this.baseState = ({
      get_insert_url: window.POST_TASK_PLANNER_DETAILS,
      title: '',
      descriprtion: '',
      type_id: '',
      sub_type_id: '',
      document_id: 0,
      active: 1,
      notification: 1,
      auto_increment_lessthan: 1,
      auto_increment_greaterthan: 1,
      tor_email: 1,
      tor_dashboard: 1,
      start_webform: 1,
      template_needed: 0,
      recurrent_task: 1,
      responsible_amount_all:0,
      verify_amount_all:0,
      responsible_amount:1,
      verify_amount:1,
      task_id: '',
      startDate: '',
      endDate: '',
      setStartDate: '',
      interval: '',
      task_period_id: 1,
      timeSeconds: '12:34:01',
      run_task_option: 1,
      run_task_type_id: '1',
      ips_type_id:'1',
      t: props.t,
      webform_id: 0,
      disableFields: false,
      action: this.props.action,
      errorTitle: '',
      errorSelectWebform: '',
      erroRecurrentTask: '',
      unRecurrentInterval: '',
      duration_type: 'days',
      holidays_count: 1,
      start_date_time: '12:34:01',
      recurrent_due_date: '',
      duedate_period_days:'',
      duedate_period_type:'days',
      countDays: 1,
      [window.tabs.verifier]: [],
      [window.tabs.responsible]: [],
      errorSelectDocument: '',
      auto_increment_greaterthan_day: '',
      auto_increment_lessthan_day: '',
      selected_webform: '',
      selected_document : '',
      credentials:this.props,
      // OrgUnits : [],
      flag:1,
      element_flag:1,
      controlls_data:[],
      taskplan_actor_type:350,
      taskplan_actor_type_id:0,
      webform_actor_amount:1,
      webform_actor_amount_all:0,
      controlId:undefined,
      operator_id:undefined,
      selectvaluetype:1,
      valueId:undefined,
      value: undefined,
      periodtype:1,
      category:4,
      count:undefined,
      css:undefined,
      copyTask_days1:[],
      resultData:[],
    })
  }

async  componentDidMount() {
    let Userdata = store.getState();
    if (this.props.action === 'create') {
      this.props.UserData.task_days.map(value => {
          value.checked = 0;
         })
    }
    let task_periods = Userdata.UserData.task_periods;
    let task_days = Userdata.UserData.task_days;
      this.setState({
        task_periods: task_periods,
        task_days: task_days,
        copyTask_days1: task_days
      })
    if (this.props.action === 'create') {
        await this.fetchDocuments();
        await this.fetchwebForms();

        await this.fecthAllPJDG(1);
      this.setState(
        this.baseState
      )
    }
    if (this.props.id) {
      var url = this.state.get_insert_url + '/' + this.props.id;
      datasave.service(url, 'GET')
        .then(resultObj => {
          this.setState({
            resultData: resultObj,
          }, () => {
            this.handleEditdata(resultObj)
          });
        })
    }

    datasave.service(window.GET_TYPE, 'GET')
      .then(response => {
        this.setState({
          types: response.type,
          sub_types: response.sub_type,
        });
      });

  }
  getCurrentTimeSeconds() {
    var current_date = moment().format('HH:mm:ss');
    //var time = tempDate.getHours()+':'+ tempDate.getMinutes()+':'+ '00';
    return current_date;
  }
  fetchwebForms = () =>{
    let data = {manual_id: 0,type: 22};
    let url = window.GETSTARTWEBFORM_DATA;
    datasave.service(url, "GET", data)
    .then(result =>{
      if(this.props.action==="edit" || this.props.action==="clone") {
        let selected =  Object.values(result['data']).filter(({value})=>value===this.state.webform_id);
        this.setState({selected_webform:selected})
      }
      this.setState({webforms: this.sort(result['data'])});
    });
  }
  fetchDocuments = () =>{
    var url1 = window.GET_DOCUMENT_NOCW_DETAILS;
    datasave.service(url1, "GET")
      .then(result => {
        if(this.props.action==="edit" || this.props.action==="clone") {
          let selected =  Object.values(result['data']).filter(({value})=>value===this.state.document_id);
          this.setState({selected_document:selected})
        }
        this.setState({documents: this.sort(result.data)});
      });
  }



 fecthAllPJDG = (org_type)=> {
   const { t } = this.state;
      datasave.service(window.GET_TEXTFIELD_LIST_ORG + '/' + 123, 'GET')
          .then(response => {
              if (response['status'] == 200) {
                  this.setState({
                      OrgUnits: {
                          '1': response['person'],
                          '2': response['jobs'],
                          '3': response['departments'],
                          '4': response['groups']
                      },
                      OrgunitOptions:response[window.ORG_TYPE_IDS[org_type]],
                  })
              } else {
                  OCAlert.alertError(t(response['Msg']), { timeOut: window.TIMEOUTNOTIFICATION });
              }
          })

 }


 getOrganisationAndWebControlOptions(parent_type) {

     if (this.state.orgUnits.length != 0) {
         switch (parent_type) {
             case window.PERSON_ENTITY:
                 return this.state.orgUnits[window.PERSON_ENTITY];
                 break;
             case window.JOB_ENTITY:
                 return this.state.orgUnits[window.JOB_ENTITY];
                 break;
             case window.DEPARTMENT_ENTITY:
                 return this.state.orgUnits[window.DEPARTMENT_ENTITY];
                 break;
             case window.GROUP_ENTITY:
                 return this.state.orgUnits[window.GROUP_ENTITY];
                 break;
         }
     }
 }

  handleFilter = async(selctIds,dataObj) =>{
     let data = [];
     if(dataObj[selctIds]!== undefined){
     Array.prototype.push.apply(data, Object.values(dataObj[selctIds]))
   }
 return data;
   }
  sort=(data)=>{
    return Object.values(data).sort(function(a,b){return (a.label).toLowerCase() < (b.label).toLowerCase() ? -1 : 1;});
  }
  daysc() {
    let count = 1;
    let data = this.state.resultData.task_period_days === undefined || this.state.resultData.task_period_days === [] ? this.state.task_days : this.state.resultData.task_period_days;
    data.map(value => {
      if (value['checked'] === true || value['checked'] === 1) {
        count = 0;
        this.setState({
          countDays: count
        })
      }
    });
    return count;
  }
  handleSubmit(event) {
    event.preventDefault()
    this.setState({
      submitted: 'true'
    });
    if (this.dateValidation()) {
        this.formSave();
    }
  }
alertMessage = (message) =>{
  const {t}=this.state;
    OCAlert.alertWarning(t(message), { timeOut: window.TIMEOUTNOTIFICATION });
}
errorSettingState = (name,value) =>{
  this.setState({
    [name]:value
  })
}
dateValidation() {
  const { t , start_webform, webform_id, title, recurrent_task, startDate, endDate, interval,
    run_task_option, countDays, auto_increment_lessthan, auto_increment_lessthan_day,
    auto_increment_greaterthan_day, ips_type_id,auto_increment_greaterthan,selectedElements,selectedBuildings,selectedInspections,selectedFloors,selectedLayers,taskplan_actor_type,taskplan_actor_type_id} = this.state;
    var dayc = this.daysc();
    let check_start_date=new Date(startDate);
    let check_end_date=new Date(endDate);
    let present_date=new Date();
    let start_webfom_check = start_webform;
    let year=present_date.getFullYear();
    let month=present_date.getMonth();
    let date=present_date.getDate();
    let start_date_y =check_start_date.getFullYear();
    let start_date_m = check_start_date.getMonth();
    let start_date_d = check_start_date.getDate();
    let end_date_y =check_end_date.getFullYear();
    let end_date_m = check_end_date.getMonth();
    let end_date_d= check_end_date.getDate();
    if (title.length < 1) {
      this.alertMessage('Something is missing please check all the tabs');
      this.errorSettingState('errorTitle',t('Title is mandatory'));
      return false;
    }else if ((start_webform === 1 || start_webform ===true) && webform_id===0 ) {
       console.log('webform');
      this.alertMessage('Something is missing please check all the tabs');
      this.errorSettingState('errorSelectWebform',t('Select webform'));
      return false;
    }else if (startDate.length < 1 || endDate.length < 1 ||(recurrent_task && interval.length < 1)) {
      this.alertMessage('Something is missing please check all the tabs');
      this.errorSettingState('erroRecurrentTask',t('All the fields are mandatory'));
      return false;
    }else if ( this.props.action === 'create' && startDate < moment().format('YYYY-MM-DD')
              ||this.props.action === 'create' && check_end_date < check_start_date
              //year >check_end_date.getFullYear() ||month >check_end_date.getMonth() || date >check_end_date.getDate()
            ) {
            //  Number(start_date_y) ||Number(month) > Number(start_date_m) || Number(date) > Number(start_date_d)
              //           ||Number(year) > Number(end_date_y) ||Number(month) > Number(end_date_m) || Number(date) > Number(end_date_d)
      this.alertMessage('Something is missing please check all the tabs');
      this.errorSettingState('erroRecurrentTask',t('All the fields are mandatory'));
      return false;

    }else if(start_webform === 1 && (taskplan_actor_type <= 4) && taskplan_actor_type_id <= 1) {
     this.alertMessage('Something is missing, please check all the tabs');
    return false;
    }
    else if (run_task_option && (dayc > 0 || countDays.length<1)) {
      this.alertMessage('Select atleast one day');
      return false;
    }else if (auto_increment_lessthan === 1 && auto_increment_lessthan_day.length < 1) {
      this.alertMessage('Please fill minimum days  before deadline');
      return false;
    }else if (auto_increment_greaterthan === 1 && auto_increment_greaterthan_day.length < 1) {
      this.alertMessage('Please fill maximum days  after deadline');
      return false;

   }
    else {
      return true;
    }
  }

  formSave() {
    const { t } = this.state;
    const task_id = this.props.id;
    if (this.dateValidation()) {
      if (this.props.action==='edit') {
        datasave.service(this.state.get_insert_url + '/' + task_id, 'PUT', this.state)
          .then(result => {
              if(result['status']===200 && result['data']>0){
              this.props.tables(result['data']);
              OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
            this.props.cancel();
            }else{
              OCAlert.alertWarning(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
            }
          });
      }
      else {
        datasave.service(this.state.get_insert_url, 'POST', this.state)
        .then(result => {
            if(result['status']===200 && result['data']>0){
            this.props.tables(result['data']);
            OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
            this.props.cancel();
          }else{
            OCAlert.alertWarning(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
        });
      }
    }
  }
  handleTaskDaysSelect(data) {
    this.setState({
      task_days: data
    })
  }
  onTimeChange(event) {
    const { name, value } = event.target;
    const newTime = value.replace(/-/g, ':');
    const timeSeconds = newTime.padEnd(8, value.substr(5, 3));
    if (name === 'start_date_time') {
      this.setState({
        [name]: timeSeconds,
        timeSeconds: timeSeconds
      });
    } else {
      this.setState({ [name]: timeSeconds });
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.id != prevProps.id) {
      this.componentDidMount();
    }
  };
  handleCancel = (event) => {
    if (this.props.id) {
      this.props.closeForm();
      // var url = this.state.get_insert_url + '/' + this.props.id;
      // datasave.service(url, 'GET')
      //   .then(resultObj => {
      //     this.setState({
      //       resultData: resultObj,
      //     }, () => {
      //       this.handleEditdata(resultObj)
      //     });
      //   })
    }else{
      this.state.task_days.map(value => {
        if (value['checked'] !== 0) {
          value['checked'] = 0;
        }
      });

      this.setState(this.baseState)
    }

  }


  handleFilter = async(selctIds,dataObj) =>{
     let data = [];
     if(dataObj[selctIds]!== undefined){
     Array.prototype.push.apply(data, Object.values(dataObj[selctIds]))
   }
 return data;
   }
   handleGetTypeData = async (type) => {
     let data = [];
     if(type === 1) {
       data = this.state.buildingsOptions;
     }
     else if(type === 2){
       data = this.state.floorResponse;
     }
     else if(type === 3){
       data = this.state.inspectionResponse;
     }
     return data;
   }
  updateSelected = (latestDropped, result, type, id = '') => {
    var array = [...this.state[type]];
    if (result.type === 'remove') {
      var filterArray = array.filter(selected => (selected.name !== latestDropped.name));
    }
    if (result.type === 'remove') {
      this.setState({
        [type]: filterArray
      })
    }
    else {
      this.setState(prevState => ({
        [type]: [...prevState[type], latestDropped]
      }));
    }
  }
  handleChangestartDate = date => {
    var d = new Date(date + ' EDT');
    var endDate = (this.state.endDate !== undefined && this.state.endDate !== null) ? this.state.endDate : d;
    this.setState({
      startDate: d,
      endDate: endDate,
      erroReceurrentTask: '',
      recurrent_due_date: ''
    });
  };
  handleChangedueDate = date => {
    const { t } = this.state;
    if (this.state.startDate !== null && this.state.startDate !== '') {
      this.setState({
        recurrent_due_date: (date !== '1970-01-01') ? date : '',
      },() => console.log(moment(this.state.startDate).format('DD/MM/YYYY')),)
    } else {
      this.setState({
        recurrent_due_date: '',
      });
      OCAlert.alertWarning(t('Select start date first'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
  };
  handleChangeunRecurrentstartDate = date => {
    this.setState({
      unRecurrentStartDate: date,
      erroRecurrentTask: ''
    });
  };
  handleChangeunRecurrentendDate(date) {
    this.setState({
      unRecurrentEndDate: date,
      erroRecurrentTask: ''
    });
  };

  handleChangeendDate = date => {
    var d = new Date(date + ' EDT');
    var startDate =  this.state.startDate ;
    this.setState({
      endDate: d,
      startDate: startDate,
      erroRecurrentTask: '',
    });
  };
  handleChangenum(event) {
    const { name, value } = event.target;
    const re = /^[0-9\b]+$/
     var current_date = moment().format('YYYY-MM-DD');
    if (name == 'duedate_period_days' && value != ''&& re.test(value)) {
        var d = moment(current_date, 'YYYY-MM-DD').add(value, this.state.duedate_period_type);
        this.setState({
            recurrent_due_date: d.format('YYYY-MM-DD'),
            [name]: value,
        })
    }
    else if (name == 'duedate_period_days' && value === '') {
        this.setState({
            recurrent_due_date: '',
            [name]: value,
        })
    }
    if (name === 'unRecurrentInterval' && value != '') {
      if (!this.state.startDate) {
        this.setState({
          startDate: moment().toDate(),
        });
        this.setDate(moment().toDate(), name, value, this.state.duration_type)
      } else {
        this.setDate(this.state.startDate, name, value, this.state.duration_type)
      }
    }
    else if (name === 'unRecurrentInterval' && value === '') {
      this.setState({
        endDate: '',
        [name]: value,
      })
    }
    if (event.target.value === '' || re.test(event.target.value)) {
      this.setState({
        [name]: value,
        erroRecurrentTask: '',
      })
    }
    if (name === 'auto_increment_lessthan_day' || name === 'auto_increment_greaterthan_day') {
      if (event.target.value === '' || re.test(event.target.value)) {
        this.setState({
          [name]: value,
        })
      }
    }

  }
  setDate(status, name, value, field) {
    var d = moment(status, 'YYYY-MM-DD').add(value, field);
    var endDate = new Date(d.format('YYYY-MM-DD'));
    this.setState({
      [name]: value,
      endDate: endDate,
    })
  }
  filterArray = (allList, selectedList) => {
    var pack_func = allList;
    Object.values(selectedList).map(
      function (item, key) {
        pack_func = pack_func.filter(selected => (selected.id !== item.id));
      }, this);
    return pack_func;
  }
  handleSelect(event) {
    let Userdata = store.getState();
    let task_days = Userdata.UserData.task_days;
    console.log(this.state.copyTask_days1)
    const { name } = event.target;
    if (event.target.name == 'start_webform' && event.target.checked == 1) {
      this.setState({
        [name]: !this.state[name],
        [window.tabs.verifier]: [],
        [window.tabs.responsible]: [],
        template_needed: 0,
        selected_document:'',
        document_id: 0,
        selected_webform :'',
        webform_id : 0,
      })
    }else if (event.target.name == 'start_webform' && event.target.checked == 0) {
      this.setState({
        selected_webform :'',
        webform_id : 0,
        start_webform : event.target.checked
      })
    }else if (event.target.name == 'template_needed') {
      this.setState({template_needed:event.target.checked, selected_document:'',document_id: 0})
    }
    else {
      this.setState({
        [name]: !this.state[name],
      })
    }
    if (event.target.name == 'run_task_option' && event.target.checked === false) {
      this.setState({
        run_task_type_id: '1',
        countDays: 1,
        task_days: task_days
      });
      if (event.target.name == 'run_task_option' && event.target.checked === true) {
        this.setState({
          run_task_type_id: '',
          countDays: 1,
          task_days: task_days
        });
      }
    }
    if (event.target.name === 'recurrent_task') {
      this.setState({
        interval: '',
        period: '',
        task_period_id: '',
        timeSeconds: '',
        erroRecurrentTask: '',
        unRecurrentInterval: '',
        duration_type: 'days',
        startDate: '',
        endDate: '',
        start_date_time: ''
      })
    }
    if (name === 'auto_increment_greaterthan' && event.target.checked === false) {
      this.setState({ auto_increment_greaterthan_day: '' })
    }
    else if (name === 'auto_increment_lessthan' && event.target.checked === false) {
      this.setState({ auto_increment_lessthan_day: '' })
    }
  }
  handleSelectRadio(event) {
    const { name, value } = event.target;this.setState({
      [name]: value,
    })
  }
  handleChange(event) {
    const { name, value } = event.target;
    if(this.props.action === 'edit'){
      if(name === 'taskplan_actor_type') {
        let options = this.state.OrgUnits[event.target.value];
      this.setState({ [name]: value,OrgunitOptions:options});
      }
      else {
      var datetime = this.getCurrentTimeSeconds();
      this.setState({ [name]: value,
                        start_date_time:datetime,
                       timeSeconds:datetime,
       });
     }
    }
    else if(name === 'taskplan_actor_type') {
      let options = this.state.OrgUnits[event.target.value];
    this.setState({ [name]: value,OrgunitOptions:options});
    }
   else {
       this.setState({ [name]: value});
   }
    if (name === 'duration_type') {
      if (!this.state.startDate) {
        this.setState({
          startDate: moment().toDate()
        })
      } else {
        this.setDate(this.state.startDate, name, value, this.state.unRecurrentInterval);
      }
    }
    if (name === 'title') {
      this.setState({
        errorTitle: '',
      })
    }
  }

  handleChangeDocumentsOptions = (event) =>{
    this.setState({ selected_document: event,document_id:event.value})
  }
  handleChangeWebformsOptions = (event) => {
    this.setState({ selected_webform: event ,webform_id:event.value,errorSelectWebform:'',element_flag:1,})
  }

  handleEditdata(result) {
    let taskDays = result.task_period_days;
    let r = result.recurrent_task.start_time;
    this.fetchwebForms();
    this.fetchDocuments();
    this.fecthAllPJDG(result.task_planner.taskplan_actor_type);
    this.setState({
      [window.tabs.responsible]: (result.responsible_data.length > 0) ? result.responsible_data.filter(item => item.responsible_type === 1) : [],
      [window.tabs.verifier]: (result.responsible_data.length > 0) ? result.responsible_data.filter(item2 => item2.responsible_type === 2) : [],
      title: this.props.action==='clone'?'':result.task_planner.name,
      task_id: result.task_planner.id,
      descriprtion: result.task_planner.descriprtion,
      active: result.task_planner.active,
      notification: result.task_planner.notification,
      auto_increment_lessthan: result.task_planner.automic_reminder_lessthan,
      auto_increment_greaterthan: result.task_planner.automic_reminder_greaterthan,
      duedate_period_days:result.task_planner.duedate_period_days,
      tor_email: result.task_planner.email,
      tor_dashboard: result.task_planner.dashboard,
      recurrent_task: result.task_planner.recurrent_task,
      start_webform: result.task_planner.start_webform,
      template_needed: result.task_planner.template_needed,
      run_task_option: result.task_planner.run_task_option,
      duedate_period_type:result.task_planner.duedate_period_type,
      responsible_amount : result.task_planner.responsible_amount,
      responsible_amount_all : result.task_planner.responsible_amount_all,
      verify_amount_all : result.task_planner.verify_amount_all,
      taskplan_actor_type:result.task_planner.taskplan_actor_type,
      taskplan_actor_type_id:result.task_planner.taskplan_org_unit,
      webform_actor_amount:result.task_planner.amount,
      webform_actor_amount_all:result.task_planner.amount_all,
      verify_amount : result.task_planner.verify_amount,
      run_task_type_id: (result.task_planner.run_task_type_id === 1) ? '1' : '2',
      ips_type_id:(result.task_planner.ips_type_id === 1)?'1':'2',
      type_id: (result.task_planner.type === null) ? '':result.task_planner.type ,
      sub_type_id: result.task_planner.sub_type,
      startDate: result.recurrent_task.start_date,
      endDate: result.recurrent_task.end_date,
      interval: result.recurrent_task.interval,
      task_period_id: result.recurrent_task.period,
      timeSeconds: r,
      document_id: result.start_webform.entity_id,
      webform_id: result.start_webform.entity_id,
      task_days: taskDays,
      unRecurrentInterval: result.recurrent_task.unrecurrent_interval,
      duration_type: result.recurrent_task.unrecurrent_duration,
      holidays_count: (result.task_planner.holidays_count == 1)?result.task_planner.holidays_count:0,
      start_date_time: result.recurrent_task.start_time_task,
      recurrent_due_date: (result.task_planner.recurrent_due_date !== null) ? new Date(result.task_planner.recurrent_due_date) : (''),
      auto_increment_lessthan_day: result.task_planner.days_before_deadline,
      auto_increment_greaterthan_day: result.task_planner.days_after_deadline,
      action: "edit",
      flag:1,
      element_flag:1,
    });

  }
  closeTaskplanner=()=>{
    this.props.closeForm();
  }
  render() {
    return (
      <div >
        <SchedularComponent
          details={this.state}
          handleprops={this.props}
          task_id = {this.props.id}
          handleSubmit={this.handleSubmit.bind(this)}
          handleCancel={this.handleCancel.bind(this)}
          handleSelect={this.handleSelect.bind(this)}
          handleSelectRadio={this.handleSelectRadio.bind(this)}
          handleChange={this.handleChange.bind(this)}
          getCurrentTimeSeconds = {this.getCurrentTimeSeconds.bind(this)}
          updateSelected={this.updateSelected.bind(this)}
          filterArray={this.filterArray.bind(this)}
          handleChangestartDate={this.handleChangestartDate.bind(this)}
          handleChangeendDate={this.handleChangeendDate.bind(this)}
          handleChangenum={this.handleChangenum.bind(this)}
          onTimeChange={this.onTimeChange.bind(this)}
          handleTaskDaysSelect={this.handleTaskDaysSelect.bind(this)}
          object={this.state}
          handleChangedueDate={this.handleChangedueDate.bind(this)}
          handleChangeDocumentsOptions = {this.handleChangeDocumentsOptions}
          handleChangeWebformsOptions = {this.handleChangeWebformsOptions}
          handleGroundOptions = {this.handleGroundOptions}
           closeTaskplanner = {this.closeTaskplanner}
        />
      </div>
    );
  }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(SchedularTask));
