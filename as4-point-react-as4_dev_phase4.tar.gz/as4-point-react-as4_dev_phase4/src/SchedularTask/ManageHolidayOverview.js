import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { datasave } from '../_services/db_services';
import HolidaysComponent from '../_components/SchedularComponents/HolidaysComponent';
import Pagination from 'react-bootstrap/Pagination';
class ManageHolidayOverView extends Component {
  constructor(props) {
    super(props)
    this.state = ({
      t: props.t,
      addPlanner: false,
      editPlanner: false,
      holiday_overview:true,
      tableData: [],
      plannerId: '',
      currentPage: 1,
      todosPerPage: 5,
      fcurrentPage: 1,
      mcurrentPage: 1,
      page: 5,
      active: 1,
      count: 0,
      holidays: [],
      holidaysId: '',
      createdHoliday: '',
      searchTerm: '',
      pageIndex: [6, 11, 16, 22, 28, 34, 40, 46, 52, 58, 64, 70, 76],
      filterFullList: [],
      showDeletePopUP: false,
      currentId: 0,
    })
    this.addHolidays = this.addHolidays.bind(this);
    this.searchData = this.searchData.bind(this);
    this.holidayOverview =this.holidayOverview.bind(this);

  }
  async componentDidMount() {
    await this.tableData();
  }
  async tableData(data, saveRedit) {
    await datasave.service(window.HOLIDAYOVERVIEW_DATA, "GET")
      .then(async response => {
        let data = response['data'];
        let p1 = saveRedit === 'save' ? 1 : this.state.active;
        let pageData = this.getPageData(p1, data);
        let count = this.getCountPage(data);
        if (pageData.length === 0 && this.state.active === 1) {
          this.setState({ tableData: pageData, });
        }
        if (pageData.length < 1) {  //this is related to delete button shift to minus one of Pagination
          pageData = this.getPageData(this.state.active - 1, data);
          this.setState({
            active: this.state.active - 1
          })
        }
        if (pageData.length > 0) {
          this.setState({
            count: count,
            tableData: pageData,
            holidays: data,
            filterFullList: data,
            holidaysId: data[0].id,
            active: saveRedit === 'save' ? 1 : this.state.active,
          })
        }
      })
  }
  handleCancel() {
    this.setState({
      plannerId: '',
      addPlanner: false,
      editPlanner: false
    });
    this.componentDidMount();
  }
  searchData(e) {
    var list = [...this.state.holidays];
    let res = '';
    list = list.filter(function (item) {
      if (item.name !== null) {
        res = item.name.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
      if (res) {
        return res;
      }
      else {
        if (item.discription !== null) {
          return item.discription.toLowerCase().search(
            e.target.value.toLowerCase()) !== -1;
        }
      }

    });
    const page_data = this.getPageData(1, list);
    const count = this.getCountPage(list);
    this.setState({
      tableData: page_data,
      count: count,
      active: 1,
      searchTerm: e.target.value,
      filterFullList: list,
    });
  }

  getPageData(id, list = '') {
    const page = this.state.page;
    const items = (list != undefined) ? list : this.state.holidays;
    const page_data = items.slice(page * (id - 1), page * id);
    return page_data;
  }
  getCountPage(items) {
    const itemLength = items.length;
    return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }
  editPlanner(id) {
    this.setState({
      plannerId: id,
      editPlanner: true,
      addPlanner: false
    });
  }
  async  deletePlanner() {
    let url = window.DELETE_HOLIDAY + '/' + this.state.currentId;
    datasave.service(url, 'POST')
      .then(async response => {
        await this.tableData();
      })
    this.handleHideDeletePopUp();
  }
  holidayOverview(){
    this.setState({
      holiday_overview:true,
      addPlanner: false,
    })
  }
  addHolidays() {
    this.setState({
      holiday_overview:false,
      plannerId: '',
      addPlanner: true,
      editPlanner: false,

    })
  }
  holidaysTabel() {
    const { t } = this.state;
    return (<div style={{ height: 'auto', width: '100%', overflow: 'auto' }}>
      <reactbootstrap.Table className="site-table-main" style={{ border: '1px solid lightgray', borderRadius: '5px' }}>
        <tr>
          <th>{t('Name')}</th>
          <th>{t('Date')}</th>
          <th>{t('Description')}</th>
          <th></th>
        </tr>
        <tbody>
          {this.holidaysData()}
        </tbody>
      </reactbootstrap.Table>
    </div>
    )
  }
  openPopUp(id) {
    this.setState({
      currentId: id,
      showDeletePopUP: true
    })
  }
  holidaysData() {
    let table = [];
    const { tableData } = this.state;
    if (tableData.length > 0) {
      table.push(
        tableData.map(value =>
          <tr style={{ borderTop: '1px solid lightgray' }} className="higlet_class">
            <td style={{ borderTop: '0px' }}>{value.name}</td>
            <td style={{ borderTop: '0px' }}>{value.date}</td>
            <td style={{ borderTop: '0px' }}>{value.discription}</td>
            <td style={{ borderTop: '0px' }}><i title="Edit" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc" onClick={this.editPlanner.bind(this, value.id)} /></td>
            <td id={value.id}><i title="Delete" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={this.openPopUp.bind(this, value.id)} /></td>
          </tr>))
    }
    return table;
  }
  changePage(e, id = 1) {
    const page_data = this.getPageData(id, this.state.filterFullList);
    this.setState({
      tableData: page_data,
      active: id,
      createdHoliday: '',
    });
  }
  handleHideDeletePopUp = () => {
    this.setState({
      showDeletePopUP: false
    })
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevState.currentId !== this.state.currentId) {
      this.setState({
        currentId: this.state.currentId,
      })
    }
  }
  render() {
    const { t } = this.state;
    let active = this.state.active;
    let pages = [];
    if (this.state.count > 0) {
      for (let number = 1; number <= this.state.count; number++) {
        pages.push(
          <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
            {number}
          </Pagination.Item>,
        );
      }
    }
    const deletePopUP = (
      <reactbootstrap.Modal
        show={this.state.showDeletePopUP}
        onHide={this.handleHideDeletePopUp}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
          {t('Are you sure you want to delete this holiday ?')}
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={this.handleHideDeletePopUp}>{t('Cancel')}</reactbootstrap.Button>
          <reactbootstrap.Button onClick={this.deletePlanner.bind(this)}>{t('Confirm')}</reactbootstrap.Button>
        </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
    );
    return (
      <reactbootstrap.Container className="col-md-12" style={{width:'95%', margin: 'auto'}}>
        <reactbootstrap.Row >
          <reactbootstrap.Button className='mr-2 mb-2 mt-2' onClick={this.holidayOverview} >{t('Holiday overview')}</reactbootstrap.Button>
          <reactbootstrap.Button className='mr-2 mb-2 mt-2' onClick={this.addHolidays}>{t('Add holidays')}</reactbootstrap.Button>
        </reactbootstrap.Row>
        <reactbootstrap.Row className='mb-5 button-design'>
          {this.state.holiday_overview === true && <reactbootstrap.Col className="pl-0 pr-0">
            <input type="text" value={this.state.searchTerm} className="search-input form-control" style={{ 'border-radius': "5px", 'border-color': "#EC661C" }} placeholder={t("Search by Name or Description")} autoFocus onChange={this.searchData} />
            {this.holidaysTabel()}{deletePopUP}
            <Pagination style={{ width: '530px', overflow: 'auto' }} size="md">{pages}</Pagination>
          </reactbootstrap.Col>}
          <reactbootstrap.Col className='col-md-12'>
            {this.state.addPlanner === true && <HolidaysComponent table={this.tableData.bind(this)} cancel={this.handleCancel.bind(this)}></HolidaysComponent>}
            {this.state.editPlanner === true && <HolidaysComponent table={this.tableData.bind(this)} cancel={this.handleCancel.bind(this)} id={this.state.plannerId}></HolidaysComponent>}
          </reactbootstrap.Col>
        </reactbootstrap.Row>
      </reactbootstrap.Container>
    );
  }
}
export default translate(ManageHolidayOverView);
