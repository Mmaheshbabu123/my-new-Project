import React, { useState, useEffect, } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../language';
import axios from 'axios';
import {store } from '../store';
import { datasave } from '../_services/db_services';
const path = require('path')
const ImprtPlanning=(props)=>{
  const t = props.t;
  const [importData,setImportData] = useState({
    file:'',
    file_details: '',
    show:false,
    popUpData:[],
    filePath:'',
    fileId:0
  });
  const {file,file_details,show,popUpData,filePath}=importData;
  useEffect(() => {
    const baseState =async ()=>{
      setImportData({
        ...importData,
        file:props.filename?props.filename:'',
        file_details: '',
        show:false,
        popUpData:'',
        filePath:props.filePath?props.filePath:'',
        fileId:props.fileId?props.fileId:0,
      })
    }
    baseState();
  },[])
    const handleChange = async(result,e)=>{
    const formData = new FormData();
    formData.append('file', e)
    const url = window.UPLOAD_FILE + '/' + window.GROUND_PLAN_FILES;
    let fileData = e;
    document.getElementById("loding-icon").setAttribute("style", "display:block;");
    await axios.post(window.backendURL + url, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
        .then(async response => {
            document.getElementById("loding-icon").setAttribute("style", "display:none;");
            let res = response.data;
      if(res.status ===1){
         setImportData({
          ...importData,
          file:res.originalfname,
          filePath:res.filepath,
          fileId:res['file_id'][0],
          file_details: fileData
        })
        let sendingData={
          file:res.originalfname,
          filePath:res.filepath,
          fileId:res['file_id'][0],
          file_details: fileData
        };
        props.saveImportPlanning(result,sendingData);
      }
    })
    .catch(error => {
      document.getElementById("loding-icon").setAttribute("style", "display:none;");
      OCAlert.alertError('Error occured while importing planning', { timeOut: window.TIMEOUTNOTIFICATION });
    })
    // setImportData({
    //   ...importData,
    //   file:e.target.files[0]['name'],
    //   file_details: e.target.files[0]
    // })
  }
  const uploadFile =async (e)=>{
    if(e.target.files[0].size > 1000000){
      OCAlert.alertError(t('Upload file size is bigger than 1mb!'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
    else{
    if(e.target.files[0]!=='' && e.target.files[0].name.split('.').pop() === 'csv'){
      const formData = new FormData();
      let Userdata = store.getState();
      var details = {
        file: e.target.files[0],
        loginPerson_Id :Userdata.UserData.user_details.person_id,
        action : props.action,
        tablename : props.tableName,
        task_id :props.task_id,
        task_name:props.task_name,
      }
      for (var key in details) {
        formData.append(key, details[key]);
      }
      // formData.append('file', file_details);
      var filedata = e.target.files[0];
      document.getElementById("loding-icon").setAttribute("style", "display:block;");
      await axios.post(window.backendURL + window.IMPORT_TASK_PLANNING_FILE, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
      .then(async response => {
        let data = response.data;
        document.getElementById("loding-icon").setAttribute("style", "display:none;");
        if(data.status===200 && data.result.status === 200){
          responseStatus(data,filedata);
        }else{
          console.log(data.result.exception.message)
          OCAlert.alertError(data.result.exception.message.slice(0,60), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      });
    }
    else {
        OCAlert.alertError(t('Something went wrong please try with correct  file'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
  }
  }
  const responseStatus=(result,e)=>
  {
    let data = result.validation;
   if(data.columns === 0) {
     OCAlert.alertWarning(t('Rows and columns are not equal'), { timeOut: window.TIMEOUTNOTIFICATION });
   }
   else if(data.count === 0) {
     OCAlert.alertWarning(t('There is no data to import'), { timeOut: window.TIMEOUTNOTIFICATION });
   }
   else if(data.emptyRows === 0){
      OCAlert.alertWarning(t('Empty row without column are there '), { timeOut: window.TIMEOUTNOTIFICATION });
   }
   else if(data.fields === 0){
     OCAlert.alertWarning(t('Id,startdate,actors and status fields are mandatory '), { timeOut: window.TIMEOUTNOTIFICATION });
  }

   else {
     handleChange(result,e);
   }
  }
  const downloadFile =()=>{
    let userAgentString = navigator.userAgent;
    let chromeAgent = userAgentString.indexOf("Chrome") > -1;// Detect Chrome
    // let IExplorerAgent =  userAgentString.indexOf("MSIE") > -1 || userAgentString.indexOf("rv:") > -1;// Detect Internet Explorer
    // let firefoxAgent =  userAgentString.indexOf("Firefox") > -1;// Detect Firefox
    // let safariAgent =   userAgentString.indexOf("Safari") > -1;
    // let operaAgent =  userAgentString.indexOf("OP") > -1;
    if(chromeAgent){
      window.open(filePath, '_blank');
    }else {
      var a = document.createElement('a');
      a.title = t("Download");
      a.href = filePath;
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
  }

  const exampleDownLoad = ()=>{
    let userAgentString = navigator.userAgent;
    let chromeAgent = userAgentString.indexOf("Chrome") > -1;// Detect Chrome
    if(chromeAgent){
      window.open('https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/61376008d4d636.797616711631019016.csv', '_blank');
    }else {
      var a = document.createElement('a');
      a.title = t("Download");
      a.href = 'https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/61376008d4d636.797616711631019016.csv';
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
  }

  // const clearForm =()=>{
  //   setImportData({
  //     ...importData,
  //     show:false,
  //     popUpData:[],
  //     file:'',
  //     file_details: '',
  //   });
  //   props.openCloseUploadPopup();
  // }
    return(
      <>
      <reactbootstrap.Row>
      <reactbootstrap.Col className='col-md-2 pt-4'>
      <reactbootstrap.FormLabel style={{color: '#EC661C'}}>{t('Upload planning:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-10'>
      <reactbootstrap.InputGroup className="custom-file input_sw">
      <reactbootstrap.FormControl
      type="file"
      className="custom-file-input"
      id="inputGroupFile01"
      name='image'
      accept={".csv"}
      onChange={(e) => uploadFile(e)}
      />
      <reactbootstrap.FormLabel className="custom-file-label" htmlFor="inputGroupFile01">
      {file !== null && file}
      </reactbootstrap.FormLabel>
      </reactbootstrap.InputGroup>
      <p style={{padding:'0px',margin:'0px'}}>{t('Upload only csv format files.')}</p>
      {filePath.length<1 &&<p onClick={(e)=>exampleDownLoad()} style={{color: '#EC661C',padding:'0px',margin:'0px'}}>{t('Download example csv file')}</p>}
      {filePath.length>0 && <p onClick={(e)=>downloadFile()} style={{color: '#EC661C',padding:'0px',margin:'0px'}}>{t('Download')}</p>}
      </reactbootstrap.Col>
      </reactbootstrap.Row>
      </>
      // <reactbootstrap.Row className='pl-4 float-right'>
      // <a id="cancel" className='mt-2 mr-3' active='true' onClick={(e) => clearForm()}>{t('Cancel')}</a>
      // <reactbootstrap.Button  onClick={(e) => uploadFile(e)}>{t('Save')}</reactbootstrap.Button>{popUp()}
      // </reactbootstrap.Row>
    )

  }
  export default translate(ImprtPlanning);
