import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { datasave } from '../_services/db_services';
import SchedularTask from './SchedularTask';
// import Pagination from 'react-bootstrap/Pagination';
import { connect } from "react-redux";
import { store } from '../store';
import './task.css';
import Can from '../_components/CanComponent/Can';
import {SearchFilter }from '../SearchFilter';
import moment from 'moment';
import Paginator from '../Paginator';
import PlanningIndex from '../TaskPlanner/PlanningIndex';
import '../TaskPlanner/Css/Taskplanner.css';
import CheckBox from '../CheckBox';
import { OCAlert } from '@opuscapita/react-alerts';
import ImportPlanning from './ImprtPlanning';
const css = {
  width: '295px', overflow: 'auto', marginBottom: '0px',
}
class ManageOverView extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t: props.t,
      searchTask: [],
      tasks: [],
      task_id: '',
      webform_id: '',
      editSchedular: false,
      viewSchedular:false,
      addSchedular: false,
      active: 1,
      count: 0,
      page: 5,
      searchTerm: '',
      items: [],
      tagId: '',
      currentPage: 1,
      tasksPerPage: 5,
      fcurrentPage: 1,
      mcurrentPage: 1,
      next_start_date:'',
      name: '',
      type: '',
      last_start_date: '',
      showDeletePopUP: false,
      currentId: 0,
      copyTasks:[],
      cloneSchedular:false,
      uploadPopUp:false,
      currentTableName:'',
      selectedActor:1,
    }
    this.handleNewTask = this.handleNewTask.bind(this);
    this.dataInsert = this.dataInsert.bind(this);
    this.runTask = this.runTask.bind(this);
  }
  componentDidMount() {
    this.dataInsert();
  }
  async dataInsert(id=0) {
    console.log('1');
    await datasave.service(window.TASKPLANNER_DATA, 'GET')
      .then(async response => {
          var constructedData=  await this.reconstructData(response['data']);
          let checkDataExistForVerifiyPageNumber = constructedData.filter(value=>{return parseInt(value.id)===parseInt(id)});
          var pageData = [];
        if(id>0 && checkDataExistForVerifiyPageNumber.length>0){
          let result =await SearchFilter.verifyPageNumber(1,parseInt(id),constructedData,this.state.page);
          pageData = result[0];
          this.setState({active:result[1]});
        }else {
          pageData = await SearchFilter.getPageData(1,this.state.page,constructedData,constructedData);
          this.setState({  active:1});
        }
        this.setState({
            tasks: constructedData,
            searchTask: constructedData,
            items:pageData,
            count:await SearchFilter.getCountPage(constructedData,this.state.page),
            cloneSchedular:false,
            editSchedular: false,
            viewSchedular:false,
            addSchedular: false,
            tagId:id
        })
      });
  }
  reconstructData=(data)=>{
    if(data.length>0){
      return data.map(value=>{
        return {
          'id': value.id? value.id:0,
          'name':value.name?value.name.toString():' ',
          'last_start_date':value.last_start_date?value.last_start_date.toString():' ',
          'next_start_date':value.next_start_date?value.next_start_date.toString():' ',
          'run_task_start': value.run_task_start?value.run_task_start:0,
          'webform_id':value.webform_id?value.webform_id:0,
          'type':value.type?value.type:' ',
          'type_of_recurrect_task':value.type_of_recurrect_task?parseInt(value.type_of_recurrect_task):1,
          'active':value.active?true:false,
          'sro':value.scheduled_read_out?true:false,
          'fileId':value.file_id?value.file_id:0,
          'file_name':value.file_name?value.file_name:'',
          'file_path':value.file_path?value.file_path:'',
          'tablename':value.table_name?value.table_name:'',
          'selectedActor':value.taskplan_actor_type?value.taskplan_actor_type:1,
        }
      })
    }else {
      return [];
    }
  }

  handleSelect=async (value,id)=>{
    const {  items,t } = this.state;
    await datasave.service(window.ACTIVE_INACTIVE_PLANNER_BY_ID+'/'+id+'/'+value,'POST')
          .then(
            response=>{
              if(response['status']!==200){
                OCAlert.alertError(t('Something went wrong please try again later'),{ timeOut: window.TIMEOUTNOTIFICATION });
              }else{
                this.dataInsert(id);
              }
            }
          )
  }

  openCloseUploadPopup=(id,table='')=>{
    const {uploadPopUp} =this.state;
    this.setState({
      uploadPopUp:!uploadPopUp,
      task_id: id,
      cloneSchedular:false,
      editSchedular: false,
      viewSchedular:false,
      addSchedular: false,
      currentTableName:table
    })
  }
  upDateImortPlanning=async(tabelData,fileData)=>{
    const {t,tasks,uploadPopUp} =this.state;
    let filterdData = tasks.filter(value=>{return parseInt(value.id)===parseInt(this.state.task_id)});
    let data ={
      filename:fileData.file,
      filePath:fileData.filePath,
      fileId:fileData.fileId,
      tableName:tabelData.table_name,
      selectedWebForm:filterdData[0]['webform_id'],
      csv_file_name:tabelData.csv_file_name,
      selectedActor:filterdData[0]['selectedActor'],

    }
    await   datasave.service(window.UPDATE_PLANNER_IMPORT_PLANNING_BY_ID+'/'+this.state.task_id,'PUT',data)
    .then(async response=>{
      if(response['status']===200){
        OCAlert.alertSuccess(t('Import planning success'), { timeOut: window.TIMEOUTNOTIFICATION });
        this.setState({
          uploadPopUp:!uploadPopUp,
          cloneSchedular:false,
          editSchedular: false,
          viewSchedular:false,
          addSchedular: false,
        },()=> this.dataInsert(parseInt(this.state.task_id)))
      }
      else{
        OCAlert.alertError(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    }
  )
}
  uploadPopUp=()=>{
    const {uploadPopUp,tasks}=this.state
    if(parseInt(this.state.task_id)>0){
        let filterdData = tasks.filter(value=>{return parseInt(value.id)===parseInt(this.state.task_id)});
        console.log(filterdData[0]['file_name']);
    return(
     <reactbootstrap.Modal
      show={uploadPopUp}
      onHide={this.openCloseUploadPopup}
      dialogClassName="modal-90w modal-md"
      aria-labelledby="example-custom-modal-styling-title"
      >
      <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
      </reactbootstrap.Modal.Header>
      <reactbootstrap.Modal.Body>
      <ImportPlanning
      filename={filterdData[0]['file_name']}
      filePath={filterdData[0]['file_path']}
      fileId={filterdData[0]['fileId']}
      saveImportPlanning={this.upDateImortPlanning}
      openCloseUploadPopup={this.openCloseUploadPopup}
      action={1}
      tableName={this.state.currentTableName}
      task_id={this.state.task_id}

      />
      </reactbootstrap.Modal.Body>
      </reactbootstrap.Modal>
    )}
  }
  taskplannerData() {
    let table = [];
    const {  items,tagId,t } = this.state;
    console.log('taskPlannerData', items, tagId, t);
    table.push(
      items.map(value =>
        <tbody>
          {/** <tr style={{backgroundColor:(tagId===value.id)?'#feb389':'#fafafa', }}>*/}
          <tr style={{backgroundColor:(tagId===value.id)?'#feb389':'#fafafa', }}>
            <td>
            <span title={(value.active===true || value.active === 1)?t('Inactive'):t('Active')}>
            <CheckBox
                tick={(value.active===true || value.active === 1)?true:false}
                onCheck={(e) => this.handleSelect(e.target.checked?1:0,value.id)}/>
            </span>
            </td>
            <td className='cell1'>{value.name} </td>
            <td className='cell1'>{value.type} </td>
            <td className='cell1'>{value.last_start_date}</td>
            <td className='cell1'>{value.next_start_date}</td>
            <td>
            <div style={{ display: 'flex', textAlign: 'center', justifyContent: 'center' }}>
              <Can
                perform="C_taskplanner"
                yes={() => (
                  <span style={{ padding: '0 3px' }}><i title={t("Edit")} style={{}} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc"
                    onClick={this.editSchedular.bind(this, value.id)} ></i></span>
                )}
              />
              <Can
                perform="V_taskplanner"
                yes={() => (
                  <span style={{ padding: '0 2px' }}><i title={t("View")} style={{}} style={{ 'cursor': 'pointer' }} class="webform-sprite webform-sprite-smallviewc"
                    onClick={this.viewSchedular.bind(this, value.id)} ></i></span>
                )}
              />
              <Can
                perform="Clone_taskplanner"
                yes={() => (
                  <span style={{ padding: '0 3px' }}><i title={t("Clone")} style={{ 'cursor': 'pointer' }} class="dashboard-tiles  dashboard-tiles-clone" onClick={this.cloneSchedular.bind(this, value.id)}/></span>
                )}
              />
              <Can
                perform="D_taskplanner"
                yes={() => (
                  <span style={{padding: '0 3px' }}><i title={t("Delete")} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={this.openPopUp.bind(this, value.id)} /></span>
                )}
              />
              {(value.active ===true || value.active ===1 )&& <Can
                perform="RUN_taskplanner"
                yes={() => (
                  <>
                  {[1,2].includes(value.type_of_recurrect_task) &&<span style={{padding: '0 3px' }}><i title={t('Run planning')} style={{ 'cursor': 'pointer' }} class="play_button" disabled={value.run_task_start === 0?true:false} onClick={(e) => this.runTask(value.id, value.webform_id)} /></span>}
                  {[4].includes(value.type_of_recurrect_task) &&<span style={{padding: '0 3px' }}><i title={t('Read out planning')} style={{ 'cursor': 'pointer' }} class="play_button"/></span>}
                  {[3].includes(value.type_of_recurrect_task) &&<span style={{padding: '3px 3px' }}><i class="status-sprite status-sprite-editorc" style={{ 'cursor': 'pointer' }} title={t('Import planning')} onClick={(e)=>this.openCloseUploadPopup(value.id,value.tablename)}/></span>}
                  </>
                  // <img src="https://as4-point.s3-eu-west-1.amazonaws.com/as4-point/profile/play-button.png" style={{ 'cursor': 'pointer' }} title={t('Run task')}disabled={value.run_task_start === 0} onClick={(e) => this.runTask(value.id, value.webform_id)}/>
                )}/>}
                </div>
            </td>
          </tr>
        </tbody>
      )
    )
    return table;
  }
  openPopUp(id) {
    this.setState({
      currentId: id,
      showDeletePopUP: true,
      tagId:id,
    })
  }

  async searchFilter(e) {
    const {name,value}=e.target;
    const {tasks,page}=this.state;
    if (e.key !== "Delete" || e.key !== "Backspace") {
      var filledStates = await this.getStates('', '', '','', name, value);
      var result = await SearchFilter.getData(filledStates, tasks);
      console.log(result);
      this.setState({
        [name]:value
      })
      console.log('length', result.length);
        if(result.length > 0) {
          let pageData = await SearchFilter.getPageData(1,page,result,tasks);
          console.log(pageData);
          this.setState({
            items:pageData,
            active:1,
            count:await SearchFilter.getCountPage(result,page),
            searchTask:result
          })
        } else {
          this.setState({
            items:[],
            active:1,
            count:0,
            searchTask:''
          })
        }
        console.log(this.state);
      }
    }
    getStates = (col1, col2, col3, col4, names, cols) => {
      const { name,type,last_start_date,next_start_date} =this.state;
      if (names !== '') {
        col1 = names === 'name'?col1+cols:name;
        col2 = names === 'type'?col2+cols:type;
        col3 = names === 'last_start_date'?col3+cols:last_start_date;
        col4 = names === 'next_start_date'?col4+cols:next_start_date;
      }
      var arr = []
      if (col1 != '') {
        arr.push({ name: 'name', value: col1 });
      }
      if (col2 != '') {
        arr.push({ name: 'type', value: col2 });
      }
      if (col3 != '') {
        arr.push({ name: 'last_start_date', value: col3 });
      }
      if (col4 != '') {
        arr.push({ name: 'next_start_date', value: col4 });
      }
      return arr;
    }
    async onKeyUp(e){
        const { name,type,last_start_date,next_start_date,tasks,page} =this.state;
      var result = [];
      if (e.key === "Delete" || e.key === "Backspace") {
        var filledStates = await this.getStates(name, type, last_start_date,next_start_date, '', '');
        result = await SearchFilter.getData(filledStates, tasks);
        if(result.length > 0) {
          let pageData = await SearchFilter.getPageData(1,page,result,tasks);
          console.log(pageData);
          this.setState({
            items:pageData,
            active:1,
            count:await SearchFilter.getCountPage(result,page),
            searchTask:result
          })
        } else {
          this.setState({
            items:[],
            active:1,
            count:0,
            searchTask:''
          })
        }
        // let pageData = await SearchFilter.getPageData(1,page,result,tasks);
        // this.setState({
        //   items:pageData,
        //   active:1,
        //   searchTask:result,
        //   count:await SearchFilter.getCountPage(result,page),
        // })
      }
      }

  tableView() {
    const { t ,count,active} = this.state;
    return (
      <div style={{ height: '500px', width: '100%', overflow: 'auto' }}>
        <reactbootstrap.Table style={{ border: '1px solid lightgray', borderRadius: '5px' }} >
          <thead  style={{ backgroundColor: '#EC661C', position: 'sticky', top: '0', textAlign: 'center' }}>
            <tr style={{textAlign:'center'}}>
              <th>{t('Active')}</th>
              <th>{t('Name')}</th>
              <th>{t('Type')}</th>
              <th>{t('Last started at')}</th>
              <th>{t('Next start')}</th>
              <th>{t('Actions')}</th>
            </tr>
            <tr>
              <td></td>
              <td><input type="text" className="form-control search-box-border " name='name' value={this.state.name} placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} onChange={(e)=>this.searchFilter(e)} onKeyUp={(e)=>this.onKeyUp(e)}/></td>
              <td><input type="text" className="form-control search-box-border " name='type' value={this.state.type} placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} onChange={(e)=>this.searchFilter(e)} onKeyUp={(e)=>this.onKeyUp(e)}/></td>
              <td><input type="text" className="form-control search-box-border " name='last_start_date' value={this.state.last_start_date} placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} onChange={(e)=>this.searchFilter(e)} onKeyUp={(e)=>this.onKeyUp(e)}/></td>
              <td><input type="text" className="form-control search-box-border " name='next_start_date' value={this.state.next_start_date} placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} onChange={(e)=>this.searchFilter(e)} onKeyUp={(e)=>this.onKeyUp(e)} /></td>
              <td></td>
            </tr>
          </thead>
          {this.taskplannerData()}
        </reactbootstrap.Table>
        <Paginator count={count} active={active} changePage={this.changePage.bind(this)} css={css} size="md"/>
      </div>
    )
  }
  changePage(id) {
    const { name,type,last_start_date,next_start_date,tasks,page,searchTask} =this.state;
    this.setState({
      items: SearchFilter.getPageData(id,page,(name !== ''||type!==''||last_start_date!==''||next_start_date!=='')? searchTask : '',tasks) ,
      active: id,
    });
  }
  editSchedular(id, webform_id) {
    this.setState({
      task_id: id,
      editSchedular: true,
      addSchedular: false,
      viewSchedular:false,
      webform_id: webform_id,
      cloneSchedular:false,
      uploadPopUp:false,
      tagId:id,
    });
  }
  viewSchedular(id, webform_id) {
    this.setState({
      task_id: id,
      viewSchedular:true,
      editSchedular: false,
      addSchedular: false,
      webform_id: webform_id,
      cloneSchedular:false,
      uploadPopUp:false,
      tagId:id,
    });
  }
  cloneSchedular(id, webform_id) {
    this.setState({
      task_id: id,
      cloneSchedular:true,
      editSchedular: false,
      viewSchedular:false,
      addSchedular: false,
      webform_id: webform_id,
      uploadPopUp:false,
      tagId:id,
    });
  }
  deleteSchedular(id, webform_id) {
    var runTask = window.POST_TASK_PLANNER_DELETE + '/' + this.state.currentId;
    datasave.service(runTask, "PUT", '')
      .then(result => {
        var res = result['data'];
        let pageData =  SearchFilter.getPageData(this.state.active,this.state.page,result['data'],result['data']) ;
        let count = SearchFilter.getCountPage(result['data'],this.state.page);
        if (pageData.length === 0 && this.state.active === 1) {
          this.setState({ items: pageData });
        }
        if (pageData.length < 1 && this.state.active !== 1) {
          pageData = SearchFilter.getPageData(this.state.active-1,this.state.page,result['data'],result['data']) ;
          this.setState({
            active: this.state.active - 1
          })
        }
        if (res.length > 0) {
          this.setState({
            tasks: res,
            searchTask: res,
            tagId: result['data'][0].id,
            count: count,
            items: pageData,
          });
        }
      });
      if(parseInt(this.state.currentId) === parseInt(this.state.task_id)){
        this.setState({
          addSchedular: false,
          editSchedular: false,
          viewSchedular:false,
          cloneSchedular:false,
          uploadPopUp:false,
          task_id: 0,
        })
      }
    this.handleHideDeletePopUp();
  }
  handleNewTask() {
    this.setState({
      addSchedular: true,
      editSchedular: false,
      viewSchedular:false,
      cloneSchedular:false,
      uploadPopUp:false,
      task_id: 0,
      tagId:0
    });
  }
  handleCancel() {
    this.setState({
      addSchedular: false,
      editSchedular: false,
      viewSchedular:false,
      cloneSchedular:false,
      uploadPopUp:false,
      task_id: 0,
    });
  }
  getCurrentTimeSeconds() {
     var current_date = moment().format('HH:mm:ss');
     //var time = tempDate.getHours()+':'+ tempDate.getMinutes()+':'+ '00';
     var time = current_date;
     return time;
   }
  runTask(task_id, webform_id) {
    let Userdata = store.getState();
    let person_id = Userdata.UserData.user_details.person_id;
   var start_time = this.getCurrentTimeSeconds();
    const data = {
      task_id: task_id,
      webform_id: webform_id,
      user_id: person_id,
      start_date:moment().format('YYYY-MM-DD'),
      start_time:start_time,
    }
    var runTask = window.RUN_TASK_DATA;
    datasave.service(runTask, "POST", data)
      .then(result => {
        var res = result['data'];
        const pageData = SearchFilter.getPageData(this.state.active,this.state.page,result['data'],result['data']);
        const count = SearchFilter.getCountPage(result['data'],this.state.page);
        if (res.length > 0) {
          this.setState({
            tasks: res,
            searchTask: res,
            tagId: result['data'][0].id,
            count: count,
            items: pageData,
          });
        }
      });
  }
  handleHideDeletePopUp = () => {
    this.setState({
      showDeletePopUP: false,
      tagId:0
    })
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevState.currentId !== this.state.currentId) {
      this.setState({
        currentId: this.state.currentId,
      })
    }
    if(prevState.task_id!==this.state.task_id) {
      this.setState({
        task_id:this.state.task_id
      })
    }
  }
  openCalendar =(e)=>{
    this.props.history.push('/todoscalendar');
  }
  closeForm=()=>{
    this.setState({
      addSchedular:false,
      editSchedular:false,
      cloneSchedular:false,
      uploadPopUp:false,
      task_id:0,
    })
  }
  render() {
    const { t} = this.state;
    const deletePopUP = (
      <reactbootstrap.Modal
        show={this.state.showDeletePopUP}
        onHide={this.handleHideDeletePopUp}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
          {t('Are you sure you want to delete this Task ?')}
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={this.handleHideDeletePopUp}>{t('Cancel')}</reactbootstrap.Button>
          <reactbootstrap.Button onClick={this.deleteSchedular.bind(this)}>{t('Confirm')}</reactbootstrap.Button>
        </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
    );
    return (
      <reactbootstrap.Container>
        <reactbootstrap.Row className="row-1">
          {/* <reactbootstrap.Button>{t('Yearplanning')}</reactbootstrap.Button> */}
          <Can
            perform="C_taskplanner,D_taskplanner,RUN_taskplanner,V_taskplanner"
            yes={() => (
              <reactbootstrap.Button  variant="outline-success" className='mr-2 mb-2 mt-2' onClick={(e)=>this.openCalendar()}>{t('Planning')}</reactbootstrap.Button>
            )}
          />
          <Can
            perform="C_taskplanner"
            yes={() => (
              <reactbootstrap.Button variant="outline-danger" onClick={(e)=>this.handleNewTask()} className='mr-2 mb-2 mt-2'>{t('New task')}</reactbootstrap.Button>
            )}
          />
        </reactbootstrap.Row>
        <Can
          perform="C_taskplanner,D_taskplanner,RUN_taskplanner,V_taskplanner"
          yes={() => (
            <reactbootstrap.Row className='mb-5 row-1 button-design'>
              <reactbootstrap.Col className="pl-0 pr-0">
                {this.tableView()}{deletePopUP}{this.uploadPopUp()}
              </reactbootstrap.Col>
              <reactbootstrap.Col>
              { this.state.addSchedular === true &&<PlanningIndex cancel={this.handleCancel.bind(this)} tables={this.dataInsert.bind(this)} action={'create'} plannerId={this.state.task_id}/>}
              { this.state.editSchedular === true &&<PlanningIndex cancel={this.handleCancel.bind(this)} tables={this.dataInsert.bind(this)} action={'edit'} plannerId={this.state.task_id}/>}
              { this.state.cloneSchedular === true &&<PlanningIndex cancel={this.handleCancel.bind(this)} tables={this.dataInsert.bind(this)} action={'clone'} plannerId={this.state.task_id}/>}
              { this.state.viewSchedular === true &&<PlanningIndex cancel={this.handleCancel.bind(this)} tables={this.dataInsert.bind(this)} action={'view'} plannerId={this.state.task_id}/>}
                {/**this.state.addSchedular === true && <div>< SchedularTask cancel={this.handleCancel.bind(this)} tables={this.dataInsert.bind(this)} action={'create'} closeForm={this.closeForm}/></div>*/}
                {/**this.state.editSchedular === true && <div>< SchedularTask cancel={this.handleCancel.bind(this)} tables={this.dataInsert.bind(this)} id={this.state.task_id} action={'edit'} closeForm={this.closeForm}/></div>*/}
                {/**this.state.cloneSchedular === true && <div>< SchedularTask cancel={this.handleCancel.bind(this)} tables={this.dataInsert.bind(this)} id={this.state.task_id} action={'clone'} closeForm={this.closeForm}/></div>*/}
              </reactbootstrap.Col>
            </reactbootstrap.Row>
          )}
        />
      </reactbootstrap.Container>
    )
  }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(ManageOverView));
