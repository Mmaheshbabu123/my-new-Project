import React, { Component } from 'react';
import Pagination from 'react-bootstrap/Pagination'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import SearchInput, { createFilter } from 'react-search-input';
import Space from '../Space/Space';
import Can from '../_components/CanComponent/Can';
import SpaceFolderStructure from '../Space/SpaceFolderStructure';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import spaceedit from './space-edit2.png';
import spacedelete from './space-delete.png';
import spaceadd from './add-space.png';
import { translate } from '../language';
import './SpaceList.css';
import { OCAlert } from '@opuscapita/react-alerts';
import SubFile from './SpaceSub';

const KEYS_TO_FILTERS = ['name', 'id']

class ManageSpaces extends Component {
    constructor(props) {
        super(props)
        this.state = {
            spacelist: [],
            showspacepop: '',
            searchTerm: '',
            clone: [],
            popid: '',
            showpopup: '',
            doc_data: [],
            createdId:'',
            alert: '',
            malert: '',
            falert: '',
            currentPage: 1,
            todosPerPage: 5,
            tabId: '',

            scurrentPage: 1,
            spacePerPage: 5,
            persons: [],
            didupdate: '',
            page: 5,
            active: 1,
            id: '',
            count: 0,
            items: [],
            filterFullList: [],
            searchTerm: '',
            _1stSpace: '',
            active: false,
            mouse: false,
            created_space: '',
            t: props.t,
            pageIndex : [6,11,16,22,28,34,40,46,52,58,64,70,76]
        }
        this.searchData = this.searchData.bind(this);
        this.handledelete = this.handledelete.bind(this);
        this.changeComponent = this.changeComponent.bind(this);
        this.handleSpaceTrack = this.handleSpaceTrack.bind(this);

    }
    getPageData(id, list = '') {

        const page = this.state.page;

        const items = (list !== '') ? list : this.state.spacelist;

        const page_data = items.slice(page * (id - 1), page * id);

        return page_data;
    }
    componentDidMount() {

        const url = window.GET_SPACES;
        datasave.service(url, 'GET', '')
            .then(response => {
                const pageData = this.getPageData(1, response);
                const count = this.getCountPage(response);
                this.setState({
                    spacelist: response,
                    clone: response,
                    count: count,
                    items: pageData,
                    _1stSpace: response[0].id,

                })
            })
    }
    componentDidUpdate(prevProps, prevState) {

        if (prevState.component !== this.state.component || (prevState.didupdate !== this.state.didupdate && this.state.doc_data.length ===0 )) {
            const url = window.GET_SPACES;
            datasave.service(url, 'GET')
                .then(response => {
                    if(this.state.created_space == ''){

                    const pageData = this.getPageData(this.state.active, this.state.searchTerm!==''?this.state.items:response);
                    const count = this.getCountPage(this.state.searchTerm!==''?this.state.items:response);
                    this.setState({
                        created_space:'',
                        spacelist: response,
                        clone: response,
                        items: pageData,
                        count: count,
                        didupdate: 'true'
                    })
                }else{
                    const pageData = this.getPageData(1, response);
                    const count = this.getCountPage(response);
                    this.setState({
                        spacelist: response,
                        clone: response,
                        items: pageData,
                        count: count,
                        didupdate: 'true',

                    })
                    this.handleSpaceCatch(response);
                }
                })
        }
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }
    componentWillMount() {
        this.setState({ items: this.state.spacelist, active: 1 })
    }
    searchData(e) {
        var list = [...this.state.spacelist];
        list = list.filter(function (item) {
            if (item.name !== null) {
                return item.name.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
        });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    handlehide = () => {
        this.setState(
            { show: false, showspacepop: false }
        )
    }
    handleCancel() {
        this.setState(
            { show: false }
        )
    }
    handledelete(id) {
        const url = window.GET_LINKED_DATA + id
        datasave.service(url, 'GET', id).then(
            response => {
                this.setState({ doc_data: response, id: id, show: true, alert: '', })
                if (this.state.doc_data.length == 0) {
                    this.setState({ alert: 'true', })
                }
            }

        )

        this.setState({ currentPage: 1, popid: id, show: true, showpopup: 'true', didupdate: 'true' })
    }
    updateComponent(e) {
        if (e) {
            this.setState({
                component: 'false',
                saveComponent: 1,
            })
        }


    }
    update(e) {
        if (e !== this.state.tabId) {
            this.setState({
                tabId: e,
            });
        }
    }

    changeComponent(e, id) {
        this.setState({
            component: 'true',
            formId: (id !== '') ? id : '',
            _1stSpace: (id === undefined ? this.state._1stSpace:id)
        });

    }
    handlepopok() {
        this.setState({ didupdate: '1' })
        const {t} = this.state;
        const { popid, doc_data, folder_data, manual_data } = this.state;
        if (doc_data.length == 0) {
            const url = window.DELETE_SPACE_DATA + popid;
            datasave.service(url, 'put').then(
                response => {

                }
            )

            if (this.state.items.length - 1 == 0) {
                this.state.active = this.state.active - 1;
            }
        } else {
            OCAlert.alertWarning(t('Unable to delete space because its been using in documents'), { timeOut: window.TIMEOUTNOTIFICATION});

            // alert("Unlink associated records and try again!")
        }
        this.setState({ show: false, showpopup: '' })
    }

    handleExport() {
        const spaceid = this.state.id;
        const url = window.EXPORT_SPACES + spaceid;
        datasave.service(url, 'PUT', '').then(
            response => {
                window.open(response);
                window.close();
            }
        )
    }
    handlePageClick(event) {
        this.setState({
            currentPage: Number(event.target.id)
        });
    }


    handleSpacePageClick(event) {
        this.setState({
            scurrentPage: Number(event.target.id)
        })
    }
    handleSpaceClick(spaceid) {
        var url = window.GET_SPACE_FOLDERS_STRUCT + '/' + spaceid;
        datasave.service(url, 'GET').then(
            response => {
            }
        )
        this.setState({
            showspacepop: true,
            spacepop: spaceid,
            _1stSpace: spaceid,
            createdId :'',
            component:'false',
        })
    }
    handlespaceClickOK() {
        this.setState({ showspacepop: false, spacepop: '' })
    }
    changePage(e, id = 1) {

        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);

        this.setState({
            created_space:'',
            items: page_data,
            active: id,

        });
    }
    handleSpaceTrack(space) {
        this.setState({ created_space: space });



    }
    handleSpaceCatch(spacelist) {
        if(this.state.created_space!= ''&& this.state.created_space!== this.props.created_space){

        var index = spacelist.map(function(e) { return e.label; }).indexOf(this.state.created_space);
           let id  = spacelist[index]['id']

          var page = Math.floor(index/5);


          if(index%5>0){

            this.changePage('',(page+1));
            this.setState({
                _1stSpace:id
            })
            }else{
                this.setState({
                    _1stSpace:id
                })
                if(this.state.pageIndex.includes(index+1)){
                this.changePage('temp',page+1)
                }else{
                    if(index == 0){
                        this.changePage('temp',1)
                    }else{
                 this.changePage('temp',page)
                    }

                }
            }

        }

    }


    render() {
        const { t } = this.state;
        const { showpopup, doc_data, alert, todosPerPage, currentPage, folder_data, manual_data, mcurrentPage, fcurrentPage, malert, falert, spacelist, scurrentPage, spacePerPage, spacepop, clone, persons } = this.state;
        const indexOfLastTodo = currentPage * todosPerPage;
        const indexOfFirstTodo = indexOfLastTodo - todosPerPage;

        const indexOfLastSpace = scurrentPage * spacePerPage;
        const indexOfFirstSpace = indexOfLastSpace - spacePerPage;

        const currentTodos = doc_data.slice(indexOfFirstTodo, indexOfLastTodo);
        const pagerender = currentTodos.map(doc => {
            return <tr><td>{doc.code}</td>
                <td>{doc.name}</td>
                <td>{doc.folder}</td>
                <td>{doc.manual}</td>
            </tr>
        });

        const personsdata = persons.map(person => {
            return <li>
                {person}
            </li>
        })
        const pageNumbers = [];
        if (doc_data.length > 5) {
            for (let i = 1; i <= Math.ceil(doc_data.length / todosPerPage); i++) {
                pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
                    {i}
                </Pagination.Item>);
            }
        }


        const popup = (
            <reactbootstrap.Modal
                size="lg"
                show={this.state.show}
                onHide={this.handlehide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title">
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                    </reactbootstrap.Modal.Title>
                    <reactbootstrap.Modal.Body>

                        <reactbootstrap.Table responsive striped bordered hover size="sm">
                            <thead>
                                <tr>
                                    <td>{t('Document code')}</td>
                                    <td>{t('Document name')}</td>
                                    <td>{t('Folder name')}</td>
                                    <td>{t('Manual name')}</td>
                                </tr>
                            </thead>
                            <tbody>
                                {pagerender}

                            </tbody>
                            {alert && <span className=" alert text-center">{t('No  Record found !')}</span>}
                        </reactbootstrap.Table>
                        <div className="col-md-12">
                        <Pagination style={{width: '200px', overflow: 'auto'}} size="sm">{pageNumbers}</Pagination>
                        </div>

                    </reactbootstrap.Modal.Body>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button onClick={() => this.handleCancel()}>{t('Cancel')}</reactbootstrap.Button>
                    &nbsp;&nbsp; &nbsp;&nbsp;
                <reactbootstrap.Button onClick={() => this.handlepopok()}>{t('Delete')}</reactbootstrap.Button>
                    &nbsp;&nbsp; &nbsp;&nbsp;
                <reactbootstrap.Button onClick={() => this.handleExport()}>{t('Export')}</reactbootstrap.Button>
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );
        const filtered = this.state.items;
        const spaces = filtered.map(space => {
            let className = ((space.id === this.state._1stSpace)) ? 'sactive' : 'sinactive';
            return <tr>
                <td className={className} style={{ cursor: 'pointer', hover: 'color:#007bf8' }} onClick={(e) => this.handleSpaceClick(space.id)} >
                    <span   className={className}>
                        {space.name}
                    </span>
                </td>
                <td   className={className} >

                    <div style={{ display: "flex" }}>
                            <div style={{paddingLeft: '2rem'}}>
                            <Can
                                perform="E_space"
                                yes={() => (
                                    <span className="" variant="link">
                                        <i title={t("Edit")}  style ={{'cursor':'pointer'}} class="overall-sprite overall-sprite-myeditc" onClick={(e) => this.changeComponent(e, space.id)}></i>
                                    </span>
                                )}
                            />
                            </div>

                        <div style={{paddingLeft: '10px'}}>
                            {this.state.component !== 'true' &&
                                <Can
                                    perform="D_space"
                                    yes={() => (

                                        <span className="">
                                            <i title={t("Delete")} style ={{'cursor':'pointer'}}class="overall-sprite overall-sprite-mtdeletec" onClick={() => this.handledelete(space.id)}></i>
                                            </span>

                                    )}
                                />
                            }
                        </div>
                        </div>

                </td>
            </tr>
        })
        let active = this.state.active;
        let pages = [];
        if (this.state.count > 0)
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }
        return (
            <div className='container'>
                <div className="card-body mb-3">
                    <Can
                        perform="R_space,E_space,D_space"
                        yes={() => (
                            <div className='row'>
                                <div className='col-md-12 mb-3'>
                                    <div className='card'>
                                        {/*<div className="text-center">
                                            <div className='card-header'><h3>{t('Manage spaces')}</h3> </div>
                                        </div>*/}

                                        {showpopup && popup}
                                        <div className="row container">
                                            <reactbootstrap.Col lg={4}>
                                                <div className="text-center">
                                                    {/*<h3 style={{marginTop: '10px'}}>{t('Spaces')} </h3><hr />*/}
                                                    <div style={{ display: 'flex' }} className="mb-2 pt-3">
                                                        <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C" }} placeholder={t("What are you looking for ?")} autoFocus onChange={this.searchData} /><br />
                                                        <Can
                                                          perform = "E_space"
                                                          yes = {() => (
                                                          <reactbootstrap.Button onClick={(e) => this.changeComponent(e)} variant="link">
                                                            <i title={t("Add Spaces")} class="overall-sprite overall-sprite-spacec"></i>
                                                          </reactbootstrap.Button>
                                                          )}
                                                        />
                                                    </div>
                                                    <reactbootstrap.Table responsive bordered hover>
                                                        <thead>
                                                            <tr style={{backgroundColor: '#EC661C',color: '#fff'}}>
                                                                <th>{t('Name')}</th>
                                                                <th>{t('Actions')}</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {spacelist.length == 0 && <div> {t('No records found')}</div>}
                                                            {spaces}
                                                        </tbody>
                                                    </reactbootstrap.Table>
                                                    <div className="pg col-md-12">
                                                    {pages.length > 1 && <Pagination style={{width: '200px', overflow: 'auto'}} size="md">{pages}</Pagination>}
                                                    </div>
                                                </div>
                                            </reactbootstrap.Col>
                                            {this.state.component === 'true' &&
                                              <Can
                                                perform = "E_space"
                                                yes = {() => (
                                                <div className="col-8">
                                                  <Space updateComponent={this.updateComponent.bind(this)} id={this.state.formId} saved={this.handleSpaceTrack} />
                                                </div>
                                                )}
                                              />
                                            }
                                            {this.state.component !== 'true' && <reactbootstrap.Col lg={8} className="py-3"> <SubFile update={this.update.bind(this)} data={this.state._1stSpace} tabId={this.state.tabId} /></reactbootstrap.Col>}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        no={() =>
                            <AccessDeniedPage />
                        }
                    />
                </div>
            </div>

        );
    }
}

export default translate(ManageSpaces);
