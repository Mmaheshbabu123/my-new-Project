import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import TreeMenu from 'react-simple-tree-menu'
import renderhtml from 'react-render-html';
import { datasave } from '../_services/db_services';
import FolderStructure from '../Folder/Folder';
import DocumentStructure from '../Document/Document';
import documentlogo from './document.png';
import folderlogo from './folder-icon.png';
import manageunlink from './manage-unlink.png';
import managelink from './manage-link.png';
import {translate} from '../language';
import { Button, Container, Form, FormGroup, Input, Label, ListGroup, ListGroupItem } from 'reactstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import Can from '../_components/CanComponent/Can';


class SpaceFolderStructure extends Component{
    constructor(props) {
        super(props)
        this.state = {
            blanco_data: {},
            testdata: "testdata",
            showDocHeader: false,
            showFolder: false,
            credentials: {},
            update: 1,
            lnk_ulnk_status:'',
            openNodeManual:[],
            manualtabkey: '',
            manual_data:'',
            count:[],
            tag:'',
            space_id:'',
            doc_id:'',
            t:props.t,
        }
        this.unlinkSpace = this.unlinkSpace.bind(this);
        this.onClickNode = this.onClickNode.bind(this);

        this.linkSpace = this.linkSpace.bind(this);
    }
    componentDidMount() {

        var url = window.GET_STANDARDS_FOLDER_STRUCT+'/'+this.props.data.toString()+'/'+5
        datasave.service(url, "GET")
            .then(result => {
              this.setState({
                  openNodeManual:result.opennodes,
                  });
                this.displayFolder(result.data, result.manual, result.count);
            });
    }
    componentDidUpdate(prevProps, prevState) {
        if (this.props.data !== prevProps.data) {
            datasave.service(window.GET_STANDARDS_FOLDER_STRUCT+'/'+this.props.data.toString()+'/'+5, 'GET', '')
            .then(response => {
              this.setState({
                  openNodeManual:response.opennodes,
                  });
                this.displayFolder(response.data, response.manual, response.count);
            });
           }

    }
    // displayFolder(data, manual, counter) {
    //     let finalData = {};
    //     let folderData = data;
    //     var touched_ids = [];
    //     var dat = [];
    //     var count = Object.values(counter)[0];
    //     var docCount = count
    //     Object.keys(folderData).map(function (key) {
    //         dat = Object.values(folderData[key]);
    //         touched_ids[key] = [];
    //             dat.map(function(data) {
    //               if (data.childrens.length > 0) {
    //                 data.childrens.forEach(function (id) {
    //                   var child_key = id;
    //                   var parent_key = 'F' + data.key_type;
    //                   if (data.key_type !== undefined) {
    //                     folderData[key][parent_key].nodes[id] = folderData[key][id];
    //                     touched_ids[key].push(id);
    //                   }
    //                 })
    //               }
    //             });
    //           finalData[key] = folderData[key];
    //       });
    //       Object.keys(finalData).forEach(function(fd) {
    //         touched_ids.forEach(function (id, value) {
    //           id.forEach(function(cid){
    //             delete finalData[fd][cid];
    //           })
    //         });
    //       })
    //       this.setState({
    //           blanco_data: finalData,
    //           update: 0,
    //           manual_data:manual,
    //           lnk_ulnk_status: '',
    //           manualtabkey: (this.props.tabId === '') ? Object.values(manual)[0].mid : this.props.tabId,
    //           count:docCount,
    //       })
    // }
    /*
    *@param data takes the folder object which is to be created.
    * Creates an object with the childrens which is specified in data param and sets to the blanco state.
    */
    displayFolder(data, manual, counter) {
        let finalData = {};
        let folderData = data;
        var touched_ids = [];
        var dat = [];
        var count = Object.values(counter)[0];
        var docCount = count;

        Object.keys(folderData).map(function (key) {
            dat = Object.values(folderData[key]);
            touched_ids[key] = [];
                dat.map(function(data) {
                  if (data.childrens.length > 0) {
                    data.childrens.forEach(function (id) {
                      var child_key = id;
                      var parent_key = 'F' + data.key_type;
                      if (data.key_type !== undefined) {
                        folderData[key][parent_key].nodes[id] = folderData[key][id];
                        touched_ids[key].push(id);
                      }
                    })
                  }
                });
              finalData[key] = folderData[key];
          });

          Object.keys(finalData).forEach(function(fd) {
            touched_ids.forEach(function (id, value) {
              id.forEach(function(cid){
                delete finalData[fd][cid];
              })
            });
          })

          this.setState({
              blanco_data: finalData,
              update: 0,

              manual_data:manual,

              manualtabkey: (this.state.manualtabkey === '') ? Object.values(manual)[0].mid : this.state.manualtabkey,
              count:docCount,
          })
    }

        onClickNode(key, label, props) {
          var openNodeArray=this.state.openNodeManual;
          if(openNodeArray!==null && openNodeArray.includes(key)){
            var index = openNodeArray.indexOf(key);
            if (index !== -1) openNodeArray.splice(index, 1);
          }else{
            openNodeArray.push(key);
          }
          this.setState({
              openNodeManual:openNodeArray,
              });
        }
    unlinkSpace(e, tabId, docData) {
      const {t} = this.state;
        e.preventDefault();
        var url = window.UNLINK_SPACE+'/'+this.props.data+'/'+docData.key_type;
        const details = {
           space_id:this.props.data,
           doc_id:docData.key_type
        }
        datasave.service(url, "PUT",details)
            .then(result => {
              OCAlert.alertSuccess(t('Unlinked successfully!'), { timeOut: window.TIMEOUTNOTIFICATION});

           this.handleSPaceLink();

            });
    }
    linkSpace(e, tabId, docData) {
        const {t} = this.state;
        var url = window.LINK_SPACE+'/'+this.props.data+'/'+docData.key_type;
        const details ={
            space_id:this.props.data,
            doc_id:docData.key_type
        }
        datasave.service(url, "POST",details)
            .then(result => {
              OCAlert.alertSuccess(t('Linked successfully!'), { timeOut: window.TIMEOUTNOTIFICATION});
              this.handleSPaceLink();

            });
    }

    handleSPaceLink = ()=>{
      datasave.service(window.GET_STANDARDS_FOLDER_STRUCT+'/'+this.props.data.toString()+'/'+5, 'GET', '')
      .then(response => {
        this.setState({
            openNodeManual:response.opennodes,
            });
          this.displayFolder(response.data, response.manual, response.count);
      });
    }
    render() {
        let count = 0




    const {t} = this.state;
     // let count = 0;
     const DEFAULT_PADDING = 5;
     const ICON_SIZE = 8;
     const LEVEL_SPACE = 16;
     const WIDTH = '25px';
     const HEIGHT = '25px';
     const STYLE = { color: 'blue' };
     const DISPLAY = 'inline-flex';
     const WIDTH_DYNAMIC = 33;
     const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }}>{on ? '-' : '+'}</span>;
     const logo = renderhtml('<img  src=' + folderlogo + ' alt="Logo" style="width:5%" />');
     const ListItem = ({
       level = 0,
       key,
       doc_type,
       status,
       rights,
       owner,
       hasNodes,
       isOpen,
       type_id,
       current_type,
       manual_id,
       label,
       searchTerm,
       openNodes,
       version,
       isLinked,
       ...props
     }) => (
         < div className="folder-manual-section">
           <ListGroupItem
             {...props}
             style={{
               paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
               cursor: 'pointer',
             }}
             key={key}
           >
           <div className="list-items-structure" style = {{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
             {hasNodes && <ToggleIcon on={isOpen} />}
             {!hasNodes && <span style={{ marginRight: 8 }}> &nbsp;</span>}
             {current_type === 'manual' &&
                 <i class="folder-icons folder-icons-accounts" title="Manual"  style={{ marginRight: '5px' }}> </i>
             }
             {current_type === 'folder' &&
                 <i class="folder-icons folder-icons-folder" title="Folder"  style={{ marginRight: '5px' }}> </i>
             }
             {current_type === 'document' &&
                 <i class={'folder-icons folder-icons-' + doc_type} title={doc_type} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id)} />
             }
             {current_type === 'document' &&
                 <i class={'sprite-document2 sprite-document2-' + status} title={status} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id)} />
             }
             <span title={label} className={"folderstructure-label-" + current_type} style={{ marginBottom: '0px' }}>
                 {label}
             </span>
             {current_type === 'document' &&
              <span className="version-wrapper">
                 {version}
               </span>
             }
             <div className = 'icon-items'>
             { isLinked && type_id === 'document' &&
                <Can
                  perform = "E_space"
                  yes = {() => (
                    <reactbootstrap title="Unlink" onClick={(e) => this.unlinkSpace(e, this.props.data, {...props})} >
                      <img src={manageunlink} style={{width: '20px', height: '20px', marginLeft: '10px'}}></img>
                    </reactbootstrap>
                  )}
                />
             }
            { !isLinked && type_id === 'document' &&
              <Can
                perform = "E_space"
                yes = {() => (
                  <reactbootstrap title="Link" onClick={(e) => this.linkSpace(e, this.props.data, {...props})} >
                      <img src={managelink} style={{width: '20px', height: '20px',marginLeft: '10px'}}></img>
                  </reactbootstrap>
                )}
              />
            }

                </div>
           </div>
           </ListGroupItem>
         </div >
       );
    return (
      <Can
        perform = "R_space"
        yes = {() => (
          <div className="container-fluid">
              <div className="row">
                  <div className="col-lg-12 pl-0 mt-1">
                  <reactbootstrap.Tabs
                   id="controlled-tab-example" className="header_tabs"
                   activeKey={this.state.manualtabkey}
                   onSelect={manualtabkey => this.setState({ manualtabkey })}
                  >
                   {
                                 Object.values(this.state.manual_data).map(function(values,key) {
                                  (Object.keys(this.state.count)).map((item,index)=>{
                                          if(values.mid == item){
                                               count = this.state.count[item];
                                               return;
                                          }
                                  }
                                  )
                                 return (
                                 <reactbootstrap.Tab eventKey = {values.mid} title={values.label+'('+count+')'}>

                                  <TreeMenu
                              data={this.state.blanco_data[values.mid]}
                              hasSearch='false'
                              openNodes={this.state.openNodeManual}
                               onClickItem={({ key, label, ...props }) => {
                                 this.onClickNode(key, label, props);
                              }}
                              debounceTime={125}>
                              {({ search, items }) => (
                                  <>
                                  <Input className="search-input form-control mt-2 mb-3" style={{borderRadius: '5px', 'border-color': "#EC661C"}} onChange={e => search(e.target.value)} placeholder={t("Search")} />
                                  <ListGroup style={{height: '220px',overflow: 'auto', WebkitBackfaceVisibility: 'hidden'}}>
                                      {items.map(props => (
                                      <div>
                                          <ListItem {...props} />
                                      </div>
                                      ))}
                                  </ListGroup>
                                  </>
                              )}
                              </TreeMenu>

                                </reactbootstrap.Tab>
                              )}, this)
                             }
                  </reactbootstrap.Tabs>
                 </div>
               </div>
            </div >
          )}
      />
    );
  }

}
export default translate(SpaceFolderStructure)
