import axios from 'axios'
import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import DragnDrop from '../DragnDrop';
import { filterArray } from '../_helpers/filter-array';
import { translate } from '../language';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
class Space extends Component {
  constructor(props) {
    super(props)
    this.state = {
      space_store_url: window.GET_INSERT_SPACE_DETAILS,
      name: '',
      name_error: '',
      available_in_masterdata: 1,
      tasks: [],
      clone: '',
      items: [],
      types: [],
      active_tab1: 1,
      disableFields: false,
      credentials: {},
      details: {},
      [window.tabs.spaces]: [],
      t: props.t,
    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handlechange = this.handlechange.bind(this);
    this.handleActiveTab = this.handleActiveTab.bind(this);
    this.validate = this.validate.bind(this);

  }

  componentDidMount() {
    const space_id = this.props.id;
    if (this.props.id) {
      const geturl = window.GET_SPACE_NAME + space_id;
      datasave.service(geturl, 'GET').then(
        response => {
          this.setState({ name: response[0]['name'], clone: response[0]['name'] })
        }
      )
      const selectedurl = window.GET_SPACE_SELECTED + space_id;
      datasave.service(selectedurl, 'GET', space_id).then(
        response => {
          this.setState({
            [window.tabs.spaces]: response,
            require_error: '', name_error: '',
          })
        }
      )
      var url = window.GET_READ_UNDERSTOOD_DATA;
      datasave.service(url, "GET")
        .then(result => {
          this.setState({
            tasks: result.jgd,
            items: result.jgd,
            types: result.types,
          })
        });

    }
    else {
      axios.get(process.env.REACT_APP_serverURL + '/api/functions').then(response => {
        this.setState({
          responsibilites: response.data,
        })
      })
      var url = window.GET_READ_UNDERSTOOD_DATA;
      datasave.service(url, "GET")
        .then(result => {
          this.setState({
            tasks: result.jgd,
            items: result.jgd,
            types: result.types,
            [window.tabs.spaces]: [],
          })
        });
    }
  }
  componentDidUpdate(prevProps, prevState) {
    let space_id = this.props.id;
    if (space_id !== '' && prevProps.id !== this.props.id) {
      if (space_id !== undefined) {
        this.getSpaceDetails(space_id);
        this.getSpaces(space_id);
        this.getOrginisationUnit();
      }
      else {
        this.setState({
          name: '',
          [window.tabs.spaces]: '',
          require_error: '',
          name_error: '',

        })
      }
    }
  }
  componentWillReceiveProps() {
    if (this.props.id === undefined) {
      this.setState({ name_error: '', error: '', require_error: '' })
    }
  }

  getSpaceDetails(id) {
    const geturl = window.GET_SPACE_NAME + id;
    if (id !== undefined) {
      datasave.service(geturl, 'GET').then(
        response => {
          this.setState({ name: response[0]['name'], clone: response[0]['name'], require_error: '', name_error: '' })
        }
      )
    }
  }
  getOrginisationUnit() {
    var url = window.GET_READ_UNDERSTOOD_DATA;
    datasave.service(url, "GET")
      .then(result => {
        this.setState({
          tasks: result.jgd,
          items: result.jgd,
          types: result.types,
        })
      });
  }
  getSpaces(id) {
    const selectedurl = window.GET_SPACE_SELECTED + id;
    if (id !== undefined) {
      datasave.service(selectedurl, 'GET').then(
        response => {
          this.setState({
            [window.tabs.spaces]: response,
          })
        }
      )
    }
  }
  handleCancel(event) {
    this.props.updateComponent(1);
  }

  handlechange(event) {
    const {t} = this.state;
    const { name, value, } = event.target
    this.setState({
      [name]: value
    })
    if (event.target.value == '') {
      this.setState({ require_error: t('Space name is required field'), name_error: '' })
    } else {

      this.setState({ name_error: '', require_error: '' })
    }
  }



  handleSubmit(event) {
    event.preventDefault()
    const { history } = this.props
    const {t} = this.state;
    const data = {
      name: this.state.name.replace(/\s+/g, ' ').trim(),
      available_in_masterdata: this.state.available_in_masterdata,
      org: this.state[window.tabs.spaces],
      clone: this.state.clone,
    }

    if (this.props.id) {
      if (this.validate()) {
        const details = {
          name: this.state.name.replace(/\s+/g, ' ').trim(),
          id: this.props.id,
          available_in_masterdata: this.state.available_in_masterdata,
          org: this.state[window.tabs.spaces],
          clone: this.state.clone.replace(/\s+/g, ' ').trim(),
          modifyname:this.state.clone.replace(/\s+/g, ' ').trim() !== this.state.name.replace(/\s+/g, ' ').trim(),
        }
        const editurl = window.UPDATE_SPACE
        datasave.service(editurl, 'PUT', details).then(
          response => {
            if (response == 'exist') {
              this.setState({
                name_error: t('The name has already been taken!'),
              })
            } else {
              if (response == "success") {
                this.props.saved(this.state.name.replace(/\s+/g, ' ').trim());
                this.props.updateComponent(1);
              }
            }
          }
        )

      }
    } else {
      if (this.validate()) {
        const url = this.state.space_store_url;
        datasave.service(this.state.space_store_url, 'POST', data)
          .then(response => {
            if (response == 'exist') {
              this.setState({
                name_error: t('The name has already been taken !'),
              })
            } else {
              if (response == "success") {
                this.props.updateComponent(1);
                this.props.saved(this.state.name.replace(/\s+/g, ' ').trim());
              }
            }
          })
          .catch(error => {
            this.setState({
              errors: t('Error try again !')
            })
          })
      }
    }

  }
  validate() {
    var name_valid = this.state.name.replace(/\s+/g, ' ').trim();
    let formIsValid;
    var regex = new RegExp("^[0-9a-zA-Z\b ]+$");
    const {t} = this.state;
    //  let $spl = name_valid.match(/[^\w\.\-]/);
    let spl = regex.exec(name_valid)
    if (name_valid == '') {
      formIsValid = false;
      this.setState(
        {
          require_error: t('Space name is required field')
        }
      )
     }
     else {
      formIsValid = true;
      // if (spl == null) {
      //   this.setState({
      //     require_error: t('Special characters are not allowed!')
      //   })
      //   formIsValid = false;
      // } else {
      //   formIsValid = true;
      // }
    }
    return formIsValid;
  }
  updateSelected = (latestDropped, result, type, id = '') => {
    var array = [...this.state[type]];
    if (result.type === 'remove') {
      var filterArray = array.filter(selected => (selected.name !== latestDropped.name));
    }
    if (result.type === 'remove') {
      this.setState({
        [type]: filterArray
      })
    }
    else {
      this.setState(prevState => ({
        [type]: [...prevState[type], latestDropped]
      }));
    }
  }

  handleActiveTab(key) {
    this.setState({
      active_tab1: key,
    });
  }

  render() {
    const { loading, name, t, available_in_masterdata, name_error, require_error } = this.state
    var filter_default = this.state.tasks;
    if (this.state[window.tabs.spaces].length > 0) {
      filter_default = filterArray(this.state.tasks, this.state[window.tabs.spaces])
    }
    let disable_based_on_right = false;

    return (

      <div className='container '>
        <div className='row ' >
          <div className='col-md-12 pt-3' >
          <div>
          {/*<h3 style={{marginTop: '0.7rem',marginBottom: '0.7rem'}}>{t('Create space')}</h3>*/}
          </div>
            <div className='card'>
              {this.props.id && <div className='card-header' >{t('Update space')} </div>}
              {this.props.id === undefined && <div className='card-header' > {t('Create space')} </div>}

              <div className='card-body mb-3' >
                <reactbootstrap.Container className="">
                  <reactbootstrap.Form onSubmit={this.handleSubmit}>
                    <reactbootstrap.Tabs activeKey={this.state.active_tab1} onSelect={this.handleActiveTab} id="controlled-tab-example">
                      <reactbootstrap.Tab eventKey={1} title={t("Space")}>
                        <reactbootstrap.FormGroup>
                          <div className=" row input-overall-sec ">
                            <reactbootstrap.InputGroup className="">
                              <div className="col-md-4">
                                <reactbootstrap.InputGroup.Prepend>
                                  <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Space name')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                                </reactbootstrap.InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd">
                                <reactbootstrap.FormControl
                                  name='name'
                                  autoFocus
                                  placeholder={t("Space name")}
                                  aria-label="Functionname"
                                  aria-describedby="basic-addon1"
                                  value={name}
                                  onChange={this.handlechange}
                                  className="input_sw"
                                />
                                <div style={{ color: 'red' }} className="error-block mt-2">{name_error}</div>
                            <div style={{ color: 'red' }} className="error-block mt-2">{require_error}</div>
                              </div>
                            </reactbootstrap.InputGroup>

                          </div>
                        </reactbootstrap.FormGroup>
                      </reactbootstrap.Tab>
                      <reactbootstrap.Tab eventKey={2} title={t("Organisation units")}>
                        <DragnDrop
                          types={this.state.types}
                          tasks={filter_default}
                          items={filter_default}
                          active_tab={this.state.active_tab}
                          details={this.state.details}
                          type={window.tabs.common}
                          selected={Object.values(this.state[window.tabs.spaces])}
                          {...this}
                          updateSelectedChild={this.updateSelected}
                          activeKey={this.state.active_tab}
                          onSelect={this.state.handleActiveTab}
                          tab={window.tabs.spaces}
                          credentials={this.state.credentials}
                          details={this.state.disableFields}
                          updateProps={1}
                          disable_based_on_right={disable_based_on_right}
                        />
                      </reactbootstrap.Tab>

                    </reactbootstrap.Tabs>

                    <FormGroup>
                      <div style={{ float: 'right' }} className="organisation_list mt-3">
                        <a onClick={this.handleCancel} >{t('Cancel')}</a>
                        &nbsp;&nbsp;&nbsp;
                        <Button style={{fontSize: '14px'}} type="submit" className="btn btn-primary" disabled={loading}>{t('Save')}</Button>
                      </div>
                    </FormGroup>

                  </reactbootstrap.Form>
                </reactbootstrap.Container>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default translate(Space);
