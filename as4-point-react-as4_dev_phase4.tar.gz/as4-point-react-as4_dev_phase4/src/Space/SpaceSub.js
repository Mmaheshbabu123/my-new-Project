import React, { Component } from 'react';
import SpaceFolderStructure from './SpaceFolderStructure';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Pagination from 'react-bootstrap/Pagination'
import Can from '../_components/CanComponent/Can';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';
import { translate } from '../language';

class  SpaceSub extends React.Component {
    constructor(props) {
        super(props);
        this.state ={
          data:[],
          id:'',
          page: 5,
          active: 1,
          items:[],
          count:0,
          orgdata:[],
          t:props.t,
        }
    }
    componentDidMount(){
        if (this.props.data !== undefined) {
        const selectedurl = window.GET_SPACE_SELECTED + this.props.data;
            datasave.service(selectedurl, 'GET').then(
              response => {
                // const pageData = this.getPageData(1, response);
                // const count = this.getCountPage(response);
                this.setState({
                 orgdata: response,

                })
              }
            )
          }
    }
    componentDidUpdate(prevProps,prevState){

        if(this.props.data!= prevProps.data){
        if (this.props.data !== undefined) {
            const selectedurl = window.GET_SPACE_SELECTED + this.props.data
            datasave.service(selectedurl, 'GET').then(
              response => {
                // const pageData = this.getPageData(1, response);
                // const count = this.getCountPage(response);
                this.setState({
                 orgdata: response,

                })
              }
            )
          }
    }
}


  render() {
      const link_tab_diable = CanPermissions("R_space,E_space", "");
      let link_tab_access = (link_tab_diable) ? '' : 'disabled';
      const organisationalunits_tab_diable = CanPermissions("R_space,E_space", "");
      let organisationalunits_tab_access = (organisationalunits_tab_diable) ? '' : 'disabled';
      let persons = [];
      let jobs =  [];
      let groups = [];
      let departments = [];
      const {t} = this.state;
           this.state.orgdata.map(item=>{

           {item.category == "persons" && persons.push(item.name)}
            {item.category == "jobs"&& jobs.push(item.name)
           }
           {item.category == "groups"&&  groups.push(item.name)}
            {item.category == "departments"&& departments.push(item.name)}

            })

    let  data1 =  persons.map(item=>{
         return(
             <li>
                 {item}
             </li>

         )
     })
    let  data2 =  jobs.map(item=>{
      return(
          <li>

              {item}
          </li>

      )
    })
       let data3 =  groups.map(item=>{
          return(

              <li>
                  {item}
              </li>

          )
      })
       let data4 =  departments.map(item=>{
          return(

              <li>
                  {item}
              </li>

          )
        })
        return(
          <div>
            <reactbootstrap.Tabs defaultActiveKey="home" id="uncontrolled-tab-example">
              <reactbootstrap.Tab disabled = {link_tab_access} eventKey="home" title={t("Link")}>
              <Can
                  perform="R_space,E_space"
                  yes={() => (
                    <SpaceFolderStructure update={this.props.update} data={this.props.data} tabId={this.props.tabId} />
                  )}
              />
              </reactbootstrap.Tab>

              <reactbootstrap.Tab disabled = {organisationalunits_tab_access} eventKey="used" title={t("Organisation units")}>
                <Can
                   perform="R_space,E_space"
                   yes={() => (
                     <reactbootstrap.Table responsive bordered hover>
                      <thead>
                        <tr>
                          <th>{t('Persons')}</th>
                          <th>{t('Jobs')}</th>
                          <th>{t('Groups')}</th>
                          <th>{t('Departments')}</th>
                        </tr>
                      </thead>
                      <tbody>


                   <tr>
                       <td> {data1}</td>
                        <td>{data2}</td>
                        <td>{data3}</td>
                        <td>{data4}</td>
                        </tr>


                    </tbody>
                  </reactbootstrap.Table>
                   // <Pagination size="md">{pages}</Pagination>
                )}
              />
              </reactbootstrap.Tab>
            </reactbootstrap.Tabs>
          </div>
        )
    }

}
export default translate(SpaceSub);
