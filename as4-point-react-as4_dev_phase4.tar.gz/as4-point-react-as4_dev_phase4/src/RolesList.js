//import axios from 'axios'
import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from './_services/db_services';
import Can from './_components/CanComponent/Can';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import Pagination from 'react-bootstrap/Pagination';
import {translate} from './language';
import './RolesList.css';
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from './store';
import Roles from './Roles';

class RolesList extends Component {
  constructor (props) {
    super(props)
    let userData = store.getState();
    this.state = {
        roles: [],
        items:[],
        searchTerm:'',
        id:'',
        page: 5,
        count: 0,
        active: 1,
        filterFullList:[],
        t:props.t,
        logedinRoleId : userData.UserData.user_details.role_id,
        mainkey : 1,
    }
    this.searchData = this.searchData.bind(this);
    this.handleMainTabSelect = this.handleMainTabSelect.bind(this);
  }

  componentDidMount () {
    var url = window.CHILDROLES + '/' + this.state.logedinRoleId;
    datasave.service(url, "GET")
    .then(response => {
      const pageData = this.getPageData(1, response);
      const count = this.getCountPage(response);
      this.setState({
        roles: response,
        count: count,
        items : pageData,

      })
    })
  }
  componentDidUpdate(prevProps, prevState) {
      if (prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
          var url = window.CHILDROLES + '/' + this.state.logedinRoleId;
          datasave.service(url, 'GET')
              .then(response => {
                      const pageData = this.getPageData(this.state.active, response);
                      const count = this.getCountPage(response);
                      this.setState({
                          roles: response,
                          items :pageData,
                          count: count,
                      })
              });
      }
  }
  getCountPage(items) {
      const itemLength = items.length;
      return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }
  componentWillMount() {
      this.setState({ items: this.state.roles })
  }
  searchData(e) {
      var list = [...this.state.roles];
      list = list.filter(function (item) {
          if (item.name !== null) {
              return item.name.toLowerCase().search(
                  e.target.value.toLowerCase()) !== -1;
          }
      });
      const page_data = this.getPageData(1, list);
      const count = this.getCountPage(list);
      this.setState({
          items: page_data,
          count: count,
          active: 1,
          searchTerm: e.target.value,
          filterFullList: list,
      });

  }
  changePage(e, id = 1) {
      const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
      const page_data = this.getPageData(id, list);
      this.setState({
          items : page_data,
          active: id,
      });
  }
  getPageData(id, list = '') {
      const page = this.state.page;
      const items = (list !== '') ? list : this.state.roles;
      const page_data = items.slice(page * (id - 1), page * id);
      return page_data;
  }
  handleDelete(id) {
    const {t} = this.state;
    var url = window.DELETE_ROLE;
    var details = {
      role_id: id,
    }
    datasave.service(url, 'PUT', details)
      .then(response => {
        const pageData = this.getPageData(1, response);
        const count = this.getCountPage(response);
        this.setState({
          roles: response,
          count: count,
          items : pageData,
        })
        if (response === "linked persons") {
         OCAlert.alertWarning(t('Persons has been created with this role'), { timeOut: window.TIMEOUTNOTIFICATION1});
        }
      })
  }
  handleMainTabSelect (key) {
    this.setState({
      mainkey : key
    })

  }
  handlePageChange () {
    this.setState({
      mainkey : 1,
    })
    var url = window.CHILDROLES + '/' + this.state.logedinRoleId;
    datasave.service(url, 'GET')
      .then(response => {
        const pageData = this.getPageData(this.state.active, response);
        const count = this.getCountPage(response);
        this.setState({
            roles: response,
            items :pageData,
            count: count,
        })
    });

  }

  render () {
    const { roles,t } = this.state
    const filtered = this.state.items;
    let active = this.state.active;
    let pages = [];
    if(this.state.count > 0)
    {
        for (let number = 1; number <= this.state.count; number++) {
            pages.push(
                <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                    {number}
                </Pagination.Item>,
            );
        }
    }
    return (
      <div className=" row col-md-12">
      <div style={{visibility: 'hidden'}} className="col-md-1"><p>welcome</p></div>
      <div style={{}} className='col-md-11' >
      <Can
        perform = "E_role,D_role,R_role"
        yes = {() => (
          <div className='card'>
            <div className='col-md-12 mt-0 mb-0 pl-0 pr-0'>
            <reactbootstrap.Tabs activeKey={this.state.mainkey} onSelect={this.handleMainTabSelect} id="controlled-tab-example">
            <reactbootstrap.Tab eventKey={1} title={t("Manage roles")}>

              <div className=''>
                {/* <div className='card-header'>{t('All default roles')}</div> */}
                <div className='card-body'>
                <input className="form-control search-box-border col-md-4 mb-2" placeholder={t("Search")} onChange={this.searchData} /><br />
                <div style={{}}>
                <reactbootstrap.Table  className="site-table-main" >
                    <thead>
                      <tr>
                        <th>{t('Name of usertype')}</th>
                        <th style={{textAlign: 'right'}} colspan="2">{t('Actions')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map(roleItem => (
                        <tr style={{borderTop: '1px solid #dee2e6'}}>
                          <td>
                            {roleItem.name}
                          </td>
                          <td style={{display: 'flex', float: 'right', border: '0px'}}>
                            <Can
                              perform="E_role"
                              yes={() => (
                                <Link style={{float: 'right', padding: '10px'}}
                                  to={`/roles/${roleItem.id}`}
                                  key={roleItem.id}
                                >
                                  {/* {t('Edit')} */}
                                  <i title="Edit" class="overall-sprite overall-sprite-myeditc"></i>
                                </Link>
                              )}
                            />
                            {roleItem.role_type == 'site_role' &&
                              <Can
                                perform="D_role"
                                yes={() => (
                                  <a  style={{float: 'right', padding: '10px'}} onClick={this.handleDelete.bind(this, roleItem.id)}>
                                    {/* {t('Delete')} */}
                                    <i title="Delete" class="overall-sprite overall-sprite-mtdeletec"></i>
                                  </a>
                                )}
                              />
                            }
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </reactbootstrap.Table>
                  </div>
                  {/* <Pagination size="md">{pages}</Pagination> */}
                  <div className="page-nation-sec col-md-12">
                        <Pagination style={{width: '500px',overflow: 'auto',scrollbarWidth: 'thin'}} size="md">{pages}</Pagination>
                        </div>
                </div>
              </div>
              </reactbootstrap.Tab>
              <reactbootstrap.Tab eventKey={2} title={t("Create role")}>
                <Roles handlePageChange={this.handlePageChange.bind(this)}></Roles>
              </reactbootstrap.Tab>
              </reactbootstrap.Tabs>
            </div>
          </div>

        )}
        no = {() =>
          <AccessDeniedPage/>
        }
      />
      </div>
      </div>
    )
  }
}

export default translate(RolesList)
{/* <i class="overall-sprite overall-sprite-myeditc"></i> */}
