import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import './Sectors.css';
import { datasave } from './_services/db_services';
import Can from './_components/CanComponent/Can';
import { translate } from './language';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import { PagePermissions } from './_components/CanComponent/PagePermissions';


class Industry extends Component {
  constructor(props) {
    super(props)
    this.state = {
      save: props.t('Save'),
      savevalue: 'true',
      name: '',
      sector: '',
      industries_data: [],
      industries: [],
      result: '',
      name_error: '',
      t: props.t,

    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
  }
  componentDidMount() {
    var url = window.sectors;
    if (this.props.handleSelect !== undefined)
      this.props.handleSelect('/appsettings/createsector')
    datasave.service(url, "GET")
      .then(response => {
        this.setState({
          industries_data: response
        })
      })
    var list = window.sectorslist;
    datasave.service(list, "GET")
      .then(response => {
        this.setState({
          industries: response
        })
      })
    const industry_id = this.props.match.params.id;
    if (this.props.match.params.id) {
      var sectorsedit = window.sectors + '/' + industry_id;
      datasave.service(sectorsedit, "GET")
        .then(response => {
          this.setState({
            name: response[0]['name'],
            sector: response[0]['sector'],
            id: this.props.match.params.id,
            package_details: response,
          })
        })
    }
  }

  handleCancel(event) {
    const { history } = this.props
    if (this.props.match.params.id) {
      history.push('/appsettings/managesectors')
      if (this.props.handleSelect !== undefined)
        this.props.handleSelect('/appsettings/managesectors')

    } else {
      history.push('/appsettings/managesectors')
      if (this.props.handleSelect !== undefined)
        this.props.handleSelect('/appsettings/managesectors')

    }
  }

  handleSubmit(event) {
    event.preventDefault()
    const { history } = this.props
    const details = {
      name: this.state.name,
      sector: this.state.sector,
    }
    var url;
    if (this.props.match.params.id) {
      const industryId = this.props.match.params.id;
      url = window.sectors + '/' + industryId;
      datasave.service(url, "PUT", details)
        .then(response => {
          if (response.name) {
            this.setState({
              name_error: response.name,
            })
          } else {
            history.push('/appsettings/managesectors')
            if (this.props.handleSelect !== undefined)
              this.props.handleSelect('/appsettings/managesectors')
          }
        })
        .catch(error => {
          this.setState({
            error: error.response.errors
          })
        })
    }
    else {
      url = window.sectors;
      datasave.service(url, "POST", details)
        .then(response => {
          if (response.name) {
            this.setState({
              name_error: response.name,
            })
          }
          else {
            history.push('/appsettings/managesectors');
            if (this.props.handleSelect !== undefined)
              this.props.handleSelect('/appsettings/managesectors')

          }
        })
        .catch(error => {
          this.setState({
            error: error.response.errors
          })
        })
    }
  }

  render() {
    const as4_or_site = PagePermissions()
    const { industries, t, name_error } = this.state
    const result = Object.values(industries);
    const disabled = this.props.match.params.id
    if (as4_or_site) {
      return (

        <div className=" row col-md-12">
        <div style={{visibility: 'hidden'}} className="col-md-1"><p>welcome</p></div>
        <div  className='col-md-11' >
          <Can
            perform="E_sector"
            yes={() => (
              <div className='' >
                <div className='col-md-12 mt-5 mb-5 p-0' >
                  <div className='card ' >
                    <div className='card-header' > {t('Create sector')} </div>
                    <div className='card-body' >
                      <form onSubmit={this.handleSubmit} encType="multipart/form-data">
                        <div>
                          <FormGroup>
                            <div className=" row input-overall-sec ">
                              <InputGroup className="">
                                <div className="col-md-4">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Sector')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 ">
                                  <FormControl
                                    placeholder={t("Sector")}
                                    aria-label="Sector"
                                    aria-describedby="basic-addon1"
                                    name='name'
                                    value={this.state.name}
                                    onChange={e => this.setState({ name: e.target.value })}
                                    className="input_sw"
                                  />
                                   <div style={{ color: 'red' }} className="error-block mt-2 ">{name_error}</div>
                                </div>
                              </InputGroup>

                            </div>
                          </FormGroup>
                          <FormGroup>
                            <div className=" row input-overall-sec ">
                              <InputGroup className="">
                                <div className="col-md-4">
                                  <InputGroup.Prepend>
                                    <InputGroup  style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Select main sector')}:</InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                                <div class="col-md-8 ">
                                  <div className="input_sw">
                                    <FormControl as="select" name="sector"
                                      value={this.state.sector}
                                      onChange={e => this.setState({ sector: e.target.value })} >
                                      <option value='0'>{t('Select')}</option>
                                      {this.state.industries_data.map(sector => <option value={sector.id} disabled={disabled === sector.id ? true : null}>{sector.name}</option>)}
                                    </FormControl>
                                  </div>
                                </div>
                              </InputGroup>
                            </div>
                          </FormGroup>
                          <FormGroup>
                          <div style={{ float: 'right' }} className="organisation_list mb-3">
                          <a onClick={this.handleCancel} >{t('Cancel')}</a>
                          &nbsp;&nbsp;&nbsp;
                            <Button style={{fontSize: '14px'}} variant="primary" disabled={!this.state.savevalue} type="submit">{this.state.save}</Button>
                          </div>
                          </FormGroup>
                        </div>
                      </form >
                      <div className='card-body industries'>
                        <reactbootstrap.Table responsive>
                          <thead style={{position: 'sticky',top: '0',backgroundColor: '#fff'}}>
                            <tr>
                              <th>{t('Name of sector')}</th>
                            </tr>
                          </thead>
                          {result.map(details => (
                            <tbody>
                              <tr>
                                <td>
                                  {details.parent.name}
                                </td>
                              </tr>
                              {Object.values(Object.values(details.child)).map(subdetails => (
                                <tr>
                                  <td className='child'>
                                    {subdetails.name}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          ))}
                        </reactbootstrap.Table>
                      </div>
                    </div>
                  </div >
                </div>
              </div >
            )}
            no={() =>
              <AccessDeniedPage />
            }
          />
        </div>
        </div>
      );
    }
    else {
      return (
        <AccessDeniedPage />
      )
    }
  }

}

export default translate(Industry)
