import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import {translate} from '../language';
import { persistor, store } from '../store';
import Pagination from 'react-bootstrap/Pagination'
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import Can from '../_components/CanComponent/Can';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import CheckBox from '../../src/CheckBox';

class ExternalLinks extends Component {
  constructor(props) {
    super(props)

    this.state = {
      name: '',
      edit_img: '',
      available_field_screen: true,
      active_link: true,
      checked: true,
      description: '',
      submitted: false,
      loading: false,
      name_error: '',
      code: '',
      status: 1,
      url: '',
      show_in_popup: true,
      link_details: [],
      t:props.t,
      show :false,
      itemsUsedIn:[],
      icurrentPage :1,
      PerPage :5,
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handlehide = this.handlehide.bind(this);
  }

  handleChange(event) {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
      name_error: '',
      url_error: '',
     });
  }
  componentDidMount() {
    if (this.props.id) {
      const id = this.props.id;
      const url = window.SHOW_LINK + this.props.id;
      datasave.service(url, 'GET', '')

        .then(response => {
          this.setState({
            link_details: response,
            name: response[0]['name'],
            clonename : response[0]['name'],
            description: response[0]['description'],
            clonedescription: response[0]['description'],
            active_link: response[0]['status'],
            url: response[0]['url'],
            cloneurl:response[0]['url'],
            code: response[0]['code'],
            show_in_popup: response[0]['show_in_popup'],
            available_field_screen: response[0]['available_field_screen'],
          })
        });
    }
  }
  componentDidUpdate(prevProps,prevState) {
    let tid  = this.props.id;
    if(tid !== undefined && prevProps.id !== this.props.id  ){
      const id = this.props.id;

      const url = window.SHOW_LINK + this.props.id;
      datasave.service(url, 'GET', '')
        .then(response => {
          this.setState({
            name: response[0]['name'],
            clonename : response[0]['name'],
            description: response[0]['description'],
            clonedescription: response[0]['description'],
            active_link: response[0]['status'],
            url: response[0]['url'],
            cloneurl:response[0]['url'],
            code: response[0]['code'],
            show_in_popup: response[0]['show_in_popup'],
            available_field_screen: response[0]['available_field_screen'],
            name_error: '',
            url_error: ''
          });
          if(response[0].description == null) {
          this.setState({
            name: response[0]['name'],
            clonename : response[0]['name'],
            description: " ",
            clonedescription:" ",
            active_link: response[0]['status'],
            url: response[0]['url'],
            cloneurl:response[0]['url'],
            code: response[0]['code'],
            show_in_popup: response[0]['show_in_popup'],
            available_field_screen: response[0]['available_field_screen'],
          });
        }

      });
    }

    if(tid===undefined && prevProps.id !== this.props.id){

      this.setState({
        name:'',
        description:'',
        code:'',
        url:'',
        name_error: '',
        url_error: ''
      });
    }

  }
  handleCancel(event) {
      this.props.updateComponent(1);
}

  handleSubmit(event) {
    let Userdata = store.getState();
    let person_id = Userdata.UserData.user_details.person_id;
    event.preventDefault();
    this.setState({ submitted: true });
    const { history } = this.props
    const details = {
      name: this.state.name,
      description: this.state.description,
      url: this.state.url,
      code: this.state.code,
      status: this.state.active_link,
      show_in_popup: this.state.show_in_popup,
      available_field_screen: this.state.available_field_screen,
      modifyname : (this.state.name === this.state.clonename) ? false:true,
      modifydescription :(this.state.clonedescription === this.state.description) ? false:true,
      pid : person_id,
      clonename : this.state.clonename,
      clonedescription:this.state.clonedescription

    }

    if (this.props.id) {

          const {name,clonename,clonedescription,description,url,cloneurl}= this.state
          {clonename === name&&description ===clonedescription&&url==cloneurl && this.props.updateComponent(1)}
      datasave.service(window.GetUsedInDocs_links+this.props.id, 'GET',)
      .then(response => {
        if(response.length === 0){
          const url = window.SHOW_LINK + this.props.id;
          datasave.service(url, 'PUT', details)
            .then(response => {
              if (response.name || response.url) {
                this.setState({
                  name_error: response.name,
                  url_error: response.url,
                  show:false
                })
              }
              else {
                this.props.created(this.state.name)
                this.props.updateComponent(1);
              }
            })

        }else{
        this.setState({
          show: true,itemsUsedIn:response
         })
        }
      })


      // const id = this.props.id;
      // const url = window.SHOW_LINK + this.props.id;
      // datasave.service(url, 'PUT', details)
      //   .then(response => {
      //     if (response.name || response.url) {
      //       this.setState({
      //         name_error: response.name,
      //         url_error: response.url
      //       })
      //     }
      //     else {
      //       this.props.updateComponent(1);
      //     }
      //   })
    }

    else {
      datasave.service(window.INSERT_LINK, 'POST', details)
        .then(response => {
          if (response.name || response.url) {
            this.setState({
              name_error: response.name,
              url_error: response.url
            })
          }
          else {
            this.props.created(this.state.name)
            this.props.updateComponent(1)
          }
        })
    }
  }

  handleExport(){
    const eid = this.props.id;
    var url =window.EXPORT_HYPERLINK_DOCS;
    const details = {
      oldname:this.state.clonename,
      name:this.state.name,
      olddescription:this.state.clonedescription,
      description:this.state.description,
      oldurl:this.state.cloneurl,
      url:this.state.url,
      id:eid
    }
    datasave.service(url,'PUT',details).then(response =>{
      window.open(response);
      window.close();
    })

  }
  handlehide(){
    this.setState({
      show:false
    })
  }

  handlePageClick(event){
    this.setState({
      icurrentPage: Number(event.target.id)
    });
  }

  handlePopOk(){
    let Userdata = store.getState();
    let person_id = Userdata.UserData.user_details.person_id;
    const details = {
      name: this.state.name,
      description: this.state.description,
      url: this.state.url,
      code: this.state.code,
      status: this.state.active_link,
      show_in_popup: this.state.show_in_popup,
      available_field_screen: this.state.available_field_screen,
      modifyname : (this.state.name === this.state.clonename) ? false:true,
      modifydescription :(this.state.clonedescription === this.state.description) ? false:true,
      pid : person_id,
      clonename : this.state.clonename,
      clonedescription:this.state.clonedescription
    }
    const id = this.props.id;
      const url = window.SHOW_LINK + this.props.id;
      datasave.service(url, 'PUT', details)
        .then(response => {
          if (response.name || response.url) {
            this.setState({
              name_error: response.name,
              url_error: response.url,
              show:false,
            })
          }
          else {
            this.props.created(this.state.name)
            this.props.updateComponent(1);
          }
        })
  }
  render() {
    const { name,t, description, submitted, loading, available_field_screen, active_link,
              name_error, url_error, show_in_popup,icurrentPage,PerPage,itemsUsedIn,clonename,
            cloneurl,url,clonedescription } = this.state;

    const indexOfLastitem = icurrentPage * PerPage;
    const indexOfFirstitem = indexOfLastitem - PerPage;
    const currentitems = itemsUsedIn.slice(indexOfFirstitem, indexOfLastitem);
    const data = currentitems.map(item => {
        return (
          <tr>
        <td>{item.d_code}</td>
       <td>{item.d_name}</td>
       {/* <td>{item.d_version}</td> */}
       <td>{item.f_name}</td>
       <td>{item.m_name}</td>
       </tr>
        )
    });

    const pageNumbers = [];
    if(itemsUsedIn.length > 5) {
        for (let i = 1; i <= Math.ceil(itemsUsedIn.length / PerPage); i++) {
        pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === icurrentPage}>
            {i}
        </Pagination.Item>);
    }
  }
    const popup = (
      <reactbootstrap.Modal
        size="lg"
        show={this.state.show}
        onHide={this.handlehide}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title">
        <reactbootstrap.Modal.Header closeButton>
              <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
              </reactbootstrap.Modal.Title>
              <reactbootstrap.Modal.Body>
              <reactbootstrap.Table striped bordered hover size="sm">
                <thead>
                <tr>
                  <th>{t('Document code')}</th>
                  <th>{t('Document name')}</th>
                  {/* <th>{t('Document version')}</th> */}
                  <th>{t('Folder name')}</th>
                  <th>{t('Manual name')}</th>
                </tr>
              </thead>
                {data}
              </reactbootstrap.Table>
              <Pagination   size="sm">{pageNumbers}</Pagination>
              <reactbootstrap.Table striped bordered hover size="sm">
              <thead>
                {clonename!== name &&
                  <tr>
                  <th className ="taghead" style ={{width: '30%'}}>{t('Previous name')}</th>
                  <td>{clonename}</td>
                  </tr>
                }
                  {clonename!== name &&
                  <tr>
                  <th className ="taghead" style ={{width: '30%'}}>{t('Updated name')}</th>
                  <td>{name}</td>
                  </tr>}
                  {cloneurl !== url &&
                  <tr>
                  <th className ="taghead" style ={{width: '30%'}}>{t('Previous URL')}</th>
                  <td>{cloneurl}</td>
                  </tr>}
                  {cloneurl !== url &&
                  <tr>
                  <th className ="taghead" style ={{width: '30%'}}>{t('Updated URL')}</th>
                  <td>{url}</td>
                  </tr>
                  }
                  {clonedescription !== description &&
                  <tr>
                  <th className ="taghead" style ={{width: '30%'}}>{t('Previous description')}</th>
                  <td>{clonedescription}</td>
                  </tr>
                  }{clonedescription !== description &&
                  <tr>
                  <th className ="taghead" style ={{width: '30%'}}>{t('Updated description')}</th>
                  <td>{description}</td>
                  </tr>
                  }
                </thead>
                </reactbootstrap.Table>
              </reactbootstrap.Modal.Body>
            </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={() => this.handlehide()}>{t('Cancel')}</reactbootstrap.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
        <reactbootstrap.Button onClick={() => this.handlePopOk()}>{t('Edit')}</reactbootstrap.Button>
        &nbsp;&nbsp; &nbsp;&nbsp;
        <reactbootstrap.Button onClick={() => this.handleExport()}>{t('Export')}</reactbootstrap.Button>


        </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
    );

    return (
      <Can
        perform = "E_hyperlink"
        yes = {() => (
        <div className='container' >
          <div className='row justify-content-center' >
            <div className='col-md-12' >
              <div className='card' >
                <div className='card-header' > {t('Create external link')} </div>
                <div className='card-body' >
                  <reactbootstrap.Container className="p-1">
                    <reactbootstrap.Form onSubmit={this.handleSubmit}>
                      <reactbootstrap.FormGroup>
                        <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
                        <div className=" input-overall-sec ">
                          <reactbootstrap.InputGroup className="">
                          <div className="col-md-4">
                            <reactbootstrap.InputGroup.Prepend>
                              <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Name')}:<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                            </reactbootstrap.InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                            <reactbootstrap.FormControl
                              name="name"
                              autoFocus
                              placeholder={t("External link")}
                              aria-label="External link"
                              aria-describedby="basic-addon1"
                              value={name}
                              onChange={this.handleChange}
                              className="input_sw "
                            />
                             <div style={{ color: 'red' }} className="error-block mt-2">{name_error}</div>
                            </div>
                          </reactbootstrap.InputGroup>

                        </div>
                        </div>
                      </reactbootstrap.FormGroup>
                      <reactbootstrap.FormGroup>
                      <div className=" input-overall-sec ">
                        <reactbootstrap.InputGroup className="">
                        <div className="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('URL')}:<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                          </div>
                          <div class="col-md-8 input-padd">
                          <reactbootstrap.FormControl
                            placeholder={t("URL")}
                            aria-label="externalcode"
                            aria-describedby="basic-addon1"
                            value={this.state.url}
                            onChange={e => this.setState({ url: e.target.value })}
                            className="input_sw "
                          />
                          <div style={{ color: 'red'  }} className="error-block mt-2">{url_error}</div>
                          </div>
                        </reactbootstrap.InputGroup>

                     </div>
                      </reactbootstrap.FormGroup>
                      <reactbootstrap.FormGroup>
                      <div className=" input-overall-sec ">
                        <reactbootstrap.InputGroup className="">
                        {/* <div className="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Code')}</reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                          </div> */}
                          {/* <div class="col-md-8 input-padd">
                          <reactbootstrap.FormControl
                            placeholder="Code"
                            aria-label="externalcode"
                            aria-describedby="basic-addon1"
                            value={this.state.code}
                            onChange={e => this.setState({ code: e.target.value })}
                            className="input_sw "
                          />
                          </div> */}
                        </reactbootstrap.InputGroup>
                        </div>
                      </reactbootstrap.FormGroup>
                      <reactbootstrap.FormGroup>
                      <div className=" input-overall-sec ">
                      <reactbootstrap.InputGroup className="">
                      <div className="col-md-4">
                        <reactbootstrap.InputGroup.Prepend>
                          <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Description')}:</reactbootstrap.InputGroup>
                        </reactbootstrap.InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                        <reactbootstrap.FormControl
                          style={{ height: '200px' }}
                          as="textarea" rows="3"
                          name="description"
                          placeholder={this.props.placeholder}
                          value={description}
                          id="description"
                          onChange={this.handleChange}
                          className="input_sw "
                        />
                        </div>
                        </reactbootstrap.InputGroup>
                        </div>
                      </reactbootstrap.FormGroup>
                      <div className="ml-4 mt-2">
                      <reactbootstrap.Form.Group>
                      <CheckBox
                            name={t("Available in master data")}
                            tick={available_field_screen}
                            style={{ paddingLeft: '0px' }}
                            onCheck={e => this.setState({ available_field_screen: !available_field_screen })}
                            value={'require'}
                        />


                      </reactbootstrap.Form.Group>

                      <reactbootstrap.Form.Group>

                         <CheckBox
                            name={t("Show in popup")}
                            tick={show_in_popup}
                            style={{ paddingLeft: '0px' }}
                            onCheck={e => this.setState({ show_in_popup: !show_in_popup })}
                            value={'Show in popup'}
                        />
                      </reactbootstrap.Form.Group>
                      </div>
                      <FormGroup>
                      <div style={{float: 'right'}} className="organisation_list mt-3">
                        <a  onClick={this.handleCancel} >{t('Cancel')}</a>
                        &nbsp;&nbsp;&nbsp;
                          <reactbootstrap.Button style={{fontSize: '14px'}} type="submit" className="btn btn-primary" disabled={loading}>{t('Save')}</reactbootstrap.Button>
                         {popup}
                        </div>
                        </FormGroup>
                    </reactbootstrap.Form>
                  </reactbootstrap.Container>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      no={() =>
            <AccessDeniedPage />
        }
    />
    );
  }
}
export default translate(ExternalLinks);
