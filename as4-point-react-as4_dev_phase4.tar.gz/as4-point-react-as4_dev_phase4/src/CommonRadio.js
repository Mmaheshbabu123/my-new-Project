import React, { Component } from 'react';
import { t } from './language';
import * as reactbootstrap from 'react-bootstrap';

class CommonRadio extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {

        return (
            <div>

                <reactbootstrap.Form.Check
                    type={'checkbox'}
                    id={this.props.id1}
                    label={this.props.label1}
                    checked={this.props.check1}
                    onChange={this.props.handleCheck}
                />
                <reactbootstrap.Form.Check
                    type={'checkbox'}
                    id={this.props.id2}
                    label={this.props.label2}
                    checked={this.props.check2}
                    onChange={this.props.handleCheck}
                />
                <reactbootstrap.Form.Check
                    type={'checkbox'}
                    id={this.props.id3}
                    label={this.props.label3}
                    checked={this.props.check3}
                    onChange={this.props.handleCheck}
                />
            </div>
        )
    }

}
export default CommonRadio;