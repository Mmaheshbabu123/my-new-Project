import React, { Component } from 'react'
import axios from 'axios'
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import {translate} from './language';
const base64 = require('base-64');

class Resetpassword extends Component {

  constructor(props) {
    super(props)
    this.state = {
      token: '',
      email: '',
      newpassword: '',
      confirmpassword: '',
      showError: '',
      messageFromServer: '',
      reset: '',
      t:props.t,
      newpasswordError : '',
      confirmPasswordError : '',
      submit : false,
    }

    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    const encryptedToken = base64.encode(this.props.match.params.token);
    this.setState({
      token: encryptedToken,
    })
    axios.get(window.backendURL + `/api/user/resetpassword/${encryptedToken}`, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
      .then(response => {

        if (response.data.successmsg === 'link expired') {
          this.setState({
            showError: response.data.successmsg,
            messageFromServer: '',
          });
        } else if (response.data.successmsg === 'token not found') {
          this.setState({
            showError: response.data.successmsg,
            messageFromServer: '',
          });
        } else if (response.data.successmsg === 'change password') {

          const reset = response.data.successmsg;
          const email = base64.decode(response.data.email);
          this.setState({
            reset: reset,
            email: email,
          });
        }
      })
  }

  handleChange(event) {
    const {name} = event.target
    const { t } = this.state;
    let pwdError = t('Password should be minimum length of 10 characters, atleast one upper case, one special character (#, ?, !, @, $, %, ^, &, *, -) and one numeric')
    let pwd = event.target.value;

    let newpasswordTest = true;
    let confirmpasswordTest = true;
    if(name === 'newpassword') {
      if (event.target.value.length === pwd.trim().length) {
        const reg = new RegExp("^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{10,}$");
        newpasswordTest = reg.test(event.target.value);
      } else {
        this.setState({
          newpasswordError: t('Space is not allowed'),
        })
        return false;
      }

      // if(event.target.value.match(/\s/g)) {
      //     newpasswordTest = false;
      // }
    }
    if(name === 'confirmpassword') {
      if (event.target.value.length === pwd.trim().length) {
        const reg = new RegExp("^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{10,}$");
        confirmpasswordTest = reg.test(event.target.value);
      } else {
        this.setState({
          confirmPasswordError: t('Space is not allowed'),
        })
        return false;
      }

      // if(event.target.value.match(/\s/g)) {
      //     confirmpasswordTest = false;
      // }
    }

    this.setState({
      [name]: event.target.value,
      newpasswordError :  newpasswordTest ? '' : pwdError,
      confirmPasswordError : confirmpasswordTest ? '' : pwdError,
    });
  };

  resetPassword = (event) => {
    event.preventDefault();
    this.setState({
      submit : true,
    })
    if (this.state.newpassword === this.state.confirmpassword && this.state.newpasswordError === '' && this.state.confirmPasswordError === '') {
      const encryptedPassword = base64.encode(this.state.newpassword);
      const encryptedEmail = base64.encode(this.state.email);

      axios.get(window.backendURL + `/api/user/updatepassword/${encryptedEmail}/${encryptedPassword}`, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
        .then(response => {
          if (response.data === 'Mail has been sent') {
            this.setState({
              showError: '',
              messageFromServer: response.data,
            });
            const { history } = this.props;
            history.push('/loginscreen');
          } else if (response.data === 'mail not sent') {
            this.setState({
              showError: response.data,
              messageFromServer: '',
            });
          }
        })
    } else {
      this.setState({
        showError: 'password not matched',
        messageFromServer: '',
      });
    }
  }

  handleKeyPress = event => {
    if (event.key == 'Enter') {
      this.resetPassword(event);
    }
  }

  render() {
    const { messageFromServer,t, showError , newpasswordError, confirmPasswordError} = this.state;

    if (this.state.reset === 'change password') {
      return (
        <div className="container"  onKeyPress={e => this.handleKeyPress(e)}>
          <div className="row justify-content-center">
            <div className="col-md-8 mt-5">
              <div className="card">
                <div style={{textAlign: 'center'}} className="card-header">{t('Reset password')}</div>
                <Container className="p-5">
                  <Form onSubmit={this.resetPassword} >

                    <FormGroup>
                      <div class="col-md-12 row">
                        <div className="col-md-4">
                      <Label>{t('New password')}<span style={{ color: 'red' }}>  *</span></Label>
                    </div>
                    <div className="col-md-8">
                      <Input
                        id="newpassword"
                        type="password"
                        name="newpassword"
                        placeholder="new password"
                        value={this.state.newpassword}
                        onChange={this.handleChange}
                        autoComplete="off"
                      />
                      {this.state.submit && this.state.newpassword === '' &&
                        <p style={{ color: 'red' }} className="error-block">{t('New password field is required')}</p>
                      }
                      {newpasswordError &&
                        <div style={{ color: 'red' }} className="error-block  mt-2">{newpasswordError}</div>
                      }
                    </div>
                    </div>
                    </FormGroup>
                    <FormGroup>
                      <div class="col-md-12 row">
                          <div className="col-md-4">
                      <Label>{t('Confirm password')}<span style={{ color: 'red' }}>  *</span></Label>
                    </div>
                      <div className="col-md-8">
                      <Input
                        id="confirmpassword"
                        type="password"
                        name="confirmpassword"
                        placeholder="confirm password"
                        value={this.state.confirmpassword}
                        onChange={this.handleChange}
                        autoComplete="off"
                      />
                      {this.state.submit && this.state.confirmpassword === '' &&
                        <p style={{ color: 'red' }} className="error-block">{t('Confirm password field is required')}</p>
                      }
                      {confirmPasswordError &&
                        <div style={{ color: 'red' }} className="error-block  mt-2">{confirmPasswordError}</div>
                      }
                    </div>
                    </div>
                    </FormGroup>
                    <FormGroup>
                      <div style={{ textAlign: 'right'}} className="col-lg-12 pr-5">
                        <Button className="btn btn-primary" type="submit" color="primary">{t('Reset password')}</Button>
                      </div>
                    </FormGroup>
                  </Form>
                </Container>
              </div>
            </div>
          </div>
          {messageFromServer === 'Mail has been sent' && (
            <div>
              <p>{"Your account password was updated successfully. Reset password mail has been sent sucessfully!"}</p>
                <p>{t('Login with your new password')}</p>
           </div>
          )}
          {showError === 'password not matched' && (
            <div className={'alert alert-danger'}>
              <p>
                {t('Password and confirm password both are not same.')}
                  </p>
            </div>
          )}
          {showError === 'mail not sent' && (
            <div className={'alert alert-danger'}>
              <p>{t('Your password has been updated but update mail was not sent!')}</p>
            </div>
          )}
        </div>
      );
    } else {
      return (
        <div className="container mt-5">
          {showError === 'token not found' && (
            <div className={'alert alert-danger'}>
              <p>
                {t('Something went wrong with this link.Request again for resetpassword.')}
                  </p>
            </div>
          )}
          {showError === 'link expired' && (
            <div className={'alert alert-danger'}>
              <p style={{textAlign: 'center'}}>{t('This link has been expired')}</p>
            </div>
          )}
        </div>
      );
    }
  }
}
export default translate(Resetpassword)
