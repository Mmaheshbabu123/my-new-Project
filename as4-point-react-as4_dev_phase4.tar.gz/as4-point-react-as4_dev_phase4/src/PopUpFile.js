import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../src/_services/db_services';
import { connect } from "react-redux";
import { translate } from "../src/language";
import CommonRadio from '../src/CommonRadio'
import FileUpload from '../src/_components/FileUpload/FileUpload';
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from './store';
import TemplatePopUp from './Webforms/WebReports/TemplatePopUp';
import DownloadPopup from './_components/ManualComponent/DownloadPopup';

class PopUpFile extends Component {
    constructor(props) {
        super(props)
        this.state = {
            save: props.t('Save'),
            switch_case: true,
            credentials: this.props.credentials,
            use_existing_file_name: props.t('Choose file'),
            savevalue: 'true',
            loading: false,
            error: '',
            description: '',
            status: 1,
            submitted: false,
            memo_data: [],
            id: '',
            showpopup: true,
            uid: '',
            use_existing_file: '',
            use_existing_file_name: props.t('Choose file'),
            use_existing_file_edit_img: '',
            uid: '',
            file_id: '',
            file_path: '',
            sucess: '',
            lCBoth: [],
            1: false,
            2: false,
            3: false,
            curd: this.props.curd,
            t: props.t,
            download :false,
            PopUp : false,
            show: false,
            doc_id: this.props.doc_id

        }
        this.updateImageUpload = this.updateImageUpload.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.cancelPopup = this.cancelPopup.bind(this);
        this.showPopup = this.showPopup.bind(this);
        this.handleCheck = this.handleCheck.bind(this);
        this.showDownloadPopup = this.showDownloadPopup.bind(this);
        this.downloadPath = this.downloadPath.bind(this);
        this.docType = this.docType.bind(this);
        this.handleClose = this.handleClose.bind(this);
        //alert('no');

    }
    updateImageUpload(response) {
        this.setState({
            sucess: window.FILE_UPLOAD_SUCCESS,
            edit_img: '',
            file_id: response.data.file_id[0],
            file_path: response.data.filepath
        });

    }
    handleCheck(event) {

        var id = event.target.id;
        var data = this.state.lCBoth;
        if (event.target.checked) {

            var label = event.target.label;

            if (data.length > 0) {
                var prevId = data[0];
                data = [];
                data.push(id);
                this.setState({
                    [prevId]: false,
                    [id]: true,
                    lCBoth: data,
                })

            } else {

                data.push(id);
                this.handleState(id, true, "lCBoth", data);
            }


        } else {
            data = [];
            this.handleState(id, false, "lCBoth", data);
        }


    }

    handleState(name1, value1, name2, value2) {
        this.setState({
            [name1]: value1,
            [name2]: value2,
        })
    }

    handleSubmit(event) {
        const { history } = this.props;
        const {t} = this.state;
        event.preventDefault()
        if(this.state.description.length<1){
          this.setState({
              error: t('Comment is required'),
          })
          return false;
        }
        this.setState({ submitted: true });
        this.setState({
            savevalue: '',
            save: t('Please wait')
        })


        let description = this.state.description.toString().replace(/\s+/g, ' ').trim();
        const details4 = {
            doc_id: this.props.doc_id,
            person_id: this.props.UserData.user_details.person_id,
            comment: description,
            doc_status: this.props.status_id,
            r_id: this.props.todoId,
            comment_type: this.props.comment_type,
            option_type: this.state.lCBoth.length ? this.state.lCBoth[0] : 0,
            file_id: this.state.file_id,
            file_path: this.state.file_path,

        }
        this.handleService(window.COMMENT_STORE, "POST", details4);




        if (description) {

            if (this.state.curd) {
                var details1 = {
                    doc_id: this.props.doc_id,
                    doc_status: this.props.status_id,
                    r_id: this.props.todoId,
                    read_or_not: 3,
                    r_u_type: 1,
                }

                this.handleService(window.STORECRUCDETIALS, 'POST', details1);



                var details2 = {
                    id: this.props.todoId,
                    read_or_not: 2,
                }
                this.handleService(window.READUPDATE, "POST", details2);
            } else {
                const details4 = {
                    id: this.props.todoId,
                    doc_id: this.props.doc_id,
                }
                this.handleService(window.UPDATESYSTEM, "POST", details4);

            }



            OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });

            // alert('Submited successfully');
            this.props.history.push(localStorage.getItem('prevLocation'));

        } else {
            this.setState({
                error: t('Comment is required'),
            })

        }



    }
    // updateCycles(doc_id, doc_status, person_id) {
    //     const { history } = this.props;
    //     var url = window.GET_CYCLE + '/' + doc_id + '/' + doc_status + '/' + person_id;
    //     datasave.service(url, "POST")
    //         .then(result => {
    //             if (result) {

    //                 //  history.push('/workarea');

    //             }

    //         });
    // }
    handleCancel(event) {
        this.cancelPopup();
    }
    cancelPopup() {
        this.setState({ showpopup: false });
        //   {this.state.switch_case &&
        //   <FourthCycleComponent status_id = {this.props.status_id} doc_id = {this.props.doc_id} status_name = {this.props.status_name}/>}
        // }
    }
    showPopup() {
        this.setState({ showpopup: true });
    }

    handleService(url, request_type, data) {
        datasave.service(url, request_type, data)
            .then(response => {
            });
    }
    showDownloadPopup() {
       this.handleDownload();
     }

     hideDownloadPopup() {
       this.setState({
         showDownloadPopup: false,
       })
     }
     downloadPath(languageId,templateId){
       datasave.service(window.DOWNLOAD_TEMPLATE + '/' + this.state.doc_id + '/' + templateId + '/' + this.props.refid + '/' + languageId + '/' +  this.state.doc_id,'GET')
        .then(response => {
             this.setState({
                 typeUrl : response,
             });
        });
     }
    docType(doc) {
      let res = this.state.typeUrl;
      let typeDoc;
        if (res !== undefined && res.status === 200 && doc !== '') {
              if(doc === 'p'){
                   typeDoc = res.urlPdf;
              }
              else{
                 typeDoc = res.urlDoc;
              }
                   var a = document.createElement("a");
                   a.href = typeDoc;
                   a.download = res.name;
                   a.target = '_blank';
                   document.body.appendChild(a);
                   a.click();
                   a.remove();
              }
              else {
                  OCAlert.alertError('Unable to process your request', { timeOut: window.TIMEOUTNOTIFICATION1 });
              }
    }
    handleClose(e) {
       this.setState({
           PopUp: false,
           show: false,
       });
    }
    handleDownload() {
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        let person_name = Userdata.UserData.user_details.user_name;
        let lang = 'Dutch';
        if (localStorage.getItem('langId') !== null) {
          lang = localStorage.getItem('langId');
        }
        if(!this.props.webform){
             this.setState({
                showDownloadPopup: true,
             })
           } else {
             datasave.service(window.DOWNLOAD_TEMPLATE_WEBFORM_ID + '/' + this.state.doc_id,'GET').then(response => {
                 this.setState({
                    PopUp: true,
                    // show: true,
                    templates: response,
                    download:true
                 });
             });
           }
    }
    dowloadDoc(e) {
        e.preventDefault();
        let id = this.props.doc_id;
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        let person_name = Userdata.UserData.user_details.user_name;
        datasave.service(window.DOC_PREVIEW + '/4' + '/' + id + '/general/Dutch?username=' + person_name + '&downloadtype=' + 1, 'GET')
            .then(response => {
                if (response.status === 200) {
                    var a = document.createElement("a");
                    a.href = response.url;
                    a.download = response.name;
                    a.target = '_blank';
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                } else {
                    OCAlert.alertError(response.message, { timeOut: window.TIMEOUTNOTIFICATION1 });
                }
            });
    }
    render() {


        const { description, loading, updateImageUpload, use_existing_file_edit_img, memo_data, error, id,t } = this.state;
        const download = <div className='row md-8'>
          <TemplatePopUp
             show={this.state.PopUp}
             handleClose = {this.handleClose.bind(this)}
             titleName = {t('Download Template')}
             templates = {this.state.templates}
             downloadPath = {this.downloadPath.bind(this)}
             docType = {this.docType.bind(this)}
           />
       </div>
        return (

            <reactbootstrap.Modal show={this.state.showpopup} onHide={this.cancelPopup}>
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title>{this.props.title}</reactbootstrap.Modal.Title>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Container className="p-5">
                    <reactbootstrap.Form onSubmit={this.handleSubmit}>
                        <reactbootstrap.Modal.Body>
                            <reactbootstrap.FormGroup>
                                <reactbootstrap.FormControl
                                    style={{ height: '20<reactbootstrap.Modal show={this.state.showpopup} 0px' }}
                                    as="textarea" rows="3"
                                    placeholder={this.props.placeholder}
                                    value={this.state.description}
                                    onChange={e => this.setState({ description: e.target.value ,error:''})}
                                />
                            </reactbootstrap.FormGroup>
                            <reactbootstrap.FormLabel style={{ color: 'red' }} className="error-block">{error}</reactbootstrap.FormLabel>
                            <reactbootstrap.FormGroup md="4">
                                <reactbootstrap.Button onClick={(e) => this.showDownloadPopup(e)}>
                                    {t('Download')}
                                </reactbootstrap.Button>
                            </reactbootstrap.FormGroup>
                            <reactbootstrap.FormGroup md="4" controlId="validationCustom02">
                                <div className="input-group ">
                                    <FileUpload type = {5} updateImageUpload={updateImageUpload} file_name={this.state.use_existing_file_name} {...this} />
                                </div>
                                <div>
                                    <a href={this.state.file_path} target="_blank" >{this.state.use_existing_file_edit_img}</a>
                                    <span style={{ color: "green" }}>{this.state.sucess}</span>
                                </div>
                                {/* {(details.doc_type_id == 4 || details.doc_type_id == 5) && <div style={{ color: 'red' }} className="error-block">{'Upload file is required'}</div>} */}
                            </reactbootstrap.FormGroup>
                            {/* <CommonRadio handleCheck={this.handleCheck} label1={'Layout/Spellings'} id1={1} check1={this.state[1]} label2={'Content'} id2={2} check2={this.state[2]} label3={'Both'} id3={3} check3={this.state[3]}></CommonRadio> */}
                        </reactbootstrap.Modal.Body>

                        <reactbootstrap.Modal.Footer style={{ borderTop: '0px' }}>
                            <reactbootstrap.Modal.Footer style={{ borderTop: '0px' }}></reactbootstrap.Modal.Footer>
                            <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.handleCancel} >{t('Cancel')}</reactbootstrap.Button>

                            <reactbootstrap.Button type="submit" disabled={loading} color="primary">{this.props.current_status}</reactbootstrap.Button>
                            {loading &&
                                <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                            }
                            &nbsp;&nbsp;&nbsp;
                        </reactbootstrap.Modal.Footer>
                    </reactbootstrap.Form>
                </reactbootstrap.Container>
                {this.state.showDownloadPopup &&
                    <DownloadPopup doc_id={this.state.doc_id} showDownloadPopup={this.state.showDownloadPopup} downloadType = {1} hideDownloadPopup={this.hideDownloadPopup.bind(this)}/>
                }
                {this.state.download &&download}
            </reactbootstrap.Modal >
        );
    }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(PopUpFile));
