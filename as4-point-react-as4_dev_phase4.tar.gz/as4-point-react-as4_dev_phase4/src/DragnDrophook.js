import React, { Component,useState, useEffect,useRef  } from 'react'
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd'
import * as reactbootstarp from 'react-bootstrap'
import SearchInput, { createFilter } from 'react-search-input'
import { datasave } from './_services/db_services';
import CheckBox from './CheckBox';
import TextField from '../src/_components/TextField'
import PersonImg from './images/personc.png';
import TaskPopUp from '../src/TaskPopUp.js'
import JobImg from './images/jobc.png';
import DepartmentImg from './images/departmentsc.png';
import GroupImg from './images/groupc.png';
import DeleteImg from './images/delete1.png';
import approvalsearch from './images/approval-search.png';
import './DragnDrop.css';
import wname from './wname.png';
import wview from './wview.png';
import wverify from './wverify.png';
import wabbrv from './abrv-w.png';
// import wselectall from '../src/selectall-w.png';
import wselectall from './selectall-w.png';
import wremove from './wremove.png';
import winitiate from './winitiate.png';
import wcrud from './wcrud.png';
import wauthorise from './wauthorise.png';
import $ from 'jquery';
import { translate } from './language';


/**
 * Moves an item from one list to another list.
 */
const move = (source, destination, droppableSource, droppableDestination, draggableId) => {

    const sourceClone = Array.from(source);
    const destClone = Array.from(destination);
    const [removed] = sourceClone.filter(items => items.id === draggableId);
    destClone.splice(droppableDestination.index, 0, removed);
    const result = {};
    result[droppableSource.droppableId] = sourceClone.filter(items => items.id !== draggableId);
    result[droppableDestination.droppableId] = destClone;
    result['latestDropped'] = removed;
    result['type'] = (droppableDestination.droppableId === 'droppable') ? 'remove' : 'add';
    return result;
};
const grid = 8;
/*const getItemStyle = (isDragging, draggableStyle) => ({
    // some basic styles to make the items look a bit nicer
    userSelect: 'none',
    padding: grid * 2,
    margin: `0 0 ${grid}px 0`,

    // change background colour if dragging
    background: isDragging ? 'lightgreen' : 'grey',

    // styles we need to apply on draggables
    ...draggableStyle
});*/

const getListStyle = isDraggingOver => ({
    background: isDraggingOver ? 'lightblue' : '#fff',
    padding: grid,
    //  width: '62%',
});

const getFlexStyle = ({
    display: 'flex',
    backgroundColor: '#fff',
});

const imageStyle = ({
    width: 20,
    cursor: "default",
});
const TextCurser = ({
    cursor: "default",
});

const textinline = ({
    display: '-webkit-inline-flex',
});

const checkApproval = ({

    width: 18,
    padding: 5,
    borderColor: '#EC661C',
    borderWidth: 1,
    height: 18

});
const checkApprovalChecked = ({
    backgroundColor: '#EC661C',
    backgroundImage: 'url("./images/tick.png")',
    backgroundRepeat: 'no-repeat',
    backgroundOrigin: 'content-box'
});
/*const tooltipStyle = ({
    height: 150,
    width: 200,
    overflow: 'auto'
});*/

const DragnDrop = (props) => {
const prevProps =  usePrevious(props);
const t = props.t;
const filteredNames = [];
  const [state, setState] = useState({
            t: props.t,
            KEYS_TO_FILTERS: window.search_fields,
            items: (props.tasks !== undefined)?props.tasks:[],
            selected: (props.selected !== undefined)?props.selected:[],
            types: (props.types !== undefined)?props.types:[],
            searchData: [],
            searchTerm: [],
            searchType: '',
            result_obj:[],
            type: (props.type !== undefined)?props.type:'',
            html: window.HTML_OBJECT,
            html_right: window.HTML_RIGHT,
            updated: 1,
            persons: [],
            curently_hovered_item: [],
            show: false,
            showPopup :false,
            isTooltipActive: false,
            parent: "tooltip",

        })

        // useEffect(() => {
        //         if (props.items !== undefined) {
        //             setState({
        //                   ...state,
        //                 types: props.types,
        //                 items: props.items,
        //                 selected: props.selected,
        //                 type: props.type,
        //             });
        //         }
        //
        //     },[]);

            // useEffect(() => {
            //      if(prevProps !== undefined && prevState !== undefined) {
            //       if (prevState.items !== props.tasks) {
            //           setState({
            //             ...state,
            //               items: props.tasks,
            //           })
            //       }
            //      }
            // },[prevProps,prevState]);

    const handleClicktr = (resultObj) => {
       let allowOrNot = (props.details.doc_status_id === 22 && resultObj.category === 'spaces') ? (props.details.diable_ExpirationPeriod) : (props.details.disableFields || props.disable_based_on_right||props.approvalcycle_disabled||props.extra_tab_disabled||props.default_tab_disabled);
        if (allowOrNot) {
            return;
        }
        var selected = state.selected;
        var remove = selected.filter(item => (item.name !== resultObj.name && item.id !== resultObj.id));
        const result = {};
        result['latestDropped'] = resultObj;
        result['type'] = 'remove';
        setState(prevState => ({
             ...state,
            items: [...prevState.items, resultObj],
            selected: remove,
        }))
        props.updateSelectedChild(result.latestDropped, result, props.tab, props.notify_id);
    }
    const handleClicktrTask = (resultObj,task_status = 0,show_comment = true) =>{
         let allowOrNot = (props.details.doc_status_id === 22 && resultObj.category === 'spaces') ? (props.details.diable_ExpirationPeriod) : (props.details.disableFields || props.disable_based_on_right||props.approvalcycle_disabled||props.extra_tab_disabled||props.default_tab_disabled);
         if (allowOrNot) {
             return;
         }
        // if (props.details.disableFields ||props.details.exp_his_disabled|| props.
        //  || props.approvalcycle_disabled || props.extra_tab_disabled||props.default_tab_disabled) {
        //     return;
        // }
        //if(props.details.action === 'edit'){
        if(props.remove_type === true && props.details.action === 'edit'){
          if(task_status == 0){
          setState({
            ...state,
            showPopup :show_comment,
            result_obj:resultObj,
          })
        }
        else{
          setState({
            ...state,
            showPopup :show_comment,
            result_obj:resultObj,

          })
          handleClicktr(resultObj);
        }
        }
        else{
          handleClicktr(resultObj);
        }

    }

    const prevState = usePrevious(state);

    const updateSelectAll = () => {
      $('tr').find('#verify').each(function(){
        $(this).appendTo($(this).parent().find('#9'));
        // $(this).parent().parent().find('#verify').remove();
      })
      $('tr').find('#authorise').each(function(){
        $(this).appendTo($(this).parent().find('#10'));
        // $(this).parent().parent().find('#authorise').remove();
      })
    }

    /**
     * A semi-generic way to handle multiple lists. Matches
     * the IDs of the droppable container to the names of the
     * source arrays stored in the state.
     */
    const id2List = {
        droppable: 'items',
        droppable2: 'selected'
    };

  const  handleDragSelectedChange = (result) => {
    Promise.resolve()
     .then(() => { setState({
       ...state,
         items: result.droppable,
         selected: result.droppable2,})})
     .then(() => props.updateSelectedChild(result.latestDropped, result, props.tab, props.notify_id))
    // console.log(result)
    //     setState(
    //       ...state,
    //         items: result.droppable,
    //         selected: result.droppable2,
    //      () => props.updateSelectedChild(result.latestDropped, result, props.tab, props.notify_id),
    //     );
    }
  const  getList = (id) => state[id2List[id]];

  const  onDragEnd = (resultObj) => {
        const { source, destination, draggableId } = resultObj;
        // dropped outside the list
        if (!destination) {
            return;
        }
        if (source.droppableId === destination.droppableId) {
            return;
            /*const items = reorder(
                getList(source.droppableId),
                source.index,
                destination.index
            );

            let state = { items };

            if (source.droppableId === 'droppable2') {
                state = { selected: items };
            }

            setState(state);*/
        } else {
            const result = move(
                getList(source.droppableId),
                getList(destination.droppableId),
                source,
                destination,
                draggableId
            );
            handleDragSelectedChange(result);
        }
    }
    const searchUpdated = (term, itemlist) =>{
        const items = { ...state.searchTerm };
        items[itemlist] = term;
        setState({
          ...state,
            searchTerm: items,
            searchType: itemlist,
        })
    }
    const handleCheck = (id, checked, category) => {
       if(id == 0){
        handleSelectCheckAll(id, checked, "checkboxes", "checked", category, "flag")
        handleSelectTextAll(id, checked, "textfield", "order", category, "flag")
        handleSelectTextAll(id, checked, "textfield", "count", category, "flag")
        handleSelectTextHideAll("7", checked, "textfield", "count", category, "flag")
        handleSelectTextHideAll("8", checked, "textfield", "count", category, "flag")

      }else {
        handleUpdateState(id, checked, "checkboxes", "checked", category, "flag")
      }
      if(id == 9){
        handleSelectTextHideAll("7", checked, "textfield", "count", category, "flag")
      }
      if(id == 10){
      handleSelectTextHideAll("8", checked, "textfield", "count", category, "flag")
      }
      // else{
      //    handleSelectTextHideAll(id, checked, "checkboxes", "checked", category, "flag")
      // }
    }
  const  handleSelectTextHideAll = (id, value, type, action, pid, flag) => {
      let selected = [...state.selected];
       state.selected.map(functions => {
          Object.values(functions[type]).map(function (item, index) {
              if (item.id === id && functions.id === pid) {
                  item[action] = 1;
                  item[flag] = 1;
                  item.show=!value;
                  return;
              }
          })
      });
      setState({
         ...state,
          selected: selected,
      })
      props.updateSelectedRights(state.selected);
        // let selected = state.selected;
        // state.selected.map(functions => {
        //     Object.values(functions[type]).map(function (item, index) {
        //         if (value  && functions.id === pid) {
        //             item[action] = 1;
        //             item[flag] = 1;
        //             return;
        //         }
        //         else if(functions.id === pid){
        //           item[action] = 0;
        //           item[flag] = 0;
        //           return;
        //         }
        //     })
        // });
        // setState({
        //     selected: selected,
        // }, () => {
        //     props.updateSelectedRights(state.selected);
        //
        // })

    }
  const  handleSelectTextAll = (id, value, type, action, pid, flag) => {
        let selected = [...state.selected];
        state.selected.map(functions => {
            Object.values(functions[type]).map(function (item, index) {
                if (value  && functions.id === pid) {
                    item[action] = 1;
                    item[flag] = 1;
                    return;
                }
                else if(functions.id === pid){
                  item[action] = 0;
                  item[flag] = 0;
                  return;
                }
            })
        });
        setState({
          ...state,
            selected: selected,
        })
          props.updateSelectedRights(state.selected);

    }
  const  handleSelectCheckAll = (id, value, type, action, pid, flag) =>{
        let selected = [...state.selected];
        state.selected.map(functions => {
            Object.values(functions[type]).map(function (item, index) {
                if (value && functions.id === pid) {
                    item[action] = value;
                    item[flag] = 1;
                    return;
                }
                else if(functions.id === pid){
                  item[action] = value;
                  item[flag] = 0;
                  return;
                }
            })
        });
        setState({
          ...state,
            selected: selected,
        })
        props.updateSelectedRights(state.selected);

    }
  const   handleUpdateState = (id, value, type, action, pid, flag) => {
        let selected = state.selected;
        state.selected.map(functions => {
            Object.values(functions[type]).map(function (item, index) {
                if (item.id === id && functions.id === pid) {
                    item[action] = value;
                    item[flag] = 1;
                    return;
                }
            })
        });
        setState({
          ...state,
            selected: selected,
        })
        props.updateSelectedRights(state.selected);

    }
  const  handleChange = (id, value, type_id, type) => {
        const re = /^(?:[0-9]*)$/;
        if (value === '' || re.test(value)) {

            handleUpdateState(id, value, "textfield", type, type_id, "flag");
        }

    }
  const  handleChangeOrder = (id, value, type_id, type) =>{
        const re = /^(?:[0-9])$/;
        if (value === '' || re.test(value)) {
            handleUpdateState(id, value, "textfield", type, type_id, "flag");
        }
        // else{
        //     handleUpdateState(id, 1, "textfield", type, type_id, "flag");
        // }
    }
  const  handlePersons = async (item) =>{

    //  if (!props.details.disableFields || props.details.disableFields === undefined) {
        let callbackend = true;
        let show = state.show;
        let curently_hovered_item = state.curently_hovered_item;
        let persons : state.persons;
          if ((item.category_id !== undefined && item.category_id !== window.PERSON_ENTITY) || parseInt(item.entity_type_id) !== window.PERSON_ENTITY) {
               show = true;
              //setState({ ...state,show: true });
              if (state.persons[item.id]) {
                curently_hovered_item = state.persons[item.id];
                  setState({
                      ...state,
                      show: true,
                      curently_hovered_item: state.persons[item.id]
                  })
              }
              else {
                  const loaded_persons = state.persons;
                  var url = '';
                  let entity_type_id = '';
                  if (parseInt(item.category_id) === parseInt(window.SPACES_ENTITY) || item.category === "spaces") {
                     url = window.GET_SPACE_PERSONS + '/' + item.id
                  } else if (parseInt(item.category_id) === parseInt(window.ROLE_ENTITY) || item.category === "roles") {
                      if (item.abbrevation === "user roles") {
                        url = window.GET_ROLEPERSONS + '/' + item.id
                      } else {
                        callbackend = false
                        let persons_of_VCIVA = []
                        switch (item.abbrevation) {
                          case "view":
                            persons_of_VCIVA = props.credentials.access_details[1] ? props.credentials.access_details[1] : [];
                            break;
                          case "CRUD people" :
                            persons_of_VCIVA = props.credentials.access_details[2] ? props.credentials.access_details[2] : [];
                            break;
                          case "initiater":
                            persons_of_VCIVA = props.credentials.access_details[6] ? props.credentials.access_details[6] : [];
                            break;
                          case "verifyer":
                            persons_of_VCIVA = props.credentials.access_details[7] ? props.credentials.access_details[7] : [];
                            break;
                          case "authoriser":
                            persons_of_VCIVA = props.credentials.access_details[8] ? props.credentials.access_details[8] : [];
                            break;
                          default:
                            persons_of_VCIVA = []
                        }
                        let personsOfVCIVA = []
                        let personsWithoutDuplicates = []
                        persons_of_VCIVA.filter(item => {
                            if (!personsOfVCIVA.includes(item.name)) {
                              personsOfVCIVA.push(item.name)
                              personsWithoutDuplicates.push(item)
                            }
                          })
                        setState({
                           ...state,
                           show: true,
                            persons: personsWithoutDuplicates,
                            curently_hovered_item: personsWithoutDuplicates
                        })

                      }
                  } else {
                     entity_type_id = item.entity_type_id;
                     url = window.GetAllLinkedPersons + '/' + item.id + '/' + entity_type_id
                  }

                  if (callbackend) {
                  await datasave.service(url, "GET", '')
                        .then(async result => {
                            const all_persons = {
                                ...loaded_persons,
                                ...result
                            }
                            setState({
                               ...state,
                               show: true,
                                persons: all_persons,
                                curently_hovered_item: result[item.id]
                            })
                        })
                        .catch(error => {

                        })
                  }

              }
          }

      //}

    }
  const handleHide  = () => {
        setState({ ...state,show: false });
    }





    /*hideTooltip() {
        setState({isTooltipActive: false})
    }

    showTooltip() {
        setState({isTooltipActive: true})
    }*/


    // Normally you would want to split things out into separate components.
    // But in this example everything is just done in one place for simplicity


      const showPopup = state.showpopup;
        /*const popover = (
            <reactbootstarp.Popover style={tooltipStyle} id="popover-basic" title="Persons">
                <ul>
                    {state.curently_hovered_item.map(person =>
                        <li>{person.name}</li>
                    )}
                </ul>
            </reactbootstarp.Popover>
        );*/


        const popupContent = (

            <reactbootstarp.Modal
                show={state.show}
                onHide={handleHide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title"
            >
                <reactbootstarp.Modal.Header closeButton>
                    <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
                        {t("Persons")}
                </reactbootstarp.Modal.Title>
                    <reactbootstarp.Modal.Body>
                        <ul>
                            {state.curently_hovered_item.length != 0 &&
                                state.curently_hovered_item.map(person =>
                                    <li>{person.name}</li>
                                )
                            }
                            {state.curently_hovered_item.length === 0 &&
                                t('No persons are linked')
                            }
                        </ul>
                        {}
                        {}
                    </reactbootstarp.Modal.Body>
                </reactbootstarp.Modal.Header>
            </reactbootstarp.Modal>
        );
        const renderFunction = () => {

        if (props.types !== undefined && state.items !== undefined) {
            // const type = props.type;
            const types = props.types;
            // if ((props.tasks !== undefined && props.tasks.length > 0) && state.items.length === 0) {
            //     setState({
            //         items: props.tasks
            //     });
            // }
           state.selected = [...props.selected];
            if (props.selected !== undefined && props.selected.length === 0 && props.updateProps === 1 && state.updated > 0) {
                setState({
                    ...state,
                    selected: props.selected,
                    updated: 0,
                });
            }
            else if (props.selected !== undefined && props.selected.length > 0 && props.updateProps === 1 && state.selected.length === 0) {


                setState({
                    ...state,
                    selected: props.selected,
                    updated: 2,
                });
            }
          }
        }
            const dragObject = () => {
              const types = props.types;
            return(<reactbootstarp.Tabs activeKey={props.activeKey} onSelect={props.onSelect} id="controlled-tab-example">

                {Object.values(types).map(
                    function (itemlist, key) {
                        var search = '';
                        if (state.searchTerm && state.searchType) {
                            search = state.searchTerm[itemlist];
                            search = (search !== undefined) ? search : '';
                        }
                        filteredNames[itemlist] = state.items.filter(createFilter(search, state.KEYS_TO_FILTERS));
                        return (

                            <reactbootstarp.Tab className="input-right-field" id="dashdragndrop" eventKey={itemlist} title={t(itemlist.charAt(0).toUpperCase() + itemlist.slice(1))}>
                                <reactbootstarp.Table  responsive striped hover >

                                    <thead style={{position: 'sticky',top: '0',backgroundColor: '#fff'}}>
                                        <tr>
                                            <td style={{ padding: '0.25rem' }} colSpan="3" >
                                                <SearchInput style={{ colour: 'red', border: '0px', color: '#EC661C', fontSize: '13px', }} className="search-input approval-input" onChange={(e) => searchUpdated(e, itemlist)} />
                                                {/* <img style={{width: '17px', height: '17px'}} src={approvalsearch}></img> */}
                                            </td>
                                        </tr>
                                        <tr>
                                            {state.html_right[0][itemlist].map(rights =>
                                                <th style={{ backgroundColor: '#EC661C', fontSize: '14px', color: '#fff', padding: '0.25rem' }} title={rights.name}>{rights.name}</th>
                                            )}
                                        </tr>
                                    </thead>
                                    <tbody style={{ backgroundColor: '#fff', border: '0px' }}>
                                        {/* <div> */}
                                        {Object.values(filteredNames[itemlist]).map(
                                            function (item, index) {
                                                item.category_id = (item.entity_type_id !== undefined) ? item.entity_type_id : item.category_id;
                                                if (item !== undefined && item.id !== undefined && item.category === itemlist) {
                                                    return (
                                                        <Draggable className="right-field-border"
                                                            isDragDisabled={ (props.details.doc_status_id === 22 && item.category === 'spaces') ? (props.details.diable_ExpirationPeriod) : (props.details.disableFields ||props.details.exp_his_disabled|| props.disable_based_on_right||props.approvalcycle_disabled||props.extra_tab_disabled||props.default_tab_disabled)}
                                                            key={item.id}
                                                            draggableId={item.id}
                                                            type={item.category}
                                                            index={index}>
                                                            {(provided, snapshot) => (
                                                                <tr style={{}}
                                                                    ref={provided.innerRef}
                                                                    {...provided.draggableProps}
                                                                    {...provided.dragHandleProps}
                                                                >
                                                                    {/* <td className="borderrr" style={{ backgroundColor: '#fff', }}> */}
                                                                    <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6'}}>
                                                                        <div style={textinline} onClick={(e) => handlePersons(item)}>
                                                                            {/* <div className="dropdown-user-sec"> */}
                                                                            <span className="">
                                                                                {/* <p onClick={(e) => handlePersons(item)}> */}
                                                                                {item.category != 'spaces' &&
                                                                                    <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                                                                }
                                                                                &nbsp;
                                                                                {/* </p> */}
                                                                            </span>
                                                                            &nbsp;
                                                                            {/* <div> */}
                                                                                <span style={{wordBreak: 'break-word'}}>
                                                                                {item.name}
                                                                                </span>
                                                                            {/* </div> */}
                                                                        </div>
                                                                        {popupContent}
                                                                        {/* { item.category != 'spaces' &&
                                                                            <img style = {imageStyle} src={ item.category === 'persons' ? PersonImg : (item.category ==='jobs'? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" onClick={(e) => handlePersons(item)} />
                                                                        }
                                                                        {popupContent}
                                                                        &nbsp; &nbsp;
                                                                        {item.name} */}
                                                                    </td>
                                                                    {/* <td> */}
                                                                    {item.category != 'persons' &&
                                                                        // <td style={{ backgroundColor: '#fff', fontSize: '13px' }}>
                                                                        <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6', textAlign:'center',wordBreak: 'break-word'}}>
                                                                            {item.abbrevation}
                                                                        </td>
                                                                    }
                                                                    {/* </td> */}
                                                                </tr>
                                                            )}
                                                        </Draggable>
                                                    )
                                                }
                                            }, this)}
                                            {/* </div> */}
                                    </tbody>
                                </reactbootstarp.Table>
                            </reactbootstarp.Tab>
                        )
                    }, this)}
            </reactbootstarp.Tabs>
        )
      }

        return (
            <div className="col-md-12 p-0" style={getFlexStyle}>
              {updateSelectAll()}
              {renderFunction()}
                <DragDropContext onDragEnd={onDragEnd}>
                    <Droppable droppableId="droppable2">
                        {(provided, snapshot) => (
                            <div className="selected-item-header-section"
                                ref={provided.innerRef}
                                style={getListStyle(snapshot.isDraggingOver)}>
                                <p>{t("Selected items")}</p>
                                {state.showPopup && <TaskPopUp
                                   title = {t('Reason of change')}
                                   current_status = {'Save'}
                                   result_obj = {state.result_obj}
                                   task_id = {props.details.task_id}
                                   handleClicktrTask = {handleClicktrTask}
                                  />}
                                <div className='border-remove' style={{ width: '100%', overflowX: 'auto',  }}>
                                    <reactbootstarp.Table style={{ width: '100%', overflowX: 'auto', margin: '0' }} striped responsive bordered hover variant="dark">
                                        <thead  style={{ backgroundColor: '#EC661C',position: 'sticky',top: '0' }}>
                                            <tr >
                                                { state.html[0][props.type] !== undefined &&
                                                  state.html[0][props.type].map(commons =>
                                                    <th style={{ paddingTop: '20px', border: '0px', }} className={commons.class} title={t(commons.name)}></th>
                                                )}
                                            </tr>
                                        </thead>

                                        <tbody >
                                            {state.selected !== undefined && state.selected.map(
                                                function (item, index) {
                                                    if (props.type === "common") {
                                                        return (
                                                            <tr style={{ backgroundColor: '#fff', border: '0px' }}>
                                                                <td style={{ backgroundColor: '#fff', color: '#212529', border: '1px solid #fff', fontSize: '14px', padding: '0px', verticalAlign: 'middle',width: '5rem' }}>
                                                                    <div style={textinline} onClick={(e) => handlePersons(item)}>
                                                                        <div >
                                                                            {item.category !== 'spaces' &&
                                                                                <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                                                            }
                                                                        </div>
                                                                        &nbsp;
                                                                    <span style={{cursor: 'default', wordBreak: 'break-word',width: '5rem'}}>
                                                                            {item.name}
                                                                        </span>
                                                                    </div>
                                                                    {popupContent}

                                                                </td>
                                                                <td style={{textAlign: 'center'}} className="dpt-abrivation">
                                                                   <span style= {{cursor: 'default', color: '#212529',wordBreak: 'break-word'}}> {item.abbrevation}</span>
                                                                </td>
                                                                <td className = 'remove' style={{ verticalAlign: 'middle', textAlign: 'center' }}
                                                                  disabled={props.details.disableFields || props.disable_based_on_right||props.approvalcycle_disabled||props.extra_tab_disabled||props.default_tab_disabled}>
                                                                    {props.remove_type === undefined && <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => handleClicktr(item)}></img>}
                                                                      {props.remove_type === true && <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => handleClicktrTask(item)}></img>}
                                                                </td>
                                                            </tr>
                                                        )
                                                    }
                                                    else if (props.type == 'rights') {
                                                        return (
                                                            <tr style={{ 'backgroundColor': '#fff', 'border': '0px' }}>
                                                                <td style={{ backgroundColor: '#fff', color: '#212529', 'border': '1px solid #fff', fontSize: '14px', padding: '0px', verticalAlign: 'middle' }}>
                                                                    <div style={textinline} onClick={(e) => handlePersons(item)}>
                                                                        <div>
                                                                            {item.category !== 'spaces' &&
                                                                                <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                                                            }
                                                                        </div>
                                                                        &nbsp;
                                                                    <div style={TextCurser}>
                                                                            {item.name}
                                                                        </div>
                                                                    </div>
                                                                    {popupContent}
                                                                </td>
                                                                {item.checkboxes.map(function (check) {
                                                                    return (
                                                                        <td id = {check.id} style={{ verticalAlign: 'middle' }}>
                                                                            <CheckBox
                                                                                key={check.id}
                                                                                name={''}
                                                                                value={check.id}
                                                                                tick={check.checked}
                                                                                category={item.category}
                                                                                classification={check.name}
                                                                                approvalcycle_disabled = {props.details.approvalcycle_disabled}
                                                                                onCheck={(e) => handleCheck(check.id, e.target.checked, item.id)}
                                                                                keyvalue={check.id}
                                                                                disabled = {props.details.disableFields || props.details.exp_his_disabled || props.disable_based_on_right}
                                                                            />
                                                                        </td>
                                                                    )
                                                                }, this)}
                                                                {item.textfield.map(function (text) {
                                                                    return (
                                                                        <td id={text.name}>
                                                                            <TextField
                                                                                name={text}
                                                                                order={text.order}
                                                                                count={text.count}
                                                                                category={item.category}
                                                                                show = {text.show}
                                                                                handleChange={(e) => handleChange(text.id, e.target.value, item.id, "count")}
                                                                                handleChangeOrder={(e) => handleChangeOrder(text.id, e.target.value, item.id, "order")}
                                                                                approvalcycle_disabled = {props.details.approvalcycle_disabled}
                                                                                disabled = {props.details.disableFields || props.details.exp_his_disabled || props.disable_based_on_right}
                                                                            />
                                                                        </td>
                                                                    )
                                                                }, this)}
                                                                <td className = 'remove' style={{ verticalAlign: 'middle' }}>
                                                                    <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => handleClicktr(item)}></img>
                                                                </td>
                                                            </tr>
                                                        )
                                                    }
                                                }, this)}
                                            {provided.placeholder}
                                        </tbody>

                                    </reactbootstarp.Table>
                                </div>
                            </div>
                        )}
                    </Droppable>
                    <Droppable droppableId="droppable">
                        {(provided, snapshot) => (

                            <div className="avialble-filed-person "

                                ref={provided.innerRef}
                                style={getListStyle(snapshot.isDraggingOver)}
                            >
                                <p>{t("Available items")}</p>
                                {provided.placeholder}
                                {dragObject()}
                            </div>
                        )}
                    </Droppable>
                </DragDropContext>
            </div>
        );

}
export default translate(React.memo(DragnDrop));
function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {

    ref.current = value;
  });
  return ref.current;
}
