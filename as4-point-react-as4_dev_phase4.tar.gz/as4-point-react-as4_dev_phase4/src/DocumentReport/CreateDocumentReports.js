import React, { Component } from 'react';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';

 class CreateDocumentReports extends Component {
   constructor(props) {
     super(props);
     this.state = {
        t: props.t,
        name              : '',
        warning           : false,
        showPopUp         : false,
        deletePopUp       : false,
        reportList        : [],
        selectedReport    : 0,
        deleteReportId    : 0,
        filterdReportList : [],
     }
   }

   componentDidMount() {
     this.getReportsList();
   }

   getReportsList = () => {
      datasave.service(window.GET_DOC_TEMPLATE_REPORT,'GET').
      then(result =>{
        this.setState({ reportList : result['data'], filterdReportList : result['data'] });
      });
   }
   handleSave = async () => {
     let data = await this.getData();
     if (this.state.warning === false && this.state.name !== '') {
         datasave.service(window.INSERT_DOC_TEMPLATE_REPORT, 'POST', data)
             .then(response => {
               if(response['status'] === 200) {
                 OCAlert.alertSuccess('Saved successfully', { timeOut: window.TIMEOUTNOTIFICATION });
                 this.getReportsList();
                 this.closePopUp();
               } else {
                 OCAlert.alertError('Error occured while saving', { timeOut: window.TIMEOUTNOTIFICATION });
               }
             });
     }
     else {
          this.setState({ warning: true });
      }
   }
   handleDelete = (val) => {
     if(val){
       datasave.service(window.DELETE_DOC_TEMPLATE_REPORT+ '/' + this.state.deleteReportId ,'GET')
       .then(result => {
         console.log(result);
         if(result['status'] === 200){
           OCAlert.alertSuccess('Deleted successfully', { timeOut: window.TIMEOUTNOTIFICATION });
           this.getReportsList();
           this.setState({ deletePopUp: false });
         } else{
           this.setState({ deletePopUp: false });
         }
       })
     }else {
       this.setState({ deletePopUp : false })
     }
   }

   getData = () => {
       let data = {
           name : this.state.name,
           id   : this.state.selectedReport,
       }
       return data;
   }

   deleteReportPopup = (id) => {
    this.setState({
      deletePopUp    : true,
      deleteReportId : id,
    })
   }

   closeDeletePopUp = () => {
     this.setState({
       deletePopUp : false,
     });
   }

   editReport = (id, name) => {
     this.setState({
       selectedReport : id,
       name           : name,
       showPopUp      : true,
     })
   }

   showCreatePopup = () => {
     this.setState({
       showPopUp : true,
     });
   }

   closePopUp = () => {
     this.setState({
       showPopUp      : false,
       name           : '',
       warning        : false,
       selectedReport : 0,
     });
   }

   handleKeyPress = (e) => {
       var value = (e.target.value.length > 0) ? true : false;
       if (e.key === 'Enter' && value === true) {
           this.handleSave();
       }
   }

   handleName = (e) => {
       let value = e.target.value;
       let condition = /[^\s-]/;
       if (value.match(condition) || value === '') {
           this.setState({
             name    : value,
             warning : value === '' ? true : false,
          })
       }
   }

   searchList = (e) => {
     let value = e.target.value.toLowerCase();
     let filterList = [...this.state.reportList];
     filterList = filterList.filter(
       (list) => {
         return list.name.toLowerCase().indexOf(value) !== -1;
       }
     )
     this.setState({ filterdReportList : filterList })
   }

   createTableStructure = () => {
     let table = [];
     const { t } = this.state;
     table.push(
       <reactbootstrap.Table responsive bordered hover>
         <thead>
             <tr>
                 <th class="text-center" >{t('Name')}</th>
                 <th class="text-center" >{t('actions')}</th>
             </tr>
         </thead>
         <tbody style={{ border: '1px solid lightgray' }}>
             {this.getWebfomTemplate()}
         </tbody>
       </reactbootstrap.Table>
     );
     return table;
   }

   getWebfomTemplate = () => {
     const { t } = this.state;
     var link = "/document_template_report/";
     var preview = "/document_template_preview/";
     let table = [];
     let reportList = this.state.filterdReportList;
     reportList.map(value =>{
       table.push(
         <tr>
           <td id = {value.id} class="text-center">
             {value.name}
           </td>
           <td class="text-center">
           <table style={{width:'100%'}}><tr className="remove-border">
               <td>
                  <i title="Edit"
                     style={{ 'cursor': 'pointer' }}
                     class="overall-sprite overall-sprite-myeditc"
                     onClick={this.editReport.bind(this, value.id, value.name)}>
                  </i>
               </td>
                <td>
                  <i title="View"
                     style={{ 'cursor': 'pointer' }}
                     class="webform-sprite webform-sprite-smallviewc"
                     onClick={() => window.open(link + value.id, "_blank")} >
                  </i>
               </td>
               <td>
                  <a style={{color:'#EC661C','cursor': 'pointer'}}
                     title="Preview"
                     onClick={() => window.open(preview + value.id, "_blank")}>
                     {t('Preview')}
                  </a>
               </td>
               <td>
                  <i title="Delete"
                     style={{ 'cursor': 'pointer' }}
                     class="overall-sprite overall-sprite-mtdeletec"
                     onClick={this.deleteReportPopup.bind(this, value.id)}>
                  </i>
               </td>
             </tr></table>
           </td>
         </tr>
       );
     });
    return table;
   }

   handleonEntered = () => {
       document.getElementById('formtemplateid').focus();
   }

   modalBody = () => {
     const { t, warning, name } = this.state;
     let table = [];
     table.push(
         <div>
             <reactbootstrap.Col className="row col-md-12">
                 <reactbootstrap.Form.Group className="row justify-content-center" controlId="formtemplateid">
                     <reactbootstrap.Form.Label className="col-md-5">
                         {t('Name')}:<span style={{ color: "red" }}>*</span>
                     </reactbootstrap.Form.Label>
                     <reactbootstrap.Form.Control className="col-md-7"
                         type="text"
                         value={name}
                         onChange={this.handleName}
                         placeholder="Enter Name"
                         onKeyPress={this.handleKeyPress}
                     />
                     {warning === true && <reactbootstrap.Form.Text style={{ color: "red" }} >
                         {t('Name is required field')}
                     </reactbootstrap.Form.Text>}
                 </reactbootstrap.Form.Group>
             </reactbootstrap.Col>
         </div>
     );
     return table;
   }

   modalFooter = () => {
     const { t } = this.state;
         return (
             <div>
                 <reactbootstrap.Button onClick={this.closePopUp} variant="primary">
                     {t('Close')}
                 </reactbootstrap.Button> <span style={{ marginRight: '10px' }}></span>
                 <reactbootstrap.Button onClick={this.handleSave} variant="primary">
                     {t('Save')}
                 </reactbootstrap.Button>
             </div>
         );
   }

  render(){
    const { t,showPopUp, deletePopUp } = this.state;
    const createReportPopUp = (
      <div className='row md-8'>
          <reactbootstrap.Modal
              show={showPopUp}
              onHide={this.closePopUp}
              dialogClassName="modal-90w"
              aria-labelledby="example-custom-modal-styling-title"
              onEntered={this.handleonEntered}
          >
              <reactbootstrap.Modal.Header closeButton>
                  <reactbootstrap.Modal.Title style={{ textAlign:'center' }}>{t('Create Document Report')}</reactbootstrap.Modal.Title>
              </reactbootstrap.Modal.Header >
              <reactbootstrap.Container className="">
                  <reactbootstrap.Modal.Body>
                      {this.modalBody()}
                  </reactbootstrap.Modal.Body>
                  <reactbootstrap.Modal.Footer>
                      {this.modalFooter()}
                  </reactbootstrap.Modal.Footer>
              </reactbootstrap.Container>
          </reactbootstrap.Modal>
      </div>
    );
    const createDeletePopUp = (
      <reactbootstrap.Modal
          show={deletePopUp}
          onHide={this.closeDeletePopUp}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
          <reactbootstrap.Modal.Header closeButton>
              <reactbootstrap.Modal.Title>{t('Delete Report')}</reactbootstrap.Modal.Title>
          </reactbootstrap.Modal.Header >
          <reactbootstrap.Container className="">
              <reactbootstrap.Modal.Body>
                  {t('Are you sure want to delete the Report')}
              </reactbootstrap.Modal.Body>
              <reactbootstrap.Modal.Footer>
              <reactbootstrap.Form>
                <reactbootstrap.Button onClick={(e)=>this.handleDelete(1)} style={{ margin: '0px 10px' }}variant="primary" type="button">
                  {t('Yes')}
                </reactbootstrap.Button>
                <reactbootstrap.Button onClick={(e)=>this.handleDelete(0)} variant="primary" type="button">
                  {t('No')}
                </reactbootstrap.Button>
              </reactbootstrap.Form>
              </reactbootstrap.Modal.Footer>
          </reactbootstrap.Container>
      </reactbootstrap.Modal>
    );
    return(
      <reactbootstrap className=" row ">
        <div className="col-md-12" >
          <div style={{ border: '1px solid gray', borderRadius: '5px' }} className="samplae col-md-12 pt-2 mt-2  mb-3" >
             <reactbootstrap.Container className=''>
               <div className='col-md-5 row pt-3'>
                  <input type="text" className="form-control search-box-border col-md-8"
                         placeholder='Search'
                         style={{ borderRadius: "5px", borderColor: "#EC661c" }}
                         onChange = {this.searchList}
                  />
                  <button type="button" class="btn btn-link">
                   <i title="Create Report"
                      className= "col-md-4 "
                      class="webform-sprite webform-sprite-createlistc"
                      onClick = {this.showCreatePopup}
                    >
                   </i>
                  </button>
               </div>
               <div className='col-md-8'>
                   {this.createTableStructure()}
                   {createReportPopUp}
                   {createDeletePopUp}
               </div>
             </reactbootstrap.Container>
          </div>
        </div>
      </reactbootstrap>
    );
  }
 }

 export default translate(CreateDocumentReports);
