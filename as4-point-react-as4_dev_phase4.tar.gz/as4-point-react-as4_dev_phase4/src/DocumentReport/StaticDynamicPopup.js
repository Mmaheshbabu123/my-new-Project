import React, { Component } from 'react';
import { translate } from '../language';
import * as reactbootstrap from 'react-bootstrap';
import MultiSelect from '../_components/MultiSelect';
import { reportFilter } from '../Webforms/WebReports/CustomFilterFunctions';
const todaysDate = new Date();
const dateOptionObj = Object.keys(window.DATE_DEFAULT_FILTER_KEY_LABEL).map(key => { return { 'label': window.DATE_DEFAULT_FILTER_KEY_LABEL[key], 'value': key } });
dateOptionObj.push({label:'From and to date', value: window.FROM_TO_DATE});
const fromDate =todaysDate.getFullYear() + '-' + '01' + '-' + '01' ;
const toDate  =todaysDate.getFullYear() + '-' + (todaysDate.getMonth() + 1) + '-' + todaysDate.getDate();
class StaticDynamicPopup extends Component {
  constructor(props){
    super(props)
    this.state = {
      t: props.t,
      isDynamic     : 0,
      fromDate      : '',
      toDate        : '',
      dynamicPeriod :dateOptionObj[0] ,
      warning       : false,
      dynamicDates  : dateOptionObj,
      isDisable:true,
      dateFieldFilter: {
        label: 'Start date',
        value: "99991||"+ window.START_DATE
      },
      dateListMinMaxObj: {},
      quality_fiscal:{
        fiscal:{
          from_date:'1',
          from_month:'1',
          to_date:'1',
          to_month:'1'
        },
        quality:{
          from_date:'7',
          from_month:'9',
          to_date:'13',
          to_month:'9'
        }
      },

    }
  }

  getData = () => {
    let data = {
      isDynamic : this.state.isDynamic,
      fromDate  : this.state.fromDate,
      toDate    : this.state.toDate,
      period    : this.state.isDynamic === 1 ? this.state.dynamicPeriod : '',
    }
    return data;
  }

  handleSave = async () => {
    const { fromDate, toDate } = this.state;
    if(fromDate !=='' && toDate !== ''){
      let data = await this.getData();
      this.props.storeTokensData(data);
      this.props.closePopUp();
    }else { this.setState({ warning : true }) }
  }

  handleDatesChange = (event, name) => {
    this.setState({[name]: event.target.value, warning : false});
  }
  handleDynamicDates = (e) => {
    let name = e.label;
    let value = e.value;
    let setObj = { [name]: value };
    let resFromToDate = parseInt(value) !== window.FROM_TO_DATE && Object.keys(value).length > 0 ?
                        (parseInt(value) === window.ALL ?
                        this.getToFromDateAccordingToDateSelect(value,this.state.dateFieldFilter['value'], this.state.dateListMinMaxObj,fromDate, toDate) :
                        reportFilter.dateFilterSwitch(value, this.state.quality_fiscal)) : {};
    let fromDate = resFromToDate['fromDate'] !== undefined &&
                  resFromToDate['fromDate'] !== '' ? this.convertDateObjToString(resFromToDate['fromDate']) : '';
    let toDate = resFromToDate['toDate'] !== undefined &&
                 resFromToDate['toDate'] !== '' ? this.convertDateObjToString(resFromToDate['toDate']) : '';
    if (e.label === 'All'){
      this.setState({ dynamicPeriod:e,
        });
    }else {
      this.setState({ dynamicPeriod:e,
                      fromDate:fromDate,
                      toDate:toDate,
                      isDisable:value =='15'?false:true
                  });
    }

   }
convertDateObjToString = (dateObj) => {
  let month = dateObj.getMonth() + 1;
  let fullYear = dateObj.getFullYear();
  let date = dateObj.getDate() * 10 >= 100 ? dateObj.getDate() : '0' + (dateObj.getDate());
  return fullYear + '-' + ((month * 10) >= 100 ? month : '0' + month) + '-' + date;
}

  getToFromDateAccordingToDateSelect = (tempDateSelect, tempDateFieldFilter, tempDateListMinMaxObj, toDate, fromDate) =>{
      if(Object.keys(tempDateListMinMaxObj).length > 0 && parseInt(tempDateSelect) === window.ALL){
      let  selectDateObj = tempDateListMinMaxObj[tempDateFieldFilter] !== undefined ? tempDateListMinMaxObj[tempDateFieldFilter] : {};
        return  {toDate: selectDateObj['max'] !== 0 ? new Date(selectDateObj['max']) : '',
      	 fromDate: selectDateObj['min'] !== 0 ? new Date(selectDateObj['min']) : ''};
      }else{
        return { toDate: toDate, fromDate: fromDate };
      }
}
  handleCheckBox = (e) => {
      this.setState({
        isDynamic : (e.target.name === 'staticReport' ? 0 : 1 ),
      })
  }


  render(){
    // console.log(this.state.dynamicDates,this.state.dynamicPeriod);
    let options = this.state.dynamicDates;
    const { t, isDynamic, dynamicPeriod,warning } = this.state;
    return(
      <div className='container'>
          <div className='col-md-12'>
            <reactbootstrap.Row className="col-md-12">
                <div className="col-md-5 m-2">
                   <input type="checkbox"
                          name="staticReport"
                          checked={isDynamic === 1 ? false : true}
                          onChange={this.handleCheckBox}
                   />
                   <span> {t('Static')} </span>
                </div>
                <div className="col-md-5 m-2">
                    <input type="checkbox"
                           name="dynamicReport"
                           checked={isDynamic === 1 ? true : false}
                           onChange={this.handleCheckBox}
                    />
                    <span> {t('Dynamic')} </span>
                </div>
            </reactbootstrap.Row>
            <reactbootstrap.Row className="col-md-12">
                   <div className='col-md-12'>
                       <label className='col-md-5'>
                         {t('From date')}<span style={{ color: "red" }}> *</span>:
                       </label>
                       <input className='col-md-6'
                              type="date"
                              value={this.state.fromDate}
                              disabled={isDynamic ===1 && this.state.isDisable}
                              onChange={(e) => { this.handleDatesChange(e, 'fromDate') }}>
                        </input>
                                  <br />
                       <label className='col-md-5'>
                           {t('To date')}<span style={{ color: "red" }}> *</span>:
                       </label>
                       <input className='col-md-6'
                              type="date"
                              disabled={isDynamic ===1 && this.state.isDisable}
                              value={this.state.toDate}
                              onChange={(e) => { this.handleDatesChange(e, 'toDate') }}>
                        </input>
                   </div>
                  {isDynamic ===0 ? '' :
                      <div className='col-md-12 row'>
                        <label className='col-md-5'>
                            {t('Period :')}
                        </label>
                        <div className='col-md-7'>
                              <MultiSelect
                               options={options}
                               standards={dynamicPeriod}
                               id={'dates'}
                               isMulti={false}
                               handleChange={(e) => this.handleDynamicDates(e)}
                              />
                        </div>
                      </div>
                  }
            </reactbootstrap.Row>
            <div>
                {warning && <reactbootstrap.Form.Text style={{ color: "red" }} >
                   {t('Enter all required fields')}
                </reactbootstrap.Form.Text>}
            </div>
             <div className='m-3' style={{ float:'right' }}>
                <reactbootstrap.Button onClick={this.props.closePopUp} variant="primary">
                    {t('Close')}
                </reactbootstrap.Button> <span style={{ marginRight: '10px' }}></span>
                <reactbootstrap.Button onClick={this.handleSave} variant="primary">
                    {t('Save')}
                </reactbootstrap.Button>
             </div>
          </div>
      </div>
    );
  }
}

export default translate(StaticDynamicPopup);
