import React, { Component } from 'react';
import { translate } from '../language';
import { datasave } from '../_services/db_services'
import * as reactbootstrap from 'react-bootstrap';
import ReactDOM from 'react-dom';

class DocumentTemplatePreview extends Component {
  constructor(props){
    super(props)
    this.state = {
      templateId : this.props.match.params.docTempId,
      langId     : 3, // default dutch
      htmlCode   : ''
    }
  }
  async componentDidMount(){
    await datasave.service(window.DOC_TEMPLATE_PREVIEW + '/' + this.state.templateId + '/' + this.state.langId , 'GET')
    .then(response => {
      console.log(response);
      this.setState({ htmlCode : response  });
      // console.log(response.url);
      // if(response.status === 200) {
      //       var a      = document.createElement("a");
      //       a.href     = response.url;
      //       a.download = response.name;
      //       document.body.appendChild(a);
      //       a.click();
      //       a.remove();
      // }
    })
    // ReactDOM.render(this.state.htmlCode, document.getElementById('root_root'));
  }
  render(){
    return(
      <div className='container'>
          <div className='col-md-12'>
              <div id = "root_root"></div>
          </div>
      </div>
    );
  }
}

export default translate(DocumentTemplatePreview);
