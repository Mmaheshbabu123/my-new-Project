import React, { Component } from 'react';
import TreeMenu from 'react-simple-tree-menu'
import renderhtml from 'react-render-html';
import { datasave } from '../_services/db_services';
import { Button, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import DocumentHeader from '../_components/DocumentHeader';
import * as reactbootstrap from 'react-bootstrap';
import FolderStructure from '../Folder/Folder';
import DocumentStructure from '../Document/Document';
//import DocumentStructure from '../DocumentCopy/Document';
import Draft from '../Document/Draft';
import Memo from '../Memo/Memo';
import { Input, ListGroup, ListGroupItem } from 'reactstrap';
import folderlogo from './folder-icon.png';
import documentlogo from './document.png';
import addfolder from './addfolder.png';
import adddocument from './adddocument.png';
import './BlancoStructure.css';
import Can from '../_components/CanComponent/Can';
import BlancoCan from '../_components/CanComponent/BlancoCan';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import SmartEditor from '../SmartEditor/SmartEditor';
import FMDSmartEditor from '../FrameMasterData/FMDSmartEditor';
import '../Css/DocumentIcons.css';
import { persistor, store } from '../store';
import _ from "lodash";
import sandboxicon from './sandbox.png';
import { translate } from '../language';
import SandboxStructure from '../Sandbox/SandboxStructure';
import ImportDocument from '../Document/ImportDocument';
import axios from 'axios';
import Pdf from '../_components/ObjectComponents/Pdf';
import { browserHistory } from 'react-router';
import { Draggable, Droppable } from 'react-drag-and-drop'
import { OCAlert } from '@opuscapita/react-alerts';
import { isAbsolute } from 'path';
import Hierarchy from '../Siteshierarchy/hierarchy.js'
import BuildWebformNElements from '../_components/Webforms/DragnDrop/BuildWebformNElements';
import { saveWebform } from '../../src/_services/save.webform';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css';
import ImportWebform from '../../src/Webforms/ImportExportWebform/Import';
import ExportWebform from '../../src/Webforms/ImportExportWebform/Export';
import $ from 'jquery';

function arr_diff(a1, a2) {

    var a = [], diff = [];

    for (var i = 0; i < a1.length; i++) {
        a[a1[i]] = true;
    }

    for (var i = 0; i < a2.length; i++) {
        if (a[a2[i]]) {
            delete a[a2[i]];
        } else {
            a[a2[i]] = true;
        }
    }

    for (var k in a) {
        diff.push(k);
    }

    return diff;
}
String.prototype.explode = function (separator, limit) {
    const array = this.split(separator);
    if (limit !== undefined && array.length >= limit) {
        array.push(array.splice(limit - 1).join(separator));
    }
    return array;
};


const docs = [
    {
        id: '',
        name: 'All',
    },
    {
        id: 1,
        name: 'DOC',
    },
    {
        id: 2,
        name: 'EXCEL'
    },
    {
        id: 3,
        name: 'VISIO'
    },
    {
        id: 4,
        name: 'PDF'
    },
    {
        id: 5,
        name: 'OBJECT'
    },
    {
        id: 6,
        name: 'WEBFORM'
    },

]
const doc_status = [
    {
        id: '',
        name: 'All',
    },
    {
        id: 1,
        name: 'New',
    }]

let clickEventPrevent = false;

let state_showDocument = false;
let state_openNodeManual = [];
let state_sitecount =0;
let state_as4PersonOrNot = 0;
let state_count = 0;
let state_web_id = 0;
let state_sandbox = false;
let state_addsite =  false;
let state_doc_id = 0;
let state_document_status = 0;
let state_showFolder = false;
let state_showMemo = false;
let state_showEditor = false;
let state_showWebform = false;

class BlancoStructure extends Component {
    content = '';
    cloneContent = '';
    webformSaveDocId = '';
    editordocobj = '';
    constructor(props) {
        let userData = store.getState();
        let personid = userData.UserData.user_details.person_id;
        let person_name = userData.UserData.user_details.user_name;
        let url = window.REMOVE_LOCK_FOR_PERSON_ENTITY+personid;
        datasave.service(url, "GET")
        .then(result => {
          if(result.status === 500)
          OCAlert.alertError(props.t('Error occured while fetching data.'), { timeOut: window.TIMEOUTNOTIFICATION });
        })
        if (window.performance) {
            // if (performance.navigation.type == 1) {
                 url = window.REMOVE_LOCK_BASED_NAME;
                let data = {
                    name:person_name,
                    person_id:personid,
                }
                datasave.service(url, "POST",data)
                .then(result => {

                })
            // }
          }

        super(props)
        this.clickCount = 0;
        this.singleClickTimer = '';
        // this.getButton = this.getButton.bind(this)
        this.actionEdit = this.actionEdit.bind(this)
        this.actionHeader = this.actionHeader.bind(this)
        this.cancelImport = this.cancelImport.bind(this)
        this.updateFolder = this.updateFolder.bind(this)
        this.onClickNode = this.onClickNode.bind(this)
        this.uploadDocument = this.uploadDocument.bind(this)
        this.handleCycle = this.handleCycle.bind(this)
        this.cancelData = this.cancelData.bind(this)
        this.onDoubleClickNode = this.onDoubleClickNode.bind(this)
        this.removeEditorFrame = this.removeEditorFrame.bind(this)
        this.updateEditorFrame = this.updateEditorFrame.bind(this)
        this.minimizeEditorFrame = this.minimizeEditorFrame.bind(this)
        this.addmasterdata = this.addmasterdata.bind(this)
        this.closemasterdata = this.closemasterdata.bind(this)
        this.removeWebformFrame = this.removeWebformFrame.bind(this)
        this.close = this.close.bind(this)
        this.updateWebformFrame = this.updateWebformFrame.bind(this)
        this.minimizeWebform = this.minimizeWebform.bind(this)
        this.addWebformmasterdata = this.addWebformmasterdata.bind(this)
        this.closeWebformmasterdata = this.closeWebformmasterdata.bind(this)
        this.deleteDocument = this.deleteDocument.bind(this);
        this.memoId = this.memoId.bind(this);
        this.openDocument = this.openDocument.bind(this);
        this.deleteFolder = this.deleteFolder.bind(this);
        this.deleteManual = this.deleteManual.bind(this);
        this.docfilter = this.docfilter.bind(this);
        this.onDrop = this.onDrop.bind(this);
        this.applyFilter = this.applyFilter.bind(this);
        this.logCredentials = this.logCredentials.bind(this);
        this.draftStatus = this.draftStatus.bind(this);
        this.openNodesFilter = this.openNodesFilter.bind(this);
        this.addToSites = this.addToSites.bind(this);
        this.checkDocLockStatus =  this.checkDocLockStatus.bind(this);
        // this.onDragOver = this.onDragOver.bind(this);
        this.importWebform = this.importWebform.bind(this);
        this.exportWebform = this.exportWebform.bind(this);
        this.memoSaved = this.memoSaved.bind(this);
        this.filterArrayConstruct = this.filterArrayConstruct.bind(this);
        if (this.props.match !== undefined) {
            var blancoid = this.props.match.params.id;
        }
        else {
            var blancoid = this.props.blanco_id;
        }
        this.state = {
            blanco_data: {},
            // folderDetails: {},
            testdata: "testdata",
            showDocHeader: false,
            // showFolder: false,
            // showMemo: false,
            showpdf: false,
            showDraft: false,
            blanco_id: blancoid,
            credentials: {},

            // showEditor: false,
            // showWebform: false,
            doc_type_id: (localStorage.getItem('filter_type_val') === null) ? '' : localStorage.getItem('filter_type_val'),
            // doc_status: [],
            doc_type_status: (localStorage.getItem('filter_status_val') === null) ? '' : localStorage.getItem('filter_status_val'),//localStorage.getItem('filter_status_val'),
            // doc_types: [],
            standards: [],
            templates: [],
            docPath: '',
            cancelPopup:0,
            fileexists: 0,
            openNode: [],
            activeOpenNode: '',
            t: props.t,
            editorDocId: '',
            linked_key: [],
            not_linked_key: [],
            doc_type: '',
            // sandbox: false,
            showUploadDoc: false,
            minimize: false,
            minimizeWebform: false,
            // web_id: 0,
            openNodeManual: [],
            hovering: false,
            nodeList: [],
            dropped: '',
            droppable_status: false,
            draft: false,
            insertmasterdata: true,
            insertWebformmasterdata: true,
            // count : 0,
            usedDocs:[],
            todoDetails : {},
            // addsite : false,
            // sitecount : 0,
            showImportWebform : false,
            showExportWebform : false,
            // document_status : 0,
            logedinRoleId: userData.UserData.user_details.role_id,
            // as4PersonOrNot: 0,
        }
        // this.BuildWebformNElements =  React.createRef();

    }
   componentDidMount() {
        this.documentTotalCount()
        // localStorage.remove  Item('openNodeManual');
        // this.setState({
        //       activeOpenNode:localStorage.getItem('activeOpenNode'),
        // });
        state_openNodeManual =  JSON.parse(localStorage.getItem('openNodeManual'))
        this.setState({
          // openNodeManual: JSON.parse(localStorage.getItem('openNodeManual')),
          activeOpenNode: localStorage.getItem('activeOpenNode'),
        })
        datasave.service(window.SITESCOUNT,"GET")
          .then(result => {
            state_sitecount = result;
            // this.setState({
            //   sitecount : result
            // })
          })
        let rolesURL = window.USERROLES + '/' + this.state.logedinRoleId;
        datasave.service(rolesURL, "GET")
          .then(response => {
            state_as4PersonOrNot =  response[0] ?  response[0]['as4member'] : 0;
            // this.setState({
            //   as4PersonOrNot: response[0] ?  response[0]['as4member'] : 0,
            // })
          })
        let userData = store.getState();
        var url = '';
        if (this.props.match !== undefined) {
            url = window.FETCH_FOLDER + '/' + this.props.match.params.id + '?pid=' + userData.UserData.user_details.person_id;
        }
        else if (this.props.manual_id !== '') {
            url = window.FETCH_MANUALS + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id;
        }
        if (url !== '') {
         datasave.service(url, "GET")
            .then(result => {
                localStorage.setItem('folderDetails', JSON.stringify(result.folderdata));
                let filter_type_val = this.state.doc_type_id;
                let filter_status_val = this.state.doc_type_status;
                state_openNodeManual = result.opennodesfilter
                state_web_id = parseInt(localStorage.getItem('web_id'));
                state_sandbox = false;
                state_addsite = false;
                // this.setState({
                //     // openNodeManual: result.opennodesfilter,
                //     // folderDetails: result.folderdata,
                //     // web_id: parseInt(localStorage.getItem('web_id')),
                //     // sandbox: false,
                //     // addsite : false,
                //     // doc_status: [window.DOCUMENT_STATUS_TODOS],
                //     // doc_types: docs,
                // });
                this.displayFolder(result.folderdata, filter_type_val, filter_status_val);
            });
        }
        if (this.props.addnewmanual) {
            this.actionHeader('', 'blanco', 'create', 'folder', '', '', '', '');
        }
        else {
            this.logCredentials();
        }



    }
    addToSites(id,status) {
      state_showDocument = false;
      state_addsite = true;
      state_doc_id = id;
      state_document_status = status;
      state_showFolder = false;
      state_showMemo = false;
      state_showEditor = false;
      // this.setState({
      //   // doc_id:id,
      //   // document_status : status,
      //   // showFolder: false,
      //   // showDocument: false,
      //   // showMemo: false,
      //   // showEditor: false,
      //   // addsite : true,
      // })
    }

    documentTotalCount() {
        const data = ({
            manual_id : this.props.manual_id ,
            web_id :parseInt(localStorage.getItem('web_id')),
            status :window.TODO
        })
        if (parseInt(localStorage.getItem('web_id'))!==0){
            datasave.service(window.SANDBOX_COUNT,'POST',data)
            .then(result=>{
              state_count = result;
                // this.setState({
                //     count: result,
                // })
        })
      }

    }
    componentDidUpdate(prevProps, prevState) {
        let userData = store.getState();
        if (this.props.blanco_id !== undefined) {
            this.state.blanco_id = this.props.blanco_id;
        }
        if (prevProps.manual_id !== this.props.manual_id && this.props.manual_id !== "") {
            this.documentTotalCount()
            var url = window.FETCH_MANUALS + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id;
            datasave.service(url, "GET")
                .then(result => {
                  state_web_id =  parseInt(localStorage.getItem('web_id'));
                  state_sandbox = false;
                  state_addsite = false;
                    // this.setState({
                    //
                    //     // folderDetails: result.folderdata,
                    //     // openNodeManual: result.opennodes,
                    //     // web_id: parseInt(localStorage.getItem('web_id')),
                    //     // sandbox: false,
                    //     // addsite:false,
                    //
                    // })
                    this.setState({
                        nodeList: result.opennodesfilter,
                    });
                    localStorage.setItem('folderDetails', JSON.stringify(result.folderdata));
                    let filter_type_val = this.state.doc_type_id;
                    let filter_status_val = this.state.doc_type_status;
                    if(filter_type_val != '' || filter_status_val != ''){
                      this.applyFilter();
                    } else {
                      if(prevProps.manual_id != "" && this.props.manual_id != prevProps.manual_id && this.props.manual_id !== undefined ){
                        state_openNodeManual = [];

                      }
                      this.displayFolder(result.folderdata, filter_type_val, filter_status_val);
                    }
                });
        }
    }

    componentWillUnmount() {
        localStorage.removeItem('headercredentials');
    }

    // getButton(key, props, keys) {
    //     this.setState({
    //         showDocHeader: props.key_type,
    //     })
    // }
    removeButton() {

    }
    sandbox() {
        this.removeEditorFrame();
        this.removeWebformFrame();
        state_showDocument = false;
        state_sandbox = true;
        state_showFolder = false;
        state_showMemo = false;
        state_showEditor = false;
        state_showWebform = false;
        this.setState({
            // showFolder: false,
            // showDocument: false,
            // showMemo: false,
            // showEditor: false,
            // sandbox: true,
            // showWebform: false,
        })
    }



    draftStatus(action) {
        switch (action) {
            case 'yes':
            this.state.credentials['cancelPopup'] = 1;
                this.setState({
                    showDraft: false,
                    cancelPopup :1,
                })
                this.logCredentials();
                return;
            case 'no':
            this.state.credentials['cancelPopup'] = 0;
                this.setState({
                    showDraft: false,
                    cancelPopup :0,
                })
                return;
            default:
                this.setState({
                    showDraft: true,
                })
                return;
        }
    }

    logCredentials(type = 0) {
        var editcredentials = JSON.parse(localStorage.getItem('editcredentials'));
        var headercredentials = JSON.parse(localStorage.getItem('headercredentials'));
        if (editcredentials !== null || headercredentials !== null) {
            if (editcredentials !== null && editcredentials.function === 'actionEdit' && headercredentials === null) {
                this.actionEdit(editcredentials.parent_id, editcredentials.parent_type, editcredentials.action, editcredentials.addtype, editcredentials.manual_id, editcredentials.rights, editcredentials.priority, editcredentials.access_details,type,1);
            }
            else {
                this.actionHeader(headercredentials.parent_id, headercredentials.parent_type, headercredentials.action, headercredentials.addtype, headercredentials.manual_id, headercredentials.label, headercredentials.code, headercredentials.rights, headercredentials.priority, headercredentials.access_details);
            }
        }
    }
    updateFolder(manual_id, insert_key = '') {
        if (insert_key != '') {
            if (this.state.activeOpenNode.includes('D')) {
                var result = this.state.activeOpenNode.substring(this.state.activeOpenNode.lastIndexOf("/"));
                var active = this.state.activeOpenNode.replace(result, "");
                this.setState({
                    activeOpenNode: active + '/' + insert_key,
                });
            }
            else {
                this.setState({
                    activeOpenNode: this.state.activeOpenNode + '/' + insert_key,
                });
            }

        }
        let random_num = Math.random();
        this.props.updateManualId(manual_id, random_num);
        let userData = store.getState();
        var url = window.FETCH_MANUALS + '/' + manual_id + '?pid=' + userData.UserData.user_details.person_id;
        datasave.service(url, "GET")
            .then(result => {
                // this.setState({
                //     // folderDetails: result.folderdata,
                //     // sandbox:true,
                //
                // })
                localStorage.setItem('folderDetails', JSON.stringify(result.folderdata));
                this.displayFolder(result.folderdata)
            });
        /*this.state.folderDetails[Object.keys(data)] = data[Object.keys(data)];

        var details = Object.values(data);
        var parent_key = details[0].parent_id_child;
        var child_key = details[0].current_id_child;

        if (parent_key !== undefined) {
            this.state.folderDetails[parent_key].childrens.push(child_key);
        }
        this.displayFolder(this.state.folderDetails)*/
    }

    memoId(type_id, ref_id) {
        this.removeEditorFrame();
        const credentials = {};
        credentials.type_id = type_id;
        credentials.ref_id = ref_id;
        state_showMemo = true;
        this.setState({
            credentials: credentials,
            // showMemo: true,
        })
    }

    memoSaved () {
        state_showMemo = false;
        let userData = store.getState();

        var url = window.FETCH_MANUALS + '/' + this.props.manual_id + '?pid=' + userData.UserData.user_details.person_id;
        datasave.service(url, "GET")
            .then(result => {
                localStorage.setItem('folderDetails', JSON.stringify(result.folderdata));
                this.displayFolder(result.folderdata)
            });
    }
    cancelImport() {
        this.setState({
            showUploadDoc: false
        })
    }
    uploadDocument(doc_id, doc_type, manual_id, current_type, addtype, access_details) {
        const credentials = {};
        credentials.doc_id = doc_id;
        credentials.doc_type = doc_type;
        credentials.manual_id = manual_id;
        credentials.current_type = current_type;
        credentials.addtype = addtype;
        credentials.access_details = access_details;
        this.setState({
            credentials: credentials,
            showUploadDoc: true
        })
    }

    docfilter(e, filter_type) {
        if (filter_type == 'doc_type_id') {
            this.setState({
                doc_type_id: e.target.value,
            }, () => { this.applyFilter() });
        } else {
            this.setState({
                doc_type_status: e.target.value,
            }, () => { this.applyFilter() });
        }
        // this.applyFilter(filter_type,parseInt(e.target.value));
        // localStorage.removeItem('openNodeManual');
        // this.displayFolder(JSON.parse(localStorage.getItem('folderDetails')),filter_type, parseInt(e.target.value));
    }

    applyFilter() {
        const { t } = this.state;
        let filter_type_val = this.state.doc_type_id;
        let filter_status_val = this.state.doc_type_status;
        localStorage.setItem('filter_type_val', filter_type_val);
        localStorage.setItem('filter_status_val', filter_status_val);

        this.displayFolder(JSON.parse(localStorage.getItem('folderDetails')), filter_type_val, filter_status_val, true);
    }
    deleteDocument(doc_id, status, manual_id) {
        const { t } = this.state;
        let iurl = window.GET_USED_DOC_FOR_DOC + '/' + doc_id
        datasave.service(iurl, 'GET').then(
            response => {
                this.setState({
                    usedDocs: response.all,
                    show: response.all.length > 0 ? true : false,
                    mid: manual_id,
                    did: doc_id
                })
                if (response.all.length == 0) {
                    document.getElementById("fde-wrapper").style.display = "none";
                    this.handlePopOk();
                }
            }
        )

    }
    handlePopOk = () => {
        const { t } = this.state;
        let url = window.DELETE_DOC + '/' + this.state.did;
        datasave.service(url, "POST")
            .then(result => {
                this.setState({ show: false })
                this.updateFolder(this.state.mid);
                OCAlert.alertSuccess(t('Document deleted successfully'), { timeOut: window.TIMEOUTNOTIFICATION });

                // alert('Document deleted successfully');
            });
    }
    deleteFolder(fol_id, manual_id) {
        const { t } = this.state;
        let url = window.FOLDER_DELETE + '/' + fol_id;
        datasave.service(url, "PUT")
            .then(result => {
                this.updateFolder(manual_id);
                state_showFolder = false
                OCAlert.alertSuccess(t('Folder deleted successfully'), { timeOut: window.TIMEOUTNOTIFICATION });

                // alert('Folder deleted successfully');
            });
    }

   deleteManual(mid, manual_id) {
        const { t } = this.state;
        let url = window.MANUAL_DELETE + '/' + mid;
        datasave.service(url, "PUT")
            .then(result => {

                if (document.getElementById('manual-link-wrapper') !== null){
                  localStorage.removeItem('manual_id');
                  localStorage.removeItem('editcredentials');
                  localStorage.removeItem('headercredentials');
                  let random_num = Math.random();
                  state_showFolder = false
                  state_showDocument = false;
                  this.props.updateManualId('', random_num);
                  document.getElementById('manual-link-wrapper').click();
                }

                OCAlert.alertSuccess(t('Manual deleted successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
            });
    }

    importWebform(webform_id, manual_id) {
        const credentials = {};
        credentials.webform_id = webform_id;
        credentials.manual_id = manual_id;
        this.setState({
            credentials : credentials,
            showImportWebform : true,
        })
    }
    hideImportWebform() {
        this.setState({
            showImportWebform : false,
        })
    }
    exportWebform(webform_id, manual_id) {
        const credentials = {};
        credentials.webform_id = webform_id;
        credentials.manual_id = manual_id;
        this.setState({
            credentials : credentials,
            showExportWebform : true,
        })
    }
    hideExportWebform() {
        this.setState({
            showExportWebform : false,
        })
    }

    actionEdit(id, parent_type, action, addtype, manual_id, rights = '', priority = '', access_details = [],from = 0,cancelPopup = 0) {
        const credentials = {};
        if (action !== "view" && action !== "edit") {
            clickEventPrevent = true;

        }
       /* this.setState({
            draft: true,
        });*/
        credentials.parent_type = parent_type;
        credentials.parent_id = id;
        credentials.manual_id = manual_id;
        credentials.manual_flag = 1;
        credentials.blanco_id = this.state.blanco_id;
        credentials.action = action;
        credentials.addtype = addtype;
        credentials.rights = rights;
        credentials.priority = priority;
        credentials.function = 'actionEdit';
        credentials.access_details = access_details;
        credentials.cancelPopup = 0;
        credentials.cycle_run = 0;
        localStorage.setItem('editcredentials', JSON.stringify(credentials));
this.removeEditorFrameCommon();
      //  this.removeEditorFrame();
        if (addtype === 'folder') {
          state_showDocument = false;
          state_sandbox = false;
          state_addsite = false;
          state_showFolder = (from === 0 ? true:false);
          state_showMemo = false;
          state_showEditor = false;
          state_showWebform = false;
            this.setState({
                credentials: credentials,
                // showFolder: from === 0 ? true:false,
                // showDocument: false,
                // showMemo: false,
                // showEditor: false,
                // showWebform: false,
                // sandbox: false,
                // addsite : false,
                minimize: false,
                cancelPopup:0,
            })
        }
        else {
          state_showDocument =  (from === 0 ? true:false);
          state_sandbox = false;
          state_addsite = false;
          state_showFolder = false;
          state_showMemo = false;
          state_showEditor = false;
          state_showWebform = false;

            this.setState({
                credentials: credentials,
                minimize: false,
                // showDocument: from === 0 ? true:false,
                // showFolder: false,
                // showMemo: false,
                // showEditor: false,
                // showWebform: false,
                // sandbox: false,
                // addsite:false,
                cancelPopup:cancelPopup,
            })
        }
    }
     actionCycleEdit(id, parent_type, action, addtype, manual_id, rights = '', priority = '', access_details = [],from = 0,cancelPopup = 0,cycle_run = 0,insert_key = '') {
       if (insert_key != '') {
           var activeOpenNode;

             if (this.state.activeOpenNode.includes('D')) {
                 var result = this.state.activeOpenNode.substring(this.state.activeOpenNode.lastIndexOf("/"));
                 var active = this.state.activeOpenNode.replace(result, "");
                 activeOpenNode = active + '/' + insert_key;
             }
             else {
                   activeOpenNode =  this.state.activeOpenNode + '/' + insert_key;
             }
           }
           const credentials = {};
           if (action !== "view" && action !== "edit") {
               clickEventPrevent = true;

           }
           credentials.parent_type = parent_type;
           credentials.parent_id = id;
           credentials.manual_id = manual_id;
           credentials.manual_flag = 1;
           credentials.blanco_id = this.state.blanco_id;
           credentials.action = action;
           credentials.addtype = addtype;
           credentials.rights = rights;
           credentials.priority = priority;
           credentials.function = 'actionEdit';
           credentials.access_details = access_details;
           credentials.cancelPopup = 0;
           credentials.cycle_run = cycle_run;
           localStorage.setItem('editcredentials', JSON.stringify(credentials));

           //this.removeEditorFrame();
           // let random_num = Math.random();
           // this.props.updateManualId(manual_id, random_num);
           let userData = store.getState();
           var url = window.FETCH_MANUALS + '/' + manual_id + '?pid=' + userData.UserData.user_details.person_id;
            datasave.service(url, "GET")
               .then( result => {
                 let data = {};
                 let result_data = result.folderdata;
           if (addtype === 'folder') {
             state_showDocument =  false;
             state_sandbox = false;
             state_addsite = false;
             state_showFolder = (from === 0 ? true:false);
             state_showMemo = false;
             state_showEditor = false;
             state_showWebform = false;
               this.setState({
                   credentials: credentials,
                   // showFolder: from === 0 ? true:false,
                   // showDocument: false,
                   // showMemo: false,
                   // showEditor: false,
                   // showWebform: false,
                   // sandbox: false,
                   // addsite : false,
                   cancelPopup:0,
                   draft: true,
                   // folderDetails: result_data,
                   activeOpenNode:activeOpenNode,
               })
           }
           else {
             state_showDocument = (from === 0 ? true:false);
             state_sandbox = false;
             state_addsite = false;
             state_showFolder = false;
             state_showMemo = false;
             state_showEditor = false;
             state_showWebform = false;
               this.setState({
                   credentials: credentials,
                   // showDocument: from === 0 ? true:false,
                   // showFolder: false,
                   // showMemo: false,
                   // showEditor: false,
                   // showWebform: false,
                   // sandbox: false,
                   // addsite:false,
                   draft: true,
                   cancelPopup:cancelPopup,
                   // folderDetails: result_data,
                   activeOpenNode:activeOpenNode,
               })
           }
           localStorage.setItem('folderDetails', JSON.stringify(result_data));
          this.displayFolder(result_data)
         })


    }
    // handleSetCycleState(latestData) {
    //    this.setState({
    //      blanco_data:latestData,
    //    })
    // }
      handleCycle(id, parent_type, action, addtype, manual_id, rights = '', priority = '', doc_id = '',cycle_run = 0){
       this.actionCycleEdit (id, parent_type, action, addtype, manual_id, rights, priority,[],0,0,cycle_run,doc_id);
     //   this.setState({
     //     doc_type_status:'',
     //     doc_type_id:''
     // })
      //  await this.updateCycleFolder(manual_id, doc_id);
  }

    cancelData() {
        this.draftStatus('');
        //commented because of confirmation of draft status
        // this.setState({
        //     showDocument: false,
        //     showFolder: false,
        //     showMemo: false,
        //     showEditor: false,
        // },() => { this.draftStatus('') });

    }

    onDrop(id, dragable_unique_key, manual_id, current_type, unique_key, parent_id) {
      var draggable_data = dragable_unique_key.document.split(',');
        const { t } = this.state;
        let userData = store.getState();
        var element = document.getElementById("drop");
        element.classList.add("dropabble-style");
        // const data = {
        //     status: window.IMPLEMENTED_DOCUMENT,
        //     web_id: localStorage.getItem('web_id'),
        //     secret_doc_id: dragable_unique_key
        // }
        const unique_details = {
          unique_key : draggable_data[0],
        }
        datasave.service(window.GET_DOCUMENT_USING_UNIQUE_KEY, 'POST', unique_details)
              .then(response => {
          var url = window.FETCH_MANUALS + '/' + response[0]['manual_id'] + '?pid=' + userData.UserData.user_details.person_id + '&sandbox=' + state_sandbox + '&web_id=' + state_web_id + '&url=' + window.backendURL;
          axios.get(process.env.REACT_APP_serverURL + url)
              .then(result => {
                confirmAlert({
                    title: t('Confirm to submit'),
                    message: t('Do you want to copy parent folder?'),
                    buttons: [
                        {
                            label: this.props.t('Yes'),
                            onClick: () => this.handleCopyData(draggable_data[0],manual_id,
                                current_type,unique_key,parent_id,id,result.data.folderdata,draggable_data[1],1)
                        },
                        {
                            label: this.props.t('No'),
                            onClick: () => this.handleCopyData(draggable_data[0],manual_id,
                                current_type,unique_key,parent_id,id,result.data.folderdata,draggable_data[1],0)
                        }
                    ]
                });
            });
          })

    }
    handleCopyData (draggable_id,manual_id,current_type,unique_key,parent_id,id,folderdata,std,status) {
        const drag_and_drop = {
            dragable_unique_key: draggable_id,
            manual_id: manual_id,
            current_type: current_type,
            droppable_unique_key: unique_key,
            dropabble_parent_id: parent_id,
            droppable_id: id,
            tododata: folderdata,
            standard : std,
            status :status
        }
        // if (current_type === 'manual'){
        //     OCAlert.alertWarning(t("can't drop the document on manual"), { timeOut: window.TIMEOUTNOTIFICATION1 });

        // }
        // else{
        datasave.service(window.SANDBOX_STORING, 'POST', drag_and_drop)
            .then(response => {
                if (response === 'Success') {
                    this.updateFolder(drag_and_drop.manual_id)
                    state_sandbox = true;
                    this.setState({
                        // sandbox: true,
                        droppable_status: true
                    })
                }
            })
    }



    change_droppable_status(droppable_status) {
        this.setState({
            droppable_status: droppable_status
        })
    }
    onDragEnter(e) {
        var element = document.getElementById("drop");
        element.classList.add("dropabble-style");
        e.stopPropagation();
        var element = document.getElementById("drop");
        element.classList.add("dropabble-style");
        // this.setState({ hovering : true })
    }
    onDragLeave(e) {
        e.stopPropagation();
        var element = document.getElementById("drop");
        element.classList.remove("dropabble-style");
    }
    actionHeader(id, parent_type, action, addtype, manual_id, label = '', code = '', rights = '', priority = '', access_details = [],from = 0,cycle_run = 0) {
        const { t } = this.state;
        if (action === 'create'){
            clickEventPrevent = true;}
        const credentials = {};
        credentials.parent_type = parent_type;
        credentials.parent_id = id;
        credentials.addtype = addtype;
        credentials.blanco_id = this.state.blanco_id;
        credentials.manual_id = manual_id;
        credentials.manual_flag = 1;
        credentials.action = action;
        credentials.label = label;
        credentials.code = code;
        credentials.rights = rights;
        credentials.priority = priority;
        credentials.access_details = access_details;
        credentials.function = 'actionHeader';
        credentials.cycle_run = cycle_run;
        if (action !== 'create' && action !== 'preview')
            localStorage.setItem('headercredentials', JSON.stringify(credentials));
        state_showDocument =  false;
        state_sandbox = false;
        state_addsite = false;
        state_showFolder = false;
        state_showMemo = false;
        // this.setState({
        //     // showFolder: false,
        //     // showDocument: false,
        //     // showMemo: false,
        //     // sandbox: false,
        //     // addsite:false,
        // })
        this.removeWebformFrame();
        if (addtype === 'folder') {
            this.removeEditorFrame();
            this.removeWebformFrame();
            state_showDocument = false;
            state_sandbox = false;
            state_addsite = false;
            state_showFolder = true;
            state_showMemo = false;
            state_showEditor = false;
            state_showWebform = false;
            this.setState({
                credentials: credentials,
                // showFolder: true,
                // showDocument: false,
                // showMemo: false,
                // showEditor: false,
                // showWebform: false,
                // sandbox: false,
                // addsite:false,
            })
        }
        else if (addtype === 'editor') {
            datasave.service(window.GET_META_DATA + '/' + id, "GET")
                .then(result => {
                    if (result.docpath.length === 0) {
                        datasave.service(window.ADD_DOC_DATA + '/' + id, "GET")
                            .then(response => {
                                if (result.templates.length < 2) {
                                    // alert('No layouts are added');
                                    OCAlert.alertWarning(t('No layouts are added'), { timeOut: window.TIMEOUTNOTIFICATION1 });

                                }
                            })
                    }
                    else if (result.templates.length < 2) {
                        OCAlert.alertWarning(t('Layouts are not properly configured. Try again'), { timeOut: window.TIMEOUTNOTIFICATION1 });
                        // alert('Layouts are not properly configured. Try again.');
                    }
                    else {
                        this.checkDocLockStatus(credentials,result.standards,result.templates,result.docpath[0].doc_path,id,result.docpath[0].doc_type_id,result.file_exists)
                    }
                })
        }
        else if (addtype === "webform") {
            this.updateWebformFrame();
            state_showDocument = false;
            state_sandbox = false;
            state_addsite = false;
            state_showFolder = false;
            state_showMemo = false;
            state_showEditor = false;
            state_showWebform = true;
            this.setState({
                credentials: credentials,
                // showDocument: false,
                // showFolder: false,
                showMemo: false,
                // showEditor: false,
                // showWebform: true,
                editorDocId: id,
                minimize: true,
                // sandbox: false,
                // addsite:false,

            });
        }
        else if (addtype === "preview") {
            datasave.service(window.GET_META_DATA + '/' + id, "GET")
                .then(result => {
                    console.log(result.docpath[0].webform);
                  if (result.docpath[0].webform !== undefined && result.docpath[0].webform === 1) {
                    window.open('/webformaction/' + id + '/1/' + window.FROM_CASE1_activation_cycle + '/0'+ '/0' + '/0' + '/0' + '/0'+ '/0' + '?onlypreview=1', '_blank');
                  }
                  else {
                      console.log(result.docpath[0].corporate);
                    if (result.docpath[0].corporate ==1) {
                        var encr = result.docpath[0].envfilename!=null?btoa(result.docpath[0].envfilename):btoa(window.backendURL+'/');
                        if (result.docpath[0].doc_type_id <= 3) {
                            window.open(window.location.origin + '/previewrevisionentities/' + result.docpath[0].corporate_id+'/'+encr, '_blank');
                        }
                        else if (result.docpath[0].doc_type_id > 3) {
                            this.openDocument(result.docpath[0].corporate_id)
                        }
                    }
                    else{
                        if (result.docpath[0].doc_type_id <= 3) {
                            window.open(window.location.origin + '/previewrevisionentities/' + id, '_blank');
                        }
                        else if (result.docpath[0].doc_type_id > 3) {
                            this.openDocument(id)
                        }
                    }

                  }

                });
        }
        else {
            this.removeEditorFrame();
            this.removeWebformFrame();
            state_showDocument = true;
            state_sandbox = false;
            state_addsite = false;
            state_showFolder = false;
            state_showEditor = false;
            state_showWebform = false;
            this.setState({
                credentials: credentials,
                // showDocument: true,
                // showFolder: false,
                showMemo: false,
                // showEditor: false,
                // sandbox: false,
                // showWebform: false,
                // addsite:false,
            })
        }
    }

    updateEditorFrame() {
        document.getElementById('manualstructure').setAttribute("style", "display:none;");
        document.getElementById('main-content-wrapper-editor').setAttribute("style", "height:100vh;");
        document.getElementById('manual-management-nav').setAttribute("style", "display:none;");
        document.getElementById('manual-list-wrapper-main').setAttribute("style", "display:none;");
        document.getElementById('header-hide-editor').setAttribute("style", "display:none;");
        document.getElementById('side-nav-wrapper-editor').setAttribute("style", "display:none;");
        if (document.getElementById('editor-extra-wrapper') !==  null) {
          document.getElementById('editor-extra-wrapper').setAttribute("class", "col-lg-0 col-md-0");;
          document.getElementById('editor-extra-wrapper').setAttribute("style", "display:none;");
        }
        document.getElementById('fde-wrapper').setAttribute("class", "col-lg-12 col-md-12 float-left px-0 pt-0");
        document.getElementById('fde-wrapper').setAttribute("style", "display:block;");
        if (document.getElementById('office_frame') !== null)
            document.getElementById('office_frame').setAttribute("style", "margin-left: -224px;");
        this.setState({ minimize: true, insertmasterdata: true });

    }
     async checkDocLockStatus(credentials,standards,templates,doc_path,id,doc_type_id,file_exists,from = 1){
       const {t} = this.state
       let userData = store.getState();
        let personid = userData.UserData.user_details.person_id;
        let person_name = userData.UserData.user_details.user_name;
      const data = {
      person_id:personid,
      person_name:person_name,
      doc_id :id,
      entity_id:id
      }
      this.editordocobj = {
        credentials: credentials,
        standards: standards,
        templates: templates,
        docPath: doc_path,
        editorDocId: id,
        doc_type: doc_type_id,
        fileexists: file_exists,
      }
      await  datasave.service(window.DOC_LOCK_STATUS,'POST',data).then(
          result=>{
              if(result.status === 200){
                  if(result.data.is_opened === 0 || result.data.person_id === personid){
                    if(state_showEditor){
                      window.open('/vieweditor/'+JSON.stringify(this.editordocobj)+'/1')
                      return
                    }
              this.updateEditorFrame();
              state_showDocument = false;
              state_sandbox = false;
              state_addsite = false;
              state_showFolder = false;
              state_showEditor = true;
              this.setState({
                  credentials: credentials,
                  // showDocument: false,
                  // showFolder: false,
                  showMemo: false,
                  // showEditor: true,
                  standards: standards,
                  templates: templates,
                  docPath: doc_path,
                  editorDocId: id,
                  doc_type: doc_type_id,
                  fileexists: file_exists,
                  // sandbox: false,
                  // addsite:false,
              },()=>{
                datasave.service(window.LOCK_OPEN_DOC,'POST',data).then(response=>{
                    if(response.status === 500){
                    OCAlert.alertError(t('Error occured while fetching data.'), { timeOut: window.TIMEOUTNOTIFICATION });}
                })

              });
            }else{
            this.RemindToAddSubmitElement(result.data.person_name,0)
            }
            }else{
              OCAlert.alertError(t('Error occured while fetching data.'), { timeOut: window.TIMEOUTNOTIFICATION });
            }
          })
    }
    removeEditorFrameCommon() {

        document.getElementById('manualstructure').setAttribute("style", "display:block;");
        document.getElementById('main-content-wrapper-editor').setAttribute("style", "height:calc(-50px + 100vh);");
        document.getElementById('manual-management-nav').setAttribute("style", "display:block;");
        document.getElementById('manual-list-wrapper-main').setAttribute("style", "display:flex;");
        document.getElementById('header-hide-editor').setAttribute("style", "display:flex;");
        if (document.getElementById('editor-extra-wrapper') !==  null) {
          document.getElementById('editor-extra-wrapper').setAttribute("style", "display:block;");
          document.getElementById('editor-extra-wrapper').setAttribute("class", "col-lg-1 col-md-1");;
        }
        document.getElementById('side-nav-wrapper-editor').setAttribute("style", "display:block;");
        document.getElementById('fde-wrapper').setAttribute("class", "col-lg-7 col-md-7 float-left px-0 pt-0");
        document.getElementById('fde-wrapper').setAttribute("style", "display:block;");
        if (document.getElementById('office_frame') !== null)
            document.getElementById('office_frame').setAttribute("style", "margin-left: -160px;");
    }

    removeEditorFrame(type =0) {
      if(type ==1){
        const {t} = this.state
        let data = {
          entity_id:this.state.editorDocId
        }
          datasave.service(window.REMOVE_LOCK_BY_ENTITY_ID,'POST',data).then(response=>{
              if(response.status === 500){
              OCAlert.alertError(t('Error occured while fetching data.'), { timeOut: window.TIMEOUTNOTIFICATION });}

          })
      }
        this.removeEditorFrameCommon();
        state_showEditor = false;
        this.setState({
           // showEditor: false,
           minimize: false
          });
    }

    minimizeEditorFrame() {
        this.removeEditorFrameCommon();
        this.setState({ minimize: false });
    }
    addmasterdata() {
        document.getElementById('editor-frame-wrapper').setAttribute("class", "col-md-8 col-lg-8 px-0 py-0");
        document.getElementById('fmd-wrapper').setAttribute("style", "display:block;");
        document.getElementById('office_frame').setAttribute("style", "margin-left:-181px");
        this.setState({ insertmasterdata: false });
    }

    closemasterdata() {
        document.getElementById('editor-frame-wrapper').setAttribute("class", "col-md-12 col-lg-12 px-0 py-0");
        document.getElementById('fmd-wrapper').setAttribute("style", "display:none;");
        document.getElementById('office_frame').setAttribute("style", "margin-left:-224px");
        this.setState({ insertmasterdata: true });
    }

    updateWebformFrame() {
        document.getElementById('manualstructure').setAttribute("style", "display:none;");
        document.getElementById('manual-management-nav').setAttribute("style", "display:none;");
        document.getElementById('manual-list-wrapper-main').setAttribute("style", "display:none;");
        document.getElementById('fde-wrapper').setAttribute("class", "col-lg-11 col-md-11 float-left px-0 pt-0");
        document.getElementById('fde-wrapper').setAttribute("style", "display:block;");

        this.setState({ minimizeWebform: true });

    }
    removeWebformFrameCommon() {
        document.getElementById('manualstructure').setAttribute("style", "display:block;");
        document.getElementById('manual-management-nav').setAttribute("style", "display:block;");
        document.getElementById('manual-list-wrapper-main').setAttribute("style", "display:flex;");
        document.getElementById('fde-wrapper').setAttribute("class", "col-lg-7 col-md-7 float-left px-0 pt-0");
        document.getElementById('fde-wrapper').setAttribute("style", "display:block;");
    }

   async removeWebformFrame(close = 0,locked = undefined) {
        if (close === 1) {
            const { editorDocId, t } = this.state;
            let url = window.REMOVE_LOCK_ON_WEBFORM + editorDocId;
           await datasave.service(url, 'GET').then(
                comeback => {
                    if (comeback['status'] == 500) {
                        OCAlert.alertError(t('Error occured while fetching data.'), { timeOut: window.TIMEOUTNOTIFICATION });
                    }
                    (this.content !== this.cloneContent) ? this.showConfirmPopUp() : this.removeWebformFrame();
                })
        } else {
            if(locked !== undefined){
                this.removeWebformFrameCommon();
                state_showWebform = false;
                this.setState({
                   // showWebform: false,
                    minimizeWebform: false
                   },()=>{
                    this.RemindToAddSubmitElement(locked);

                })
            }else{
              this.cloneContent = ''; this.content = ''; this.webformSaveDocId = '';
            this.removeWebformFrameCommon();
            state_showWebform = false;
            this.setState({
              // showWebform: false,
              minimizeWebform: false,
               insertWebformmasterdata : true
              });
            }
        }
    }
    RemindToAddSubmitElement(data,typeid=1) {
        const { t } = this.state;
        let type = typeid === 1?'webform':'document'
        let msg = 'This '+ type +' is currently in use  by';
        let title = 'Unable to open '+type;
        confirmAlert({
            title: t(title),
            message: t(msg)+' '+data,
            buttons: [
                {
                    label: this.props.t('OK'),
                    // onClick: () =>this.removeWebformFrame()
                },
            ]
        });
    }
    close(){
      state_showWebform = true;
      this.setState({
        // showWebform: true,
         minimizeWebform: true
      })
    }
    showConfirmPopUp = () => {
        const { t } = this.state;
           confirmAlert({
            title: t('Unsaved changes'),
            message: t('Do you want to save changes ?'),
            buttons: [
                {
                    label: this.props.t('Yes'),
                    onClick: () => this.SaveWebformData()
                },
                {
                    label: this.props.t('No'),
                    onClick: () => this.removeWebformFrame()
                },
                {
                  label : this.props.t('Cancel'),
                  onClick:() =>this.close()
                }
            ],
        });
    }
    SaveWebformData = () => {
        const data = {
            doc_id: this.webformSaveDocId,
            webform_data: this.content,

        }
        saveWebform.webformSave(data, 0, this.state.t);
        this.removeWebformFrame();
    }
    setWebformDataForPopUpSave = (content, cloneContent, docId) => {
        this.content = content;
        this.cloneContent = cloneContent;
        this.webformSaveDocId = docId;

    }
    minimizeWebform() {
        this.removeWebformFrameCommon();
        this.setState({ minimizeWebform: false });
    }
    addWebformmasterdata() {
        document.getElementById('editor-frame-wrapper').setAttribute("class", "col-md-10 col-lg-10 px-0 py-0");
        document.getElementById('fmd-wrapper').setAttribute("style", "display:block;");
        this.setState({ insertWebformmasterdata: false });
    }

    closeWebformmasterdata() {
        document.getElementById('editor-frame-wrapper').setAttribute("class", "col-md-12 col-lg-12 px-0 py-0");
        document.getElementById('fmd-wrapper').setAttribute("style", "display:none;");
        this.setState({ insertWebformmasterdata: true });
    }
    /*
    * @param data takes the folder object which is to be created.
    * Creates an object with the childrens which is specified in data param and sets to the blanco state.
    */
    displayFolder(data, filter_type_val = '', filter_status_val = '', showfilter = '') {
        let finalData = {};
        let folderData = data;
        var touched_ids = [];
        var linked_folders = [];
        var not_linked_folders = [];
        var doccount = 0;
        Object.keys(folderData).map(function (key) {
            folderData[key].childrens.forEach(function (id) {
                if (((filter_type_val !== '' && filter_type_val !== 99) || (filter_status_val !== '' && filter_status_val !== 99)) && id.includes('D')) {
                    if (filter_type_val !== '' && filter_status_val === '') {
                        if (folderData[id].doc_type_id == filter_type_val) {
                            folderData[key].nodes[id] = folderData[id];
                            linked_folders.push('F' + folderData[id].parent);
                        }
                        else {
                            var index = linked_folders.indexOf('F' + folderData[id].parent);
                            if (index !== -1) not_linked_folders.push('F' + folderData[id].parent);
                        }
                    }
                    else if (filter_type_val === '' && filter_status_val !== '') {
                        if (folderData[id].doc_status == filter_status_val || folderData[id].latest == filter_status_val) {
                            folderData[key].nodes[id] = folderData[id];
                            linked_folders.push('F' + folderData[id].parent);
                        }
                        else {
                            var index = linked_folders.indexOf('F' + folderData[id].parent);
                            if (index !== -1) not_linked_folders.push('F' + folderData[id].parent);
                        }

                    }
                    else {
                        if ((folderData[id].doc_status == filter_status_val || folderData[id].latest == filter_status_val) && folderData[id].doc_type_id == filter_type_val) {
                            folderData[key].nodes[id] = folderData[id];
                            linked_folders.push('F' + folderData[id].parent);
                        } else {
                            var index = linked_folders.indexOf('F' + folderData[id].parent);
                            if (index !== -1) not_linked_folders.push('F' + folderData[id].parent);

                        }
                    }

                    // if(folderData[id].doc_type_id === filter_type_val){
                    //   folderData[key].nodes[id] = folderData[id];
                    // }
                } else {
                    folderData[key].nodes[id] = folderData[id];
                }
                touched_ids.push(id);
            });
            finalData[key] = folderData[key];
        });
        touched_ids.forEach(function (id) {
            delete finalData[id];
        });



        if(filter_type_val !== '' || filter_status_val !== '') {
            var dataArray = {};
            var data = Object.values(finalData)[0].nodes
            var data2 =  Object.values(finalData)[0];

            Object.entries(linked_folders).forEach(([key, value])=> {
              const found = this.dfs(data2,parseInt(value.substring(1)) ); //to iterate found the folder details using dfs
          if (found) {
            //if(linked_folders.includes(key)){
                  dataArray[value] = found;
                  this.filterArrayConstruct(finalData,found , linked_folders, dataArray);
              }
            })
            Object.values(finalData)[0].nodes = dataArray;
        }
        if (showfilter === true)
            this.openNodesFilter(linked_folders, not_linked_folders);
        this.setState({
            // openNodeManual:['M6904/F7006', 'M6904/F6940',  'M6904/F6940/F6955', 'M6904/F6940/F6955/F6964', 'M6904','M6904/F6940'],
            // activeOpenNode:'M6904/F6940/F6955/F6964',
            blanco_data: finalData,
        })
    }

    filterArrayConstruct(finalData, value, linked_folders, dataArray){
        linked_folders = [...new Set(linked_folders)];
        value.childrens.map(item => {
          if(item.includes('F')) {
            if(Object.values(value.nodes).length && !linked_folders.includes(item)){
              delete value.nodes[item];
            }
          }
        })
    }

    openNodesFilter(linked_folders, not_linked_folders) {
        linked_folders = [...new Set(linked_folders)];
        not_linked_folders = [...new Set(linked_folders)];
        var result = not_linked_folders.filter(value => -1 !== linked_folders.indexOf(value));
        var finalresult = arr_diff(not_linked_folders, result);
        var filter_nodes = this.state.nodeList;
        filter_nodes.forEach(function (value, index, array) {
            var inner_key = value.explode('/', '');
            inner_key.forEach(function (value1, index1, array) {
                if (finalresult.includes(value1)) {
                    filter_nodes.splice(index);
                }

            });

        });
        state_openNodeManual = filter_nodes;
        // this.setState({
        //     openNodeManual: filter_nodes
        // });
        localStorage.setItem('openNodeManual', JSON.stringify(filter_nodes));

    }
    onDoubleClickNode = (key_type, current_type, view, type_id, manual_id, rights, priority, access_details, label, code) => {
      //this.singleClick(key_type, current_type, view, type_id, manual_id, rights, priority, access_details, label, code);
      this.clickCount++;
      if (this.clickCount === 1) {
        this.singleClickTimer = setTimeout(function() {
          this.clickCount = 0;
          this.singleClick(key_type, current_type, view, type_id, manual_id, rights, priority, access_details, label, code);
        }.bind(this), 500);

      } else if (this.clickCount === 2) {
        clearTimeout(this.singleClickTimer);
        this.clickCount = 0;
        if (current_type === 'document') {
          this.handleDoubleClick(key_type, current_type, view, type_id, manual_id, rights, priority, access_details, label, code);
        }
      }

    }
    singleClick = (key_type, current_type, view, type_id, manual_id, rights, priority, access_details, label, code) => {
      this.actionEdit(key_type, current_type, view, type_id, manual_id, rights, priority, access_details);
      console.log(type_id);
    }
    handleDoubleClick = (id, current_type, view, type_id, manual_id, rights, priority, access_details, label, code) => {
      this.actionHeader(id, current_type, 'preview', 'preview', manual_id, label, code, access_details);
    }
    onClickNode(key, label, props) {
        // const {key, label, props} = e;
        if (props.current_type === 'document') {
            localStorage.setItem('docID', props.key_type);
        }

        // if(this.state.draft===true){
        //   this.cancelData();
        // }
        if (clickEventPrevent) {
            clickEventPrevent = false;
            return false;
        }
        // Is this needed below we are adding ..
      /*  this.setState({
            activeOpenNode: key,
        }); commented for mutliple set state*/
        if (localStorage.getItem('openNodeManual') !== null ) {
            var opennodes = JSON.parse(localStorage.getItem('openNodeManual'));
        }
        else {
            var opennodes = [];
        }
        if (opennodes !== null && opennodes.includes(key)) {
          var manualId = key.slice(1);
          if(manualId == props.manual_id){
            opennodes = [];
          } else {
            var index = opennodes.indexOf(key);
            if (index !== -1) opennodes.splice(index, 1);
          }
        } else {
          // props.childrens.map(items => {
          //    if(items.includes('F')) {
          //      opennodes.push(key+'/'+items);
          //    }
          // })
          // opennodes.push(key);

          /**Fold unfold code **/
            /*var res = [];
            var value = key.split('/');
            console.log(this.state.blanco_data[value[0]]);
             res = this.recursive(key, this.state.blanco_data[value[0]]['nodes'], res);
             opennodes = res;
             opennodes.push(key);*/

             let blancoData = {...this.state.blanco_data['M'+this.props.manual_id]['nodes']}
             let selectedNodes = [];
             let rec = [];
             if(props.current_type === 'folder') {
              this.findSelectedFolders(props.key_type,blancoData,selectedNodes,props.parent,props.manual_id);
              this.findRecursiveNodes(key, selectedNodes, rec,props.key_type,key);
              opennodes = opennodes.concat(rec);
            }
            // else if(props.current_type === 'manual') {
              // this.findRecursiveNodes(key, blancoData, rec,props.key_type,key);
              // opennodes = rec;
            // }
            opennodes.push(key);
        }
        localStorage.setItem('openNodeManual', JSON.stringify(opennodes));
        localStorage.setItem('activeOpenNode', key);

        state_openNodeManual = opennodes;
        this.setState({
            // openNodeManual: opennodes,
            activeOpenNode: key,
        });

      /*  recursive(key, copyObj, opennodes){
   if(copyObj){
       Object.values(copyObj).map(val => {
         var folderId = key+'/'+'F'+val.key_type;
         opennodes.push(folderId);

         if(val.childrens && val.current_type == 'folder' && val.childrens.length > 0)
            this.recursive(folderId, val.nodes, opennodes);
       })
     }

     return opennodes;
   }*/
        // return false;
       /* this.debouncedClickEvents = this.debouncedClickEvents || [];

        // Each click we store a debounce (a future execution scheduled in 250 milliseconds)
        const callback = _.debounce(_ => {
            // YOUR ON CLICKED CODE

            this.debouncedClickEvents = [];
        }, 500);
        this.debouncedClickEvents.push(callback);

        // We call the callback, which has been debounced (delayed)
        callback();*/
        // We call the callback, which has been debounced (delayed)
    }
    // onDoubleClickNode(key, label, props) {
    //     if (this.debouncedClickEvents.length > 0) {
    //         _.map(this.debouncedClickEvents, (debounce) => debounce.cancel());
    //         this.debouncedClickEvents = [];
    //     }
    //     OCAlert.alertWarning('double click!', { timeOut: window.TIMEOUTNOTIFICATION1 });
    //
    //     // alert('double click');
    // }

    findRecursiveNodes(key, copyObj, opennodes,id,selectNode){
          if(copyObj){
            Object.values(copyObj).map(val => {
              if(val.parent !== null && val.current_type == 'folder' && val.parent === id ){
                let node_key = key;
                node_key = node_key.replace(/[A-Z]/g, '');
                let current_key = val.parent;
                let previous_keys = node_key.split('/');
                let selected_keys = selectNode.replace(/[A-Z]/g, '');
                    selected_keys = selected_keys.split('/');

                if(previous_keys.includes(current_key.toString()) && !selected_keys.includes(current_key.toString())) {
                key = key+'/'+'F'+val.key_type;
              }else{
                key = selectNode+'/'+'F'+val.key_type;
              }
                opennodes.push(key)
;
              }
              if(val.childrens && val.current_type == 'folder' && val.childrens.length > 0)
                 this.findRecursiveNodes(key,val.nodes, opennodes,val.key_type,selectNode);
            })
          }
          return opennodes;
        }
      findSelectedFolders(key, copyObj, selectedNodes,id,manual_id){
    var folderId = key;
    if(copyObj){
       Object.values(copyObj).map(val => {
         const found = this.dfs(val, key);
     if (found) {
       selectedNodes.push(found);
       return found
      }
        else if (val.childrens && val.current_type == 'folder' && val.childrens.length > 0) {
            this.findSelectedFolders(folderId, val.nodes, selectedNodes,val.key_type,manual_id);
          }
       });
     }

     return selectedNodes;
    }
     dfs = (obj, targetId) =>  {
   if (obj.key_type === targetId) {
      return obj;
   }
   if (obj.nodes) {
      for (let item of Object.keys(obj.nodes)) {
         let check: obj | null = this.dfs(obj.nodes[item], targetId);
         if (check) {
            return check;
         }
      }
   }
   return null;
};

    openDocument(doc_id,corporate_url='') {
        const url = window.GET_S3OBJECT_URL + '/' + doc_id;
        datasave.service(url, 'GET', 'doc_id')
            .then(response => {
            if (response[0].webform !== undefined && response[0].webform === 1) {
                if(response[0]["corporate"]==1){
                    var encr = (response[0]["envfilename"]!=null||response[0]["envfilename"]!=undefined||response[0]["envfilename"]!='')?btoa(response[0]["envfilename"]):'';
                    window.open('/webformactionpreview/' + response[0]["corporate_id"] + '/1/' + window.FROM_CASE1_activation_cycle + '/0'+ '/0' + '/0' + '/0'+'/'+encr+'/'+1, '_blank');
                }
                else{
                    window.open('/webformaction/' + doc_id + '/1/' + window.FROM_CASE1_activation_cycle + '/0'+ '/0' + '/0' + '/0' + '/0'+ '/0' + '?onlypreview=1', '_blank');
                }
            }
            else {
                if (response[0]["corporate"]==0) {
                    this.checkIfDocExist(response[0]["file_path"], doc_id)
                }
                else {
                    this.checkIfDocExist(response[0]["file_path"], response[0]["corporate_id"], response[0]["envfilename"])
                }
            }
            });
    }
    checkIfDocExist(response, doc_id, corporate_url='') {
        const { t } = this.state;
        if (response !== null) {
            if(corporate_url=='') {
                window.open('/previewrevisionentities/' + doc_id)
            }
            else{
                console.log(window.backendURL);
                var encr = corporate_url!=null?btoa(corporate_url):btoa(window.backendURL+'/');
                window.open('/previewrevisionentities/' + doc_id+'/'+encr)
            }
        } else {
            OCAlert.alertWarning(t('There is no object available to show preview!'), { timeOut: window.TIMEOUTNOTIFICATION1 });
        }
    }
    // onDragOver = (e) => {
    //     e.stopPropagation();
    //     e.preventDefault();
    // }
    handlehide = () => {
        this.setState(
            { show: false }
        )
    }

    updatecount(){
        this.documentTotalCount()
    }
    render() {
      console.log('blanco_render');
        const { t } = this.state;
        const DEFAULT_PADDING = 3;
        const ICON_SIZE = 4;
        const LEVEL_SPACE = 8;
        const WIDTH = '25px';
        const HEIGHT = '25px';
        const WIDTH_DYNAMIC = 25;
        // const PADDINGTOP = '10px';
    //    const WIDTH_DYNAMIC =' calc(100% - 100px)';
        const DISPLAY = 'inline-flex';
        let droppableStyle = {
            height: '20px',
            width: '100%',
            position: 'absolute',
            color: 'pink'
            // backgroundColor : 'black',
        }
        if (this.state.hovering)
            droppableStyle.backgroundColor = 'pink'
        const ToggleIcon = ({ on }) => <span style={{ marginRight: 4 }} >{on ? '-' : '+'}</span>;
        // const logo_folder = renderhtml('<img  src=' + folderlogo + ' alt="Logo" style="width:7%"  />');
        // const logo_document = renderhtml('<img  src=' + documentlogo + ' alt="Logo" style="marginRight: 5px"  />');
        // const logo_document_status = renderhtml('<img  src=' + documentlogo + ' alt="Logo" style="marginRight: 5px"  />');
        // class={'sprite' + '-' + doc_type }
        const ListItem = ({
            level = 1,
            key,
            // type_id,
            doc_type,
            doc_type_id,
            status,
            rights,
            access_details,
            priority,
            owner,
            parent,
            hasNodes,
            isOpen,
            type_id,
            current_type,
            manual_id,
            label,
            code,
            searchTerm,
            openNodes,
            activeKey,
            doc_status,
            webform,
            latest,
            childrens,
            version,
            unique_key,
            status_icon,
            corporate,
            envfilename,
            corporate_id,
            general_memo,
            private_memo,
            ...props
        }) => (
                <div className="folder-manual-section">
                    <BlancoCan
                        perform={rights}
                        owner={owner}
                        type="view"
                        yes={() => (
                            <ListGroupItem
                                className="left-border list-zindex"
                                {...props}
                                style={{
                                    paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
                                    paddingRight: 0,
                                    cursor: 'pointer',
                                }}
                                key={key}
                            >

                                <div className="list-items-structure" style={{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
                                    {(current_type === 'folder' || current_type === 'document') &&
                                      <Can
                                          perform="R_folder"
                                          yes={() => (
                                          <>
                                            {hasNodes && <ToggleIcon on={isOpen} />}
                                          </>
                                        )}
                                      />
                                    }
                                    {current_type === 'manual' &&
                                      <Can
                                          perform="R_manual"
                                          yes={() => (
                                          <>
                                            {hasNodes && <ToggleIcon on={isOpen} />}
                                          </>
                                        )}
                                      />
                                    }
                                    {!hasNodes && <span style={{ marginRight: 4 }}> &nbsp;</span>}
                                    <div className="droppable-items" style = {{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
                                    <Droppable
                                        id='drop'
                                        types={['document']}
                                        onDrop={(e) => this.onDrop(props.key_type,e,manual_id,current_type,unique_key,parent,type_id,this)}
                                        onDragEnter={this.onDragEnter.bind(this)}
                                        onDragLeave={this.onDragLeave.bind(this)}
                                        onDragOver={(event) => event.preventDefault()}
                                        style = {{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}
                                        // onDragOver={(e) => this.onDragOver(e)}
                                        >
                                            <Can
                                                perform="R_manual"
                                                yes={() => (
                                                <>
                                                  {current_type === 'manual' &&
                                                      <i class="folder-icons folder-icons-accounts" title={t("Manual")} style={{ marginRight: '5px' }}> </i>
                                                  }
                                                </>
                                              )}
                                            />
                                            <Can
                                                perform="R_folder"
                                                yes={() => (
                                                <>
                                                  {current_type === 'folder' &&
                                                      <i class="folder-icons folder-icons-folder" title={t("Folder")} style={{ marginRight: '5px' }}> </i>
                                                  }
                                                  { doc_type_id === 6 && current_type === 'document' &&
                                                    <i class={'folder-icons-webform'} title={"Webform"} style={{ display: DISPLAY, }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id, '', '', access_details)} />
                                                  }
                                                  { doc_type_id !== 6 && current_type === 'document' &&
                                                    <i class={'folder-icons folder-icons-' + doc_type} title={doc_type} style={{ display: DISPLAY, }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id, '', '', access_details)} />
                                                  }
                                                  {/*current_type === 'document' &&
                                                    <i class={'folder-icons folder-icons-' + doc_type} title={doc_type} style={{ display: DISPLAY, }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id, '', '', access_details)} />
                                                  */}
                                                  {current_type === 'document' &&
                                                      <i class={'sprite-document2 sprite-document2-' + status} title={status_icon} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id, '', '', access_details)} />
                                                  }
                                                </>
                                              )}
                                            />

                                            {/* {current_type === 'document' &&
                                                <div className="one" style={{marginLeft: '3px', marginRight: '3px'}}>
                                                <i class="folder-icons folder-icons-menu"></i>
                                                </div>
                                            } */}

                                            {(current_type === 'folder' || current_type === 'document') &&
                                              <Can
                                                  perform="R_folder"
                                                  yes={() => (
                                                    <>
                                                      <div style={{ textAlign: 'center', lineHeight: '100px' }}>{this.state.dropped}</div>
                                                      <span style={{ width: 'inherit', marginBottom: '0px' }}  title={label} className={'folderstructure-label-' + current_type} onClick = {() => this.onDoubleClickNode(props.key_type, current_type, "view", type_id, manual_id, rights, priority, access_details, label, code)}  >
                                                          {label}
                                                      </span>
                                                    </>
                                                )}
                                              />
                                            }
                                            {current_type === 'manual' &&
                                              <Can
                                                  perform="R_manual"
                                                  yes={() => (
                                                    <>
                                                      <div style={{ textAlign: 'center', lineHeight: '100px' }}>{this.state.dropped}</div>
                                                      <span style={{width: 'inherit'}}  title={label} className={'folderstructure-label-' + current_type} onClick = {() => this.onDoubleClickNode(props.key_type, current_type, "view", type_id, manual_id, rights, priority, access_details, label, code)}  >
                                                          {label}
                                                      </span>
                                                    </>
                                                )}
                                              />
                                            }


                                            <div className="version-folder-wrapper">
                                              {current_type === 'document' &&
                                                <Can
                                                  perform="R_folder"
                                                  yes={() => (
                                                    <span className="version-wrapper">
                                                        V-{version}
                                                    </span>
                                                  )}
                                                />
                                              }

                                              {/* } */}
                                              <div className="cfold-dfold">
                                                {(current_type === 'folder' || current_type === 'document') &&
                                                  <Can
                                                      perform="R_folder"
                                                      yes={() => (
                                                        <>
                                                          {current_type !== 'document' && label !== 'Corporate manual' &&
                                                              <Can
                                                                  perform="E_folder"
                                                                  yes={() => (
                                                                      <BlancoCan
                                                                          perform={rights}
                                                                          owner={owner}
                                                                          type="curd"
                                                                          yes={() => (
                                                                              // <img src={addfolder} alt="Logo" title="Add Folder" style={{ height: HEIGHT, width: WIDTH, paddingLeft: 5, paddingRight: 5 }} onClick={this.actionHeader.bind(this, props.key_type, current_type, 'create', 'folder', manual_id)} />
                                                                              <i class="overall-sprite overall-sprite-msfolderc" alt={t("Logo")} title={t("Add folder")} onClick={() => this.actionHeader(props.key_type, current_type, 'create', 'folder', manual_id, '', '', access_details)}></i>
                                                                          )}
                                                                      />
                                                                  )}
                                                              />
                                                          }
                                                        </>
                                                      )}
                                                  />
                                                }
                                                {current_type === 'manual' &&
                                                  <Can
                                                      perform="R_manual"
                                                      yes={() => (
                                                        <>
                                                          {current_type !== 'document' && label !== 'Corporate manual' &&
                                                              <Can
                                                                  perform="E_folder"
                                                                  yes={() => (
                                                                      <BlancoCan
                                                                          perform={rights}
                                                                          owner={owner}
                                                                          type="curd"
                                                                          yes={() => (
                                                                              <i class="overall-sprite overall-sprite-msfolderc" alt={t("Logo")} title={t("Add folder")} onClick={() => this.actionHeader(props.key_type, current_type, 'create', 'folder', manual_id, '', '', access_details)}></i>
                                                                          )}
                                                                      />
                                                                  )}
                                                              />
                                                          }
                                                        </>
                                                      )}
                                                  />
                                                }
                                                <Can
                                                    perform="R_folder"
                                                    yes={() => (
                                                      <>
                                                      {current_type === 'folder' && label !== 'Corporate manual'  &&
                                                          <Can
                                                              perform="E_folder,E_webform"
                                                              yes={() => (
                                                                  <BlancoCan
                                                                      perform={rights}
                                                                      owner={owner}
                                                                      type="curd"
                                                                      yes={() => (
                                                                          // <img src={adddocument} alt="Logo" title="Add Document" style={{ height: HEIGHT, width: WIDTH, paddingLeft: 5, paddingRight: 5 }} onClick={this.actionHeader.bind(this, props.key_type, current_type, 'create', 'document', manual_id)} />
                                                                          <i class="overall-sprite overall-sprite-msdocumentc" alt={t("Logo")} title={t("Add document")} style={{ marginTop: '5px' }} onClick={() => this.actionHeader(props.key_type, current_type, 'create', 'document', manual_id, '', '', access_details)}></i>
                                                                      )}
                                                                  />
                                                              )}
                                                          />
                                                      }

                                                    {current_type === 'folder' && childrens.length === 0 &&
                                                        <Can
                                                            perform="D_folder"
                                                            yes={() => (
                                                                <BlancoCan
                                                                    perform={rights}
                                                                    owner={owner}
                                                                    type="curd"
                                                                    yes={() => (
                                                                        <div style={{ alignSelf: 'center', margin: '0px 5px' }}> <i class="overall-sprite overall-sprite-msdeletec" alt={t("Delete folder")} title={t('Delete folder')} onClick={() => this.deleteFolder(props.key_type, manual_id)}></i> </div>
                                                                    )}
                                                                />
                                                            )}
                                                        />
                                                    }
                                                    </>
                                                  )}
                                                />
                                                <Can
                                                  perform="R_manual"
                                                  yes={() => (
                                                    <>
                                                      {(current_type === 'manual' && childrens.length === 0) && corporate !== 1 &&
                                                          <Can
                                                              perform="D_manual"
                                                              yes={() => (
                                                                  <BlancoCan
                                                                      perform={rights}
                                                                      owner={owner}
                                                                      type="curd"
                                                                      yes={() => (
                                                                          <div style={{ alignSelf: 'center', margin: '0px 5px' }} > <i class="overall-sprite overall-sprite-msdeletec" alt={t("Delete manual")} title={t('Delete manual')} onClick={() => this.deleteManual(props.key_type, manual_id)}></i> </div>
                                                                      )}
                                                                  />
                                                              )}
                                                          />
                                                      }
                                                    </>
                                                  )}
                                                />
                                                {/* <p>{'test'}</p> */}

                                                <Can
                                                    perform="R_folder,R_manual"
                                                    yes={() => (
                                                    <DocumentHeader
                                                        status={doc_status}
                                                        code={code}
                                                        webform={webform}
                                                        propsData={label}
                                                        id={props.key_type}
                                                        current_type={current_type}
                                                        addtype={type_id}
                                                        manual_id={manual_id}
                                                        actionEdit={this.actionEdit}
                                                        memoId={this.memoId}
                                                        uploadDocument={this.uploadDocument}
                                                        actionHeader={this.actionHeader}
                                                        rights={rights}
                                                        priority={priority}
                                                        owner={owner}
                                                        doc_type={doc_type_id}
                                                        deleteDocument={this.deleteDocument}
                                                        openDocument={this.openDocument}
                                                        access_details={access_details}
                                                        addtosites = {this.addToSites}
                                                        corporate = {corporate}
                                                        // status={doc_status}
                                                        sitecount = {state_sitecount}
                                                        importWebform = {this.importWebform}
                                                        exportWebform = {this.exportWebform}
                                                        as4PersonOrNot = {state_as4PersonOrNot}
                                                    />
                                                  )}
                                                />
                                                <span style={{width:'5px'}}></span>
                                                {current_type=='document' && general_memo ==1 &&
                                                    <div><i class="status-sprite status-sprite-gmemoc " alt={t("General memo")} title={t("General memo")} onClick={() => this.memoId(window.public_memo, props.key_type)}></i></div>
                                                }
                                                {current_type=='document' && private_memo ==2 &&
                                                    <div><i class="status-sprite status-sprite-pmemoc" alt={t("Private memo")} title={t("Private memo")} onClick={() => this.memoId(window.private_memo, props.key_type)} ></i></div>
                                                }
                                              </div>
                                         </div>
                                     </Droppable>
                                   </div>
                                </div>
                            </ListGroupItem>
                        )}

                    />

                </div>
            );

        const usedData = this.state.usedDocs.map(item => {
            return (
                <tr>
                    <td>{item.code}</td>
                    <td>{item.name}</td>
                </tr>
            )
        })


        const popup = (
            <reactbootstrap.Modal
                size="lg"
                show={this.state.show}
                onHide={this.handlehide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title">
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">{t('Impact analysis')}</reactbootstrap.Modal.Title>
                </reactbootstrap.Modal.Header>
                    <reactbootstrap.Modal.Body>
                        <reactbootstrap.Table responsive striped bordered hover size="sm">
                            <thead>
                                <tr>
                                    <td>{t('Document code')}</td>
                                    <td>{t('Document name')}</td>
                                </tr>
                            </thead>
                            <tbody>
                                {usedData}
                            </tbody>
                        </reactbootstrap.Table>
                    </reactbootstrap.Modal.Body>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button onClick={() => this.handlehide()}>{t('Cancel')}</reactbootstrap.Button>
                    &nbsp;&nbsp; &nbsp;&nbsp;
                            <reactbootstrap.Button onClick={() => this.handlePopOk()}>{t('Delete')}</reactbootstrap.Button>
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );
        return (
            <div style={{}} className="container-fluid mb-5 pt-2">
                <div className="row">
                    <div className="col-md-1 col-lg-1">
                        <h3 style={{ display: 'none' }}>simple</h3>
                    </div>
                    {popup}
                    <>
                        {/* <div className="container mb-5"> */}
                        <Can
                            perform="R_manual,E_manual,Manual_management,R_sandbox,E_sandbox,AIS_role_sandbox,PRIOR_sandbox,Archive_doc_in_sandbox,Preview_doc_in_sandbox"
                            yes={() => (
                                <>
                                    {/* <div className="page-header">Folder Structure</div> */}
                                    <div id="manualstructure" className="col-lg-4 col-md-4">
                                        {/* <div className="col-md-12"> */}
                                        <div className="manualstructure">
                                            <div className="card">
                                                <div className="manual-title-wrapper header">
                                                    {/* <div className="d-flex col-md-12 "> */}
                                                    <div className=" col-md-12 pr-0">
                                                        <div class="p-0 col-md-6"><span class="head heading py-1 px-2">{t('Manual structure')}</span></div>
                                                        <div style={{ display: 'flex', justifyContent: 'flex-end' }} className="p-0 col-md-6">
                                                            <Can
                                                                perform="R_sandbox,E_sandbox,AIS_role_sandbox,PRIOR_sandbox,Archive_doc_in_sandbox,Preview_doc_in_sandbox"
                                                                yes={() => (
                                                                    <>
                                                                        <div class="py-1 px-0 mr-1 text-white" hidden={parseInt(localStorage.getItem('web_id')) === 0 ? true : false}>
                                                                            <img src={sandboxicon} onClick={this.sandbox.bind(this)}></img>
                                                                        </div>
                                                                        <div class="py-1  px-1 head-right" hidden={parseInt(localStorage.getItem('web_id')) === 0 ? true : false} onClick={this.sandbox.bind(this)}>{t('Manage sandbox')}</div>
                                                                        <div class="py-1  px-1 head-right" hidden={parseInt(localStorage.getItem('web_id')) === 0 ? true : false}>{t('Todo count:')}{state_count}</div>
                                                                    </>
                                                                )}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                {/* <Form.Group> */}
                                                <Can
                                                    perform="R_manual,E_manual,Manual_management"
                                                    yes={() => (
                                                      <div className="row col-md-12 pr-0 mb-2 " >
                                                          <div className="col-md-6 pl-0">
                                                              <InputGroup.Prepend>
                                                                  <InputGroup style={{ background: 'none', border: '0px'}} ><p style={{margin: '5px 0px'}}>{t("Type:")}</p> </InputGroup>
                                                              </InputGroup.Prepend>
                                                              <reactbootstrap.FormControl
                                                                  name="doc_type_id"
                                                                  as='select'
                                                                  value={this.state.doc_type_id}
                                                                  onChange={(e) => this.docfilter(e, 'doc_type_id', this)}
                                                                  // onChange={this.docfilter.bind(this)}
                                                                  className="input_sw"
                                                              >
                                                                  {docs.map(doc_type => <option value={doc_type.id}>{doc_type.name}</option>)}
                                                              </reactbootstrap.FormControl>
                                                          </div>
                                                          <div className="col-md-6 pr-0">
                                                              <InputGroup.Prepend>
                                                                  <InputGroup style={{ background: 'none', border: '0px' }} ><p style={{margin: '5px 0px'}} >{t("Status:")}</p> </InputGroup>
                                                              </InputGroup.Prepend>
                                                              <reactbootstrap.FormControl
                                                                  name="doc_type_status"
                                                                  as='select'
                                                                  value={this.state.doc_type_status}
                                                                  onChange={(e) => this.docfilter(e, 'doc_status', this)}
                                                                  // onChange={this.docfilter.bind(this)}
                                                                  className="input_sw"
                                                              >
                                                                  {window.DOCUMENT_STATUSES.map(doc_type => <option value={doc_type.id}>{doc_type.name}</option>)}
                                                              </reactbootstrap.FormControl>
                                                          </div>
                                                      </div>
                                                    )}
                                                  />
                                                {/* </Form.Group> */}
                                                <TreeMenu
                                                    data={this.state.blanco_data}
                                                    hasSearch='false'
                                                    onClickItem={({ key, label, ...props }) => {
                                                        this.onClickNode(key, label, props);
                                                    }}
                                                    // onDoubleClickItem={({ key, label, ...props }) => {
                                                    //     this.onClickNode(key, label, props);
                                                    // }}
                                                    debounceTime={125}
                                                    activeKey={this.state.activeOpenNode}
                                                    openNodes={state_openNodeManual}
                                                >
                                                    {({ search, items }) => (
                                                        <>
                                                            <Input style={{}} onChange={e => search(e.target.value)} placeholder={t("Type and search")} />
                                                            <div className="sim">
                                                                <Can
                                                                    perform="R_manual,E_manual,Manual_management"
                                                                    yes={() => (
                                                                        <ListGroup className="folder-left-list-group">
                                                                            {items.map(props => (
                                                                                <ListItem {...props} />
                                                                            ))}
                                                                        </ListGroup>
                                                                    )}
                                                                />
                                                                <div style={{ height: '190px', visibility: 'hidden', }}></div>

                                                            </div>
                                                        </>
                                                    )}
                                                </TreeMenu>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="fde-wrapper" style={{ backgroundColor: '#f4f4f4' }} className="col-lg-7 col-md-7 float-left px-0 pt-0">
                                        {state_showFolder &&
                                            <FolderStructure credentials={this.state.credentials}
                                                updateFolder={this.updateFolder.bind(this)}
                                                cancelData={this.cancelData.bind(this)}
                                                 manualid = {this.props.manual_id}
                                            />
                                        }
                                        {state_showDocument &&
                                            <DocumentStructure credentials={this.state.credentials}
                                               cancelPopup = {this.state.cancelPopup}
                                                updateFolder={this.updateFolder.bind(this)}
                                                handleCycle={this.handleCycle.bind(this)}
                                                cancelData={this.cancelData.bind(this)}
                                                actionEdit = {this.actionEdit.bind(this)}
                                            />
                                        }
                                        {state_showMemo &&
                                            <Memo credentials={this.state.credentials}
                                                memoId={this.memoId.bind(this)} memoSaved={this.memoSaved}
                                            />

                                        }
                                        {state_sandbox &&
                                            <SandboxStructure blanco_id={this.props.blanco_id} manual_id={this.props.manual_id} droppable_status={this.state.droppable_status} change_droppable_status={this.change_droppable_status.bind(this)} updatecount={this.updatecount.bind(this)}/>
                                        }
                                        {state_addsite &&
                                            <Hierarchy doc_id={state_doc_id} document_status = {state_document_status}></Hierarchy>
                                        }

                                        {state_showEditor &&
                                            <>

                                                <SmartEditor type={this.state.doc_type} fileexists = {this.state.fileexists} path={this.state.docPath} standards={this.state.standards} templates={this.state.templates} did={this.state.editorDocId} code={this.state.credentials.code} name={this.state.credentials.label.replace(this.state.credentials.code + '-', '')} minimize={this.state.minimize} removeeditor={this.removeEditorFrame} minimizeeditor={this.minimizeEditorFrame} updateeditor={this.updateEditorFrame} addmasterdata={this.addmasterdata} closemasterdata={this.closemasterdata} insertmasterdata={this.state.insertmasterdata} />
                                            </>
                                        }
                                        {
                                            state_showWebform && <>
                                                <BuildWebformNElements
                                                    type={this.state.doc_type}
                                                    path={this.state.docPath}
                                                    standards={this.state.standards}
                                                    templates={this.state.templates}
                                                    did={this.state.editorDocId}
                                                    code={this.state.credentials.code}
                                                    name={this.state.credentials.label.replace(this.state.credentials.code + '-', '')}
                                                    minimizeWebformState={this.state.minimizeWebform}
                                                    removeWebformFrame={this.removeWebformFrame}
                                                    minimizeWebform={this.minimizeWebform}
                                                    updateWebformFrame={this.updateWebformFrame}
                                                    addWebformmasterdata={this.addWebformmasterdata}
                                                    closeWebformmasterdata={this.closeWebformmasterdata}
                                                    insertWebformmasterdata={this.state.insertWebformmasterdata}
                                                    sendDataToBlanco={this.setWebformDataForPopUpSave}
                                                />

                                            </>
                                        }
                                    </div>
                                </>
                            )}
                        />
                    </>
                    {this.state.showUploadDoc &&
                        <ImportDocument
                             showUploadDoc={this.state.showUploadDoc}
                             credentials={this.state.credentials}
                             cancelImport={this.cancelImport.bind(this)}
                             actionEdit = {this.actionEdit.bind(this)}
                             />
                    }

                    {this.state.showDraft &&
                        <Draft draftStatus={this.draftStatus.bind(this)} showDraft={this.state.showDraft} />
                    }
                    {this.state.showImportWebform &&
                      <ImportWebform
                        showImportWebform = {this.state.showImportWebform}
                        hideImportWebform = {this.hideImportWebform.bind(this)}
                        credentials = {this.state.credentials}
                        updateFolder = {this.updateFolder.bind(this)}
                      />
                    }
                    {this.state.showExportWebform &&
                      <ExportWebform
                        showExportWebform = {this.state.showExportWebform}
                        hideExportWebform = {this.hideExportWebform.bind(this)}
                        credentials = {this.state.credentials}
                      />
                    }
                </div>
            </div>
        );
    }
}



export default translate(BlancoStructure)
