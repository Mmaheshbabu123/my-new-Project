import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import {PagePermissions} from '../_components/CanComponent/PagePermissions';
import Pagination from 'react-bootstrap/Pagination';
import {translate} from '../language';

class ManageBlanco extends Component {
    constructor(props) {
        super(props)
        this.state = {
            blanco: [],
            items:[],
            searchTerm:'',
            id:'',
            page: 5,
            count: 0,
            active: 1,
            filterFullList: [],
            t:props.t,
        }
        this.searchData = this.searchData.bind(this);
    }
    componentDidMount() {
        var url = window.GET_BLANCO_DETAILS;
        datasave.service(url, "GET")
            .then(result => {
              const pageData = this.getPageData(1, result);
              const count = this.getCountPage(result);
                this.setState({
                    blanco: result,
                    count: count,
                    items : pageData,
                })
            });
    }
    componentDidUpdate(prevProps, prevState) {
        if (prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
            datasave.service(window.GET_BLANCO_DETAILS, 'GET', '')
                .then(response => {
                        const pageData = this.getPageData(this.state.active, response);
                        const count = this.getCountPage(response);
                        this.setState({
                            blanco: response,
                            items :pageData,
                            count: count,
                        })
                });
        }
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }
    componentWillMount() {
        this.setState({ items: this.state.blanco })
    }
    searchData(e) {
        var list = [...this.state.blanco];
        list = list.filter(function (item) {
            if (item.name !== null) {
                return item.name.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
        });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    changePage(e, id = 1) {
        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);
        this.setState({
            items : page_data,
            active: id,
        });
    }
    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.blanco;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;
    }

    render() {
        const as4_or_site = PagePermissions()
        const { blanco,t } = this.state
        const filtered = this.state.items;
        let active = this.state.active;
        let pages = [];
        if(this.state.count > 0)
        {
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }
        }

        if (as4_or_site) {
            return (
                <Can
                    perform = "E_manual,R_manual"
                    yes = {() => (
                    <div className='container py-4'>
                        <div className='row justify-content-center'>
                            <div className='col-md-9'>
                                <div className='card'>
                                    <div className='card-header'>{t('All Blancos')}</div>
                                    <div className='card-body'>
                                    <input type="text" className="search-input" placeholder={t("Search")} onChange={this.searchData} />
                                        <reactbootstrap.Table responsive>
                                            <thead>
                                                <tr>
                                                    <th>{t('Name of Blanco')}</th>
                                                    <th colspan="2">{t('Actions')}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {filtered.map(blancoItem => (
                                                    <tr>
                                                        <td>{blancoItem.name}</td>
                                                        <td>
                                                            <Can
                                                                perform="E_manual"
                                                                yes={() => (
                                                                    <Link
                                                                        to={`/blanco/manual/${blancoItem.id}`}
                                                                        key={blancoItem.id}
                                                                    >
                                                                        {t('Edit')}
                                                                    </Link>
                                                                )}
                                                            />
                                                             <br></br>
                                                            <Can
                                                                perform="R_manual"
                                                                yes={() => (
                                                                    <Link
                                                                        to={`/blanco/${blancoItem.id}`}
                                                                        key={blancoItem.id}
                                                                    >
                                                                        {t('View')}
                                                                    </Link>
                                                                )}
                                                            />
                                                        </td>

                                                    </tr>
                                                ))}
                                            </tbody>
                                        </reactbootstrap.Table>
                                        <Pagination size="md">{pages}</Pagination>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    )}
                    no = {() =>
                        <AccessDeniedPage/>
                    }
                />
            )
        }
        else {
          return(
              <AccessDeniedPage />
          )
        }
    }
}

export default translate(ManageBlanco);
