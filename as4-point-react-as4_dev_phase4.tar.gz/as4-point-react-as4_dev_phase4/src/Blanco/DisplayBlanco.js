
import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import folderlogo from './folder-icon.png';
import documentlogo from './document-logo.png';
import TreeMenu from 'react-simple-tree-menu'
import renderhtml from 'react-render-html';
import { Button, Container, Form, FormGroup, Input, Label, ListGroup, ListItem, ListGroupItem } from 'reactstrap';
import {translate} from '../language';


class DisplayBlanco extends Component {
    constructor(props) {
        super(props)
        this.state = {
            blanco_data: [],
            t:props.t,
        }
    }
    componentDidMount() {
        var url = window.FETCH_FOLDER + '/' + this.props.match.params.id;
        datasave.service(url, "GET")
            .then(result => {
                this.displayFolder(result)
            });

    }


    /*
    *@param data takes the folder object which is to be created.
    * Creates an object with the childrens which is specified in data param and sets to the blanco state.
    */
    displayFolder(data) {
        let finalData = {};
        let folderData = data;
        var touched_ids = [];
        Object.keys(folderData).map(function (key) {
            folderData[key].childrens.forEach(function (id) {
                folderData[key].nodes[id] = folderData[id];
                touched_ids.push(id);
            });
            finalData[key] = folderData[key];
        });
        touched_ids.forEach(function (id) {
            delete finalData[id];
        });
        this.setState({
            blanco_data: finalData,
        })
    }
    render() {
        const {t} = this.state;
        const DEFAULT_PADDING = 16;
        const ICON_SIZE = 8;
        const LEVEL_SPACE = 16;
        const WIDTH = '9%';
        const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }}>{on ? '-' : '+'}</span>;
        const folder_logo = renderhtml('<img  src=' + folderlogo + ' alt="Logo" style="width:5%" />');
        const document_logo = renderhtml('<img  src=' + documentlogo + ' alt="Logo" style="width:5%" />');
        // <ListGroupItem onClick={this.getButton}> {logo} </ListGroupItem>
        const ListItem = ({
            level = 0,
            key,
            hasNodes,
            isOpen,
            type_id,
            current_type,
            manual_id,
            label,
            searchTerm,
            openNodes,
            ...props

        }) => (
                < div >
                    <ListGroupItem
                        {...props}
                        style={{
                            paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
                            cursor: 'pointer',
                        }}
                        key={key}
                    >
                        {hasNodes && <ToggleIcon on={isOpen} />}
                        {type_id == 'folder' && folder_logo}
                        {type_id == 'document' && document_logo}
                        {label}
                    </ListGroupItem>
                </div >
            );
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-lg-12">
                        <div className="page-header">{t('Blanco Structure')}</div>
                        <TreeMenu
                            data={this.state.blanco_data}
                            onClickItem={({ key, label, ...props }) => {
                                // this.navigate(props.url); // user defined prop
                            }}
                            debounceTime={125}>
                            {({ search, items }) => (
                                <>
                                    <ListGroup>
                                        {items.map(props => (
                                            <ListItem {...props} />
                                        ))}
                                    </ListGroup>
                                </>
                            )}
                        </TreeMenu>
                    </div>
                </div>
            </div>
        )
    }
}

export default translate(DisplayBlanco)
