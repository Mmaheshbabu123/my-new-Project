import React, { Component } from 'react';
import { datasave } from '../_services/db_services';
import BlancoComponent from '../_components/BlancoComponent';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import {PagePermissions} from '../_components/CanComponent/PagePermissions';
import { translate } from '../language';

const mandatory_fields = ['name', 'standards'];

class Blanco extends Component {
    constructor(props) {
        super(props)
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this)
        this.handleCancel = this.handleCancel.bind(this)
        this.state = {
            name: '',
            submitted: false,
            error: [],
            standards: [],
            options: [],
            t: props.t,

        }
    }

    handleCancel(event) {
        const { history } = this.props
        if (this.props.match.params.id) {
            history.push('/manage-manual')
        } else {
            history.push('/ifo')
        }
    }

    componentDidMount() {
        var url = '';
        if (this.props.match.params.id) {
            url = window.GET_MANUAL + '/' + this.props.match.params.id;
            datasave.service(url, "GET")
                .then(result => {
                    this.setState({
                        name: result.name,
                        clone:result.name,
                        type: result.type,
                        standards: result.standards,
                    })
                });
        }
        url = window.GET_STANDARDS;
        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    options: result,
                })
            });
    }

    formSave() {
      const {t} = this.state;
        var url;
        const { history } = this.props;
        if (this.props.match.params.id) {
            url = window.INSERT_MANUAL + '/' + this.props.match.params.id;
            datasave.service(url, "PUT", this.state)
                .then(result => {
                    if (result !== 'success') {
                        this.setState({
                            error: result.name,
                        })
                    }
                    else {
                        history.push('/manage-manual');
                    }
                });
        }
        else {
            url = window.INSERT_BLANCO;
            datasave.service(url, "POST", this.state)
                .then(result => {
                    if (result == 1) {
                        this.setState({
                            error: t('name already exits'),
                        })
                    }
                    else {
                    history.push('/blanco/manual/' + result);
                     }
                });
        }
    }
    handleSubmit = (event) => {
        var formvalid = true;
        this.setState({
            submitted: true,
        })
        for (var i = 0; i < mandatory_fields.length; i++) {
            if (this.state[mandatory_fields[i]].length === 0) {
                formvalid = false;
            }
        }

        if (formvalid)
            this.formSave();
    }
    handleChange(event) {
        if (event.target === undefined) {
            this.setState({ standards: event });
        }
        else {
            const { name, value } = event.target;
            this.setState({ [name]: value,error:'' });
        }
    }
    render() {
        const as4_or_site = PagePermissions()

        if (as4_or_site) {
            return (
                <Can
                    perform="E_manual"
                    yes={() => (
                        <BlancoComponent
                            handleChange={this.handleChange.bind(this)}
                            handleSubmit={this.handleSubmit.bind(this)}
                            handleCancel={this.handleCancel.bind(this)}
                            name={this.state.name}
                            error={this.state.error}
                            submitted={this.state.submitted}
                            standards={this.state.standards}
                            options={this.state.options}
                            handleprops={this.props}
                        />
                    )}
                    no={ () =>
                        <AccessDeniedPage/>
                    }
                />
            );
        }
        else {
          return(
              <AccessDeniedPage />
          )
        }

    }

}

export default translate(Blanco)
