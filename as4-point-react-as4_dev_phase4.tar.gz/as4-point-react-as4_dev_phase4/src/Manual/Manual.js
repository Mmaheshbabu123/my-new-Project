import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import ManualComponent from '../_components/manualComponent';
import { translate } from '../language';
const mandatory_fields = ['name', 'standards'];

class Manual extends Component {
    constructor(props) {
        super(props)
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this)
        this.handleCancel = this.handleCancel.bind(this)
        this.state = {
            name: '',
            submitted: false,
            error: [],
            standards: [],
            type: '',
            options: [],
            t:props.t,
        }
    }

    handleCancel(event) {
        const { history } = this.props
        if (this.props.match.params.id) {
            history.push('/manage-manual')
        } else {
            history.push('/ifo')
        }
    }

    componentDidMount() {
        if (this.props.match.params.id) {
            var url = window.GET_MANUAL + '/' + this.props.match.params.id;
            datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    name: result.name,
                    type: result.type,
                    standards: result.standards,
                })
            });
        }
        var url = window.GET_STANDARDS;
        datasave.service(url, "GET")
        .then(result => {
            this.setState({
                options: result,
            })
        });
    }

    formSave() {
        const { history } = this.props;
        if (this.props.match.params.id) {
            var url = window.INSERT_MANUAL + '/' + this.props.match.params.id;
            datasave.service(url, "PUT", this.state)
                .then(result => {
                    if (result != 'success') {
                        this.setState({
                            error: result.name,
                        })
                    }
                    else {
                        history.push('/manage-manual');
                    }
                });
        }
        else {
            var url = window.INSERT_MANUAL;
            datasave.service(url, "POST", this.state)
                .then(result => {
                    if (result != 'success') {
                        this.setState({
                            error: result.name,
                        })
                    }
                    else {
                        history.push('/manage-manual');
                    }
                });
        }
    }
    handleSubmit = (event) => {
        var formvalid = true;
        this.setState({
            submitted: true,
        })
        for (var i = 0; i < mandatory_fields.length; i++) {
            if (this.state[mandatory_fields[i]].length === 0) {
                formvalid = false;
            }
        }

        if (formvalid)
            this.formSave();
    }
    handleChange(event) {
        if (event.target == undefined) {
            const { value } = event;
            this.setState({ standards: event });
        }
        else {
            const { name, value } = event.target;
            this.setState({ [name]: value });
        }
    }
    render() {
        return (
            <ManualComponent
                handleChange={this.handleChange.bind(this)}
                handleSubmit={this.handleSubmit.bind(this)}
                handleCancel = {this.handleCancel.bind(this)}
                name={this.state.name}
                error={this.state.error}
                type={this.state.type}
                submitted={this.state.submitted}
                standards={this.state.standards}
                options={this.state.options}
                handleprops={this.props}

            />
        );
    }


}
export default translate(Manual)
