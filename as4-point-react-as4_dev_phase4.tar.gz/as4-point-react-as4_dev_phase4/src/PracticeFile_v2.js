import React, { Component , useEffect, useState} from 'react';
import Chart from 'react-google-charts';
import { datasave } from './_services/db_services';
import { AgGridReact } from 'ag-grid-react';
import { persistor, store } from '../src/store';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import Plot from 'react-plotly.js';




const PracticeFile_v2 = props =>{
 const [nameArray, setNameArray] = useState([]);
	const [sample, setSample] = useState(0);
  var refCount = 0;
/*		const [count, setCount] = useState(0);
	useEffect(()=>{
		console.log(count);
		const tempFunc = async()=>{
		  if(parseInt(count) === 0){
	  	    await updateSubmitDateElementValue();
		  }
		}
		tempFunc();
	})

async function updateSubmitDateElementValue(){
	await datasave.service(window.TEMPERORY_UPDATE1, 'GET').then(
            async result => {
              if(result['status'] == 200){
                OCAlert.alertSuccess(result['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
	      }else{
                OCAlert.alertError(result['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
	      }
	      setCount(1);
	    })
	}

*/

        useState(()=>{
		const temp = async() =>{
	          await tokenServiceFunc();
		}
		temp();
	})
async function tokenServiceFunc(){
    //    await datasave.service(window.SELECTED_TOKENS + '/' + 9251 + '/' + 99   , 'GET').then(
        await datasave.service('/api/qr-code-g', 'GET').then(
            async result => {
            })
        }


	var trace1 = {
  x: ['2020-07-24', '2020-08-17'],
  y: [334, 607],
  mode: 'markers',
  name: "decimal1",
  type: 'bar'
};

var trace2 = {
  x: ['2020-07-24', '2020-08-17'],
  y: [333, 123],
   mode: "markers",
   name: "decimal2",
   type: 'bar'
};

	return (
	<div className = {'Container'} style= {{'margin-left': '100px'}}>
		<Plot
        data={[trace1]}
      />
		</div>
	);
}

export default PracticeFile_v2;
