import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { PagePermissions } from '../_components/CanComponent/PagePermissions';
import {translate} from '../language';

class EmailList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            emails: [],
            t:props.t,
        }
        this.handleDelete = this.handleDelete.bind(this);
    }
    handleDelete(id, e) {
        datasave.service(window.DELETE_EMAIL + id, 'PUT', '')
            .then(response => {
                if (response === 1) {
                    window.location.reload()
                }
            })
    }
    componentDidMount() {
        var url = window.EMAILLIST;
        datasave.service(url, 'GET', '')
            .then(response => {
                this.setState({
                    emails: response,
                })
            });
    }
    render() {
        const as4_or_site = 1;//PagePermissions()
        const { emails,t } = this.state;

        /*<Can
          perform="E_email,D_email,R_email"
          yes={() => (
          )}
          no={ () =>
              <AccessDeniedPage/>
          }
        />*/
        /*  <Can
            perform = "E_email"
            yes = {() => (
        )}
      />*/

        // if (as4_or_site) {
          return (
              <div className='container py-4' >
                  <div className='row justify-content-center' >
                      <div className='col-md-12' >
                          <div className='card' >
                              <form method='POST'>
                                  <reactbootstrap.Table responsive>
                                      <thead>
                                          <tr>
                                              <th>{t('Name')}</th>
                                              <th>{t('Actions')}</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                          <div style={{ textAlign: 'center' }} className="error-block">{this.state.error}
                                          </div>
                                          {this.state.emails.map(
                                              function (email) {
                                                  return (
                                                      <tr>
                                                          <td>{email.name}</td>
                                                          <td>

                                                                  <Link
                                                                      to={`/appsettings/email/${email.id}`}
                                                                      key={email.id}
                                                                  >
                                                                      {t('Edit')}
                                                                  </Link>

                                                          </td>
                                                          {/*<td>
                                                            <Can
                                                              perform = "D_email"
                                                              yes = {() => (
                                                                <a href='#'
                                                                    onClick={this.handleDelete.bind(this, email.id)}
                                                                >
                                                                    {t('Delete')}
                                                                </a>
                                                              )}
                                                            />
                                                            <br></br>
                                                          </td>*/}
                                                      </tr>
                                                  )
                                              }, this)
                                          }
                                      </tbody>
                                  </reactbootstrap.Table>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>

          )
        // }
        // else {
        //   return(
        //       <AccessDeniedPage />
        //   )
        // }
    }
}

export default translate(EmailList);
