import React, { Component } from 'react';
import { Button, Form, FormGroup, InputGroup } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { datasave } from '../_services/db_services';
import * as reactbootstrap from 'react-bootstrap'
import MultiSelect from '../_components/MultiSelect';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { exists } from 'fs';
import { PagePermissions } from '../_components/CanComponent/PagePermissions';
import {translate} from '../language';

class Email extends Component {
  constructor(props) {
    super(props)
    this.state = {
      name: '',
      description: '',
      token: '',
      selected_tokens: '',
      email_token_options: [],
      selected_email_tokens: [],
      id: [],
      name_error: '',
      description_error: '',
      email_unique_id_error: '',
      t:props.t,
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleMultiSelect = this.handleMultiSelect.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
  }

  handleChange(event) {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
      name_error: '',
    });
  }
  handleSubmit(event) {
    event.preventDefault();
    this.setState({ submitted: true });
    const { history } = this.props
    const details = {
      name: this.state.name,
      description: this.state.description,
      email_unique_id: this.state.token,
      selected_email_tokens: this.state.selected_email_tokens,
      id: this.props.match.params.id,
    }
    if (this.props.match.params.id) {
      datasave.service(window.UPDATE_EMAIL + '/' + details.id, 'PUT', details)
        .then(response => {
          if (response.name || response.description || response.email_unique_id) {
            this.setState({
              name_error: response.name,
              description_error: response.description,
              email_unique_id_error: response.email_unique_id,
            })
          } else {
            history.push('/appsettings/email-list')
          }
        })
        .catch(error => {
          this.setState({
            errors: error.response.data.errors
          })
        })
    }
    else {
      datasave.service(window.EMAIL, 'POST', details)
        .then(response => {
          if (response.name || response.description || response.email_unique_id) {
            this.setState({
              name_error: response.name,
              description_error: response.description,
              email_unique_id_error: response.email_unique_id,
            })
          }
          else {
            history.push('/appsettings/email-list')
          }
        })
        .catch(error => {
          this.setState({
            errors: error.response.data.errors
          })
        })
    }
  }
  handleCancel(e) {
    const { history } = this.props
    history.push('/appsettings/email-list')
  }
  componentDidMount() {
    datasave.service(window.EMAILTOKENS, 'GET', '')
      .then(result => {
        this.setState({
          email_token_options: result,
        })
      });
    if (this.props.match.params.id) {
      const details = {
        id: this.props.match.params.id
      }
      datasave.service(window.GET_EMAILDATA + details.id, 'GET')
        .then(response => {
          this.setState({
            name: response.email_data[0]['email_name'],
            description: response.email_data[0]['email_desc'],
            token: response.email_data[0]['email_uniq'],
            selected_email_tokens: response.email_token_data,
          })
        });
    }
  }

  handleMultiSelect(event) {
    this.setState({
      selected_email_tokens: event,
    })
  }

  render() {
    const as4_or_site = 1;//PagePermissions()
    const { name_error,t, description_error, email_unique_id_error, loading } = this.state

  /*  <Can
      perform="E_email,R_email,D_email"
      yes={() => (

      )}
      no={() =>
        <AccessDeniedPage />
      }
    />*/

    // if (as4_or_site) {
      return (
        <div className=" row">
            <div style={{visibility: 'hidden'}} className="col-md-1"><p>{t('welcome')}</p></div>
            <div style={{marginLeft: '-1.5rem'}} className='col-md-11' >
              <div className='row justify-content-center' >
                <div className='col-md-9 mt-5 mb-5' >
                  <div className='card' >
                    <div className="container-fluid pb-3">
                      <Link className="float-right"
                        to={'/appsettings/email-list'}
                      >
                        <div className="mt-3">
                          {t('Email list')}
                      </div>
                      </Link>
                      <div className="mt-4 p-3">
                        <FormGroup>
                          <reactbootstrap.Form method="post">
                            <reactbootstrap.FormGroup controlId="EmailName">
                              <div className=" row input-overall-sec ">
                                <div className="col-md-4">
                                  <reactbootstrap.FormLabel style={{ padding: '8px', color: '#EC661C' }}>
                                    {t('Name')}:<span style={{ color: "red", }}>*</span>
                                  </reactbootstrap.FormLabel>
                                </div>
                                <div class="col-md-8 input-padd">
                                  <reactbootstrap.FormControl className="input_sw" type="textbox" name="Email name" value={this.state.name} placeholder={t("Enter name")} onChange={e => this.setState({ name: e.target.value, name_error: '' })} />

                                  <div style={{ color: 'red' }} className="error-block mt-2">{name_error}</div>
                                </div>

                              </div>
                            </reactbootstrap.FormGroup>
                            <reactbootstrap.FormGroup controlId="EmailDescription">
                              <div className=" row input-overall-sec ">
                                <div className="col-md-4">
                                  <reactbootstrap.FormLabel style={{ padding: '8px', color: '#EC661C' }}>{t('Description')}:<span style={{ color: "red" }}>*</span></reactbootstrap.FormLabel>
                                </div>
                                <div class="col-md-8 input-padd">
                                  <reactbootstrap.FormControl className="input_sw" as="textarea" rows="6" name="Email description" value={this.state.description} placeholder={t("Enter description")} onChange={e => this.setState({ description: e.target.value, description_error: '' })} />
                                  <div style={{ color: 'red' }} className="error-block mt-2">{description_error}</div>
                                </div>
                              </div>
                            </reactbootstrap.FormGroup>
                            <reactbootstrap.FormGroup controlId="EmailToken">
                              <div className=" row input-overall-sec ">
                                <div className="col-md-4">
                                  <reactbootstrap.FormLabel style={{ padding: '8px', color: '#EC661C' }}>{t('Email unique id')}:<span style={{ color: "red" }}>*</span></reactbootstrap.FormLabel>
                                </div>
                                <div class="col-md-8 input-padd">
                                  <reactbootstrap.FormControl className="input_sw" type="textbox" name="Email token" value={this.state.token} placeholder="Email unique id" onChange={e => this.setState({ token: e.target.value, email_unique_id_error: '' })} />
                                  <div style={{ color: 'red' }} className="error-block mt-2">{email_unique_id_error}</div>
                                </div>
                              </div>
                            </reactbootstrap.FormGroup>
                            <reactbootstrap.FormGroup>
                              <div className=" row input-overall-sec ">
                                <div className="col-md-4">
                                  <reactbootstrap.FormLabel style={{ padding: '8px', color: '#EC661C' }} >{t('Select tokens')}: </reactbootstrap.FormLabel>
                                </div>
                                <div class="col-md-8 input-padd">
                                  <div className="input_sw">
                                    <MultiSelect
                                      options={this.state.email_token_options}
                                      standards={this.state.selected_email_tokens}
                                      handleChange={(e) => this.handleMultiSelect(e)}
                                    />
                                  </div>
                                </div>
                              </div>
                            </reactbootstrap.FormGroup>
                            <div style={{ float: 'right' }} className="organisation_list">
                            <a onClick={this.handleCancel} > {t('Cancel')} </a>
                            &nbsp;&nbsp;&nbsp;
                              <Button style={{fontSize: '14px'}} className="btn btn-primary" disabled={loading} onClick={this.handleSubmit}>{t('Save')}</Button>
                            </div>
                          </reactbootstrap.Form>
                        </FormGroup>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      );
    // }
    // else {
    //   return(
    //       <AccessDeniedPage />
    //   )
    // }
  }
}
export default translate(Email)
