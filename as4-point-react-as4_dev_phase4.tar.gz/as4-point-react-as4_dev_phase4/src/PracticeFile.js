import React, { Component } from 'react';
import { datasave } from './_services/db_services';
import { AgGridReact } from 'ag-grid-react';
import { persistor, store } from '../src/store';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import Chart from 'react-google-charts';
import Plot from 'react-plotly.js';
//import ResizePanel from "react-resize-panel";
import {Resizable, ResizableBox} from 'react-resizable';
import "react-resizable/css/styles.css";
//import "./PracticeFile.css";
class PracticeFile extends Component {
  constructor(props) {
    super(props);
        this.state = {
    }
  }

  getChart=()=>{
    return (<Chart
    width={1000}
    height={500}
    chartType="ColumnChart"
    loader={<div>Loading Chart</div>}
    data={[
      ['City', '2010 Population', '2000 Population'],
      ['New York City, NY', 8175000, 8008000],
      ['Los Angeles, CA', 3792000, 3694000],
      ['Chicago, IL', 2695000, 2896000],
      ['Houston, TX', 2099000, 1953000],
      ['Philadelphia, PA', 1526000, 1517000],
    ]}
    options={{
      title: 'Population of Largest U.S. Cities',
      chartArea: { width: '30%' },
      hAxis: {
        title: 'Total Population',
        minValue: 0,
      },
      vAxis: {
        title: 'City',
      },
    }}
    legendToggle
  />);
  }
  render(){
  return (<div>{this.getChart()}</div>);
 }

componentDidMount(){
//window.UPDATE_PARENT_CHILD
	//datasave.service(`${window.UPDATE_PARENT_CHILD}${'/1848/8760'}`, 'GET').then(
//	datasave.service(`${window.CALCULATE_KPI_FREQUENCY}${'/48'}`, 'GET').then(
//	datasave.service(`${window.GET_ALL_ELEMENT_SUBMIT_DETAILS}${'/11169'}`, 'GET').then(
       // datasave.service(window.GET_TODO_BY_DETAILS + '/' + 11134 + '/' + 55070 + '/' + 3726 , 'GET').then(
//	datasave.service(window.QUERY_EXECUTE_FUNC + '/' + 2067 , 'GET').then(
	//datasave.service(window.GET_BLOCKBOX_REPORTS + '/' + 11144 , 'GET').then(
//		datasave.service(`${window.INSERT_TARGET_AND_ACTUAL}`, 'GET').then(
//window.GET_LATEST_SUBMIT
//	datasave.service(`${window.GET_SUBMIT + '/' + 56585 + '/' + 11276 + '/' + 0}`, 'GET').then(
//	datasave.service(`${window.GET_REPORT_REQUIRED_DETAILS}`, 'GET').then(
//	datasave.service(`${window.window.SELECTED_TOKENS + '/' + 11276 + '/' + 56586}`, 'GET').then(
//	let webform_id = 12523;
///	let submit_id = 15307;
//	let step_id = 4584;
		
		//datasave.service(`${window.INSERT_TARGET_AND_ACTUAL_REFTABLE + '/' + 798}`, 'GET').then(
//		datasave.service(window.SELECTED_TOKENS + '/' + 99 + '/' + 10080 +  '/' +  2845, 'GET').then(
//	datasave.service(window.GET_TODO_BY_DETAILS + '/' + webform_id + '/' + submit_id + '/' + step_id , 'GET').then(
//	result => { });
	datasave.service(window.INSERT_SUBMIT_USERS , 'GET').then(
	result => { });
}

}
export default PracticeFile;
