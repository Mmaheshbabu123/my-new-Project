import React, { Component } from 'react'
import * as reactbootstrap from "react-bootstrap";
import { FormGroup } from 'react-bootstrap';
import * as Reactbootstrap from 'react-bootstrap'
import DatePicker from "react-datepicker";
import { datasave } from '../_services/db_services';
import BaseSelect from 'react-select';
import SignaturePad from '../Webforms/WebElements/Signature/Signature';
import { store } from '../store'
import calendericon from '../Webforms/Simulation/Webelements/calender.png';
import question from '../Webforms/Simulation/Webelements/question.png';
import axios from 'axios';
import FilesList from '../Webforms/Simulation/Webelements/FilesList';
import Timerexample from '../Webforms/WebElements/Timersimulate';
import Stopwatch from '../Webforms/WebElements/stopwatchsimulate';
import ChildformSimulate from '../Webforms/ChildformSimulate';
import ChildNormal from '../Webforms/ChildNormal';
import FixRequiredSelect from "../Webforms/Simulation/RequiredSelect";
import '../Webforms/Simulation/Webelements/TagBuild.css';
import * as allDevices from "react-device-detect";
// import { datasave } from '../../../_services/db_services';
// const customColor = (txtclr, bgcolor) => {
//   'txtclr' : txtclr,
//   'bgcolor': bgcolor
// };

let customStyles = {
  option: (provided, state) => ({
    ...provided,
  backgroundColor: state.isFocused
        ? '#EC661C'
        : null,
    color:'black',
  }),
  menuList: base => ({
        ...base,
        minHeight: 'fit-content',
  }),
}

const ENABLE = window.WEBFORM_Enable
const DISABLE = window.WEBFORM_Disable
const SHOW = window.WEBFORM_Show
const HIDE = window.WEBFORM_Hide
const REQUIRD = window.WEBFORM_Required
const DEFAULT = window.WEBFORM_DefaultValue
const EMPTY = window.WEBFORM_Empty
const CSS = window.WEBFORM_COLOR
const Select = props => (
  <FixRequiredSelect
    {...props}
    SelectComponent={BaseSelect}
    options={props.options || options}
  />
);

const mandatory_field = React.createElement(
            'span',
            {style:
            {
              'color': '#EC661C',
            }
          },
          '*'
            );
// const mandatory_field = '<span style="color: red;">*</span>';
var table_attributes = {};
table_attributes['className'] = 'table-span-border-wrapper col-md-12';

const options =
[
];

class BlockBoxTagBuild extends React.Component {
    constructor(props) {
      super(props);
      console.log(this.props)
      this.state={
        content: null,
        files: [],
        details:[],
        file_ids:[],
        PJDG: this.props.PJDG,
      }
      this.constructInputTag= this.constructInputTag.bind(this);
      this.constructTagElements= this.constructTagElements.bind(this);

    }


    componentDidMount() {
      // datasave.service(window.FILE_DETAILS,'GET',).then(response =>{
      //        this.setState({
      //          details:response
      //        })
      // })
    }

    componentDidUpdate(prevProps, prevState) {

    }
    constructTagElements(type) {

      console.log('type', type);
      let contentBuild;
      switch (type) {
        case 2:
          contentBuild = this.constructTextBoxTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
          break;
        case 1:
        case 3:
        case 4:
          contentBuild = this.constructInputTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
          break;
        case 5:
        contentBuild = this.constructDateTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
          break;
        case 6:
        contentBuild = this.constructFormNumberTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
          break;
        case 8:
          contentBuild = this.constructListOrgTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
          break;
        case 7:
        case 9:
        case 10:
        contentBuild = this.constructMultiselectTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data ,this.props.form_content.list_values,this.props.form_content.ruleProperties);
          break;
        case 11:
        contentBuild = this.constructRadioTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data ,this.props.form_content.list_values,this.props.form_content.ruleProperties);
          break;
        case 12:
            contentBuild = this.constructCheckboxTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data ,this.props.form_content.list_values,this.props.form_content.ruleProperties);
          break;

        case 13:
        contentBuild = this.constructAttachmentTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties, this.props.form_content.file_values);
          break;
        case 14:
        contentBuild = this.constructChildformTag(this.props.form_content.id,this.props.form_content.type,this.props.form_content.name,this.props.form_content.data,this.props.form_content.ruleProperties);
          break;
        case 15:
        case 16:
              contentBuild = this.constructButtonTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
          break;
        // case 17: break;
        case 18:
          contentBuild = this.constructTimerTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
          break;
        case 19:
            contentBuild = this.constructSignatureTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
          break;
        case 21:
            contentBuild = this.constructVideoTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
          break;
        case window.DOWNLOAD:
        contentBuild = this.constructDownloadTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
        break;
        case window.LABELTEXT :
             contentBuild = this.constructLabelTag(this.props.form_content.id, this.props.form_content.type, this.props.form_content.name, this.props.form_content.data, this.props.form_content.ruleProperties);
        break;
        default:


      }
    return contentBuild;
    }

    constructInputTag(id, type, name, data, ruleProperties) {
      const enable = ruleProperties[id][ENABLE];
      const disable = ruleProperties[id][DISABLE];
      const required =  this.generateRequireAttributeValue(ruleProperties[id])
      const empty = ruleProperties[id][EMPTY];
      const defaultvalue =  ruleProperties[id][DEFAULT];
      const show = ruleProperties[id][SHOW];
      const hide = ruleProperties[id][HIDE];
      const css = ruleProperties[id][CSS];
      const info = (data !== null) ? data.information : '';
      var div_level2_attributes = {};
      var div_level1_attributes = {};
      var div_radio_class={};
      var attributes = ['name', 'placeholder', 'min', 'value'];
      let state_value = '';
      var tag_attributes = {};
      var span_attributes = {};
      span_attributes['id'] = 'e-' + id;
      span_attributes['class'] = 'error';
      tag_attributes['id'] = id;
      tag_attributes['className'] = 'form-control';
      tag_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
      tag_attributes['data-numberOfDecimal'] = data.numberOfDecimal;
      tag_attributes['data-numberOfDigits'] = data.numberOfDigits;
      tag_attributes['minlength'] = (data.minlength !== undefined ? data.minlength : '');
      tag_attributes['maxlength'] = (data.maxlength !== undefined ? data.maxlength : '');
      tag_attributes['style'] = css

      if (type == 1 || type == 3 || type == 4) {
        if (this.props.datavalue === ''  ||  this.props.datavalue  === null  || this.props.datavalue === undefined)
        tag_attributes['placeholder'] = data.placeholder;

        tag_attributes['type'] = 'text';
      }
      else {
        tag_attributes['type'] = data.displayType;
      }
      if(data.displayType === 'username'){
        let storage = store.getState()
        tag_attributes['type'] = 'text';
        tag_attributes['value'] = storage.UserData.user_details.user_name;
        if(empty)
          tag_attributes['value'] = storage.UserData.user_details.user_name;
        tag_attributes['disabled'] = true;
      }
      else {
        if(this.props.datavalue!==undefined&&this.props.datavalue!==null) {
          tag_attributes['value'] =this.props.datavalue;
        }
        else {

          tag_attributes['value'] = (data.value == undefined || data.value == null ) && this.generateDisableAttributeValue(enable,disable) ? "":data.value;
        }

        if((defaultvalue.rule !== undefined && defaultvalue.rule === true && (data.value === undefined || data.value === null || data.value == ""))  || (defaultvalue.rule !== undefined && defaultvalue.rule === true && data.value  === defaultvalue.defaultValue.defaultValue)){
          let rulevalue = defaultvalue.defaultValue.defaultValue;
          this.props.updateStateByDefaultValue(id,rulevalue);
          tag_attributes['value'] = rulevalue;
        }else if (defaultvalue.rule !== undefined && defaultvalue.rule === false &&  data.value === defaultvalue.defaultValue.defaultValue) {
          tag_attributes['value'] = '';
          this.props.emptyStateById(id)
        }

        if(empty){
          tag_attributes['value'] = '';
          this.props.emptyStateById(id)
        }
      }
      tag_attributes['name'] = id;
      // tag_attributes['placeholder'] =
      tag_attributes['onChange'] = this.generateDisableAttributeValue(enable,disable) ? this.preventchange:this.props.handleChange;

      //it won't affect text field element,only for decimal and numeric element
    //  tag_attributes['onKeyPress'] = this.props.validateNumberFields.bind(this,type);
      Object.entries(data).forEach(([key, value]) => {
        var index = attributes.indexOf(key);
        if (key !== 'value' && key !== 'name' && key === 'require' && required ) {
            key = value = 'required';
            tag_attributes[key] = value;
        }
      });
        tag_attributes['disabled'] = this.generateDisableAttributeValue(enable,disable)
        // if((!show && hide)){
        //   this.props.emptyStateById(id)
        // }
        let src = question;
        let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})
        div_level2_attributes['className'] = 'form-group';
        div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-textfield-dec-int';
        let label_tag = React.createElement("label", {
                          for: name,
                          name: name,
                          className: ' control-label',
                        }, name + ' ' , (tag_attributes['required'] ? mandatory_field : ''),((info !== null && info !== undefined) ? tooltip_tag :''));
          if (required || data.require) {
            var input_tag = React.createElement('div', {'className' : 'wf-web-form-control'},
            React.createElement(
             'input',
             tag_attributes,
            ), React.createElement(
             'span',
             span_attributes,
            ));
          } else {
              var input_tag = React.createElement('div', {'className' : 'wf-web-form-control'},
                         React.createElement(
                          'input',
                          tag_attributes,
                ),
                React.createElement(
                 'span',
                 span_attributes,
                )
              );
          }
          div_radio_class['className'] = (data !== null && (data.showLabel || data.showlabel)) ? 'dividing-fields textfield-fields' : 'col-md-12';

          // let input_td_tag = React.createElement(
          //
          //                     input_tag,
          //                   );
          let div_structure_check = React.createElement('td','',
            React.createElement('div', div_level1_attributes,
            React.createElement('div', div_level2_attributes,
            React.createElement('div', {'className' : 'row'},
            (data !== null && (data.showLabel || data.showlabel) ? label_tag : ''),
            React.createElement('div', div_radio_class,
            React.createElement('div', {'className' : 'col-md-12'},
            input_tag),
            React.createElement('div', {'className' : 'col-md-2'}),
            )
            )
            )
            )
          );
          let tr_tag = React.createElement(
                      'tr',
                      '',
                      div_structure_check,
                      );

          let table_tag =  React.createElement(
                            'table',
                            table_attributes,
                            tr_tag
                          );

          return table_tag;
    }

    constructTextBoxTag(id, type, name, data,ruleProperties) {

      const enable = ruleProperties[id][ENABLE];
      const disable = ruleProperties[id][DISABLE];
      const required =  this.generateRequireAttributeValue(ruleProperties[id])
      const empty = ruleProperties[id][EMPTY];
      const defaultvalue =  ruleProperties[id][DEFAULT];
      const show = ruleProperties[id][SHOW];
      const hide = ruleProperties[id][HIDE];
      const css = ruleProperties[id][CSS];
      const info = (data !==null) ? data.information : '';
      var div_level2_attributes = {};
      var div_level1_attributes = {};
      var div_radio_class={};
      var attributes = ['name', 'placeholder', 'min', 'value'];
      var tag_attributes = {};
      tag_attributes['id'] = id;
      tag_attributes['name'] = id;
      tag_attributes['rows'] = data.rows;
      tag_attributes['className'] = 'form-control';
      tag_attributes['onChange'] = this.generateDisableAttributeValue(enable,disable) ? this.preventchange :this.props.handleChange
      tag_attributes['value'] = (this.props.datavalue == undefined || this.props.datavalue == "") && this.generateDisableAttributeValue(enable,disable) ? "":this.props.datavalue;
      tag_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
      tag_attributes['style'] = css
      if (this.props.datavalue === ''  ||  this.props.datavalue  === null  || this.props.datavalue === undefined){
      tag_attributes['placeholder'] = data.placeholder;}

      // tag_attributes['placeholder'] = this.props.datavalue;


      var span_attributes = {};
      span_attributes['id'] = 'e-' + id;
      span_attributes['className'] = 'error';
      Object.entries(data).forEach(([key, value]) => {
      var index = attributes.indexOf(key);
      if (key !== 'value' && key !== 'name' && key === 'require' && required) {
        key = value = 'required';
          tag_attributes[key] = value;
        }

      });

      if((defaultvalue.rule !== undefined && defaultvalue.rule === true && (this.props.datavalue === undefined || this.props.datavalue === null || this.props.datavalue == ""))  || (defaultvalue.rule !== undefined && defaultvalue.rule === true && this.props.datavalue  === defaultvalue.defaultValue.defaultValue) ){
        let rulevalue = defaultvalue.defaultValue.defaultValue;
        this.props.updateStateByDefaultValue(id,rulevalue);
        tag_attributes['value'] = rulevalue;
      }else if (defaultvalue.rule !== undefined && defaultvalue.rule === false &&  this.props.datavalue === defaultvalue.defaultValue.defaultValue) {
        tag_attributes['value'] = '';
        this.props.emptyStateById(id)
      }


      if(empty){
      tag_attributes['value'] = '';
      this.props.emptyStateById(id)
    }

      // tag_attributes['cols'] = 50;

      tag_attributes['disabled'] = this.generateDisableAttributeValue(enable,disable)
      // if((!show && hide)){
      //   this.props.emptyStateById(id)
      // }

        div_level2_attributes['className'] = 'form-group';
        div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-textbox';
        let src = question;
        let tooltip_tag  = React.createElement("img", {src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})

      let label_tag =  React.createElement("label", {
                          for: name,
                          name: name,
                          className: ' control-label',
                        }, name + ' ' , (tag_attributes['required'] ? mandatory_field : ''),((info !== null && info!== undefined) ? tooltip_tag :''));
        if (data.require || required) {
            var textarea = React.createElement('div', {'className' : 'wf-web-form-control'},
                      React.createElement(
                      'textarea',
                      tag_attributes
                    ), React.createElement(
                      'span',
                      span_attributes,
                    ));
        } else {
            var textarea = React.createElement('div', {'className' : 'wf-web-form-control'},
                      React.createElement(
                      'textarea',
                      tag_attributes
                    ), React.createElement(
                      'span',
                      span_attributes,
                    ));
        }
        div_radio_class['className'] = (data !== null && data.showLabel) ? 'dividing-fields textbox-fields' : 'col-md-12';
        let div_structure_check = React.createElement('td','',
          React.createElement('div', div_level1_attributes,
          React.createElement('div', div_level2_attributes,
          React.createElement('div', {'className' : 'row'},
          (data !== null && data.showLabel ? label_tag : ''),
          React.createElement('div', div_radio_class,
          React.createElement('div', {'className' : ''},
          textarea),
          React.createElement('div', {'className' : 'col-md-2'}),
          )
          )
          )
          )
      );
      let tr_tag = React.createElement(
        'tr',
        '',
        div_structure_check,
      );

      let table_tag =  React.createElement(
          'table',
          table_attributes,
          tr_tag
        );
      return table_tag;
    }


    setCustomDateFormat=(dateInt, addOffset = false)=>{
         let date = (!dateInt || dateInt.length < 1) ? new Date : new Date(dateInt);
         if (typeof dateInt === "string") {
             return date;
         } else {
           console.log('odd');
             const offset = addOffset ? date.getTimezoneOffset() : -(date.getTimezoneOffset());
             const offsetDate = new Date();
             offsetDate.setTime(date.getTime() + offset * 60000)
             return offsetDate;
         }
     }


    constructDateTag(id, type, name, data, ruleProperties) {
      const enable = ruleProperties[id][ENABLE];
      const disable = ruleProperties[id][DISABLE];
      const required =  this.generateRequireAttributeValue(ruleProperties[id]);
      const empty = ruleProperties[id][EMPTY];
      const defaultvalue =  ruleProperties[id][DEFAULT];
      const show = ruleProperties[id][SHOW];
      const hide = ruleProperties[id][HIDE];
      const css = ruleProperties[id][CSS];
      const info = (data !==null) ? data.information : '';

      var div_level2_attributes = {};
      var div_level1_attributes = {};
      var div_radio_class={};
      let readonly;
      let display_type = parseInt(data.display_type);
      let feature = parseInt(data.feature);
      let tag_attributes = {};
      tag_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
      tag_attributes['dateFormat'] = (display_type === 1) ? 'dd-MM-yyyy' : (display_type === 3) ? 'HH:mm' :'dd-MM-yyyy HH:mm';
      tag_attributes['showTimeSelect'] = (display_type === 1) ? false : true;
      if(tag_attributes['showTimeSelect'])
      {
        tag_attributes['timeFormat'] = "HH:mm";
      }

      tag_attributes['showTimeSelectOnly'] =(display_type === 3) ? true :false;
      tag_attributes['name'] = id;
      tag_attributes['id'] = id;


      if (feature !== 1 && feature !==2) {
        tag_attributes['disabled'] = true;
        tag_attributes['onChange'] = this.preventchange
        if( feature === 3 || feature === 4 || feature === 5 || feature === 6 ){
          const { datavalue, refid, step_id, submit_details_id } = this.props;
          switch(feature){
            case 3:
            tag_attributes['selected'] = refid === undefined || parseInt(refid) === 0 ? new Date() : (this.props.datavalue !== '' && this.props.datavalue !== null) ? new Date(this.props.datavalue) : new Date();
            break;
            case 4:
            tag_attributes['selected'] = (this.props.datavalue !== '' && this.props.datavalue !== null) ? new Date(this.props.datavalue) : '';
            break;
            case 5:
            tag_attributes['selected'] = (submit_details_id === null || parseInt(submit_details_id) === 0) && step_id !== undefined && data['selectedStep'] !== undefined && (parseInt(step_id) === parseInt(data['selectedStep'])) ? new Date() : (this.props.datavalue !== '' && this.props.datavalue !== null) ? new Date(this.props.datavalue) : '';
            break;
            case 6:
            tag_attributes['selected'] = (this.props.datavalue !== '' && this.props.datavalue !== null) ? new Date(this.props.datavalue) : '';
            break;
          }
          readonly = tag_attributes['disabled'];
          // tag_attributes['selected'] = (this.props.datavalue !== '' && this.props.datavalue !== null) ? new Date(this.props.datavalue) : '';
        }

      }

      else {
           tag_attributes['selected'] = (this.props.datavalue !== '' && this.props.datavalue !== null) ?new Date(this.props.datavalue) : '';
           if(id == 1530){
             console.log(this.props.datavalue,defaultvalue.defaultValue.defaultValue);
              console.log(new Date(this.props.datavalue).valueOf(),new Date(defaultvalue.defaultValue.defaultValue).valueOf());
           }
           if((defaultvalue.rule !== undefined && defaultvalue.rule === true && (this.props.datavalue === undefined || this.props.datavalue === null || this.props.datavalue == ""))){
             let rulevalue = new Date(defaultvalue.defaultValue.defaultValue);
             this.props.updateStateByDefaultValue(id,rulevalue);
             tag_attributes['selected'] = rulevalue;
           }else if (defaultvalue.rule !== undefined && defaultvalue.rule === false &&  this.props.datavalue === defaultvalue.defaultValue.defaultValue) {
             tag_attributes['selected'] = '';
             this.props.emptyStateById(id)
           }
      if(empty){
          tag_attributes['selected'] = '';
          this.props.emptyStateById(id)
      }
      }
      tag_attributes['className'] = 'form-control';
      // tag_attributes['withPortal'] = true;
      // tag_attributes['popperPlacement'] = "top-end";
      // tag_attributes['popperModifiers'] = [{
      //   offset: {
      //     enabled: true,
      //     // offset: "5px, 10px"
      //   },
      //   preventOverflow: {
      //     enabled: true,
      //     escapeWithReference: false,
      //     boundariesElement: "viewport"
      //   }
      // }];
      if (feature === 1 || feature ===2) {
       tag_attributes['disabled'] = this.generateDisableAttributeValue(enable,disable);
       readonly = tag_attributes['disabled'];
     }
    //  if((!show && hide)){
    //   this.props.emptyStateById(id)
    // }
      tag_attributes['onChange'] = this.generateDisableAttributeValue(enable,disable) ? this.preventchange :this.props.handleDateChange.bind(this, id);
      if (allDevices.isMobile || allDevices.isTablet || allDevices.isIPhone13 || allDevices.isIPad13 || allDevices.isIPod13) {
         tag_attributes['onFocus'] = this.props.handleOnFocus.bind(this);
         //tag_attributes['onBlur'] = this.props.handleOnFocus.bind(this);
         tag_attributes['withPortal'] = true;
         //tag_attributes['disabledKeyboardNavigation'] = true;
      }

      let img_attributes = {};
      var span_attributes = {};
      span_attributes['id'] = 'e-' + id;
      span_attributes['className'] = 'error';
      img_attributes['src'] = calendericon;
      div_level2_attributes['className'] = 'form-group';
      div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-datepicker';

      let src = question;
      let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})

      var label_tag = React.createElement("label", {
                          for: name,
                          name: name,
                          className: '   control-label',
                        }, name +' ',(required ? mandatory_field : ''),((info !== null && info !== undefined) ? tooltip_tag : ''));

      var span_tag = React.createElement('span',
                      {'className' : 'input-group-addon'},
                      React.createElement('span',
                       {'className' : 'glyphicon glyphicon-calendar'},
                      )
                     );
    if (required) {
      tag_attributes['required']='required';
      const dateCustomPicker = ({ value ,onChange}) => (
      <input className="date-field-input form-control" readOnly={true} disabled = {readonly} id={id} name={id}  onChange={e => this.props.handleDateChange.bind(this,e.target.value)} required type="button"  value={tag_attributes['selected']}  style = {css}/>);
      // tag_attributes['customInput'] = React.createElement(dateCustomPicker, {}, '');
      // tag_attributes['customInput'] = React.createElement(dateCustomPicker, {}, '');
      var dateTag = React.createElement('div', { 'className': 'input-group wf-web-form-control date-group' },
      React.createElement(DatePicker,
        tag_attributes
      ), span_tag, React.createElement('span', span_attributes));
    } else {
        const dateCustomPicker = ({ value ,onChange}) => (

        <input className="date-field-input form-control" readOnly={true} disabled = {readonly}  id={id}  onChange={e => this.props.handleDateChange.bind(this,e.target.value)} name={id} type="button"  value={tag_attributes['selected']} style = {css} />);
        // tag_attributes['customInput'] = React.createElement(dateCustomPicker, {}, '');
        var dateTag = React.createElement('div', { 'className': 'input-group wf-web-form-control date-group' },
        React.createElement(DatePicker,
          tag_attributes
        ), span_tag);
    }
      div_radio_class['className'] = (data !== null && data.showlabel) ? 'dividing-fields date-fields' : 'col-md-12';
      let div_structure_check = React.createElement('td','',
        React.createElement('div', div_level1_attributes,
        React.createElement('div', div_level2_attributes,
        React.createElement('div', {'className' : 'row'},
        (data !== null && data.showlabel ? label_tag  : ''),
        React.createElement('div', div_radio_class,
        React.createElement('div', {'className' : 'col-md-12'},
        dateTag),
        React.createElement('div', {'className' : 'col-md-2'}),
        )
        )
        )
        )
    );
      // let td_date_tag = React.createElement('td','', React.createElement('label','',dateTag,span_tag));

      let tr_tag = React.createElement(
                    'tr',
                    '',
                    div_structure_check,
                  );

      let table_tag =  React.createElement(
                      'table',
                      table_attributes,
                      tr_tag
                    );

      return table_tag;
    }


    constructListOrgTag(id, type, name, data, ruleProperties) {
      let org_option_list ={};
      if(data!==null)
      org_option_list = this.allPersonsOfSelectedOU(data.order, data.showAllPersons, data.selectedItems, data);
      const enable = ruleProperties[id][ENABLE];
      const disable = ruleProperties[id][DISABLE];
      const required =  this.generateRequireAttributeValue(ruleProperties[id]);
      const empty = ruleProperties[id][EMPTY];
      const defaultvalue =  ruleProperties[id][DEFAULT];
      const show = ruleProperties[id][SHOW];
      const hide = ruleProperties[id][HIDE];
      const css = ruleProperties[id][CSS];
      const info = (data !==null) ? data.information : '';
      const customcss =  this.getCustomCssStyle(css);
      var div_level2_attributes = {};
      var div_level1_attributes = {};
      var div_radio_class={};
      let selectoptions = [];
      let required_span = {};
      let tag_attributes = {};


      if (data !== null && data.multiselect !== undefined && data.multiselect ) {
        tag_attributes['isMulti'] = true;
      }
      else {
        let selectoption = {};
        selectoption.value = -2;
        selectoption.label = 'Select';
        selectoptions.push(selectoption);
        tag_attributes['isMulti'] = false;
      }
      if (data !== null) {
        Object.entries(org_option_list).forEach(([key, value]) => {
          let dataw = {};
          dataw.value = value.id !== undefined ? value.id : value.p_id;
          dataw.label = value.name !== undefined ? value.name : value.p_name;
          if(value.id !== -999) {
            selectoptions.push(dataw);
          }
        });
      }
      // tag_attributes['name'] = 'name';
      tag_attributes['id'] =id;
      tag_attributes['name'] = id;
      tag_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];

      tag_attributes['options'] = selectoptions;
    if(empty){
      tag_attributes['defaultValue'] = {};
      this.props.emptyStateById(id)
    }else{
      if (this.props.datavalue === 0) {
        let selectoption = {};
        selectoption.value = -2;
        selectoption.label = 'Select';
          tag_attributes['defaultValue'] = selectoption;
      }else{
          tag_attributes['defaultValue'] = this.props.datavalue;
      }
    }


      tag_attributes['onChange'] = this.generateDisableAttributeValue(enable,disable) ? this.preventchange :this.props.handleSelectChange;
      tag_attributes['styles'] = customcss
      tag_attributes['isDisabled'] = this.generateDisableAttributeValue(enable,disable)
      tag_attributes['blurInputOnSelect'] = true;
      tag_attributes['searchable'] = false;
      // if((!show && hide)){
      //   this.props.emptyStateById(id)
      // }
      div_level2_attributes['className'] = 'form-group';
      div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-listorg';
      if (data !== null){
      if (data.OU_Option !== undefined &&  data.OU_Option === 1 || data.OU_Option === 2 ){
        tag_attributes['isDisabled'] = true
      }
    }
      if(required){
        var span_attributes = {};
    	  span_attributes['id'] = 'e-' + id;
    	  span_attributes['className'] = 'error';
        tag_attributes['required'] = 'required';
         required_span  = React.createElement('span', span_attributes);
      }

      let src = question;
      let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})

      let label_tag = React.createElement("label", {
                          for: name,
                          name: name,
                          className: ' control-label',
                        }, name + ' ', (required ? mandatory_field : ''),((info !== null && info !== undefined && info.length > 0) ? tooltip_tag : ''));
      let multiselect = React.createElement('div', {'className' : 'wf-web-form-control'},
                        React.createElement(
                          Select,
                          tag_attributes
                        ),(required ? required_span : ''));

      div_radio_class['className'] = ((data !== null && data.showLabel) || data === null) ? 'dividing-fields listorg-fields' : 'col-md-12';
      let div_structure_check = React.createElement('td','',
        React.createElement('div', div_level1_attributes,
        React.createElement('div', div_level2_attributes,
        React.createElement('div', {'className' : 'row'},
        (data !==null && data.showLabel ? label_tag : (data === null ? label_tag : '')),
        React.createElement('div', div_radio_class,
        React.createElement('div', {'className' : 'col-md-12'},
        multiselect),
        React.createElement('div', {'className' : 'col-md-2'}),
        )
        )
        )
        )
      );
      let tr_tag = React.createElement(
                    'tr',
                    '',
                    div_structure_check,
                  );

      let table_tag =  React.createElement(
                        'table',
                        table_attributes,
                        tr_tag
                      );

      return table_tag;

    }

    allPersonsOfSelectedOU(louOrder = 1, showAllPersons, selectedItems = [], data, JDG_persons = this.props.JDG_personlist) {
      let personsOfOU = [];
      let personExist = false;
      let louPersons = [];
      let allPJDG = this.state.PJDG;
      if(Number(data.selectAll) === 1) {
         selectedItems = allPJDG.filter(itemOfPjdg => (itemOfPjdg.category == data.orgUnit));
      }
      if (showAllPersons) {
        JDG_persons.map((each_item, index) => {
          selectedItems.map((selected_item, key) => {
            if (selected_item.id === each_item.entity_id && selected_item.entity_type_id === each_item.entity_type_id) {
              if (personsOfOU.length > 0) {
                personsOfOU.map((each_person, key1) => {
                  if (each_person.p_id == each_item.p_id) {
                    personExist = true
                  }
                })
                if (!personExist) {
                  personsOfOU.push(each_item);
                }
                personExist = false;
              } else {
                personsOfOU.push(each_item);
              }
            }
          })
        })
        louPersons = personsOfOU;
        // return personsOfOU;
      } else {
        louPersons = selectedItems;
        // return selectedItems;
      }

      louPersons.sort(function (a, b) {
        let item = 0;
        if (showAllPersons) {
          var nameA = a.p_name.toLowerCase(), nameB = b.p_name.toLowerCase()
        } else {
          var nameA = a.name.toLowerCase(), nameB = b.name.toLowerCase()
        }
        if (Number(louOrder) === 1) {
          item = (nameA < nameB) ? -1 : ((nameA > nameB) ? 1 : 0);
          return item
        } else if (Number(louOrder) === 2) {
          item = (nameA < nameB) ? 1 : ((nameA > nameB) ? -1 : 0);
          return item
        }
      })
      return louPersons;
    }

    constructMultiselectTag(id, type, name, data, options, ruleProperties) {
      const enable = ruleProperties[id][ENABLE];
      const disable = ruleProperties[id][DISABLE];
      const required =  this.generateRequireAttributeValue(ruleProperties[id])
      const empty = ruleProperties[id][EMPTY];
      const defaultvalue =  ruleProperties[id][DEFAULT];
      const show = ruleProperties[id][SHOW];
      const hide = ruleProperties[id][HIDE];
      const css = ruleProperties[id][CSS];
      const info = (data !==null) ? data.information :'';
      const customcss =  this.getCustomCssStyle(css);
      var div_level2_attributes = {};
      var div_level1_attributes = {};
      var div_radio_class={};
      let selectoptions = [];
      let listInOrder = (data !== null && data !== undefined && data !== 'null'  && options[data.list] !== null && options[data.list] !==undefined) ? this.selectListSorting(data, options[data.list]) : [];

      // let input_values = (data !== null && data !== undefined && data !== 'null') ? options[data.list] : [];
      let input_values = listInOrder;
      if(data != undefined) {
        if(data.na !==undefined && data.na ===1) {
          let na = {
            id  : -1,
            name: "NA",
            hide: 0,
          }
          let na_exists = false;
          Object.entries(input_values).forEach(([key, value]) => {
            if(value.id === -1){
              na_exists = true;
            }
          })
          if(na_exists === false)
             {input_values.push(na)
          }
        }
      }
      let tag_attributes = {};

      if (data !== null && data.multiselect !== undefined && data.multiselect ) {
        tag_attributes['isMulti'] = true;
      }
      else {
        let selectoption = {};
        selectoption.value = -2;
        selectoption.label = 'Select';
        selectoptions.push(selectoption);
        tag_attributes['isMulti'] = false;
      }
      if(type === 7) {
        if(input_values !== undefined && input_values !== null) {
        Object.entries(input_values).forEach(([key, value]) => {
          let dataw = {};
          dataw.value = value.id;
          dataw.label = value.name;
          selectoptions.push(dataw);
          });
        }
      }
      else {
        // add value of DB list array for options
        if (this.props.Dbobj !== undefined && this.props.Dbobj[id]!== undefined && this.props.Dbobj[id] !== 'null' && this.props.Dbobj[id] !== null) {
          Object.entries(this.props.Dbobj[id]).forEach(([key, value]) => {
            let dataw = {};
            dataw.value = value.value;
            dataw.label = value.label;
            selectoptions.push(dataw);
          });
        }

      }
      // tag_attributes['name'] = 'name';
      tag_attributes['id'] = id;
      tag_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
      tag_attributes['name'] = id;
      tag_attributes['styles'] = customcss;
    	// if (data !== null && data.multiselect !== undefined && data.multiselect) {
      //       tag_attributes['isMulti'] = true;
      //     }
      //     else {
      //       tag_attributes['isMulti'] = false;
      //     }
      tag_attributes['options'] = selectoptions;
      if(empty) {
        tag_attributes['defaultValue'] = {};
        this.props.emptyStateById(id)
      } else {
        if (this.props.datavalue === 0) {
          let selectoption = {};
          selectoption.value = -2;
          selectoption.label = 'Select';
          tag_attributes['defaultValue'] = selectoption;
        } else {
          tag_attributes['defaultValue'] = this.props.datavalue;
        }
      }
      tag_attributes['onChange'] = this.generateDisableAttributeValue(enable,disable) ? this.preventchange :this.props.handleSelectChange;
      tag_attributes['isDisabled'] = this.generateDisableAttributeValue(enable,disable)
      tag_attributes['blurInputOnSelect'] = true;
      tag_attributes['searchable'] = false;
      // if((!show && hide)){
      //   this.props.emptyStateById(id)
      // }
      div_level2_attributes['className'] = 'form-group';
      div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-list-multi';

      if (required)   {
    	  var span_attributes = {};
    	  span_attributes['id'] = 'e-' + id;
    	  span_attributes['className'] = 'error';
        tag_attributes['required'] = 'required';
        var multiselect = React.createElement('div', {'className' : 'wf-web-form-control'},
                        React.createElement(
                          Select,
                          tag_attributes,
                        ), React.createElement('span', span_attributes));
      } else {
    	  var multiselect = React.createElement('div', {'className' : 'wf-web-form-control'},
                        React.createElement(
                          Select,
                          tag_attributes,
                        ));
      }
      let src = question;
      let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})
      let label_tag =  React.createElement("label", {
                          for: name,
                          name: name,
                          className: ' control-label',
                        },  name + ' ' , (required ? mandatory_field : ''),((info !== null && info !== undefined) ? tooltip_tag : ''));
      div_radio_class['className'] = ((data !== null && data.showlabel) || data === null) ? 'dividing-fields multiselect-fields' : 'col-md-12';
      let div_structure_check = React.createElement('td','',
        React.createElement('div', div_level1_attributes,
        React.createElement('div', div_level2_attributes,
        React.createElement('div', {'className' : 'row'},
        (data !== null && data.showlabel ? label_tag : ''),
        React.createElement('div', div_radio_class,
        React.createElement('div', {'className' : 'col-md-12'},
        (data !== null ? multiselect : ''),
        React.createElement('div', {'className' : 'col-md-2'}),
        )
        )
        )
        )
        )
      );
      let tr_tag = React.createElement(
                  'tr',
                  '',
                div_structure_check
      );

      let table_tag =  React.createElement(
                      'table',
                      table_attributes,
                      tr_tag
                    );
      return table_tag;
    }
        selectListSorting(data, selectListOptions) {
          const sortable = Object.keys(selectListOptions).map(i => selectListOptions[i])
            sortable.sort(function (a, b) {
            let return_value_yes = 1;
            let return_value_no = -1;
            if (data.order !== null && data.order === 'descending') {
              a=a.name;
              b=b.name;
              return_value_yes = -1;
              return_value_no = 1;

            }
            else if (data.order !== null && data.order === 'ascending') {
              a=a.name;
              b=b.name;
               return_value_yes = 1;
               return_value_no = -1;
            }
            else{
              a=a.index;
              b=b.index;
              return_value_yes = 1;
              return_value_no = -1;
            }
              var reA = /[^a-zA-Z]/g;
              var reN = /[^0-9]/g;
              var AInt = parseInt(a, 10);
              var BInt = parseInt(b, 10);
              if(isNaN(AInt) && isNaN(BInt)){
                  var aA = a.replace(reA, "");
                  var bA = b.replace(reA, "");
                  if(aA === bA) {
                      var aN = parseInt(a.replace(reN, ""), 10);
                      var bN = parseInt(b.replace(reN, ""), 10);
                      return aN === bN ? 0 : aN > bN ? return_value_yes : return_value_no;
                  } else {
                      return aA > bA ? return_value_yes : return_value_no;
                  }
              }else if(isNaN(AInt)){//A is not an Int
                  return 1;//to make alphanumeric sort first return 1 here
              }else if(isNaN(BInt)){//B is not an Int
                  return -1;//to make alphanumeric sort first return -1 here
              }else if(AInt == BInt) {
                  var aA = a.replace(reA, "");
                  var bA = b.replace(reA, "");
                  return aA > bA ? return_value_yes : return_value_no;
              }
              else {
                  return AInt > BInt ? return_value_yes : return_value_no;
              }
            })

          return sortable;
        }

    constructRadioTag(id, type, name, data, list_values, ruleProperties) {
      const enable = ruleProperties[id][ENABLE];
      const disable = ruleProperties[id][DISABLE];
      const required =  this.generateRequireAttributeValue(ruleProperties[id])
      const empty = ruleProperties[id][EMPTY];
      const defaultvalue =  ruleProperties[id][DEFAULT];
      const show = ruleProperties[id][SHOW];
      const hide = ruleProperties[id][HIDE];
      const css = ruleProperties[id][CSS];
      const info = (data !== null) ? data.information : '';


      let tag_attributes = {};
      const orientation = (data !== null && data !== undefined && data['orientation'] !== undefined) ? data['orientation'] : 2;
      const orientation_class = (orientation === 1) ? 'vertical' : 'horizontal';
      var radio_tag = [];
      var div_level2_attributes = {};
      var div_level1_attributes = {};
      var div_radio_class={};
      let input_values = (data !== null && data !== undefined && data !== 'null') ? list_values[data.list] : [];
      if(data !== null && data !== undefined && data !== 'null') {
        if(data.na !== undefined && data.na === 1) {
          let na = {
             id   : -1,
             name : "NA",
             hide : 0,
           }
           input_values[-1] = na;
        }
      }
      if (input_values !== undefined && input_values !== null) {
        let i=0;
        Object.entries(input_values).forEach(([key, value]) => {
          var span_attributes = {};
          var label_attributes = {};
          var input_attributes = {};
          label_attributes['for'] = value.name;
          label_attributes['name'] = value.name;
          label_attributes['style'] = css
          label_attributes['className'] = 'radio-wrapper';
          span_attributes['id'] = 'e-' + id;
          span_attributes['className'] = 'error';
          span_attributes['className'] = 'error';
          input_attributes['id'] = id;
          input_attributes['type'] = 'radio';
          input_attributes['name'] =  id;
          input_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
          input_attributes['value'] = value.id;

          // input_attributes['className'] = 'form-control';
          if (parseInt(this.props.datavalue) === parseInt(value.id))
          {
            input_attributes['checked'] = 'checked';
          }else{
            input_attributes['checked'] = false;
          }
          if(id == 1527){
          // console.log(this.props.datavalue,this.props.datavalue === undefined,this.props.datavalue === null,this.props.datavalue === " ",(this.props.datavalue === undefined || this.props.datavalue === null || this.props.datavalue === " "),(defaultvalue.rule !== undefined && defaultvalue.rule === true && (this.props.datavalue === undefined || this.props.datavalue === null || this.props.datavalue == "")));
          // console.log(document.getElementById(1527).querySelectorAll("input"));
          // console.log(this.props.datavalue);
        }
        // let checked = undefined;
        // if(document.getElementById(id) != null){
        //   let nodes = document.getElementById(id).querySelectorAll("input");
        //   // console.log(nodes);
        //   if(nodes.length >0){
        //     Object.values(nodes).some(node=>{
        //       // console.log(node);
        //       checked = node.checked;
        //     })
        //   }
        // }

      // let rule =defaultvalue.rule !== undefined && defaultvalue.rule === true;
      //
      //     if((rule && parseInt(defaultvalue.defaultValue.defaultValueId) === parseInt(value.id)) ||
      //      (rule && parseInt(defaultvalue.defaultValue.defaultValueId) === parseInt(value.id) && parseInt(this.props.datavalue) === parseInt(value.id))){
      //
      //       let rulevalue = defaultvalue.defaultValue.defaultValueId;
      //       this.props.updateStateByDefaultValue(id,rulevalue);
      //       input_attributes['checked'] = true
      //     }
          /*else if (defaultvalue.rule !== undefined && defaultvalue.rule === false && parseInt(defaultvalue.defaultValue.defaultValueId) === parseInt(value.id)  && parseInt(this.props.datavalue) === parseInt(defaultvalue.defaultValue.defaultValueId)) {
            this.props.emptyStateById(id)

            input_attributes['checked'] = false
          }*/
          if(empty){
            this.props.emptyStateById(id)
            input_attributes['checked'] = false
          }



          input_attributes['onChange'] =this.generateDisableAttributeValue(enable,disable) ? this.preventchange : this.props.handleChange;

          input_attributes['disabled'] = this.generateDisableAttributeValue(enable,disable);

          // if((!show && hide)){
          //   this.props.emptyStateById(id)
          // }
          input_attributes['style'] = css;
          var req = (required === true && i === (Object.keys(input_values).length-1));
          let wid = {'width':(orientation === 2) ? '25%' : '50%'};
          if (req) {
            input_attributes['required'] = 'required';
            tag_attributes['required'] = 'required';
            // radio_tag.push(
            //   React.createElement("input", input_attributes
            // ),value.name,
            //   React.createElement('label',
            //         label_attributes,
            //     ),
            //     React.createElement('span',
            //       span_attributes
            //     ),
            // );
            radio_tag.push(
              React.createElement('div', {'className' : 'radio-wf','style':wid},
              React.createElement('label',  {'className' : 'radio-wf','style': css},
              React.createElement("input",
                  input_attributes
              ), value.name, React.createElement('span',
                  span_attributes
              ),
              )
              )
             );
          } else {
            radio_tag.push(
              React.createElement('div', {'className' : 'radio-wf','style':wid},
              React.createElement('label', {'className' : 'radio-wf', 'style': css},
              React.createElement("input",
                  input_attributes
              ), value.name
              )
              )
             );
          }

          i++;
        });

      }

      div_level2_attributes['className'] = 'form-group radioWrap';
      div_level1_attributes['className'] = 'wb-web-control wb-form-control-radio';
      let src = question;
      let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})
      console.log('my ho', label_tag);
      let label_tag = React.createElement("label", {
                        for: name,
                        name: name,
                        className: 'control-label',
                      }, name + ' ', (tag_attributes['required'] ? mandatory_field : ''),((info !== null && info !== undefined) ? tooltip_tag : ''));
      div_radio_class['className'] = (data !== null && data.show_label) ? 'radio-fields ' + orientation_class : 'col-md-12 ' + orientation_class;
      let div_structure_check = React.createElement('td','',
        React.createElement('div', div_level1_attributes,
        React.createElement('div', div_level2_attributes,
        React.createElement('div', {'className' : 'row'},
        (data !== null && data.show_label ? label_tag : ''),
        React.createElement('div', div_radio_class,
        React.createElement('div', {'className' : 'col-md-12'},
        radio_tag),
        React.createElement('div', {'className' : 'col-md-2'}),
        )
        )
        )
        )
    );

      // let radio_td_tag = React.createElement('td','',
      //                     radio_tag
      //                   );

     let tr_tag = React.createElement(
                  'tr',
                  '',
                  div_structure_check,
                );

      let table_tag =  React.createElement(
          'table',
          table_attributes,
          tr_tag
        );

      console.log(table_tag);
      return table_tag;
    }

    constructCheckboxTag(id, type, name, data, list_values, ruleProperties) {
      const enable = ruleProperties[id][ENABLE];
      const disable = ruleProperties[id][DISABLE];
      const required =  this.generateRequireAttributeValue(ruleProperties[id])
      const empty = ruleProperties[id][EMPTY];
      const defaultvalue =  ruleProperties[id][DEFAULT];
      const show = ruleProperties[id][SHOW];
      const hide = ruleProperties[id][HIDE];
      const css = ruleProperties[id][CSS];
      const info = (data!== null) ? data.information : '';


      let tag_attributes ={};
      const orientation = (data !== null && data !== undefined && data['orientation'] !== undefined) ? data['orientation'] : 2;
      const orientation_class = (orientation === 1) ? 'vertical' : 'horizontal';

      var span = document.createElement("SPAN");
      var checkbox_tag = [];
      var div_level2_attributes = {};
      var div_level1_attributes = {};
      var div_checkbox_class={};
      let input_values = (data!==null && data !== undefined && data !== 'null') ? list_values[data.list] : [];
      if(data!==null && data !== undefined && data !== 'null') {
        if(data.na !== undefined && data.na === 1){
          let na = {
             id   : -1,
             name : "NA",
             hide : 0,
           }
           input_values[-1] = na;
        }
      }
      if (input_values !== undefined && input_values !== null) {
        let i = 0;
        Object.entries(input_values).forEach(([key, value]) => {
          var span_attributes = {};
          var label_attributes = {};
          var input_attributes = {};
          label_attributes['for'] = value.name;
          label_attributes['name'] = value.name;
          label_attributes['className'] = 'checkbox-wrapper';
          span_attributes['id'] = 'e-' + id;
          span_attributes['className'] = 'error';
          input_attributes['id'] =  id;
          input_attributes['type'] = 'checkbox';
          input_attributes['name'] = id;
          input_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
      	  if(data.multiselect){
            input_attributes['data-multiselect'] = true;
          }
          else {
            input_attributes['data-multiselect'] = false;
          }
          input_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
          input_attributes['value'] = value.id;
          input_attributes['onChange'] = this.generateDisableAttributeValue(enable,disable) ? this.preventchange :this.props.handleChange;

          input_attributes['disabled'] = this.generateDisableAttributeValue(enable,disable);
          input_attributes['style'] = css;
          // if((!show && hide)){
          //   this.props.emptyStateById(id)
          // }
          var prefill_index = this.props.datavalue.indexOf(''+value.id+'')

          if(prefill_index !== -1 ){
            input_attributes['checked'] = 'checked';
          }else if(empty){
            input_attributes['checked'] = false;
          }else{
            input_attributes['checked'] = false;
          }
          let rule =defaultvalue.rule !== undefined && defaultvalue.rule === true;
          let state = this.props.datavalue;
          let checked = undefined;
          if(document.getElementById(id) != null){
            let nodes = document.getElementById(id).querySelectorAll("input");
            if(nodes.length >0){
              Object.values(nodes).some(node=>{
                checked = node.checked;
              })
            }
          }

          // if((rule && parseInt(defaultvalue.defaultValue.defaultValueId) === parseInt(value.id)
          //     && (state.includes('-2')|| state.length === 0 ))  || (rule && state.includes(defaultvalue.defaultValue.defaultValueId)
          //     && parseInt(value.id) === parseInt(defaultvalue.defaultValue.defaultValueId) )){
          //   let rulevalue = defaultvalue.defaultValue.defaultValueId;
          //   delete state['-2'];
          //   if(data.multiselect){
          //     rulevalue = state.push(rulevalue)
          //   }else{
          //     rulevalue = [rulevalue]
          //   }
          //   this.props.updateStateByDefaultValue(id,rulevalue);
          //   input_attributes['checked'] = 'checked'
          // }else if (defaultvalue.rule !== undefined && defaultvalue.rule === false
          //   && parseInt(value.id) === parseInt(defaultvalue.defaultValue.defaultValueId)
          //   ) {
          //   this.props.emptyStateById(id,'CHECKBOX')
          //   // this.props.updateStateByDefaultValue(id,rulevalue);
          //   input_attributes['checked'] = false
          // }
          if(empty){
            input_attributes['checked'] = false;
            this.props.emptyStateById(id,'CHECKBOX')
          }

          var req = (required === true && i === (Object.keys(input_values).length-1));
          if (req) {
            input_attributes['required'] = 'required';
            tag_attributes['required'] = 'required';

            checkbox_tag.push(
            // React.createElement("label",
            //     label_attributes
            // ), value.name
            // ,React.createElement('input',
            //     input_attributes
            // ), React.createElement('span',
            //     span_attributes
            // )
            React.createElement('div', {'className' : 'checkbox-wf'},
            React.createElement('label',{'className' : 'checkbox-wf','style': css},
            React.createElement("input",
                input_attributes
            ), value.name),React.createElement('span',
                span_attributes
            )));
            // React.createElement("input",
            //     input_attributes
            // ), value.name
            // ,React.createElement('input',
            //     label_attributes
            // ), React.createElement('span',
            //     span_attributes
            // ));
          } else {
            checkbox_tag.push(
              React.createElement('div', {'className' : 'checkbox-wf'},
              React.createElement('label', {'className' : 'checkbox-wf','style': css},
              React.createElement("input",
                  input_attributes
              ), value.name
            )
            ));
          }

            i++;

      });
      }
      div_level2_attributes['className'] = 'form-group checkboxWrap';
      div_level1_attributes['className'] = 'wb-web-control wb-form-control-checkbox col-mb-4';

      // let div_structure = React.createElement(
      //     'div',
      //     div_level1_attributes,
      //     React.createElement(
      //       'div',
      //       div_level2_attributes,
      //       button_tag)
      // );

      let src = question;
      let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})


      let label_tag = React.createElement("label", {
                        for: name,
                        name: name,
                        className: 'control-label',
                      },name + ' ',
                        (tag_attributes['required'] ? mandatory_field : ''),((info !== null && info !== undefined)? tooltip_tag:''));

      div_checkbox_class['className'] = (data !== null && data.show_label) ? 'checkbox-fields ' + orientation_class : 'col-md-12 ' + orientation_class;


      let div_structure_check = React.createElement('td','',
        React.createElement('div', div_level1_attributes,
        React.createElement('div', div_level2_attributes,
        React.createElement('div', {'className' : 'row'},
        (data !== null && data.show_label ? label_tag : ''),
        React.createElement('div', div_checkbox_class,
        React.createElement('div', {'className' : 'col-mad-12'},
        checkbox_tag),
        React.createElement('div', {'className' : 'col-mad-2'}),
        )
        )
        )
        )
    );
      // let checkbox_td_tag = React.createElement('td','',
      //                         checkbox_tag
                            // );

      let tr_tag = React.createElement(
                  'tr',
                  '',
                  div_structure_check
                  );

      let table_tag =  React.createElement(
          'table',
          table_attributes,
          tr_tag
        );

      return table_tag;
    }

    constructButtonTag(id, type, name, data, ruleProperties) {
      const enable = ruleProperties[id][ENABLE]
      const disable = ruleProperties[id][DISABLE]
      const required = ruleProperties[id][REQUIRD]
      const css = ruleProperties[id][CSS];
      const info = (data!==null ) ? data.info : '';

      var tag_attributes = {};
      var div_level2_attributes = {};
      var div_level1_attributes = {};
      tag_attributes['id'] = id;
      tag_attributes['data-action'] = data.displayvalue;
      tag_attributes['type'] = 'button';
      tag_attributes['name'] = id;
      tag_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
      tag_attributes['value'] = name;
      tag_attributes['style'] = css;
      tag_attributes['onClick'] = this.generateDisableAttributeValue(enable,disable) ? this.preventchange : this.props.handleSubmit;
      tag_attributes['className'] = 'btn-default btn wb-submit-web-form';
      div_level2_attributes['className'] = 'form-group';
      div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-button';


        tag_attributes['disabled'] = this.generateDisableAttributeValue(enable,disable);
        let src = question;
        let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})


      let button_tag = React.createElement(
        'input',
        tag_attributes
      );
      let div_structure = React.createElement(
          'div',
          div_level1_attributes,
          React.createElement(
            'div',
            div_level2_attributes,
            button_tag,((info!==null && info!==undefined) ? tooltip_tag :''))
      );


      let table_tag =  React.createElement(
                        'table',table_attributes,React.createElement('tr','',React.createElement('td','', div_structure))
                    );

      return table_tag;
    }

    constructDownloadTag(id, type, name, data, ruleProperties){
      const enable = ruleProperties[id][ENABLE]
      const disable = ruleProperties[id][DISABLE]
      const required = ruleProperties[id][REQUIRD]
      const css = ruleProperties[id][CSS];
      var tag_attributes = {};
      var div_level2_attributes = {};
      var div_level1_attributes = {};
      tag_attributes['id'] = id;

      const info = (data !== null) ? data.information : '';
      // tag_attributes['data-action'] = data.displayvalue;
      tag_attributes['type'] = 'button';
      tag_attributes['name'] = id;
      tag_attributes['value'] = name;
      tag_attributes['style'] = css;
      tag_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
       tag_attributes['onClick'] = this.props.handleDownload;
      tag_attributes['className'] = 'btn-default btn wb-submit-web-form';
      div_level2_attributes['className'] = 'form-group';
      div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-button';


        tag_attributes['disabled'] = this.generateDisableAttributeValue(enable,disable)

        let src = question;
        let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})

      let button_tag = React.createElement(
        'input',
        tag_attributes,
      );
      let div_structure = React.createElement(
          'div',
          div_level1_attributes,
          React.createElement(
            'div',
            div_level2_attributes,
            button_tag,
            ((info!==null && info !== undefined && info.length > 0) ? tooltip_tag : ''))
      );


      let table_tag =  React.createElement(
                        'table',table_attributes,React.createElement('tr','',React.createElement('td','', div_structure))
                    );

      return table_tag;
    }

    // handleFileChange(e) {
    //   let type = 'attachedFiles';
    //   let    files = [];
    //       if (e.target.files[0] !== undefined || e.target.files[0] !== null) {
    //           const formData = new FormData();
    //           //formData.append('file', e.target.files)
    //           formData.forEach(function(value, key){
    //               formData.append(key, value)
    //           });
    //           const url = window.UPLOAD_FILE + '/' + type;
    //           document.getElementById("loding-icon").setAttribute("style", "display:block;");
    //           axios.post(window.backendURL + url, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
    //               .then(response => {
    //                   document.getElementById("loding-icon").setAttribute("style", "display:none;");
    //                 //  this.props.updateImageUpload(response);
    //               })
    //               .catch(error => {
    //                   document.getElementById("loding-icon").setAttribute("style", "display:none;");
    //
    //                   this.setState({
    //                       errors: error.response.data.errors
    //                   })
    //               })
    //       }
    //
    // }


    constructAttachmentTag(id, type, name, data, ruleProperties, filedetails = []) {
      const enable = ruleProperties[id][ENABLE];
      const disable = ruleProperties[id][DISABLE];
      const required =  this.generateRequireAttributeValue(ruleProperties[id])
      const empty = ruleProperties[id][EMPTY];
      const defaultvalue =  ruleProperties[id][DEFAULT];
      const css = ruleProperties[id][CSS];
      const info = (data !== null) ? data.Information : '';

      var div_level2_attributes = {};
      var div_level1_attributes = {};
      var div_checkbox_class = {};
      // let tag_attributes = {};
      // tag_attributes['id'] = id;
      // tag_attributes['type'] = 'file';
      // tag_attributes['name'] = id;
      // tag_attributes['multiple'] = data.Allowmultiplefiles;
      // tag_attributes['onChange'] = this.props.handleFileChange;

      // if(!enable)
      //   tag_attributes['disabled'] = true;
      // if (!enable && disable)
      //   tag_attributes['disabled'] = disable;
      let del = false;
      let file_attributes = {};
      var file_tag = [];
      var details = [];
      Object.values(filedetails).map(function (ele,key) {
          details.push(ele)
      })
      let allFiles = (details.length > 0) ? filedetails[id] : this.props.datavalue;
        if(empty){
          allFiles.map((eachItem,index) => {
            this.props.removeFile(id,index);
          })
          allFiles = undefined;
        }
      if(this.props.datavalue && allFiles !== undefined) {
        allFiles.map((eachItem, index) => {
          if (typeof eachItem === 'object') {
            file_tag.push(
                  React.createElement('div', { 'className' : 'col-md-12' },
                     React.createElement('div',{'className':'attachment-wrapper' },
                        React.createElement('span',
                              {id: index,className:'attachment-label'},
                              eachItem.originalfname,
                            ),
                            React.createElement("span",{className:'attachment-delete'},
                            <i title="Remove" hidden={disable || ! enable || !data.Allowdelete }  className="overall-sprite overall-sprite-mtdeletec" onClick={e => this.props.removeFile(id, index)}></i>
                           ),
                      ),
                       React.createElement("a",
                                {href: eachItem.filepath,target: "_blank"},
                                  'Preview'
                                     ),
                        React.createElement("br",{},),
                        React.createElement("span",{className:'attachment-time-label'},"Timestamp: ",
                            React.createElement('span',{className:'attachment-timestamp'},
                            eachItem.convertTimeStamp
                          ),
                      ),
                  )
            )
          }

        })
      }
      let src = question;
      let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})

      let attachment_tag = React.createElement("label", {
                            for: name,
                            name: name,
                          }, name + ' ',
                            (required ? mandatory_field :''),((info !== undefined && info !== null) ? tooltip_tag: '')
                          );
        div_level2_attributes['className'] = 'form-group';
        div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-attachment';


       let drag_tag =   React.createElement(FilesList, {handleFileChange:this.props.handleFileChange, webelement_id : this.props.form_content.id, enable : enable, disable : disable, data : data,required:required});
       let result = [];

       // result.push(attachment_tag);
       result.push(drag_tag);
       result.push(file_tag);
       div_checkbox_class['className'] = (data !== null && data.Showlabel) ? 'dividing-fields attachment-fields ' : 'col-md-12';

      let div_structure_check = React.createElement('td','',
          React.createElement('div', div_level1_attributes,
          React.createElement('div', div_level2_attributes,
          React.createElement('div', {'className' : 'row'},
          (data !== null && data.Showlabel ? attachment_tag : ''),
          React.createElement('div', div_checkbox_class,
          React.createElement('div', {'className' : ''},
          result),
          React.createElement('div', {'className' : 'col-mad-2'}),
          )
          )
          )
          )
      );
      let table_tag =  React.createElement(
                        'table',table_attributes,React.createElement('tr','', div_structure_check));

      return table_tag;
    }

    constructVideoTag(id, type, name, data,ruleProperties) {
      let tag_attributes = {};
      let video_attributes = {};
      var div_level2_attributes = {};
      var div_level1_attributes = {};
      var div_radio_class={};
      const info = (data !== null) ? data.information : '';
      // tag_attributes['id'] = name + '-' + id;
      // tag_attributes['src'] = testvideo;
      // if(data !== 'null') {
      tag_attributes['type'] = 'video/mp4';
      tag_attributes['name'] = name + '-' + id;
      tag_attributes['src'] = (data!== null) ? data.file_path : '';
      video_attributes['id'] = name + '-' + id;
      video_attributes['width'] = (data!== null) ? data.width : '';
      video_attributes['height'] = (data!== null) ? data.height : '';
      video_attributes['controls'] = true;
      video_attributes['className'] = 'video-fit-wrapper';

      if(data!== null && data.checkBoxStatus){
      video_attributes['autoPlay'] =true;
      video_attributes['muted'] =true;
      video_attributes['preload'] = true;
    }
    div_level2_attributes['className'] = 'form-group';
    div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-video';

    let src = question;
    let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})

    let label_tag =
                     React.createElement("label", {
                        for: name,
                        name: name,
                        className: ' control-label',
                      }, name,((info!== null && info !== undefined) ? tooltip_tag : ''));
    div_radio_class['className'] = (data !== null && data.showlabel) ? 'dividing-fields video-fields' : 'col-md-12';

    let video_tag = React.createElement('div', {'className' : 'wf-web-form-control'},
                     React.createElement('video',
                       video_attributes
                       , React.createElement(
                         'source', tag_attributes
                       )
                     ));
     let div_structure_check = React.createElement('td','',
       React.createElement('div', div_level1_attributes,
       React.createElement('div', div_level2_attributes,
       React.createElement('div', {'className' : 'row'},
       (data !== null && data.showlabel ? label_tag : ''),
       React.createElement('div', div_radio_class,
       React.createElement('div', {'className' : 'col-md-12'},
       video_tag),
       React.createElement('div', {'className' : 'col-md-2'}),
       )
       )
       )
       )
     );
     let tr_tag = React.createElement(
                   'tr',
                   '',
                   div_structure_check,
                 );

     let table_tag =  React.createElement(
                       'table',
                       table_attributes,
                       tr_tag
                     );

     return table_tag;
   }

   constructSignatureTag(id, type, name, data, ruleProperties) {
     const enable = ruleProperties[id][ENABLE];
     const disable = ruleProperties[id][DISABLE];
     const required =  this.generateRequireAttributeValue(ruleProperties[id])
     const empty = ruleProperties[id][EMPTY];
     const show = ruleProperties[id][SHOW];
     const hide = ruleProperties[id][HIDE];
     const css = ruleProperties[id][CSS];
     const info = (data !== null) ? data.information : '';

     var div_level2_attributes = {};
     var div_level1_attributes = {};
     var div_radio_class={};

     let tag_attributes = {};
     let signature_style = {
       width: '25%',
       backgroundColor: '#fff',
       border: '1px solid #ced4da',
       borderRadius: '5px',
       margintop: '20px',
     }
     tag_attributes['id'] = id;
     tag_attributes['name'] = id;
     tag_attributes['height'] = data.height;
     tag_attributes['width'] = data.width;
     tag_attributes['value'] = (this.props.datavalue !== undefined) ? this.props.datavalue : '';
     // tag_attributes['value'] =
     // tag_attributes['className'] = signature_style;
       tag_attributes['handleChange'] = this.props.handleSignature;
       tag_attributes['required'] = required;
       tag_attributes['disabled'] =   this.generateDisableAttributeValue(enable,disable)
       if(empty){
        tag_attributes['value']  = '';
        this.props.emptyStateById(id)
      }
       div_level2_attributes['className'] = 'form-group';
       div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-signature';
       let src = question;
       let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})

       let label_tag =  React.createElement("label", {
                           for: name,
                           name: name,
                           className: ' control-label',
                         }, name + ' ', (required ? mandatory_field :''),((info !== null && info !== undefined) ? tooltip_tag : ''));
    div_radio_class['className'] = (data !== null && data.showlabel) ? 'dividing-fields signature-fields' : 'col-md-12';

    let signature =  React.createElement('div', {'className' : 'wf-web-form-control'},
    React.createElement(SignaturePad, tag_attributes));
    let div_structure_check = React.createElement('td','',
      React.createElement('div', div_level1_attributes,
      React.createElement('div', div_level2_attributes,
      React.createElement('div', {'className' : 'row'},
      (data !== null && data.showlabel ? label_tag : ''),
      React.createElement('div', div_radio_class,
      React.createElement('div', {'className' : 'col-md-12'},
      signature),
      React.createElement('div', {'className' : 'col-md-2'}),
      )
      )
      )
      )
    );
     let tr_tag = React.createElement(
                   'tr',
                   '',
                   div_structure_check,
                 );

     let table_tag =  React.createElement(
                       'table',
                       table_attributes,
                       tr_tag
                     );

     return table_tag;

   }

     constructFormNumberTag(id, type, name, data, ruleProperties) {
       const enable = ruleProperties[id][ENABLE];
       const disable = ruleProperties[id][DISABLE];
       const required =  this.generateRequireAttributeValue(ruleProperties[id])
       const empty = ruleProperties[id][EMPTY];
       const defaultvalue =  ruleProperties[id][DEFAULT];
       const show = ruleProperties[id][SHOW];
       const hide = ruleProperties[id][HIDE];
       const css = ruleProperties[id][CSS];

       const info = (data !== null) ? data.information : '';

     var div_level2_attributes = {};
     var div_level1_attributes = {};
     var div_radio_class={};
     var attributes = ['name', 'placeholder', 'min', 'value'];
     let state_value = '';
     var tag_attributes = {};
     var span_attributes = {};
     tag_attributes['id'] = id;

     let formNumValue = this.props.datavalue != undefined ? this.props.datavalue : '';
     tag_attributes['value'] = formNumValue.replace(/[\])}[{(]/g, '');
     tag_attributes['name'] = id;
     tag_attributes['type'] = 'text';
     tag_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
     // tag_attributes['onChange'] = this.props.handleChange;
     tag_attributes['className'] = 'form-control';
     span_attributes['id'] = 'e-' + id;
     span_attributes['className'] = 'error';
     if (data !== null) {
       Object.entries(data).forEach(([key, value]) => {
         var index = attributes.indexOf(key);
         if (index != -1 && key !== 'value' && key !== 'name') {
           if (key === 'require'  && required) {
             if (required)
               key = value = 'required';

           }
           tag_attributes[key] = value;
         }
       });
     }

       tag_attributes['style'] = css
       tag_attributes['disabled'] = this.generateDisableAttributeValue(enable,disable)
	if(empty){
         tag_attributes['value'] = '';
         this.props.emptyStateById(id)
       }

       div_level2_attributes['className'] = 'form-group';
       div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-formnumber';
       let src = question;
       let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})


      let label_tag = React.createElement("label", {
                         for: name,
                         name: name,
                         className: ' control-label',
                       }, name + ' ', (required ? mandatory_field :''),((info!==null && info !== undefined) ? tooltip_tag : ''));
     let span_tag =  React.createElement(
                     'span',
                     span_attributes,
                   );
     let input_tag = React.createElement('div', {'className' : 'wf-web-form-control'},
                 React.createElement(
                   'input',
                   tag_attributes,
               ),span_tag);
      div_radio_class['className'] = (data !== null && (data.Showlabel)) ? 'dividing-fields formnumber-fields' : 'col-md-12';
      let div_structure_check = React.createElement('td','',
        React.createElement('div', div_level1_attributes,
        React.createElement('div', div_level2_attributes,
        React.createElement('div', {'className' : 'row'},
        (data !== null && (data.Showlabel) ? label_tag : ''),
        React.createElement('div', div_radio_class,
        React.createElement('div', {'className' : 'col-md-12'},
        input_tag),
        React.createElement('div', {'className' : 'col-md-2'}),
        )
        )
        )
        )
      );
      // let form_td_tag = React.createElement(
      //                     'td','',
      //                      React.createElement('label','',
      //                     input_tag,
      //                     span_tag)
      //                   );

      let tr_tag = React.createElement(
                  'tr',
                  '',
                  div_structure_check,
                );

    let table_tag =  React.createElement(
                      'table',
                      table_attributes,
                      tr_tag
                    );

    return table_tag;
   }

   constructTimerTag(id, type, name, data, ruleProperties){

     const enable = ruleProperties[id][ENABLE]
     const disable = ruleProperties[id][DISABLE]
     const required = ruleProperties[id][REQUIRD]
     const empty = ruleProperties[id][EMPTY]
     const show = ruleProperties[id][SHOW];
     const hide = ruleProperties[id][HIDE];
     const css = ruleProperties[id][CSS];
     const info = (data !== null) ? data.information : '';

     var div_level2_attributes = {};
     var div_level1_attributes = {};
     var div_radio_class={};
     var tag_attributes = {};
     tag_attributes['id'] = id;
     tag_attributes['name'] = id;
     tag_attributes['data'] = (data!== null) ? data.countdowntime : '';
     tag_attributes['delaytime'] = (data!== null) ? data.timeofdelay : '';
     let src = question;
     let tooltip_tag  = React.createElement("img", {className: 'info-tooltip', src : src ,title: info,height:30,width:30,style:{cursor:'pointer','margin-top':5,'margin-left':7}})
     div_level2_attributes['className'] = 'form-group';
     div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-timer';
     let label_tag = React.createElement("label", {
                         for: name,
                         name: name,
                         className: 'col-mad-4 control-label',
                       }, name,((info !== null && info !== undefined) ? tooltip_tag:''));


     let timer = React.createElement('div', {'className' : 'wf-web-form-control'},
                       React.createElement(
                         Timerexample,
                         tag_attributes,
                       ));
     let stopwatch = React.createElement('div',{'className' : 'wf-web-form-control'},
                        React.createElement(
                          Stopwatch,
                          tag_attributes
                        ));
    let element = (data!== null && data.usestopWatch) ? stopwatch : timer;
     div_radio_class['className'] = (data !== null && data.showlabel) ? 'dividing-fields timer-section' : 'col-md-12';
     let div_structure_check = React.createElement('td','',
       React.createElement('div', div_level1_attributes,
       React.createElement('div', div_level2_attributes,
       React.createElement('div', {'className' : 'row form-group'},
       (data !== null && data.showlabel ? label_tag : ''),
       React.createElement('div', div_radio_class,

       React.createElement('div', {'className' : 'col-md-12'},
       element),
       React.createElement('div', {'className' : 'col-md-2'}),
       )
       )
       )
       )
     );
     let tr_tag = React.createElement(
                 'tr',
                 '',
               div_structure_check
     );


     let table_tag =  React.createElement(
                     'table',
                     table_attributes,
                     tr_tag,
                   );
     return table_tag;

   }

   constructChildformTag(id, type, name, data, ruleProperties){
     // data.linktype
     // const enable = ruleProperties[id][ENABLE]
     // const disable = ruleProperties[id][DISABLE]
     // const required = ruleProperties[id][REQUIRD]
     // const empty = ruleProperties[id][EMPTY]
     let tag_attributes = {};

     var div_level2_attributes = {};
     var div_level1_attributes = {};
     let childform = {};
     let childform_name = '';
     let childform_name_u = '';
     var div_radio_class={};
     tag_attributes['id'] = id;
     tag_attributes['name'] = id;
     tag_attributes['childform_name'] = (data!== null && data.name)
     tag_attributes['data'] = (data!== null && data)
     tag_attributes['childwebform'] = (data!== null && data.childform);
     tag_attributes['url'] = (data !== null && data.url!== null)?data.url:"";
     tag_attributes['normal_name'] = (data !== null && data.normal_name!== null)?data.normal_name:"";
     tag_attributes['normal_docType'] = (data !== null && data.normal_docType!== null)?data.normal_docType:"";
     tag_attributes['normal_code'] = (data !== null && data.normal_code!== null)?data.normal_code:"";
     tag_attributes['normal_version'] = (data !== null && data.normal_version!== null)?data.normal_version:"";

     tag_attributes['childautogenerate'] = (data !== null && data.automaticgeneration!==null && data.automaticgeneration!== '')?data.automaticgeneration:false;
     tag_attributes['handleSubmit'] = this.props.handleSubmit;
     tag_attributes['submit_id'] = this.props.submit_id;
     tag_attributes['webform_id'] = this.props.webform_id;
     tag_attributes['autoGenerateChildform'] = this.props.autoGenerateChildform;
     // tag_attributes['parent_id'] = this.props.parent_id;
     tag_attributes['parent_id'] = this.props.refid;
     tag_attributes['step_id'] = this.props.step_id;
     tag_attributes['refid'] = 0;
     // tag_attributes['refid'] = this.props.refid;
     tag_attributes['child_linked_unique_id'] = this.props.child_linked_unique_id;
     tag_attributes['getParentUpdateState'] = this.props.getParentUpdateState;
     tag_attributes['simulate'] = this.props.simulate;
     tag_attributes['todo_id'] = this.props.todo_id;
     tag_attributes['parentSaved'] = this.props.parentSaved;
     tag_attributes['selectlistname'] = (data !== null && data.selectlistname!="" && data.selectlistname != "select")?data.selectlistname : "";
     tag_attributes['caption'] = (data !== null && data.caption!="") ? data.caption : ""
     tag_attributes['target'] = (data !== null && data.targeta != "" && data.selectlistname != "select")?data.targeta:"";
     tag_attributes['disable_field'] = this.props.disable_field;
     div_level2_attributes['className'] = 'form-group';
     div_level1_attributes['className'] = 'wb-web-control label-control-wrapper wb-form-control-child';
     if (data !== null && parseInt(data.linktype) === 2) {
       if(data !== null && data.url == null) {
         tag_attributes['href'] = (data!== null && data.selectlistname)?data.selectlistname:"";
         childform_name = "test"
       }
       else {
         tag_attributes['href'] = (data!== null && data.url)?data.url:"";
        childform_name=  data.url;
       }
     }
     let label_tag = React.createElement("u", {
                         for: name,
                         name: name,
                         className: 'text-left control-label child-form-label',
                       }, name);
    if (data !== null && parseInt(data.linktype) === 1) {
       childform = React.createElement('div', {'className' : 'wf-web-form-control'},
                         React.createElement(
                          ChildformSimulate,
                           tag_attributes,
                         ));
    }
    else{
        childform=  React.createElement(ChildNormal, tag_attributes);
         // childform = React.createElement('div', {'className' : 'wf-web-form-control'},
         //                 React.createElement(
         //                   "a",
         //                  // ChildformNormal,
         //                   tag_attributes,
         //                   childform_name
         //                 ));
    }


         div_radio_class['className'] = (data !== null && data.showlabel) ? 'dividing-fields childform-fields text-left' : 'col-md-12';
         let div_structure_check = React.createElement('td','',
           React.createElement('div', div_level1_attributes,
           React.createElement('div', div_level2_attributes,
           React.createElement('div', {'className' : 'row'},
           (data !== null && data.showlabel ? label_tag : ''),
           React.createElement('div', div_radio_class,
           React.createElement('div', {'className' : 'col-md-12'},
           childform),
           React.createElement('div', {'className' : 'col-md-2'}),
           )
           )
           )
           )
         );

         let tr_tag = React.createElement(
                     'tr',
                     '',
                   div_structure_check
         );


         let table_tag =  React.createElement(
                         'table',
                         table_attributes,
                         tr_tag,
                       );
         return table_tag
   }

   constructLabelTag(id, type, name, data, ruleProperties) {
     const enable = ruleProperties[id][ENABLE];
     const disable = ruleProperties[id][DISABLE];
     const empty = ruleProperties[id][EMPTY];
     const defaultvalue =  ruleProperties[id][DEFAULT];
     const show = ruleProperties[id][SHOW];
     const hide = ruleProperties[id][HIDE];
     const css = ruleProperties[id][CSS];
     const label_value = (data!== null) ? data.label: '';
     let span_attributes = {};
     if(show){
       span_attributes['id'] = 'e-' + id;
       span_attributes['className'] = 'label_text';
       span_attributes['name'] = id;
       span_attributes['style'] = css;
       span_attributes['data-elementtype'] = window.ELEMENT_TYPE[type];
     }
     let table_tag = React.createElement('span', {span_attributes}, label_value);
     return table_tag;
   }

   // getSimulateWebformData(){
   //
   // }

   generateDisableAttributeValue(enable,disable){
      var disabled = true
        if(enable && !disable){console.log(disabled); return false};

      return disabled
   }
    generateRequireAttributeValue = (ruleProperties)=>{
     let enable  = ruleProperties[ENABLE]
     let disable  = ruleProperties[DISABLE]
     let show = ruleProperties[SHOW]
     let hide = ruleProperties[HIDE]
     let require = ruleProperties[REQUIRD]
     if(!show){
        return false;
     }else if(disable && !enable || !enable || disable ){
          return false
     }else{
       return require;
     }

   }
   getCustomCssStyle = (css)=>{
     let cssstyle = customStyles;
     if(css !== undefined && Object.keys(css).length>0){
       let newcssstyle = {
         option: (provided, state) => ({
           ...provided,
         backgroundColor:
           state.isSelected
                 ? css['background-color']
            :state.isFocused
               ? css.color
               : null,
           color:'black',
           ':active': {
               backgroundColor: !state.isDisabled && (state.isSelected ? css['background-color'] : css.color),
             },
         }),
         multiValue: (styles, { data }) => {
           return {
             ...styles,
             backgroundColor: css['background-color'],
           };
         },
         multiValueLabel: (styles, { data }) => ({
           ...styles,
           color: css.color,
         }),
         multiValueRemove: (styles, { data }) => ({
           ...styles,
           color: css.color,
           ':hover': {
             backgroundColor: css.color,
             color: css.color,
           },
         }),
         menuList: base => ({
               ...base,
               minHeight: 'fit-content',
         }),
	 control: styles =>
         ({ ...styles, backgroundColor: css['background-color'] }),
       }
       return newcssstyle;

   }
   return cssstyle
 }
 preventchange = (e)=>{
   return false;
 }

    render(){
      console.log(this.props)
      return(
              <>
              {this.constructTagElements(this.props.form_content.type)}
              </>
      );

    }




}
export default BlockBoxTagBuild;
