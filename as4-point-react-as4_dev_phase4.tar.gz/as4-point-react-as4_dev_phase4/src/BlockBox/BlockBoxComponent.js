import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import BlockBoxGeneral from './BlockBoxGeneralTab';
import BlockBoxRules from './BlockBoxRules';
import { Button, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import ReleaseTab from './ReleaseTab';
class BlockBoxComponent extends Component {
  constructor(props) {
     super(props)
     this.state = {
        tasks: [],
        items: [],
        types: [],
        selected: [{ 'approval_cycle': '' }],
        active_tab1: 1,
        credentials :true,
        t:props.t,
        condition: { action: 0, orgunit: 0, workflow: 0, control: 1 },
     }
  }
    render() {
        return (
          <>
              <div className="justify-content-center">
                  {/* <div className="col-md-11"> */}
                  {/* commited by sreenu */}
                  <div className="">

                      <div className="col-md-12 col-lg-12 px-0">
                          <reactbootstrap.Container className="Schedular-container ">
                              <reactbootstrap.Form >
                              <reactbootstrap.Tabs id="controlled-tab-example" className="header_tabs" >
                                  <reactbootstrap.Tab eventKey={1} title={("General")}>
                                    <BlockBoxGeneral
                                    handleSubmit={this.props.handleSubmit}
                                    handleCancel={this.props.handleCancel}
                                    handleChange={this.props.handleChange}
                                    handleSelect={this.props.handleSelect}
                                    details={this.props.details}
                                    handleSelectRadio={this.props.handleSelectRadio}
                                    />
                                  </reactbootstrap.Tab>
                                  <reactbootstrap.Tab eventKey={2} title={("Triggers")}>
                                   <BlockBoxRules
                                       blockboxId={this.props.details.blockboxId}
                                       type={ 1 }
                                      _webformid = {this.props.details.webform_id}
                                      handleRules = {this.props.handleRules}
                                   />
                                  </reactbootstrap.Tab>
                                  <reactbootstrap.Tab eventKey={3} title={("Release")}>
                                   <ReleaseTab
                                   handleSubmit={this.props.handleSubmit}
                                   handleCancel={this.props.handleCancel}
                                   handleChange={this.props.handleChange}
                                   handleSelect={this.props.handleSelect}
                                   handleChangeReleasPeriodType = {this.props.handleChangeReleasPeriodType}
                                   handleChangeReleaseWebform = {this.props.handleChangeReleaseWebform}
                                   handleReleasePeriodNumber = {this.props.handleReleasePeriodNumber}
                                   details={this.props.details}
                                   showCloseChildForm =  {this.props.showCloseChildForm}
                                   saveChildForm = {this.props.saveChildForm}
                                   handleCheckBox={this.props.handleCheckBox}
                                   resetChildForm={this.props.resetChildForm}
                                   editChildForm = {this.props.editChildForm}
                                   deleteChildForm ={this.props.deleteChildForm}
                                   cancelChildForm = {this.props.cancelChildForm}
                                   searchData = {this.props.searchData}
                                   addChildForm ={this.props.addChildForm}
                                   />
                                  </reactbootstrap.Tab>
                              </reactbootstrap.Tabs>
                              <reactbootstrap.FormGroup style={{ float: 'right' }} className="organisation_list mb-5 mt-2">
                                  <a onClick={this.props.handleCancel} >{('Cancel')}</a>
                                  &nbsp;&nbsp;&nbsp;
                                      {/* <reactbootstrap.Button className="btn btn-primary"  color="primary"> Save </reactbootstrap.Button > */}
                                  <Button type="submit" className="btn btn-primary" onClick={this.props.handleSubmit}>{('Save')}</Button>
                              </reactbootstrap.FormGroup>
                              </reactbootstrap.Form>
                          </reactbootstrap.Container>
                      </div>
                  </div>
              </div>
          </>
        )
      }
    }
export default translate(BlockBoxComponent);
