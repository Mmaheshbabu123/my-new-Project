import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import { filterArray } from '../_helpers/filter-array';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import Trigger from './BlockBoxForm';
import { Button, FormGroup } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';


class ManageBlockBox extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t: props.t,
      triggerList: [],
      blockbox_id: 0,
      searchList: [],
      tasks: [],
      tabs: [],
      addblockbox: false,
      editblockbox: false,
      receiver: true,
      latestDropped: [],
      webform_id: this.props.webform_id,
      allControlsOfWebform : [],
      emailreminder: 0,
      controlCount: 0,
      emailaddressCount : 0,
      addedWorkflow: 0,
      removedWorkflow: 0,
      // savedNow : 0,
      action:'create',
      cloneblockbox:false
    }
    this.handleBlockbox = this.handleBlockbox.bind(this);
    this.blockboxList = this.blockboxList.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  searchData = (e) => {
    var triggers = [...this.state.searchList];
    triggers = triggers.filter(function (item) {

      if (item.name !== null) {
          return (item.name).toLowerCase().toString()
            .indexOf(e.target.value.toLowerCase().toString()) !== -1;
        }
    });
    this.setState({
      triggerList: triggers
    });
  }

  async handleClick(id, showReceivers,reminder) {
    this.setState({
      addblockbox: false,
      editblockbox: false,
      cloneblockbox:false,
      blockbox_id: id,
      showReceivers: showReceivers,
      emailreminder:reminder
    });
  }

  handleBlockbox = () => {
    this.setState({
      addblockbox: true,
      receiver: false,
      editblockbox: false,
      cloneblockbox:false,
      action:'create',
      blockbox_id: 0,
    })
  }

  handleCancel() {
    this.setState({
      addblockbox: false,
      receiver: true,
      editblockbox: false,
      cloneblockbox:false
    })
  }

  showPopUp(id,Trigger_name) {
     confirmAlert({
      title:'Delete blockbox.',
      message:'Delete blockbox '+Trigger_name,
      buttons:[
        {
          label:'No',
        },
        {
          label:'Yes',
          onClick:()=> this.handleDelete(id)
        }
      ]
    });
  }
  handleDelete=(id)=>{
    datasave.service(window.DELETE_BLOCKBOX_DETAILS + '/' + id ,'POST')
      .then( response => {
        this.blockboxList();
      });
  }

  editBlockbox(id) {
    this.setState({
      blockbox_id: id,
      editblockbox: true,
      addblockbox: false,
      cloneblockbox:false,
      receiver: false,
      action:'edit'
    })
  }

  async blockboxList(id = 0, entity_type_id = '') {
    await datasave.service(window.GET_ALL_BLOCKBOX_DETAILS + '/' +this.props.webform_id ,'GET')
      .then(async response => {
        let res = response['data'];
        if (res != undefined && res.length > 0) {
          this.setState({
            triggerList: response['data'],
            searchList: response['data'],
            addblockbox:false,
            editblockbox:false,
            cloneblockbox:false,
            blockbox_id: id === 0 ? (response['data'][0] ? response['data'][0]['id'] : undefined) : id,
          //  showReceivers: id === '' ? (response['data'][0] ? (response['data'][0]['entity_type_id'] === 1046 ? true : false) : undefined) : (entity_type_id === '1046' ? true : false),
            // showReceivers: response['data'][0] ? (response['data'][0]['start_webform'] === 0 ? true : false) : undefined,
          //  webformId: response['data'][0]['webform_id'],
            //emailreminder:response['data'][0]['reminder'],
          });
        }
        else{
          this.setState({
            triggerList: [],
            searchList:[],
          })
        }
      })
  }

  componentDidMount() {
    // datasave.service(window.GET_ALLCONTROLS + '/' + this.state.webform_id,'GET')
    //   .then(response => {
    //     this.setState({
    //       allControlsOfWebform: response.data,
    //     })
    //   })

    this.blockboxList();
  }



  componentDidUpdate(prevProps, prevState) {

  }

cloneBlockBox(id){
  this.setState({
    action:'clone',
    blockbox_id: id,
    cloneblockbox: true,
    editblockbox: false,
    addblockbox: false,
    receiver: false,
  });
}

  getBlockboxes = (e) => {
    var trigger = this.state.triggerList;
    var webform_id = this.state.webform_id;

    let table = [];
    {
      trigger.length > 0 &&
        trigger.map(value => {
          let higlet_class = (value.id === this.state.blockbox_id) ? 'sactive' : 'sinactive';
          //when email template is null or 0, display both code and name for webform
            if(value.webform_id===webform_id) {
            table.push(
              <tr style={{borderTop: '1px solid lightgray'}} className={higlet_class}>
              <td onClick={e => this.handleClick(value.id, false,value.reminder)} style={{ cursor: 'pointer',display:'flex' }} title='webform'><span style={{ paddingRight: '5px' }}><i class="blockbox"/></span><span>{value.name}</span></td>
              <td style={{borderTop: '0px'}}>
                <div style={{ display: 'flex', textAlign: 'center' }} >
                    <i title="Edit" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc" onClick={this.editBlockbox.bind(this, value.id)}/>
                    <span style={{ paddingLeft: '10px', paddingRight: '10px' }}><i title="Clone" class="dashboard-tiles  dashboard-tiles-clone" onClick={this.cloneBlockBox.bind(this,value.id)}/></span>
                    <i title="Delete" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={this.showPopUp.bind(this,value.id, value.name)}/>
                </div>
                </td>
              </tr>
              )
          }
          //display just name for email template
        })
    }
    return table;
  }

  render() {
    const { t, showReceivers, emailreminder } = this.state;
    var pack_fun = this.state.tasks;
    const linkTabs = Object.values(this.state.tabs).map(
      function (itemlist, key) {
        pack_fun = filterArray(this.state.tasks, this.state.selected)
        return (
          <reactbootstrap.Tab eventKey={itemlist} title={itemlist} >
          </reactbootstrap.Tab>
        )
      }, this);
    return (
      <div>
        {/* <div className='row' > */}

        <div className='col-md-12 row p-0'>
          <div className='col-md-3'>
            <h4 className="mb-3 mt-2" style={{textAlign: 'center'}}>Blockbox List</h4>
             <reactbootstrap.Button style={{ float: 'right' }} type="button" onClick={this.handleBlockbox}> {t("Add Blockbox")}</reactbootstrap.Button>
            <input type="text" className="form-control search-box-border col-md-6" placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#ec661c" }} onChange={this.searchData} /><br />
            <div className='col-md-12' style={{ height: '377px', overflow: 'auto',border: '1px solid lightgray',borderRadius: '5px',padding: '5px'}}>
              <reactbootstrap.Table className="site-table-main">
                <tbody>
                  {this.getBlockboxes()}
                </tbody>
              </reactbootstrap.Table>
            </div>
          </div>
          {this.state.blockbox_id>0 && (this.state.receiver === true && this.state.addblockbox === false && this.state.triggerList.length>0) &&
            <div className='col-md-9 row pr-0'>
              <div className='col-md-4'>
                <reactbootstrap.Tabs id="controlled-tab-example">
                </reactbootstrap.Tabs>
              </div>
              {this.state.showReceivers &&
                <div className='col-md-7'>
                  <reactbootstrap.Tabs id="controlled-tab-example">

                  </reactbootstrap.Tabs>
                </div>
              }
            </div>
          }
          {this.state.addblockbox === true && <div className='col-md-6'> <Trigger cancel={this.handleCancel.bind(this)} action = {this.state.action} webform_id={this.state.webform_id} id={this.state.blockbox_id} blockboxList={this.blockboxList.bind(this)} tableData={this.state.triggerList}/> </div>}
          {this.state.editblockbox === true && <div className='col-md-6'> <Trigger cancel={this.handleCancel.bind(this)} action = {this.state.action} webform_id={this.state.webform_id} id={this.state.blockbox_id} blockboxList={this.blockboxList.bind(this)} tableData={this.state.triggerList}/> </div>}
          {this.state.cloneblockbox === true && <div className='col-md-6'> <Trigger cancel={this.handleCancel.bind(this)} action = {this.state.action} webform_id={this.state.webform_id} id={this.state.blockbox_id} blockboxList={this.blockboxList.bind(this)} tableData={this.state.triggerList}/> </div>}
        </div>
        {/* </div> */}
        {(this.state.receiver === true && this.state.addblockbox === false) &&
          <FormGroup>
            <div style={{ float: 'right' }} className="organisation_list mt-3 mr-3">
              {/*<a onClick={this.handleCancel} >{t('Cancel')}</a>*/}
              &nbsp;&nbsp;&nbsp;
             <Button className="btn btn-primary" type="button" color="primary" onClick={this.handleSubmit}> {t('Save')} </Button>
            </div>
          </FormGroup>
        }
      </div>
    )
  }
}

export default translate(ManageBlockBox)
