import React, { Component } from 'react'
import * as Reactbootstrap from 'react-bootstrap'
import { translate } from '../language'
import SubActions from '../Webforms/Actions/SubActions'
import DisplayRules from '../Webforms/WebElements/DisplayRules'
import { create } from '../_components/SchedularComponents/Actions/CreateRule';
import { datasave } from '../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import { filter } from '../Webforms/Actions/ActionFilter';
import { store } from '../store'
class BlockBoxRules extends Component {
     SUBACTIONSDATA = ''
    Email = { action: 1, orgunit: 0, workflow: 1, control: 0 }
    webform = { action: 1, orgunit: 1, workflow: 1, control: 1 }
    constructor(props) {
        super(props);
        this.state = {
            t: props.t,
            orgArrayIds: window.WEBFORM_ORG_ID,
            DisplayOptions: { action: 1, orgunit: 1, workflow: 1, control: 1 },
            editClick: false,
            popUpShow: false,
            treeData: [],
            openNodes: [],
            editclick: false,
            deleteclick: false,
            clickid: undefined,
            activeKey: undefined,
            showworkflow: 1,
        }
    }
    componentDidUpdate(prevProps) {
        let d = prevProps.blockboxId !== this.props.blockboxId ? this.getApiDataRules() : 1;
    }
    UNSAFE_componentWillMount() {
            datasave.service(window.GET_ORG_UNITS + '/' + this.props._webformid, 'GET').then(res=>{
                this.SUBACTIONSDATA = res
            })
        this.getApiDataRules();
    }
  async  getApiDataRules() {
        const { t } = this.state
        let storage = store.getState();
        let controlTypes = storage.UserData.webform_controls;
        let blockboxId = (this.props.blockboxId != '')?this.props.blockboxId:0;
        let url = window.GET_BLOCKBOX_RULES + '/' + blockboxId + '/' + this.props._webformid;
      await  datasave.service(url, 'GET').then(
          async  result => {
                if (result['status'] === 200  && this.props.blockboxId !== undefined) {
                    if(result['length'] ===1){
                   let obj = await filter.latestdata(result.data, controlTypes)
                   this.setState({
                       treeData: obj[this.props.blockboxId] !== undefined ? obj[this.props.blockboxId][0]['tree_data']:[],
                       openNodes:   [],
                       //obj[this.props.triggerId] !== undefined && obj[this.props.triggerId][0]['open_nodes'] != 'null' && obj[this.props.triggerId][0]['open_nodes']&& obj[this.props.triggerId][0]['open_nodes'] !== null !== undefined ?JSON.parse(obj[this.props.triggerId][0]['open_nodes']):[],
                       DisplayOptions: this.props.type === 0 ? this.Email : this.webform,
                       clickid: undefined,
                   })
                    }else{
                        this.setState({
                            treeData:[],
                            openNodes:[],
                            DisplayOptions: this.props.type === 0 ? this.Email : this.webform,
                            clickid: undefined,
                        })
                    }
                } else {
                    OCAlert.alertError(t('We were sorry,error occured while fetching rules.'), { timeOut: window.TIMEOUTNOTIFICATION });
                }
            }
        )
    }

    handleTreeClick = (e, activekey = undefined) => {
        const { index, key, action, control, operator, orgid, value,
            workflow, orgname, type, name, controlType,
            workflowid, controlid, operatorId, onenter,required, overwrite,css, showworkflow ,valueType,isDateType,count,periodtype,category, valueId} = e;
        let openNodes = this.state.openNodes;
        let node = activekey === undefined ? key : activekey
        if (openNodes.includes(node)) {
            var i = openNodes.indexOf(node);
            if (i !== -1) openNodes.splice(i, 1);
        } else {
            openNodes.push(node)
        }
        this.setState({
            clickid: index, editaction: action,
            editcontrol: control, editoperator: operator, editorgname: orgname,
            editorgid: orgid, editvalue: value, editworkflow: workflow,
            editworkflowid: workflowid,
            edittype: parseInt(type), editauthor: name, editcontroltype: controlType,
            editcontrolid: parseInt(controlid),
            editoperatorid: parseInt(operatorId),
            activeKey: activekey !== undefined ? activekey : key,
            openNodes: openNodes,
            editleave: overwrite,
            editenter: onenter,
            editcss:css,
            overwrite:overwrite,
            required:required,
            showworkflow: showworkflow,
            editvalueType:valueType,
            editisDateType:isDateType,
            DisplayOptions:  showworkflow === 1 && this.props.type === 0 ? this.Email:this.webform,
            category:category,
            count:count,
            periodtype:periodtype,
            valueId : valueId,
        })
    }
    handleRule(e, type) {
        const { showworkflow } = this.state

        this.setState({
            ruleclick: true,
            type: type,
            popUpShow: true,
            DisplayOptions: this.webform
        })
        if (showworkflow === 1 && type !== 1 && this.props.type === 0) {
            this.setState({
                DisplayOptions: this.Email
            })
        } else {

        }

    }
    handleEditDeleRule(e, type) {
        if (type) {
            this.setState({
                editclick: true, popUpShow: true, type: 0,
            })
        } else {
            this.setState({
                deleteclick: true
            }, () => {
                let data = create.createRule({}, this.state.treeData, this.state)
                let openNodes = this.state.openNodes
                var i = openNodes.indexOf(this.state.activeKey);
                if (i !== -1) openNodes.splice(i, 1);
                this.setState({
                    treeData: data.tree,
                    deleteclick: false,
                    openNodes: openNodes
                }, () => {
                    this.postRuleData();
                    if (data.tree.length == 0) {
                        this.setState({ showworkflow: 1 })
                    }
                })
            })
        }
    }
    changeComponent = (saved, obj = {}) => {
        if (saved) {
            let prevStateTreeData = this.state.treeData;
            const data = create.createRule(obj, this.state.treeData, this.state)
            this.setState({
                popUpShow: false,
                editclick: false,
                treeData: data.tree,
                overwrite: obj.overwrite,
                required: obj.required,
            }, () => {
                this.postRuleData();
                if (prevStateTreeData.length > 0)
                    this.updateActiveNodes(data.createdobj, data.nodeadded);
            })
        } else {
            this.setState({
                popUpShow: false,
                editclick: false,
            })
        }
    }
    updateActiveNodes = (obj, nodeadded) => {
        let key1; const { key } = obj;
        if (nodeadded) {
            key1 = this.state.activeKey + '/' + key;
        } else {
            var removedIndex = this.state.activeKey.substring(this.state.activeKey.lastIndexOf("/"));
            var active = this.state.activeKey.replace(removedIndex, "");
            if (active != '') {
                key1 = active + '/' + key
            } else {
                key1 = key
            }
        }
        this.handleTreeClick(obj, key1);
    }

    displayPopUpForRuleAdd = () => {
        const { editclick, popUpShow, required, overwrite, showworkflow, type, DisplayOptions } = this.state;

        return (<Reactbootstrap.Modal show={popUpShow} size='lg'>
            <Reactbootstrap.Modal.Body>
                {<SubActions
                    action={(this.props.type === 0 && DisplayOptions.orgunit == 0) ? window.WEBFORM_WORKFLOW : window.PERSON_ENTITY}
                    changeComponent={this.changeComponent}
                    type={DisplayOptions}
                    edit={editclick}
                    data={this.sendEditData()}
                    webelement_id={45}
                    webform_id={this.props._webformid}
                    releaseblockbox = {true}
                      SHOWCSS = {true}
                    triggers={this.props.type === 0 && DisplayOptions.orgunit == 0 ? true : false}
                    apidata = {this.SUBACTIONSDATA}
                />}
            </Reactbootstrap.Modal.Body>
        </Reactbootstrap.Modal>
        );
    }
    postRuleData = () => {
        const { t } = this.state
        const data = this.createDataToPost();
        this.props.handleRules(data);
        // datasave.service(window.POST_TRIGGER_RULE, 'POST', this.createDataToPost()).then(
        //     response => {
        //         if (response['status'] == 200) {
        //             OCAlert.alertSuccess(t('Rules has been updated successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
        //         } else {
        //             OCAlert.alertError(t('Error occured while storing rules!'), { timeOut: window.TIMEOUTNOTIFICATION });
        //         }
        //     })
    }
    createDataToPost = () => {
        const { treeData, openNodes } = this.state;
        return {
            treeData: treeData,
            openNodes: openNodes,
            webform_id: this.props._webformid,
            trigger_id: this.props.triggerId,
            // releaseoptions: {
            //     required: this.state.required,
            //     overwrite: this.state.overwrite
            // }
        }
    }
    render = () => {
        const { treeData, clickid, activeKey, openNodes ,t} = this.state;
        const disableButtons = clickid === undefined;
        let showButton = treeData.length >= 1;
        return (
            <Reactbootstrap.Row className="row  mt-1 ">
                <td className="mt-2 ml-3">
                    <Reactbootstrap.Button className="mb-2 mr-2" variant="outline-primary" onClick={(e) => this.handleRule(e, 0)} disabled={treeData.length === 0 ? false : disableButtons}>{t("Add OR")}</Reactbootstrap.Button>
                    &nbsp;{showButton && <Reactbootstrap.Button className="mb-2 mr-2" variant="outline-success" onClick={(e) => this.handleRule(e, 1)} disabled={disableButtons}> {t("Add AND")}</Reactbootstrap.Button>} &nbsp;
                    {showButton && < Reactbootstrap.Button className="mb-2 " variant="outline-warning" onClick={(e) => this.handleEditDeleRule(e, 1)} disabled={disableButtons} > {t("Edit")}</Reactbootstrap.Button>}&nbsp;
                    {showButton && <Reactbootstrap.Button className="mb-2"  variant="outline-danger" onClick={(e) => this.handleEditDeleRule(e, 0)} disabled={disableButtons} >{t("Remove")}</Reactbootstrap.Button>}
                </td>
                <DisplayRules data={treeData} handleTreeClick={this.handleTreeClick} active={activeKey} openNodes={openNodes} />
                {this.displayPopUpForRuleAdd()}
            </Reactbootstrap.Row>
        )
    }
    sendEditData = () => {
        const {
            editaction, editauthor, editorgname, editorgid,
            editcontrol, editoperator, editvalue, editworkflow, editcontroltype,
            editworkflowid, editcontrolid, valueId,editoperatorid,required,overwrite, editenter, editleave ,editcss,editvalueType,editisDateType,
            count,periodtype,category} = this.state
        if (this.state.editclick) {
            return {
                action: editaction,
                author: editauthor,
                orgid: editorgid,
                orgunit: editorgname,
                workflow: editworkflow,
                workflowid: editworkflowid,
                controlid: editcontrolid,
                control: editcontrol,
                controlType: editcontroltype,
                valueId:valueId,
                // (this.state.treeData[0]['valueId']!== undefined)?this.state.treeData[0]['valueId']:undefined,
                editcss :editcss,
                value: editvalue,
                operatorId: editoperatorid,
                operator: editoperator,
                overwrite: overwrite,
                required: required,
                valueType:editvalueType,
                isDateType:editisDateType,
                count:count,
                periodtype:periodtype,
                category:category
            }
        }
        return {};
    }

}
export default translate(BlockBoxRules)
