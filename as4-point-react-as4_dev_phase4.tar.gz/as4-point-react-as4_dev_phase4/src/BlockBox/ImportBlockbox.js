import React, { useState, useEffect, } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../language';
import axios from 'axios';
import {store } from '../store';
import { datasave } from '../_services/db_services';
const ImportBlockBox=(props)=>{
  const t = props.t;
  const [importData,setImportData] = useState({
    file:'',
    file_details: '',
    show:false,
    popUpData:[]
  });
  const {file,file_details,show,popUpData}=importData;
  useEffect(() => {
    const baseState =async ()=>{
      setImportData({
        ...importData,
        file:'',
        file_details: '',
        show:false,
        popUpData:''
      })
    }
    baseState();
  },[])
  const handleChange = (e)=>{
    setImportData({
      ...importData,
      file:e.target.files[0]['name'],
      file_details: e.target.files[0]
    })
  }
  const updateBatchcodes = async (e)=>{
    await datasave.service(window.UPDATE_BATCH_CODE_PERSONS,'POST','')
      .then(result => {
          if(result['status']===200){
          OCAlert.alertSuccess(t('Updated successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
        }else{
          OCAlert.alertWarning(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      });
  }

  const uploadFile =async (e)=>{
    if(file_details!==''){
      const formData = new FormData();
      let Userdata = store.getState();
      var details = {
        file: file_details,
        loginPerson_Id :Userdata.UserData.user_details.person_id,
      }
      for (var key in details) {
        formData.append(key, details[key]);
      }
      // formData.append('file', file_details);
      document.getElementById("loding-icon").setAttribute("style", "display:block;");
      await axios.post(window.backendURL + window.IMPORT_BLOCK_BOX_PERSOSN, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
      .then(async response => {
        let data = response.data;
        document.getElementById("loding-icon").setAttribute("style", "display:none;");
        if(data.status===200){
          responseStatus(data.data[0],data.data[1]);
        }else{
          OCAlert.alertError(t('Something went wrong please try with correct  file'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      });
    }
  }
  const responseStatus=(number,data)=>
  {
    switch (number) {
      case 1:
      OCAlert.alertWarning(t('Please import correct format file'), { timeOut: window.TIMEOUTNOTIFICATION });
      break;
      case 2:
      OCAlert.alertWarning(t('There is no data to import'), { timeOut: window.TIMEOUTNOTIFICATION });
      break;
      case 3:
      OCAlert.alertWarning(t('Email should be unique for each person'), { timeOut: window.TIMEOUTNOTIFICATION });
      break;
      case 4:
      OCAlert.alertWarning(t('Barcode should be unique for each person'), { timeOut: window.TIMEOUTNOTIFICATION });
      break;
      case 5:
      OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
      break;
      case 6:
      setImportData({
        ...importData,
        show:true,
        popUpData:data
      });
      break;
    }
  }
  const openClosePopup=()=>{
    setImportData({
      ...importData,
      show:false,
      popUpData:[]
    });
  }
  const clearForm =()=>{
    setImportData({
      ...importData,
      show:false,
      popUpData:[],
      file:'',
      file_details: '',
    });
  }
  const generateFiles=async()=> {
      await datasave.service('/api/generateBlockBoxPersonFile', "GET")
          .then(response => {
              var a = document.createElement("a");
              a.setAttribute("type", "file");
              a.href = response.file;
              a.download = response.name;
              document.body.appendChild(a);
              a.click();
              a.remove();
            }
          );

  }
  const generateSampleFiles=async()=>{
    await datasave.service('/api/generateSampleBlockBoxPersonFile', "GET")
        .then(response => {
            var a = document.createElement("a");
            a.setAttribute("type", "file");
            a.href = response.file;
            a.download = response.name;
            document.body.appendChild(a);
            a.click();
            a.remove();
          }
        );
  }
  const popUp = ()=>{
    let data = popUpData &&Object.values(popUpData).map(item=>{
      return(
        <tr style={{ textAlign: 'center' }}>
        <td>{item.name}</td>
        <td>{item.email}</td>
        <td>{item.batch_code}</td>
        </tr>
      );
    })
    return(
      <reactbootstrap.Modal
      show={show}
      onHide={(e) => openClosePopup()}
      dialogClassName="modal-90w"
      aria-labelledby="example-custom-modal-styling-title"
      >
      <reactbootstrap.Modal.Header closeButton>
      <reactbootstrap.Modal.Title>{t('Please verify this users and import again')}</reactbootstrap.Modal.Title>
      </reactbootstrap.Modal.Header>
      <reactbootstrap.Modal.Body>
      <reactbootstrap.Table responsive striped bordered hover size="sm">
      <thead style={{ backgroundColor: '#EC661C', color: '#fff', position: 'sticky', top: '0', textAlign: 'center' }}>
      <tr style={{ textAlign: 'center' }}>
      <th>{t('Name')}</th>
      <th>{t('Email')}</th>
      <th>{t('Batch code')}</th>
      </tr>
      </thead>
      <tbody>
      {data}
      </tbody>
      </reactbootstrap.Table>
      </reactbootstrap.Modal.Body>
      </reactbootstrap.Modal>)
    }
    return(
      <reactbootstrap.Container className='mt-5'>
      <reactbootstrap.Row className='pl-4'>
      <reactbootstrap.Col className='col-md-2 pt-4 ml-2'>
      <reactbootstrap.FormLabel>{t('Upload persons')}</reactbootstrap.FormLabel>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-6'>
      <reactbootstrap.InputGroup className="custom-file input_sw">
      <reactbootstrap.FormControl
      type="file"
      className="custom-file-input"
      id="inputGroupFile01"
      name='image'
      accept={".xlsx,.xls"}
      onChange={(e) => handleChange(e)}
      />
      <reactbootstrap.FormLabel className="custom-file-label" htmlFor="inputGroupFile01">
      {file !== null && file}
      </reactbootstrap.FormLabel>
      </reactbootstrap.InputGroup>
      <p>{t('Upload only excel format files.')}</p>
      <p onClick={(e) => generateSampleFiles()} style={{color: '#EC661C'}}>{t('Download sample file')}</p>
      <p onClick={(e) => generateFiles()} style={{color: '#EC661C'}}>{t('Download active persons file')}</p>
      { /**<p onClick={(e) => generateFiles()} style={{color: '#EC661C'}}>{t('Download active persons or sample file')}</p>*/}
        <p  onClick={(e) => updateBatchcodes(e)} style={{color: '#EC661C'}}>{t('Assign random batch code to all users')}</p>
      </reactbootstrap.Col>
      </reactbootstrap.Row>

      <reactbootstrap.Row className='pl-4 float-right'>
      <a id="cancel" className='mt-2 mr-3' active='true' onClick={(e) => clearForm()}>{t('Cancel')}</a>
      <reactbootstrap.Button  onClick={(e) => uploadFile(e)}>{t('Save')}</reactbootstrap.Button>{popUp()}
      </reactbootstrap.Row>
      </reactbootstrap.Container>
    )

  }
  export default translate(ImportBlockBox);
