import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { datasave } from '../_services/db_services';
import BlockBoxComponent from './BlockBoxComponent';
import { OCAlert } from '@opuscapita/react-alerts';
import { store } from '../store'
import { filter } from '../Webforms/Actions/ActionFilter';
const chilFormSkeleton = {
    id:0,
    name:'',
    caption:'',
    showName:true,
    // alias:'',
    url:'',
    automaticgeneration:false,
    saveinstedofforward:false,
    showChildForm:false,
    showSelectList:false,
    selectedManual:0,
    childform:0,
    selectlistname:0,
    child_type:0,
    selectedReports:[],
    language_data:[],
    showSaveForward:false,
    disabled:false,
    blockBoxpersons:[],
    inOutPersons:1,
    caption_translation:[],
};
class BlockBoxForm extends Component {
  constructor(props) {
     super(props)
     this.handleSubmit = this.handleSubmit.bind(this)
     this.handleChange = this.handleChange.bind(this)
     this.handleCancel = this.handleCancel.bind(this)
     this.handleSelect = this.handleSelect.bind(this)
     this.handleRules = this.handleRules.bind(this)
     this.handleEditdata = this.handleEditdata.bind(this);
     this.state = {
       name:'',
       blockboxId:'',
        release_actor_type:1,
        release_actor_type_id:0,
        webform_id:this.props.webform_id,
        amount:1,
        amount_all:0,
        release_method_id:1,
        from_distance:true,
        selected: [{ 'approval_cycle': '' }],
        active_tab1: 1,
        work_flow:[],
        allOrgUnits:[],
        step_id:0,
        workflowsteps:[],
        BlockboxRules:[],
        resultData:[],
        t:props.t,
        resolve:false,
        number_of_blockboxes:0,
        condition: { action: 0, orgunit: 0, workflow: 0, control: 1 },
        releaseWebforms:[],
        // selectedReleaseWebform:[],
        stopWebform:false,
        releasePeriodTypeOptions:[
          {label:props.t('Minutes'),value:1},
          {label:props.t('Hours'),value:2},
          {label:props.t('Days'),value:3},
          {label:props.t('Weeks'),value:4},
          {label:props.t('Months'),value:5},
          {label:props.t('Years'),value:6}],
        releasePeriodTypeSelectedOptions:{label:props.t('Minutes'),value:1},
        releasePeriodNumber:'',
        showChildForm:false,
        chidForm:false,
        manualListOptions:[],
        language_list:[],
        childformData:{...chilFormSkeleton},
        arrayChildForm:[],
        childFormName:'',
        copyArrayChildForm:[],
        originalChildForms:[],
     }
     this.baseState = ({
       name:'',
       blockboxId:'',
        release_actor_type:1,
        release_actor_type_id:0,
        amount:1,
        amount_all:0,
        release_method_id:1,
        from_distance:true,
        webform_id:this.props.webform_id,
        selected: [{ 'approval_cycle': '' }],
        active_tab1: 1,
        work_flow:[],
        step_id:0,
        BlockboxRules:[],
        resultData:[],
        t:props.t,
        condition: { action: 0, orgunit: 0, workflow: 0, control: 1 },
        // selectedReleaseWebform:[],
        stopWebform:false,
        releasePeriodTypeSelectedOptions:{label:props.t('Minutes'),value:1},
        releasePeriodNumber:'',
        showChildForm:false,
        allowChildForm:false,
        inOutPersons:1,
        number_of_blockboxes :0,
          resolve:false,
          childFormName:'',
     })
  }
  getBlockBoxTreedata(blockboxId) {
    const { t } = this.state
    let storage = store.getState();
    let controlTypes = storage.UserData.webform_controls;
    let url = window.GET_BLOCKBOX_RULES + '/' + blockboxId + '/' + this.props.webform_id;
      datasave.service(url, 'GET').then(
        result => {
            if (result['status'] === 200  && blockboxId !== undefined) {
                if(result['length'] ===1){
               let obj = filter.latestdata(result.data, controlTypes)
               let blockBoxtree = {webform_id: this.props._webformid}
               blockBoxtree['treeData'] = obj[blockboxId] !== undefined ? obj[blockboxId][0]['tree_data']:[];
               this.setState({
                   BlockboxRules: blockBoxtree,
                   //obj[this.props.triggerId] !== undefined && obj[this.props.triggerId][0]['open_nodes'] != 'null' && obj[this.props.triggerId][0]['open_nodes']&& obj[this.props.triggerId][0]['open_nodes'] !== null !== undefined ?JSON.parse(obj[this.props.triggerId][0]['open_nodes']):[],
               })
                }else{
                  this.setState({
                     BlockboxRules:[],
                  })

                }
              }
            })


  }
  async componentDidMount() {

        if (this.props.action === 'create') {
          this.setState(
            this.baseState
          )
          // this.fetchwebForms([]);
        }else{
          this.editFlow();
        }
      await  this.getTranslations();
      await  this.getAllManuals();
      await  this.getOrgunits();
      await  this.getBlockBoxImportPersons();
  }
  getBlockBoxImportPersons=async()=>{
    await datasave.service(window.GET_BLOCK_BOX_IMPORTED_PERSONS,'GET')
          .then(async response=>{
            if(response.status===200){
            this.setState({
              blockBoxpersons:response['data']
            })
          }
          })
  }
  getOrgunits=async ()=>{
  await  datasave.service(window.GET_ORG_UNITS + '/' + this.props.webform_id, 'GET')
        .then(async response => {
          await this.setState({
          allOrgUnits: response,
          workflowsteps: response['workflow'],
        })
        })
  }
getTranslations=async ()=>{
    await datasave.service(window.GET_TRANSLATION,'GET')
    .then(async result=>{
      await  this.setState({
          language_list:result
        });
    })
  }
  editFlow = ()=>{
    datasave.service(window.GET_BLOCKBOX_DETAILS + '/' + this.props.id, 'GET')
      .then(async resultObj => {
        this.setState({
          resultData: resultObj,
        },async () => {
        await  this.handleEditdata(resultObj)
        // await  this.fetchwebForms(resultObj);
        });
      })
  }
  // fetchwebForms =async (resultObj) =>{
  //   let data = {manual_id: 0,type: 22};
  //   await datasave.service(window.GETSTARTWEBFORM_DATA, "GET", data)
  //   .then(async result =>{
  //     if (this.props.action!=='create') {
  //        this.setState({
  //          selectedReleaseWebform:result['data'][resultObj.general.releasewebform]
  //        });
  //     }
  //     this.setState({releaseWebforms: this.sort(result['data'])});
  //   });
  // }
  sort=(data)=>{
    return Object.values(data).sort(function(a,b){return (a.label).toLowerCase() < (b.label).toLowerCase() ? -1 : 1;});
  }
  componentDidUpdate(prevProps) {
    if (this.props.id != prevProps.id) {
      this.componentDidMount();
    }
  };
  handleRules(data) {
    this.setState({
      BlockboxRules:data,
    })

  }
  handleChange(event) {
    const { name, value } = event.target;
    this.setState({ [name]: value,
                     // start_date_time:datetime,
     });
   }
   handleCheckBox=(e,checkBoxName)=>{
     const {checked}=e.target;
     this.setState({
       [checkBoxName]:checked
     })
   }
   handleSelect(event) {
     const { name ,checked} = event.target;
     const {showChildForm} =this.state;
     console.log(name);
     if(name==='allowChildForm'){
       this.setState({
         // allowChildForm:checked,
         showChildForm:!showChildForm,
         childformData:chilFormSkeleton,
         childFormName:''
       })
     }else{
       this.setState({
         [name]: !this.state[name],
       })
     }
   }
  async handleEditdata(details) {
   let general = details.general;
   let filterdValue = this.state.releasePeriodTypeOptions.filter(item=>{return item.value===general.release_period_type});
   await this.getBlockBoxTreedata(this.props.id);
   await this.getBlockBoxChildForms(this.props.id);
       // var data = (general&& general.json_data) ? JSON.parse(general.json_data) : {};
       // let childform = {
       //   name:data.name?data.name:'',
       //   caption:data.caption?data.caption:'',
       //   showName:data.showlabel?data.showlabel:true,
       //   // alias:data.alias?data.alias:'',
       //   url:data.url?data.url:'',
       //   automaticgeneration:data.automaticgeneration?data.automaticgeneration:false,
       //   saveinstedofforward:data.saveinstedofforward?data.saveinstedofforward:false,
       //   showChildForm:data.showChildForm?data.showChildForm:false,
       //   showSelectList:data.showSelectList?data.showSelectList:false,
       //   language_data:data.language_data?data.language_data:[],
       //   caption_translation:data.caption_translation?data.caption_translation:[],
       //   selectedManual:data.selectedManual?data.selectedManual:0,
       //   childform:data.childform?data.childform:0,
       //   selectlistname:data.selectlistname?data.selectlistname:0,
       //   child_type:data.child_type?data.child_type:0,
       //   selectedReports:data.selectedReports?data.selectedReports:[],
       //   showSaveForward:data.showSaveForward?data.showSaveForward:false,
       //   disabled:data.disabled?data.disabled:false,
       //   linktype:data.linktype?data.linktype:0,
       //   targeta:data.targeta?data.targeta:0,
       // };
    this.setState({
       blockboxId:general.id,
       name:this.props.action==='edit'?general.name:'',
       release_actor_type:general.release_actot_type,
       release_actor_type_id:general.release_actor_id,
       amount:general.amount,
       amount_all:general.amount_all,
       release_method_id:general.release_method_id,
       from_distance:(general.from_distance ===1)?true:false,
       step_id:general.step_id,
       webform_id:general.webform_id,
       // selectedReleaseWebform:general.releaseWebform,
       releasePeriodNumber:general.release_period_number>0?general.release_period_number:'',
       stopWebform:general.stopwebform===1?true:false,
       resolve:general.resolve === 1? true:false,
       number_of_blockboxes:general.number_of_blockboxes,
       releasePeriodTypeSelectedOptions:filterdValue[0],
       // childformData:{...childform},
       allowChildForm:general.allow_child_form===1?true:false,
       inOutPersons:general.inoutpersons?general.inoutpersons:1
    });

  }
  getBlockBoxChildForms=async(id)=>{
    const {t} =this.state;
    datasave.service(window.GET_BLOCK_BOX_CHILDFORMS+'/'+id,'GET')
    .then(response=>{
      if(response['status']===200){
        this.setState({
          arrayChildForm:Object.values(response['data']),
          copyArrayChildForm:Object.values(response['data']),
          originalChildForms:Object.values(response['data']),
        })
      }else{
        OCAlert.alertWarning(t('Problem while fetching childform please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
        return false;
      }

    })
  }
  getAllManuals = async() => {
    await datasave.service(window.GET_MANUALS_REPORTS, 'GET')
        .then(response => {
            this.setState({
              manualListOptions  : response,
            })
        })
  }
  handleSubmit(event) {
    event.preventDefault()
    this.formSave();
    this.setState({
      submitted: 'true'
    });
  }
  formValidation() {
    const{t ,name,release_actor_type_id,release_method_id,step_id,selectedReleaseWebform,allowChildForm,childformData,resolve,copyArrayChildForm}=this.state
    if(name.length <1 || release_actor_type_id === 0 ||  release_method_id === 0 || (resolve && parseInt(step_id)<1)){
      OCAlert.alertWarning(t('Please fill mandatory fields'), { timeOut: window.TIMEOUTNOTIFICATION });
     return false;
   }else if ((this.props.action!=='edit'  && this.props.tableData.length>0 && this.checkDuplicateNamesCreateMode(this.props.tableData))|| (this.props.action==='edit' && this.props.tableData.length>1 && this.checkDuplicateNamesEditMode(this.props.tableData))) {
     OCAlert.alertWarning(t('Name should be unique for each blockbox '), { timeOut: window.TIMEOUTNOTIFICATION });
     return false;
   }else if (allowChildForm && copyArrayChildForm.length<1) {
     OCAlert.alertWarning(t('Please add childform'), { timeOut: window.TIMEOUTNOTIFICATION });
     return false;
   }
   else{
      return true;
    }
  }
  checkDuplicateNamesCreateMode=(data)=>{
    let presentCodes = data.map(item => { return item.name });
    return presentCodes.includes(this.state.name);
  }
  checkDuplicateNamesEditMode=(tableData)=>{
    let data = tableData.filter(item => { return item.id !== this.props.id });
    return this.checkDuplicateNamesCreateMode(data);
  }
  formSave() {
    if (this.formValidation()) {
      if (this.props.action ==='create') {
        this.storeBlockBoxData();
      }else if (this.props.action ==='edit') {
        this.updateBloxData();
      }else{
        this.cloneBloxData();
      }
    }
  }
  cloneBloxData=async()=>{
    const {t} =this.state;
    await datasave.service(window.CLONE_BLOCKBOX_DETAILS + '/' +this.props.id , 'POST', this.state)
      .then(result => {
          if(result['status']===200){
          OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
        this.props.blockboxList();
        }else{
          OCAlert.alertWarning(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      });
  }
  updateBloxData=async()=>{
    const {t} =this.state;
    await datasave.service(window.STORE_BLOCKBOX_DETAILS + '/' +this.props.id , 'PUT', this.state)
      .then(result => {
          if(result['status']===200){
          OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
        this.props.blockboxList();
        }else{
          OCAlert.alertWarning(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      });
  }
  storeBlockBoxData=async ()=>{
    const {t}=this.state;
    await datasave.service(window.STORE_BLOCKBOX_DETAILS, 'POST', this.state)
    .then(result => {
        if(result['status']===200 ){
            this.props.blockboxList();
      //  this.props.tables(result['data']);
        OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
      //  this.props.cancel();
      }else{
        OCAlert.alertWarning(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    });
  }
  handleCancel = (event) => {
    const {name,release_actor_type,release_actor_type_id,amount,amount_all,release_method_id,step_id,from_distance,stopWebform,releasePeriodNumber,originalChildForms,selectedReleaseWebform,releasePeriodTypeSelectedOptions} = this.state;
    if(!this.props.id && (name!=='' || release_actor_type>1|| release_actor_type_id>0||amount!=1|| amount_all!=0 || release_method_id!==1 || step_id!==0 ||from_distance!==true||stopWebform!==false||releasePeriodNumber!=''||releasePeriodTypeSelectedOptions.value!==1 )){
      this.setState(
        this.baseState
      );
      this.setState({
        arrayChildForm:originalChildForms,
        copyArrayChildForm:originalChildForms
      })
    }else{
      // this.editFlow();
      this.props.cancel();
    }
  }
  handleChangeReleasPeriodType=(e)=>{
    this.setState({
      releasePeriodTypeSelectedOptions:e
    })
  }
  // handleChangeReleaseWebform=(e)=>{
  //   this.setState({
  //     selectedReleaseWebform:e
  //   })
  // }
  handleReleasePeriodNumber=(e)=>{
    if (!isNaN(e.target.value)) {
      this.setState({
        [e.target.name]: e.target.value
      })
    }
  }
  showCloseChildForm=()=>{
    this.setState({
      showChildForm:!this.state.showChildForm
    })
  }
  cancelChildForm=()=>{
    this.setState({
    childformData:{...chilFormSkeleton},
    childFormName:'',
    showChildForm:!this.state.showChildForm
    })
  }
  saveChildForm=(data)=>{
    const {arrayChildForm,childFormName,t} =this.state;
    let filteredChildForm = [];
      filteredChildForm = arrayChildForm.filter(value=>{return  value.name!==childFormName});
    let uniqNames = filteredChildForm.map(value=>{return value['name']});
    if(uniqNames.includes(data.name)){
      OCAlert.alertWarning(t('Name should be unique for each childform'), { timeOut: window.TIMEOUTNOTIFICATION });
      return false;
    }else{

      filteredChildForm.push(data);
      this.setState({
        arrayChildForm:filteredChildForm,
        showChildForm:false,
        childFormName:data.name,
        childformData:{...chilFormSkeleton},
        copyArrayChildForm:filteredChildForm
      })
    }

  }
  handleSelectRadio=(e)=>{
  const {name,value}=e.target;
    this.setState({
      [name]:parseInt(value),
      release_actor_type_id:0,
    })
  }
  resetChildForm=()=>{
    this.setState({
      childformData:{...chilFormSkeleton},
      childFormName:''
    })
  }
  editChildForm=(data)=>{
    this.setState({
      childformData:data,
      childFormName:data.name,
    })
    this.showCloseChildForm();
  }
  deleteChildForm=(data)=>{
    const {arrayChildForm}=this.state;
    this.setState({
      arrayChildForm:arrayChildForm.filter(value=>{return value.name!==data.name}),
      childFormName:'',
      copyArrayChildForm:arrayChildForm.filter(value=>{return value.name!==data.name}),
    })
  }
  searchData=(e)=>{
    var list = [...this.state.arrayChildForm];
    let res ='';
    list = list.filter(value=>{
      if (value.name) {
      res = value.name.toLowerCase().search(
        e.target.value.toLowerCase()) !== -1;
      }
      if(res){
        return res;
      }
    });
    this.setState({
      copyArrayChildForm:list
    })
  }
  addChildForm=()=>{
    const {showChildForm,originalChildForms} =this.state;
    let uniqueIds = originalChildForms.map(value=>{return value['id']});
    chilFormSkeleton['id'] = this.randomNumberGenerator(uniqueIds);
    this.setState({
      // allowChildForm:checked,
      showChildForm:!showChildForm,
      childformData:chilFormSkeleton,
      childFormName:'',
    })
  }
  randomNumberGenerator=(uniqueIds)=>{
      let randomNumber = Math.floor(Math.random() * 100000) + 1;
      if(uniqueIds.includes(randomNumber)){
        return this.randomNumberGenerator(uniqueIds);
      }else{
        return randomNumber;
      }
  }
    render() {
      console.log(this.state.arrayChildForm);
        return (
          <div>
          <BlockBoxComponent
              handleSubmit = {this.handleSubmit.bind(this)}
              handleChange = {this.handleChange.bind(this)}
              handleCancel = {this.handleCancel.bind(this)}
              handleSelect = {this.handleSelect.bind(this)}
               handleRules = {this.handleRules.bind(this)}
               handleChangeReleasPeriodType = {this.handleChangeReleasPeriodType}
               handleReleasePeriodNumber = {this.handleReleasePeriodNumber}
               handleChangeReleaseWebform = {this.handleChangeReleaseWebform}
               showCloseChildForm={this.showCloseChildForm}
               saveChildForm={this.saveChildForm}
              details={this.state}
              handleSelectRadio={this.handleSelectRadio}
              handleCheckBox={this.handleCheckBox}
              resetChildForm = {this.resetChildForm}
              editChildForm = {this.editChildForm}
              deleteChildForm ={this.deleteChildForm}
              searchData ={this.searchData}
              addChildForm={this.addChildForm}
              cancelChildForm={this.cancelChildForm}
          />
          </div>
        )
      }
    }
export default translate(BlockBoxForm);
