import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import CheckBox from '../CheckBox';
import MultiSelect from '../_components/MultiSelect';
import TranslationTab from '../Webforms/TranslationTab';
class ReleaseChildFormPopUp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      t:props.t,
        name:'',
        caption:'',
        showName:false,//true
        alias:'',
        linktypeOptions:[],
        selectedLinkType:[],
        manualListOptions:[],
        selectedManualList:[],
        childFormOptions:[],
        selectedChildForm:[],
        targetOptions:[],
        selectedTargetOptions:[],
        url:'',
        selectListOptions:[],
        selectedList:[],
        autoGeneration:false,
        saveOrForward:false,
        tab:1,
        webReportOptions:[],
        selectedWebReport:[],
        language_data:[],
        language_list:this.props.language_list,
         WebformLinkType: [
            {label:props.t("Show new webform in pop-up"),value:1},
            {label:props.t("Open in new tab"),value:2}
          ],
        NormalLinkType:[
            {label:props.t("New window"),value:1},
            {label:props.t("Open in popup"),value:2}
          ],
        caption_translation:[]
      };
    }
async componentDidMount(){
  await this.setPropsData();
  await this.setDbData();
  await this.setTargetPropsData();
}

setTargetPropsData=async ()=>{
const{t}=this.state;
  var WebformLinkType = [
     {label:t("Show new webform in pop-up"),value:1},
     {label:t("Open in new tab"),value:2}
   ];
   var NormalLinkType = [
       {label:t("New window"),value:1},
       {label:t("Open in popup"),value:2}
     ];
  if(parseInt(this.props.details.linktype)===0){
    this.setState({
      targetOptions:[],
      selectedTargetOptions:[],
    })
  }else if (parseInt(this.props.details.linktype)===1) {
    this.setState({
      targetOptions:WebformLinkType,
      selectedTargetOptions:await WebformLinkType.filter(item=>item.value===parseInt(this.props.details.targeta))[0],
    })
  }else {
    this.setState({
      targetOptions:NormalLinkType,
      selectedTargetOptions:await NormalLinkType.filter(item=>item.value===parseInt(this.props.details.targeta))[0],
    })
  }
}
setPropsData=async()=>{
  const {t}=this.state;
  let linktype = [
    {label:t('Webform'),value:1},
    {label:t('Normal'),value:2},
  ]
  await this.setState({
      name:this.props.details.name?this.props.details.name:'',
      caption:this.props.details.caption?this.props.details.caption:'',
      showName:this.props.details.showlabel?this.props.details.showlabel:false,
      // alias:this.props.details.alias,
      linktypeOptions:linktype,
      selectedLinkType:this.props.details.linktype?await linktype.filter(response=>response.value===parseInt(this.props.details.linktype))[0]:[],
      manualListOptions:this.props.manualListOptions,
      selectedManualList:this.props.details.selectedManual?this.props.manualListOptions.filter(response=>response.value===parseInt(this.props.details.selectedManual))[0]:[],
      url:this.props.details.url?this.props.details.url:'',
      autoGeneration:this.props.details.automaticgeneration?this.props.details.automaticgeneration:false,
      saveOrForward:this.props.details.saveinstedofforward?this.props.details.saveinstedofforward:false,
      tab:1,
      language_data:this.props.details.language_data?this.props.details.language_data:[],
      caption_translation:this.props.details.caption_translation?this.props.details.caption_translation:[]
  })
}
  setDbData=async ()=>{
      await this.getChildSelectList(parseInt(this.props.details.selectedManual),parseInt(this.props.details.childform),parseInt(this.props.details.selectlistname));
      let data = {childform_id : parseInt(this.props.details.childform)};
      await this.getReports(data, this.props.details.selectedReports);
  }
  tabOnChange=(key)=>{
  this.setState({
      tab:key
    });
  }
  textOnchange=(e)=>{
    var {name,value}=e.target;
    this.setState({
        [name]:value
      });
  }
  handleCheckBox=(e,checkBoxName)=>{
    const {checked}=e.target;
    if(checkBoxName==='autoGeneration'){
      this.setState({
        saveOrForward:false,
      })
    }
    this.setState({
        [checkBoxName]:checked
      });
  }
  handleChangeLinkType=(e)=>{
    if(e.value==1){
    this.setState({
        selectedLinkType:e,
        targetOptions:this.state.WebformLinkType,
        selectedTargetOptions:[],
        selectedChildForm:[],
        selectedWebReport:[],
        url:'',
        selectedList:[],
        selectedManualList:[]
     });
   }else{
       this.setState({
          selectedLinkType:e,
          targetOptions:this.state.NormalLinkType,
          selectedTargetOptions:[],
          selectedChildForm:[],
          selectedWebReport:[],
          url:'',
          selectedList:[],
          selectedManualList:[]
        });
     }
  }
  handleChangeManualList=(e)=>{
  this.setState({
        selectedManualList:e,
        selectedReports:[],
        selectedTargetOptions:[],
        url:''
      });
      this.getChildSelectList(e.value,0,0);
  }
  getChildSelectList=async(manual_id,childId,listId)=>{
    const {t} =this.state;
    let data={manual_id : parseInt(manual_id)};
    await datasave.service(window.GET_CHILDFORM_SELECTLIST,'POST',data)
    .then(async result=>{
      if(result['status']===200){
        this.setState({
            childFormOptions:Object.values(result['data']['childElements']),
            selectListOptions:Object.values(result['data']['selectElements']),
            selectedChildForm:childId>0?result['data']['childElements'][childId]:[],
            selectedList:listId>0?result['data']['selectElements'][listId]:[]
          });
      }else{
        OCAlert.alertWarning(t('Something went wrong please try again later'),{ timeOut: window.TIMEOUTNOTIFICATION });
      }
    })
  }
  handleChangeTarget=(e)=>{

      this.setState({
            selectedTargetOptions:e,
            url:'',
          });
        }
  handleChangeChildForm=(e)=>{
    let data = {childform_id : e.value};
    this.setState({
        selectedChildForm:e
      });
      this.getReports(data, []);
  }
  getReports=async(data, selectedReport)=> {
    const {t}=this.state;
    await datasave.service(window.GETWEBFORMREPORT,"POST",data)
      .then(async response => {
        if(response['status']==='200'){
          this.setState({
              webReportOptions:response['data'],
              selectedWebReport:selectedReport
            });
        }else{
          OCAlert.alertWarning(t('Something went wrong please try again later'),{ timeOut: window.TIMEOUTNOTIFICATION });
        }
      });
  }
  handleChangeWebReport=(e)=>{
    this.setState({
        selectedWebReport:e
      });
  }
  handleChangeList=(e)=>{
    this.setState({
        selectedList:e
      });
  }
  handleTranslation=(name,value)=> {
       var obj = { [name]: value };
       var tempObj = { ...this.state.language_data, ...obj }
       this.setState({
           language_data:tempObj
         });
   }
   handleCaptionTranslation=(name,value)=>{
     var obj = { [name]: value };
     var tempObj = { ...this.state.caption_translation, ...obj }
     this.setState({
         caption_translation:tempObj
       });
   }
 saveChildForm=()=>{
   var {t,name,caption,showName,selectedLinkType,selectedManualList,selectedChildForm,selectedTargetOptions,url,selectedList,autoGeneration,saveOrForward,selectedWebReport,language_data,caption_translation}=this.state;
   if(name.length<1 ){
     OCAlert.alertWarning(t('Please enter mandatory fields'),{ timeOut: window.TIMEOUTNOTIFICATION });
     return;
   }
   let data ={
     id:this.props.details.id,
     name:name,
     // alias:alias,
     showlabel:showName,
     caption:caption,
     automaticgeneration:autoGeneration,
     linktype:selectedLinkType && selectedLinkType[0]?selectedLinkType[0].value:selectedLinkType && selectedLinkType.value?selectedLinkType.value.toString():0,
     saveinstedofforward:saveOrForward,
     selectedReports: selectedWebReport ? selectedWebReport : [],
     childform:selectedChildForm&&selectedChildForm[0]?selectedChildForm[0].value:selectedChildForm && selectedChildForm.value?selectedChildForm.value.toString():0,
     targeta:selectedTargetOptions && selectedTargetOptions[0]?selectedTargetOptions[0].value:selectedTargetOptions && selectedTargetOptions.value?selectedTargetOptions.value.toString():0,
     language_data:language_data,
     caption_translation:caption_translation,
     selectedManual:selectedManualList && selectedManualList[0]?selectedManualList[0].value:selectedManualList && selectedManualList.value?selectedManualList.value.toString():0,
     url:url,
     selectlistname:selectedList && selectedList[0]?selectedList[0].value:selectedList && selectedList.value?selectedList.value.toString():0,
     hide:true
   }
   this.props.saveChildForm(data);
 }
  childform=()=>{
      const {name,caption,showName,linktypeOptions,selectedLinkType,manualListOptions,selectedManualList,childFormOptions,selectedChildForm,targetOptions,selectedTargetOptions,url,selectListOptions,selectedList,autoGeneration,saveOrForward,webReportOptions,selectedWebReport,t}=this.state;
      return (<>
        <reactbootstrap.Row className='mt-3'>
          <reactbootstrap.Col className='col-md-4 d-flex'>
              <reactbootstrap.FormLabel className='col-md-3'>{t('Name')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
              <reactbootstrap.FormControl
                    className="col-md-9 input_sw"
                    type='text'
                    name='name'
                    onChange={(e)=>this.textOnchange(e)}
                    value={name}/>
            </reactbootstrap.Col>
              <reactbootstrap.Col className='col-md-4 d-flex'>
                  <reactbootstrap.FormLabel className='col-md-3'>{t('Caption')}</reactbootstrap.FormLabel>
                  <reactbootstrap.FormControl
                        className="col-md-9 input_sw"
                        type='text'
                        name='caption'
                        onChange={(e)=>this.textOnchange(e)}
                        value={caption}/>
                </reactbootstrap.Col>
          <reactbootstrap.Col className='col-md-4' >
          <reactbootstrap.Row>
              <reactbootstrap.Col className='col-md-1'>
                  <CheckBox
                      tick={showName}
                      onCheck={(e)=>this.handleCheckBox(e,'showName')}/>
              </reactbootstrap.Col>
                  <reactbootstrap.FormLabel className='pt-1 ml-4'>{t('Show name')}</reactbootstrap.FormLabel>
          </reactbootstrap.Row>
          </reactbootstrap.Col>
        </reactbootstrap.Row>
      {/**  <reactbootstrap.Row className='mt-3'>
        <reactbootstrap.Col className='col-md-4 d-flex'>
            <reactbootstrap.FormLabel className='col-md-3'>{t('Alias')}</reactbootstrap.FormLabel>
            <reactbootstrap.FormControl
                  className="col-md-9 input_sw"
                  type='text'
                  name='alias'
                  onChange={(e)=>this.textOnchange(e)}
                  value={alias}/>
          </reactbootstrap.Col>
        </reactbootstrap.Row>*/}
      <reactbootstrap.Row className='mt-3'>
      <reactbootstrap.Col className='col-md-4 d-flex'>
          <reactbootstrap.FormLabel className='col-md-3' >{t('Link type')}</reactbootstrap.FormLabel>
          <reactbootstrap.Col className='col-md-9 p-0'>
          <MultiSelect
          options={linktypeOptions}
          standards={selectedLinkType}
          disabled={false}
          handleChange={(e)=>this.handleChangeLinkType(e)}
          isMulti={false}
          name = {'selectedLinkType'}
          />
          </reactbootstrap.Col>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-4 d-flex'>
          <reactbootstrap.FormLabel  className='col-md-3'>{t('Manual List:')}</reactbootstrap.FormLabel>
          <reactbootstrap.Col className='col-md-9 p-0'>
          <MultiSelect
          options={manualListOptions}
          standards={selectedManualList}
          disabled={false}
          handleChange={(e)=>this.handleChangeManualList(e)}
          isMulti={false}
          name = {'selectedManualList'}
          />
          </reactbootstrap.Col>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-4 d-flex'>
          <reactbootstrap.FormLabel  className='col-md-3'>{t('Target:')}</reactbootstrap.FormLabel>
          <reactbootstrap.Col className='col-md-9 p-0'>
          <MultiSelect
          options={targetOptions}
          standards={selectedTargetOptions}
          disabled={false}
          handleChange={(e)=>this.handleChangeTarget(e)}
          isMulti={false}
          name = {'selectedTargetOptions'}
          />
          </reactbootstrap.Col>
      </reactbootstrap.Col>
      </reactbootstrap.Row>
      <reactbootstrap.Row className='mt-3'>
    {selectedLinkType && selectedLinkType.value && selectedLinkType.value==1 && <reactbootstrap.Col className='col-md-4 d-flex'>
          <reactbootstrap.FormLabel  className='col-md-3'>{t('Child form:')}</reactbootstrap.FormLabel>
          <reactbootstrap.Col className='col-md-9 p-0'>
          <MultiSelect
          options={childFormOptions}
          standards={selectedChildForm}
          disabled={false}
          handleChange={(e)=>this.handleChangeChildForm(e)}
          isMulti={false}
          name = {'selectedChildForm'}
          />
          </reactbootstrap.Col>
      </reactbootstrap.Col>}
      {selectedLinkType && selectedLinkType.value && selectedLinkType.value==1 &&  <reactbootstrap.Col className='col-md-4 d-flex'>
          <reactbootstrap.FormLabel  className='col-md-3'>{t('Web report:')}</reactbootstrap.FormLabel>
          <reactbootstrap.Col className='col-md-9 p-0'>
          <MultiSelect
          options={webReportOptions}
          standards={selectedWebReport}
          disabled={false}
          handleChange={(e)=>this.handleChangeWebReport(e)}
          isMulti={false}
          name = {'selectedWebReport'}
          />
          </reactbootstrap.Col>
      </reactbootstrap.Col>}
      {selectedLinkType && selectedLinkType.value && selectedLinkType.value===2 && <reactbootstrap.Col className='col-md-4 d-flex'>
          <reactbootstrap.FormLabel className='col-md-3'>{t('URL')}</reactbootstrap.FormLabel>
          <reactbootstrap.FormControl
                className="col-md-9 input_sw"
                type='text'
                name='url'
                onChange={(e)=>this.textOnchange(e)}
                value={url}
                disabled={selectedTargetOptions.value && selectedTargetOptions.value==2?true:false}/>
        </reactbootstrap.Col>}
        {selectedLinkType && selectedLinkType.value && selectedLinkType.value===2 && <reactbootstrap.Col className='col-md-4 d-flex'>
            <reactbootstrap.FormLabel className='col-md-3'>{t('Select list')}</reactbootstrap.FormLabel>
            <reactbootstrap.Col className='col-md-9 p-0'>
            <MultiSelect
            options={selectListOptions}
            standards={selectedList}
            disabled={false}
            handleChange={(e)=>this.handleChangeList(e)}
            isMulti={false}
            name = {'selectedWebReport'}
            />
            </reactbootstrap.Col>
        </reactbootstrap.Col>}
      </reactbootstrap.Row>
      <reactbootstrap.Row>
      <reactbootstrap.Col className='col-md-1'>
      <CheckBox
          tick={autoGeneration}
          onCheck={(e)=>this.handleCheckBox(e,'autoGeneration')}/>
      </reactbootstrap.Col>
      <reactbootstrap.FormLabel className='pt-1'>{t('Automatic generation')}</reactbootstrap.FormLabel>
      </reactbootstrap.Row>
    {autoGeneration && <reactbootstrap.Row>
      <reactbootstrap.Col className='col-md-1'>
      <CheckBox
          tick={saveOrForward}
          onCheck={(e)=>this.handleCheckBox(e,'saveOrForward')}/>
      </reactbootstrap.Col>
      <reactbootstrap.FormLabel className='pt-1'>{t('Save instead of forward')}</reactbootstrap.FormLabel>
      </reactbootstrap.Row>}
      </>);
  }

  displayTranslationOne=(column_name,column_information) => {
    const {language_list,caption_translation,t}=this.state;
    if(language_list && language_list.length > 0){
            return (<TranslationTab
                language_list={language_list}
                language_data={caption_translation}
                name={column_name}
                information={column_information}
                handleTranslation={this.handleCaptionTranslation.bind(this)}
                name_alternative = {t('Caption')} />);
      }
  }
  displayTranslationTwo=(column_name,column_information) => {
    const {language_list,language_data}=this.state;
    if(language_list && language_list.length > 0){
            return (<TranslationTab
                language_list={language_list}
                language_data={language_data}
                name={column_name}
                information={column_information}
                handleTranslation={this.handleTranslation.bind(this)} />);
      }
  }
render(){
  console.log(this.props);
      const {t}=this.state;
  return(
    <reactbootstrap.Container>
         <reactbootstrap.Tabs activeKey={this.state.tab} onSelect={(key) => this.tabOnChange(key)}>
          <reactbootstrap.Tab eventKey={1} title={t("General")}>
            {this.childform()}
          </reactbootstrap.Tab>
          <reactbootstrap.Tab eventKey={2} title={t("Translation")}>
          <>
          {this.displayTranslationTwo(1,0)}
          {this.displayTranslationOne(1,0)}
          {this.displayTranslationTwo(0,1)}
          </>
          </reactbootstrap.Tab>
         </reactbootstrap.Tabs>
         <reactbootstrap.Row className='mt-3' style={{float:'right'}}>
         <reactbootstrap.Button className='m-2' onClick={this.props.cancelChildForm}>{t('Cancel')}</reactbootstrap.Button>
         <reactbootstrap.Button className='m-2' onClick={(e)=>this.saveChildForm()}>{t('Save')}</reactbootstrap.Button>
         </reactbootstrap.Row>
      </reactbootstrap.Container>
  );
}
}
export default translate(ReleaseChildFormPopUp);
