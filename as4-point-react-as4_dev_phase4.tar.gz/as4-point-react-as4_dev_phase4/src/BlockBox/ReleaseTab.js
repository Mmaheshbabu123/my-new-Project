import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
import CheckBox from '../CheckBox';
import ReleaseChildFormPopUp from './ReleaseChildFormPopUp';
class ReleaseTab extends Component {
  constructor(props) {
     super(props)
     this.state = {
        tasks: [],
        items: [],
        types: [],
        selected: [{ 'approval_cycle': '' }],
        active_tab1: 1,
        credentials :true,
        t:props.t,
        condition: { action: 0, orgunit: 0, workflow: 0, control: 1 },
        arrayChildForm:this.props.details.arrayChildForm,
     }
  }
  childFormPopUp=()=>{
    return(
      <reactbootstrap.Modal
        show={this.props.details.showChildForm}
        onHide={this.props.showCloseChildForm}
        dialogClassName="modal-90w modal-xl"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
        </reactbootstrap.Modal.Header>
        <ReleaseChildFormPopUp
         details={this.props.details.childformData}
         language_list={this.props.details.language_list}
         manualListOptions={this.props.details.manualListOptions}
         showCloseChildForm={this.props.showCloseChildForm}
         saveChildForm={this.props.saveChildForm}
         cancelChildForm={this.props.cancelChildForm}
        />
      </reactbootstrap.Modal>
    )
  }
  render() {
    const { t } = this.state;
    return (
        <reactbootstrap.Container className=" pb-4">
            <reactbootstrap.Form >
              {/**<reactbootstrap.Row className='mt-3'>
                <reactbootstrap.Col className='col-md-3'><reactbootstrap.Form.Label style={{color: '#EC661C'}}>{t('Select webform')}<span style={{ color: 'red' }}>{' *'}</span></reactbootstrap.Form.Label></reactbootstrap.Col>
                <reactbootstrap.Col className='col-md-9'>
                <MultiSelect
                options={this.props.details.releaseWebforms}
                standards={this.props.details.selectedReleaseWebform}
                disabled={false}
                handleChange={this.props.handleChangeReleaseWebform}
                isMulti={false}
                name='selectedReleaseWebform'
                />
                </reactbootstrap.Col>
              </reactbootstrap.Row>*/}
              <reactbootstrap.Row className='mt-2'>
                  <>
                      <CheckBox
                          key='stopWebform'
                          tick={this.props.details.stopWebform}
                          name='stopWebform'
                          onCheck={(e)=>this.props.handleCheckBox(e,'stopWebform')}
                          name={t("Stop webform")}/>
                  </>
                </reactbootstrap.Row>
                <reactbootstrap.Row className='mt-2 '>
                        <CheckBox
                            key='allowChildForm'
                            tick={this.props.details.allowChildForm}
                            onCheck={(e)=>this.props.handleCheckBox(e,'allowChildForm')}
                            name={t("Action child form needs to be linked before release")}/>
                  </reactbootstrap.Row>
                  <reactbootstrap.Row className='justify-content-center'>
                  <reactbootstrap.Col className='col-md-10' style={{maxHeight:'320px',overflow:'auto'}}>
                  <reactbootstrap.Table striped bordered hover variant="" >
                  <thead style={{ position: 'sticky', top: '0', textAlign: 'center' }}>
                    <tr style={{ textAlign: 'center' }}>
                      <th>{t('Childform')}</th>
                      <th><i title={t("Add childform")} style={{ 'cursor': 'pointer',float:'right' }} className="webform-sprite webform-sprite-createlistc"  onClick={this.props.addChildForm}/></th>
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                    <td colspan='2'><input type="text" className="form-control search-box-border "  placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }}  onChange={this.props.searchData}/></td>
                    </tr>
                    {this.props.details.copyArrayChildForm && this.props.details.copyArrayChildForm.map(value=>{
                      return <tr>
                              <td>{value.name}</td>
                              <td>
                              <div style={{ display: 'flex', textAlign: 'center' }} >
                                <i title={t("Edit")} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc" onClick={(e) => this.props.editChildForm(value)} />
                                <span style={{ paddingLeft: '10px', paddingRight: '10px' }}><i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec" onClick={(e) => this.props.deleteChildForm(value)}></i></span>
                              </div>
                              </td>
                              </tr>
                       })}
                    </tbody>
                  </reactbootstrap.Table>
                  </reactbootstrap.Col>
                  </reactbootstrap.Row >
                {/*  <reactbootstrap.Row className='mt-2 '>
                      <>
                          <CheckBox
                              key='stopWebform'
                              tick={this.props.details.resolve}
                              name='resolve'
                              onCheck={(e)=>this.props.handleCheckBox(e,'resolve')}
                              name={t('Show "Not possible to resolve"')}/>
                      </>
                    </reactbootstrap.Row>*/}
                  {/*this.props.details.resolve && <reactbootstrap.Row className="mt-2 pl-3 d-flex">
                  <reactbootstrap.Form.Label>{t("Only show after")}</reactbootstrap.Form.Label>
                        <reactbootstrap.FormControl
                          name="number_of_blockboxes"
                          placeholder={t("Number")}
                          aria-label="number"
                          aria-describedby="basic-addon1"
                          value={this.props.details.number_of_blockboxes}
                          style={{width:'60px',height:'20px',marginLeft: "4px",marginRight: "4px",padding: "0px",textAlign:'center'}}
                          onChange={this.props.handleReleasePeriodNumber}
                          className="input_sw"
                          //disabled={details.auto_increment_lessthan===false?true:false}
                          />
                      <reactbootstrap.Form.Label>{t("Blockboxes")}</reactbootstrap.Form.Label>
                   </reactbootstrap.Row>*/}
                   {/*this.props.details.resolve && <reactbootstrap.Row className="mt-3">
                      <reactbootstrap.Col className='col-md-4'><reactbootstrap.Form.Label style={{color: '#EC661C'}}>{t('Resolving period:')}</reactbootstrap.Form.Label></reactbootstrap.Col>
                      <reactbootstrap.Col className='col-md-3'>
                      <reactbootstrap.FormControl
                        type='text'
                        name =  "releasePeriodNumber"
                        value={this.props.details.releasePeriodNumber}
                        onChange={this.props.handleReleasePeriodNumber}
                        className="input_sw"
                        placeholder={t('Number')}/>
                        </reactbootstrap.Col>
                        <reactbootstrap.Col className='col-md-4 px-0'>
                        <MultiSelect
                        options={this.props.details.releasePeriodTypeOptions}
                        standards={this.props.details.releasePeriodTypeSelectedOptions}
                        disabled={false}
                        handleChange={this.props.handleChangeReleasPeriodType}
                        name='releasePeriodTypeSelectedOptions'
                        isMulti={false}
                        placeholder={t('select')}/>
                        </reactbootstrap.Col>
                        </reactbootstrap.Row>*/}
                        {/*this.props.details.resolve && <reactbootstrap.Row className='mt-2'>
                          <reactbootstrap.Col className='col-md-4'>
                          <reactbootstrap.Form.Label style={{color: '#EC661C'}}>
                          {t('Select step:')}<span style={{ color: "red" ,backgroundColor: 'none', border: '0px'}}>*</span>
                          </reactbootstrap.Form.Label>
                          </reactbootstrap.Col>
                          <reactbootstrap.Col className='col-md-7 px-0 pl-3'>
                                    <reactbootstrap.FormControl as="select" name="manual_id"
                                              value={this.props.details.step_id}
                                              name = {'step_id'}
                                              // disabled={details.disableFields || details.exp_his_disabled}
                                              onChange={this.props.handleChange}
                                              className="input_sw"
                                          >   <option value={0}>{t('---Select---')}</option>
                                          { (this.props.details.workflowsteps !== undefined && this.props.details.workflowsteps.length > 0) ? this.props.details.workflowsteps.map(org => <option value={org.id}>{org.step_name}</option>):[]}
                                          </reactbootstrap.FormControl>
                            </reactbootstrap.Col>
                          </reactbootstrap.Row>*/}
                        {this.childFormPopUp()}
            </reactbootstrap.Form>
        </reactbootstrap.Container>
    );
  }
}
export default translate(ReleaseTab);
