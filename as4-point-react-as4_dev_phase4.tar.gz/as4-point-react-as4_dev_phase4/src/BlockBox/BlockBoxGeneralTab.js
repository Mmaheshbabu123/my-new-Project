import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
class BlockBoxGeneralTab extends Component {
  constructor(props) {
     super(props)
     this.state = {
        tasks: [],
        items: [],
        types: [],
        selected: [{ 'approval_cycle': '' }],
        active_tab1: 1,
        credentials :true,
        t:props.t,
        condition: { action: 0, orgunit: 0, workflow: 0, control: 1 },
     }
  }
  render() {
    const {t}=this.state;
    let string = parseInt(this.props.details.release_actor_type) === window.PERSON_ENTITY ? 'person' : parseInt(this.props.details.release_actor_type) === 2 ? 'jobs' : parseInt(this.props.details.release_actor_type) === 3 ? 'departments' : 'groups';
          let obj = this.props.details.allOrgUnits[string] === undefined ? [] :parseInt(this.props.details.release_actor_type) === window.PERSON_ENTITY && this.props.details.inOutPersons===2?this.props.details.blockBoxpersons:this.props.details.allOrgUnits[string];
    return (
        <reactbootstrap.Container className=" pb-4">
            <reactbootstrap.Form >
            <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                    <reactbootstrap.InputGroup className="  ">
                        <div className="col-md-4">
                            <reactbootstrap.InputGroup.Prepend>
                                <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Name')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                            </reactbootstrap.InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <reactbootstrap.FormControl
                                name="name"
                                placeholder={("Name")}
                                aria-label="title"
                                aria-describedby="basic-addon1"
                                value={this.props.details.name}
                                onChange={this.props.handleChange}
                                className="input_sw"
                            />
                        </div>
                        <span style={{ color: 'red' }}>{this.props.details.errors}</span>
                    </reactbootstrap.InputGroup>
                </div>
            </reactbootstrap.FormGroup>
            <reactbootstrap.FormGroup>
              <div className=" row input-overall-sec ">
                  <reactbootstrap.InputGroup className="">
                      <div className="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                              <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Release actor:')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                      </div>
                      <div class="col-md-8 input-padd">
                    <reactbootstrap.Form.Control
                    name="release_actor_type"
                    as="select"
                    value={this.props.details.release_actor_type}
                    onChange={this.props.handleChange} >
                        <option value={window.PERSON_ENTITY}>{t('Person')}</option>
                        <option value={window.JOB_ENTITY}>{t('Job')}</option>
                        <option value={window.DEPARTMENT_ENTITY}>{t('Department')}</option>
                        <option value={window.GROUP_ENTITY}>{t('Group')}</option>
                    </reactbootstrap.Form.Control>
                    </div>
                      <span style={{ color: 'red' }}>{this.props.details.errorSelectWebform}</span>
                  </reactbootstrap.InputGroup>
              </div>
          </reactbootstrap.FormGroup>
          {parseInt(this.props.details.release_actor_type)===parseInt(window.PERSON_ENTITY) &&
            <reactbootstrap.Row className='pl-4' style={{flexDirection: 'column'}}>
            <div><input  type="radio" value={1} checked={this.props.details.inOutPersons === 1} name={"inOutPersons"} className='pr-2' onChange={this.props.handleSelectRadio}/>{t('Inside organisation persons')}</div>
            <div><input  type="radio" value={2} checked={this.props.details.inOutPersons === 2} name={"inOutPersons"} onChange={this.props.handleSelectRadio}/>{t('Outside organisation persons')}</div>
            </reactbootstrap.Row>}
          <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                    <reactbootstrap.InputGroup className="">
                        <div className="col-md-4">
                            <reactbootstrap.InputGroup.Prepend>
                                <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C'}} id="basic-addon1">{t('Organisation unit:')}<span style={{ color: "red" ,backgroundColor: 'none', border: '0px'}}>*</span></reactbootstrap.InputGroup>
                            </reactbootstrap.InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                            <reactbootstrap.FormControl as="select" name="manual_id"
                                value={this.props.details.release_actor_type_id}
                                name = {'release_actor_type_id'}
                                // disabled={details.disableFields || details.exp_his_disabled}
                                onChange={this.props.handleChange}
                                className="input_sw"
                            >   <option value={0}>{'---Select---'}</option>
                            { (obj !== undefined && obj.length > 0) ? obj.map(org => <option value={org.id}>{org.name}</option>):[]}
                            </reactbootstrap.FormControl>
                        </div>
                    </reactbootstrap.InputGroup>

                </div>
            </reactbootstrap.FormGroup>
          {(this.props.details.release_actor_type <= 4 && this.props.details.release_actor_type >= 2) && <div style = {{display: 'inline-flex'}} className="col-md-8 ">
          <div className="col-md-6">
              <reactbootstrap.InputGroup.Prepend>
                  <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C', backgroundColor: 'none', border: '0px' }} id="basic-addon1">{t('Amount:')}</reactbootstrap.InputGroup>
              </reactbootstrap.InputGroup.Prepend>
          </div>
                   <reactbootstrap.Form.Control
                       type="number"
                       value={this.props.details.amount}
                       onChange={this.props.handleChange}
                       name='amount'
                      disabled={this.props.details.amount_all == 1 ? true : false}
                   />
                   <div className="col-md-2">
                       <reactbootstrap.InputGroup.Prepend>
                           <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C', backgroundColor: 'none', border: '0px' }} id="basic-addon1">{t('All:')}</reactbootstrap.InputGroup>
                       </reactbootstrap.InputGroup.Prepend>
                   </div>
                     <reactbootstrap.Form.Check
                       name={'amount_all'}
                       checked = {this.props.details.amount_all}
                       //tick={amountAllValue == 1 ? true : false}
                       style={{ paddingLeft: '35px' }}
                       onChange={this.props.handleSelect}
                   />
           </div>}
           <reactbootstrap.FormGroup>
             <div className=" row input-overall-sec ">
                 <reactbootstrap.InputGroup className="">
                     <div className="col-md-4">
                         <reactbootstrap.InputGroup.Prepend>
                             <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Release Method:')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                         </reactbootstrap.InputGroup.Prepend>
                     </div>
                     <div class="col-md-8 input-padd">
                   <reactbootstrap.Form.Control
                   name="release_method_id"
                   as="select"
                   value={this.props.details.release_method_id}
                   onChange={this.props.handleChange} >
                       <option value={window.PERSON_ENTITY}>{t('Pass code from distance')}</option>
                       <option value={window.JOB_ENTITY}>{t('Pass code at blockbox')}</option>
                       <option value={window.DEPARTMENT_ENTITY}>{t('Scanner from distance')}</option>
                       <option value={window.GROUP_ENTITY}>{t('Scanner from blockbox')}</option>
                   </reactbootstrap.Form.Control>
                   </div>
                     <span style={{ color: 'red' }}>{this.props.details.errorSelectWebform}</span>
                 </reactbootstrap.InputGroup>
             </div>
         </reactbootstrap.FormGroup>
         {/*<reactbootstrap.FormGroup>
               <div className=" row input-overall-sec ">
                   <reactbootstrap.InputGroup className="">
                       <div className="col-md-4">
                           <reactbootstrap.InputGroup.Prepend>
                               <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C'}} id="basic-addon1">{t('Select step:')}<span style={{ color: "red" ,backgroundColor: 'none', border: '0px'}}>*</span></reactbootstrap.InputGroup>
                           </reactbootstrap.InputGroup.Prepend>
                       </div>
                       <div class="col-md-8 input-padd">
                           <reactbootstrap.FormControl as="select" name="manual_id"
                               value={this.props.details.step_id}
                               name = {'step_id'}
                               // disabled={details.disableFields || details.exp_his_disabled}
                               onChange={this.props.handleChange}
                               className="input_sw"
                           >   <option value={0}>{'---Select---'}</option>
                           { (this.props.details.workflowsteps !== undefined && this.props.details.workflowsteps.length > 0) ? this.props.details.workflowsteps.map(org => <option value={org.id}>{org.step_name}</option>):[]}
                           </reactbootstrap.FormControl>
                       </div>
                   </reactbootstrap.InputGroup>

               </div>
           </reactbootstrap.FormGroup>*/}
              {/*   <reactbootstrap.FormGroup className="mt-3">
                     <reactbootstrap.Form.Check
                         onChange={this.props.handleSelect}
                         name='from_distance'
                         checked={this.props.details.from_distance}
                         disabled={false}
                         label={t("Can be resolved from a distance")}
                     />
                 </reactbootstrap.FormGroup> */}

            </reactbootstrap.Form>
        </reactbootstrap.Container>
    );
  }
}
export default translate(BlockBoxGeneralTab);
