import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { throwStatement } from '@babel/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';


class DocumentListView extends Component {
    constructor(props) {
        super(props);

        this.state = {
            columnDefs: [],
            rowData: [],
            status: false,
            defaultColDef: {},
        }
    }
    defaultText() {
        if ((this.state.columnDefs === undefined || this.state.rowData === undefined) && this.state.status === true) {
            return { noRowsToShow: 'No Data To Show' };

        } else {
            return { noRowsToShow: '<span class="ag-overlay-loading-center">loading....</span>' };
        }
    }
    onGridReady = params => {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    onBtShowLoading() {
        this.gridApi.showLoadingOverlay();
    }
    render() {




        return (

            <div>

                <div className='container py-4' >
                    <div className='row justify-content-center' >
                        <div className='col-md-12' >
                            <div className='card' >

                                <span id="selectedRows" />
                                <div
                                    className="ag-theme-balham"
                                    style={{
                                        height: '500px',
                                        width: '1000px',
                                    }}
                                >
                                    <button onClick={this.onBtShowLoading.bind(this)}>Show Loading Overlay</button>
                                    <AgGridReact
                                        rowSelection="multiple"
                                        onGridReady={this.onGridReady}

                                        columnDefs={this.state.columnDefs}
                                        rowData={this.state.rowData}
                                        defaultColDef={this.state.defaultColDef}
                                        floatingFilter={true}
                                        onSelectionChanged={this.onSelectionChanged.bind(this)}
                                        localeText={this.defaultText()}

                                    >


                                    </AgGridReact>
                                </div>
                            </div>
                        </div></div></div></div >

        );

    }
    onSelectionChanged() {
        var selectedRows = this.gridApi.getSelectedRows();
        var selectedRowsString = "";
        selectedRows.forEach(function (selectedRow, index) {
            if (index !== 0) {
                selectedRowsString += ", ";
            }
            selectedRowsString += selectedRow.id;
        });
        document.querySelector("#selectedRows").innerHTML = selectedRowsString;
    }
    componentDidMount() {
      let data = {
        grid_type : 4,
        grid_items_id : 53,
        tile_id : 3,
        p_id : 152
      }
        datasave.service(window.TILE_DETAILS, 'POST', data).then(result => {
            this.setState({
                status: true,
                columnDefs: result.columnDefs,
                rowData: result.rowData,
                defaultColDef: result.defaultColDef,

            })
        });
    }



}

export default DocumentListView;
