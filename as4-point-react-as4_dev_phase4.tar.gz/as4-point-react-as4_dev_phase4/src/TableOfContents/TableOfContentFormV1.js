import React, { Component } from 'react';
import { datasave } from '../_services/db_services';
import * as reactbootstrap from 'react-bootstrap';
import MultiSelect from '../_components/MultiSelect';
import { translate } from '../language';
import CheckBox from '../CheckBox.js';
import { OCAlert } from '@opuscapita/react-alerts';
import { Button, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import './TableContent.css';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';

class TableContentFormV1 extends Component {
    constructor(props) {
        super(props)
        this.state = {
            manualCheck: false,
            folderCheck: false,
            documentCheck: false,
            standardsCheck: false,
            spacesCheck: false,
            tagsCheck: false,
            ownerCheck: false,
            docTypeCheck: false,
            layoutsCheck: false,
            bundlesCheck: false,
            document_choice: 2,
            manualOptions: [],
            folderOptions: [],
            documentOptions: [],
            standardsOptions: [],
            spacesOptions: [],
            tagsOptions: [],
            ownersOptions: [],
            docTypesOptions: [],
            layoutsOptions: [],
            bundlesOptions: [],
            selectedManual: [],
            selectedFolder: [],
            selectedDocument: [],
            selectedStandards: [],
            selectedSpaces: [],
            selectedTags: [],
            selectedOwners: [],
            selectedDocTypes: [],
            selectedLayouts: [],
            selectedBundles: [],
            tocName: '',
            entityData: [],
            id: this.props.id == undefined ? 0 : this.props.id,
            t:props.t

        }
        this.handleSave = this.handleSave.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    handleChangeMultiSelect(e, name, entity_type_id) {
        if (entity_type_id != 1 && entity_type_id != 2) {
            this.handleEntityData(e, name, entity_type_id);
        } else {
            this.handleManFoldEntityData(e, name, entity_type_id);
        }
    }


    async handleManFoldEntityData(e, name, entity_type_id) {
        var entityData = this.state.entityData;
        let {selectedManual, folderCheck, selectedFolder, documentCheck, selectedDocument, document_choice} = this.state;
        let setStateObj = {[name]: e};
        var result = [];
        if (entityData.length > 0) {
            if (entity_type_id == 1) {
                if(e.length > 0){
                  let folderOptions = folderCheck ? await this.handleService_v2(window.GET_TOC_ENTITYOPTIONS, 'POST', {data: e, entity_type_id: 2, document_choice: document_choice}) : [];
                  result = e.concat(this.removeEntityFromData([entity_type_id], entityData));
                  setStateObj['folderOptions'] = folderOptions['data'] != undefined ?await this.filterParentfolder(Object.values(folderOptions['data']),e): [];
                  setStateObj['entityData'] =  result;
                  if(e.length < selectedManual.length && folderCheck && selectedFolder.length != 0){
                    selectedFolder = this.commonManFoldDocFunction(folderOptions, selectedFolder);
                    // folderOptionIds = folderOptions['data'] !== undefined ? folderOptions['data'].map(key=>{ return key['value']}) : [];
                    // selectedFolder = selectedFolder.filter(key=>{ return folderOptionIds.indexOf(key['value']) !== -1});
                    let documentOptions = documentCheck && selectedFolder.length > 0? await this.handleService_v2(window.GET_TOC_ENTITYOPTIONS, 'POST', {data: selectedFolder, entity_type_id: 3, document_choice: document_choice}) : [];
                    setStateObj['selectedFolder'] = selectedFolder;
                    setStateObj['documentOptions'] = documentOptions['data'];
                    if(documentCheck && selectedDocument.length !== 0){
                      // docOptionIds = documentOptions['data'] !== undefined ? documentOptions['data'].map(key=>{ return key['value']}) : [];
                      // selectedDocument = selectedDocument.filter(key=>{ return docOptionIds.indexOf(key['value']) !== -1});
                      selectedDocument = this.commonManFoldDocFunction(documentOptions, selectedDocument);
                      setStateObj['selectedDocument'] = selectedDocument;
                      setStateObj['documentCheck'] = selectedDocument.length > 0 ? true : false;
                      this.handleSetState(setStateObj);
                    }else{
                    this.handleSetState(setStateObj);
                    }
                  }else {
                    this.handleSetState(setStateObj);
                  }
                }else{
                  result = this.removeEntityFromData([1, 2, 3], entityData)
                  setStateObj['selectedManual'] = [];
                  setStateObj['folderCheck'] = false;
                  setStateObj['selectedFolder'] = [];
                  setStateObj['folderOptions'] = [];
                  setStateObj['documentCheck'] = false;
                  setStateObj['selectedDocument'] = [];
                  setStateObj['documentOptions'] = [];
                  setStateObj['entityData'] =  result;
                  this.handleSetState(setStateObj);
                }
            } else {
                result = e.concat(this.removeEntityFromData([entity_type_id], entityData));
                let documentOptions = documentCheck && e.length > 0? await this.handleService_v2(window.GET_TOC_ENTITYOPTIONS, 'POST', {data: e, entity_type_id: 3, document_choice: document_choice}) : [];
                setStateObj['entityData'] =  result;
                setStateObj['documentOptions'] = documentOptions['data'];
                if(e.length > 0){
                  if(e.length < selectedFolder.length && documentCheck && selectedDocument.length !== 0){
                      selectedDocument = this.commonManFoldDocFunction(documentOptions, selectedDocument);
                      // docOptionIds = documentOptions['data'] !== undefined ? documentOptions['data'].map(key=>{ return key['value']}) : [];
                      // selectedDocument = selectedDocument.filter(key=>{ return docOptionIds.indexOf(key['value']) !== -1});
                      setStateObj['selectedDocument'] = selectedDocument;
                      setStateObj['documentCheck'] = selectedDocument.length > 0 ? true : false;
                      this.handleSetState(setStateObj);
                  }else{
                    this.handleSetState(setStateObj);
                  }
                }else{
                  setStateObj['documentCheck'] = false;
                  setStateObj['selectedDocument'] = [];
                  this.handleSetState(setStateObj);
                }
            }
        } else {
            this.handleSetState({[name] : e, 'entityData' : e});
        }
    }

    filterParentfolder=(result,selected)=>{
      let ids = selected.map(value=>{return value['value']});
      return result.filter(value=>{return !ids.includes(value['value'])});
    }
    commonManFoldDocFunction(options, selected){
      if(selected.length > 0){
        let optionIds = options['data'] !== undefined ? options['data'].map(key=>{ return key['value']}) : [];
        return selected.filter(key=>{ return optionIds.indexOf(key['value']) !== -1});
      }else{
        return [];
      }
    }

    handleEntityData(e, name, entity_type_id) {
        var entityData = this.state.entityData;
        if (entityData.length > 0) {
            var resData = e.concat(this.removeEntityFromData([entity_type_id], entityData));
            this.handleSetState({[name] : e, 'entityData' : resData});
        } else {
            this.handleSetState({[name] : e, 'entityData' : e});
        }
    }


    removeEntityFromData(entity_type_ids, entityData) {
        var temp = [];
        entityData.map(key => {
            if (entity_type_ids.indexOf(key['entity_type_id']) === -1) {
                temp.push(key);
            }
        })
        return temp;

    }

    handleSetState(setStateObj) {
        this.setState(setStateObj);
    }

    handleCheckBox(checked, name, entity_type_id, optionsName, selectionName) {

        if (name == 'manualCheck') {
            this.handleManual(checked, name, entity_type_id);
        }
        if (name == 'folderCheck') {
            this.handleFolder(checked, name, entity_type_id);
        }
        if (name == 'documentCheck') {
            this.handleDocument(checked, name, entity_type_id);
        }
        if (name != 'manualCheck' && name != 'folderCheck' && name != 'documentCheck') {
            this.handleOtherSelections(checked, name, entity_type_id, optionsName, selectionName);
        }
    }

    handleOtherSelections(checked, name, entity_type_id, optionsName, selectionName) {

        if (checked) {
            var data = {
                data: [],
                entity_type_id: entity_type_id,
                document_choice: this.state.document_choice
            }
            this.handleService(window.GET_TOC_ENTITYOPTIONS, 'POST', data, optionsName, name, checked);
        } else {
            this.setState({
                [optionsName]: [],
                [selectionName]: [],
                [name]: checked,
                entityData: this.removeEntityFromData([entity_type_id], this.state.entityData)
            })

        }
    }
    handleManual(checked, name, entity_type_id) {
        if (checked) {
            var data = {
                data: [],
                entity_type_id: entity_type_id,
                document_choice: this.state.document_choice
            }
            this.handleService(window.GET_TOC_ENTITYOPTIONS, 'POST', data, 'manualOptions', name, checked);
        } else {
            var resManRmv = this.removeEntityFromData([entity_type_id], this.state.entityData);
            var resFoldRmv = this.removeEntityFromData([2], resManRmv);
            var result = this.removeEntityFromData([3], resFoldRmv);
            this.setState({
                manualCheck: false,
                folderCheck: false,
                documentCheck: false,
                manualOptions: [],
                folderOptions: [],
                documentOptions: [],
                selectedManual: [],
                selectedFolder: [],
                selectedDocument: [],
                entityData: result
            })

        }

    }
    handleFolder(checked, name, entity_type_id) {
const {t}=this.state;
        if (checked) {
            if (this.state.manualCheck && this.state.selectedManual.length > 0) {
                var data = {
                    data: this.state.selectedManual,
                    entity_type_id: entity_type_id,
                    document_choice: this.state.document_choice
                }
                this.handleService(window.GET_TOC_ENTITYOPTIONS, 'POST', data, 'folderOptions', name, checked)
            } else {
                alert(t('please select manuals'));
            }
        } else {
            var resFoldRmv = this.removeEntityFromData([entity_type_id], this.state.entityData);
            var result = this.removeEntityFromData([3], resFoldRmv);
            this.setState({

                folderCheck: false,
                documentCheck: false,
                // manualOptions: [],
                folderOptions: [],
                documentOptions: [],
                selectedFolder: [],
                selectedDocument: [],
                entityData: result,
            })
        }
    }

    handleDocument(checked, name, entity_type_id) {
const {t}=this.state;
        if (checked) {
            if (this.state.manualCheck && this.state.selectedManual.length > 0 &&
                this.state.folderCheck && this.state.selectedFolder.length > 0) {
                var data = {
                    data: this.state.selectedFolder,
                    entity_type_id: entity_type_id,
                    document_choice: this.state.document_choice
                }
                this.handleService(window.GET_TOC_ENTITYOPTIONS, 'POST', data, 'documentOptions', name, checked);
            } else {
                alert(t('Please select respective manuals/folders'));
            }
        } else {
            this.setState({
                documentCheck: false,
                selectedDocument: [],
                documentOptions: [],
                entityData: this.removeEntityFromData([entity_type_id], this.state.entityData)
            })
        }
    }


    async handleService(url, type, data, key, key1, value1) {
        datasave.service(url, type, data)
            .then(async result => {
                if (result != '') {
                    this.setState({
                        // [key]: key==='folderOptions'?this.sort(result['data']):result['data'],
                        [key]: key ==='folderOptions'?await this.filterParentfolder(Object.values(result['data']),data['data']): result['data'],
                        [key1]: value1
                    })
                }
            });
    }
    // sort(data){
    //   return Object.values(data).sort((a,b)=>a.value - b.value);
    // }

  async  handleService_v2(url, type, data){
      let resultData = '';
      await datasave.service(url, type, data)
          .then(async result => {
            resultData = result;
          });
      return resultData;
    }

    handleText(e, name) {
        this.setState({
            [name]: e.target.value
        })
    }
    async handleOptionChange(event) {
      let setStateObj = {[event.target.name]: parseInt(event.target.id)};
      let {selectedFolder, documentCheck, selectedDocument} = this.state;
        if(documentCheck){
          let documentOptions = await this.handleService_v2(window.GET_TOC_ENTITYOPTIONS, 'POST', {data: selectedFolder, entity_type_id: 3, document_choice: event.target.id});
          setStateObj['documentOptions'] = documentOptions['data'];
          if(selectedDocument.length > 0){
            setStateObj['selectedDocument'] = this.commonManFoldDocFunction(documentOptions, selectedDocument);
            this.handleSetState(setStateObj);
          }else{
            this.handleSetState(setStateObj);
          }
        }else{
            this.handleSetState(setStateObj);
        }
    }

    handleSave() {
      const {t}=this.state;
        const { history } = this.props
        if (this.state.selectedManual.length > 0 && this.state.tocName.length > 0) {
            let data = {
                name: this.state.tocName,
                entityData: this.state.entityData,
                documentChoice: this.state.document_choice
            }
            datasave.service(window.INSERT_TOC_DETAILS, 'POST', data)
                .then(result => {
                    if (result['status'] == 200) {
                        OCAlert.alertSuccess(t('Save successfull!'), { timeOut: window.TIMEOUTNOTIFICATION });
                        history.push('/appsettings/managetoc');
                        window.location.reload();
                    } else if (result['status'] == 400) {
                        OCAlert.alertError(t('Name already exist'), { timeOut: window.TIMEOUTNOTIFICATION });
                    } else {
                        alert(t('Error please try again'));
                    }
                })
        } else {
            var alertMsg = (this.state.selectedManual.length <= 0 && this.state.tocName.length <= 0 ? 'Name and Manual are mandatory' : (this.state.selectedManual.length <= 0 ? 'Manual is mandatory' : 'Name field is mandatory'))
            alert(t(alertMsg));
        }

    }

    handleUpdate() {
      const {t}=this.state;
        const { history } = this.props
        if (this.state.selectedManual.length > 0 && this.state.tocName.length > 0) {
            let data = {
                id: this.state.id,
                name: this.state.tocName,
                entityData: this.state.entityData,
                documentChoice: this.state.document_choice
            }

            datasave.service(window.UPDATE_TOC_DETAILS, 'POST', data)
                .then(result => {
                    if (result['status'] == 200) {
                        OCAlert.alertSuccess(t('Updated successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });

                        // alert("Saved successfully");
                        history.push('/appsettings/managetoc');
                    } else if (result['status'] == 400) {
                        OCAlert.alertError(t('Name already exist'), { timeOut: window.TIMEOUTNOTIFICATION });
                    } else {
                        alert(t('Error please try again'));
                    }
                })

        } else {
            var alertMsg = (this.state.selectedManual.length <= 0 && this.state.tocName.length <= 0 ? 'Name and Manual are mandatory' : (this.state.selectedManual.length <= 0 ? 'Manual is mandatory' : 'Name field is mandatory'))
            alert(t(alertMsg));
        }
    }
    displayButton() {
        var table = [];
        const {t}=this.state;
        if (this.state.id != 0) {
            table.push(
                <reactbootstrap.Button onClick={this.handleUpdate}>{t("Save changes")}</reactbootstrap.Button>
            )
        } else {
            table.push(
                <reactbootstrap.Button onClick={this.handleSave}>{t("Save")}</reactbootstrap.Button>
            )
        }

        return table;
    }



    render() {
      const {t}=this.state;
        return (
           CanPermissions('E_TOC', '')?
          <div className="row col-md-12 mb-5">
                {/* <div className="row">
                    <div style={{ visibility: 'hidden',  }} className="col-md-1">
                        <p>welcome</p>
                    </div>*/}
                    <div style={{ }} className='col-md-12 pl-0' >
                    <div style={{ border: '1px solid lightgray', borderRadius: '5px' ,float: 'left'}} className="col-md-12 mt-5  pb-3 p-0 mb-5">
                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'flex' }} className="col-md-12">
                                <div style={{ alignSelf: 'center' }} className="col-md-4 p-0">
                                    <span style={{ color: '#EC661C' }}>
                                        {t('Table of content Name:')}
                                    </span>
                                </div>
                                <div class="col-md-8 input-padd">
                                    <input style={{borderStyle: 'unset'}} className="input_sw active-color col-md-12 p-2" type="text" onChange={(e) => this.handleText(e, 'tocName')} value={this.state.tocName} ></input>
                                </div>
                            </label>
                        </div>
                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'inline-flex', width: '40px' }} className="col-md-5 p-0">

                                <CheckBox
                                    // value={this.state.selectedFundamental}
                                    tick={this.state.manualCheck}
                                    style={{ paddingLeft: '0px' }}
                                    onCheck={(e) => this.handleCheckBox(e.target.checked, 'manualCheck', 1, 'manualOptions', 'selectedManual')}


                                />

                            </label>
                            <span style={{ alignSelf: 'center' }}>
                                    {t('Manuals')}
                                </span>
                            <div className="input_sw ml-3 mr-3">
                                <MultiSelect
                                   className="sasdf"
                                    // className="input_sw"
                                    options={this.state.manualOptions}
                                    // disabled={[{ label: 'jagadish', value: '1' }]}
                                    standards={this.state.selectedManual}
                                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedManual", 1)}
                                />
                            </div>
                        </div>

                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'inline-flex', width: '40px' }} className="col-md-5 p-0">
                                <CheckBox
                                    // value={this.state.selectedFundamental}
                                    tick={this.state.folderCheck}
                                    style={{ paddingLeft: '0px' }}
                                    onCheck={(e) => this.handleCheckBox(e.target.checked, 'folderCheck', 2, 'folderOptions', 'selectedFolder')}


                                />
                                <span style={{ alignSelf: 'center' }}>
                                {t('Folders')}
                                </span>
                            </label>
                            <div className="input_sw ml-3 mr-3">
                                <MultiSelect
                                    options={this.state.folderOptions}
                                    // disabled={[{ label: 'jagadish', value: '1' }]}
                                    standards={this.state.selectedFolder}
                                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedFolder", 2)}
                                />
                            </div>
                        </div>
                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'inline-flex', width: '40px' }} className="col-md-5 p-0">
                                <CheckBox
                                    // value={this.state.selectedFundamental}
                                    tick={this.state.documentCheck}
                                    style={{ paddingLeft: '0px' }}
                                    onCheck={(e) => this.handleCheckBox(e.target.checked, 'documentCheck', 3, 'documentOptions', 'selectedDocument')}


                                />
                          </label>
                          <span style={{ alignSelf: 'center' }}>
                                {t('Documents')}
                                </span>
                            <div className="input_sw ml-3 mr-3">
                                <MultiSelect
                                    options={this.state.documentOptions}
                                    // disabled={[{ label: 'jagadish', value: '1' }]}
                                    standards={this.state.selectedDocument}
                                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedDocument", 3)}
                                />
                            </div>
                        </div>
                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'inline-flex', width: '40px' }} className="col-md-5 p-0">
                                <CheckBox
                                    // value={this.state.selectedFundamental}
                                    tick={this.state.standardsCheck}
                                    style={{ paddingLeft: '0px' }}
                                    onCheck={(e) => this.handleCheckBox(e.target.checked, 'standardsCheck', 4, 'standardsOptions', 'selectedStandards')}

                                />

                            </label>
                            <span style={{ alignSelf: 'center' }}>
                                {t('Standards')}
                                </span>
                            <div className="input_sw ml-3 mr-3">
                                <MultiSelect
                                    options={this.state.standardsOptions}
                                    // disabled={[{ label: 'jagadish', value: '1' }]}
                                    standards={this.state.selectedStandards}
                                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedStandards", 4)}
                                />
                            </div>
                        </div>
                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'inline-flex', width: '40px' }} className="col-md-5 p-0">
                                <CheckBox
                                    // value={this.state.selectedFundamental}
                                    tick={this.state.spacesCheck}
                                    style={{ paddingLeft: '0px' }}
                                    onCheck={(e) => this.handleCheckBox(e.target.checked, 'spacesCheck', 5, 'spacesOptions', 'selectedSpaces')}
                                />

                            </label>
                            <span style={{ alignSelf: 'center' }}>
                                {t('Spaces')}
                                </span>
                            <div className="input_sw ml-3 mr-3">
                                <MultiSelect
                                    options={this.state.spacesOptions}
                                    // disabled={[{ label: 'jagadish', value: '1' }]}
                                    standards={this.state.selectedSpaces}
                                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedSpaces", 5)}
                                />
                            </div>
                        </div>
                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'inline-flex', width: '40px' }} className="col-md-5 p-0">
                                <CheckBox
                                    // value={this.state.selectedFundamental}
                                    tick={this.state.tagsCheck}
                                    style={{ paddingLeft: '0px' }}
                                    onCheck={(e) => this.handleCheckBox(e.target.checked, 'tagsCheck', 6, 'tagsOptions', 'selectedTags')}


                                />

                            </label>
                            <span style={{ alignSelf: 'center' }}>
                                {t('Tags')}
                                </span>
                            <div className="input_sw ml-3 mr-3">
                                <MultiSelect
                                    options={this.state.tagsOptions}
                                    // disabled={[{ label: 'jagadish', value: '1' }]}
                                    standards={this.state.selectedTags}
                                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedTags", 6)}
                                />
                            </div>
                        </div>
                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'inline-flex', width: '40px' }} className="col-md-5 p-0">
                                <CheckBox
                                    // value={this.state.selectedFundamental}
                                    tick={this.state.ownerCheck}
                                    style={{ paddingLeft: '0px' }}
                                    onCheck={(e) => this.handleCheckBox(e.target.checked, 'ownerCheck', 10, 'ownersOptions', 'selectedOwners')}


                                />

                            </label>
                            <span style={{ alignSelf: 'center' }}>
                                {t('Owners')}
                                </span>
                            <div className="input_sw ml-3 mr-3">
                                <MultiSelect
                                    options={this.state.ownersOptions}
                                    // disabled={[{ label: 'jagadish', value: '1' }]}
                                    standards={this.state.selectedOwners}
                                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedOwners", 10)}
                                />
                            </div>
                        </div>
                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'inline-flex', width: '40px' }} className="col-md-5 p-0">
                                <CheckBox
                                    // value={this.state.selectedFundamental}
                                    tick={this.state.docTypeCheck}
                                    style={{ paddingLeft: '0px' }}
                                    onCheck={(e) => this.handleCheckBox(e.target.checked, 'docTypeCheck', 12, 'docTypesOptions', 'selectedDocTypes')}


                                />

                            </label>
                            <span style={{ alignSelf: 'center' }}>
                                {t('Document type')}
                                </span>
                            <div className="input_sw ml-3 mr-3">
                                <MultiSelect
                                    options={this.state.docTypesOptions}
                                    // disabled={[{ label: 'jagadish', value: '1' }]}
                                    standards={this.state.selectedDocTypes}
                                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedDocTypes", 12)}
                                />
                            </div>
                        </div>
                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'inline-flex', width: '40px' }} className="col-md-5 p-0">
                                <CheckBox
                                    // value={this.state.selectedFundamental}
                                    tick={this.state.layoutsCheck}
                                    style={{ paddingLeft: '0px' }}
                                    onCheck={(e) => this.handleCheckBox(e.target.checked, 'layoutsCheck', 13, 'layoutsOptions', 'selectedLayouts')}
                                />

                            </label>
                            <span style={{ alignSelf: 'center' }}>
                                {t('Layouts')}
                                </span>
                            <div className="input_sw ml-3 mr-3">
                                <MultiSelect
                                    options={this.state.layoutsOptions}
                                    // disabled={[{ label: 'jagadish', value: '1' }]}
                                    standards={this.state.selectedLayouts}
                                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedLayouts", 13)}
                                />
                            </div>
                        </div>
                        <div className=" input-overall-sec mb-3 ">
                            <label style={{ display: 'inline-flex', width: '40px' }} className="col-md-5 p-0">
                                <CheckBox
                                    // value={this.state.selectedFundamental}
                                    tick={this.state.bundlesCheck}
                                    style={{ paddingLeft: '0px' }}
                                    onCheck={(e) => this.handleCheckBox(e.target.checked, 'bundlesCheck', 11, 'bundlesOptions', 'selectedBundles')}


                                />

                            </label>
                            <span style={{ alignSelf: 'center' }}>
                                {t('Bundles')}
                                </span>
                            <div className="input_sw ml-3 mr-3">
                                <MultiSelect
                                    options={this.state.bundlesOptions}
                                    // disabled={[{ label: 'jagadish', value: '1' }]}
                                    standards={this.state.selectedBundles}
                                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedBundles", 11)}
                                />
                            </div>
                        </div>
                        <div >
                            <reactbootstrap.FormGroup className="p-3" >
                                <reactbootstrap.FormCheck className="mb-2" type="radio" aria-label={"Active documents"} label={"Active documents"} name="document_choice" id={1} checked={this.state.document_choice === 1}
                                    value="Active_documents"
                                    onChange={(e) => this.handleOptionChange(e)}
                                />
                                <reactbootstrap.FormCheck className="mb-2" type="radio" aria-label={"All documents"} label={"All documents"} name="document_choice" id={2} checked={this.state.document_choice === 2}
                                    value="All_documents"
                                    onChange={(e) => this.handleOptionChange(e)}
                                />
                            </reactbootstrap.FormGroup>
                              <FormGroup>
                             {/* <div className="float-right pr-3"> */}
                             <div style={{ float: 'right' }} className="organisation_list pr-3">
                              {this.displayButton()}
                              </div>
                            </FormGroup>
                        </div>



                    </div>
                </div>
            </div >:<AccessDeniedPage/>

        )
    }


    componentDidMount() {
        if (this.state.id != 0) {
            datasave.service(window.GET_TOC_BY_ID + '/' + this.state.id, 'GET')
                .then(result => {
                    if (result['status'] == 200) {

                        this.setState({
                            entityData: result['entityData'],
                            document_choice: result['documentChoice'],
                            selectedManual: result['selectedManual'],
                            selectedFolder: result['selectedFolder'],
                            selectedDocument: result['selectedDocument'],
                            selectedStandards: result['selectedStandards'],
                            selectedSpaces: result['selectedSpaces'],
                            selectedTags: result['selectedTags'],
                            selectedOwners: result['selectedOwners'],
                            selectedLayouts: result['selectedLayouts'],
                            selectedBundles: result['selectedBundles'],
                            selectedDocTypes: result['selectedDocTypes'],
                            manualOptions: result['manualOptions'],
                            folderOptions: result['folderOptions'],
                            documentOptions: result['documentOptions'],
                            standardsOptions: result['standardsOptions'],
                            spacesOptions: result['spacesOptions'],
                            tagsOptions: result['tagsOptions'],
                            layoutsOptions: result['layoutsOptions'],
                            bundlesOptions: result['bundlesOptions'],
                            ownersOptions: result['ownersOptions'],
                            docTypesOptions: result['docTypeOptions'],
                            manualCheck: result['selectedManual'].length > 0 ? true : false,
                            folderCheck: result['selectedFolder'].length > 0 ? true : false,
                            documentCheck: result['selectedDocument'].length > 0 ? true : false,
                            standardsCheck: result['selectedStandards'].length > 0 ? true : false,
                            spacesCheck: result['selectedSpaces'].length > 0 ? true : false,
                            tagsCheck: result['selectedTags'].length > 0 ? true : false,
                            layoutsCheck: result['selectedLayouts'].length > 0 ? true : false,
                            bundlesCheck: result['selectedBundles'].length > 0 ? true : false,
                            ownerCheck: result['selectedOwners'].length > 0 ? true : false,
                            docTypeCheck: result['selectedDocTypes'].length > 0 ? true : false,
                            tocName: result['name']
                        })
                    }
                });
        }
    }
}

export default translate(TableContentFormV1);
