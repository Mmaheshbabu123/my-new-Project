import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import TableOfContentFormV1 from './TableOfContentFormV1';



class ReportList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            reports: [],
            t: props.t,
            activeTab: (this.props.match && this.props.match.params && this.props.match.params.id)? 2:1,
        }
        this.handleDelete = this.handleDelete.bind(this);
        this.handleSelect = this.handleSelect.bind(this);
    }

    handleSelect(key) {
      this.setState({
        activeTab: key
      });
    }
    handleDelete(id, e) {
        datasave.service(window.DELETE_REPORT + id, 'PUT', '')
            .then(response => {
                if (response === 1) {
                    window.location.reload()
                }
            })
    }
    componentDidMount() {
        var url = window.REPORTLIST;
        datasave.service(url, 'GET', '')
            .then(response => {
                this.setState({
                    reports: response,
                })
            });
    }
    render() {
        const { reports, t, activeTab } = this.state;
        let id = (this.props.match && this.props.match.params && this.props.match.params.id) ? this.props.match.params.id : 0;
        return (
          <Can
            perform = 'R_TOC,E_TOC,D_TOC'
            yes = {() => (
              <div className=" row col-md-12">
                  <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
                  <div style={{  }} className='col-md-11' >
                  <reactbootstrap.Tabs activeKey={activeTab} onSelect={this.handleSelect} style={{border:'none'}} id="controlled-tab-example">
                    <reactbootstrap.Tab eventKey={1} title={t("Manage table of content")}>
                      <div className='row ' >
                          <div id="reportslist" className='col-md-12 mt-5 mb-5' >
                              <div className='card' >
                                  <form method='POST'>
                                  <Can
                                    perform = 'R_TOC,E_TOC,D_TOC'
                                    yes = {() => (

                                    //   <reactbootstrap.Table className="site-table-main"  responsive striped bordered hover size="sm">
                                    <reactbootstrap.Table className="site-table-main"  striped responsive bordered>
                                        <thead>
                                              <tr>
                                                  <th style={{ border: 'none',position: 'sticky',top: '0' }}>{t('Name')}</th>
                                                  <th style={{ borderTop: 'none', position: 'sticky',top: '0' }}>{t('Actions')}</th>
                                              </tr>
                                          </thead>
                                          <tbody>
                                              <div style={{  }} className="error-block">{this.state.error}
                                              </div>
                                              {this.state.reports.map(
                                                  function (item) {
                                                      return (
                                                          <tr style={{ borderBottom: '1px solid #dee2e6' }}>
                                                              <td style={{}}>{item.name}</td>
                                                              <td style={{ display: 'flex', border: '0px'}}>
                                                              <Can
                                                                perform = 'E_TOC'
                                                                yes = {() => (
                                                                  <Link
                                                                      style={{ paddingRight: '1rem' }}
                                                                      to={`/appsettings/addtoc/${item.id}`}
                                                                      key={item.id}
                                                                  >
                                                                      {/* {t('Edit')} */}
                                                                      <i title="Edit" class="overall-sprite overall-sprite-myeditc"></i>
                                                                  </Link>
                                                                  )}
                                                                />
                                                                <Can
                                                                  perform = 'D_TOC'
                                                                  yes = {() => (
                                                                  <a href='#'
                                                                      onClick={this.handleDelete.bind(this, item.id)}
                                                                  >
                                                                      <i title="Delete" class="overall-sprite overall-sprite-mtdeletec"></i>
                                                                  </a>
                                                                  )}
                                                                />
                                                              </td>

                                                          </tr>
                                                      )
                                                  }, this)
                                              }
                                          </tbody>

                                      </reactbootstrap.Table>

                                      )}
                                    />

                                  </form>
                              </div>
                          </div>
                          </div>

                          </reactbootstrap.Tab>
                          <reactbootstrap.Tab eventKey={2} title={t("Add table of content")}>
                            <TableOfContentFormV1 history={this.props.history} id={id}/>
                          </reactbootstrap.Tab>
                          </reactbootstrap.Tabs>
                  </div>
              </div>
            )}
            no = {() =>
              <AccessDeniedPage />
            }
          />
        )
    }

}

export default translate(ReportList);
