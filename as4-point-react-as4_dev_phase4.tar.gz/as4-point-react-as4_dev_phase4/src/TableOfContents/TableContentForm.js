import React, { Component } from 'react';
import { datasave } from '../_services/db_services';
import * as reactbootstrap from 'react-bootstrap';
import MultiSelect from '../_components/MultiSelect';
import { Link } from 'react-router-dom';
import { translate } from '../language';
import { Button, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import { ConditionPosition } from 'ag-grid-community/dist/lib/filter/provided/simpleFilter';
import { OCAlert } from '@opuscapita/react-alerts';
import Can from '../_components/CanComponent/Can'
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';

class TableContentForm extends Component {
  constructor(props) {
    super(props)
    this.state = {
      name: '',
      options: [],
      selected_options: [],
      tokens: [],
      token_options: [],
      selected_tokens: [],
      checked_options: [],
      multiselect_options: [],
      multiselect: [],
      selected_multiselect_options: [],
      list: [],
      multi_options: [],
      choosen_options: [],
      check: false,
      exportcheckbox: false,
      filter: false,
      sortorder: false,
      id: [],
      name_error: '',
      type_name: '',
      type_names: [],
      folders: [],
      manuals: [],
      spaces: [],
      tags: [],
      standards: [],
      bundles: [],
      doc_type: [],
      document_owner: [],
      layouts: [],
      documents: [],
      radio_option: '',
      token_names: [],
      filter: false,
      exportcheckbox: false,
      checkboxes: [],
      id: this.props.match.params.id,
      t: props.t,
      manuals_ids: [],
      new_tokens: [],
      token: [],
      document_choice: 'All_documents',
    }
    this.handleCheck = this.handleCheck.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleChangeTokens = this.handleChangeTokens.bind(this);
    this.handleonClick = this.handleonClick.bind(this);
    this.handleChangeOptions = this.handleChangeOptions.bind(this);
    this.handleOptionChange = this.handleOptionChange.bind(this);
    this.handleCheckChange = this.handleCheckChange.bind(this);
  }
  handleChange(event) {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
      name_error: '',
    });
  }
  findDiff(arr1, arr2) {
    var count = 0;
    var result = [];
    for (var i = 0; i < arr1.length; i++) {
      if (arr2.indexOf(arr1[i]) === -1) {
        result.push(arr1[i]);
      }
    }
    return result;
  }
  changeOptions(event, name) {
    let before_manuals = [];
    let after_manuals = [];
    before_manuals = this.state.manuals;
    this.state[name] = event;
    after_manuals = this.state.manuals;

    if (before_manuals.length > after_manuals.length) {
      let result = this.findDiff(before_manuals, after_manuals);
      // if(this.state.folders != undefined) {

      if (this.state.folders != undefined) {
        var arr = this.state.folders.filter(function (s) {
          return s.manual_id != result[0].value
        });

      }
      if (this.state.documents != undefined) {
        var darr = this.state.documents.filter(function (s) {
          return s.manual_id != result[0].value
        });

      }

      this.setState({
        folders: arr,
        documents: darr,
      })
    }
  }
  fchangeOptions(event, name) {
    let before_folders = [];
    let after_folders = [];
    before_folders = this.state.folders;
    this.state[name] = event;
    after_folders = this.state.folders;
    if (before_folders != undefined) {
      if (before_folders.length > after_folders.length) {
        let result = this.findDiff(before_folders, after_folders);
        if (this.state.documents !== undefined) {
          var darr = this.state.documents.filter(function (s) {
            return s.parent_id != result[0].value
          });
        }

        this.setState({
          documents: darr,
        })
      }
    }
  }
  handleChangeOptions(event, name) {
    if (name === 'manuals') {
      this.changeOptions(event, name);
    }
    else if (name === 'folders') {
      this.fchangeOptions(event, name);
    }
    let type = name;
    let dataResult = [];
    const details = {
      type_name: name,
      manuals_ids: event,
      states: this.state,
    }
    datasave.service(window.DISPLAYOPTIONS, 'POST', details)
      .then(result => {
        if (type === 'folders' || type === 'documents' || type === 'manuals') {
          dataResult = this.state.multiselect_options;
          dataResult.push({ 'manuals': result['manuals'] });
          dataResult.push({ 'folders': result['folders'] });
          dataResult.push({ 'documents': result['documents'] });
          this.setState(prevState => ({
            multiselect_options: dataResult,
            [name]: event,
          }));
        }
        else {
          dataResult = { [type]: result[type] };
          this.setState(prevState => ({
            multiselect_options: [...prevState['multiselect_options'], dataResult],
            [name]: event,
          }));
        }
      })
    if (this.state[name] == '') {
      let checked = 'false';
      this.setState({
        [name]: { [checked]: 'false' },
      })
    }
  }
  handleChangeTokens(event) {
    let token = this.state.token;
    token.push(event.target.value);
    let token_options = [];
    let new_tokens = [];
    new_tokens = this.state.new_tokens;
    token_options = this.state.token_options;
    token.map((rtoken) => {
      token_options.map((tok) => {
        if (tok.label == rtoken) {
          new_tokens.push(tok);
        }
      })
    })
    this.setState({
      selected_tokens: event.target.value,
      new_tokens: new_tokens,
      token: token
    });
  }
  handleOptionChange(event) {
    this.setState({
      [event.target.name]: event.target.value,
      //  radio_option: event.target.value,
    })
  }
  handleonClick() {
    let tokens = [];
    let defaultTokenS = [];
    defaultTokenS = this.state.checkboxes;
    tokens = this.state.tokens;
    if (this.state.selected_tokens != '') {
      let defaultToken = {
        'name': this.state.selected_tokens,
        'exported': false,
        'filter': false,
        'sortorder': '',
      };
      defaultTokenS.push(defaultToken);
      tokens.push(this.state.selected_tokens);
      this.setState({
        tokens: tokens,
        checkboxes: defaultTokenS,
        selected_tokens: '',
      });
      this.deleteTokens(this.state.selected_tokens)
    }
  }
  handleClick(e, token) {
    if (this.props.match.params.id) {
      var array = this.state.checkboxes.filter(function (s) {
        return s != token
      });
      this.state.tokens.map((opt) => {
        if (opt.label == token.name) {
          this.state.token_options.push(opt);
        }
      })
      this.setState({
        checkboxes: array,
      });
    }
    else {
      var array = this.state.checkboxes.filter(function (s) {
        return s != token
      });
      this.state.new_tokens.map((opt) => {
        if (opt.label == token.name) {
          this.state.token_options.push(opt);
        }
      })
      this.state.token_options.sort(function (a, b) {
        if (a.label > b.label) return 1;
        else if (a.label < b.label) return -1;
        else return 0;
      });
      this.setState({
        checkboxes: array,
      });
    }
  }
  handleCheck(event) {
    let type_names = [];
    let type = event.target.name;
    var data = {
      type_name: type,
      id: event.target.value,
      states: this.state,
    }
    type_names = this.state.type_names;
    type_names.push(event.target.name);
    this.setState({
      type_names: type_names,
      check: true,
    })
    this.state.options.map((option_name) => {
      if (option_name.name === event.target.name) {
        option_name.checked = !option_name.checked;
      }
    }
    );
    let dataResult = [];
    datasave.service(window.MULTITOKENOPTIONS, 'POST', data)
      .then(result => {
        if (type === 'folders' || type === 'documents' || type === 'manuals') {
          dataResult = this.state.multiselect_options;
          dataResult.push({ 'manuals': result['manuals'] });
          dataResult.push({ 'folders': result['folders'] });
          dataResult.push({ 'documents': result['documents'] });
          this.setState(prevState => ({
            multiselect_options: dataResult,
          }));
        }
        else {
          dataResult = { [type]: result[type] };
          this.setState(prevState => ({
            multiselect_options: [...prevState['multiselect_options'], dataResult],
          }));
        }

      });
  }
  handleCheckChange(e, token, type) {
    let tokenname = token;
    let checked = (type === 1) ? e.target.checked : e.target.value;
    let checkboxes = this.state.checkboxes;
    checkboxes.map((tokend, i) => {
      if (tokend.name === tokenname) {
        checkboxes[i][e.target.name] = checked;
      }
    });
    this.setState({
      checkboxes: checkboxes,
    })
  }
  handleSubmit(event) {
    const {t} = this.state;
    event.preventDefault();
    this.setState({ submitted: true });
    const { history } = this.props
    const details = {
      name: this.state.name,
      id: this.props.match.params.id,
      tokens: this.state.tokens,
      radio_option: this.state.radio_option,
      document_choice: this.state.document_choice,
      checkboxes: this.state.checkboxes,
      type_name: this.state.type_name,
      type_names: this.state.type_names,
      options: this.state.options,
      states: this.state,
    }
    let stateValue = this.state;

    if (this.state.manuals.length > 0) {


      if (this.props.match.params.id) {
        datasave.service(window.UPDATE_RECORD + '/' + details.id, 'PUT', this.state)
          .then(response => {
            if (response.name) {
              this.setState({
                name_error: response.name,
              })
            }
            else {
              OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });

              // alert("Saved successfully");
              history.push('/appsettings/managetoc');
            }
          })
          .catch(error => {
            this.setState({
              errors: error.response
            })
          })
      }
      else {
        datasave.service(window.SAVEOPTIONS, 'POST', stateValue)
          .then(response => {
            if (response.name) {
              this.setState({
                name_error: response.name,
              })
            }
            else {
              OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });

              // alert("Saved successfully");
              history.push('/appsettings/managetoc');
            }
          })
          .catch(error => {
            this.setState({
              errors: error.response
            })
          })
      }
    } else {
      OCAlert.alertWarning(t('Please select manuals'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
  }
  getTokenOptions() {
    let temp = [];
    if (this.state.token_options.length >= 1) {
      if (this.state.token_options) {
        temp = this.state.token_options.map((ind) => {
          return (<option id={ind.value} value={ind.label} >{ind.label}</option>)
        })
        return temp;
      }
    }
  }
  deleteTokens(item) {
    var array = this.state.token_options.filter(function (s) {
      return s.label != item
    });
    this.setState({ token_options: array });
  }
  deleteToken(item) {
    item.forEach(element => {
      var array = this.state.token_options.filter(function (s) {
        return s.label != element
      });
      this.setState({ token_options: array });
    });
  }
  componentDidMount() {
    datasave.service(window.SHOWOPTIONS, 'GET')
      .then(result => {
        this.setState({
          options: result,
        })
      });
    datasave.service(window.TOKENOPTIONS, 'GET')
      .then(result => {
        if (this.state.tokens) {
          this.deleteToken(this.state.tokens)
        }
        this.setState({
          token_options: result,
        })
      });
    if (this.props.match.params.id) {
      const details = {
        id: this.props.match.params.id,
        states: this.state,
      }
      datasave.service(window.GET_REPORTDATA + details.id, 'POST', details)
        .then(response => {
          this.setState({
            name: response.toc_data[0]['toc_name'],
            radio_option: response.toc_data[0]['toc_type'],
            document_choice: response.toc_data[0]['document_choice'] == 1 ? 'Active_documents' : 'All_documents',
            token_names: response.toc_items_data,
            type_name: response.toc_type,
            folders: response.folders,
            manuals: response.manuals,
            spaces: response.spaces,
            tags: response.tags,
            standards: response.standards,
            bundles: response.bundles,
            doc_type: response.doc_type,
            document_owner: response.document_owner,
            layouts: response.layouts,
            documents: response.documents,
            checked: response.checked,
            checkboxes: response.checked_data,
            multiselect_options: response.multiselect,
          })
          if (this.state.type_name) {
            this.state.type_name.map((type) => {
              this.state.type_names.push(type.label);
            })
          }
          let defaultTokenS = [];
          let tokens = [];
          defaultTokenS = this.state.checkboxes;
          tokens = this.state.token_names;
          let defaultToken = {};
          let defaultTokenSel = [];
          let token = [];
          if (this.state.token_names) {
            this.state.token_names.map((tok) => {
              defaultToken = {
                'name': tok.label,
                'exported': false,
                'filter': false,
                'sortorder': '',
              };
              defaultTokenSel.push(defaultToken);
              token.push(tok);
              this.deleteTokens(tok.label);
            })
          }
          this.setState({
            tokens: token,
          })
          if (this.state.type_name) {
            this.state.type_name.map((type) => {
              if (type.checked == 1) {
                let data = type.label;
                let elementOptions = this.state.options;
                elementOptions.map(function (element, key) {
                  if (element.name === type.label) {
                    elementOptions[key]['checked'] = true;
                    this.setState(prevState => ({
                      options: elementOptions,
                    }));
                  }
                }, this);
              }
            })
          }
        });
    }
  }
  render() {
    const { name, t, loading, filter, exportcheckbox, name_error } = this.state
    const displayoptions = (
      <ul>
        {
          this.state.options.map(function (data, key) {
            var multioptions = [];
            var selected_multiselect_options = [];
            if (this.state.multiselect_options.length >= 1) {
              this.state.multiselect_options.map(function (item, mkey) {
                Object.keys(item).map(function (itemms, keyms) {
                  if (itemms === data.name) {
                    multioptions = item[itemms];
                    return;
                  }
                })
              });
            }
            // console.log(multioptions)
            selected_multiselect_options = this.state[data.name];
            return (<li style={{ listStyle: 'none' }}>
              <label style={{ display: 'flex' }} className="col-md-12 mt-2 p-0">
                <input
                  type="checkbox"
                  name={data.name}
                  id={data.id}
                  value={data.id}
                  checked={data.checked}
                  onChange={this.handleCheck}
                  style={{ opacity: 0, marginRight: '5px' }}
                />
                <div className="check-approval">
                  <div class="inside"></div>
                </div>
                <div style={{ marginLeft: '7px' }}> {data.toc_name} {data.toc_name === 'Manuals'&& <span style={{ color: "red" }}>*</span>} </div>
              </label>
              {/* <reactbootstrap.FormCheck
                name={data.name}
                value={data.id}
                // label = {data.name.charAt(0).toUpperCase() + data.name.slice(1)}
                label={data.toc_name}
                onChange={this.handleCheck}
                checked={data.checked}
              >
              </reactbootstrap.FormCheck> */}
              {data.checked === true &&
                <div className="input_sw">
                  <MultiSelect
                    options={multioptions}
                    standards={selected_multiselect_options}
                    id="select_ids"
                    value={this.state.selected_multiselect_options.select_ids}
                    handleChange={(e) => this.handleChangeOptions(e, data.name)}
                  />
                </div>
              }
            </li>)
          }, this)}
      </ul>
    );
    // console.log(selected_multiselect_options)
    const displaytokens = (
      <ul>
        {this.state.checkboxes.map(token =>
          <li style={{ listStyle: 'none' }}>
            <td>{token.name}</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td><reactbootstrap.FormCheck
              name={"filter"}
              checked={token.filter}
              label={t("Filter")}
              tick={filter}
              id={filter}
              onChange={(e) => this.handleCheckChange(e, token.name, 1)}>
            </reactbootstrap.FormCheck>
            </td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>
              <reactbootstrap.FormCheck
                name={"exported"}
                checked={token.exported}
                label={t("Export")}
                tick={"exported"}
                id={token}
                onChange={(e) => this.handleCheckChange(e, token.name, 1)}>
              </reactbootstrap.FormCheck>
            </td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>{t('Column order')}
              <input type="number" min="0" id="sortorder" value={token.sortorder} name="sortorder" onChange={(e) => this.handleCheckChange(e, token.name, 2)} />
            </td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>
              <button type="button" onClick={(e) => this.handleClick(e, token)}>{t('Remove')}</button>
            </td>
            <br></br>
          </li>
        )}
      </ul>
    );
    return (
      <Can
        perform="E_TOC"
        yes={() => (
          <div className="row">
            <div style={{ visibility: 'hidden' }} className="col-md-1">
              <p>welcome</p>
            </div>
            <div style={{ marginLeft: '0.45rem' }} className='col md-11' >
              <div className='row justify-content-center' >
                <div style={{ border: '1px solid lightgray', borderRadius: '5px', marginLeft: '-2rem' }} className='col-md-9 mb-5 pt-2 mt-4' >
                  <form method="post" >
                    <reactbootstrap className="">
                      <reactbootstrap>
                        <Can
                          perform="R_TOC,E_TOC,D_TOC"
                          yes={() => (
                            <Link className="float-right"
                              to={`/appsettings/managetoc`}
                            ><div className="col-md-12 mb-3">
                                {t('Manage table of contents')}
                              </div>
                            </Link>
                          )}
                        />
                        <reactbootstrap.FormGroup>
                          <div className=" input-overall-sec ">
                            <InputGroup className="">
                              {/* <reactbootstrap.InputGroup className="mb-3"> */}
                              <div className="col-md-4 ">
                                <reactbootstrap.InputGroup.Prepend>
                                  <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Table of contents')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                                </reactbootstrap.InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd   ">
                                <div className="input_sw ">
                                  <reactbootstrap.FormControl
                                    name="name"
                                    placeholder={t("Table of contents name")}
                                    aria-label="Table of contents name"
                                    aria-describedby="basic-addon1"
                                    value={name}
                                    onChange={e => this.setState({ name: e.target.value, name_error: '' })}
                                  />
                                </div>
                                {/* </reactbootstrap.InputGroup> */}
                                <div style={{ color: 'red' }} className="error-block mt-2">{name_error}</div>
                              </div>
                            </InputGroup>
                          </div>
                        </reactbootstrap.FormGroup>
                        {displayoptions}
                        <reactbootstrap.FormGroup className="pl-3">

                          {/* <reactbootstrap.FormCheck className="mb-1" type="radio" aria-label="Fundamental" label="Fundamental" name="radio_option" id="Fundamental" checked={this.state.radio_option === 'Fundamental'}
                            value="Fundamental"
                            onChange={(e) => this.handleOptionChange(e)}
                          />
                          <reactbootstrap.FormCheck className="mb-1" type="radio" aria-label="Statistics" label="Statistics" name="radio_option" id="Statistics" checked={this.state.radio_option === 'Statistics'}
                            value="Statistics"
                            onChange={(e) => this.handleOptionChange(e)}
                          /> */}
                          <reactbootstrap.FormCheck className="mb-1" type="radio" aria-label={t("Active documents")} label={t("Active documents")} name="document_choice" id="Active_documents" checked={this.state.document_choice === 'Active_documents'}
                            value="Active_documents"
                            onChange={(e) => this.handleOptionChange(e)}
                          />
                          <reactbootstrap.FormCheck className="mb-1" type="radio" aria-label={t("All documents")} label={t("All documents")} name="document_choice" id="All_documents" checked={this.state.document_choice === 'All_documents'}
                            value="All_documents"
                            onChange={(e) => this.handleOptionChange(e)}
                          />
                        </reactbootstrap.FormGroup>
                        {/* <reactbootstrap.FormGroup>
                          <reactbootstrap.InputGroup className="mb-3 col-md-4 col-lg-4 col-sm-4">
                            <reactbootstrap.Form.Control as="select" name="token_options"
                              value={this.state.selected_tokens}
                              onChange={this.handleChangeTokens} >
                              <option>Select</option>
                              {this.getTokenOptions()}
                            </reactbootstrap.Form.Control>
                            <button type="button" onClick={this.handleonClick}> {t('Add column')} </button>
                          </reactbootstrap.InputGroup>
                        </reactbootstrap.FormGroup> */}
                        <ul style={{ listStyle: 'none' }}>{displaytokens}</ul>
                        <FormGroup>
                          <div style={{ float: 'right' }} className="organisation_list mb-3">
                            <a onClick={this.handleCancel} >{t('Cancel')}</a>
                            &nbsp;&nbsp;&nbsp;
                          <reactbootstrap.Button type="button" style={{ fontSize: '14px' }} className="btn btn-primary " disabled={loading} onClick={this.handleSubmit}>{t('Save')}</reactbootstrap.Button>
                          </div>
                        </FormGroup>

                      </reactbootstrap>
                    </reactbootstrap>
                  </form>
                </div>
              </div>
            </div>
          </div>
        )}
        no={() =>
          <AccessDeniedPage />
        }
      />
    )
  }
}
export default translate(TableContentForm);
