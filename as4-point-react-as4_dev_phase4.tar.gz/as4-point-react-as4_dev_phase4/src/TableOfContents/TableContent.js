import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import CKEditor from '@ckeditor/ckeditor5-react';
import ClassicEditor from 'ckeditor5-build-classic-plus';
import { datasave } from '../_services/db_services';
import Select from 'react-select';
import contents from '../TableOfContents/tablecontents.json';
import TagsList from '../Tags/TagsList';
import { translate, t } from '../language';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { existsTypeAnnotation, exportDefaultSpecifier } from '@babel/types';
import { OCAlert } from '@opuscapita/react-alerts';
import './TableContent.css';
import TreeMenu from 'react-simple-tree-menu';
import { Input, ListGroup, ListGroupItem } from 'reactstrap';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';

class TableContent extends Component {
    count = 0;
    color = ["", "#244061", "#244061", "#B8CCE4", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF", "#BFBFBF"];
    parentStage = [];
    manuals=[];
    manual_folders =[];
    folders=[];
    manual_id=0;
    tileId=0;
    constructor(props) {
        super(props);
        this.state = {
            contents: {},
            view: [],
            width: [],
            resultJSON: {},
            selectionData: {},
            status: false,
            id: this.props.match.params.id,
            links: false,
            columnDefs: [],
            defaultColDef: [],
            gridId: this.props.match.params.gridid,
            gridItemId: this.props.match.params.griditemid,
            tileId: this.props.match.params.tileid,
            personId: this.props.match.params.uid,
            grandParent: {},
            tocDetails: [],
            tocDetailsState: false,
            itemIdAsTileId: 0,
            tocViewStatus: false,
            tocLinkState: false,
            t: props.t,
            allData: [],
            tableLinks: [],
            allDataStatus: false,
            resIntialOpen: [],
            resIntialActive: [],
            tocSelectedKeys: [],
            showClosePopup:false,
            check_manual:false,
            TocSelectedStandards:[],
        }
        this.handleOnClick = this.handleOnClick.bind(this);
        this.handleSelect = this.handleSelect.bind(this);
        this.sendHTMLToBackend = this.sendHTMLToBackend.bind(this);
        this.onClickNode = this.onClickNode.bind(this);
    }

    getalldata() {
        let table = [];
        let contents = this.state.grandParent;
        if (this.state.allDataStatus) {
            for (var key in contents) {
                let item = contents[key];
                if (item.entity_type === "parent" && item.type === "manual") {
                    this.count = 1;
                    this.manual_id= item.id;
                    table.push(this.parentFolder(item.id));
                }
            }
            this.setState({
                allData: table,
                tocLinkState: true,
                allDataStatus: false,
            })
        }
    }

    sendHTMLToBackend(){
      let html = document.getElementById('tableOfContent').innerHTML;
      let htmalData = {
        body  : html,
      }
      datasave.service(window.DOWNLOAD_TOC,'POST',htmalData)
      .then(response => {
          console.log(response);
        if(response.status === '200') {
              var a      = document.createElement("a");
              a.setAttribute("type", "file");
              a.href     = response.data.url;
              a.download = response.data.name;
              a.target   = '_blank';
              document.body.appendChild(a);
              a.click();
              a.remove();
        }
      })
    }

    handleSelect(id) {
      // window.open(window.location.origin + '/documentview/' + id + '?q=' + window.location.pathname)
       if(parseInt(localStorage.getItem("toc_download")) ===1 ) {
             window.open(window.location.origin + '/tocpreview/' + id + '/' + this.tileId + '?q=' + window.location.pathname)
           }else{
             window.open(window.location.origin + '/documentview/' + id + '?q=' + window.location.pathname)
           }

    //  window.open(window.location.origin + '/documentview/' + id + '/' + this.tileId + '?q=' + window.location.pathname)
    //  window.open(window.location.origin + '/previewrevisionentities/' +1+'/'+ id+'/11034', '_blank');

        // datasave.service(window.DOC_PREVIEW + '/1' + '/' + id, 'GET')   // word,visio, xl
        //     .then(response => {
        //         if (response.status === 200) {
        //             window.open(window.location.origin + '/previewrevision?content=' + response.content, '_blank');
        //         }
        //         else {
        //             OCAlert.alertWarning(response.message, { timeOut: window.TIMEOUTNOTIFICATION1 });
        //         }
        //     });
    }

    getItem(id) {
        let table = [];
        let contents = this.state.contents;
        for (var key in contents) {
            if (key === id) {
                return contents[id];
            }
        }
    }

    getview() {
        let table = [];
        const { view, width } = this.state;
        view.map((key, index) => {
            table.push(<td><div style={{width: width[index] + 'px'}}>{key}</div></td>);
        });
        return table;
    }

    onClickNode(key, label, props) {
      let tocObj = [];
      let opennodes = this.state.tocSelectedKeys;
      if (opennodes !== null && opennodes.includes(key)) {
          var index = opennodes.indexOf(key);
          if (index !== -1) opennodes.splice(index, 1);
      } else {
          opennodes.push(key);
      }

      this.setState(prevState => ({
        tocSelectedKeys: [...prevState['tocSelectedKeys'], opennodes]
      }));
    }

    parentFolder(id) {
        let table = [];
        let item = this.getItem(id);
        table.push(
            <reactbootstrap.Table responsive striped bordered hover size="sm">
              <thead style={{ background: this.color[this.count] }}>
                <th style={{ color: '#fff' }} id={item.id}>{item.title}</th>
              </thead>
              </reactbootstrap.Table >
        );
        let childDoc = [];
        let childFold = [];
        if (item.children !== undefined) {
            let childArr = [];
            childArr = item.children;
            childArr.map(key => {
                let item = this.getItem(key);
                if (item.type === "document") {
                    childDoc.push(
                        item.id
                    );
                }
                if (item.type === "folder") {
                    childFold.push(
                        item.id
                    );
                }
            });
        }

        if (childDoc !== undefined && childDoc.length > 0) {
            table.push(<reactbootstrap.Table responsive striped bordered hover size="sm">
                <thead>
                    <tr>
                        {this.getview()}
                    </tr>
                </thead>
                <tbody>
                    {this.documents(childDoc)}
                </tbody>
            </reactbootstrap.Table>);
        }

        if (childFold !== undefined) {
            childFold.map((key, index) => {
                var contents = this.state.contents;
                var pid = contents[key]['parent_id'];
                if (this.parentStage.length > 0) {
                    var val = this.findParentStages(this.parentStage, pid);
                    if (val) {
                        this.count = val + 1;
                        this.parentStage.push({ [key]: this.count });
                    } else {
                        this.count = 2;
                        this.parentStage.push({ [pid]: 1 });
                        this.parentStage.push({ [key]: 1 + 1 });
                    }
                } else {
                    this.count = 2;
                    this.parentStage.push({ [pid]: 1 });
                    this.parentStage.push({ [key]: 1 + 1 });
                }
                table.push(this.parentFolder(key));
            });
        }
        return table;
    }

    findParentStages(parentStages, pid) {
        var tempVar = 0;
        parentStages.map((key, index) => {
            if (key[pid] !== undefined && key[pid] !== 0) {
                tempVar = key[pid];
            }
        })
        return tempVar;
    }


    documents(childDoc) {
        let table = [];
        let rowData = [];
        childDoc.map(key => {
            let item = this.getItem("'" + key + "'");
            //rowData.push(item);

            // table.push(<tr id={key} onClick={this.handleSelect(key)}>
            //     {this.getdocuments(item)}
            // </tr>
            // )
            table.push(<tr id={key} onClick={() => this.handleSelect(key)}>
                {/* <div > */}
                {this.getdocuments(item)}
                {/* </div> */}
            </tr>
            )
        });
        // if (rowData.length > 0) {
        //     table.push(
        //         <div
        //             className="ag-theme-balham"
        //             style={{
        //                 height: '200px',
        //                 width: '700px',
        //             }}
        //         >
        //             <AgGridReact
        //                 rowSelection="multiple"
        //                 onGridReady={params => this.gridApi = params.api}
        //                 columnDefs={this.state.columnDefs}
        //                 rowData={rowData}
        //                 defaultColDef={this.state.defaultColDef}
        //                 floatingFilter={true}
        //                 onSelectionChanged={this.onSelectionChanged.bind(this)}
        //             // localeText={this.defaultText()}
        //             >
        //             </AgGridReact>
        //         </div>
        //     );
        // }
        return table;
    }

    onSelectionChanged() {
        var selectedRows = this.gridApi.getSelectedRows();
        var selectedRowsString = "";
        selectedRows.forEach(function (selectedRow, index) {
            OCAlert.alertSuccess(selectedRow.id, { timeOut: window.TIMEOUTNOTIFICATION });
            // alert(selectedRow.id);
        });
    }

    getdocuments(item) {
        let table = [];
        let view = this.state.view;
        view.map(key => {
            table.push(<td id={key}>{item[key]}</td>);
        });
        return table;
    }

    handleOnClick(id) {
        this.handleTocViewService(id);
    }

    getInitialKeys(openIntial, ) {
      this.state.tocSelectedKeys.map(function(item, key){
        openIntial.push(item);
      });
      return openIntial;
    }

    labelClick(e, id) {
      console.log(id);
      document.getElementById(id).scrollIntoView({behavior: 'smooth', inline: 'center'});
    }

    tablesLinkList() {
        let table = [];
        const {t} = this.state;
        const DEFAULT_PADDING = 5;
        const ICON_SIZE = 8;
        const LEVEL_SPACE = 16;
        const WIDTH = '25px';
        const HEIGHT = '25px';
        const DISPLAY = 'inline-flex';
        const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }} >{on ? '-' : '+'}</span>;
        const ListItem = ({
            level = 0,
            key,
            id,
            type,
            hasNodes,
            isOpen,
            label,
            searchTerm,
            openNodes,
            ...props

        }) => (
                <div className="folder-manual-section">
                  <ListGroupItem
                    className="left-border list-zindex"
                    {...props}
                    style={{
                      paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
                      cursor: 'pointer',
                    }}
                    key={key}>
                    <div className="list-items-structure">
                      {hasNodes && <ToggleIcon on={isOpen} />}
                      {!hasNodes && <span style={{ marginRight: 8 }}> &nbsp;</span>}
                      {type === 'manual' && <i class="folder-icons folder-icons-accounts" title="Manual" style={{ marginRight: '5px' }}> </i>}
                      {type === 'folder' &&
                        <i class="folder-icons folder-icons-folder" title="Folder" style={{ marginRight: '5px',float:'right' }}> </i>}
                      <span onClick={(e) => this.labelClick(e, id)} title={label} className={'folderstructure-label-' + type} >
                        {label}
                      </span>
                    </div>
                    </ListGroupItem>
                </div>
            );
        if (this.state.tocLinkState) {
            var stagesArr = this.parentStage;
            let contents = this.state.contents;
            let treeData1 = [];
            let openIntial = [];
            let activeIntial = [];
            var count = -1;
            stagesArr.map(key => {
                var temp = Object.keys(key)[0];
                if (key[temp] === 1) {
                    openIntial.push(temp);
                    activeIntial.push(temp);
                    treeData1.push(
                        {
                            key: temp,
                            label: contents[temp]['title'],
                            nodes: [],
                            id: temp,
                            type: 'manual',
                        }
                    );
                    count = count + 1;
                } else {
                    let str = this.findParentNode(treeData1, key[temp] - 2, count);
                    openIntial.push(str[1] + '/' + temp);
                    str[0].push(
                        {
                            key: temp,
                            label: contents[temp]['title'],
                            nodes: [],
                            id: temp,
                            type: 'folder',

                        }
                    )
                }
                // var padding = 3 * key[temp] + '%';
                // table.push(<li><a href={'#' + temp} style={{ "padding-left": padding }}>{contents[temp]['title']}</a></li>)
            });
            return (<TreeMenu
                data={treeData1}
                hasSearch='false'
                // initialOpenNodes={openIntial}
                // initialActiveKey={activeIntial}
                onClickItem={({ key, label, ...props }) => {
                    this.onClickNode(key, label, props);
                }
                }
                // onDoubleClickItem={({ key, label, ...props }) => {
                //     this.onClickNode(key, label, props);
                // }}
                debounceTime={125}
                activeKey={activeIntial}
                openNodes={this.getInitialKeys(openIntial)}
            >
                {({ search, items }) => (
                    <>
                        <Input style={{}} onChange={e => search(e.target.value)} placeholder={t("Type and search")} />
                        <div className="sim">
                            <ListGroup className="folder-left-list-group">
                                {items.map(props => (
                                    <ListItem {...props} />
                                ))}
                            </ListGroup>
                            <div style={{ height: '170px', visibility: 'hidden', }}></div>

                        </div>
                    </>
                )
                }
            </TreeMenu>
            );
            // stagesArr.map(key => {
            //     var temp = Object.keys(key)[0];

            //     var padding = 3 * key[temp] + '%';

            //     table.push(<li><a href={'#' + temp} style={{ "padding-left": padding }}>{contents[temp]['title']}</a></li>)

            // });
            // })
        }
        // return table;
        // for (var key in contents) {
        //     let item = contents[key];
        //     if (item.entity_type === "parent" && item.type === "folder") {
        //         table.push(<li><a href={'#' + item.id}>{item.title}</a></li>);
        //     }
        // }
    }

    findParentNode(treeData1, key, count) {
        var levelCount = 1;
        var tempIntial = treeData1[count]['id'];
        var str = treeData1[count]['nodes'];
        for (var i = 1; i <= key; i++) {
            if (str.length == 0) {
                // if (levelCount < 2) {
                // tempIntial = tempIntial + '/' + str[0]['id'];
                // levelCount++;
                // }
                str = str[0]['nodes'];
            } else {
                // if (levelCount < 2) {
                // tempIntial = tempIntial + '/' + str[str.length - 1]['id'];
                // levelCount++;
                // }
                str = str[str.length - 1]['nodes'];
            }
        }
        return [str, tempIntial];
    }

    handleIntialOpenNodes(tableData1) {
        var result = {
            resIntialOpen: [],
            resIntialActive: [],
        }
        tableData1.map(key => {
            var k = key.id.trim('"');
            result['resIntialActive'].push(k);
            result['resIntialOpen'].push(k);
            key.nodes.map(key1 => {

                var k1 = key1.id.trim('"');
                result['resIntialOpen'].push(k + '/' + k1);
                key1.nodes.map(key2 => {
                    var k2 = key2.id.trim('"');
                    result['resIntialOpen'].push(k + '/' + k1 + '/' + k2);
                })
            })
        })
        // this.setState({
        //     'resIntialOpen': result['resIntialOpen'],
        //     'resIntialActive': result['resIntialActive']
        // });
        return result;
    }
    tocLinkList() {
        let table = [];
        const {t} = this.state;
        const DEFAULT_PADDING = 5;
        const ICON_SIZE = 8;
        const LEVEL_SPACE = 16;
        const WIDTH = '25px';
        const HEIGHT = '25px';
        const DISPLAY = 'inline-flex';
        const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }} >{on ? '-' : '+'}</span>;
        const ListItem = ({
            level = 0,
            key,
            id,
            type,
            parent_id,
            hasNodes,
            isOpen,
            label,
            searchTerm,
            openNodes,
            ...props

        }) => (
                <div className="folder-manual-section">
                  <ListGroupItem
                    className="left-border list-zindex"
                    {...props}
                    style={{
                      paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
                      cursor: 'pointer',
                    }}
                    key={key}>
                    <div className="list-items-structure">
                      {hasNodes && <ToggleIcon on={isOpen} />}
                      {!hasNodes && <span style={{ marginRight: 8 }}> &nbsp;</span>}
                      {type === 'manual' &&
                        <label><input style={{marginRight:'5px',marginTop:'15px'}}
                                type="checkbox"
                                checked={(this.manuals.find((item)=>  item === id) ?true:false)}
                                onChange={(e) => this.handleCheckBox(id,type,e.target.checked,'')}
                            />
                        <i class="folder-icons folder-icons-accounts mt-3" title="Manual" style={{ marginRight: '5px',float:'right' }}> </i>
                      </label>}
                      {type === 'folder' &&
                      <label>
                        <input style={{marginRight:'5px'}}
                            type="checkbox"
                            checked={(this.folders.find((item)=>  item === id) ?true:false)}
                            onChange={(e) => this.handleCheckBox(id,type,e.target.checked,parent_id)}
                            />
                        <i class="folder-icons folder-icons-folder mt-1" title="Folder" style={{ marginRight: '5px',float:'right' }}> </i>
                      </label>}
                      <span onClick={(e) => this.labelClick(e, id)} title={label} className={'folderstructure-label-' + type} >
                        {label}
                      </span>
                    </div>
                    </ListGroupItem>
                </div>
            );
        if (this.state.tocLinkState) {
            var stagesArr = this.parentStage;
            let contents = this.state.contents;
            let treeData1 = [];
            let openIntial = [];
            let activeIntial = [];
            var count = -1;
            stagesArr.map(key => {
                var temp = Object.keys(key)[0];
                if (key[temp] === 1) {
                    openIntial.push(temp);
                    activeIntial.push(temp);
                    treeData1.push(
                        {
                            key: temp,
                            label: contents[temp]['title'],
                            nodes: [],
                            id: temp,
                            type: 'manual',
                            parent_id:''
                        }
                    );
                    count = count + 1;
                } else {
                    let str = this.findParentNode(treeData1, key[temp] - 2, count);
                    openIntial.push(str[1] + '/' + temp);
                    str[0].push(
                        {
                            key: temp,
                            label: contents[temp]['title'],
                            nodes: [],
                            id: temp,
                            type: 'folder',
                            parent_id:contents[temp]['parent_id'],
                        }
                    )
                }
                // var padding = 3 * key[temp] + '%';
                // table.push(<li><a href={'#' + temp} style={{ "padding-left": padding }}>{contents[temp]['title']}</a></li>)
            });
            return (<TreeMenu
                data={treeData1}
                hasSearch='false'
                onClickItem={({ key, label, ...props }) => {
                    this.onClickNode(key, label, props);
                }
                }
                debounceTime={125}
                activeKey={activeIntial}
                openNodes={this.getInitialKeys(openIntial)}
            >
                {({ search, items }) => (
                    <>
                        <Input style={{}} onChange={e => search(e.target.value)} placeholder={t("Type and search")} />
                        <div className="sim">
                            <ListGroup className="folder-left-list-group">
                                {items.map(props => (
                                    <ListItem {...props} />
                                ))}
                            </ListGroup>
                            <div style={{ height: '170px', visibility: 'hidden', }}></div>

                        </div>
                    </>
                )
                }
            </TreeMenu>
            );
        }
    }
    handleCheckBox(id,type,checked,parent_id){

      const {manual_folders,contents} = this.state;
      console.log(id)
      var folder =  Object.values(contents);
      var folderArray =folder.filter(selected =>(selected.type === 'folder'))
      if(type==='manual'){
            if(checked === true) {
             this.manuals.push(id);
             this.getFoldersChecked(folderArray,id,checked);
            }
           else{
            this.manuals=this.manuals.filter((key)=>{
             return  key !== id;
            })
            this.getFoldersChecked(folderArray,id,checked);
          }
      }
      else if(type === 'folder'){
          if(checked === true) {
            this.folders.push(id);
            this.getFoldersChecked(folderArray,id,checked);
          }
          else{
            this.folders=this.folders.filter((key)=>{ //-->direct folder unchecked
             return  key !== id;
            })
            // this.folders=this.folders.filter((key)=>{//-->direct parent folder unchecked
            //  return  key !== parent_id;
            // })
            this.manuals=this.manuals.filter((key)=>{//-->direct parent manual unchecked
             return  key !== parent_id;
            })
            console.log(this.folders)
            this.getFoldersChecked(folderArray,id,checked);
          }

      }
      // this.folders.push(id)
      //
      //       this.getFoldersChecked(folderArray,id,checked);
      //       console.log(id);
      //      console.log(this.folders);return;
   //   var filterArray =folder.filter(selected =>(selected.type === 'folder'))
   //   var folder1 = filterArray.filter(selected1 =>(selected1.id ===id ))
   // console.log(folder1);return;
      // if(type==='manual'){
      //   if(checked === true){
      //     this.manuals.push(id);
      //     let childrens=contents[id]['children'];
      //     for (var i = 0; i < childrens.length; i++) {
      //       this.folders.push(childrens[i]);
      //     }
      //
      //     this.folders = [...new Set(this.folders)];
      //     for (var i = 0; i < this.folders.length; i++) {
      //       Object.values(contents).map((key)=>{
      //         if(key['parent_id']=== this.folders[i]){
      //           this.folders.push(key['id']);
      //         }
      //       })
      //     }
      //     this.folders = [...new Set(this.folders)];
      //   }
      //   else {
      //     this.manuals=this.manuals.filter((key)=>{
      //      return  key !== id
      //     })
      //     this.folders=[];
      //   }
      // }
      // else if (type==='folder') {
      //   var subfolders=contents[id]['children'];
      //   if(checked === true){
      //     this.folders.push(id);
      //     for (var i = 0; i < subfolders.length; i++) {
      //       if(contents[subfolders[i]]['type'] === 'folder'){
      //         this.folders.push(subfolders[i]);
      //       }
      //     }
      //   }
      //   else{
      //     let subfolder=contents[id]['children'];
      //     let folder_details=contents[id]['parent_id'];
      //     let parent_details=contents[folder_details]['type']==='folder'?contents[folder_details]['parent_id']:0;
      //       for (var i = 0; i < subfolder.length; i++) {
      //         this.folders=this.folders.filter((key)=>{
      //          return  key !== subfolder[i]
      //         })
      //       }
      //
      //       this.manuals=this.manuals.filter((key)=>{
      //        return  key !== parent_id && key !== parent_details
      //       })
      //         this.folders=this.folders.filter((key)=>{
      //          return  key !== id
      //         })
      //   }
      //
      // }
      // console.log(this.folders);
      // console.log(this.manuals);
    }
    getFoldersChecked(folderData,Id,type) {

      Object.entries(folderData).forEach(([key, value]) => {
        if(value['parent_id'] !== undefined && value['parent_id'] ===Id ) {
         if(type === true) {
          this.folders.push(value['id']);
        }else{
          this.folders=this.folders.filter((key)=>{
           return  key !== value['id']
          })
        }
        this.getFoldersChecked(folderData,value['id'],type);

        }
      })


    //   let folder1 = folderData.filter(selected =>(selected.parent_id ===id ))
    // console.log(folder1);return;
    }
    handleTocViewService(idAsTileId) {
      this.tileId=idAsTileId;
        let data = {
          grid_type:this.state.gridId,
          grid_items_id:this.state.gridItemId ,
          tile_id:idAsTileId,
          p_id:this.state.personId
        }
        datasave.service(window.TILE_DETAILS, 'POST', data).then(result => {
            this.setState({
                columnDefs: result['columnDefs'],
                contents: result['rowData'],
                defaultColDef: result['defaultColDef'],
                grandParent: result['grandParent'],
                view: result['views'],
                width: result['widths'],
                allDataStatus: true,
                tocDetailsState: false,
                TocSelectedStandards:result['TocStandards'],
            })
            // var allData = this.getalldata();

            // this.setState({
            //     allData: allData,
            //     tocDetailsState: false,
            //     tocLinkState: true,
            // });
        });
    }
    showClosePopup (){
      this.setState({
        showToc: !this.state.showToc,
      })
      this.folders = [];
      this.manuals = [];
    }

    downloadTocPopup = ()=>{
      const {showToc } = this.state;
        return (
          <reactbootstrap.Modal
            show={showToc}
            onHide={(e)=>this.showClosePopup()}
            size="lg"
           >
            <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
              <reactbootstrap.Modal.Title>{t('Toc download')}</reactbootstrap.Modal.Title>
            </reactbootstrap.Modal.Header>
            <reactbootstrap.Modal.Body>
            <div className='row justify-content-center' >
                <div className="col-md-10">
                    <div>
                        <ul>
                            {this.tocLinkList()}
                        </ul>
                    </div>
                </div>
            </div>
            </reactbootstrap.Modal.Body>
           <reactbootstrap.Modal.Footer>
            <button type="button" class="btn btn-primary" onClick={(e)=>this.downloadToc()}>Download</button>
            </reactbootstrap.Modal.Footer>
          </reactbootstrap.Modal>
        )
    }

    downloadToc(){
      console.log(this.manual_id);
      console.log(this.state.gridId,this.state.gridItemId,this.state.personId,this.tileId);
      let data=this.manuals.concat(this.folders);
      let filterdata=[];
      for (var i = 0; i < data.length; i++) {
        Object.values(this.state.contents).map((ele)=>{
          if(ele.id === data[i]){
            //ele.type = (ele.type ==='folder')?2:1;
            filterdata.push(ele);
          }
        })
      }
      let details = {
        grid_type:this.state.gridId,
        grid_items_id:this.state.gridItemId ,
        tile_id:this.tileId,
        p_id:this.state.personId,
        manual_id:this.manual_id,
        selected:filterdata,
        toc_name:this.state.tocDetails[0]['name'],
      }
      console.log(details)
      if(filterdata.length ===0){
        OCAlert.alertWarning(('Select atleast one folder'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
      else {
        datasave.service(window.TOC_DOWNLOAD, 'POST', details).then(result => {
        console.log(result)
         if(result.status === 200) {
           console.log(result)
          var a      = document.createElement("a");
          a.setAttribute("type", "file");
          a.href     = result.url;
          a.download = result.zipFileName;
          a.target   = '_blank';
          document.body.appendChild(a);
          a.click();
          a.remove();
          this.showClosePopup();
          OCAlert.alertSuccess(('Toc downloaded successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
           }
           else {
             OCAlert.alertWarning('Not able to download', { timeOut: window.TIMEOUTNOTIFICATION });
           }
        })
      }
    }

    handleTocList() {
        let data = [];
        const {t} = this.state;
        if (this.state.tocDetailsState) {
            if (this.state.tocDetails.length > 0) {
                if (this.state.tocDetails.length > 1) {
                    this.state.tocDetails.map(key => {
                        data.push(<span><reactbootstrap.Button id={key['id']} onClick={() => this.handleOnClick(key['id'])}>{key['name']}</reactbootstrap.Button></span>);
                    })
                } else {
                    this.handleTocViewService(this.state.tocDetails[0]['id']);
                }
            } else {
                this.setState({
                    allData: [<div>{t('No Data')}</div>],
                    tocDetailsState: false,
                    tocLinkState: true,
                })
            }
        }
        return data;
    }


    render() {
      const showDownloadOptiom = (this.state.tocDetails.length > 0 && this.state.allData.length > 0 ) ?
                                 true : false;
        const {t,showClosePopup} = this.state;

        if (this.state.status) {
            return (
                <div className='container py-4' style={{maxWidth: '1240px'}} >
                {showDownloadOptiom &&
                    <div style={{position:"sticky",top:"0px"}}>
                       <a onClick={this.sendHTMLToBackend} style={{color:'red',float:'right', cursor:'pointer'}}>{t("Download as PDF")}</a>
                    </div>}
                {showDownloadOptiom && parseInt(localStorage.getItem("toc_download")) ===1 &&
                      <div style={{position:"sticky",top:'0px'}}>
                         <a onClick={(e)=>this.showClosePopup()} style={{color:'red',float:'right', cursor:'pointer',marginRight:'15px'}}>{t("TOC download")}</a>
                         {this.state.showToc ===true && this.downloadTocPopup()}
                      </div>}
                    <div style={{}} className="tableofcontent-toc-list">
                        {this.handleTocList()}
                    </div>
                    <div className='row justify-content-center' >
                        <div className="col-md-4">
                            <div>
                                <ul>
                                    {this.tablesLinkList()}
                                </ul>
                            </div>
                        </div>
                        <div style={{ height: '500px', overflowY: 'auto' }} className="col-md-8" >
                            <div id="tableOfContent">
                                {this.state.allData}
                                {this.getalldata()}
                                {/* {this.handleTocViewService()} */}
                            </div>

                        </div>
                    </div>
                </div >
            );
        } else {
            return <div>
                <h1>{t('.......loading')}</h1>
            </div>
        }
    }


    componentDidMount() {
        datasave.service(window.GET_TOC + '/' + this.state.tileId, 'GET', '').then(result => {
            this.setState({
                status: true,
                tocDetails: result,
                tocDetailsState: true
            })
        });
    }
}

export default translate(TableContent);
