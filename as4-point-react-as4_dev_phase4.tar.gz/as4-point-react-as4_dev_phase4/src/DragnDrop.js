import React, { Component } from 'react'
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd'
import * as reactbootstarp from 'react-bootstrap'
import SearchInput, { createFilter } from 'react-search-input'
import { datasave } from './_services/db_services';
import CheckBox from './CheckBox';
import TextField from '../src/_components/TextField'
import PersonImg from './images/personc.png';
import TaskPopUp from '../src/TaskPopUp.js'
import JobImg from './images/jobc.png';
import DepartmentImg from './images/departmentsc.png';
import GroupImg from './images/groupc.png';
import DeleteImg from './images/delete1.png';
import approvalsearch from './images/approval-search.png';
import './DragnDrop.css';
import wname from './wname.png';
import wview from './wview.png';
import wverify from './wverify.png';
import wabbrv from './abrv-w.png';
// import wselectall from '../src/selectall-w.png';
import wselectall from './selectall-w.png';
import wremove from './wremove.png';
import wedit from './wedit.svg';
import winitiate from './winitiate.png';
import wcrud from './wcrud.png';
import wauthorise from './wauthorise.png';
import $ from 'jquery';
import { translate } from './language';


/**
 * Moves an item from one list to another list.
 */
const move = (source, destination, droppableSource, droppableDestination, draggableId) => {

    const sourceClone = Array.from(source);
    const destClone = Array.from(destination);
    const [removed] = sourceClone.filter(items => items.id === draggableId);
    destClone.splice(droppableDestination.index, 0, removed);
    const result = {};
    result[droppableSource.droppableId] = sourceClone.filter(items => items.id !== draggableId);
    result[droppableDestination.droppableId] = destClone;
    result['latestDropped'] = removed;
    result['type'] = (droppableDestination.droppableId === 'droppable') ? 'remove' : 'add';
    return result;
};
const grid = 8;
/*const getItemStyle = (isDragging, draggableStyle) => ({
    // some basic styles to make the items look a bit nicer
    userSelect: 'none',
    padding: grid * 2,
    margin: `0 0 ${grid}px 0`,

    // change background colour if dragging
    background: isDragging ? 'lightgreen' : 'grey',

    // styles we need to apply on draggables
    ...draggableStyle
});*/

const getListStyle = isDraggingOver => ({
    background: isDraggingOver ? 'lightblue' : '#fff',
    padding: grid,
    //  width: '62%',
});

const getFlexStyle = ({
    display: 'flex',
    backgroundColor: '#fff',
});

const imageStyle = ({
    width: 20,
    cursor: "default",
});
const TextCurser = ({
    cursor: "default",
});

const textinline = ({
    display: '-webkit-inline-flex',
});

const checkApproval = ({

    width: 18,
    padding: 5,
    borderColor: '#EC661C',
    borderWidth: 1,
    height: 18

});
const checkApprovalChecked = ({
    backgroundColor: '#EC661C',
    backgroundImage: 'url("./images/tick.png")',
    backgroundRepeat: 'no-repeat',
    backgroundOrigin: 'content-box'
});
/*const tooltipStyle = ({
    height: 150,
    width: 200,
    overflow: 'auto'
});*/

class DragnDrop extends Component {

    constructor(props) {

        super(props);
        this.searchUpdated = this.searchUpdated.bind(this)

        this.state = {
            KEYS_TO_FILTERS: window.search_fields,
            items: [],
            selected: [],
            types: [],
            searchData: [],
            searchTerm: [],
            searchType: '',
            result_obj:[],
            type: '',
            html: window.HTML_OBJECT,
            html_right: window.HTML_RIGHT,
            updated: 1,
            persons: [],
            curently_hovered_item: [],
            show: false,
            showPopup :false,
            isTooltipActive: false,
            parent: "tooltip",
            t:props.t
        }
        this.handleCheck = this.handleCheck.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleChangeOrder = this.handleChangeOrder.bind(this);
        this.handleClicktr = this.handleClicktr.bind(this);
        this.handlePersons = this.handlePersons.bind(this);
        this.handleClicktrTask = this.handleClicktrTask.bind(this);
        // this.showTooltip = this.showTooltip.bind(this);
        // this.hideTooltip = this.hideTooltip.bind(this);


    }

    handleClicktr(resultObj) {
       let allowOrNot = (this.props.details.doc_status_id === 22 && resultObj.category === 'spaces') ? (this.props.details.diable_ExpirationPeriod) : (this.props.details.disableFields || this.props.disable_based_on_right||this.props.approvalcycle_disabled||this.props.extra_tab_disabled||this.props.default_tab_disabled);
        if (allowOrNot) {
            return;
        }
        // if (this.props.details.disableFields ||this.props.details.exp_his_disabled|| this.props.disable_based_on_right || this.props.approvalcycle_disabled || this.props.extra_tab_disabled||this.props.default_tab_disabled) {
        //     return;
        // }
        // if(this.props.remove_type === true){
        //   this.setState({
        //     showPopup :true,
        //   })
        // }
        var selected = this.state.selected;
        var remove = selected.filter(item => (item.name !== resultObj.name && item.id !== resultObj.id));
        const result = {};
        result['latestDropped'] = resultObj;
        result['type'] = 'remove';
        this.setState(prevState => ({
            items: [...prevState.items, resultObj],
            selected: remove,
        }), () => {
            this.props.updateSelectedChild(result.latestDropped, result, this.props.tab, this.props.notify_id);
        });
    }
    handleClicktrTask(resultObj,task_status = 0,show_comment = true) {
         let allowOrNot = (this.props.details.doc_status_id === 22 && resultObj.category === 'spaces') ? (this.props.details.diable_ExpirationPeriod) : (this.props.details.disableFields || this.props.disable_based_on_right||this.props.approvalcycle_disabled||this.props.extra_tab_disabled||this.props.default_tab_disabled);
         if (allowOrNot) {
             return;
         }
        // if (this.props.details.disableFields ||this.props.details.exp_his_disabled|| this.props.
        //  || this.props.approvalcycle_disabled || this.props.extra_tab_disabled||this.props.default_tab_disabled) {
        //     return;
        // }
        //if(this.props.details.action === 'edit'){
        if(this.props.remove_type === true && this.props.details.action === 'edit'){
          if(task_status == 0){
          this.setState({
            showPopup :show_comment,
            result_obj:resultObj,
          })
        }
        else{
          this.setState({
            showPopup :show_comment,
            result_obj:resultObj,

          })
          this.handleClicktr(resultObj);
        }
        }
        else{
          this.handleClicktr(resultObj);
        }

    }


    async componentDidMount() {

        if (this.props.items !== undefined) {
            this.setState({

                types: this.props.types,
                items: this.props.items,
                selected: this.props.selected,
                type: this.props.type,
            });
        }

    }

    updateSelectAll() {
      $('tr').find('#verify').each(function(){
        $(this).appendTo($(this).parent().find('#9'));
        // $(this).parent().parent().find('#verify').remove();
      })
      $('tr').find('#authorise').each(function(){
        $(this).appendTo($(this).parent().find('#10'));
        // $(this).parent().parent().find('#authorise').remove();
      })
    }

    /**
     * A semi-generic way to handle multiple lists. Matches
     * the IDs of the droppable container to the names of the
     * source arrays stored in the state.
     */
    id2List = {
        droppable: 'items',
        droppable2: 'selected'
    };

    handleDragSelectedChange = (result) => {
        this.setState({
            items: result.droppable,
            selected: result.droppable2
        }, () => {

            this.props.updateSelectedChild(result.latestDropped, result, this.props.tab, this.props.notify_id);
        });
    }
    getList = id => this.state[this.id2List[id]];

    onDragEnd = resultObj => {
        const { source, destination, draggableId } = resultObj;
        // dropped outside the list
        if (!destination) {
            return;
        }
        if (source.droppableId === destination.droppableId) {
            return;
            /*const items = reorder(
                this.getList(source.droppableId),
                source.index,
                destination.index
            );

            let state = { items };

            if (source.droppableId === 'droppable2') {
                state = { selected: items };
            }

            this.setState(state);*/
        } else {
            const result = move(
                this.getList(source.droppableId),
                this.getList(destination.droppableId),
                source,
                destination,
                draggableId
            );
            this.handleDragSelectedChange(result);
        }
    };
    searchUpdated(term, itemlist) {
        const items = { ...this.state.searchTerm };
        items[itemlist] = term;
        this.setState({
            searchTerm: items,
            searchType: itemlist,
        })
    }
    handleCheck = (id, checked, category) => {
       if(id == 0){
        this.handleSelectCheckAll(id, checked, "checkboxes", "checked", category, "flag")
        this.handleSelectTextAll(id, checked, "textfield", "order", category, "flag")
        this.handleSelectTextAll(id, checked, "textfield", "count", category, "flag")
          this.handleSelectTextHideAll("7", checked, "textfield", "count", category, "flag")
          this.handleSelectTextHideAll("8", checked, "textfield", "count", category, "flag")

      }else {
        this.handleUpdateState(id, checked, "checkboxes", "checked", category, "flag")
      }
      if(id == 9){

        this.handleSelectTextHideAll("7", checked, "textfield", "count", category, "flag")
      }
      if(id == 10){

        this.handleSelectTextHideAll("8", checked, "textfield", "count", category, "flag")
      }
      // else{
      //    this.handleSelectTextHideAll(id, checked, "checkboxes", "checked", category, "flag")
      // }
    }
    handleSelectTextHideAll(id, value, type, action, pid, flag) {
      let selected = this.state.selected;
      this.state.selected.map(functions => {
          Object.values(functions[type]).map(function (item, index) {
              if (item.id === id && functions.id === pid) {
                  item[action] = 1;
                  item[flag] = 1;
                  item.show=!value;
                  return;
              }
          })
      });
      this.setState({
          selected: selected,
      }, () => {
          this.props.updateSelectedRights(this.state.selected);

      })
        // let selected = this.state.selected;
        // this.state.selected.map(functions => {
        //     Object.values(functions[type]).map(function (item, index) {
        //         if (value  && functions.id === pid) {
        //             item[action] = 1;
        //             item[flag] = 1;
        //             return;
        //         }
        //         else if(functions.id === pid){
        //           item[action] = 0;
        //           item[flag] = 0;
        //           return;
        //         }
        //     })
        // });
        // this.setState({
        //     selected: selected,
        // }, () => {
        //     this.props.updateSelectedRights(this.state.selected);
        //
        // })

    }
    handleSelectTextAll(id, value, type, action, pid, flag) {
        let selected = this.state.selected;
        this.state.selected.map(functions => {
            Object.values(functions[type]).map(function (item, index) {
                if (value  && functions.id === pid) {
                    item[action] = 1;
                    item[flag] = 1;
                    return;
                }
                else if(functions.id === pid){
                  item[action] = 0;
                  item[flag] = 0;
                  return;
                }
            })
        });
        this.setState({
            selected: selected,
        }, () => {
            this.props.updateSelectedRights(this.state.selected);

        })

    }
    handleSelectCheckAll(id, value, type, action, pid, flag) {
        let selected = this.state.selected;
        this.state.selected.map(functions => {
            Object.values(functions[type]).map(function (item, index) {
                if (value && functions.id === pid) {
                    item[action] = value;
                    item[flag] = 1;
                    return;
                }
                else if(functions.id === pid){
                  item[action] = value;
                  item[flag] = 0;
                  return;
                }
            })
        });
        this.setState({
            selected: selected,
        }, () => {
            this.props.updateSelectedRights(this.state.selected);

        })

    }
    handleUpdateState(id, value, type, action, pid, flag) {
        let selected = this.state.selected;
        this.state.selected.map(functions => {
            Object.values(functions[type]).map(function (item, index) {
                if (item.id === id && functions.id === pid) {
                    item[action] = value;
                    item[flag] = 1;
                    return;
                }
            })
        });
        this.setState({
            selected: selected,
        }, () => {
            this.props.updateSelectedRights(this.state.selected);

        })
    }
    handleChange(id, value, type_id, type) {
        const re = /^(?:[0-9]*)$/;
        if (value === '' || re.test(value)) {

            this.handleUpdateState(id, value, "textfield", type, type_id, "flag");
        }

    }
    handleChangeOrder(id, value, type_id, type) {
        const re = /^(?:[0-9])$/;
        if (value === '' || re.test(value)) {
            this.handleUpdateState(id, value, "textfield", type, type_id, "flag");
        }
        // else{
        //     this.handleUpdateState(id, 1, "textfield", type, type_id, "flag");
        // }
    }
    handlePersons(item) {

    //  if (!this.props.details.disableFields || this.props.details.disableFields === undefined) {
        let callbackend = true;
          if ((item.category_id !== undefined && item.category_id !== window.PERSON_ENTITY) || parseInt(item.entity_type_id) !== window.PERSON_ENTITY) {
              this.setState({ show: true });
              if (this.state.persons[item.id]) {
                  this.setState({
                      curently_hovered_item: this.state.persons[item.id]
                  })
              }
              else {
                  const loaded_persons = this.state.persons;
                  var url = '';
                  let entity_type_id = '';
                  if (parseInt(item.category_id) === parseInt(window.SPACES_ENTITY) || item.category === "spaces") {
                     url = window.GET_SPACE_PERSONS + '/' + item.id
                  } else if (parseInt(item.category_id) === parseInt(window.ROLE_ENTITY) || item.category === "roles") {
                      if (item.abbrevation === "user roles") {
                        url = window.GET_ROLEPERSONS + '/' + item.id
                      } else {
                        callbackend = false
                        let persons_of_VCIVA = []
                        switch (item.abbrevation) {
                          case "view":
                            persons_of_VCIVA = this.props.credentials.access_details[1] ? this.props.credentials.access_details[1] : [];
                            break;
                          case "CRUD people" :
                            persons_of_VCIVA = this.props.credentials.access_details[2] ? this.props.credentials.access_details[2] : [];
                            break;
                          case "initiater":
                            persons_of_VCIVA = this.props.credentials.access_details[6] ? this.props.credentials.access_details[6] : [];
                            break;
                          case "verifyer":
                            persons_of_VCIVA = this.props.credentials.access_details[7] ? this.props.credentials.access_details[7] : [];
                            break;
                          case "authoriser":
                            persons_of_VCIVA = this.props.credentials.access_details[8] ? this.props.credentials.access_details[8] : [];
                            break;
                          default:
                            persons_of_VCIVA = []
                        }
                        let personsOfVCIVA = []
                        let personsWithoutDuplicates = []
                        persons_of_VCIVA.filter(item => {
                            if (!personsOfVCIVA.includes(item.name)) {
                              personsOfVCIVA.push(item.name)
                              personsWithoutDuplicates.push(item)
                            }
                          })
                        this.setState({
                            persons: personsWithoutDuplicates,
                            curently_hovered_item: personsWithoutDuplicates
                        })

                      }
                  } else {
                     entity_type_id = item.entity_type_id;
                     url = window.GetAllLinkedPersons + '/' + item.id + '/' + entity_type_id
                  }

                  if (callbackend) {
                    datasave.service(url, "GET", '')
                        .then(result => {
                            const all_persons = {
                                ...loaded_persons,
                                ...result
                            }
                            this.setState({
                                persons: all_persons,
                                curently_hovered_item: result[item.id]
                            })
                        })
                        .catch(error => {

                        })
                  }

              }
          }

      //}

    }
    handleHide = () => {
        this.setState({ show: false });
    }
    componentDidUpdate(prevProps, prevState) {

        if (prevState.items !== this.props.tasks) {
            this.setState({
                items: this.props.tasks,
            })
        }
    }

    /*hideTooltip() {
        this.setState({isTooltipActive: false})
    }

    showTooltip() {
        this.setState({isTooltipActive: true})
    }*/


    // Normally you would want to split things out into separate components.
    // But in this example everything is just done in one place for simplicity
    render() {
      const {t} = this.state;
      const showPopup = this.state.showpopup;
        /*const popover = (
            <reactbootstarp.Popover style={tooltipStyle} id="popover-basic" title="Persons">
                <ul>
                    {this.state.curently_hovered_item.map(person =>
                        <li>{person.name}</li>
                    )}
                </ul>
            </reactbootstarp.Popover>
        );*/
        this.updateSelectAll();
        const popupContent = (
            <reactbootstarp.Modal
                show={this.state.show}
                onHide={this.handleHide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title"
            >
                <reactbootstarp.Modal.Header closeButton>
                    <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
                        {t("Persons")}
                </reactbootstarp.Modal.Title>
                    <reactbootstarp.Modal.Body>
                        <ul>
                            {this.state.curently_hovered_item.length != 0 &&
                                this.state.curently_hovered_item.map(person =>
                                    <li>{person.name}</li>
                                )
                            }
                            {this.state.curently_hovered_item.length === 0 &&
                                t('No persons are linked')
                            }
                        </ul>
                    </reactbootstarp.Modal.Body>
                </reactbootstarp.Modal.Header>
            </reactbootstarp.Modal>
        );
        if (this.props.types !== undefined && this.state.items !== undefined) {
            // const type = this.props.type;
            const types = this.props.types;
            // if ((this.props.tasks !== undefined && this.props.tasks.length > 0) && this.state.items.length === 0) {
            //     this.setState({
            //         items: this.props.tasks
            //     });
            // }
           this.state.selected = this.props.selected;
            if (this.props.selected !== undefined && this.props.selected.length === 0 && this.props.updateProps === 1 && this.state.updated > 0) {
                this.setState({
                    selected: this.props.selected,
                    updated: 0,
                });
            }
            else if (this.props.selected !== undefined && this.props.selected.length > 0 && this.props.updateProps === 1 && this.state.selected.length === 0) {
                this.setState({
                    selected: this.props.selected,
                    updated: 2,
                });
            }
            var filteredNames = [];
            var dragObject = <reactbootstarp.Tabs activeKey={this.props.activeKey} onSelect={this.props.onSelect} id="controlled-tab-example">
                {Object.values(types).map(
                    function (itemlist, key) {
                        var search = '';
                        if (this.state.searchTerm && this.state.searchType) {
                            search = this.state.searchTerm[itemlist];
                            search = (search !== undefined) ? search : '';
                        }
                        filteredNames[itemlist] = this.state.items.filter(createFilter(search, this.state.KEYS_TO_FILTERS));
                        return (

                            <reactbootstarp.Tab className="input-right-field" id="dashdragndrop" eventKey={itemlist} title={t(itemlist.charAt(0).toUpperCase() + itemlist.slice(1))}>
                                <reactbootstarp.Table  responsive striped hover >

                                    <thead style={{position: 'sticky',top: '0',backgroundColor: '#fff'}}>
                                        <tr>
                                            <td style={{ padding: '0.25rem' }} colSpan="3" >
                                                <SearchInput style={{ colour: 'red', border: '0px', color: '#EC661C', fontSize: '13px', }} className="search-input approval-input" onChange={(e) => this.searchUpdated(e, itemlist)} />
                                                {/* <img style={{width: '17px', height: '17px'}} src={approvalsearch}></img> */}
                                            </td>
                                        </tr>
                                        <tr>
                                            {this.state.html_right[0][itemlist].map(rights =>
                                                <th style={{ backgroundColor: '#EC661C', fontSize: '14px', color: '#fff', padding: '0.25rem' }} title={rights.name}>{rights.name}</th>
                                            )}
                                        </tr>
                                    </thead>
                                    <tbody style={{ backgroundColor: '#fff', border: '0px' }}>
                                        {/* <div> */}
                                        {Object.values(filteredNames[itemlist]).map(
                                            function (item, index) {
                                                item.category_id = (item.entity_type_id !== undefined) ? item.entity_type_id : item.category_id;
                                                if (item !== undefined && item.id !== undefined && item.category === itemlist) {
                                                    return (
                                                        <Draggable className="right-field-border"
                                                            isDragDisabled={ (this.props.details.doc_status_id === 22 && item.category === 'spaces') ? (this.props.details.diable_ExpirationPeriod) : (this.props.details.disableFields ||this.props.details.exp_his_disabled|| this.props.disable_based_on_right||this.props.approvalcycle_disabled||this.props.extra_tab_disabled||this.props.default_tab_disabled)}
                                                            key={item.id}
                                                            draggableId={item.id}
                                                            type={item.category}
                                                            index={index}>
                                                            {(provided, snapshot) => (
                                                                <tr style={{}}
                                                                    ref={provided.innerRef}
                                                                    {...provided.draggableProps}
                                                                    {...provided.dragHandleProps}
                                                                >
                                                                    {/* <td className="borderrr" style={{ backgroundColor: '#fff', }}> */}
                                                                    <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6'}}>
                                                                        <div style={textinline} onClick={(e) => this.handlePersons(item)}>
                                                                            {/* <div className="dropdown-user-sec"> */}
                                                                            <span className="">
                                                                                {/* <p onClick={(e) => this.handlePersons(item)}> */}
                                                                                {item.category != 'spaces' &&
                                                                                    <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                                                                }
                                                                                &nbsp;
                                                                                {/* </p> */}
                                                                            </span>
                                                                            &nbsp;
                                                                            {/* <div> */}
                                                                                <span style={{wordBreak: 'break-word'}}>
                                                                                {item.name}
                                                                                </span>
                                                                            {/* </div> */}
                                                                        </div>
                                                                        {popupContent}
                                                                        {/* { item.category != 'spaces' &&
                                                                            <img style = {imageStyle} src={ item.category === 'persons' ? PersonImg : (item.category ==='jobs'? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" onClick={(e) => this.handlePersons(item)} />
                                                                        }
                                                                        {popupContent}
                                                                        &nbsp; &nbsp;
                                                                        {item.name} */}
                                                                    </td>
                                                                    {/* <td> */}
                                                                    {item.category != 'persons' &&
                                                                        // <td style={{ backgroundColor: '#fff', fontSize: '13px' }}>
                                                                        <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6', textAlign:'center',wordBreak: 'break-word'}}>
                                                                            {item.abbrevation}
                                                                        </td>
                                                                    }
                                                                    {/* </td> */}
                                                                </tr>
                                                            )}
                                                        </Draggable>
                                                    )
                                                }
                                            }, this)}
                                            {/* </div> */}
                                    </tbody>
                                </reactbootstarp.Table>
                            </reactbootstarp.Tab>
                        )
                    }, this)}
            </reactbootstarp.Tabs>
        }
        return (
            <div className="col-md-12 p-0" style={getFlexStyle}>
              <DragDropContext onDragEnd={this.onDragEnd}>
                <Droppable droppableId="droppable2">
                  {(provided, snapshot) => (
                    // <div className="selected-item-header-section col-md-6"
                      <div className="selected-item-header-section"
                        //   style={{width: '65% !important', overflowX: 'auto'}}
                        ref={provided.innerRef}
                        style={getListStyle(snapshot.isDraggingOver)}>
                        <p>{t("Selected items")}</p>
                        {this.state.showPopup && <TaskPopUp
                          title = {t('Reason of change')}
                          current_status = {'Save'}
                          result_obj = {this.state.result_obj}
                          task_id = {this.props.details.task_id}
                          handleClicktrTask = {this.handleClicktrTask}
                                                 />}
                        <div className='border-remove' style={{ width: '100%', overflowX: 'auto',  }}>
                          <reactbootstarp.Table style={{ width: '100%', overflowX: 'auto', margin: '0' }} striped responsive bordered hover variant="dark">
                            <thead  style={{ backgroundColor: '#EC661C',position: 'sticky',top: '0' }}>
                              <tr >
                                { this.state.html[0][this.props.type] !== undefined &&
                                  this.state.html[0][this.props.type].map(commons =>
                                    <th style={{ paddingTop: '20px', border: '0px', }} className={commons.class} title={t(commons.name)}></th>
                                  )}
                              </tr>
                            </thead>

                            <tbody >
                              {this.state.selected !== undefined && this.state.selected.map(
                                function (item, index) {
                                  if (this.props.type === "common") {
                                    return (
                                      <tr style={{ backgroundColor: '#fff', border: '0px' }}>
                                        <td style={{ backgroundColor: '#fff', color: '#212529', border: '1px solid #fff', fontSize: '14px', padding: '0px', verticalAlign: 'middle',width: '5rem' }}>
                                          <div style={textinline} onClick={(e) => this.handlePersons(item)}>
                                            <div >
                                              {/* <p onClick={(e) => this.handlePersons(item)}> */}
                                              {item.category !== 'spaces' &&
                                                <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                              }
                                              {/* </p> */}
                                            </div>
                                            &nbsp;
                                            <span style={{cursor: 'default', wordBreak: 'break-word',width: '5rem'}}>
                                              {item.name}
                                            </span>
                                          </div>
                                          {popupContent}
                                          {/* { item.category != 'spaces' &&
                                            <img style = {imageStyle} src={ item.category === 'persons' ? PersonImg : (item.category ==='jobs'? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" onClick={(e) => this.handlePersons(item)} />
                                            }
                                            {popupContent}
                                            &nbsp; &nbsp;
                                          {item.name} */}
                                        </td>
                                        <td style={{textAlign: 'center'}} className="dpt-abrivation">
                                          <span style= {{cursor: 'default', color: '#212529',wordBreak: 'break-word'}}> {item.abbrevation}</span>
                                        </td>
                                        <td className = 'remove' style={{ verticalAlign: 'middle', textAlign: 'center' }}
                                          disabled={this.props.details.disableFields || this.props.disable_based_on_right||this.props.approvalcycle_disabled||this.props.extra_tab_disabled||this.props.default_tab_disabled}>
                                          {this.props.remove_type === undefined && <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => this.handleClicktr(item)}></img>}
                                          {this.props.remove_type === true && <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => this.handleClicktrTask(item)}></img>}
                                        </td>
                                      </tr>
                                    )
                                  }
                                  else if (this.props.type == 'rights') {
                                    return (
                                      <tr style={{ backgroundColor: '#fff', border: '0px' }}>
                                        <td style={{ backgroundColor: '#fff', color: '#212529', border: '1px solid #fff', fontSize: '14px', padding: '0px', verticalAlign: 'middle' }}>
                                          <div style={textinline} onClick={(e) => this.handlePersons(item)}>
                                            <div>
                                              {/* <p onClick={(e) => this.handlePersons(item)}> */}
                                              {item.category !== 'spaces' &&
                                                <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                              }
                                              {/* </p> */}
                                            </div>
                                            &nbsp;
                                            <div style={TextCurser}>
                                              {item.name}
                                            </div>
                                          </div>
                                          {popupContent}
                                          {/* { item.category !='spaces' &&
                                            <img style = {imageStyle} src={ item.category === 'persons' ? PersonImg : (item.category ==='jobs'? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" onClick={(e) => this.handlePersons(item)} />
                                            }
                                            {popupContent}
                                            &nbsp; &nbsp;
                                          {item.name} */}
                                        </td>
                                        {item.checkboxes.map(function (check) {
                                                                    return (
                                                                        <td id = {check.id} style={{ verticalAlign: 'middle' }}>

                                                                            {/* <div>
                                                                        <input type="checkbox" style={checkApproval} />
                                                                        <div className="check-approval">
                                                                           <div class="inside"></div>
                                                                        </div>
                                                                        </div> */}
                                                                            <CheckBox
                                                                                key={check.id}
                                                                                name={''}
                                                                                value={check.id}
                                                                                tick={check.checked}
                                                                                category={item.category}
                                                                                classification={check.name}
                                                                                approvalcycle_disabled = {this.props.details.approvalcycle_disabled}
                                                                                onCheck={(e) => this.handleCheck(check.id, e.target.checked, item.id)}
                                                                                keyvalue={check.id}
                                                                                disabled = {this.props.details.disableFields || this.props.details.exp_his_disabled || this.props.disable_based_on_right}
                                                                            />
                                                                        </td>
                                                                    )
                                                                }, this)}
                                                                {item.textfield.map(function (text) {
                                                                    return (
                                                                        <td id={text.name}>
                                                                            <TextField
                                                                                name={text}
                                                                                order={text.order}
                                                                                count={text.count}
                                                                                category={item.category}
                                                                                show = {text.show}
                                                                                handleChange={(e) => this.handleChange(text.id, e.target.value, item.id, "count")}
                                                                                handleChangeOrder={(e) => this.handleChangeOrder(text.id, e.target.value, item.id, "order")}
                                                                                approvalcycle_disabled = {this.props.details.approvalcycle_disabled}
                                                                                disabled = {this.props.details.disableFields || this.props.details.exp_his_disabled || this.props.disable_based_on_right}
                                                                            />
                                                                        </td>
                                                                    )
                                                                }, this)}
                                                                <td className = 'remove' style={{ verticalAlign: 'middle' }}>
                                                                    <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => this.handleClicktr(item)}></img>
                                                                </td>
                                                            </tr>
                                                        )
                                                    }
                                                }, this)}
                                            {provided.placeholder}
                                        </tbody>

                                    </reactbootstarp.Table>
                                </div>
                            </div>
                        )}
                    </Droppable>
                    <Droppable droppableId="droppable">
                        {(provided, snapshot) => (
                            // <div className="avialble-filed-person col-md-6"
                            <div className="avialble-filed-person "
                                //  style={{width: '65% !important'}}
                                ref={provided.innerRef}
                                style={getListStyle(snapshot.isDraggingOver)}
                            >
                                <p>{t("Available items")}</p>
                                {provided.placeholder}
                                {dragObject}
                            </div>
                        )}
                    </Droppable>
                </DragDropContext>
            </div>
        );
    }
}
export default translate(DragnDrop);
