import React, { Component } from 'react';
import { datasave } from '../_services/db_services';
import { translate } from '../language';

class ShowStatus extends Component {
    constructor(props) {
        super(props)
        this.state = {
            todos: [],
            fin_todos: [],
            unfin_todos: [],
            cur_date: '',
            open: true,
            passed: true,
            t:props.t,
        }
    }
    componentDidMount() {
        datasave.service(window.GET_TODOS, 'GET')
            .then(result => {
                if (result != undefined) {
                    this.setState({
                        todos: result,
                        fin_todos: result['finished'],
                        unfin_todos: result['unfinished'],
                    })
                }
            });
    }
    current_date() {
        var date = new Date().getDate();
        var month = new Date().getMonth() + 1;
        var year = new Date().getFullYear();
        var cur_date = year + '-' + month + '-' + date;
        return cur_date;
    }
    getOpenDays(due_date) {
        if (this.state.open == true) {
            var moment = require("moment");
            let startDate = moment(due_date, 'YYYY-MM-DD HH:mm:ss');
            let endDate = moment(this.current_date(), 'YYYY-MM-DD HH:mm:ss');
            let sd = startDate.date();
            let sm = startDate.month() + 1;
            let sy = startDate.year();
            let sDate = sy + '-' + sm + '-' + sd;
            let startDat = moment(sDate, 'YYYY-MM-DD HH:mm:ss');
            if (startDate != '') {
                var start_date = moment(startDat, 'YYYY-MM-DD HH:mm:ss');
                var end_date = moment(endDate, 'YYYY-MM-DD HH:mm:ss');
                var duration = moment.duration(end_date.diff(start_date));
                var open_days = duration.asDays();
                return open_days;
            }
            this.setState({
                open: false,
            })
        }
    }
    getPassedDays(due_date) {
        if (this.state.passed == true) {
            var moment = require("moment");
            let startDate = moment(this.current_date(), 'YYYY-MM-DD HH:mm:ss');
            let endDate = moment(due_date, 'YYYY-MM-DD HH:mm:ss');
            if (startDate != '') {
                var start_date = moment(startDate, 'YYYY-MM-DD');
                var end_date = moment(endDate, 'YYYY-MM-DD');
                var duration = moment.duration(startDate.diff(endDate));
                var passed_days = duration.asDays();
                if (passed_days >= 1) {
                    return passed_days;
                }
                else {
                    return 0;
                }
            }
            this.setState({
                passed: false,
            })
        }
    }
    recievedDate(date) {
        var moment = require("moment");
        let startDate = moment(date, 'YYYY-MM-DD HH:mm:ss');
        let sd = startDate.date();
        let sm = startDate.month() + 1;
        let sy = startDate.year();
        let sDate = sd + '-' + sm + '-' + sy;
        return sDate;
    }
    getFundamental(fun) {
      const {t} = this.state;
        if (fun == 1) {
            return t('yes');
        }
        else {
            return t('no');
        }
    }
    showTodos() {
        let temp = [];
        const {t} = this.state;
        if (this.state.todos != '') {
            temp = this.state.unfin_todos.map((todo) => {
                return (
                    <ul style={{ border: '1px solid black' }}>
                        <li style={{ listStyle: 'none' }}>
                            <table>
                                <tbody>
                                    <tr>
                                        <td>{todo.status} - {todo.pname} - {t('Recieved on:')}'{this.recievedDate(todo.received_on)}</td>
                                    </tr>
                                    <tr>
                                        <td>{todo.dcode} - {todo.dname} - {todo.dversion} - {todo.fcode} - {todo.fname} - {todo.mname}</td>
                                    </tr>
                                    <tr>
                                        <td>{t('fundamental:')}{this.getFundamental(todo.fundamental)}</td>
                                    </tr>
                                    <tr>
                                        <td>{t('Due date:')}{this.recievedDate(todo.due_date)} - {this.getOpenDays(todo.received_on)} days open - {this.getPassedDays(todo.due_date)} days passed</td>
                                    </tr>
                                    <tr>
                                        <td>{t('To review date:')}{this.recievedDate(todo.review_date)}</td>
                                    </tr>
                                    <tr>
                                        <td>{t('Comments:')}{todo.comment}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </li>
                    </ul>
                )
            })
            return temp;
        }
    }
    render() {

        return (
            <div className="container-fluid">
                <div className='container py-4' >
                    <div className='row justify-content-center' >
                        <div className='col-md-3' >
                        </div>
                        <div className='col-md-9'>
                            {this.showTodos()}
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default translate(ShowStatus);
