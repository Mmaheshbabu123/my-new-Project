import React, {useState, useMemo} from 'react'
import * as reactbootstrap from "react-bootstrap";
import { SketchPicker } from 'react-color';
import { reducers } from './GroundPlan/Building/Reducers/reducers';
// import logo_as4 from './images/normecfoodcarelogo.png'; //NO SONAR

const LoginScreenLayout = (props) => {
  const t = props.t;
  const propsData = props ?.data ?? {};
  const {color, main_text, sub_text, login_logo, logo_width, logo_height} = propsData;
  const [state, setState] = useState({
      formatWarning : false
    , uploadMessage : false
    , popUpShow     : false
    , sizeWarning   : false
    , loading       : false
    , spanStyle     : {display:'inline-block', marginRight: '10px'},
  });

  const assignStateValue = (key, value, type = 0) => {
    setState({...state, [key]: value})
  }

  const handleFileChanges = async (e, type, url = '') => {
    if(type === 'upload'){
      let response = await reducers.uploadImage(e);
      if(response.status === 200){
        props.setStateDesignObject({ login_logo : response.data.filepath});
          setState({...state, formatWarning : false, sizeWarning : false, uploadMessage : true })
      } else{
        setState({...state, formatWarning : response.formatWarning, sizeWarning   : response.sizeWarning, uploadMessage:false })
      }
    } else if (type === 'download') {
         reducers.downloadImage(url, login_logo);
    } else if (login_logo) {
      props.setStateDesignObject({ login_logo: 'Choose file'});
    }
  }

  const showPopup = () => {
      const {popUpShow } = state;
      return (<reactbootstrap.Modal show={popUpShow} onHide = {() => assignStateValue('popUpShow', false, 1)} >
           <reactbootstrap.Modal.Header closeButton>
           <reactbootstrap.Modal.Body>
             <SketchPicker className="login-screen-colorpicker" color={color} onChangeComplete={(e) => props.setStateDesignObject({color: e.hex})} />
          </reactbootstrap.Modal.Body>
          </reactbootstrap.Modal.Header>
      </reactbootstrap.Modal>
      );
  }

  return(
    <div className="col-md-12">
    <reactbootstrap.Form className="col-md-12">
        <reactbootstrap.FormGroup controlId="maintext">
            <div className=" input-overall-sec ">
                <reactbootstrap.InputGroup className="">
                    <div className="col-md-4 p-0">
                        <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Main text:')}</reactbootstrap.InputGroup>
                        </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div class="col-md-8 input-padd ">
                        <reactbootstrap.FormControl className="input_sw " type="textarea" name="maintext" value={main_text} onChange={(e) => props.setStateDesignObject({main_text: e.target.value})} />
                    </div>
                </reactbootstrap.InputGroup>
            </div>
        </reactbootstrap.FormGroup>
        <reactbootstrap.FormGroup controlId="subtext">
            <div className=" input-overall-sec ">
                <reactbootstrap.InputGroup className="">
                    <div className="col-md-4 p-0">
                        <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Sub text:')}</reactbootstrap.InputGroup>
                        </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div class="col-md-8 input-padd ">
                        <reactbootstrap.FormControl className="input_sw " type="textarea" name="subtext"  value={sub_text} onChange={(e) => props.setStateDesignObject({sub_text: e.target.value})}/>
                    </div>
                </reactbootstrap.InputGroup>
            </div>
        </reactbootstrap.FormGroup>
        <reactbootstrap.Form.Group>
           <div className = 'row col-md-12'>
               <reactbootstrap.Form.Label className="col-md-4" style = {{color: 'rgb(236, 102, 28)', paddingLeft:'8px'}} >{t('Color')}:</reactbootstrap.Form.Label>
            <div style={{marginLeft: '12px'}} className = 'col-md-5 p-0 input_sw' style={{marginLeft:'12px'}}>
              <reactbootstrap.Form.Control type="text" id ={2}  col='4'  placeholder="Color"
                 name  = "color"
                 value = {color}
                 onInput = {false}
                 readonly
                 disabled
              />
            </div>
            <div className = 'col-md-2'>
            <reactbootstrap.Button  variant="outline-primary" style={{margin:'0 auto' }} onClick = {()=> assignStateValue('popUpShow', true, 1)}>
                {t('Add here')}
            </reactbootstrap.Button>
            </div>
           </div>
        </reactbootstrap.Form.Group>
        <reactbootstrap.FormGroup>
            <div className=" row input-overall-sec ">
                <reactbootstrap.InputGroup className="  ">
                    <div className="col-md-4 mobileLabel">
                        <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Upload logo:')}</reactbootstrap.InputGroup>
                        </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div className="col-md-8 custom-file input_sw" style={{margin:'0 15px 0 5px'}}>
                        <input
                            type="file"
                            className="custom-file-input"
                            id="image"
                            name='image'
                            accept={window.DOC_TYPES['default']}
                            onChange={(e) =>{handleFileChanges(e, 'upload')}}
                            onClick={(event)=> event.target.value = null}
                        />
                        <label className="custom-file-label" htmlFor="inputGroupFile01">
                            {login_logo ? login_logo: 'Choose file' }
                        </label>
                    </div>
                </reactbootstrap.InputGroup>
            </div>
        </reactbootstrap.FormGroup>
        <div style={{}} className="row col-md-12 mt-2">
            <div style={{ visibility: 'hidden' }} className="col-md-4 mob-hide"> <h3>{t('Upload')}</h3> </div>
              <div className="col-md-8 mob-align">
                {!state.formatWarning && !state.sizeWarning && login_logo && login_logo !== 'Choose file' &&
                  <div> {state.uploadMessage && <span style={{ color: "green" }}>{window.FILE_UPLOAD_SUCCESS}</span>}
                      <span style={state.spanStyle}> <i title="Preview" style={{ 'cursor': 'pointer' }} class="webform-sprite webform-sprite-smallviewc" onClick={(e) => window.open(login_logo, "_blank")}></i> </span>
                      <span style={state.spanStyle}> <img src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/61726d5042ee88.300490011634889040.png" alt="Logo" title="Download" style={{cursor: 'pointer', marginTop: '-10px' }} onClick = {(e) => handleFileChanges(e, 'download', login_logo)}></img></span>
                      <span style={state.spanStyle}> <i title="Remove" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec"  onClick={(e) => {handleFileChanges(e, 'remove')}}/> </span>
                  </div>}
                {state.formatWarning && !state.sizeWarning && <span style={{ color: "red" }}> {window.FILE_FORMAT_ERROR_MSG} </span>}
                {!state.formatWarning && state.sizeWarning && <span style={{ color: "red" }}> {t('Size should be < 1MB')} </span>}
            </div>
        </div>
        <reactbootstrap.FormGroup controlId="subtext">
            <div className=" input-overall-sec ">
                <reactbootstrap.InputGroup className="">
                    <div className="col-md-4 p-0">
                        <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Scale:')}</reactbootstrap.InputGroup>
                        </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div class="col-md-8 input-padd row">
                      <div className='col-md-3'>
                          <reactbootstrap.Form.Control type='text' className="input_sw " type="textarea" name="logowidth"  value={logo_width} onChange={(e) => props.setStateDesignObject({logo_width: (e.target.value.match(/^[0-9]*$/) || e.target.value === '') ? e.target.value : logo_width })}/>
                          <reactbootstrap.Form.Text muted style={{textAlign:'center'}}> {t('Width in px')} </reactbootstrap.Form.Text>
                      </div>
                      <div className='col-md-3'>
                        <reactbootstrap.Form.Control type='text' className="input_sw " type="textarea" name="logoheight"  value={logo_height} onChange={(e) => props.setStateDesignObject({logo_height: (e.target.value.match(/^[0-9]*$/) || e.target.value === '') ? e.target.value : logo_height })}/>
                        <reactbootstrap.Form.Text muted style={{textAlign:'center'}}>  {t('Height in px')} </reactbootstrap.Form.Text>
                      </div>

                    </div>
                </reactbootstrap.InputGroup>
            </div>
        </reactbootstrap.FormGroup>
     </reactbootstrap.Form>
      <reactbootstrap.FormGroup>
        <div style={{ float: 'right', marginBottom: '50px' }} className="organisation_list">
          <a onClick={props.handleCancel}> {t('Cancel')} </a>
            &nbsp;&nbsp;&nbsp;
          <reactbootstrap.Button type="submit" className="btn btn-primary" onClick={(e) => props.fromWelcome ? props.handleSubmit(1) : props.handleSubmit(e)}  disabled={state.loading}>{t('Save')}</reactbootstrap.Button>
            {state.loading && t('loading')}
        </div>
      </reactbootstrap.FormGroup>
     {showPopup()}
    </div>
  );
}
export default React.memo(LoginScreenLayout);
