import React from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
import CheckBox from '../CheckBox';
import FileUpload from '../_components/FileUpload/FileUpload'
const ArForm=(props)=>{
  const inlineStyle={
    checkBox:{
      padding: '0px',
      width: '5%',
    },label:{
      padding: '.25rem 0 0 0',
      width: '85%',
    }
  }
  const {t,action,buildingsOption,selectedBuildings,floreOptions,selectedFlore,webFormOptions,selectedWebform,enablePin,imageData} = props.state;
  // console.log(props.state);
  return(
    <>
    <reactbootstrap.Row className='mt-2'>
    <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Building:')}</reactbootstrap.FormLabel>
    <reactbootstrap.Col className='col-md-9 px-0'>
    <MultiSelect
    options={buildingsOption}
    standards={selectedBuildings}
    handleChange={e=>props.handleChangeBuilding(e)}
    isMulti={false} />
    </reactbootstrap.Col>
    </reactbootstrap.Row>
    <reactbootstrap.Row className='mt-2'>
    <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Floor:')}</reactbootstrap.FormLabel>
    <reactbootstrap.Col className='col-md-9 px-0'>
    <MultiSelect
    options={floreOptions}
    standards={selectedFlore}
    handleChange={e=>props.handleChangeFlore(e)}
    isMulti={false} />
    </reactbootstrap.Col>
    </reactbootstrap.Row>
    {action==1 &&<reactbootstrap.Row className='mt-2'>
    <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Webform:')}</reactbootstrap.FormLabel>
    <reactbootstrap.Col className='col-md-9 px-0'>
    <MultiSelect
    options={(selectedFlore===undefined || selectedFlore.length ===0)?[]: webFormOptions}
    standards={selectedWebform}
    handleChange={e=>props.handleChangeWebform(e)}
    isMulti={false} />
    </reactbootstrap.Col>
    </reactbootstrap.Row>}
    {/*<reactbootstrap.Row>
    <reactbootstrap.Col className='' style={inlineStyle.checkBox}>
    <CheckBox
    tick={enablePin}
    onCheck={(e) => props.handleLinkingPin(e.target.checked)}
    />
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='' style={inlineStyle.label}>{t('Pin on groundplan')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>
    !imageData && <reactbootstrap.Row className="justify-content-md-center">
    <img onClick={props.takePhoto} src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5ff4655a5d1889.496120821609852250.png" style={{width:'6%'}} title={t('Open camera')}/>
    </reactbootstrap.Row>*/}
    {!imageData && <reactbootstrap.Row className='mt-2'>
        <reactbootstrap.FormLabel className='col-md-3' style={{ color: '#EC661C' }}>{t('Upload:')}</reactbootstrap.FormLabel>
        <reactbootstrap.InputGroup className= "col-md-7 custom-file input_sw" style={{zIndex:0}}>
           <reactbootstrap.FormControl
               type="file"
               className="custom-file-input"
               id="inputGroupFile01"
               name='image'
               accept = {'image/*'}
               onChange={(e)=>props.updateImageUpload(e)}
               style={{marginTop: "0px"}}
           />
          <reactbootstrap.FormLabel className="custom-file-label" htmlFor="inputGroupFile01">
           {/*{props.file_name !== null && props.file_name }*/}
           </reactbootstrap.FormLabel>
        </reactbootstrap.InputGroup>
        {!imageData &&
        <reactbootstrap className="col-md-2 justify-content-md-center" >
        <img onClick={props.takePhoto} src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5ff4655a5d1889.496120821609852250.png" style={{width:'50%'}} title={t('Open camera')}/>
        </reactbootstrap>}
    </reactbootstrap.Row>}
    {/*<reactbootstrap.Row>
      <reactbootstrap.Col className='col-md-1' style={inlineStyle.checkBox}>
      <CheckBox
      tick={enablePin}
      onCheck={(e) => props.handleLinkingPin(e.target.checked)}
      />
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-11'>
      <reactbootstrap.FormLabel style={inlineStyle.label}>{t('Pin on groundplan')}</reactbootstrap.FormLabel>
      </reactbootstrap.Col>
    </reactbootstrap.Row>*/}
    <reactbootstrap.Row className="pl-0" >
      <reactbootstrap.Col className='col-md-12'>
          <reactbootstrap.Form.Check
                onChange={(e) => props.handleLinkingPin(e.target.checked)}
                name='Pin on groundplan'
                checked={enablePin}
                label={t("Pin on groundplan")}
            />
          </reactbootstrap.Col>
    </reactbootstrap.Row>
    {imageData &&<reactbootstrap.Row className="justify-content-md-center">
    <reactbootstrap.Button md="auto" variant="outline-success" className='mr-2 mb-2 mt-2' onClick={e=>props.imagePreview()}>{t('Preview')}</reactbootstrap.Button>
    </reactbootstrap.Row>}
    <reactbootstrap.Row className='organisation_list mt-3 float-right' >
    <a style={{paddingTop:'15px', cursor: 'pointer'}} onDoubleClick = {e=>props.cancelForm()} onClick={e=>props.cancelFormData()}>{t('Cancel')}</a>&nbsp;&nbsp;&nbsp;
    {[true,1].includes(enablePin) && <reactbootstrap.Button className='m-2' onClick={e=>props.navigateToGp()}>{t('Next')}</reactbootstrap.Button>}
    {[false,0].includes(enablePin) && <reactbootstrap.Button className='m-2' onClick={e=>props.saveBuildingPhotoData()}>{t('Save')}</reactbootstrap.Button>}
    </reactbootstrap.Row>
    </>
  )
}
export default translate(ArForm);
