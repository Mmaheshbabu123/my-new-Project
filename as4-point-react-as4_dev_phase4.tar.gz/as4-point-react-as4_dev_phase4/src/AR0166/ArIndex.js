import React, { Component } from 'react';
import { translate } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import * as reactbootstrap from 'react-bootstrap';
import ArForm from './ArForm';
import ArImageOverView from './ArImageOverView';
import WebCamera from '../WebCamera/WebCamera';
import { datasave } from '../_services/db_services';
import GroundPlanAR from '../GroundPlan/GroundPlanEditor/GroundPlanAR';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { store } from '../store';
import axios from 'axios';
import { MultiSelectorSearchFilter } from '../MultiSelectorSearchFilter';
import {SearchFilter }from '../SearchFilter';
import ImageCropper from '../Imageprocessing/ImageCropper';
import MultiSelect from '../_components/MultiSelect';
import { confirmAlert } from 'react-confirm-alert';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';
import './ArIndex.css';
class ArIndex extends Component {
  constructor(props) {
    super(props);
    this.state = {
      t: props.t,
      action: 0,
      openCamera: false,
      imageData: '',
      captureAndLinkButton: "outline-primary",
      captureAndStoreButton: "outline-primary",
      goToOverview: "outline-primary",
      imageName: '',
      convertedFile: '',
      enablePin: true,
      selectedBuildings: [],
      buildingsOption: [],
      floreOptions: [],
      selectedFlore: [],
      webFormOptions: [],
      selectedWebform: [],
      allFloars: [],
      showCloseGp: false,
      showClosePreview: false,
      filterdOverviewData: [],
      overviewData: [],
      latestRow: [],
      loginPerson_Id: 0,
      overViewRowData: [],
      gpXCoOrdinate: '',
      gpYCoOrdinate: '',
      showCloseGpOverView: false,
      openCloseReatakeWarningFromOverView: false,
      cropedItemBase64Data:'',
      cropedItemRegionsData:'',
      addItemPopUp:false,
      currentItemName:'',
      currentItemLinkingWebForm:[],
      addwebformPopup:false,
      currentMainLinkingWebForm:[],
      disableCroping:false,
      overViewItemData:[],
      showCancelSave:false,
      clonedData:false,
      latestRowId:[],
      tablePagesCount:0,
      active: 1,
      page: 10,
      count:0,
      saveRetakeImage:false,
      retakeImage:'',
    }
    this.itemNames = [];
  }
  /**
  * [componentDidMount description]
  * @return {Promise} [description]
  */
  async componentDidMount() {
    await this.getallData();
  }

  /**
  * [getallData description]
  * @return {Promise} [description]
  */
  getallData = async () => {
    const { t } = this.state;
    const Userdata = store.getState();
    const LoginPerson_Id = Userdata.UserData.user_details.person_id;
    await datasave.service(window.GET_AR_IMAGE_OVERVIEW_DATA, 'GET').then(async response => {
      if (response['status'] === 200) {
        let coonstructedOverViewData = await this.constructOverviewData(response['data']['imgOverviewData']);
        let filteredData=[];
        var pageData=[];
        pageData = await SearchFilter.getPageData(1,this.state.page,coonstructedOverViewData,coonstructedOverViewData);
        // let filteredData = response['data']['last_inserted_data'][0] ? coonstructedOverViewData.filter(value => { return value.id == response['data']['last_inserted_data'][0]['id'] }) : [];
        this.setState({
          buildingsOption: this.sort(response['data']['buildings']),
          allFloars: this.sort(response['data']['floars']),
          webFormOptions: this.sort(response['data']['webforms']),
          showCloseGp: false,
          openCamera: false,
          filterdOverviewData: coonstructedOverViewData,
          overviewData: coonstructedOverViewData,
          latestRow: filteredData[0] ? filteredData[0] : [],
          loginPerson_Id: LoginPerson_Id,
          showClosePreview: false,
          showCloseGpOverView: false,
          showCloseOverViewPreview: false,
          openCloseReatakeWarningFromOverView: false,
          addItemPopUp:false,
          addwebformPopup:false,
          latestRowId:response['data']['last_inserted_data'][0] ? response['data']['last_inserted_data'][0]['id'] :[],
          active:1,
          items:pageData,
          count:await SearchFilter.getCountPage(coonstructedOverViewData,this.state.page),

        })
      } else {
        OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
        return;
      }
    })
  }

  constructOverviewData=async(data)=>{
    await data.map(value=>{
      value.filePath = window.backendURL+value.filePath;
      Object.values(value.items).map(value1=>{
        this.itemNames.push(value1.itemName ? value1.itemName: 'no item name');
        value1.filePath = window.backendURL+value1.filePath;
        value1.json_data = JSON.parse(value1.json_data)
      })
    })
    return data;
  }
  /**
  * [sort description]
  * @param  {[type]} data [description]
  * @return {[type]}      [description]
  */
  sort = (data) => {
    return Object.values(data).sort(function (a, b) { return (a.label).toLowerCase() < (b.label).toLowerCase() ? -1 : 1; });
  }
  /**
  * [captureLinkWfAndStore description]
  * @return {[type]} [description]
  */
  captureLinkWfAndStore = () => {
    const { latestRow, allFloars, buildingsOption, webFormOptions } = this.state;
    if (latestRow && latestRow['buildingId']) {
      this.setState({
        action: 1,
        captureAndLinkButton: "outline-success",
        captureAndStoreButton: "outline-primary",
        goToOverview: "outline-primary",
        selectedBuildings: buildingsOption.filter(item => { return item.value === latestRow['buildingId'] })[0],
        floreOptions: allFloars.filter(value => { return value['parentId'] === latestRow['buildingId'] }),
        selectedFlore: allFloars.filter(value => { return value['value'] === latestRow['floarId'] })[0],
        selectedWebform: webFormOptions.filter(value => { return value['value'] === latestRow['WebformId'] })[0],
        enablePin: latestRow['gp_linked'],
        gpXCoOrdinate: latestRow['gpXCoOrdinate'],
        gpYCoOrdinate: latestRow['gpYCoOrdinate'],
        imageData: latestRow['filePath'],
        imageName: latestRow['fileName'].replace('.jpg', ''),
      })
    } else {
      this.setState({
        action: 1,
        captureAndLinkButton: "outline-success",
        captureAndStoreButton: "outline-primary",
        goToOverview: "outline-primary",
        selectedBuildings: [],
        floreOptions: [],
        selectedFlore: [],
        selectedWebform: [],
        enablePin: true,
        gpYCoOrdinate: '',
        gpXCoOrdinate: '',
        imageData: '',
        imageName: '',
      })
    }
  }
  /**
  * [captureAndStore description]
  * @return {[type]} [description]
  */
  captureAndStore = () => {
    const { latestRow, allFloars, buildingsOption, webFormOptions } = this.state;
    if (latestRow && latestRow['buildingId']) {
      this.setState({
        action: 2,
        captureAndLinkButton: "outline-primary",
        captureAndStoreButton: "outline-success",
        goToOverview: "outline-primary",
        selectedBuildings: buildingsOption.filter(item => { return item.value === latestRow['buildingId'] })[0],
        floreOptions: allFloars.filter(value => { return value['parentId'] === latestRow['buildingId'] }),
        selectedFlore: allFloars.filter(value => { return value['value'] === latestRow['floarId'] })[0],
        selectedWebform: webFormOptions.filter(value => { return value['value'] === latestRow['WebformId'] })[0],
        enablePin: true,
        gpYCoOrdinate: latestRow['gpXCoOrdinate'],
        gpXCoOrdinate: latestRow['gpYCoOrdinate'],
        imageData: latestRow['filePath'],
        imageName: latestRow['fileName'].replace('.jpg', ''),
      })
    } else {
      this.setState({
        action: 2,
        captureAndLinkButton: "outline-primary",
        captureAndStoreButton: "outline-success",
        goToOverview: "outline-primary",
        selectedBuildings: [],
        floreOptions: [],
        selectedFlore: [],
        selectedWebform: [],
        enablePin: true,
        gpYCoOrdinate: '',
        gpXCoOrdinate: '',
        imageData: '',
        imageName: '',
      })
    }
  }
  /**
  * [goToOverview description]
  * @return {[type]} [description]
  */
  goToOverview = () => {
    this.setState({
      action: 3,
      captureAndLinkButton: "outline-primary",
      captureAndStoreButton: "outline-primary",
      goToOverview: "outline-success",
      selectedWebform: [],
      selectedFlore: [],
      floreOptions: [],
      selectedBuildings: [],
      enablePin: true,
      gpYCoOrdinate: '',
      gpXCoOrdinate: '',
      imageData: '',
      imageName: '',
    })
  }
  /**
  * [handleChangeBuilding description]
  * @param  {[type]}  e [description]
  * @return {Promise}   [description]
  */
  handleChangeBuilding = async (e) => {
    const { allFloars, selectedFlore } = this.state;
    let filteredFloars = allFloars.filter(value => { return value.parentId == e.value })
    this.setState({
      selectedBuildings: e,
      floreOptions: filteredFloars,
      selectedFlore: selectedFlore && selectedFlore.parentId === e.value ? selectedFlore : [],
    })
  }
  /**
  * [handleChangeFlore description]
  * @param  {[type]} e [description]
  * @return {[type]}   [description]
  */
  handleChangeFlore = (e) => {
    this.setState({
      selectedFlore: e,
    })
  }
  /**
  * [handleChangeWebform description]
  * @param  {[type]} e [description]
  * @return {[type]}   [description]
  */
  handleChangeWebform = (e) => {
    this.setState({
      selectedWebform: e
    })
  }
  /**
  * [handleLinkingPin description]
  * @return {[type]} [description]
  */
  handleLinkingPin = () => {
    this.setState({
      enablePin: !this.state.enablePin
    })
  }
  /**
  * [cancelForm description]
  * @return {[type]} [description]
  */
  cancelForm = () => {
    this.setState({
      action: 0,
      captureAndLinkButton: "outline-primary",
      captureAndStoreButton: "outline-primary",
      goToOverview: "outline-primary"
    })
  }

  /**
  * [cancelFormData description]
  * @return {[type]} [description]
  */
  cancelFormData = () => {
    this.setState({
      selectedWebform : [],
    })
  }

  /**
  * [navigateToGp description]
  * @return {[type]} [description]
  */
  navigateToGp = () => {
    const { t, imageData, selectedBuildings, selectedFlore, showCloseGp, action, selectedWebform ,temp_imageData} = this.state;
    if (!imageData && !temp_imageData) {
      OCAlert.alertWarning(t('Image capaturing is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (!selectedBuildings.value) {
      OCAlert.alertWarning(t('Please select building'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (!selectedFlore.value) {
      OCAlert.alertWarning(t('Please select floor'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (action === 1 && !selectedWebform.value) {
      OCAlert.alertWarning(t('Please select webform'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else {
      this.setState({
        showCloseGp: !showCloseGp,
      })
    }
  }
  /**
  * [saveBuildingPhotoData description]
  * @return {[type]} [description]
  */
  saveBuildingPhotoData = () => {
    const { t, imageData } = this.state;
    if (!imageData) {
      OCAlert.alertWarning(t('Image capaturing is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else {
      this.saveArImagePinlinking([]);
    }
  }
  /**
  * [OpenCloseCamera description]
  */
  OpenCloseCamera = () => {
    this.setState({
      openCamera: !this.state.openCamera
    })
  }
  /**
  * [retakePhoto description]
  * @return {[type]} [description]
  */
  retakePhoto = (camera) => {
    this.setState({
      openCamera: camera === 'opencamera' ?!this.state.openCamera : false,
      // imageName: '',
      // convertedFile: '',
      // imageData: '',
      showClosePreview: !this.state.showClosePreview,
    })
  }
  /**
  * [retakePhotoFromOveriView description]
  * @return {[type]} [description]
  */
  retakePhotoFromOveriView = (retakeoption) => {
    const { showCloseOverViewPreview, openCamera, overviewData } = this.state;
    this.retakeWarningFromOverview();
    this.setState({
      retakeImage:retakeoption,
    })
    // this.setState({
    //   showCloseOverViewPreview:!showCloseOverViewPreview,
    //   openCamera: !openCamera,
    // })
  }
  changePage = (id) => {
    const {selectedOverViewBuildings,selectedOverViewFlores,selectedOverviewWebform,page,filterdOverviewData,items,count}=this.state;
    this.setState({
      items: SearchFilter.getPageData(id,page,(selectedOverViewBuildings !== ''||selectedOverViewFlores!==''||selectedOverviewWebform!=='')? filterdOverviewData : '',items),
      active: id,
    });

  }
  /**
  * [handleTakePhoto description]
  * @param  {[type]} encryptedData [description]
  * @param  {[type]} convertedFile [description]
  * @param  {[type]} fileName      [description]
  * @return {[type]}               [description]
  */
  handleTakePhoto = (encryptedData, convertedFile, fileName) => {
    const { action, openCamera } = this.state;
    if (encryptedData && action !== 3) {
      this.setState({
        temp_imageData: encryptedData,
        temp_convertedFile: convertedFile,
        openCamera: !openCamera,
        temp_imageName:'' ,
        showClosePreview:true,
        showCancelSave:true
      })
      this.imagePreviewPopUp();
    } else if (encryptedData && action == 3) {
      this.updateArImageInRetakeProcress(encryptedData, convertedFile, fileName);
    }

  }
  /**
  * [updateArImageInRetakeProcress description]
  * @type {[type]}
  */
  updateArImageInRetakeProcress = async (encryptedData, convertedFile, fileName) => {
    const { overViewRowData, loginPerson_Id } = this.state;
    let concateNameWithFile = this.dataURLtoFile(encryptedData, fileName + '.jpg');
    let result = await this.storeImageGetId(concateNameWithFile,'Camera');
    if (result['status'] === 200) {
      let finalData = {
        buildingId: overViewRowData.buildingId,
        floarId: overViewRowData.floarId,
        WebformId: overViewRowData.WebformId,
        gpsXCoOrdinate: '',
        gpsYCoOrdinate: '',
        gpXCoOrdinate: '',
        gpYCoOrdinate: '',
        user_id: loginPerson_Id,
        gp_linked: overViewRowData.gp_linked,
        file_id: result['data']['file_id'] ? result['data']['file_id'][0] : result['data'][0]['file_id'],
        status: 1,
        rowId: overViewRowData.id,
        itemName:'',
        json_data:'',
      }
      await datasave.service(window.UPDATE_INSERT_AR_IMAGE_RETAKE_PROCESS, 'POST', finalData).then(async response => {
        if (response['status'] === 200) {
          this.setState({
            captureAndLinkButton: "outline-primary",
            captureAndStoreButton: "outline-primary",
            goToOverview: "outline-success",
            action: 3,
            saveRetakeImage:false,
            retakeImage:''
          }, async () => {
            await this.getallData();
          })
        }
      })
    }
  }
  /**
  * [showCloseGroundPlan description]
  * @return {[type]} [description]
  */
  showCloseGroundPlan = () => {
    this.setState({
      showCloseGp: !this.state.showCloseGp
    })
  }
  isValidURL = (string) => {
    var res = string.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
    return (res !== null)
    // return false;
  };
  /**
  * [saveArImagePinlinking description]
  * @param  {[type]}  data [description]
  * @return {Promise}      [description]
  */
  saveArImagePinlinking = async (data, pinRemoved = false) => {
    const { loginPerson_Id, action, imageData, imageName, enablePin, selectedBuildings, selectedFlore, selectedWebform, t, latestRow } = this.state;
    var concateNameWithFile = '';
    var result = '';
    if (!this.isValidURL(imageData)) {
      concateNameWithFile = this.dataURLtoFile(imageData, imageName + '.jpg');
      result = await this.storeImageGetId(concateNameWithFile,'Camera');
    } else {
      result = await this.cloneImageUrlAsNewRowInFile(latestRow['file_id']);
    }
    if (result['status'] === 200) {
      let finalData = {
        buildingId: selectedBuildings.value,
        floarId: selectedFlore.value,
        WebformId: action == 1 && selectedWebform && selectedWebform.value ? selectedWebform.value : 0,
        gpsXCoOrdinate: 1,
        gpsYCoOrdinate: 2,
        gpXCoOrdinate: data.length > 0 ? data[0]['coordinate_x'] : '',
        gpYCoOrdinate: data.length > 0 ? data[0]['coordinate_y'] : '',
        user_id: loginPerson_Id,
        gp_linked: (enablePin && pinRemoved === false) ? 1 : 0,
        file_id: result['data']['file_id'] ? result['data']['file_id'][0] : result['data'][0]['file_id'],
        status: 1,
        itemName:imageName,
        json_data:'',
      }
      await datasave.service(window.INSERT_AR_IMAGE_PIN_LINKING_DATA, 'POST', finalData).then(async response => {
        if (response['status'] === 200) {
          this.setState({
            captureAndLinkButton: "outline-primary",
            captureAndStoreButton: "outline-primary",
            goToOverview: "outline-primary",
            imageData:'',
            clonedData:false
            // action: 0,
          }, async () => {
            await this.getallData();
          })
        } else {
          OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
      })
    } else {
      OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }
  }
  /**
  * [cloneImageUrlAsNewRowInFile description]
  * @param  {[type]} id [description]
  * @return {[type]}    [description]
  */
  cloneImageUrlAsNewRowInFile = async (id) => {
    const { t, imageName } = this.state;
    let name = imageName + '.jpg';
    let result = {};
    document.getElementById("loding-icon").setAttribute("style", "display:block;");
    await axios.post(window.backendURL + window.CLONE_IMAGE_DATA_BY_ID_AND_GET_ID + '/' + id + '/' + name, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
      .then(async response => {
        document.getElementById("loding-icon").setAttribute("style", "display:none;");
        result.status = 200;
        result.data = response.data.data;
      })
      .catch(error => {
        document.getElementById("loding-icon").setAttribute("style", "display:none;");
        OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
        return;
      })
    return result;
  }
  /**
  * [storeImageGetId description]
  * @type {[type]}
  */
  storeImageGetId = async (imageFile,type) => {
    const { t } = this.state;
    const result = {};
    const formData = new FormData();
    formData.append('file', imageFile);
    document.getElementById("loding-icon").setAttribute("style", "display:block;");
    await axios.post(window.backendURL + window.STORE_AR_IMAGE_DATA+'/'+type, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
      .then(async response => {
        document.getElementById("loding-icon").setAttribute("style", "display:none;");
        result.status = 200;
        result.data = response.data.data;
      })
      .catch(error => {
        document.getElementById("loding-icon").setAttribute("style", "display:none;");
        OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
        return;
      })
    return result;
  }
  /**
  * [dataURLtoFile description]
  * @param  {[type]} dataurl  [description]
  * @param  {[type]} filename [description]
  * @return {[type]}          [description]
  */
  dataURLtoFile = (dataurl, filename) => {
    var arr = dataurl.split(","),
      mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]),
      n = bstr.length,
      u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }
  /**
  * [showClosePreview description]
  * @return {[type]} [description]
  */
  showClosePreview = () => {
    this.setState({
      showClosePreview: !this.state.showClosePreview,
      showCancelSave  : false,
    })
  }

  convertImageToDataurl =(file)=>{
    return new Promise((resolve,reject)=>{
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);
      fileReader.onload=()=>{
        resolve(fileReader.result);
      }

      fileReader.onerror = (error) =>{
        reject(error);
      }
    })
  }
  updateImageUpload=async (e)=> {
    const { t ,action, openCamera,saveRetakeImage ,retakeImage} = this.state;
    const filename=e.target.files[0]['name'];
    var name =filename.split('.');
    const dataurl= await this.convertImageToDataurl(e.target.files[0]);
    let convertedFile = this.dataURLtoFile(dataurl, name[0]);
    if (dataurl && action !== 3) {
      this.setState({
        temp_imageData: dataurl,
        temp_convertedFile: convertedFile,
        temp_imageName:name[0] ,
        showClosePreview:true,
        showCancelSave:true
      })
      this.imagePreviewPopUp();
    } else if (dataurl && action == 3) {
      this.setState({
        temp_imageData: dataurl,
        temp_convertedFile: convertedFile,
        temp_imageName:name[0] ,
        showClosePreview:false
      })
        this.updateArImageInRetakeProcress(dataurl, convertedFile, name[0]);

    }
  }

  showClosePreviewNext = () => {
    this.setState({
      showClosePreview: !this.state.showClosePreview,
      showCancelSave  : false,
    })
    if([true,1].includes(this.state.enablePin)){
      this.navigateToGp();
    }
  }
  showClosePreviewSave = () => {
    this.setState({
      imageData: this.state.temp_imageData,
      convertedFile: this.state.temp_convertedFile,
      imageName: this.state.temp_imageName,
      showClosePreview: !this.state.showClosePreview,
      showCancelSave  : false,
      saveRetakeImage:true

    })

    if([true,1].includes(this.state.enablePin)){
      this.navigateToGp();
    }

  }

  /**
  * [handleFileName description]
  * @param  {[type]} e [description]
  * @return {[type]}   [description]
  */
  handleFileName = (e) => {
    const value = e.target.value;
    // if(this.state.imageName === '' && value === ''){
    //   this.showClosePreview();
    // }
     if (this.state.showCancelSave === true) {
      this.setState({
        temp_imageName: value
      })
    }
    else {
      this.setState({
        imageName: value
      })
    }
    // const regex = /^[0-9a-zA-Z(\-)]+$/
    // if (value.match(regex) || value === '') {
    // }
  }
  /**
  * [searchFilter description]
  * @param  {[type]}  value [description]
  * @param  {[type]}  name  [description]
  * @return {Promise}       [description]
  */
  searchFilter = async (value, name) => {
    const { allFloars, selectedOverViewFlores } = this.state;
    if (['selectedOverViewFlores', 'selectedOverviewWebform'].includes(name)) {
      this.setState({
        [name]: value,
      }, async () => {
        await this.getFilteredValues();
      });
    } else {
      let buildingIds = value ? value.map(item => { return item.value }) : [];
      this.setState({
        selectedOverViewBuildings: value,
        floreOptions: allFloars.filter(item => { return buildingIds.includes(item.parentId) }),
        selectedOverViewFlores: selectedOverViewFlores ? selectedOverViewFlores.filter(item => { return buildingIds.includes(item.parentId) }) : [],
      }, async () => {
        await this.getFilteredValues();
      })
    }

  }
  getFilteredPages = async ()=>{
    const {filterdOverviewData,selectedOverViewBuildings,selectedOverViewFlores,selectedOverviewWebform,page,items,active,count}=this.state;
    let pageData = await SearchFilter.getPageData(1,page,filterdOverviewData,filterdOverviewData);
    await this.setState({
      count: SearchFilter.getCountPage(filterdOverviewData,page),
      items: pageData,
      active:1,
    })
  }
  /**
  * [getFilteredValues description]
  * @type {[type]}
  */
  getFilteredValues = async () => {
    const { overviewData, selectedOverViewBuildings, selectedOverviewWebform, selectedOverViewFlores } = this.state;
    let data = {
      'buildingId': selectedOverViewBuildings ? selectedOverViewBuildings.map(item => { return item.value }) : [],
      'floarId': selectedOverViewFlores ? selectedOverViewFlores.map(item => { return item.value }) : [],
      'WebformId': selectedOverviewWebform ? selectedOverviewWebform.map(item => { return item.value }) : [],
    };
    var filterableStates = [];
    Object.keys(data).map(key => {
      if (data[key].length > 0) {
        return filterableStates.push({ name: key, value: data[key] });
      }
    })
    var items_webformIds=[];
    if(data['WebformId'].length===0 || data['WebformId']=== undefined){
    this.setState({
        filterdOverviewData: await MultiSelectorSearchFilter.getData(filterableStates, overviewData),
      })
    }
    else {
      var filter=await MultiSelectorSearchFilter.getData(filterableStates, overviewData);
      items_webformIds.push({ name: 'WebformId', value: data['WebformId'] });
      var webformitems=[];
      webformitems = await this.filterItemWebforms(items_webformIds, overviewData);
      var filteredData=filter.concat(webformitems).reduce(
          (values1, values2) => {
              if(!values1.includes(values2)) {
                values1.push(values2);
              }
              return values1;
          }, []
        );
      this.setState({
        filterdOverviewData:filteredData ,
      })
    }
    this.getFilteredPages();
  }
  filterItemWebforms(states,allData){
    let arItems=[];
    allData.forEach(function (item) {
      if( Object.keys(item['items']).length > 0 ){
        Object.values(item['items']).find(key=>{
          if(states[0]['value'].includes(key[states[0]['name']])) {
            arItems.push(item);
            return true;
          }
      })
      }
       });
       return arItems;

 }
  /**
  * [openClosePreviewFromOvervirview description]
  * @param  {[type]} data [description]
  * @return {[type]}      [description]
  */
  openClosePreviewFromOvervirview = (data) => {
    const { showCloseOverViewPreview, } = this.state;
    data['fileName'] = data['fileName'].replace('.jpg', '');
    this.setState({
      showCloseOverViewPreview: !showCloseOverViewPreview,
      overViewRowData: data,
    })
  }
  /**
  * [showCloseOverViewPreview description]
  * @return {[type]} [description]
  */
  showCloseOverViewPreview = () => {
    const { showCloseOverViewPreview } = this.state;
    this.setState({
      showCloseOverViewPreview: !showCloseOverViewPreview
    })
  }
  /**
  * [handleOverViewFileName description]
  * @param  {[type]} e [description]
  * @return {[type]}   [description]
  */
  handleOverViewFileName = (e) => {
    let value = e.target.value;
    // const regex = /^[0-9a-zA-Z(\-)]+$/
    // if (value.match(regex) || value === '') {
      let overViewRowData = { ...this.state.overViewRowData };
      overViewRowData['fileName'] = value;
      this.setState({
        overViewRowData: { ...overViewRowData }
      })
    // }
  }
  /**
  * [updateNameOfOverViewRowImage description]
  * @return {[type]} [description]
  */
  updateNameOfOverViewRowImage = async () => {
    const { loginPerson_Id, overViewRowData, t } = this.state;
    overViewRowData['user_id'] = loginPerson_Id;
    overViewRowData['fileName'] = overViewRowData['fileName'] + '.jpg';
    await datasave.service(window.UPDATE_AR_IMAGE_NAME_BY_ID + '/' + loginPerson_Id, 'PUT', overViewRowData)
      .then(async response => {
        if (response['status'] === 200) {
          this.setState({
            captureAndLinkButton: "outline-primary",
            captureAndStoreButton: "outline-primary",
            goToOverview: "outline-success",
            action: 3
          }, async () => {
            await this.getallData();
            await this.getFilteredValues();
          })
        } else {
          OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
      }
      );
  }

  /**
   * [deleteImageFromOverview description]
   * @param  {[type]} data [description]
   */
    deleteImageFromOverview = (id) => {
      const { t } = this.state;
       confirmAlert({
        message:t('Do you want to delete image?'),
        buttons:[
          {
            label:t('No'),
          },
          {
            label:t('Yes'),
            onClick:()=> this.deleteImageOverallDataById(id)
          }
        ]
      });
    }

  /**
  * [deleteImageOverallDataById description]
  * @type {[type]}
  */
  deleteImageOverallDataById = async (id) => {
    const { loginPerson_Id, t } = this.state;
    await datasave.service(window.DELETE_AR_IMAGE_DATA_BY_ID + '/' + id + '/' + loginPerson_Id, 'DELETE')
      .then(async response => {
        if (response['status'] === 200) {
          this.setState({
            captureAndLinkButton: "outline-primary",
            captureAndStoreButton: "outline-primary",
            goToOverview: "outline-success",
            action: 3,
            clonedData:false
          }, async () => {
            await this.getallData();
            await this.getFilteredValues();
          })
        } else {
          OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
      }
      );
  }
  /**
  * [showCloseGroundPlanByOvriew description]
  * @return {[type]} [description]
  */
  showCloseGroundPlanByOvriew = () => {
    this.setState({
      showCloseGpOverView: !this.state.showCloseGpOverView,
    })
  }
  /**
  * [navigateToGpByOverview description]
  * @param  {[type]} data [description]
  * @return {[type]}      [description]
  */
  navigateToGpByOverview = (data) => {
    this.setState({
      showCloseGpOverView: !this.state.showCloseGpOverView,
      overViewRowData: data
    })
  }
  /**
  * [saveArImageGpLinkingByOverview description]
  * @type {[type]}
  */
  saveArImageGpLinkingByOverview = async (data, pinRemoved = false) => {
    const { loginPerson_Id, overViewRowData, t } = this.state;
    overViewRowData['gpXCoOrdinate'] = data.length > 0 ? data[0]['coordinate_x'] : '';
    overViewRowData['gpYCoOrdinate'] = data.length > 0 ? data[0]['coordinate_y'] : '';
    overViewRowData['gp_linked'] = pinRemoved === true ? 0 : 1;
    overViewRowData['user_id'] = loginPerson_Id;
    await datasave.service(window.UPDATE_AR_IMAGE_GP_LINKING_BY_OVERVIEW_ID, 'PUT', overViewRowData)
      .then(async response => {
        if (response['status'] === 200) {
          this.setState({
            captureAndLinkButton: "outline-primary",
            captureAndStoreButton: "outline-primary",
            goToOverview: "outline-success",
            action: 3
          }, async () => {
            await this.getallData();
            await this.getFilteredValues();
          })
        } else {
          OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
      }
      );
  }
  /**
  * [imagePreviewPopUp description]
  * @return {[type]} [description]
  */
  imagePreviewPopUp = () => {
    const { showClosePreview, t, imageName, imageData, showCancelSave, retakeImage } = this.state;
    if (showClosePreview) {
      return (
        <reactbootstrap.Modal
          show={showClosePreview}
          onHide={e => this.showClosePreview()}
        >
          <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
            <reactbootstrap.Modal.Title>{t('Preview')}</reactbootstrap.Modal.Title>
          </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body>
            <reactbootstrap.Row className="justify-content-md-center">
              <img style={{ width: '25rem', height: '25rem' }} src={showCancelSave=== true ? this.state.temp_imageData: imageData} />
            </reactbootstrap.Row>
          <reactbootstrap.Row className="row mt-2">
               <reactbootstrap.Col className="col-md-8 m-0 d-flex">
                 <reactbootstrap.FormLabel className='col-md-5 mt-2'>{t('Item name')}</reactbootstrap.FormLabel>
                 <reactbootstrap.FormControl
                   className="col-md-7 m-0 p-0"
                   type='text'
                   onChange={(e) => this.handleFileName(e)}
                   value={showCancelSave=== true ? this.state.temp_imageName: imageName} />
               </reactbootstrap.Col>
               <reactbootstrap.Col className="col-md-2">
                 <img onClick={e => this.retakePhoto('opencamera')} src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5ff4655a5d1889.496120821609852250.png" style={{ width: '40px' }} title={t('Retake photo')} />
               </reactbootstrap.Col>
               <reactbootstrap.Col className="col-md-2">
               <label for="file-input" style= {{cursor:'pointer'}}>
                 <img src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5f47f7b117ba25.333358961598551985.jpg"
                      width='50px' height='50px' title='upload image'/>
               </label>
               <input style = {{display : 'none'}}id="file-input" type="file" accept = {'image/*'} onChange={(e)=>this.updateImageUpload(e)}/>
               </reactbootstrap.Col>
             </reactbootstrap.Row>
          </reactbootstrap.Modal.Body>
          {(showCancelSave || retakeImage !== '' ) &&  <reactbootstrap.Modal.Footer>
           <reactbootstrap.Button onClick={e => this.retakePhoto('closecamera')}>{t('Cancel')}</reactbootstrap.Button>
           <reactbootstrap.Button onClick={e => this.showClosePreviewSave()}>{t('Save')}</reactbootstrap.Button>
          </reactbootstrap.Modal.Footer>}
        {!showCancelSave &&  <reactbootstrap.Modal.Footer>
            <reactbootstrap.Button onClick={e => this.handleFileName(e)}>{t('Cancel')}</reactbootstrap.Button>
            <reactbootstrap.Button onClick={e => this.showClosePreviewNext()}>{t('Save')}</reactbootstrap.Button>
          </reactbootstrap.Modal.Footer>}
        </reactbootstrap.Modal>
      )
    }
  }
  /**
  * [cameraOpenClosePopUp description]
  * @return {[type]} [description]
  */
  cameraOpenClosePopUp = () => {
    const { openCamera, t } = this.state;
    if (openCamera) {
      return (
        <reactbootstrap.Modal
          show={openCamera}
          onHide={this.OpenCloseCamera}
          size="lg"
        >
          <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
            <reactbootstrap.Modal.Title>{t('Camera')}</reactbootstrap.Modal.Title>
          </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body>
            <WebCamera
              openCamera={openCamera}
              OpenCloseCamera={this.OpenCloseCamera}
              handleTakePhoto={this.handleTakePhoto}
            />
          </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal>
      )
    }
  }
  /**
  * [groundPlanPopUp description]
  * @return {[type]} [description]
  */
  groundPlanPopUp = () => {
    const { showCloseGp, t, selectedBuildings, selectedFlore } = this.state;
    if (showCloseGp) {
      return (
        <reactbootstrap.Modal
          show={showCloseGp}
          onHide={this.showCloseGroundPlan}
          size="xl"
        >
          <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
            <reactbootstrap.Modal.Title>{t('Ground plan')}</reactbootstrap.Modal.Title>
          </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body>
            <GroundPlanAR
              building_id={selectedBuildings.value}
              floor_id={selectedFlore.value}
              showCloseGroundPlan={this.showCloseGroundPlan}
              saveArImagePinlinking={this.saveArImagePinlinking}
            />
          </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal>
      )
    }
  }

  /**
  * [imageOverViewPreviewPopUp description]
  * @return {[type]} [description]
  */
  imageOverViewPreviewPopUp = () => {
    const { showCloseOverViewPreview, t, overViewRowData } = this.state;
    if (showCloseOverViewPreview) {
      return (
        <reactbootstrap.Modal
          show={showCloseOverViewPreview}
          onHide={e => this.showCloseOverViewPreview()}
        >
          <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
            <reactbootstrap.Modal.Title>{t('Preview')}</reactbootstrap.Modal.Title>
          </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body>
            <reactbootstrap.Row className="justify-content-md-center">
              <img style={{ width: '25rem', height: '25rem' }} src={overViewRowData.filePath} />
            </reactbootstrap.Row>
            <reactbootstrap.Row className="row mt-2">
              <reactbootstrap.Col className="col-md-8 m-0 p-0 d-flex">
                <reactbootstrap.FormLabel className='col-md-5 mt-2'>{t('Item name')}</reactbootstrap.FormLabel>
                <reactbootstrap.FormControl
                  className="col-md-7 m-0 p-0"
                  type='text'
                  onChange={(e) => this.handleOverViewFileName(e)}
                  value={overViewRowData.fileName} />
              </reactbootstrap.Col>
              <reactbootstrap.Col className="col-md-2 m-0 d-flex">
                {/*<img onClick={e => this.updateNameOfOverViewRowImage()} src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5ff9ca388de673.500246471610205752.png" style={{ width: '50%' }} title={t('Update name')} />*/}
                <img onClick={e => this.retakePhotoFromOveriView('camera')} src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5ff4655a5d1889.496120821609852250.png" style={{ width: '40px' }} title={t('Retake photo')} />
              </reactbootstrap.Col>
              <reactbootstrap.Col className="col-md-2">

                <img onClick={e => this.retakePhotoFromOveriView('upload')} src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5f47f7b117ba25.333358961598551985.jpg"
                     width='50px' height='50px' title='Reupload image'/>


              </reactbootstrap.Col>
            </reactbootstrap.Row>
          </reactbootstrap.Modal.Body>
          <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={e => this.showCloseOverViewPreview()}>{t('Cancel')}</reactbootstrap.Button>
          <reactbootstrap.Button onClick={e => this.updateNameOfOverViewRowImage()}>{t('Save')}</reactbootstrap.Button>
          </reactbootstrap.Modal.Footer>
        </reactbootstrap.Modal>
      )
    }
  }
  /**
   * [linkingGpThroudImageOverviewPopUp description]
   * @return {[type]} [description]
   */
  linkingGpThroudImageOverviewPopUp = () => {
    const { showCloseGpOverView, t, overViewRowData } = this.state;
    if (showCloseGpOverView) {
      return (
        <reactbootstrap.Modal
          show={showCloseGpOverView}
          onHide={this.showCloseGroundPlanByOvriew}
          size="xl"
        >
          <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
            <reactbootstrap.Modal.Title>{t('Ground plan')}</reactbootstrap.Modal.Title>
          </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body>
            <GroundPlanAR
              building_id={overViewRowData['buildingId']}
              floor_id={overViewRowData['floarId']}
              showCloseGroundPlan={this.showCloseGroundPlanByOvriew}
              saveArImagePinlinking={this.saveArImageGpLinkingByOverview}
              rowData={overViewRowData}
            />
          </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal>
      )
    }
  }
  /**
   * [retakeWarningFromOverview description]
   * @return {[type]} [description]
   */
  retakeWarningFromOverview = () => {
    const { openCloseReatakeWarningFromOverView, showCloseOverViewPreview } = this.state;
    this.setState({
      openCloseReatakeWarningFromOverView: !openCloseReatakeWarningFromOverView,
      showCloseOverViewPreview: !showCloseOverViewPreview
    })
  }
  /**
   * [confirmWarningForTakeBYOverview description]
   * @return {[type]} [description]
   */
  confirmWarningForTakeBYOverview = () => {
    const { openCloseReatakeWarningFromOverView, openCamera,retakeImage,uploadEvent } = this.state;
    this.setState({
      openCloseReatakeWarningFromOverView: !openCloseReatakeWarningFromOverView,
      openCamera:!openCamera,
    })

  }
  /**
   * [retakeWarningFromOverviewPopUp description]
   * @return {[type]} [description]
   */
  retakeWarningFromOverviewPopUp = () => {
    const { openCloseReatakeWarningFromOverView, retakeImage, t } = this.state;
    if (openCloseReatakeWarningFromOverView) {
      return (
        <reactbootstrap.Modal
          show={openCloseReatakeWarningFromOverView}
          onHide={this.retakeWarningFromOverview}
          size="md"
        >
          <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
            <reactbootstrap.Modal.Title style={{ color: 'red' }}>{t('Warning')}</reactbootstrap.Modal.Title>
          </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body>
            <reactbootstrap.FormLabel>
              {t('You will be loose items and grondplan data if data is linked with this image')}
            </reactbootstrap.FormLabel>
          </reactbootstrap.Modal.Body>
          <reactbootstrap.Modal.Footer>
            <reactbootstrap.Button onClick={e => this.retakeWarningFromOverview()}>{t('cancel')}</reactbootstrap.Button>
            {retakeImage === 'upload' &&<reactbootstrap>
                <span class="btn btn-primary btn-file ">
                    proceed <input type="file" accept = {'image/*'} onChange={(e) => this.updateImageUpload(e)}/>
                </span>
            </reactbootstrap>}
            {retakeImage === 'camera' && <reactbootstrap.Button onClick={e => this.confirmWarningForTakeBYOverview()}>{t('proceed')}</reactbootstrap.Button>}
          </reactbootstrap.Modal.Footer>
        </reactbootstrap.Modal>
      )
    }
  }
  /**
   * [onChangeCrop description]
   * @param  {[type]} base64Data  [description]
   * @param  {[type]} regionsData [description]
   * @return {[type]}             [description]
   */
  onChangeCrop=(base64Data,regionsData)=>{
    if(base64Data && regionsData){
    this.setState({
      cropedItemBase64Data:base64Data,
      cropedItemRegionsData:regionsData,
    })}
  }
  /**
   * [closeAddItemPopUpFromOverview description]
   * @return {[type]} [description]
   */
  closeAddItemPopUpFromOverview=()=>{
    this.setState({
      cropedItemBase64Data:'',
      cropedItemRegionsData:'',
      addItemPopUp:false,
      currentItemName:'',
      currentItemLinkingWebForm:[],
      disableCroping:false
    })
  }
  /**
   * [handleOverViewItemName description]
   * @param  {[type]} e [description]
   * @return {[type]}   [description]
   */
  handleOverViewItemName=(e)=>{
    const value = e.target.value;
    // const regex = /^[0-9a-zA-Z(\-)]+$/
    // if (value.match(regex) || value === '') {
      this.setState({
        currentItemName: value
      })
    // }
  }
  /**
   * [handleItemWebformfromOverview description]
   * @param  {[type]} e [description]
   * @return {[type]}   [description]
   */
  handleItemWebformfromOverview=(e)=>{
    this.setState({
      currentItemLinkingWebForm:e
    })
  }
  /**
   * [saveAddItemFromOverview description]
   * @type {[type]}
   */
  saveAddItemFromOverview=async()=>{
    const {currentItemName,currentItemLinkingWebForm,t,disableCroping, editedItemName} =this.state;
    if(((disableCroping && editedItemName !== currentItemName) || !disableCroping) && this.itemNames.includes(currentItemName)){
        OCAlert.alertWarning(t('Item name already exists'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }
    if(currentItemName.length<1){
      OCAlert.alertWarning(t('Item name is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }else if (!currentItemLinkingWebForm) {
      OCAlert.alertWarning(t('Webform is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }else if (disableCroping) {
      await this.updateCroppedItem();
    }else{
        await this.saveAddItem();
    }
  }
  updateCroppedItem=()=>{
    const {loginPerson_Id,currentItemName,t,currentItemLinkingWebForm,overViewItemData} =this.state;
      overViewItemData['user_id']=loginPerson_Id;
      overViewItemData['itemName']=currentItemName;
      overViewItemData['json_data'] = overViewItemData.json_data
      overViewItemData['WebformId']=currentItemLinkingWebForm[0] &&currentItemLinkingWebForm[0].value?currentItemLinkingWebForm[0].value:currentItemLinkingWebForm.value;
      datasave.service(window.UPDATE_CROPPED_IMAGE_ITEM,'POST',overViewItemData)
      .then(async response => {
        if (response['status'] === 200) {
          this.setState({
            cropedItemRegionsData:'',
            currentItemName: "",
            currentItemLinkingWebForm: "",
            disableCroping:false,
            addItemPopUp:false,
          }, async () => {
            await this.getallData();
            await this.getFilteredValues();
          })
        } else {
          OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
      })
  }
  /**
   * [saveAddItem description]
   * @type {[type]}
   */
  saveAddItem=async()=>{
    const {loginPerson_Id,overViewRowData,currentItemName,cropedItemBase64Data,t,cropedItemRegionsData,currentItemLinkingWebForm} =this.state;
    var randomFileName = new Date().getTime();
    let concateNameWithFile = await this.dataURLtoFile(cropedItemBase64Data, randomFileName + '.jpg');
    let result = await this.storeImageGetId(concateNameWithFile,'CropedImages');
        if (result['status'] === 200) {
    let data ={
      refId:overViewRowData.id,
      json_data:cropedItemRegionsData,
      file_id:result['data']['file_id'] ? result['data']['file_id'][0] : result['data'][0]['file_id'],
      itemName:currentItemName,
      WebformId:currentItemLinkingWebForm.value,
      status:1,
      mainOrItem:2,
      user_id: loginPerson_Id,
    };
    datasave.service(window.ADD_CROPPED_IMAGE_ITEM,'POST',data)
    .then(async response => {
      if (response['status'] === 200) {
        this.setState({
          cropedItemRegionsData:'',
          currentItemName: "",
          currentItemLinkingWebForm: "",
        }, async () => {
          await this.getallData();
          await this.getFilteredValues();
        })
      } else {
        OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
        return;
      }
    })
  }
  }
  /**
   * [addItemPopUpFromOverView description]
   */
  addItemPopUpFromOverView = () => {
    const { addItemPopUp, t ,disableCroping,overViewItemData,currentItemName,overViewRowData,currentItemLinkingWebForm,webFormOptions} = this.state;
    if (addItemPopUp) {
      return (
        <reactbootstrap.Modal
          show={addItemPopUp}
          onHide={this.closeAddItemPopUpFromOverview}
          size="md"
        >
          <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
            <reactbootstrap.Modal.Title>{disableCroping?t('Item'):t('Link picture to another webform')}</reactbootstrap.Modal.Title>
          </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body>
          <>
          <ImageCropper
            src={overViewRowData.filePath}
            cropedData={this.onChangeCrop}
            disableCroping={disableCroping}
            cropingData={disableCroping?overViewItemData.json_data:[]}
          />
          </>
          <reactbootstrap.Row>
          <reactbootstrap.FormLabel className='col-md-4 mt-2' style={{color: '#EC661C'}}>{t('Item name')}</reactbootstrap.FormLabel>
          <reactbootstrap.FormControl
            className="col-md-8 m-0 p-0"
            type='text'
            onChange={(e) => this.handleOverViewItemName(e)}
            value={currentItemName} />
          </reactbootstrap.Row>
          <reactbootstrap.Row>
          <reactbootstrap.FormLabel className='col-md-4 mt-1' style={{color: '#EC661C'}}>{t('Webform:')}</reactbootstrap.FormLabel>
          <reactbootstrap.Col className='col-md-8 px-0'>
          <MultiSelect
          options={webFormOptions}
          standards={currentItemLinkingWebForm}
          handleChange={e=>this.handleItemWebformfromOverview(e)}
          isMulti={false} />
          </reactbootstrap.Col>
          </reactbootstrap.Row>
          </reactbootstrap.Modal.Body>
          <reactbootstrap.Modal.Footer>
            <reactbootstrap.Button onClick={e => this.closeAddItemPopUpFromOverview()}>{t('Cancel')}</reactbootstrap.Button>
            <reactbootstrap.Button onClick={e => this.saveAddItemFromOverview()}>{t('Save')}</reactbootstrap.Button>
          </reactbootstrap.Modal.Footer>
        </reactbootstrap.Modal>
      )
    }
  }
  /**
   * [navigateToAddItemImageCroping description]
   * @param  {[type]} data [description]
   * @return {[type]}      [description]
   */
  navigateToAddItemImageCroping=(data)=>{
    this.setState({
      overViewRowData: data,
      cropedItemBase64Data:'',
      cropedItemRegionsData:'',
      addItemPopUp:true,
      currentItemName:'',
      currentItemLinkingWebForm:[],
      disableCroping:false,
      overViewItemData:[],
      clonedData:false
    })
  }

/**
 * [deleteItemFromOverview description]
 * @param  {[type]} data [description]
 */
  deleteItemFromOverview = (data) => {
    const { t } = this.state;
     confirmAlert({
      message:t('Do you want to delete the item ') + data.itemName + '?',
      buttons:[
        {
          label:t('No'),
        },
        {
          label:t('Yes'),
          onClick:()=> this.deleteOverViewFromOverview(data)
        }
      ]
    });
  }
  /**
   * [deleteOverViewFromOverview description]
   * @type {[type]}
   */
  deleteOverViewFromOverview=async(data)=>{
    data['status']=0;
    data['json_data'] = data['json_data'];
    await datasave.service(window.DELTE_ITEM_FROM_OVERVIEW,'PUT',data)
    .then(async response=>{
      if(response['status']===200){
          await this.getallData();
          await this.getFilteredValues();
      }
    })
  }
  /**
   * [handleMainImageWebformfromOverview description]
   * @param  {[type]} e [description]
   * @return {[type]}   [description]
   */
  handleMainImageWebformfromOverview=(e)=>{
    this.setState({
      currentMainLinkingWebForm:e
    })
  }
  /**
   * [closeAddWebformPopUpFromOverview description]
   * @param  {[type]} e [description]
   * @return {[type]}   [description]
   */
  closeAddWebformPopUpFromOverview=(e)=>{
    this.setState({
      addwebformPopup:false,
      overViewRowData:[],
      currentMainLinkingWebForm:[]
    })
  }
  /**
   * [updateMainWebformFromOverview description]
   * @type {[type]}
   */
  updateMainWebformFromOverview=async()=>{
    const {overViewRowData,currentMainLinkingWebForm,t,loginPerson_Id} =this.state;
    overViewRowData['user_id']= loginPerson_Id;
    overViewRowData['WebformId'] = currentMainLinkingWebForm[0]?currentMainLinkingWebForm[0].value:currentMainLinkingWebForm.value;
    await datasave.service(window.UPDATE_AR_IMAGE_GP_LINKING_BY_OVERVIEW_ID, 'PUT', overViewRowData)
      .then(async response => {
        if (response['status'] === 200) {
          this.setState({
            overViewRowData:[],
            currentMainLinkingWebForm:[]
          }, async () => {
            await this.getallData();
            await this.getFilteredValues();
          })
        } else {
          OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
      }
      );
  }
  /**
   * [addWebformPopUpFromOverView description]
   */
  addWebformPopUpFromOverView = () => {
    const { addwebformPopup, t ,currentMainLinkingWebForm,webFormOptions} = this.state;
    if (addwebformPopup) {
      return (
        <reactbootstrap.Modal
          show={addwebformPopup}
          onHide={this.closeAddWebformPopUpFromOverview}
          size="md"
        >
          <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
            <reactbootstrap.Modal.Title>{t('Webforms')}</reactbootstrap.Modal.Title>
          </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body>
          <reactbootstrap.Row>
          <reactbootstrap.FormLabel className='col-md-4 mt-1' style={{color: '#EC661C'}}>{t('Webform:')}</reactbootstrap.FormLabel>
          <reactbootstrap.Col className='col-md-8 px-0'>
          <MultiSelect
          options={webFormOptions}
          standards={currentMainLinkingWebForm}
          handleChange={e=>this.handleMainImageWebformfromOverview(e)}
          isMulti={false} />
          </reactbootstrap.Col>
          </reactbootstrap.Row>
          </reactbootstrap.Modal.Body>
          <reactbootstrap.Modal.Footer>
            <reactbootstrap.Button onClick={e => this.closeAddWebformPopUpFromOverview()}>{t('Cancel')}</reactbootstrap.Button>
            <reactbootstrap.Button onClick={e => this.updateMainWebformFromOverview()}>{t('Save')}</reactbootstrap.Button>
          </reactbootstrap.Modal.Footer>
        </reactbootstrap.Modal>
      )
    }
  }
  /**
   * [navigateToAddWebformByOverview description]
   * @param  {[type]} data [description]
   * @return {[type]}      [description]
   */
  navigateToAddWebformByOverview=(data)=>{
    const{webFormOptions} = this.state;
    let filteredWf = webFormOptions.filter(item=>{return item.value===data['WebformId']});
    console.log(filteredWf);
    this.setState({
      overViewRowData:data,
      addwebformPopup:true,
      currentMainLinkingWebForm:filteredWf
    })
  }
  /**
   * [navigateToAddItemImageCroping description]
   * @param  {[type]} data [description]
   * @return {[type]}      [description]
   */
  navigateToDisabledCroping=(rowdata,itemdata)=>{
    const{webFormOptions} = this.state;
    let filteredWf = webFormOptions.filter(item=>{return item.value===itemdata['WebformId']});
    this.setState({
      overViewRowData: rowdata,
      cropedItemBase64Data:'',
      cropedItemRegionsData:'',
      addItemPopUp:true,
      currentItemName:itemdata.itemName,
      currentItemLinkingWebForm:filteredWf,
      disableCroping:true,
      overViewItemData:itemdata,
      editedItemName: itemdata.itemName,
    })
  }
  /**
   * [cloneImageData description]
   * @param  {[type]} data [description]
   * @return {[type]}      [description]
   */
  cloneImageData=async (data)=>{
    const {loginPerson_Id,t} =this.state;
      data['user_id']= loginPerson_Id;
      data['itemName'] = data['fileName'].replace('.jpg', '')
    await datasave.service(window.CLONE_IMAGE_OVERALL_DATA,'POST',data)
    .then(async response=>{
      if (response['status'] === 200) {
        OCAlert.alertSuccess(t('Cloning success'), { timeOut: window.TIMEOUTNOTIFICATION });
          this.setState({
            clonedData:true
          })
          await this.getallData();
          await this.getFilteredValues();
      } else {
        OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
        return;
      }
    })
  }
  render() {
    const { t, action, goToOverview, captureAndStoreButton, captureAndLinkButton } = this.state;
    if(localStorage.getItem("ar_enable") !== null && localStorage.getItem("ar_enable") !== undefined && parseInt(localStorage.getItem("ar_enable")) && CanPermissions('AR_access', "")){
      return (
        <reactbootstrap.Container>
          <reactbootstrap.Row className='col-md-12'>
            <reactbootstrap.Col className={action == 3 ? 'col-md-12 mt-4' : 'col-md-6 mt-4'} style={{ display: 'grid' }}>
              <reactbootstrap.Button className='m-1' variant={captureAndLinkButton} onClick={e => { this.captureLinkWfAndStore() }}>{t("Take image and link to webform")}</reactbootstrap.Button>
              <reactbootstrap.Button className='m-1' variant={captureAndStoreButton} onClick={e => { this.captureAndStore() }}>{t("Take image and store")}</reactbootstrap.Button>
              <reactbootstrap.Button className='m-1' variant={goToOverview} onClick={e => { this.goToOverview() }}>{t("Go to overview")}</reactbootstrap.Button>
            </reactbootstrap.Col>
            <reactbootstrap.Col className='col-md-6 mt-4'>
              {[1, 2].includes(action) && <ArForm
                state={this.state}
                handleChangeBuilding={this.handleChangeBuilding}
                handleChangeFlore={this.handleChangeFlore}
                handleChangeWebform={this.handleChangeWebform}
                handleLinkingPin={this.handleLinkingPin}
                cancelForm={this.cancelForm}
                cancelFormData={this.cancelFormData}
                navigateToGp={this.navigateToGp}
                saveBuildingPhotoData={this.saveBuildingPhotoData}
                takePhoto={this.OpenCloseCamera}
                imagePreview={this.showClosePreview}
                updateImageUpload={this.updateImageUpload}/>

              }
            </reactbootstrap.Col>
          </reactbootstrap.Row>
          {[3].includes(action) &&
            <ArImageOverView
              state={this.state}
              searchFilter={this.searchFilter}
              changePage={this.changePage}
              openClosePreviewFromOvervirview={this.openClosePreviewFromOvervirview}
              deleteImageOverallDataById={this.deleteImageFromOverview}
              navigateToGpByOverview={this.navigateToGpByOverview}
              navigateToAddItemImageCroping={this.navigateToAddItemImageCroping}
              deleteItemFromOverview={this.deleteItemFromOverview}
              navigateToAddWebformByOverview={this.navigateToAddWebformByOverview}
              navigateToDisabledCroping={this.navigateToDisabledCroping}
              cloneImageData={this.cloneImageData}/>}
          {this.groundPlanPopUp()}
          {this.imagePreviewPopUp()}
          {this.cameraOpenClosePopUp()}
          {this.imageOverViewPreviewPopUp()}
          {this.linkingGpThroudImageOverviewPopUp()}
          {this.retakeWarningFromOverviewPopUp()}
          {this.addItemPopUpFromOverView()}
          {this.addWebformPopUpFromOverView()}
        </reactbootstrap.Container>
      )
    }else{
      return(
        <AccessDeniedPage  />
      )
    }
  }
}
export default translate(ArIndex);
