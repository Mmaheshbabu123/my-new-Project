import React from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
import Paginator from '../Paginator';
const ArImageOverView=(props)=>{
  const {filterdOverviewData,css,t,tablePagesCount,active,changePage,buildingsOption,selectedOverViewBuildings,floreOptions,selectedOverViewFlores,webFormOptions,
    selectedOverviewWebform,clonedData, latestRowId,count,items}=props.state;
    console.log(props.state);
    const getItems=(rowdata,itemsData)=>{
      let table = [];
      // let fileName=(rowdata.fileName).replace('.jpg','');
      // if(fileName !== undefined && fileName !=='' ){
      //   table.push(
      //       <tr className="remove-border" >
      //           <td><img src={rowdata.filePath} onClick={e=>props.openClosePreviewFromOvervirview(rowdata)} style={{ width: '1rem' }}/></td>
      //           <td onClick={e=>props.openClosePreviewFromOvervirview(rowdata)}>{fileName}</td>
      //           <td>{rowdata.webFormCode}-{rowdata.webFormName}-{rowdata.webFormVersion}</td>
      //           <td><i title="Delete" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={e=>props.deleteImageOverallDataById(rowdata.id)}></i> </td>
      //       </tr>
      //   );
      // }
      Object.values(itemsData).map(value=>{
      table.push(
          <tr className="remove-border" >
              <td onClick={e=>props.navigateToDisabledCroping(rowdata,value)}><img src={value.filePath} style={{width: "1rem"}}/></td>
              <td onClick={e=>props.navigateToDisabledCroping(rowdata,value)}>{value.itemName}</td>
              <td>{value.webFormCode}-{value.webFormName}-{value.webFormVersion}</td>
              <td><i title="Delete" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={e=>props.deleteItemFromOverview(value)}></i> </td>
          </tr>
      );
    });
      return table;
    }
    return(
      <>
      <reactbootstrap.Row className="mt-1 p-flex">
      <reactbootstrap.Col className='col-md-4 d-flex'>
      <reactbootstrap.Col className='col-md-3 px-0'>
      <reactbootstrap.FormLabel style={{color: '#EC661C'}}>{t('Building:')}</reactbootstrap.FormLabel>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-9 px-0'>
      <MultiSelect
      options={buildingsOption}
      standards={selectedOverViewBuildings}
      handleChange={e=>props.searchFilter(e,'selectedOverViewBuildings')}
      isMulti={true} />
      </reactbootstrap.Col>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-4  d-flex'>
      <reactbootstrap.Col className='col-md-3 px-0'>
      <reactbootstrap.FormLabel style={{color: '#EC661C'}}>{t('Floor:')}</reactbootstrap.FormLabel>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-9 px-0'>
      <MultiSelect
      options={floreOptions}
      standards={selectedOverViewFlores}
      handleChange={e=>props.searchFilter(e,'selectedOverViewFlores')}
      isMulti={true} />
      </reactbootstrap.Col>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-4  d-flex'>
      <reactbootstrap.Col className='col-md-3 px-0'>
      <reactbootstrap.FormLabel  style={{color: '#EC661C'}}>{t('Webform:')}</reactbootstrap.FormLabel>
      </reactbootstrap.Col>
      <reactbootstrap.Col className='col-md-9 px-0'>
      <MultiSelect
      options={webFormOptions}
      standards={selectedOverviewWebform}
      handleChange={e=>props.searchFilter(e,'selectedOverviewWebform')}
      isMulti={true} />
      </reactbootstrap.Col>
      </reactbootstrap.Col>
      </reactbootstrap.Row>
      <reactbootstrap.Row className="mt-1">
      <reactbootstrap.Table responsive bordered hover>
      <thead style={{ backgroundColor: '#EC661C', color: '#fff', position: 'sticky', top: '0', textAlign: 'center' }}>
      <tr style={{ textAlign: 'center' }}>
      <th>{t('Images')}</th>
      <th>{t('User')}</th>
      <th>{t('Date and time')}</th>
      <th>{t('Co-ordinates')}</th>
      <th>{t('Items')}</th>
      {/**<th>{t('Linked webform')}</th>*/}
      <th>{t('Actions')}</th>
      </tr>
      </thead>
      <tbody>
      {items && items.map(value=>{
        let css2 = clonedData===true && (latestRowId === value.id) ? '#feb389' : css;
        return <tr style={{backgroundColor: css2 ,textAlign:'center'}} >
        <td><span><img src={value.filePath} onClick={e=>props.openClosePreviewFromOvervirview(value)} style={{ width: '5rem' }}/></span></td>
        <td>{value.userName}</td>
        <td>{value.updated_at}</td>
        {value.gp_linked ===1 &&<td><a href="#" style={{color:'green'}} onClick={e=>props.navigateToGpByOverview(value)}>{t('Linked to groundplan')}</a></td>}
        {value.gp_linked ===0 &&<td><a href="#" style={{color:'red'}} onClick={e=>props.navigateToGpByOverview(value)}>{t('Not yet linked')}</a></td>}
        <td><i title={t("Link picture to another webform")} style={{ 'cursor': 'pointer',float:'right'}} className="webform-sprite webform-sprite-createlistc" onClick={e=>props.navigateToAddItemImageCroping(value)}/>{getItems(value,value.items)}</td>
        {/**<td>{value.WebformId>0?<a href="#" style={{color:'green'}} onClick={e=>props.navigateToAddWebformByOverview(value)}>{value.webFormCode}-{value.webFormName}-{value.webFormVersion}</a>:<a href="#" style={{color:'red'}} onClick={e=>props.navigateToAddWebformByOverview(value)}>{t('Not yet linked')}</a>}</td>*/}
        <td style={{textAlign:'-moz-center'}}><span style={{ paddingLeft: '10px', paddingRight: '10px' }}><i title={t("Clone")} class="dashboard-tiles  dashboard-tiles-clone" onClick={(e) => props.cloneImageData(value)}></i></span><i title={t("Delete")} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={e=>props.deleteImageOverallDataById(value.id)}/></td>
        </tr>})}
        </tbody>
        </reactbootstrap.Table>
        <div className="mb-5">
        <Paginator count={count} active={active} changePage={(e)=>props.changePage(e)} css={css} size="md"/>
        </div>
        </reactbootstrap.Row>
        </>
      )
    }
    export default translate(ArImageOverView);
