import React, {useState, useEffect } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { store } from '../store';
import { OCAlert } from '@opuscapita/react-alerts';
import { datasave } from '../_services/db_services';
import ImageCropper from '../Imageprocessing/ImageCropper';

const ItemPopUp = (props) => {
  const t = props.t;
  const [state, setState] = useState({
    currentItemName : props.itemData.item_name,
    disableCroping  : true,
    overViewItemData: props.itemData,
    fromZones: 0,
  });

  useEffect(()=>{
    getOverviewRowData();
  },[])

  const getOverviewRowData = () => {
    let overviewData = props.overviewData;
    let rowData = overviewData.filter(val => props.rowId === val.id);
    let overViewData = {
      ...props.itemData,
      filePath: window.backendURL+rowData[0].filePath,
      itemName: props.itemData.item_name,
      WebformId: props.itemData.webform_id,
      mainOrItem: props.itemData.main_or_item,
      refId: props.itemData.ref_id,
      json_data:JSON.parse(props.itemData.json_data),
      status:props.itemData.status,
    }
    setState({...state, overViewItemData: overViewData, filePath: overViewData.filePath, fromZones:1 });
  }

  const saveAddItemFromOverview = () => {
    const {currentItemName} = state;
    if(currentItemName.length<1){
      OCAlert.alertWarning(t('Item name is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }
    updateCroppedItem();
  }

  async function updateCroppedItem(){
    const userdata = store.getState();
    let loginPerson_Id = userdata.UserData.user_details.person_id;
    const {currentItemName, overViewItemData} = state;
      overViewItemData['user_id']=loginPerson_Id;
      overViewItemData['itemName']=currentItemName;
      overViewItemData['json_data'] = overViewItemData.json_data;
      overViewItemData['WebformId'] = overViewItemData.webform_id;
      await datasave.service(window.UPDATE_CROPPED_IMAGE_ITEM,'POST',overViewItemData)
      .then(response => {
        if (response['status'] === 200) {
          OCAlert.alertSuccess(t('Item saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
          props.closePopUp(state.currentItemName, overViewItemData.id);
        } else {
          OCAlert.alertWarning(t('Something went wrong please try again later'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
      })
  }

  const onChangeCrop=(base64Data,regionsData)=>{

  }
  return(
  <>
    {state.fromZones === 1 &&
     <ImageCropper
       src={state.filePath}
       cropedData={onChangeCrop}
       disableCroping={state.disableCroping}
       cropingData={state.disableCroping?state.overViewItemData.json_data:[]}
       fromZones={state.fromZones}
    />}
    <reactbootstrap.Row>
      <reactbootstrap.Col className='col-md-12 row'>
        <reactbootstrap.FormLabel className='col-md-4 mt-2' style={{color: '#EC661C'}}>{t('Item name')}</reactbootstrap.FormLabel>
        <reactbootstrap.FormControl
          className="col-md-8 m-0 p-0"
          type='text'
          onChange={(e) => setState({...state, currentItemName: e.target.value })}
          value={state.currentItemName} />
      </reactbootstrap.Col>
    </reactbootstrap.Row>
    <div style={{float:'right', marginTop:'15px'}}>
      <reactbootstrap.Button style={{ marginRight:'10px' }} onClick={e => props.closePopUp()}>{t('Cancel')}</reactbootstrap.Button>
      <reactbootstrap.Button onClick={e => saveAddItemFromOverview()}>{t('Save')}</reactbootstrap.Button>
    </div>
   </>
 )
}

export default translate(ItemPopUp);
