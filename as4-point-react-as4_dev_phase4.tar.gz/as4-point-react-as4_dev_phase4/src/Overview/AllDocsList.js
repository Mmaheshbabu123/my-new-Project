import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Layouts from '../Layouts/Layouts';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { translate } from '../language';
import { PagePermissions } from '../_components/CanComponent/PagePermissions';
import Pagination from 'react-bootstrap/Pagination';
import AllTagsCoupledToDocs from '../Overview/AllTagsCoupledToDocs';
import '../Layouts/LayoutsList.css'

//import { threadId } from 'worker_threads';

const KEYS_TO_FILTERS = ['name', 'id']
class AllDocsList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            component: 'true',
            componentState:'',
            layouts: [],
            active: 1,
            searchTerm: '',
            page: 5,
            items: [],
            _1stLayout: undefined,
            fcurrentPage: 1,
            mcurrentPage: 1,
            scurrentPage: 1,
            currentPage: 1,
            tabId: '',
            id: '',
            count: 0,
            filterFullList: [],
            t: props.t,
            alert: '',
            falert: '',
            malert: '',
            doc_data: [],
            folder_data: [],
            manual_data: [],
            showpopup: '',
            todosPerPage: 5,
            didupdate : '0'

        }
        this.changeComponent = this.changeComponent.bind(this);
        this.searchData = this.searchData.bind(this);
    }
    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.layouts;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;

    }
    componentDidMount() {
      const notify = null;
      datasave.service(window.GET_DOCS_OVERVIEW , 'GET')
          .then(response => {
              if (response !== null) {
                  const pageData = this.getPageData(this.state.active, response);
                  const count = this.getCountPage(response);
                  this.setState({
                      layouts: response,
                      count: count,
                      items: pageData,
                      _1stLayout: response[0].id,
                      editBtnStatus: 'true',
                      componentState : 'open',
                      component:'false',

                  })
              }
              else {
              }
          });
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }
    changePage(e, id = 1) {
        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });
    }
    updateComponent(e) {
        if (e) {
            this.componentDidMount();
            this.setState({
                component: 'false',
                saveComponent: 1,
            })
        }
        this.props.tab(false);
    }
    update(e) {
        if (e !== this.state.tabId) {
            this.setState({
                tabId: e,
            });
        }
    }

    changeComponent(e, id) {
        this.setState({
            component: 'true',
            formId: (id !== '') ? id : '',
            editBtnStatus: 'false'

        });
        this.props.tab(true);
    }
    handlepopok() {
        this.setState({ didupdate: '1' })
        const { popid, doc_data } = this.state;

        const url = window.DELETE_LAYOUT_DATA + popid;
        datasave.service(url, 'put').then(
            response => {
                if(response === 'sucess')
                {
                   this.componentDidMount();
                }

            if (this.state.items.length - 1 == 0) {
                this.state.active = this.state.active - 1;
            }
        }
        )
        this.setState({ show: false, showpopup: '' })
    }

    handleLayoutClick(layoutid) {
        this.setState({
            // showlayoutpop: true,
            // layoutpop: layoutid,
            _1stLayout: layoutid,
            component: false,
        })
    }
    updateComponentCancel(e) {

        if (e) {

            this.setState({
                component: 'false',
                saveComponent: 1,
            })
        }
    }
    handlePageClick(event) {
        this.setState({
            currentPage: Number(event.target.id)
        });
    }
    searchData(e) {
        var list = [...this.state.layouts];
        list = list.filter(function (item) {
            if (item.name !== null) {
                return item.name.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
        });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    render() {
        const as4_or_site = 1;//PagePermissions()
        const { layouts, doc_data, folder_data, manual_data, currentPage, todosPerPage, fcurrentPage, mcurrentPage, falert, malert, alert, showpopup, t, folders } = this.state;
        const indexOfLastTodo = currentPage * todosPerPage;
        const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
        const currentTodos = this.state.doc_data.slice(indexOfFirstTodo, indexOfLastTodo);
        const pagerender =  <tr >
                <td>{doc_data.dname}</td>
                <td>{doc_data.dcode}</td>
                <td>{doc_data.version}</td>
                <td>{doc_data.fname}</td>
                <td>{doc_data.fcode}</td>
                <td>{doc_data.mname}</td>
            </tr>


        // let active = this.state.active;
        const pageNumbers = [];
        for (let i = 1; i <= Math.ceil(doc_data.length / todosPerPage); i++) {
            pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
                {i}
            </Pagination.Item>);
        }
        const filtered = this.state.items;
        let active = this.state.active;
        let pages = [];
        if (this.state.count > 0) {
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }
        }

        if (as4_or_site) {
            return (
                <Can
                    perform="E_layout,R_layout,D_layout"
                    yes={() => (
                        <div className='container py-4'>
                            <div className="row" >

                                <reactbootstrap.Col lg={4} >
                                <div>
                                <h3 className="">{t('Documents')}</h3>
                                </div>
                                <hr></hr>
                                <div style={{display: 'flex'}} >
                                  <input  className="form-control search-box-border  mb-2" Placeholder={t("Search")} onChange={this.searchData} /><br />

                                </div>
                                    <div className='card'>
                                        <reactbootstrap.Table style={{ marginBottom: '0px' }} responsive bordered hover className="main-data-table">
                                            <thead>
                                                <tr style={{backgroundColor: '#EC661C', color: '#fff'}}>
                                                    <th>{t('Documents')}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {layouts.length == 0 && <div>{t('No records found')}'</div>}
                                                {/* {layoutsdata} */}
                                                {filtered.map(layouts => {
                                                    let className = (layouts.id === this.state._1stLayout) ? 'active' : 'inactive';

                                                    return (<tr style={{}} >
                                                        <td className={className} style={{ hover: 'color:#007bf8', cursor: "pointer", }}  ><p style={{ margin: '0px' }} onClick={(e) => this.handleLayoutClick(layouts.id)} >{layouts.name} </p></td>
                                                    </tr>
                                                    )
                                                })
                                                }

                                            </tbody>
                                        </reactbootstrap.Table>
                                    </div>
                                    <div className='text-center mt-3'  style={{width: '97%', overflowX: 'auto'}}>
                                        {pages.length > 1 && <Pagination size="md">{pages}</Pagination>}
                                    </div>
                                </reactbootstrap.Col>
                                {this.state.component !== 'true' && <reactbootstrap.Col lg={8}> <h3 className="">{t('Coupled tags')}</h3><hr /><AllTagsCoupledToDocs update={this.update.bind(this)} refId={this.state._1stLayout} /></reactbootstrap.Col>}
                            </div>
                        </div>
                    )}
                    no={() =>
                        <AccessDeniedPage />
                    }
                />
            );
        }
        else {
            return (
                <AccessDeniedPage />
            )
        }
    }
}

export default translate(AllDocsList);
{/* <i class="overall-sprite overall-sprite-layoutc"></i>
<i class="overall-sprite overall-sprite-layoutcc"></i>
<i class="layout-template layout-template-template"></i>
<i class="layout-template layout-template-templatec"></i> */}
