import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import {translate} from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import { PagePermissions } from '../_components/CanComponent/PagePermissions';
import Pagination from 'react-bootstrap/Pagination';
import './AllDocs.css';
//implement list Layout
class AllSpaceCoupledToDocs extends Component {
    constructor(props) {
        super(props)
        this.state = {
            layout_linked_docs: [],
            todosPerPage: 5,
            currentPage: 1,
            active: 1,
            count: 0,
            items: [],
            page: 5,
            t:props.t,
        }
    }
    getPageData(id, list = '') {


        const page = this.state.page;
        const items = (list !== '') ? list : this.state.layout_linked_docs;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;

    }
    componentDidMount() {
      const {t} = this.state;
      let details ={
        ref_id : this.props.refId,
      }
        datasave.service( window.GET_SPACES_AS_PER_DOC, 'POST', details)
        .then(response => {
              if(response !== []) {
                const pageData = this.getPageData(1, response);
                const count = this.getCountPage(response);
                this.setState({ layout_linked_docs: response, count: count, items: pageData, });
              }
              else {
                OCAlert.alertError(t("Could not able to fetch the overview"), { timeOut: window.TIMEOUTNOTIFICATION});
                //   alert("Couldn't able to update the what's new tile");
              }
        });
    }
    componentDidUpdate(prevProps, prevState) {
      const {t} = this.state;
      let details ={
        ref_id : this.props.refId,
      }
        if (this.props.refId !== prevProps.refId){
          datasave.service(window.GET_SPACES_AS_PER_DOC  , 'POST', details)
          .then(response => {
                if(response !== []) {
                  const pageData = this.getPageData(1, response);
                  const count = this.getCountPage(response);
                  this.setState({ layout_linked_docs: response, count: count, items: pageData, });
                }
                else {
                  OCAlert.alertError(t("Could not able to fetch the overview"), { timeOut: window.TIMEOUTNOTIFICATION});
                  //   alert("Couldn't able to update the what's new tile");
                }
          });
        }
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }

    changePage(e, id = 1) {
        // const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const list = this.state.LayoutLinkedDocs;
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });
    }

    render() {
        const { layout_linked_docs,t } = this.state
        const items = this.state.items;
        const layouts = items.map(function (data) {
            return (

                <tr key={data.id}>
                    <td>{data.name}</td>
                </tr>
            )
        });

        let active = this.state.active;
        let pages = [];
        if (this.state.count > 0)
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }



        return (
            <div >
                <reactbootstrap.Table striped bordered hover variant="dark" >
                    <thead className="layoutlinked-header">
                        <tr>
                            <th>{t('Space name')}</th>
                        </tr>
                    </thead>
                    <tbody className="layoutlinked-body">
                        {layouts}

                    </tbody>

                </reactbootstrap.Table>
                <div style={{ textAlign: 'center' }} className="mt-3">
                    {layout_linked_docs.length == 0 && <span className=" records ext-center" >{t('No Records!')}'</span>}
                </div>
                <div className='text-center' style={{ width: '50%', overflowX: 'auto' }}>
                    {pages.length > 1 && <Pagination size="md" active={this.state.active}>{pages}</Pagination>}
                </div>
            </div>
        );
    }
}
export default translate(AllSpaceCoupledToDocs);
