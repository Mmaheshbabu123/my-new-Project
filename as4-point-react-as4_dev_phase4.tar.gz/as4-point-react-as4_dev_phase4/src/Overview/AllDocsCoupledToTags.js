import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import {translate} from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import {SearchFilter}from '../SearchFilter';
class AllDocsCoupledToTags extends Component {
  constructor(props) {
    super(props)
    this.state = {
      col_name : null,
      layout_linked_docs: [],
      todosPerPage: 5,
      currentPage: 1,
      active: 1,
      count: 0,
      items: [],
      page: 5,
      fcurrentPage: 1,
      mcurrentPage: 1,
      scurrentPage: 1,
      tabId: '',
      id: '',
      filterFullList: [],
      t: props.t,
      alert: '',
      falert: '',
      malert: '',
      doc_data: [],
      folder_data: [],
      manual_data: [],
      showpopup: '',
      didupdate : '0',
      dummyitems : [],
      columnDefs : [
        {"headerName" : "id"},
        {"headerName" : "Code"},
        {"headerName" : "Name"},
        {"headerName" : "Version"},
        {"headerName" : "tag_name"},
      ],
      documentname:'',
      documentcode:'',
      documentversion:'',
      changingColumn:'',
      copyItems:[],
    };
    this.exportXLS = this.exportXLS.bind(this);
  }
    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.layout_linked_docs;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;
    }
    componentDidMount() {
      const {t} = this.state;
        let url = null;
        let col_name : null;
        switch (this.props.type) {
          case '6':
                   url = window.GET_ALL_DOCS_AND_TAGS_COUPLED ;
                   col_name = 'Tag_name';
                   break;
          case '4' :
                    url = window.GET_ALL_DOCS_AND_STANDARDS_COUPLED;
                    col_name = 'Standard_name';
                    break;
          case '5' :
                    url = window.GET_ALL_DOCS_AND_SPACES_COUPLED;
                    col_name = 'Space_name';
        }
        datasave.service( url , 'GET')
        .then(response => {
              if(response !== []) {
                this.setState({ layout_linked_docs: response, items: response, dummyitems: response, col_name : col_name});
              }
              else {
                OCAlert.alertError(t("Could not able to fetch the overview"), { timeOut: window.TIMEOUTNOTIFICATION});
              }
        });
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }

    changePage(e, id = 1) {
        const list = this.state.LayoutLinkedDocs;
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });
    }
    searchData=async (e)=> {
      const {name,value} = e.target;
      const {items,dummyitems } = this.state;
      if(e.key !== "Delete" || e.key !== "Backspace"){
        let stateName = this.getStateName(name);
        let docItems = await SearchFilter.filterItemByColumn(Object.values(items), name, value, dummyitems);
        if((docItems.length<1 && value=='') || docItems.length<1){
          docItems = Object.values(items);
          this.setState({
            documentcode:'',
            documentname:'',
            documentversion:'',
            changingColumn:'',
          })
        }
        else{
          this.setState({[stateName]: value})
        }
        this.setState({
          dummyitems:docItems
        });
      }
    }
    getStateName = targetname =>{
      switch (targetname) {
        case 'Documentname':
          return 'documentname';
          break;
          case 'Documentcode':
          return 'documentcode';
          break;
          case 'Documentversion':
          return 'documentversion';
          break;
          case this.state.col_name:
          return 'changingColumn';
          break;
      }
    }
      onKeyUp =async e=>{
        const {documentname, documentcode, documentversion, changingColumn, items} = this.state;
        var docItems =[];
        if(e.key === "Delete" || e.key === "Backspace") {
          var filledStates = await this.getStates(documentname, documentcode, documentversion, changingColumn);
          docItems =  await SearchFilter.getData(filledStates, Object.values(items));
          this.setState({
            dummyitems:docItems
          });
        }
      }
    getStates = (col1, col2, col3, col4) =>{
      var arr=[]
      if(col1!='') {
        arr.push({name:'Documentname',value:col1});
      }
      if(col2!='') {
        arr.push({name:'Documentcode',value:col2});
      }
      if(col3!='') {
        arr.push({name:'Documentversion',value:col3});
      }
      if(col4!='') {
        arr.push({name:this.state.col_name,value:col4});
      }
      return arr;
    }
    getColumnsDefs() {
      const {col_name} = this.state;
      return  ([
          {"key" : "Documentname","name" :"Documentname"},
          {"key" : "Documentversion","name" : "Documentversion"},
          {"key" : "Documentcode","name" :"Documentcode"},
          {"key" :col_name,"name" :col_name},
      ])
    }
    exportXLS() {
        var data = {};
        data.columnDefs = this.getColumnsDefs();
        data.rowData = this.state.dummyitems.length !== 0 ? this.state.dummyitems : this.state.layout_linked_docs;
        datasave.service('/api/generatefile', "POST", data)
            .then(response => {
                var a = document.createElement("a");
                a.setAttribute("type", "file");
                a.href = response.file;
                a.download = response.name;
                document.body.appendChild(a);
                a.click();
                a.remove();
            });
    }
    render() {
        const { layout_linked_docs,col_name,t,documentcode,documentname,documentversion , changingColumn} = this.state
        let col_name_abbr = null;
        if(col_name === "Tag_name")
          col_name_abbr = "Tags";
        else if(col_name === "Standard_name")
          col_name_abbr ="Standards";
        else if(col_name === "Space_name")
          col_name_abbr ="Spaces";
        let items = this.state.dummyitems;
        let finallist = [];
         finallist = Object.values(items).map(function (data) {
            return (
                <tr key={data.id}  style={{width:'auto',textAlign:'center'}}>
                    <td>{data.Documentname}</td>
                    <td>{data.Documentversion}</td>
                    <td>{data.Documentcode}</td>
                    <td>{data[col_name]}</td>
                </tr>
            )
        });
        return (
            <div className="alldocs" >
            <div style={{overflowX:'auto',overflowY:'auto',height:"430px"}}>
                <reactbootstrap.Table striped bordered hover  variant="dark" >
                    <thead style={{position: 'sticky',top: '0',textAlign:'center'}} className="col-12 layoutlinked-header">
                        <tr>
                            <th>{t('Document name')}</th>
                            <th>{t('Document version')}</th>
                            <th>{t('Document code')}</th>
                            <th >{col_name_abbr?t(col_name_abbr):t('')}</th>
                        </tr>
                        <tr>
                            <th><input type="text" className="form-control search-box-border "  placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name = 'Documentname' value = {documentname} onChange={this.searchData} onKeyUp={this.onKeyUp} /></th>
                            <th><input type="text" className="form-control search-box-border "  placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name = 'Documentversion' value = {documentversion} onChange={this.searchData} onKeyUp={this.onKeyUp}/></th>
                            <th><input type="text" className="form-control search-box-border "  placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name = 'Documentcode' value = {documentcode} onChange={this.searchData} onKeyUp={this.onKeyUp}/></th>
                            <th><input type="text" className="form-control search-box-border "  placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name = {this.state.col_name} value ={ changingColumn} onChange={this.searchData} onKeyUp={this.onKeyUp}/></th>
                        </tr>
                    </thead>
                    <tbody className="layoutlinked-body">
                    {finallist.length<1 &&<tr><td colspan='7' style={{color:'grey',textAlign:'center'}}>{t('No records found')}</td></tr>}
                        {finallist.length >0 &&  finallist}
                    </tbody>
                </reactbootstrap.Table>
                </div>
                {/** <div style={{ textAlign: 'center' }} className="mt-3">
                   {layout_linked_docs.length == 0 && <span className=" records ext-center">{t('No Records!')}'</span>}
                </div>*/}
                <reactbootstrap.Button className='mb-2' style={{marginTop:'10px',float:'right',marginRight:'3px'}}onClick={() => this.exportXLS()}>{t('Export XLS')}</reactbootstrap.Button>
            </div>
        );
    }
}
export default translate(AllDocsCoupledToTags);
