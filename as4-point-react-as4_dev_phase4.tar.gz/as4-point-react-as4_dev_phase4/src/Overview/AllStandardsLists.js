import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Layouts from '../Layouts/Layouts';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { translate } from '../language';
import { PagePermissions } from '../_components/CanComponent/PagePermissions';
import Pagination from 'react-bootstrap/Pagination';
import AllDocsCoupledToTags from '../Overview/AllDocsCoupledToTags';
import '../Layouts/LayoutsList.css'

//import { threadId } from 'worker_threads';

const KEYS_TO_FILTERS = ['name', 'id']
class AllStandardsList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            component: 'true',
            componentState:'',
            layouts: [],
            active: 1,
            searchTerm: '',
            page: 5,
            items: [],
            _1stLayout: undefined,
            fcurrentPage: 1,
            mcurrentPage: 1,
            scurrentPage: 1,
            currentPage: 1,
            tabId: '',
            id: '',
            count: 0,
            filterFullList: [],
            t: props.t,
            alert: '',
            falert: '',
            malert: '',
            doc_data: [],
            folder_data: [],
            manual_data: [],
            showpopup: '',
            todosPerPage: 5,
            didupdate : '0'

        }
        this.changeComponent = this.changeComponent.bind(this);
        this.searchData = this.searchData.bind(this);
    }
    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.layouts;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;

    }
    componentDidMount() {
      const notify = null;
      datasave.service(window.GET_STANDARDS_OVERVIEW, 'GET')
          .then(response => {
              if (response !== null) {
                  const pageData = this.getPageData(this.state.active, response);
                  const count = this.getCountPage(response);
                  this.setState({
                      layouts: response,
                      count: count,
                      items: pageData,
                      _1stLayout: response[0].id,
                      editBtnStatus: 'true',
                      componentState : 'open',
                      component:'false',

                  })
              }
              else {
              }
          });
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }
    changePage(e, id = 1) {
        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });
    }
    updateComponent(e) {
        if (e) {
            this.componentDidMount();
            this.setState({
                component: 'false',
                saveComponent: 1,
            })
        }
        this.props.tab(false);
    }
    update(e) {
        if (e !== this.state.tabId) {
            this.setState({
                tabId: e,
            });
        }
    }

    changeComponent(e, id) {
        this.setState({
            component: 'true',
            formId: (id !== '') ? id : '',
            editBtnStatus: 'false'

        });
        this.props.tab(true);
    }
    handlepopok() {
        this.setState({ didupdate: '1' })
        const { popid, doc_data } = this.state;

        const url = window.DELETE_LAYOUT_DATA + popid;
        datasave.service(url, 'put').then(
            response => {
                if(response === 'sucess')
                {
                   this.componentDidMount();
                }

            if (this.state.items.length - 1 == 0) {
                this.state.active = this.state.active - 1;
            }
        }
        )
        this.setState({ show: false, showpopup: '' })
    }

    handleLayoutClick(layoutid) {
        this.setState({
            // showlayoutpop: true,
            // layoutpop: layoutid,
            _1stLayout: layoutid,
            component: false,
        })
    }
    updateComponentCancel(e) {

        if (e) {

            this.setState({
                component: 'false',
                saveComponent: 1,
            })
        }
    }
    handlePageClick(event) {
        this.setState({
            currentPage: Number(event.target.id)
        });
    }
    searchData(e) {
        var list = [...this.state.layouts];
        list = list.filter(function (item) {
            if (item.name !== null) {
                return item.name.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
        });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    render() {
      const {t} = this.state;
      return (
        <div className='container py-4'>
          <div className="row  mb-4" >
            <reactbootstrap.Col lg={12}> <h3 className="">{t('Docs & standards overview')}</h3><hr /><AllDocsCoupledToTags update={this.update.bind(this)} tagId={this.state._1stLayout} type ={'4'}/></reactbootstrap.Col>
            </div>
          </div>
      )
  }
}

export default translate(AllStandardsList);
{/* <i class="overall-sprite overall-sprite-layoutc"></i>
<i class="overall-sprite overall-sprite-layoutcc"></i>
<i class="layout-template layout-template-template"></i>
<i class="layout-template layout-template-templatec"></i> */}
