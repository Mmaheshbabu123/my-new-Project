import React, { Component } from 'react';
import { Button, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import { Input, Label } from 'reactstrap';
import { datasave } from './_services/db_services';
import MultiSelect from './_components/MultiSelect';
import legalform from './legal_form.json';
import fte from './fte.json';
import timezone from './timezone.json';
import FileUpload from './_components/FileUpload/FileUpload';
import Can from './_components/CanComponent/Can';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import validator from 'validator';
import { translate } from './language';
import { OCAlert } from '@opuscapita/react-alerts';
import { Tabs, Tab } from 'react-bootstrap';
import * as reactbootstrap from 'react-bootstrap';
import LoginScreenLayout from './LoginScreenLayout';


// const path = require('path')
class Site extends Component {
  constructor(props) {
    super(props)
    this.siteDetials = window ?.siteDetials ?? {};
    this.state = {
      save: props.t('Save'),
      savevalue: 'true',
      name: '',
      // sitedescription: '',
      logo: [],
      errors: [],
      package_id: '',
      country_details: '',
      time_zone: timezone[42]['text'],
      location_id: '',
      language_id: 'en',
      select_database: '',
      industry_id: '',
      no_of_sites: '',
      packages_data: [],
      locations_data: [],
      industry_data: [],
      sucess: '',
      formvalid: true,
      file_name: props.t('Choose File'),
      organisation_details: [],
      default: () => [],
      organisationList: [],
      siteList: [],
      blancoList: [],
      standards: [],
      legalform: legalform,
      fte_form: fte,
      language: [],
      industries_data: [],
      industry: '',
      industry_sub_data: [],
      multiIndustry: [],
      multipersons: [],
      time_zone_list: timezone,
      edit_img: '',
      parentsite: '',
      hostname: process.env.REACT_APP_baseURL,
      protocol: window.location.protocol,
      name_error: '',
      site: '',
      telephone: '',
      website: '',
      siteid: '',
      persons: [],
      getpersonsUrl: window.GET_Active_nd_Archive,
      siteowner: '',
      clone_siteowner:[],
      // subdescription : '',
      no_of_sites: '',
      siteListlength: '',
      siteerror: '',
      loading: false,
      required: false,
      file_id: '',
      sitename: '',
      email_error: '',
      mulistandards: [],
      t: props.t,
      stdList: [],
      duplicatestandards:[],
      multipersonsduplicate: [],
      multistandradsduplicate : [],
      sandboxstandards : [],
      sandboxblanco : [],
      sandboxstdlist : [],
      standard_error : '',
      activeTab: 1,
      activePersonsTab: 1,
      activeUsers: [],
      archivedUsers: [],
      as4Users: [],
      designObject: {
          main_text     : this.siteDetials['main_text']
        , sub_text      : this.siteDetials['sub_text']
        , color         : this.siteDetials['color']
        , login_logo    : this.siteDetials['login_logo']
        , logo_width    : this.siteDetials['logo_width']
        , logo_height   : this.siteDetials['logo_height']
      },
    }
    this.handleChangeMultiStandard = this.handleChangeMultiStandard.bind(this);
    this.handleChangeSector = this.handleChangeSector.bind(this);
    this.handleChangeMultiIndustry = this.handleChangeMultiIndustry.bind(this);
    this.handleTelephoneChange = this.handleTelephoneChange.bind(this);
    this.handleWebsiteChange = this.handleWebsiteChange.bind(this);
    this.handleChangeOrganisation = this.handleChangeOrganisation.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleChangeName = this.handleChangeName.bind(this);
    this.handleChangeMultiPersons = this.handleChangeMultiPersons.bind(this);
    this.handleChangeMultiStandards = this.handleChangeMultiStandards.bind(this);
    this.handleSandboxblanco = this.handleSandboxblanco.bind(this);
    this.handleSandboxStandards = this.handleSandboxStandards.bind(this);
    this.handleTabSelect = this.handleTabSelect.bind(this);
    this.handlePersonsSelect = this.handlePersonsSelect.bind(this);
    // this.handleChangeEmail = this.handleChangeEmail.bind(this);
  }

  componentDidMount() {
    const { t } = this.state;
    var url = window.PERSONS;
    datasave.service(url, 'GET', '')
      .then(response => {
        this.setState({
          persons: response['Active'],
        })
      });
    const data = {
      id: this.props.id,
      // editid: this.props.editid
    }
    datasave.service(window.GET_BLANCO, 'GET')
      .then(result => {
        this.setState({
          blancoList: result
        })
      });
    if (data.id != undefined) {
      datasave.service(window.GET_PARENT_NAME, 'post', data)
        .then(result => {
          if (result[0]['id']) {
            this.setState({
              parentsite: result[0]['id']
            })
          }
        })
      datasave.service(window.GET_ORGANISATION_SITES, 'post', data)
        .then(response => {
          this.setState({
            siteList: response['site'],
            siteListlength: response['site'].length,
            // blancoList: response['blanco']
          })
          // }
        })
      datasave.service(window.GET_NO_OF_SITES, 'POST', data)
        .then(response => {
          this.setState({
            no_of_sites: response[0]['no_of_sites']
          })
        })
    }
    const details = {
      id: this.props.editid
    }
    if (details.id != undefined) {
      datasave.service(window.GET_SITE_DETAILS, 'post', details)
        .then(response => {
          let as4ActiveUsers = response.sitePersons ? (response.sitePersons.Active ? (response.sitePersons.Active.filter(item => (item.as4member == 1))) : []) : [];
          let as4ArchiveUsers = response.sitePersons ? (response.sitePersons.Archived ? (response.sitePersons.Archived.filter(item => (item.as4member == 1))) : []) : [];
          let as4RoleUsers = as4ActiveUsers.concat(as4ArchiveUsers);
          this.setState({
            siteList: response['site'],
            sitename: response['name'][0]['name'],
            // sitedescription: response['name'][0]['description'],
            legal_form: response['name'][0]['legal_form'],
            fte: response['name'][0]['fte'],
            // logo: this.state.logo,
            activity: response['name'][0]['activity'],
            vatnumber: response['name'][0]['vatnumber'],
            telephone: response['name'][0]['telephone'],
            fax: response['name'][0]['fax'],
            email: response['name'][0]['email'],
            website: response['name'][0]['website'],
            address: response['name'][0]['address'],
            // organisation
            parentsite: response['name'][0]['parentsite'],
            standards: response['blanco'],
            country_details: response['name'][0]['country_details'],
            // no_of_sites: this.state.no_of_sites,
            time_zone: response['name'][0]['time_zone'],
            location_id: response['name'][0]['location_id'],
            language_id: response['name'][0]['language_id'],
            industry: response['name'][0]['industry'],
            multiIndustry: response['sub_sector'],
            site: response['name'][0]['orgsite'],
            siteowner: response['name'][0]['siteowner'],

            // subdescription : response['name'][0]['subdescription'],
            file_name: response['name'][0]['logo'] ? response['name'][0]['logo'] : this.state.file_name,
            edit_img: response['name'][0]['logo'] ? t('Click here for preview') : '',
            logo: response['name'][0]['logo'],
            multipersons: response['persons'],
            clone_siteowner:response['persons'],
            mulistandards: response['standards'],
            multipersonsduplicate : response['persons'],
            multistandradsduplicate : response['standards'],
            duplicatestandards:response['blanco'],
            sandboxstdlist : response['sandboxstandards'],
            sandboxblanco : response['sandboxblanco'],
            required: true,
            activeUsers: response.sitePersons.Active ? (response.sitePersons.Active ? (response.sitePersons.Active.filter(item => (item.as4member != 1))) : []) : [],
            archivedUsers: response.sitePersons.Archived ? (response.sitePersons.Archived ? (response.sitePersons.Archived.filter(item => (item.as4member != 1))) : []) : [],
            as4Users: as4RoleUsers,
            designObject: response['designObject'] && Object.keys(response['designObject']).length ? response['designObject'] : this.state.designObject,
          })
          this.getStandards(response['blanco'],'stdList');
          this.getStandards(response['sandboxblanco'],'sandboxstandards')

          // if(response['name'][0]['file']){
          //   this.setState({
          //   file_name :response['name'][0]['file']
          // })
          // }
          // if(this.state.file_name){
          //   this.setState({
          //   edit_img :response['name'][0]['file']? 'Click here preview':'',
          // })
          // }


        })
    }
    // datasave.service(window.GET_STANDARDS, 'GET')
    //   .then(result => {
    //     this.setState({
    //       stdList: result
    //     })
    //   })

    datasave.service(window.GET_ORGANISATION, 'GET')
      .then(result => {
        this.setState({
          organisationList: result
        })
      });
    // datasave.service(window.GET_BLANCO, 'GET')
    //   .then(result => {
    //     this.setState({
    //       blancoList: result
    //     })
    //   });


    datasave.service(window.GET_ALL_LANGUAGES, 'GET')
      .then(response => {
        this.setState({
          language: response
        });
      });
    datasave.service(window.sectors, 'GET')
      .then(response => {
        this.setState({
          industries_data: response
        })
      })
    datasave.service(window.sectorslist, 'GET')
      .then(response => {
        this.setState({
          industries: response
        })
      })

  }
  getOptionItems() {
    let temp = [];
    if (this.state.organisationList.length >= 1) {
      if (this.state.organisationList) {
        temp = this.state.organisationList.map((org) => {
          return (<option id={org.id} value={org.id} >{org.name}</option>)
        }
        );
        return temp;
      }
    }
  }
  getStandards(blancos,name) {
   const details = {
     blancos: blancos
   }
   datasave.service(window.GET_SITE_STANDARDS, 'POST', details)
     .then(result => {
       this.setState({
         [name]: Object.values(result)
       })
     })

 }
  getBlancoOptionItems() {
    let temp = [];
    if (this.state.blancoList.length >= 1) {
      if (this.state.blancoList) {
        temp = this.state.blancoList.map((blanco) => {
          return (<option id={blanco.id} value={blanco.id} >{blanco.name}</option>)
        }
        );
        return temp;
      }
    }
  }

  handleChangeMultiStandard(event) {
    this.handlePreviousvalues(event,this.state.duplicatestandards,"standards",'blanco(s)')

    // if (event.target == undefined) {
    //   const { value } = event;
    //   this.setState({
    //     standards: event,
    //     loading: false,
    //     stdList: []
    //   });
    // }
    if (event.length != 0) {
      this.getStandards(event,'stdList');
    //  const details = {
      //   blancos: event
      // }
      // datasave.service(window.GET_SITE_STANDARDS, 'POST', details)
      //   .then(result => {
      //     this.setState({
      //       stdList: result
      //     })
      //   })
    }
  }

  handleTelephoneChange(event) {
    event.preventDefault()
    if (/^(?:[0-9\b]*)$/.test(event.target.value)) {
      this.setState({
        telephone: event.target.value,
        loading: false
      })
    }
  }
  handleWebsiteChange(event) {
    event.preventDefault()
    if (/([^0-9a-zA-Z-])/.test(event.target.value)) {
    }
    else {
      this.setState({
        website: event.target.value,
        website_error: '',
        loading: false
      })

    }
  }
  handleChangeName(event) {
    this.setState({
      sitename: event.target.value,
      name_error: '',
      loading: false
    })
  }
  // handleChangeEmail(event){
  //   if(validator.isEmail(event.target.value)) {
  //     this.setState({
  //       email_error : ' '
  //     })
  //   }
  //   else{
  //     this.setState({
  //       email_error : 'Email is not valid'
  //     })
  //   }
  // }


  handleChange = (e) => {
    const { name, value } = e.target;
    if (e.target.files != null) {
      this.state.file_name = e.target.files[0];
      this.state.file_name = this.state.file_name['name'];
      this.state.sucess = window.FILE_UPLOAD_SUCCESS
      this.state.edit_img = ''
      let files = e.target.files || e.dataTransfer.files;
      if (!files.length)
        return;
      this.createImage(files[0]);
    }
    this.setState({
      [name]: value,
      name_error: '',
      loading: false
    });
    this.validateForm(name);
  }
  createImage(file) {
    let reader = new FileReader();
    reader.onload = (e) => {
      this.setState({
        logo: e.target.result
      })
    };
    reader.readAsDataURL(file);

  }
  handleCancel(event) {
    const { history } = this.props
    history.push('/managemyorganisation/managesite')
  }
  validateForm(fieldname) {
    switch (fieldname) {
      case 'sitename': console.log("validate");
        break;

    }
  }
  updateState = () => {
    this.setState({
      x: 2
    }, () => { return 1 })
  }
  handleSubmit = (event) => {
    const { t } = this.state;
    event.preventDefault()
    this.updateState();

    // this.setState({ emailvalid: true })
    this.setState({ submitted: true })

    const mandatoryfields = ['sitenanme'];
    mandatoryfields.forEach(element => {
      if (this.state[element] === '' || this.state[element] === undefined) {
        this.setState({ formvalid: false })
      }
    });
    this.validateForm();

    let newArr = this.state.multipersons.filter(x =>!this.state.clone_siteowner.some(y => y.value === x.value));


    const details = {
      name: this.state.sitename,
      // description: this.state.sitedescription,
      legal_form: this.state.legal_form,
      fte: this.state.fte,
      logo: this.state.logo,
      file_id: this.state.file_id,
      activity: this.state.activity,
      vatnumber: this.state.vatnumber,
      telephone: this.state.telephone,
      fax: this.state.fax,
      email: this.state.email,
      website: this.state.website,
      address: this.state.address,
      // organisation
      parentsite: this.state.parentsite,
      // site
      site: this.state.site,
      select_database: this.state.standards,
      country_details: this.state.country_details,
      // no_of_sites: this.state.no_of_sites,
      time_zone: this.state.time_zone,
      location_id: this.state.location_id,
      language_id: this.state.language_id,
      industry: this.state.industry,
      sub_industry: this.state.multiIndustry,
      website_error: '',
      siteowner: this.state.multipersons,
      editowner:newArr,
      website: this.state.website,
      sitestandards: this.state.mulistandards,
      hostname: this.state.hostname,
      protocol: this.state.protocol,
      sandboxstandards : this.state.sandboxstdlist,
      sandboxblanco : this.state.sandboxblanco,
      designObject: this.state.designObject,
      // subdescription : this.state.subdescription,

    }
    {/*    if (validator.isEmail(details.email)) {
      this.setState({
        email_error: ''
      })
*/}


    if (this.state.no_of_sites == this.state.siteListlength - 1) {
      this.setState({
        siteerror: t("You are not able to create the site under this organisation")
      })
    }
    else {
      if (this.props.editid) {
        const data = {
          id: this.props.editid,
          ref_type_id: 2,
          website: this.state.website
        }
        datasave.service(window.VALIDATE_WEBSITE, 'POST', data)
          .then(response => {
            if (response == 'Failure') {
              this.setState({
                website_error: t("this name has already taken"),
              })
            }
            else {
              const siteid = this.props.editid
              var url = window.UPDATE_SITE + '/' + siteid;
              this.setState({
                loading: true
              })
              if ((this.state.standards.length !== 0 && this.state.mulistandards.length === 0)||(this.state.sandboxstdlist.length==0&&this.state.sandboxblanco.length!==0)) {
                this.setState({
                  standard_error : "Required"
                })
              }
              else {
              if (this.state.multipersons.length !== 0  ) {
                datasave.service(url, 'PUT', details)
                  .then(response => {
                    if (response == 'Failure') {
                      this.setState({
                        name_error: t("this name has already taken"),
                      })
                    }
                    else {
                      if (response.name) {
                        this.setState({
                          name_error: response.name,
                          // no_of_sites_error: response.no_of_sites
                        })
                      }
                      else {
                        if (response == 'Sucess') {
                          const { history } = this.props
                          OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION })
                          history.push('/managemyorganisation/managesite')
                          window.location.reload();
                        }
                      }
                    }
                  })
              }
            }
            }
          });
      }
      else {
        const data = {
          website: this.state.website
        }
        this.setState({
          loading: true
        })
        datasave.service(window.VALIDATE_WEBSITE, 'POST', data)
          .then(response => {
            if (response == 'Failure') {
              this.setState({
                website_error: t("this name has already taken"),
              })
            }
            else {
              if ((this.state.standards.length !== 0 && this.state.mulistandards.length === 0)||(this.state.sandboxstdlist.length==0&&this.state.sandboxblanco.length!==0)) {
                this.setState({
                  standard_error : "Required"
                })
              }
              else {
              if (this.state.multipersons.length !== 0) {
                datasave.service(window.CREATE_SITE, 'POST', details)
                  .then(response => {
                    if (!response) {
                      this.setState({
                        name_error: t("this name has already taken"),
                      })
                    }
                    else {
                      if (response.name) {
                        this.setState({
                          name_error: response.name,
                        })
                      }
                      else {
                        if (response == "Success") {
                          const { history } = this.props
                          OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION })
                          history.push('/managemyorganisation/managesite')
                          window.location.reload();
                        }
                      }

                    }
                  });
              }
            }
            }
          })
      }
    }
    {/*   }
    else {
      this.setState({
        email_error: 'Email is not valid'
      })
    }*/}
  }
  getLegalOptionItems() {
    let temp = [];
    if (this.state.legalform.length >= 1) {
      if (this.state.legalform) {
        temp = this.state.legalform.map((legal) => {
          return (<option id={legal.id} value={legal.value} >{legal.value}</option>)
        }
        );
        return temp;
      }
    }
  }
  getFTEOptionItems() {
    let temp = [];
    if (this.state.fte_form.length >= 1) {
      if (this.state.fte_form) {
        temp = this.state.fte_form.map((fte) => {
          return (<option value={fte.value}>{fte.value}</option>)
        }
        );
        return temp;
      }
    }
  }
  getLangOptionItems() {
    let temp = [];
    if (this.state.language.length >= 1) {
      if (this.state.language) {
        temp = this.state.language.map((lang) => {
          return (<option id={lang.code_name} value={lang.code_name} >{lang.language}</option>)
        }
        );
        return temp;
      }
    }
  }
  getSectorOptionItems() {
    let temp = [];
    if (this.state.industries_data.length >= 1) {
      if (this.state.industries_data) {
        temp = this.state.industries_data.map((ind) => {
          return (<option id={ind.id} value={ind.id} >{ind.name}</option>)
        }
        );
        return temp;
      }
    }
  }
  getTimezoneOptionItems() {
    let temp = [];
    if (this.state.time_zone_list.length >= 1) {
      if (this.state.time_zone_list) {
        temp = this.state.time_zone_list.map((ind) => {
          return (<option value={ind.text} >{ind.text}</option>)
        }
        );
        return temp;
      }
    }
  }
  // time_zone_list

  handleChangeSector(event) {
    this.setState({
      industry: event.target.value,
      loading: false
    })
    const details = {
      id: event.target.value
    }
    this.setState({
      multiIndustry: []
    })
    datasave.service(window.GET_SUBSECTOR, 'post', details)
      .then(result => {
        this.setState({
          industry_sub_data: result
        })
      })
  }
  handleChangeMultiIndustry(event) {
    if (event.target == undefined) {
      const { value } = event;
      this.setState({ multiIndustry: event });
    }

  }
  handleSandboxblanco(event) {
    if (event.target === undefined) {
      this.setState({ sandboxblanco: event});
    }
    if (event.length !== 0) {
      this.getStandards(event,'sandboxstandards');
    }
    else{
      this.setState({ sandboxstdlist: []});
    }
  }
  handleSandboxStandards(event) {
    if (event.target === undefined) {
      this.setState({
        sandboxstdlist: event,
        loading:false
      });
    }
  }
  handleChangeMultiPersons(event) {
    this.handlePreviousvalues(event,this.state.multipersonsduplicate,"multipersons",'persons(s)')
    // if (event.target == undefined) {
    //   const { value } = event;
    //   this.setState({ multipersons: event, loading: false });
    // }

  }
  handleChangeMultiStandards(event) {
    this.handlePreviousvalues(event,this.state.multistandradsduplicate,"mulistandards",'standard(s)')

    // if (event.target == undefined) {
    //   const { value } = event;
    //   this.setState({ mulistandards: event, loading: false });
    // }

  }
  handlePreviousvalues(event,duplicatevalues,name,fieldname){
    if(event.length==0) {
      OCAlert.alertWarning('Used '+fieldname+" can't be deleted", { timeOut: window.TIMEOUTNOTIFICATION });
      this.setState({
        [name]: duplicatevalues, loading: false
      })
    }
    else{
      var count = 0;
      duplicatevalues.map(function(pduplicate){
        event.map(function (person) {
          if (person.value == pduplicate.value) {
            count++
          }
        });
      })
      if (count===duplicatevalues.length){
        if (event.target == undefined) {
          const { value } = event;
          this.setState({ [name]: event, loading: false });
        }
      }
      else{
        OCAlert.alertWarning('Used '+fieldname+" can't be deleted", { timeOut: window.TIMEOUTNOTIFICATION });
        this.setState({
          [name]: duplicatevalues, loading: false
        })
      }
    }
  }

  handleChangeOrganisation(event) {
    const details = {
      id: event.target.value
    }
    this.setState({
      parentsite: event.target.value,
      site: '',
      loading: false
    })

    datasave.service(window.GET_ORGANISATION_SITES, 'post', details)
      .then(response => {
        this.setState({
          siteList: response['site'],
          siteListlength: response['site'].length,
          // blancoList: response['blanco']
        })
        // }
      })
    datasave.service(window.GET_NO_OF_SITES, 'POST', details)
      .then(response => {
        this.setState({
          no_of_sites: response[0]['no_of_sites']
        })
      })
  }

  getParentSiteOptions() {
    let temp = [];
    if (this.state.siteList.length != 0) {
      if (this.state.siteList) {
        temp = this.state.siteList.map((site) => {
          return (<option value={site.name} id={site.name}>{site.name}</option>)
        }
        );
        return temp;
      }
    }
  }
  updateImageUpload(response) {
    this.setState({
      sucess: window.FILE_UPLOAD_SUCCESS,
      edit_img: '',
      file_id: response.data.file_id[0],
      logo: response.data.filepath
    });
  }

  getUserOptions() {
    let temp = [];
    if (this.state.persons.length != 0) {
      if (this.state.persons) {
        temp = this.state.persons.map((user) => {
          return (<option value={user.id} >{user.name}</option>)
        }
        );
        return temp;
      }
    }
  }

  handleCancel(event) {
    event.preventDefault()
    const { history } = this.props
    history.push('/managemyorganisation/managesite')
    if (this.props.handleSelect !== undefined)
      this.props.handleSelect(1)

  }

  handleTabSelect(key) {
    this.setState({
      activeTab: key,
    })
  }

  handlePersonsSelect(key) {
    this.setState({
      activePersonsTab: key,
    })
  }

  render() {
    const { t } = this.state;
    const { email, submitted, emailvalid, as4Users, sitename, name_error, telephone, activeTab, activePersonsTab, activeUsers, archivedUsers } = this.state;
    return (
      <div className=" row col-md-12">
        <div style={{ }} className='col-md-11 pl-0' >
          <Can
            perform="E_site"
            yes={() => (
              // <div className='container py-4' >
              <div className='' >
                <div className='col-md-12 p-0 mb-5' >
                  <div className='card mb-3' >
                    <Tabs activeKey={activeTab} onSelect={this.handleTabSelect} id="controlled-tab-example">
                      <Tab eventKey={1} title={t('Create site')}>
                        {/* <div className='card-header' > {t('Create Site')} </div> */}
                        <div className='card-body m-3' >
                          <Form method="POST" onSubmit={this.handleSubmit} noValidate >
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="mb-3">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Site name')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <Input type="text"
                                      className="form-control"
                                      name="sitename"
                                      value={sitename}
                                      onChange={this.handleChangeName}
                                      id="sitename"
                                      placeholder=""
                                      className="input_sw"
                                    />
                                    <div style={{ color: 'red' }} className="error-block mt-2">{name_error} </div>
                                    <div className="error-block mt-2">
                                      {!this.state.sitename && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                    </div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <Form.Group >
                              <div className=" row input-overall-sec ">
                                <div className="input-group">
                                  <FileUpload updateImageUpload={this.updateImageUpload.bind(this)} file_name={this.state.file_name} {...this} />
                                </div>
                                {/* <div style={{ textAlign: 'center' }} className="col-md-12 mt-2">
                                <a href={this.state.file_name}>{this.state.edit_img}</a>
                                <span style={{ color: "green" ,textAlign: 'center', paddingRight: '7rem' }}>{this.state.sucess}</span>
                              </div> */}
                                <div style={{}} className="row col-md-12 mt-2">
                                  <div style={{ visibility: 'hidden' }} className="col-md-4">
                                    <h3>{t('Upload')}</h3>
                                  </div>
                                  <div className="col-md-8">
                                    <a href={this.state.file_name}>{this.state.edit_img}</a>
                                    <span style={{ color: "green" }}>{this.state.sucess}</span>
                                  </div>
                                </div>
                              </div>
                            </Form.Group>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Site responsible person')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  {/* <Form.Control as="select" name="siteowner" */}
                                  <div class="col-md-8 input-padd">
                                    <div className="input_sw">
                                      <MultiSelect
                                        // disabled={this.state.required}
                                        options={this.state.persons}
                                        standards={this.state.multipersons}
                                        handleChange={this.handleChangeMultiPersons}
                                      />
                                    </div>
                                    <div className="mt-2">
                                      {this.state.multipersons.length == 0 && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                    </div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Legal form')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div className="col-md-8 input-padd">
                                    <Form.Control as="select" name="legal_form"
                                      className="input_sw"
                                      value={this.state.legal_form}
                                      onChange={e => this.setState({ legal_form: e.target.value, loading: false })} >
                                      <option>{t('Select')}</option>
                                      {this.getLegalOptionItems()}
                                    </Form.Control>
                                    <div className="mt-2">
                                      {!this.state.legal_form && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                    </div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('FTE')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <Form.Control as="select" name="fte"
                                      className="input_sw"
                                      value={this.state.fte}
                                      onChange={e => this.setState({ fte: e.target.value, loading: false })} >
                                      <option>{t('Select')}</option>
                                      {this.getFTEOptionItems()}
                                    </Form.Control>
                                    <div className="mt-2">
                                      {!this.state.fte && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                    </div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Sector')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <Form.Control as="select" name="industry"
                                      className="input_sw"
                                      value={this.state.industry}
                                      onChange={this.handleChangeSector} >
                                      <option id='0' value='0'> {t('Select')}</option>
                                      {this.getSectorOptionItems()}
                                    </Form.Control>
                                    <div className="mt-2">
                                      {!this.state.industry && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Sub sector')}:</InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <div className="input_sw">
                                      <MultiSelect
                                        options={this.state.industry_sub_data}
                                        // disabled={details.disableFields}
                                        standards={this.state.multiIndustry}
                                        handleChange={this.handleChangeMultiIndustry}
                                      />
                                    </div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Activity')}</InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <Input type="text"
                                      className="form-control"
                                      name="activity"
                                      value={this.state.activity}
                                      onChange={this.handleChange}
                                      id="activity"
                                      placeholder=""
                                      className="input_sw"
                                    />
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            {/*{!this.state.activity && submitted && <p style={{ color: 'red', textAlign: 'center', paddingRight: '11rem' }}>{t('Required')}</p>}*/}
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('VAT number')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <Input type="text"
                                      className="form-control"
                                      name="vatnumber"
                                      value={this.state.vatnumber}
                                      onChange={this.handleChange}
                                      id="vatnumber"
                                      placeholder=""
                                      className="input_sw"
                                    />
                                    <div className="mt-2" >{!this.state.vatnumber && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Phone number')}: <span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <Form.Control
                                      name='mobilenumber'
                                      className="input_sw"
                                      placeholder={t("Enter Number")}
                                      aria-label="Telephone"
                                      aria-describedby="basic-addon1"
                                      value={telephone}
                                      onChange={this.handleTelephoneChange}
                                    />
                                    <div className="mt-2"> {!this.state.telephone && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('FAX')}: <span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <Input type="text"
                                      className="form-control"
                                      name="fax"
                                      value={this.state.fax}
                                      onChange={this.handleChange}
                                      id="fax"
                                      placeholder=""
                                      className="input_sw"
                                    />
                                    <div className="mt-2">{!this.state.fax && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Address')}: <span style={{ color: "red" }}>*</span></InputGroup >
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <Input type="text"
                                      className="form-control"
                                      name="address"
                                      value={this.state.address}
                                      onChange={this.handleChange}
                                      id="fax"
                                      placeholder=""
                                      className="input_sw"
                                    />
                                    <div className="mt-2">{!this.state.address && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Postcode and city/town')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <FormControl
                                      name="location_id"
                                      className="input_sw"
                                      value={this.state.location_id}
                                      onChange={e => this.setState({ location_id: e.target.value, loading: false })}
                                      placeholder={t("Postcode and city/town")}
                                      aria-label="location"
                                      aria-describedby="basic-addon1">
                                      {/* <option value='0'>Select</option>
                              {this.state.locations_data.map(location => <option value={location.id}>{location.locations}</option>)} */}
                                    </FormControl>
                                    <div className="mt-2">
                                      {!this.state.location_id && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                    </div>
                                  </div>

                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Province/Country')}:</InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <FormControl
                                      required
                                      placeholder={t("Country details")}
                                      className="input_sw"
                                      aria-label="Description field"
                                      aria-describedby="basic-addon1"
                                      value={this.state.country_details}
                                      onChange={e => this.setState({ country_details: e.target.value, loading: false })}
                                    />
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Website')} :<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  {/* <div class="col-md-8 input-padd"> */}
                                  <div className="col-md-2 input-padd">
                                    <Input type="text"
                                      readOnly
                                      className="form-control"
                                      name="website"
                                      value={this.state.protocol}
                                      style={{ backgroundColor: "white" }}
                                      className="input_sw"
                                    >
                                    </Input>
                                  </div>
                                  {/* </div> */}
                                  <FormControl
                                    className="form-control"
                                    name="website"
                                    value={this.state.website}
                                    onChange={this.handleWebsiteChange}
                                    id="website"
                                    placeholder={t("Enter website name")}
                                    className="input_sw"
                                  />
                                  <Input type="text"
                                    readOnly
                                    className="form-control"
                                    name="website"
                                    value={this.state.hostname}
                                    style={{ backgroundColor: "white" }}
                                    className="input_sw"
                                  >
                                  </Input>
                                </InputGroup>
                                <div className="mt-2 col-md-12" style={{ color: 'red', textAlign: 'center', paddingRight: '12rem' }} className="error-block">{this.state.website_error} </div>
                                <div className="mt-2 col-md-12"> {!this.state.website && submitted && <p style={{ color: 'red', textAlign: 'center', paddingRight: '12rem' }}>{t('Required')}</p>}</div>
                              </div>
                            </FormGroup>

                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Organisation')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <FormControl as="select" name="paresite"
                                      className="input_sw"
                                      disabled={this.state.required}
                                      value={this.state.parentsite}
                                      onChange={this.handleChangeOrganisation} >
                                      <option>{t('Select')}</option>
                                      {this.getOptionItems()}
                                      {/* {this.state.packages_data.map(packages => <option value={packages.id}>{packages.name}</option>)} */}
                                    </FormControl>
                                    <div className="mt-2">{!this.state.parentsite && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}</div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Parent site')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <FormControl as="select" name="paresite"
                                      className="input_sw"
                                      disabled={this.state.required}
                                      value={this.state.site}
                                      onChange={e => this.setState({ site: e.target.value, loading: false })} >
                                      <option>{t('Select')}</option>
                                      {this.getParentSiteOptions()}

                                      {/* {this.state.packages_data.map(packages => <option value={packages.id}>{packages.name}</option>)} */}
                                    </FormControl>
                                    <div className="mt-2" style={{ color: 'red' }} className="error-block">{this.state.siteerror} </div>
                                    <div className="mt-2">
                                      {!this.state.site && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                    </div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Select blanco')}: </InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <div className="input_sw">
                                      <MultiSelect
                                        options={this.state.blancoList}
                                        // disabled={this.state.required}
                                        standards={this.state.standards}
                                        handleChange={this.handleChangeMultiStandard}
                                      />
                                    </div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="mb-3">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Standards')}:{this.state.standards.length !== 0 && <span style={{ color: "red" }}>*</span>}</InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <div className="input_sw">
                                      <MultiSelect
                                        // disabled={this.state.required}
                                        options={this.state.stdList}
                                        standards={this.state.mulistandards}
                                        handleChange={this.handleChangeMultiStandards}
                                      />
                                    </div>
                                    <div className="mt-2">
                                    {this.state.standards.length !== 0 && this.state.mulistandards.length == 0 && submitted && <p style={{ color: 'red' }}>{t('Required')}</p>}
                                    </div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec">
                                <InputGroup className="">
                                  <div className="col-md-4 ">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Select sandbox blanco')}:</InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd ">
                                    <div className=" input_sw">
                                      <MultiSelect
                                        options={this.state.blancoList}
                                        standards={this.state.sandboxblanco}
                                        handleChange={this.handleSandboxblanco}
                                      />
                                    </div>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="mb-3">
                                  <div className="col-md-4 ">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Sandbox standards')}:{this.state.sandboxblanco.length !== 0 && <span style={{ color: "red" }}>*</span>}</InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd ">
                                    <div className=" input_sw">
                                      <MultiSelect
                                        // disabled={this.state.required}
                                        options={this.state.sandboxstandards}
                                        standards={this.state.sandboxstdlist}
                                        handleChange={this.handleSandboxStandards}
                                      />
                                    </div>
                                    {<span style={{ color: "red" }}>{this.state.standard_error}</span>}
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>

                            {/* {!this.state.country_details && submitted && <p style={{ color: 'red', textAlign: 'center', paddingRight: '11rem' }}>{t('Required')}</p>} */}
                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Time zone')}:</InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <FormControl as="select" name="timezone"
                                      className="input_sw"
                                      value={this.state.time_zone}
                                      onChange={e => this.setState({ time_zone: e.target.value, loading: false })}
                                    >
                                      <option>{t('select')}</option>
                                      {this.getTimezoneOptionItems()}
                                    </FormControl>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            {/* {!this.state.time_zone && submitted && <p style={{ color: 'red', textAlign: 'center', paddingRight: '11rem' }}>{t('Required')}</p>} */}

                            <FormGroup>
                              <div className=" row input-overall-sec ">
                                <InputGroup className="">
                                  <div className="col-md-4">
                                    <InputGroup.Prepend>
                                      <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Language')}: </InputGroup>
                                    </InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 input-padd">
                                    <Form.Control as="select" name="language_id"
                                      className="input_sw"
                                      value={this.state.language_id}
                                      onChange={e => this.setState({ language_id: e.target.value, loading: false })} >
                                      <option>{t('Select')}</option>
                                      {this.getLangOptionItems()}
                                    </Form.Control>
                                  </div>
                                </InputGroup>
                              </div>
                            </FormGroup>
                            <FormGroup>
                              <div style={{ float: 'right' }} className="organisation_list mt-3">
                                <a onClick={this.handleCancel} color="primary">{t('Cancel')}</a>
                                &nbsp;&nbsp;&nbsp;
                            {/* {!this.state.language_id && submitted && <p style={{ color: 'red' }}>Required</p>} */}
                                <Button className="btn btn-primary" type="submit" color="primary" disabled={this.state.loading}>{t('Save')}</Button>
                                {/* &nbsp;&nbsp;&nbsp; */}
                              </div>
                            </FormGroup>
                          </Form>
                        </div>
                        </Tab>
                        <Tab eventKey={3} title={t('Login layout')}>
                        </Tab>
                        {(this.props.editid !== null && this.props.editid !== undefined) &&
                          <Tab eventKey={2} title={t('Users')}>
                            <Tabs activeKey={activePersonsTab} onSelect={this.handlePersonsSelect} id="controlled-tab-example">
                              <Tab eventKey={1} title={t('Active')}>
                                <reactbootstrap.Table className="site-table-main" >
                                  <thead>
                                    <tr>
                                      <th>{t('Name')}</th>
                                      <th>{t('Email')}</th>
                                      <th>{t('Role')}</th>
                                    </tr>
                                  </thead>
                                  {activeUsers.map((item) => (
                                    <tbody>
                                        <td>{item.name}</td>
                                        <td>{item.email}</td>
                                        <td>{item.roleName}</td>
                                    </tbody>
                                  ))}
                                </reactbootstrap.Table>
                              </Tab>
                              <Tab eventKey={2} title={t('Inactive')}>
                                <reactbootstrap.Table className="site-table-main" >
                                  <thead>
                                    <tr>
                                      <th>{t('Name')}</th>
                                      <th>{t('Email')}</th>
                                      <th>{t('Role')}</th>
                                    </tr>
                                  </thead>
                                  {archivedUsers.map((item) => (
                                    <tbody>
                                        <td>{item.name}</td>
                                        <td>{item.email}</td>
                                        <td>{item.roleName}</td>
                                    </tbody>
                                  ))}
                                </reactbootstrap.Table>
                              </Tab>
                              <Tab eventKey={3} title={t('As4')}>
                              <reactbootstrap.Table className="site-table-main" >
                                <thead>
                                  <tr>
                                    <th>{t('Name')}</th>
                                    <th>{t('Email')}</th>
                                    <th>{t('Role')}</th>
                                  </tr>
                                </thead>
                                {as4Users.map((item) => {
                                  if(parseInt(item.status) === 1){
                                    return(
                                    <tbody>
                                        <td>{item.name}</td>
                                        <td>{item.email}</td>
                                        <td>{item.roleName}</td>
                                    </tbody>
                                  )}})}
                              </reactbootstrap.Table>
                            </Tab>
                            <Tab eventKey={4} title={t('As4 inactive')}>
                              <reactbootstrap.Table className="site-table-main" >
                                <thead>
                                  <tr>
                                    <th>{t('Name')}</th>
                                    <th>{t('Email')}</th>
                                    <th>{t('Role')}</th>
                                  </tr>
                                </thead>
                                {as4Users.map((item) => {
                                  if(parseInt(item.status) === 0){
                                    return(
                                    <tbody>
                                        <td>{item.name}</td>
                                        <td>{item.email}</td>
                                        <td>{item.roleName}</td>
                                    </tbody>
                                  )}})}
                              </reactbootstrap.Table>
                            </Tab>
                            </Tabs>
                          </Tab>
                        }
                     </Tabs>
                     {parseInt(activeTab) === 3 && this.showLayoutPage()}
                  </div>
                </div>
              </div>
              // </div >
            )}
            no={() =>
              <AccessDeniedPage />
            }
          />
        </div>
      </div>
    );
  }

  setStateDesignObject = (obj = {}) => {
    let designObj = {...this.state.designObject}
    designObj = {...designObj, ...obj}
    this.setState({ designObject: designObj })
  }

  showLayoutPage = () => {
    return (
      <LoginScreenLayout
        data = {this.state.designObject}
        handleCancel = {this.handleCancel.bind(this)}
        handleSubmit = {this.handleSubmit.bind(this)}
        setStateDesignObject = {this.setStateDesignObject}
        t = {this.props.t}
      />
    );
  }

}
export default translate(Site)
