import React from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
import CheckBox from '../CheckBox';
function GeneralSettings(props) {
    const {title,description,plannerTypeOptions,selectedPlannerType,dueDateNumber,dueDatePeriodOptions,selectedDueDatePeriod,typeOptions,selectedType,
            subTypeOptions,selectedSubType,active,notification,beforeDeadline,afterDeadLine,email,dashboard,beforeDays,afterDays} = props.state;
    const t = props.t;
  const formDisabled = (props.action === 'view') ? true : '';
    return(
      <reactbootstrap.Container>
          <reactbootstrap.Form >
            <fieldset disabled={formDisabled}>
        <reactbootstrap.Row className='mt-2'>
        <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Title:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
        <reactbootstrap.FormControl
          className="col-md-9"
          type='text'
          onChange={(e) => props.textOnChnage(e.target.value,'title')}
          value={title}/>
        </reactbootstrap.Row>
        <reactbootstrap.Row className='mt-2'>
        <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Description:')}</reactbootstrap.FormLabel>
        <reactbootstrap.FormControl
          className="col-md-9"
          as='textarea'
          onChange={(e) => props.textOnChnage(e.target.value,'description')}
          value={description}/>
        </reactbootstrap.Row>
        <reactbootstrap.Row className='mt-2'>
        <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Type of task planner:')}</reactbootstrap.FormLabel>
        <reactbootstrap.Col className='col-md-9 px-0'>
        <MultiSelect
          disabled={formDisabled}
          options={plannerTypeOptions}
          standards={selectedPlannerType}
          handleChange={e=>props.handleChangePlannerType(e)}
          isMulti={false} />
        </reactbootstrap.Col>
        </reactbootstrap.Row>
        <reactbootstrap.Row className='mt-2'>
        <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Due date period:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
        <reactbootstrap.Col className='col-md-9 px-0 d-flex'>
        <reactbootstrap.FormControl
          className="col-md-5"
          type='text'
          onChange={(e) => props.handleNumber(e.target.value,'dueDateNumber')}
          value={dueDateNumber}/>
          <reactbootstrap.Col className='col-md-7 px-0'>
        <MultiSelect
          disabled={formDisabled}
          options={dueDatePeriodOptions}
          standards={selectedDueDatePeriod}
          handleChange={e=>props.handleChangeDuration(e,'selectedDueDatePeriod')}
          isMulti={false} />
          </reactbootstrap.Col>
        </reactbootstrap.Col>
        </reactbootstrap.Row>
        <reactbootstrap.Row className='mt-2'>
        <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Type:')}</reactbootstrap.FormLabel>
        <reactbootstrap.Col className='col-md-9 px-0 ' >
        <MultiSelect
          disabled={formDisabled}
          options={typeOptions}
          standards={selectedType}
          handleChange={e=>props.handleChangeTypeSubType(e,'selectedType')}
          isMulti={false} />
        </reactbootstrap.Col>
        </reactbootstrap.Row>
        <reactbootstrap.Row className='mt-2'>
        <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Sub type:')}</reactbootstrap.FormLabel>
        <reactbootstrap.Col className='col-md-9 px-0 '>
        <MultiSelect
          disabled={formDisabled}
          options={subTypeOptions}
          standards={selectedSubType}
          handleChange={e=>props.handleChangeTypeSubType(e,'selectedSubType')}
          isMulti={false} />
        </reactbootstrap.Col>
        </reactbootstrap.Row>
        {/**<reactbootstrap.Row className='d-flex'>
        <reactbootstrap.Col className='col-md-1'>
        <CheckBox
            tick={active}
            onCheck={(e) => props.handleSelect(e.target.checked,'active')}

        />
        </reactbootstrap.Col>
        <reactbootstrap.FormLabel className='col-md-3 pt-1'>{t('Active')}</reactbootstrap.FormLabel>
        </reactbootstrap.Row>*/}
        <reactbootstrap.Row>
        <reactbootstrap.Col className='col-md-1'>
        <CheckBox
            tick={notification}
            onCheck={(e) => props.handleSelect(e.target.checked,'notification')}

        />
        </reactbootstrap.Col>
        <reactbootstrap.FormLabel className='col-md-3 pt-1'>{t('Notification')}</reactbootstrap.FormLabel>
          </reactbootstrap.Row>
          {notification &&<div className='pl-3'>
        <reactbootstrap.Row>
        <reactbootstrap.Col className='col-md-1'>
        <CheckBox
            tick={beforeDeadline}
            onCheck={(e) => props.handleSelect(e.target.checked,'beforeDeadline')}

        />
        </reactbootstrap.Col>
        <reactbootstrap.FormLabel className='ml-3 pt-1'>{t('Before deadline')}</reactbootstrap.FormLabel>
            <reactbootstrap.Form.Control
              placeholder={t("Days")}
              value={beforeDays}
              style={{width:'60px',height:'20px',marginLeft: "4px",marginRight: "4px",marginTop:'5px',textAlign:'center',padding: "0px"}}
              onChange={(e) => props.handleNumber(e.target.value,'beforeDays')}
              className="input_sw"
              disabled={!beforeDeadline}
              />
              <reactbootstrap.FormLabel className='pt-1'>{t('days before deadline')}</reactbootstrap.FormLabel>
        </reactbootstrap.Row>
        <reactbootstrap.Row>
        <reactbootstrap.Col className='col-md-1'>
        <CheckBox
            tick={afterDeadLine}
            onCheck={(e) => props.handleSelect(e.target.checked,'afterDeadLine')}

        />
        </reactbootstrap.Col>
        <reactbootstrap.FormLabel className='ml-3 pt-1'>{t('After deadline')}</reactbootstrap.FormLabel>
            <reactbootstrap.Form.Control
              placeholder={t("Days")}
              value={afterDays}
              style={{width:'60px',height:'20px',marginLeft: "4px",marginRight: "4px",marginTop:'5px',textAlign:'center',padding: "0px"}}
              onChange={(e) => props.handleNumber(e.target.value,'afterDays')}
              className="input_sw"
              disabled={!afterDeadLine}
              />
              <reactbootstrap.FormLabel className='pt-1'>{t('days after deadline')}</reactbootstrap.FormLabel>
        </reactbootstrap.Row>
        <reactbootstrap.FormLabel className='ml-2' style={{color: '#EC661C'}}>{t('Type of Reminder')}</reactbootstrap.FormLabel>
        <reactbootstrap.Row>
        <reactbootstrap.Col className='col-md-1'>
        <CheckBox
            tick={email}
            onCheck={(e) => props.handleSelect(e.target.checked,'email')}

        />
        </reactbootstrap.Col>
        <reactbootstrap.FormLabel className='col-md-3 pt-1'>{t('Email')}</reactbootstrap.FormLabel>
        </reactbootstrap.Row>
        <reactbootstrap.Row>
        <reactbootstrap.Col className='col-md-1'>
        <CheckBox
            tick={dashboard}
            onCheck={(e) => props.handleSelect(e.target.checked,'dashboard')}

        />
        </reactbootstrap.Col>
        <reactbootstrap.FormLabel className='col-md-3 pt-1'>{t('Dashboard')}</reactbootstrap.FormLabel>
        </reactbootstrap.Row>
        </div>}
          </fieldset>
      </reactbootstrap.Form >
      </reactbootstrap.Container>
    )
}
export default translate(GeneralSettings);
