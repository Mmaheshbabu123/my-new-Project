import React from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
import AddWebElements from './AddWebElements';
import CheckBox from '../CheckBox';
function WebformSettings(props){
  const {webFormOptions,selectedWebForm,actorOptions,selectedActor,searchInDbOptions,selectedsearchInDb,orgUnitOptions,selectedOrgUnit,
    allwebElements,copyArrayAddedWebElements,addWebelementPopUp,startWebForm,templateNeded,documentOptions,selectedDocument,verify_amount,
    verify_amount_all,responsible_amount,responsible_amount_all,webFormActorAmount,webform_actor_amount_all,selectedPlannerType} =props.state;
    const t = props.t;
  const formDisabled = (props.action === 'view') ? true : '';
    const addWebElementModelPopUp=()=>{
      return(
        <reactbootstrap.Modal
        show={addWebelementPopUp}
        onHide={props.closeAddWebelements}
        dialogClassName="modal-90w modal-md"
        aria-labelledby="example-custom-modal-styling-title"
        >
        <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Body>
        <AddWebElements {...props}/>
        </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal>
      )
    }

    return(
      <reactbootstrap.Container>
        <reactbootstrap.Form >
          <fieldset disabled={formDisabled}>
      <reactbootstrap.Row className='mt-2'>
      <reactbootstrap.Col className='col-md-1 px-0'>
      <CheckBox
      tick={startWebForm}
      onCheck={(e) => props.handleSelect(e.target.checked,'startWebForm')}
      disabled={true}
      />
      </reactbootstrap.Col>
      <reactbootstrap.FormLabel className='col-md-3 pt-1 '>{t('Start webform')}</reactbootstrap.FormLabel>
      </reactbootstrap.Row>
      {!startWebForm && <>
        <reactbootstrap.Row className='mt-2'>
        <reactbootstrap.Col className='col-md-1 px-0'>
        <CheckBox
        tick={templateNeded}
        onCheck={(e) => props.handleSelect(e.target.checked,'templateNeded')}
        />
        </reactbootstrap.Col>
        <reactbootstrap.FormLabel className='col-md-3 pt-1 '>{t('Template needed')}</reactbootstrap.FormLabel>
        </reactbootstrap.Row>
        {templateNeded &&<reactbootstrap.Row className='mt-2'>
        <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Document:')}</reactbootstrap.FormLabel>
        <reactbootstrap.Col className='col-md-9 px-0'>
        <MultiSelect
          disabled={formDisabled}
        options={documentOptions}
        standards={selectedDocument}
        handleChange={e=>props.handleChangeDocument(e,'selectedDocument')}
        isMulti={false} />
        </reactbootstrap.Col>
        </reactbootstrap.Row>}
        <reactbootstrap.Row className='mt-2 ml-2'>
        </reactbootstrap.Row>
        <reactbootstrap.Row className='mt-2'>
          <reactbootstrap.Col className='col-md-6 d-flex'>
            <reactbootstrap.Col className='col-md-6'>
            <reactbootstrap.FormLabel  style={{color: '#EC661C'}}>{t('Verify amount:')}</reactbootstrap.FormLabel>
            </reactbootstrap.Col>
            <reactbootstrap.Col className='col-md-6'>
            <reactbootstrap.Form.Control
                type="number"
                value={verify_amount}
                onChange={(e) => props.handleNumber(e.target.value,'verify_amount')}
                disabled={verify_amount_all == 1 ? true : false}
            />
            </reactbootstrap.Col>
          </reactbootstrap.Col>
          <reactbootstrap.Col className='col-md-6 d-flex px-0'>
          <reactbootstrap.Col className='col-md-1 px-0'>
          <CheckBox
          tick={verify_amount_all}
          onCheck={(e) => props.handleSelect(e.target.checked,'verify_amount_all')}
          />
          </reactbootstrap.Col>
          <reactbootstrap.FormLabel className='col-md-3 ml-4 pt-1'>{t('All')}</reactbootstrap.FormLabel>
          </reactbootstrap.Col>
        </reactbootstrap.Row>
        <reactbootstrap.Row className='mt-2'>
          <reactbootstrap.Col className='col-md-6 d-flex'>
          <reactbootstrap.Col className='col-md-6'>
          <reactbootstrap.FormLabel  style={{color: '#EC661C'}}>{t('Responsible amount:')}</reactbootstrap.FormLabel>
          </reactbootstrap.Col>
            <reactbootstrap.Col className='col-md-6 '>
            <reactbootstrap.Form.Control
                type="number"
                value={responsible_amount}
                onChange={(e) => props.handleNumber(e.target.value,'responsible_amount')}
                disabled={responsible_amount_all == 1 ? true : false}
            />
            </reactbootstrap.Col>
          </reactbootstrap.Col>
          <reactbootstrap.Col className='col-md-6 d-flex px-0'>
          <reactbootstrap.Col className='col-md-1 px-0'>
          <CheckBox
          tick={responsible_amount_all}
          onCheck={(e) => props.handleSelect(e.target.checked,'responsible_amount_all')}
          />
          </reactbootstrap.Col>
          <reactbootstrap.FormLabel className='col-md-3 ml-4 pt-1'>{t('All')}</reactbootstrap.FormLabel>
          </reactbootstrap.Col>
        </reactbootstrap.Row>
        <reactbootstrap.Button  className='mr-2 mb-2 mt-2' onClick={props.showCloseResponsibleVerifier}>{t('Receiver')}</reactbootstrap.Button>
        </>}
        {startWebForm  && <>
          <reactbootstrap.Row className='mt-2'>
          <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Webform:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
          <reactbootstrap.Col className='col-md-9 px-0'>
          <MultiSelect
            disabled={formDisabled}
          options={webFormOptions}
          standards={selectedWebForm}
          handleChange={e=>props.handleChangeWebform(e,'selectedWebForm')}
          isMulti={false} />
          </reactbootstrap.Col>
          </reactbootstrap.Row>
          {addWebElementModelPopUp()}
          {allwebElements.length>0 &&<reactbootstrap.Row className='mt-2'>

          <div  style={{ 'scrollbar-width': 'thin', maxHeight:'300px', overflow:'auto' }}>
          <reactbootstrap.Table striped bordered hover variant="" style={{ 'table-layout': 'fixed'}}>
          <thead style={{ backgroundColor: '#EC661C', color: '#fff', top: '0', textAlign: 'center' }}>
          <tr style={{width:'100%'}}>
          <th style={{width:'40%'}}>{t('Web element')}</th>
          <th style={{width:'40%'}}>{t('Pre-filled value')}</th>
          <th style={{width:'20%'}}><i title={t("Add webelements")} style={{ 'cursor': 'pointer',float:'right' }} className="revertbuttons-sprite revert-createlistc" onClick={props.addWebElements}/></th>
          </tr>
          </thead>
          <tbody>
          {copyArrayAddedWebElements.length>0 && copyArrayAddedWebElements.map(value=>{

            return  <tr>
            <td>{value.webElementName}</td>
            <td>{value.webElementValue}</td>
            <td>
            <div style={{ display: 'flex',float:'right' }}>
            <i title={t("Edit")} style={{}} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc" onClick={(e) => props.editAddedWebElement(value)}/>
            <i title={t("Delete")} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={(e) => props.deleteAddedWebElement(value)}/>
            </div>
            </td>
            </tr>
          })}

          </tbody>
          </reactbootstrap.Table>
          </div>
          </reactbootstrap.Row>}
          <reactbootstrap.Row className='mt-2'>
          <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Task planner actor:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
          <reactbootstrap.Col className='col-md-9 px-0'>
          <MultiSelect
            disabled={formDisabled}
          options={actorOptions}
          standards={selectedActor}
          handleChange={e=>props.handleChangeActor(e,'selectedActor')}
          isMulti={false} />
          </reactbootstrap.Col>
          </reactbootstrap.Row>
          {selectedActor.value && [window.PERSON_ENTITY,window.JOB_ENTITY,window.DEPARTMENT_ENTITY,window.GROUP_ENTITY].includes(selectedActor.value)&& <><reactbootstrap.Row className='mt-2'>
          <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Organisation unit:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
          <reactbootstrap.Col className='col-md-9 px-0'>
          <MultiSelect
            disabled={formDisabled}
          options={orgUnitOptions}
          standards={selectedOrgUnit}
          handleChange={e=>props.handleChangeActor(e,'selectedOrgUnit')}
          isMulti={false} />
          </reactbootstrap.Col>
          </reactbootstrap.Row>
          {[window.JOB_ENTITY,window.DEPARTMENT_ENTITY,window.GROUP_ENTITY].includes(selectedActor.value)&& <reactbootstrap.Row className='mt-2'>
            <reactbootstrap.Col className='col-md-6 px-0 d-flex'>
            <reactbootstrap.Col className='col-md-6'>
            <reactbootstrap.FormLabel  style={{color: '#EC661C'}}>{t('Amount:')}</reactbootstrap.FormLabel>
            </reactbootstrap.Col>
              <reactbootstrap.Col className='col-md-6 '>
              <reactbootstrap.Form.Control
                  type="number"
                  value={webFormActorAmount}
                  onChange={(e) => props.handleNumber(e.target.value,'webFormActorAmount')}
                  disabled={webform_actor_amount_all == 1 ? true : false}
              />
              </reactbootstrap.Col>
            </reactbootstrap.Col>
            <reactbootstrap.Col className='col-md-6 d-flex px-0'>
            <reactbootstrap.Col className='col-md-1 px-0'>
            <CheckBox
            tick={webform_actor_amount_all}
            onCheck={(e) => props.handleSelect(e.target.checked,'webform_actor_amount_all')}
            />
            </reactbootstrap.Col>
            <reactbootstrap.FormLabel className='col-md-3 ml-4 pt-1 px-0'>{t('All')}</reactbootstrap.FormLabel>
            </reactbootstrap.Col>
          </reactbootstrap.Row>}
          </>}
          {selectedActor.value && selectedActor.value===window.SEARCH_IN_DB && <><reactbootstrap.Row>
            <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Search in database:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
            <reactbootstrap.Col className='col-md-9 px-0'>
            <MultiSelect
              disabled={formDisabled}
            options={searchInDbOptions}
            standards={selectedsearchInDb}
            handleChange={e=>props.handleChangeDb(e,'selectedsearchInDb')}
            isMulti={true} />
            </reactbootstrap.Col>
            </reactbootstrap.Row>
            {/*<reactbootstrap.Row>
            <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Organisation unit:')}<span style={{ color: 'red' }}>{selectedActor.value && selectedActor.value!==window.SEARCH_IN_DB ?'*':''}</span></reactbootstrap.FormLabel>
            <reactbootstrap.Col className='col-md-9 px-0'>
            <MultiSelect
            options={orgUnitOptions}
            standards={selectedOrgUnit}
            handleChange={e=>props.handleChangeActor(e,'selectedOrgUnit')}
            isMulti={false} />
            </reactbootstrap.Col>
            </reactbootstrap.Row>*/}
            </>}
            </>}
          </fieldset>
      </reactbootstrap.Form >
            </reactbootstrap.Container>
          )

        }
        export default translate(WebformSettings);
