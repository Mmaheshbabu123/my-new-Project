import React ,{Component}from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import DatePicker from 'react-datepicker';
import { datasave } from '../_services/db_services';
class AddWebElements extends Component{
  constructor(props){
    super(props)
    this.state={
      t:props.t,
      webElementId:0,
      parentID:0,
      webElementName:'',
      webElementValue:'',
      childId:0,
      webElementType:0,
      operator:'',
      childData:[],
      controlType:1,
      periodType:0
    }
  }
  componentDidMount(){
    this.setPropsData();
  }
  setPropsData=async()=>{
    let webElementdetails = this.props.state.webElementData;
    await this.setState({
      webElementId:webElementdetails.webElementId,
      parentID:webElementdetails.parentID,
      webElementName:webElementdetails.webElementName,
      webElementValue:webElementdetails.webElementValue,
      childId:webElementdetails.childId?webElementdetails.childId:0,
      webElementType:webElementdetails.webElementType,
      operator:webElementdetails.operator?webElementdetails.operator:1,
      childData:this.props.state.allChildElements[webElementdetails.parentID]?Object.values(this.props.state.allChildElements[webElementdetails.parentID]['child_data']):[],
      controlType:webElementdetails.controlType,
      count:webElementdetails.count,
      periodType:webElementdetails.webElementType!==window.DATEFIELD && webElementdetails.controlType!==2?webElementdetails.periodType:1
    },()=>{
    if(parseInt(webElementdetails.webElementType)===window.LISTORG)
    {
      this.getListOrgUnits();
    }});;
  }
  changeValues = (e,type = 1) => {
    const{webElementType} =  this.state
    let value = type ===1 ?e.target.value: e
    let name  =  undefined
    let valueId = 0
    if([window.NUMERICFIELD,window.DECIMALFIELD].includes(parseInt(webElementType))){
      value =   e.target.validity.valid ? value: this.state.value!== undefined?this.state.webElementValue:''
    }
    name = value
    if([11,12,9,10,7,8].includes(parseInt(webElementType))){
      const {  childNodes, selectedIndex } = e.target
      valueId = childNodes[selectedIndex].getAttribute('id')
      name  = childNodes[selectedIndex].getAttribute('name')
    }
    this.setState({
      webElementValue: name,
      childId:valueId,
      controlType:parseInt(webElementType)===window.DATEFIELD?1:type
    })
  }
  getValueFields=()=>{
    const {webElementType,webElementValue,childData,t,childId}=this.state;
    let valueFields = [];
    if (webElementType === window.TEXTBOX) {
        valueFields.push(
            <reactbootstrap.Form.Control as="textarea" onChange={this.changeValues} value={webElementValue} rows="3" />
        )
    }
    if (webElementType === window.DATEFIELD) {
      let obj ={}; let type = 1;
      const item = this.props.state.allwebElements.filter( item =>{ return item.id === childId});
      if(item.length){
        Object.values(item).map(item =>{
          obj = JSON.parse(item.json_data);
          return obj
        })}
        type = obj.display_type !== undefined ? obj.display_type:1;
        if( parseInt(type) === 2){
          this.isDateType = 2
          valueFields.push(
            <reactbootstrap.Form.Group controlId="form">
            <DatePicker
            selected={ webElementValue !== undefined ? new Date(webElementValue):undefined}
            onChange={(date) => this.changeValues(date,0)}
            showTimeSelect
            withPortal = {true}
            timeCaption="time"
            dateFormat="dd-MM-yyyy h:mm aa"
            />
            </reactbootstrap.Form.Group>
          )
        }else{
          this.isDateType = 1;
          valueFields.push(<reactbootstrap.Form.Control
            type="date" name="date" onChange={this.changeValues} style={{ }} value={webElementValue}>
            </reactbootstrap.Form.Control>)
          }
        }
        if([window.DATABASELIST,window.TEXTFIELD,window.DECIMALFIELD,window.NUMERICFIELD ,window.DATABASELIST_MULTISELECT].includes(parseInt(webElementType))){
          valueFields.push(
            <reactbootstrap.Form.Control type='text' pattern = {(webElementType === window.DECIMALFIELD || webElementType === window.NUMERICFIELD) ? "[0-9]+(,[0-9]+)*,?":true} style={{  }} onChange={this.changeValues} placeholder = 'Value' value={webElementValue} />
          )
        }
        if ([Window.LIST,window.RADIO_BUTTON,Window.CHECKBOX,window.LISTORG].includes(parseInt(webElementType))) {
          if(childData.length>0){
            let options = [];
            childData.map(item => {
              return   options.push(<option  key = {item.id} id={item.id} name  = {item.name} value = {item.id}> {item.name}</option>)
            })
            valueFields.push(
              <reactbootstrap.Form.Control style={{  }} as="select" name="outype" value={childId} onChange={this.changeValues} >
              <option>{t("---Select---")}</option>
              {options}
              </reactbootstrap.Form.Control>  )
            }
          }
          if(valueFields.length<1){
            valueFields.push(<p style={{color:'red'}}>{t('No values available for this control')}</p>)
            return valueFields;
          }else {
            return valueFields;
          }
        }
        changeControls=(e)=>{
          const { childNodes, selectedIndex } = e.target
          let id = childNodes[selectedIndex].getAttribute('id')
          let name = childNodes[selectedIndex].getAttribute('name')
          let type = childNodes[selectedIndex].getAttribute('type')
          let parent_id = childNodes[selectedIndex].getAttribute('parent_id')
          if(this.props.state.allChildElements[parseInt(parent_id)]&&Object.values(this.props.state.allChildElements[parseInt(parent_id)]).length>0){
            this.setState({
              webElementId:id,
              webElementType:parseInt(type),
              webElementName:name,
              parentID:parent_id,
              childData:Object.values(this.props.state.allChildElements[parseInt(parent_id)]['child_data']),
              webElementValue:'',
              childId:0,
              operator:1,
              periodType:4,
              count:''
            },()=>{
            if(parseInt(type)===window.LISTORG)
            {
              this.getListOrgUnits();
            }}
          )
          }else {
            this.setState({
              webElementId:id,
              webElementType:parseInt(type),
              webElementName:name,
              childData:[],
              parentID:0,
              webElementValue:'',
              childId:0,
              operator:1,
              periodType:4,
              count:''
            },()=>{
            if(parseInt(type)===window.LISTORG)
            {
              this.getListOrgUnits();
            }}
          )
          }
        }
        getListOrgUnits =()=>{
            let controls  = this.props.state.allwebElements;
            let obj ={};
            const item = controls.filter( item =>{ return parseInt(item.id) === parseInt(this.state.webElementId)});
            let selectedItemsOfLou = [];

            if(item.length){
                item.map(item =>{
                  return obj = item.json_data!= null? JSON.parse(item.json_data):undefined;
               })
            if(obj!== undefined && obj !== null) {
              let allPJDG = this.props.state.pjgd;
              if(obj.selectAll === 1) {
                selectedItemsOfLou = allPJDG.filter(itemOfPjdg => (itemOfPjdg.category === obj.orgUnit));
              } else {
                selectedItemsOfLou = obj.selectedItems;
              }
               if(obj.showAllPersons == true) {
                  this.getPersonsInorg(selectedItemsOfLou);
               } else {
                 this.setState({
                     childData: selectedItemsOfLou,
                 })
               }
            }
        }
        }
        getPersonsInorg = (data)=>{
            let obj ={
                org:data
            }
            datasave.service(window.GET_PERSONS_ACTIONS, 'POST',obj).then(
                response =>{
                  if(response['status'] == 500){
                    OCAlert.alertWarning("error occured form our side, we're unable to process", { timeOut: 2000 });
                    this.setState({
                      childData:[]
                    })
                  }else{
                    this.setState({
                        childData:response['data']
                    })
                  }
                })
        }
        saveElementData=()=>{
          const{webElementId,parentID,webElementName,webElementValue,childId,webElementType,operator,t,count,periodType,controlType} =this.state;
          if((webElementType>0 && webElementType!==window.DATEFIELD &&( webElementName=='' || webElementValue===''))||webElementType<1){
            OCAlert.alertWarning(t('Controls and value is mandatory'),{ timeOut: window.TIMEOUTNOTIFICATION });
            return;
          }
          let custom ='';
          if(webElementType==window.DATEFIELD && operator===1 && parseInt(webElementValue)>0){
            let duration = periodType===1?'Hours': periodType===2?'Days':periodType===3?'Months':'Years';
            custom = t('Now') +'+'+ webElementValue +' '+ t(duration);
          }
          if(webElementType==window.DATEFIELD && operator===2 && parseInt(webElementValue)>0){
            let duration = periodType===1?'Hours': periodType===2?'Days':periodType===3?'Months':'Years';
            custom = t('Now') +'-'+ webElementValue + ' ' +t(duration);
          }
          if(webElementType==window.DATEFIELD && operator===2 && parseInt(webElementValue)<1){
            custom = t('Now');
          }
          let data ={
            id:this.props.state.currentWebElementId,
            webElementId:webElementId,
            parentID:parentID,
            webElementName:webElementName,
            webElementValue:webElementType===window.DATEFIELD && controlType===2?custom:webElementValue,
            childId:childId,
            webElementType:webElementType,
            operator:operator,
            count:count,
            periodType:webElementType===window.DATEFIELD && controlType===2?periodType:'',
            controlType:controlType,
          }
          if(webElementId && webElementType){
          this.props.saveAddWebElements(data);
         }
        }
        handleRadioSelect =(type)=>{
          this.setState({
            controlType:type,
            webElementValue:'',
            operator:1,
            periodType:4,
            count:''
          })
        }
        handlePeriodChange(e,from){
          const {  childNodes, selectedIndex } = e.target
          let valueId = childNodes[selectedIndex].getAttribute('id')
          this.setState({
            [from]:parseInt(valueId),
          })
        }
        changeCustomValues=(e)=>{
          this.setState({
            webElementValue:e.target.validity.valid ? e.target.value: this.state.value!== undefined?this.state.webElementValue:''
          })
        }
        getColumnFields=()=>{
          const {webElementValue,t}=this.state;
          let options = [];
          let valueFields = [];
          this.props.state.allColumns.map(item => {
            return   options.push(<option  key = {item.name} id={item.name} name  = {item.name} value = {item.name}> {item.name}</option>)
          })
          valueFields.push(
            <reactbootstrap.Form.Control style={{  }} as="select" name="outype" value={webElementValue} onChange={this.changeColumnValues} >
            <option>{t("---Select---")}</option>
            {options}
            </reactbootstrap.Form.Control>  )
            return valueFields;
        }
        changeColumnValues=(e)=>{
          this.setState({
            webElementValue:e.target.value,
          })
        }
        getCustomdate = ()=>{
          const  {category,operator,t,webElementValue} =  this.state

          return(<>
            <reactbootstrap.Row className='mt-1'>
            <reactbootstrap.Col className='col-md-3'>
            </reactbootstrap.Col>
            <reactbootstrap.Col className='col-md-9 px-0'>
            <reactbootstrap.Form.Control
            as="select"
            name="type"
            >
            <option>{t('Now')}</option>
            </reactbootstrap.Form.Control>
            </reactbootstrap.Col>
            </reactbootstrap.Row>
            <reactbootstrap.Row className='mt-1'>
            <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Period')}</reactbootstrap.FormLabel>
            <reactbootstrap.Col className='col-md-9 px-0'>
            <reactbootstrap.Form.Control
            as="select"
            name="type"
            value = {operator}
            onChange = {(e)=>this.handlePeriodChange(e,'operator')}
            >
            <option id  = {1} value = {1} name  = {'+'}>{t('Addition')}</option>
            <option id  = {2} value = {2} name  = {'-'} >{t("Subtraction")}</option>
            </reactbootstrap.Form.Control>
            </reactbootstrap.Col>
            </reactbootstrap.Row>
            <reactbootstrap.Row className='mt-1'>
            <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Value')}</reactbootstrap.FormLabel>
            <reactbootstrap.Col className='col-md-9 px-0'>
            <reactbootstrap.Form.Control pattern = {"[0-9]+(,[0-9]+)*,?"} style={{  }} onChange={this.changeCustomValues} placeholder = 'Value' value={webElementValue}/>
            </reactbootstrap.Col>
            </reactbootstrap.Row>
            <reactbootstrap.Row className='mt-1'>
            <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Category')}</reactbootstrap.FormLabel>
            <reactbootstrap.Col className='col-md-9 px-0'>
            <reactbootstrap.Form.Control
            as="select"
            name="type"
            value = {category}
            onChange = {(e)=>this.handlePeriodChange(e,'periodType')}>
            <option id = {4} value = {4} name  = 'Years'>{t("Years")}</option>
            <option id = {3}  value = {3} name = 'Months'> {t("Months")}</option>
            <option id = {2}  value = {2} name = 'Days'> {t("Days")}</option>
            <option id ={1} value = {1}  name  = 'Hours'> {t("Hours")}</option>
            </reactbootstrap.Form.Control>
            </reactbootstrap.Col>
            </reactbootstrap.Row>
            </>)
          }
          render(){
            const {t,webElementId,webElementType,controlType}=this.state;
            const allElements = this.props.state.allwebElements;
            let controlOptions =[];
            allElements.map(item=>{
              let namewithtype = item.alias+'('+item.typename+')';
              controlOptions.push(<option key = {item.id} name= {namewithtype}  value  = {item.id} type={item.type} id={item.id} parent_id={item.list_id}> {item.alias}({item.typename}) </option>)
            })
            return(
              <reactbootstrap.Container>
              <reactbootstrap.Row className='mt-1'>
              <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Controls')}</reactbootstrap.FormLabel>
              <reactbootstrap.Col className='col-md-9 px-0'>
              <reactbootstrap.Form.Control
              as="select"
              name="type"
              value={webElementId}
              onChange={this.changeControls} >
              <option > {t("---Select---")} </option>
              {controlOptions}
              </reactbootstrap.Form.Control>
              </reactbootstrap.Col>
              </reactbootstrap.Row>
              {parseInt(webElementType)>0 && parseInt(webElementType)!==window.DATEFIELD &&
                <>
                <reactbootstrap.Row>

                {this.props.state.allColumns.length>0 &&<><input type='radio'   name='radio'   checked = {controlType === 1} onChange = {(e)=>this.handleRadioSelect(1)} />{t('Value')}&nbsp;&nbsp;</>}
                {this.props.state.allColumns.length>0 &&<><input type='radio'   name='radio'   checked = {controlType === 3} onChange = {(e)=>this.handleRadioSelect(3)} />{t('Column')}&nbsp;&nbsp;</>}
                </reactbootstrap.Row>
              {controlType===1 &&<reactbootstrap.Row className='mt-1'>
              <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Value')}</reactbootstrap.FormLabel>
              <reactbootstrap.Col className='col-md-9 px-0'>
              {this.getValueFields()}
              </reactbootstrap.Col>
              </reactbootstrap.Row>}

            {controlType===3 &&<reactbootstrap.Row className='mt-1'>
            <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Value')}</reactbootstrap.FormLabel>
            <reactbootstrap.Col className='col-md-9 px-0'>
            {this.getColumnFields()}
            </reactbootstrap.Col>
            </reactbootstrap.Row>}
              </>}
              {parseInt(webElementType)>0 && parseInt(webElementType)===window.DATEFIELD && <>
                <reactbootstrap.Row className='mt-3 pl-2'>
                <input type='radio'   name='radio'   checked = {controlType === 1} onChange = {(e)=>this.handleRadioSelect(1)} />{t('Value')}&nbsp;&nbsp;
                <input type='radio'   name='radio'   checked = {controlType === 2} onChange = {(e)=>this.handleRadioSelect(2)} />{t('Custom date')}&nbsp;&nbsp;
                {this.props.state.allColumns.length>0 &&<><input type='radio'   name='radio'   checked = {controlType === 3} onChange = {(e)=>this.handleRadioSelect(3)} />{t('Column')}&nbsp;&nbsp;</>}
                </reactbootstrap.Row>
                {controlType === 1 &&<reactbootstrap.Row className='mt-1'>
                <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Value')}</reactbootstrap.FormLabel>
                <reactbootstrap.Col className='col-md-9 px-0'>
                { this.getValueFields()}
                </reactbootstrap.Col>
                </reactbootstrap.Row>}
                {controlType === 2 &&
                  this.getCustomdate()
                }
                {controlType === 3 &&<reactbootstrap.Row className='mt-1'>
                  <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Value')}</reactbootstrap.FormLabel>
                  <reactbootstrap.Col className='col-md-9 px-0'>
                  {this.getColumnFields()}
                  </reactbootstrap.Col>
                  </reactbootstrap.Row>
                }
                </>}
                <reactbootstrap.Row className='mt-3' style={{float:'right'}}>
                <a style={{paddingTop:'15px'}} onClick={e=>this.props.cancelAddWebelements()}>{t('Cancel')}</a>&nbsp;&nbsp;&nbsp;
                <reactbootstrap.Button className='m-2' onClick={e=>this.saveElementData()}>{t('Save')}</reactbootstrap.Button>
                </reactbootstrap.Row>
                </reactbootstrap.Container>
              )
            }
          }
          export default translate(AddWebElements);
