import React, { Component } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import SearchInput, { createFilter } from 'react-search-input'
import PersonImg from '../images/personc.png';
import JobImg from '../images/jobc.png';
import DepartmentImg from '../images/departmentsc.png';
import GroupImg from '../images/groupc.png';
import DeleteImg from '../images/delete1.png';
import '../DragnDrop.css';
import $ from 'jquery';



/**
* Moves an item from one list to another list.
*/
const move = (source, destination, droppableSource, droppableDestination, draggableId) => {
  const sourceClone = Array.from(source);
  const destClone = Array.from(destination);
  const [removed] = sourceClone.filter(items => items.id === draggableId);
  destClone.splice(droppableDestination.index, 0, removed);
  const result = {};
  result[droppableSource.droppableId] = sourceClone.filter(items => items.id !== draggableId);
  result[droppableDestination.droppableId] = destClone;
  result['latestDropped'] = removed;
  result['type'] = (droppableDestination.droppableId === 'droppable') ? 'remove' : 'add';
  return result;
};
const grid = 8;


const getListStyle = isDraggingOver => ({
  background: isDraggingOver ? 'lightblue' : '#fff',
  padding: grid,
  //  width: '62%',
});

const getFlexStyle = ({
  display: 'flex',
  backgroundColor: '#fff',
});

const imageStyle = ({
  width: 20,
  cursor: "default",
});
const commonTdStyle = ({
  backgroundColor: '#fff',
  color: '#212529',
  border: '1px solid #fff',
  fontSize: '14px',
  paddingLeft: '32px',
  verticalAlign: 'middle',
  zIndex:'0px'
});
const textinline = ({
  display: '-webkit-inline-flex',
});

class CommonPlannerDragAndDrop extends Component {
  constructor(props) {
    super(props)
    this.state = ({
      t : props.t,
      KEYS_TO_FILTERS :window.search_fields,
      items: [],
      selected: [],
      types: [],
      searchData: [],
      searchTerm: [],
      searchType: '',
      result_obj:[],
      type: '',
      parent: "tooltip",
      updated: 1,
      html : window.REPORTS_OBJECT,
      html_right : window.HTML_RIGHT,
    })
  }

  componentDidMount(){
    this.setState({
      items: this.props.tasks,
      selected :this.props.selected,
    })
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevState.items !== this.props.tasks) {
      this.setState({
        items: this.props.tasks,
        selected :this.props.selected,
      })
    }
  }
  searchUpdated=(term, itemlist)=>{
    const items = { ...this.state.searchTerm };
    items[itemlist] = term;
    this.setState({
      searchTerm: items,
      searchType: itemlist,
    })
  }

        updateSelectAll() {
          $('tr').find('#verify').each(function(){
            $(this).appendTo($(this).parent().find('#9'));
            // $(this).parent().parent().find('#verify').remove();
          })
          $('tr').find('#authorise').each(function(){
            $(this).appendTo($(this).parent().find('#10'));
            // $(this).parent().parent().find('#authorise').remove();
          })
        }

        /**
        * A semi-generic way to handle multiple lists. Matches
        * the IDs of the droppable container to the names of the
        * source arrays stored in the state.
        */
        id2List = {
          droppable: 'items',
          droppable2: 'selected'
        };

        handleDragSelectedChange = (result) => {
          this.setState({
            items: result.droppable,
            selected: result.droppable2
          }, () => {
            this.props.updateSelectedChild(result.latestDropped, result, this.props.tab, this.props.notify_id);
          });
        }
        getList = id => this.state[this.id2List[id]];

        onDragEnd = resultObj => {
          const { source, destination, draggableId } = resultObj;
          // dropped outside the list
          if (!destination) {
            return;
          }
          if (source.droppableId === destination.droppableId) {
            return;
          } else {
            const result = move(
              this.getList(source.droppableId),
              this.getList(destination.droppableId),
              source,
              destination,
              draggableId
            );
            this.handleDragSelectedChange(result);
          }
        };
        handleClicktrTask=(resultObj,task_status = 0,show_comment = true)=>{
            resultObj.checked=false;
          if (this.props.details.disableFields ||this.props.details.exp_his_disabled|| this.props.disable_based_on_right || this.props.approvalcycle_disabled || this.props.extra_tab_disabled||this.props.default_tab_disabled) {
            return;
          }
          this.handleClicktr(resultObj);
        }
        handleClicktr=(resultObj)=> {
          if (this.props.details.disableFields ||this.props.details.exp_his_disabled|| this.props.disable_based_on_right || this.props.approvalcycle_disabled || this.props.extra_tab_disabled||this.props.default_tab_disabled) {
            return;
          }
          var selected = this.state.selected;
          var remove = selected.filter(item => (item.name !== resultObj.name && item.id !== resultObj.id));
          const result = {};
          result['latestDropped'] = resultObj;
          result['type'] = 'remove';
          this.setState(prevState => ({
            items: [...prevState.items, resultObj],
            selected: remove,
          }), () => {
            this.props.updateSelectedChild(result.latestDropped, result, this.props.tab, this.props.notify_id);
          });
        }
        rowImage=(item)=>{
          switch (item) {
            case 'persons':
            return PersonImg;
            break;
            case 'jobs':
            return JobImg;
            break;
            case 'departments':
            return DepartmentImg;
            break;
            default:
            return GroupImg
          }
        }
        render(){
          const { html_right,html} = this.state;
          this.updateSelectAll();
        if (this.props.types && this.state.items) {
          const types = this.props.types;
          if (this.props.selected && this.props.selected.length === 0 && this.props.updateProps === 1 && this.state.updated > 0) {
            this.setState({
              selected: this.props.selected,
              updated: 0,
            });
          }
          else if (this.props.selected && this.props.selected.length > 0 && this.props.updateProps === 1 && this.state.selected.length === 0) {
            this.setState({
              selected: this.props.selected,
              updated: 2,
            });
          }
          var filteredNames = [];
          var dragObject = <reactbootstrap.Tabs style={{width:"100%",backgroundColor:'white'}} activeKey={parseInt(this.props.details.dragNDropActiveTab)} onSelect={this.props.onSelect} >
          {Object.values(types).map(
            function (itemlist, key) {
              var search = '';
              if (this.state.searchTerm && this.state.searchType) {
                search = this.state.searchTerm[itemlist];
                search = (search) ? search : '';
              }
              filteredNames[itemlist] = this.state.items.filter(createFilter(search, this.state.KEYS_TO_FILTERS));
              return (
                <reactbootstrap.Tab className="input-right-field" id="dashdragndrop" eventKey={parseInt(key)} title={itemlist.charAt(0).toUpperCase() + itemlist.slice(1)}>
                <reactbootstrap.Table  responsive striped hover >

                <thead style={{position: 'sticky',top: '0',backgroundColor: '#fff'}}>
                <tr>
                <td style={{ padding: '0.25rem' }} colSpan="3" >
                <SearchInput style={{ colour: 'red', border: '0px', color: '#EC661C', fontSize: '13px', }} className="search-input approval-input" onChange={(e) => this.searchUpdated(e, itemlist)} />
                </td>
                </tr>
                <tr style={{display:'none'}}>
                {html_right[0][itemlist].map(rights =>
                  <th style={{ backgroundColor: '#EC661C', fontSize: '14px', color: '#fff', padding: '0.25rem' }} title={rights.name}>{rights.name}</th>
                )}
                </tr>
                </thead>
                <tbody style={{ backgroundColor: '#fff', border: '0px' }}>
                {Object.values(filteredNames[itemlist]).map(

                  function (item, index) {
                    item.category_id = (item.entity_type_id) ? item.entity_type_id : item.category_id;
                    if (item && item.id && item.category === itemlist) {
                      return (
                        <Draggable className="right-field-border"
                        isDragDisabled={this.props.details.disableFields}
                        key={item.id}
                        draggableId={item.id}
                        type={item.category}
                        index={index}>
                        {(provided, snapshot) => (
                          <tr
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          >
                          <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6'}}>
                          <div style={textinline} >
                          <span className="">{item.category != 'spaces' && <img style={imageStyle} src={this.rowImage(item.category)} alt={item.category} />}&nbsp;</span>&nbsp;
                          <span style={{wordBreak: 'break-word'}}>{item.name}</span>
                          </div>
                          </td>

                        </tr>
                      )}
                      </Draggable>
                    )
                  }
                }, this)}
                </tbody>
                </reactbootstrap.Table>
                </reactbootstrap.Tab>
              )
            }, this)}
            </reactbootstrap.Tabs>
          }
          return(

                  <div className="col-md-12 p-0" style={getFlexStyle} disabled>
                  <DragDropContext onDragEnd={this.onDragEnd} >
                  <Droppable droppableId="droppable2">
                  {(provided, snapshot) => (
                    <div className="selected-item-header-section"
                    ref={provided.innerRef}
                    style={getListStyle(snapshot.isDraggingOver)}>
                    <div className='border-remove' style={{ width: '100%', overflowX: 'auto',  }}>
                    <reactbootstrap.Table style={{ width: '100%', overflowX: 'auto', margin: '0' }} striped responsive bordered hover variant="dark">
                    <thead  style={{ backgroundColor: '#EC661C',position: 'sticky',top: '0' }}>
                    <tr >
                    {html[0]['web'].map(commons =>
                      <th style={{ paddingTop: '20px', border: '0px', }} className={commons.class} key={commons.name} title={commons.name}></th>
                    )}
                    </tr>
                    </thead>
                    <tbody >
                    {this.state.selected && this.state.selected.map(
                      (item, index)=> {
                          return (
                            <tr style={{ backgroundColor: '#fff', border: '0px'}}>
                            <td style={commonTdStyle}>
                            <div style={textinline} >
                            <div ><img style={imageStyle} src={this.rowImage(item.category)} alt={item.category} /></div>&nbsp;
                            <span style={{cursor: 'default', wordBreak: 'break-word',width: '5rem'}}>{item.name}</span>
                            </div>
                            </td>
                            <td className = 'remove' style={{textAlign: 'center'}}  disabled={this.props.details.disableFields || this.props.disable_based_on_right||this.props.approvalcycle_disabled||this.props.extra_tab_disabled||this.props.default_tab_disabled}>
                            {this.props.remove_type === undefined && <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => this.handleClicktr(item)}></img>}
                            {this.props.remove_type === true && <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => this.handleClicktrTask(item)}></img>}
                            </td>
                            </tr>
                          );
                      }, this)}
                      {provided.placeholder}
                      </tbody>
                      </reactbootstrap.Table>
                      </div>
                      </div>
                    )}
                    </Droppable>
                    <Droppable droppableId="droppable">
                    {(provided, snapshot) => (
                      <div className="avialble-filed-person "
                      ref={provided.innerRef}
                      style={getListStyle(snapshot.isDraggingOver)}
                      >
                      {provided.placeholder}
                      {dragObject}
                      </div>
                    )}
                    </Droppable>
                    </DragDropContext>
                    </div>
          )
        }

}
export default translate(CommonPlannerDragAndDrop);
