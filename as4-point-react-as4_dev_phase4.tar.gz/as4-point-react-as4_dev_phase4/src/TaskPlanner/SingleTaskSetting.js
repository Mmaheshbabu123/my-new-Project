import React from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import moment from 'moment';
import TimeField from 'react-simple-timefield';
function SingleTaskSetting(props){
  const {startDate,startTime}=props.state;
  const t = props.t;
  const formDisabled = (props.action === 'view') ? true : '';
  return(
    <reactbootstrap.Container>
      <reactbootstrap.Form >
        <fieldset disabled={formDisabled}>
    <reactbootstrap.Row className="mt-2">
    <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Start date:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
    <reactbootstrap.FormControl
           name="startDate"
           type="date"
           value={startDate}
           onChange={e=>props.handleChangeDate(e.target.value,'startDate')}
           min={moment().format("YYYY-MM-DD")}
           className="col-md-9 input_sw"
       />
    </reactbootstrap.Row>
    <reactbootstrap.Row className="mt-2">
    <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Start time:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
    <TimeField
        name='startTime'
        value={startTime}
        style={{
            border: '1px solid lightgray',
            fontSize: 17,
            width: 120,
            padding: '5px 8px',
            color: '#333',
            borderRadius: 3,
            height: 37,
            textAlign: 'center',
            backgroundColor: '#fff'
        }}
          className="col-md-3 input_sw"
        onChange={e=>props.onTimeChange(e.target.value,'startTime')}/>
    </reactbootstrap.Row>
  </fieldset>
</reactbootstrap.Form >

    </reactbootstrap.Container>
  )
}
export default translate(SingleTaskSetting);
