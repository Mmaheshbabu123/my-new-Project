import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { datasave } from '../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import WebformSettings from './WebformSettings';
import RecurrentTaskSetting from './RecurrentTaskSetting';
import GeneralSettings from './GeneralSettings';
import ImportOptionSettingsDb from './ImportOptionSettingsDb';
import ImportOptionSettingsFile from './ImportOptionSettingsFile';
import SingleTaskSetting from './SingleTaskSetting';
import ImportPlanning from '../SchedularTask/ImprtPlanning';
import CommonPlannerDragAndDrop from './CommonPlannerDragAndDrop';
import PlannerQueryComponent from './PlannerQueryComponent';
import axios from 'axios';
const WebElementSkeleton = {
  id: 0,
  webElementId: 0,
  parentID: 0,
  webElementName: '',
  webElementValue: '',
  childId: 0,
  webElementType: 0,
  operator: '',
  controlType: 1,
  periodType: 0,
  count: 0
}
class PlanningIndex extends Component {
  technicalQuery = '';
  constructor(props) {
    super(props)
    console.log(props);
    this.state = {
      t: props.t,
      title: '',
      description: '',
      TaskPlannertypes: [
        {
          label: props.t('Recurrent task'),
          value: 1
        },
        {
          label: props.t('Single task'),
          value: 2,
        },
        {
          label: props.t('Task based on excel'),
          value: 3
        },
        {
          label: props.t('Task based on database'),
          value: 4
        }
      ],
      plannerTypeOptions: [],
      selectedPlannerType:
      {
        label: props.t('Recurrent task'),
        value: 1
      },
      dueDateNumber: '',
      Durations: [
        {
          label: props.t('Days'),
          value: 'days',
        },
        {
          label: props.t('Weeks'),
          value: 'weeks',
        },
        {
          label: props.t('Months'),
          value: 'months',
        },
        {
          label: props.t('Years'),
          value: 'years'
        }
      ],
      dueDatePeriodOptions: [],
      selectedDueDatePeriod: {
        label: props.t('Days'),
        value: 'days',
      },
      typeOptions: [],
      selectedType: [],
      allSubTypes: [],
      subTypeOptions: [],
      selectedSubType: [],
      active: 1,
      notification: false,
      beforeDeadline: false,
      afterDeadLine: false,
      email: false,
      dashboard: false,
      webFormOptions: [],
      selectedWebForm: [],
      Actors: [
        {
          value: window.PERSON_ENTITY,
          label: props.t('Person'),
        },
        {
          value: window.JOB_ENTITY,
          label: props.t('Job'),
        },
        {
          value: window.DEPARTMENT_ENTITY,
          label: props.t('Department')
        },
        {
          value: window.GROUP_ENTITY,
          label: props.t('Group')
        },
        {
          value: window.EVERY_ONE_ENTITY,
          label: props.t('Everyone')
        },
        {
          value: window.SEARCH_IN_DB,
          label: props.t('Search in database')
        }
      ],
      actorOptions: [],
      selectedActor:
      {
        value: window.PERSON_ENTITY,
        label: props.t('Person'),
      },
      searchInDbOptions: [
        {
          value: window.PERSON_ENTITY,
          label: props.t('Person'),
        },
        {
          value: window.JOB_ENTITY,
          label: props.t('Job'),
        },
        {
          value: window.DEPARTMENT_ENTITY,
          label: props.t('Department')
        },
        {
          value: window.GROUP_ENTITY,
          label: props.t('Group')
        }
      ],
      selectedsearchInDb: [],
      Recurrency: [
        {
          value: 1,
          label: props.t('Fixed interval')
        },
        {
          value: 2,
          label: props.t('Last start date')
        },
        {
          value: 3,
          label: props.t('Last stop date')
        }
      ],
      recurrencyOptions: [],
      selectedRecurrency:
      {
        value: 1,
        label: props.t('Fixed interval')
      },
      startDate: '',
      endDate: '',
      startTime: '',
      nextStartTime: '',
      inrevalNumber: '',
      intervalOptions: [
        {
          label: props.t('Minutes'),
          value: 1,
        },
        {
          label: props.t('Hours'),
          value: 2,
        },
        {
          label: props.t('Days'),
          value: 3,
        },
        {
          label: props.t('Weeks'),
          value: 4,
        },
        {
          label: props.t('Months'),
          value: 5,
        },
        {
          label: props.t('Years'),
          value: 6
        }
      ],
      selectedInterval: {
        label: props.t('Minutes'),
        value: 1,
      },
      nextStartDate: '',
      scheduledReadOut: false,
      runOntaskOnSpecificDay: false,
      readOutExcelOnSpecificDay: false,
      reciverPopup: false,
      importReport: false,
      onlySendOnError: false,
      indexActiveTab: 1,
      planTaskOnHoliday: false,
      beforeDays: '',
      afterDays: '',
      pjgd: [],
      orgUnitOptions: [],
      selectedOrgUnit: [],
      sunday: false,
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      runTaskDays: true,
      filename: '',
      filePath: '',
      fileId: 0,
      allwebElements: [],
      allChildElements: [],
      arrayAddedWebElements: [],
      addWebelementPopUp: false,
      documentOptions: [],
      selectedDocument: [],
      originalAddedWebElements: [],
      copyArrayAddedWebElements: [],
      webElementData: { ...WebElementSkeleton },
      currentWebElementId: 0,
      startWebForm: true,
      templateNeded: false,
      [window.tabs.verifier]: [],
      [window.tabs.responsible]: [],
      tasks: [],
      items: [],
      types: [],
      dragNDropActiveTab: 0,
      addReciverPopUp: false,
      active_tab_for_DragNDrop_Right: 1,
      webFormActorAmount: 0,
      webform_actor_amount_all: false,
      responsible_amount: 0,
      responsible_amount_all: false,
      verify_amount: 0,
      verify_amount_all: false,
      run_task_type_id: 1,
      tableName: '',
      uploadPopUp: false,
      allColumns: [],
      [window.tabs.planningReceiver]: [],
      showCloseFileReceiver: false,
      allActorsFromImportPlanning: [],
      reciverVerifierTab: 1,
      showCloseResponsibleVerifier: false,
      showCloseQueryBuilderPopUp: false,
      csv_file_name: '',
      excelTabName: '',
    }
  }
  async componentDidMount() {
    await this.getFormDetials();
  }
  componentDidUpdate(prevProps, prevState) {
    if (this.props.plannerId != prevProps.plannerId) {
      this.componentDidMount();
    }
  };
  handleActiveTabForDragNDropRight(key) {
    this.setState({
      active_tab_for_DragNDrop_Right: key,
    });
  }
  getFormDetials = async () => {
    const { Recurrency, Durations, TaskPlannertypes, Actors, t } = this.state;
    await datasave.service(window.PLANNING_COMMON_DATA, 'GET').then(response => {
      if (response['status'] === 200) {
        let data = response['data'];
        this.setState({
          typeOptions: data['types'],
          allSubTypes: data['subTypes'],
          webFormOptions: this.sort(Object.values(data['webForms'])),
          pjgd: Object.values(data['PJDB']),
          orgUnitOptions: Object.values(data['PJDB']).filter(item => { return (item.entity_type_id === window.PERSON_ENTITY) }),
          recurrencyOptions: Recurrency,
          dueDatePeriodOptions: Durations,
          plannerTypeOptions: TaskPlannertypes,
          actorOptions: Actors.filter(item => { return (item.value !== window.SEARCH_IN_DB) }),
          documentOptions: Object.values(data['documents']),
          tasks: data['dragAndDrop']['jgd'],
          items: data['dragAndDrop']['jgd'],
          types: data['dragAndDrop']['types'],
          indexActiveTab: 1,
        }, () => {
          if (this.props.action !== 'create') {
            this.getPlannerById();
          }
        })
      } else {
        OCAlert.alertWarning(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    })
  }
  getPlannerById = async () => {
    const { typeOptions, allSubTypes, webFormOptions, pjgd, recurrencyOptions, intervalOptions, Durations, dueDatePeriodOptions,
      plannerTypeOptions, actorOptions, documentOptions, tasks, t, searchInDbOptions, Actors } = this.state;
    await datasave.service(window.Get_EDITABLE_PLANNER_DATA + '/' + this.props.plannerId, 'GET').then(
      async response => {
        if (response['status'] === 200) {
          let data = response['data']['form_Data'];
          let selectedplanner = data['selectedPlannerType'] ? plannerTypeOptions.filter(value => { return value['value'] === data['selectedPlannerType'] }) : [];
          let selectDueDate = data['selectedDueDatePeriod'] ? dueDatePeriodOptions.filter(value => { return value['value'] === data['selectedDueDatePeriod'] }) : { value: 'days', label: 'Days' };
          let selectType = parseInt(data['selectedType']) ? typeOptions.filter(value => { return value['value'] === parseInt(data['selectedType']) }) : [];
          let selectedSubtype = selectType.length > 0 && allSubTypes[parseInt(data['selectedType'])] && Object.values(allSubTypes[parseInt(data['selectedType'])])[parseInt(data['selectedSubType'])] ? Object.values(allSubTypes[parseInt(data['selectedType'])])[parseInt(data['selectedSubType'])] : [];
          let selectWF = webFormOptions.filter(value => { return value['value'] === parseInt(data['docOrWebForm_id']) });
          let selectRecurcy = parseInt(data['selectedRecurrency']) ? recurrencyOptions.filter(value => { return value['value'] === parseInt(data['selectedRecurrency']) }) : [];
          let selectIntrval = data['selectedInterval'] ? intervalOptions.filter(value => { return value['value'] === parseInt(data['selectedInterval']) })[0] : { value: 1, label: 'Minutes' };
          let selectDoc = data['docOrWebForm_id'] ? documentOptions.filter(value => { return value['value'] === data['docOrWebForm_id'] }) : [];
          var filterSearchInDb = [];
          var filterSearchInDbOrg = [];
          var splitedOrder = '';
          if (parseInt(data['selectedActor']) === 10 && data['excelOrder']) {
            splitedOrder = data['excelOrder'].split(',');
            splitedOrder.map(item => {
              let temp = searchInDbOptions.filter(result => {
                return result.value === parseInt(item)
              });
              filterSearchInDb.push(temp[0]);
              let temp2 = pjgd.filter(result => { return result.entity_type_id === parseInt(item) && response['data']['importedAllActors'].includes(result.name) });
              filterSearchInDbOrg.push(temp2);
            })
          }
          let selectOrg = parseInt(data['selectedActor']) === 10 ? pjgd.filter(item => { return item.id === parseInt(data['selectedOrgUnit']) }) : parseInt(data['selectedActor']) !== 10 && parseInt(data['selectedOrgUnit']) ? pjgd.filter(item => { return (item.id === parseInt(data['selectedOrgUnit']) && item.entity_type_id === parseInt(data['selectedActor'])) }) : [];
          this.technicalQuery = data['planner_query'];
          await this.setState({
            title: (this.props.action === 'edit'||this.props.action === 'view') ? data['title'] : '',
            description: data['description'] ? data['description'] : '',
            selectedPlannerType: selectedplanner.length > 0 ? selectedplanner[0] : {
              label: t('Recurrent task'),
              value: 1
            },
            dueDateNumber: data['dueDateNumber'] ? data['dueDateNumber'] : '',
            selectedDueDatePeriod: selectDueDate.length > 0 ? selectDueDate[0] : { value: 'days', label: 'Days' },
            selectedType: selectType.length > 0 ? selectType[0] : [],
            subTypeOptions: allSubTypes[parseInt(data['selectedType'])] ? Object.values(allSubTypes[parseInt(data['selectedType'])]) : [],
            selectedSubType: selectedSubtype,
            notification: data['notification'] ? true : false,
            beforeDeadline: data['beforeDeadline'] ? true : false,
            afterDeadLine: data['afterDeadLine'] ? true : false,
            email: data['email'] ? true : false,
            dashboard: data['dashboard'] ? true : false,
            selectedWebForm: selectWF.length > 0 ? selectWF[0] : [],
            selectedRecurrency: selectRecurcy.length > 0 ? selectRecurcy[0] : { value: 1, label: t('Fixed interval') },
            startDate: data['startDate'] ? data['startDate'] : '',
            endDate: data['endDate'] ? data['endDate'] : '',
            startTime: data['startTime'] ? data['startTime'] : '',
            nextStartTime: data['nextStartTime'] ? data['nextStartTime'] : '',
            inrevalNumber: data['inrevalNumber'] ? data['inrevalNumber'] : '',
            selectedInterval: selectIntrval,
            nextStartDate: data['nextStartDate'] ? data['nextStartDate'] : '',
            // scheduledReadOut:data['scheduledReadOut']?true:false,
            scheduledReadOut: false,
            importReport: data['importReport'] ? true : false,
            onlySendOnError: data['onlySendOnError'] ? true : false,
            planTaskOnHoliday: data['planTaskOnHoliday'] ? true : false,
            beforeDays: data['beforeDays'] !== null ? data['beforeDays'] : '',
            afterDays: data['afterDays'] !== null ? data['afterDays'] : '',
            orgUnitOptions: filterSearchInDbOrg.length > 0 ? Object.values(filterSearchInDbOrg.flat()) : pjgd.filter(item => { return (item.entity_type_id === parseInt(data['selectedActor'])) }),
            selectedOrgUnit: selectOrg.length > 0 ? selectOrg[0] : [],
            sunday: data['sunday'] ? true : false,
            monday: data['monday'] ? true : false,
            tuesday: data['tuesday'] ? true : false,
            wednesday: data['wednesday'] ? true : false,
            thursday: data['thursday'] ? true : false,
            friday: data['friday'] ? true : false,
            saturday: data['saturday'] ? true : false,
            runTaskDays: data['runTaskDays'] ? true : false,
            filename: data['filename'] ? data['filename'] : '',
            filePath: data['filePath'] ? data['filePath'] : '',
            fileId: data['fileId'] ? data['fileId'] : 0,
            arrayAddedWebElements: response['data']['addElements'] ? response['data']['addElements'] : [],
            selectedDocument: selectDoc.length > 0 ? selectDoc[0] : [],
            originalAddedWebElements: response['data']['addElements'],
            copyArrayAddedWebElements: response['data']['addElements'],
            startWebForm: data['startWebForm'] ? true : false,
            templateNeded: data['templateNeded'] ? true : false,
            webFormActorAmount: data['webFormActorAmount'] ? data['webFormActorAmount'] : 0,
            webform_actor_amount_all: data['webform_actor_amount_all'] ? true : false,
            selectedActor: parseInt(data['selectedPlannerType']) !== 3 ? actorOptions.filter(value => { return value.value === parseInt(data['selectedActor']) })[0] : Actors.filter(value => { return value.value === parseInt(data['selectedActor']) })[0],
            actorOptions: parseInt(data['selectedPlannerType']) !== 3 ? actorOptions : Actors,
            responsible_amount: data['responsible_amount'] ? data['responsible_amount'] : 0,
            responsible_amount_all: data['responsible_amount_all'] ? true : false,
            verify_amount: data['verify_amount'] ? data['verify_amount'] : 0,
            verify_amount_all: data['verify_amount_all'] ? true : false,
            [window.tabs.verifier]: response['data']['verifier'] ? Object.values(tasks).filter(value => { return response['data']['verifier'].includes(value['id']) }) : [],
            [window.tabs.responsible]: response['data']['responsible'] ? Object.values(tasks).filter(value => { return response['data']['responsible'].includes(value['id']) }) : [],
            run_task_type_id: data['run_task_type_id'] ? parseInt(data['run_task_type_id']) : 1,
            tableName: data['tableName'] ? data['tableName'] : '',
            csv_file_name: ['csv_file_name'] ? data['csv_file_name'] : '',
            allColumns: this.costructColumns(response['data']['columns']),
            [window.tabs.planningReceiver]: response['data']['mailReciverIds'].length > 0 ? Object.values(tasks).filter(value => { return response['data']['mailReciverIds'].includes(value['id']) }) : [],
            selectedsearchInDb: Object.values(filterSearchInDb.flat()),
            active: data['active'] ? 1 : 0,
            allActorsFromImportPlanning: response['data']['importedAllActors'],
            excelTabName: data['tableName'] ? data['tableName'] : '',
          }, () => {
            this.getWebElementsAndChildData(parseInt(data['docOrWebForm_id']) ? parseInt(data['docOrWebForm_id']) : 0);
          })
        } else {
          OCAlert.alertWarning(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      }
    )
  }
  sort = (data) => {
    return Object.values(data).sort(function (a, b) { return (a.label).toLowerCase() < (b.label).toLowerCase() ? -1 : 1; });
  }
  indexTabChange = (key) => {
    this.setState({
      indexActiveTab: key
    })
  }
  openCloseRecivier = () => {
    this.setState({
      addReciverPopUp: !this.state.addReciverPopUp
    })
  }
  handleChangeWebform = async (value, name) => {
    const { selectedWebForm, copyArrayAddedWebElements } = this.state;
    this.setState({
      copyArrayAddedWebElements: value.value === selectedWebForm.value ? copyArrayAddedWebElements : [],
      arrayAddedWebElements: value.value === selectedWebForm.value ? copyArrayAddedWebElements : [],
      [name]: value
    }, () => { this.getWebElementsAndChildData(value.value) });
  }
  getWebElementsAndChildData = async (id) => {
    await datasave.service(window.FETCH_ALL_WEBELEMENTS + '?webform_id=' + id + "&fromSimulate=1", 'POST').then(async response => {
      if (response['status'] === '200') {
        let filteredHasSelectorElements = Object.values(response['data']).filter(value => { return [Window.LIST, window.RADIO_BUTTON, Window.CHECKBOX, window.LISTORG].includes(value.type) });
        let filteredHasSelector = filteredHasSelectorElements.map(value => { return value.list_id });
        await this.getParentChildDataByWebelementId(filteredHasSelector, Object.values(response['data']).filter(value => { return [Window.LIST, window.RADIO_BUTTON, Window.CHECKBOX, window.LISTORG, window.TEXTFIELD, window.DECIMALFIELD, window.NUMERICFIELD, window.DATEFIELD, window.TEXTBOX].includes(value.type) }));
      }
    }
    )
  }
  getParentChildDataByWebelementId = async (ids, allData) => {
    if (ids.length > 0) {
      await datasave.service(window.GET_PARENT_CHILD_DATA_BY_ARRAY, 'POST', ids).then(async response => {
        if (response['status'] === 200) {
          this.setState({
            allwebElements: allData,
            allChildElements: response['data']
          })
        }
      });
    } else {
      this.setState({
        allwebElements: allData.length > 0 ? allData : [],
        allChildElements: []
      })
    }
  }
  handleChangeActor = (value, name) => {
    const { selectedOrgUnit, pjgd } = this.state;
    if (name === 'selectedActor') {
      this.setState({
        orgUnitOptions: pjgd.filter(item => { return (item.entity_type_id === value.value) }),
        selectedOrgUnit: selectedOrgUnit.entity_type_id !== value.value ? [] : selectedOrgUnit,
        webFormActorAmount: [window.JOB_ENTITY, window.DEPARTMENT_ENTITY, window.GROUP_ENTITY].includes(value.value) ? 1 : 0,
        webform_actor_amount_all: false,
        selectedsearchInDb: [],
        [name]: value
      })
    } else {
      this.setState({
        [name]: value
      })
    }
  }
  habdleChangeRecurrency = (value, name) => {
    this.setState({
      [name]: value,
      sunday: false,
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      runTaskDays: value.value === 1 ? true : false,
    })
  }
  handleChangeDate = (value, name) => {
    this.setState({
      [name]: value
    })
  }
  onTimeChange = (value, name) => {
    this.setState({
      [name]: value.replace(/-/g, ':').padEnd(8, value.substr(5, 3)),
    })
  }
  textOnChnage = (value, name) => {
    this.setState({
      [name]: value
    })
  }
  handleSelect = (checked, name) => {
    const { t } = this.state;
    if (name === 'notification') {
      this.setState({
        notification: checked,
        beforeDeadline: false,
        afterDeadLine: false,
        beforeDays: '',
        afterDays: '',
        email: false,
        dashboard: false,
      })
    } else if (name === 'runTaskDays') {
      this.setState({
        sunday: false,
        monday: false,
        tuesday: false,
        wednesday: false,
        thursday: false,
        friday: false,
        saturday: false,
        run_task_type_id: 1,
        [name]: checked
      })
    } else if (name === 'startWebForm') {
      this.setState({
        selectedWebForm: [],
        copyArrayAddedWebElements: [],
        arrayAddedWebElements: [],
        selectedActor: [],
        selectedOrgUnit: [],
        selectedsearchInDb: [],
        templateNeded: false,
        selectedDocument: [],
        allwebElements: [],
        [window.tabs.verifier]: [],
        [window.tabs.responsible]: [],
        verify_amount: 0,
        verify_amount_all: false,
        responsible_amount: 0,
        responsible_amount_all: false,
        webFormActorAmount: 0,
        webform_actor_amount_all: false,
        [name]: checked
      })
    } else if (name === 'templateNeded') {
      this.setState({
        selectedDocument: [],
        [name]: checked
      })
    } else if (name === 'afterDeadLine') {
      this.setState({
        afterDays: '',
        [name]: checked
      })
    } else if (name === 'beforeDeadline') {
      this.setState({
        beforeDays: '',
        [name]: checked
      })
    }
    // else if (name==='scheduledReadOut') {
    //   this.setState({
    //     startDate:'',
    //     endDate:'',
    //     startTime:'',
    //     runTaskDays:false,
    //     sunday:false,
    //     monday:false,
    //     tuesday:false,
    //     wednesday:false,
    //     thursday:false,
    //     friday:false,
    //     saturday:false,
    //     run_task_type_id:1,
    //     onlySendOnError:false,
    //     [window.tabs.planningReceiver]: [],
    //     importReport:false,
    //     inrevalNumber:'',
    //     selectedInterval:
    //     {
    //       label:t('Minutes'),
    //       value:1,
    //     },
    //     [name]:checked,
    //   })
    // }
    else if (name === 'importReport') {
      this.setState({
        onlySendOnError: checked ? true : false,
        [window.tabs.planningReceiver]: [],
        [name]: checked
      })
    } else if (name === 'onlySendOnError') {
      this.setState({
        // [window.tabs.planningReceiver]: [],
        [name]: checked
      })
    } else {
      this.setState({
        [name]: checked
      })
    }
  }
  handleChangePlannerType = async (value) => {
    const { Actors } = this.state;
    if (value.value === 3) {
      this.setState({
        selectedPlannerType: value,
        actorOptions: Actors,
      }, () => { this.tabValidation(value) })
    } else {
      this.setState({
        actorOptions: Actors.filter(item => { return (item.value !== window.SEARCH_IN_DB) }),
        selectedPlannerType: value,
      }, () => { this.tabValidation(value) })
    }

  }
  tabValidation = async (value) => {
    const { t, pjgd } = this.state;
    await this.setState({
      sunday: false,
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      runTaskDays: true,
      // file:'',
      // file_details:'',
      // fileId:0,
      planTaskOnHoliday: false,
      selectedInterval:
      {
        label: t('Minutes'),
        value: 1,
      },
      scheduledReadOut: false,
      runOntaskOnSpecificDay: false,
      readOutExcelOnSpecificDay: false,
      reciverPopup: false,
      importReport: false,
      onlySendOnError: false,
      selectedRecurrency:
      {
        value: 1,
        label: t('Fixed interval')
      },
      startDate: '',
      endDate: '',
      startTime: '',
      inrevalNumber: '',
      arrayAddedWebElements: [],
      run_task_type_id: 1,
      selectedsearchInDb: [],
      allColumns: [],
      copyArrayAddedWebElements: [],
      originalAddedWebElements: [],
      currentWebElementId: 0,
      startWebForm: true,
      templateNeded: false,
      selectedDocument: [],
      verify_amount: 0,
      verify_amount_all: false,
      responsible_amount: 0,
      responsible_amount_all: false,
      selectedWebForm: [],
      selectedActor: {
        value: window.PERSON_ENTITY,
        label: t('Persons')
      },
      selectedOrgUnit: [],
      webFormActorAmount: 0,
      webform_actor_amount_all: false,
      allwebElements: [],
      orgUnitOptions: pjgd.filter(item => { return (item.entity_type_id === window.PERSON_ENTITY) }),
      [window.tabs.planningReceiver]: [],
      allActorsFromImportPlanning: [],

    })
  }
  handleNumber = (value, name) => {
    let regex = /^[0-9\b]+$/;
    if (value === '' || regex.test(value)) {
      this.setState({
        [name]: value
      })
    }
  }
  handleChangeDuration = (value, name) => {
    this.setState({
      [name]: value
    })
  }
  handleChangeTypeSubType = (value, name) => {
    const { allSubTypes } = this.state;
    if (name === 'selectedType') {
      this.setState({
        subTypeOptions: allSubTypes[value.value] ? Object.values(allSubTypes[value.value]) : [],
        selectedType: value,
        selectedSubType: []
      })
    } else {
      this.setState({
        selectedSubType: value
      })
    }
  }
  handleFile = async (e) => {
    const formData = new FormData();
    formData.append('file', e.target.files[0])
    const url = window.UPLOAD_FILE + '/' + window.GROUND_PLAN_FILES;
    document.getElementById("loding-icon").setAttribute("style", "display:block;");
    await axios.post(window.backendURL + url, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
      .then(response => {
        document.getElementById("loding-icon").setAttribute("style", "display:none;");
        if (response['data']['status'] === 1) {
          this.setState({
            filename: response['data']['originalfname'],
            filePath: response['data']['filepath'],
            fileId: response['data']['file_id'][0],
          })
        }
      })
      .catch(error => {
        document.getElementById("loding-icon").setAttribute("style", "display:none;");
        OCAlert.alertError('Error occured while importing file', { timeOut: window.TIMEOUTNOTIFICATION });
      })
  }
  addWebElements = () => {
    const { addWebelementPopUp, originalAddedWebElements, selectedPlannerType, fileId, t } = this.state;
    if (selectedPlannerType.value === 3 && fileId < 1) {
      OCAlert.alertWarning(t('Please import planning first'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }
    let uniqueIds = originalAddedWebElements.map(value => { return value['id'] });
    WebElementSkeleton['id'] = this.randomNumberGenerator(uniqueIds);
    this.setState({
      addWebelementPopUp: !addWebelementPopUp,
      webElementData: WebElementSkeleton,
      currentWebElementId: WebElementSkeleton['id'],
    })
  }
  randomNumberGenerator = (uniqueIds) => {
    let randomNumber = Math.floor(Math.random() * 1000000) + 1;
    if (uniqueIds.includes(randomNumber)) {
      return this.randomNumberGenerator(uniqueIds);
    } else {
      return randomNumber;
    }
  }
  closeAddWebelements = () => {
    const { addWebelementPopUp } = this.state;
    this.setState({
      addWebelementPopUp: !addWebelementPopUp,
    })
  }
  saveAddWebElements = (data) => {
    const { arrayAddedWebElements, currentWebElementId } = this.state;
    let filteredAddedWebElements = [];
    filteredAddedWebElements = arrayAddedWebElements.filter(value => { return value.id !== currentWebElementId });
    filteredAddedWebElements.push(data);
    this.setState({
      arrayAddedWebElements: filteredAddedWebElements,
      addWebelementPopUp: false,
      webElementData: { ...WebElementSkeleton },
      currentWebElementId: currentWebElementId,
      copyArrayAddedWebElements: filteredAddedWebElements,
    });
  }
  cancelAddWebelements = () => {
    this.setState({
      webElementData: { ...WebElementSkeleton },
      addWebelementPopUp: !this.state.addWebelementPopUp
    })
  }
  editAddedWebElement = (data) => {
    let filteredData = this.state.allwebElements.filter(value => { return value.id === parseInt(data.webElementId) });
    data['webElementType'] = filteredData[0]['type'];
    data['parentID'] = filteredData[0]['list_id'];
    this.setState({
      webElementData: { ...data },
      currentWebElementId: data.id,
      addWebelementPopUp: !this.state.addWebelementPopUp
    })
  }
  deleteAddedWebElement = (data) => {
    const { arrayAddedWebElements } = this.state;
    this.setState({
      arrayAddedWebElements: arrayAddedWebElements.filter(value => { return value.id !== data.id }),
      currentWebElementId: 0,
      copyArrayAddedWebElements: arrayAddedWebElements.filter(value => { return value.id !== data.id }),
    })
  }
  handleChangeDocument = (value, name) => {
    this.setState({
      [name]: value,
    })
  }
  saveTaskPlan = () => {
    const { title, selectedPlannerType, notification, beforeDeadline, afterDeadLine, email, dashboard, selectedWebForm, selectedActor, startDate,
      endDate, startTime, beforeDays, afterDays, templateNeded, fileId, dueDateNumber, inrevalNumber, onlySendOnError,
      selectedOrgUnit, sunday, monday, tuesday, wednesday, selectedsearchInDb, thursday, friday, saturday, runTaskDays, selectedDocument, t, startWebForm, scheduledReadOut } = this.state;
    let check_start_date = new Date(startDate);
    let check_end_date = new Date(endDate)
    if (title.length < 1) {
      OCAlert.alertWarning(t('Title is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (notification && beforeDeadline === false && afterDeadLine === false) {
      OCAlert.alertWarning(t('If notification needed please select before or after deadline'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (notification && email === false && dashboard === false) {
      OCAlert.alertWarning(t('Please select notification type'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (dueDateNumber === '') {
      OCAlert.alertWarning(t('Due date period is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if ((beforeDeadline && beforeDays.length < 1) || (afterDeadLine && afterDays.length < 1)) {
      OCAlert.alertWarning(t('Please select number of days for notification deadline'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (!startWebForm && templateNeded && !selectedDocument.value) {
      OCAlert.alertWarning(t('Please select document'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (startWebForm && !selectedWebForm.value) {
      OCAlert.alertWarning(t('Please select webform'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if ([1, 4].includes(selectedPlannerType.value) && inrevalNumber === '') {
      OCAlert.alertWarning(t('Select interval is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if ([1, 2, 3, 4].includes(selectedPlannerType.value) && startWebForm && ![window.EVERY_ONE_ENTITY, window.SEARCH_IN_DB].includes(selectedActor.value) && !selectedOrgUnit.value) {
      OCAlert.alertWarning(t('Please select organisation unit'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (selectedPlannerType.value === 2 && (startDate.length < 1 || startTime.length < 1)) {
      OCAlert.alertWarning(t('Time and date is mandatory for single task'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (([1, 4].includes(selectedPlannerType.value) && runTaskDays && sunday === false && monday === false && tuesday === false && wednesday === false && thursday === false && friday === false && saturday === false)) {
      OCAlert.alertWarning(t('Please select minimum one day in a week you would like to run task on specific days'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (selectedPlannerType.value === 3 && fileId < 1) {
      OCAlert.alertWarning(t('Import planning is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (selectedPlannerType.value === 3 && selectedActor.value === 10 && selectedsearchInDb.length < 1) {
      OCAlert.alertWarning(t('Search in database field is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (([1, 4].includes(selectedPlannerType.value) && (!startDate || !endDate))) {
      OCAlert.alertWarning(t('Please enter correct dates'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (([1, 2, 4].includes(selectedPlannerType.value) && !startTime)) {
      OCAlert.alertWarning(t('Please enter correct time'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (([1, 4].includes(selectedPlannerType.value) && (check_start_date > check_end_date))) {
      OCAlert.alertWarning(t('Please enter correct start date and end date'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }
    // else if (onlySendOnError && this.state[window.tabs.planningReceiver].length<1) {
    //   OCAlert.alertWarning(t('Please select receivers'),{ timeOut: window.TIMEOUTNOTIFICATION });
    //   return;
    // }
    else {
      this.savingProcess();
    }
  }
  savingProcess = () => {

    const { title, description, selectedPlannerType, dueDateNumber, selectedDueDatePeriod, selectedType, subTypeOptions, notification,
      beforeDeadline, afterDeadLine, email, dashboard, selectedWebForm, selectedActor, selectedsearchInDb, selectedRecurrency, startDate,
      endDate, startTime, nextStartTime, inrevalNumber, selectedInterval, nextStartDate, scheduledReadOut, importReport, onlySendOnError, beforeDays, afterDays,
      selectedOrgUnit, sunday, monday, tuesday, wednesday, thursday, friday, saturday, runTaskDays, filename,
      filePath, fileId, selectedDocument, startWebForm, arrayAddedWebElements, templateNeded, planTaskOnHoliday,
      verify_amount, verify_amount_all, responsible_amount, responsible_amount_all, webFormActorAmount, webform_actor_amount_all, run_task_type_id, tableName, active, csv_file_name } = this.state;
    let excelOrder = [];
    selectedsearchInDb.map(value => {
      excelOrder.push(value['value']);
    })
    console.log(parseInt(webFormActorAmount));
    let data = {
      title: title,
      description: description,
      selectedPlannerType: selectedPlannerType.value ? selectedPlannerType.value : 1,
      dueDateNumber: dueDateNumber,
      selectedDueDatePeriod: selectedDueDatePeriod.value ? selectedDueDatePeriod.value : 'days',
      selectedType: selectedType.value ? selectedType.value : 0,
      selectedSubType: subTypeOptions.value ? subTypeOptions.value : 0,
      notification: notification ? 1 : 0,
      beforeDeadline: beforeDeadline ? beforeDeadline : 0,
      afterDeadLine: afterDeadLine ? afterDeadLine : 0,
      email: email ? email : 0,
      dashboard: dashboard ? dashboard : 0,
      selectedWebForm: selectedWebForm && selectedWebForm.value ? selectedWebForm.value : 0,
      selectedActor: selectedActor && selectedActor.value ? selectedActor.value : 0,
      selectedsearchInDb: selectedsearchInDb,
      selectedRecurrency: selectedRecurrency && selectedRecurrency.value ? selectedRecurrency.value : 0,
      startDate: startDate,
      endDate: endDate,
      startTime: startTime,
      nextStartTime: nextStartTime,
      inrevalNumber: inrevalNumber ? inrevalNumber : 0,
      selectedInterval: selectedInterval && selectedInterval.value ? selectedInterval.value : 1,
      nextStartDate: nextStartDate,
      scheduledReadOut: scheduledReadOut ? 1 : 0,
      runTaskDays: runTaskDays ? 1 : 0,
      importReport: importReport ? 1 : 0,
      onlySendOnError: onlySendOnError ? 1 : 0,
      beforeDays: beforeDays ? beforeDays : 0,
      afterDays: afterDays ? afterDays : 0,
      selectedOrgUnit: selectedOrgUnit && selectedOrgUnit.value ? selectedOrgUnit.value : 0,
      sunday: sunday ? 1 : 0,
      monday: monday ? 1 : 0,
      tuesday: tuesday ? 1 : 0,
      wednesday: wednesday ? 1 : 0,
      thursday: thursday ? 1 : 0,
      friday: friday ? 1 : 0,
      saturday: saturday ? 1 : 0,
      filename: selectedPlannerType.value && selectedPlannerType.value == 3 && filename ? filename : '',
      filePath: selectedPlannerType.value && selectedPlannerType.value == 3 && filePath ? filePath : '',
      fileId: selectedPlannerType.value && selectedPlannerType.value == 3 && fileId ? fileId : 0,
      selectedDocument: selectedDocument && selectedDocument.value ? selectedDocument.value : 0,
      startWebForm: startWebForm ? 1 : 0,
      arrayAddedWebElements: arrayAddedWebElements,
      responsibleData: this.state[window.tabs.responsible],
      verifierData: this.state[window.tabs.verifier],
      templateNeded: templateNeded ? 1 : 0,
      planTaskOnHoliday: ([1].includes(selectedPlannerType.value) && planTaskOnHoliday) || [2, 3, 4].includes(selectedPlannerType.value) ? 1 : 0,
      verify_amount: Number.isInteger(verify_amount) ? verify_amount : 0,
      verify_amount_all: verify_amount_all ? 1 : 0,
      responsible_amount: Number.isInteger(responsible_amount) ? responsible_amount : 0,
      responsible_amount_all: responsible_amount_all ? 1 : 0,
      webFormActorAmount:parseInt(webFormActorAmount),
      webform_actor_amount_all: webform_actor_amount_all ? 1 : 0,
      run_task_type_id: run_task_type_id,
      tableName: selectedPlannerType.value && selectedPlannerType.value == 3 ? tableName : '',
      csv_file_name: selectedPlannerType.value && selectedPlannerType.value == 3 ? csv_file_name : '',
      excelOrder: excelOrder.join(),
      mailReciverData: this.state[window.tabs.planningReceiver],
      active: active,
      taskplan_db_actor_type: selectedOrgUnit && selectedOrgUnit.entity_type_id ? selectedOrgUnit.entity_type_id : 0,
      planner_query: this.technicalQuery,
    }
    if (this.props.action === 'create') {
      this.storing(data);
    } else if (this.props.action === 'edit') {
      this.updating(data);
    } else {
      this.cloning(data);
    }

  }
  storing = async (data) => {
    const { t } = this.state;
    await datasave.service(window.SAVE_PLANNING, 'POST', data).then(async response => {
      if (response['status'] === 200) {
        OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
        this.props.tables(response['data'][0]);
        this.props.cancel();
      } else {
        OCAlert.alertError(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    })
  }
  updating = async (data) => {
    const { t } = this.state;
    await datasave.service(window.UPDATE_PLANNING + '/' + this.props.plannerId, 'POST', data).then(async response => {
      if (response['status'] === 200) {
        OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
        this.props.tables(response['data'][0]);
        this.props.cancel();
      } else {
        OCAlert.alertError(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    })
  }
  cloning = async (data) => {
    const { t } = this.state;
    await datasave.service(window.CLONE_PLANNING, 'POST', data).then(async response => {
      if (response['status'] === 200) {
        OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
        this.props.tables(response['data'][0]);
        this.props.cancel();
      } else {
        OCAlert.alertError(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    })
  }
  filterArray = (allList, selectedList) => {
    var pack_func = allList;
    Object.values(selectedList).map(
      function (item, key) {
        pack_func = pack_func.filter(selected => (selected.id !== item.id));
      }, this);
    return pack_func;
  }
  updateSelected = (latestDropped, result, type = window.tabs.planningReceiver, id = '') => {
    var array = [...this.state[type]];
    if (result.type === 'remove') {
      var filterArray = array.filter(selected => (selected.name !== latestDropped.name));
    }
    if (result.type === 'remove') {
      this.setState({
        [type]: filterArray
      })
    }
    else {
      this.setState(prevState => ({
        [type]: [...prevState[type], latestDropped]
      }));
    }
  }
  showCloseFileReceiver = () => {
    this.setState({
      showCloseFileReceiver: !this.state.showCloseFileReceiver
    })
  }
  showCloseResponsibleVerifier = () => {
    this.setState({
      showCloseResponsibleVerifier: !this.state.showCloseResponsibleVerifier
    })
  }
  handleReciverVerifierTab = (key) => {
    this.setState({
      reciverVerifierTab: parseInt(key)
    })
  }
  responsibleVerifierPopUp = () => {
    const { showCloseResponsibleVerifier, t, reciverVerifierTab } = this.state;
    var filter_recivers = this.state.tasks;
    if (reciverVerifierTab === 1 && this.state[window.tabs.responsible].length > 0) {
      filter_recivers = this.filterArray(this.state.tasks, this.state[window.tabs.responsible]);
    }
    if (reciverVerifierTab === 2 && this.state[window.tabs.verifier].length > 0) {
      filter_recivers = this.filterArray(this.state.tasks, this.state[window.tabs.verifier]);
    }
    return (
      <reactbootstrap.Modal
        show={showCloseResponsibleVerifier}
        onHide={this.showCloseResponsibleVerifier}
        dialogClassName="modal-90w modal-lg"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Body>
          <reactbootstrap.Tabs activeKey={reciverVerifierTab} onSelect={(key) => this.handleReciverVerifierTab(key)}>
            <reactbootstrap.Tab eventKey={1} title={t("Responsible")}>
              <CommonPlannerDragAndDrop
                types={this.state.types}
                tasks={filter_recivers}
                details={this.state}
                tab={window.tabs.responsible}
                type={window.tabs.responsible}
                selected={Object.values(this.state[window.tabs.responsible])}
                {...this}
                updateSelectedRights={this.updateSelectedRights}
                updateSelectedChild={this.updateSelected}
                credentials={this.state.credentials}
                onSelect={this.handleActiveTab}
              />
            </reactbootstrap.Tab>
            <reactbootstrap.Tab eventKey={2} title={t("Verifier")}>
              <CommonPlannerDragAndDrop
                types={this.state.types}
                tasks={filter_recivers}
                details={this.state}
                tab={window.tabs.verifier}
                type={window.tabs.verifier}
                selected={Object.values(this.state[window.tabs.verifier])}
                {...this}
                updateSelectedRights={this.updateSelectedRights}
                updateSelectedChild={this.updateSelected}
                credentials={this.state.credentials}
                onSelect={this.handleActiveTab}
              />
            </reactbootstrap.Tab>
          </reactbootstrap.Tabs>
        </reactbootstrap.Modal.Body>
      </reactbootstrap.Modal>
    )
  }
  fileReceiverPopUp = () => {
    const { showCloseFileReceiver, t } = this.state;
    var filter_recivers = this.state.tasks;
    if (this.state[window.tabs.planningReceiver].length > 0) {
      filter_recivers = this.filterArray(this.state.tasks, this.state[window.tabs.planningReceiver]);
    }
    return (
      <reactbootstrap.Modal
        show={showCloseFileReceiver}
        onHide={this.showCloseFileReceiver}
        dialogClassName="modal-90w modal-lg"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
          <reactbootstrap.Modal.Title>{t('Receivers')}</reactbootstrap.Modal.Title>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Body>
          <CommonPlannerDragAndDrop
            types={this.state.types}
            tasks={filter_recivers}
            details={this.state}
            tab={window.tabs.planningReceiver}
            type={window.tabs.planningReceiver}
            selected={Object.values(this.state[window.tabs.planningReceiver])}
            {...this}
            updateSelectedRights={this.updateSelectedRights}
            updateSelectedChild={this.updateSelected}
            credentials={this.state.credentials}
            onSelect={this.handleActiveTab}
          />
        </reactbootstrap.Modal.Body>
      </reactbootstrap.Modal>
    )
  }
  handleActiveTab = (key) => {
    this.setState({
      dragNDropActiveTab: key,
    });
  }
  updateSelectedRights = (latestList, tab) => {
    this.setState({
      [tab]: latestList,
    })
  }
  openCloseUploadPopup = () => {
    const { uploadPopUp } = this.state;
    if(this.state.title.trim() != '') {
    this.setState({
      uploadPopUp: !uploadPopUp
    })
  }else{
    OCAlert.alertWarning(('Title is mandatory'), { timeOut: window.TIMEOUTNOTIFICATION });
    return;
  }
  }
  saveImportPlanning = (data, fileData) => {
    const { selectedActor, selectedOrgUnit, selectedsearchInDb } = this.state;
    this.setState({
      tableName: data.table_name,
      csv_file_name: data.csv_file_name,
      allColumns: this.costructColumns(data.columns),
      allActorsFromImportPlanning: data.allImportActors,
      filename: fileData.file,
      filePath: fileData.filePath,
      fileId: fileData.fileId,
      selectedsearchInDb: selectedActor.value && selectedActor.value !== window.SEARCH_IN_DB ? [] : selectedsearchInDb,
      selectedOrgUnit: selectedActor.value && selectedActor.value !== window.SEARCH_IN_DB ? selectedOrgUnit : [],
    });
    this.openCloseUploadPopup();
  }
  costructColumns = (data) => {
    return data.map(value => {
      return ({ 'name': value })
    })
  }
  uploadPopUp = () => {
    const { uploadPopUp, filename, filePath, fileId, t } = this.state
    return (
      <reactbootstrap.Modal
        show={uploadPopUp}
        onHide={this.openCloseUploadPopup}
        dialogClassName="modal-90w modal-md"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Body>
          <ImportPlanning
            filename={filename}
            filePath={filePath}
            fileId={fileId}
            action={this.props.action === 'edit' ? 1 : 0}
            tableName={this.state.excelTabName.length < 1 ? '' : this.state.excelTabName}
            saveImportPlanning={this.saveImportPlanning}
            openCloseUploadPopup={this.openCloseUploadPopup}
            task_id={this.props.plannerId}
            task_name = {this.state.title}
          />
        </reactbootstrap.Modal.Body>
      </reactbootstrap.Modal>
    )
  }
  handleRadioSelect = (type) => {
    this.setState({
      run_task_type_id: parseInt(type),
    })
  }
  handleChangeDb = (value, name) => {
    const { pjgd, allActorsFromImportPlanning, selectedOrgUnit } = this.state;
    let filterdArray = [];
    let currentSelectedIds = [];

    value.map(result => {
      currentSelectedIds.push(result.value);
      filterdArray.push(pjgd.filter(item => { return (item.entity_type_id === result.value && allActorsFromImportPlanning.includes(item.name)) }))
    });
    this.setState({
      orgUnitOptions: filterdArray.flat(),
      selectedOrgUnit: !currentSelectedIds.includes(selectedOrgUnit.entity_type_id) ? [] : selectedOrgUnit,
      [name]: value,
    })
  }
  openCloseQueryBuilder = () => {
    this.setState({
      showCloseQueryBuilderPopUp: !this.state.showCloseQueryBuilderPopUp,
    });
  }
  callBackUpdate = (query = undefined) => {
    if (query != undefined) {
      this.technicalQuery = query
    }
  }
  queryBuilderPopUp = () => {
    const { showCloseQueryBuilderPopUp, t } = this.state;
    return (
      <reactbootstrap.Modal
        show={showCloseQueryBuilderPopUp}
        onHide={this.openCloseQueryBuilder}
        dialogClassName="modal-90w modal-lg"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
          <reactbootstrap.Modal.Title>{t('Query builder')}</reactbootstrap.Modal.Title>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Body>
          <PlannerQueryComponent
            plannerDbQuery={this.technicalQuery}
            callBackUpdate={this.callBackUpdate}
          />
        </reactbootstrap.Modal.Body>
      </reactbootstrap.Modal>
    )
  }
  render() {
    const { indexActiveTab, selectedPlannerType, t, excelTabName } = this.state;
    const disableFields = (this.props.action === 'view') ? true: false;
    console.log(this.state);
    return (
      <reactbootstrap.Container>
        <reactbootstrap.Tabs activeKey={indexActiveTab} onSelect={(key) => this.indexTabChange(key)}>
          <reactbootstrap.Tab eventKey={1} title={t("Settings")}>
            <GeneralSettings
              state={this.state}
              textOnChnage={this.textOnChnage}
              handleChangePlannerType={this.handleChangePlannerType}
              handleSelect={this.handleSelect}
              handleNumber={this.handleNumber}
              handleChangeDuration={this.handleChangeDuration}
              handleChangeTypeSubType={this.handleChangeTypeSubType}
              action={this.props.action}
            />
          </reactbootstrap.Tab>
          <reactbootstrap.Tab eventKey={2} title={t("Webform settings")}>
            {this.responsibleVerifierPopUp()}
            <WebformSettings
              state={this.state}
              handleChangeWebform={this.handleChangeWebform}
              handleChangeActor={this.handleChangeActor}
              handleChangeDb={this.handleChangeDb}
              closeAddWebelements={this.closeAddWebelements}
              addWebElements={this.addWebElements}
              saveAddWebElements={this.saveAddWebElements}
              cancelAddWebelements={this.cancelAddWebelements}
              editAddedWebElement={this.editAddedWebElement}
              deleteAddedWebElement={this.deleteAddedWebElement}
              handleSelect={this.handleSelect}
              handleChangeDocument={this.handleChangeDocument}
              openCloseRecivier={this.openCloseRecivier}
              handleNumber={this.handleNumber}
              showCloseResponsibleVerifier={this.showCloseResponsibleVerifier}
              action={this.props.action}
            />
          </reactbootstrap.Tab>
          {selectedPlannerType.value && selectedPlannerType.value === 2 && <reactbootstrap.Tab eventKey={3} title={t("Single task")}>
            <SingleTaskSetting
              state={this.state}
              handleChangeDate={this.handleChangeDate}
              onTimeChange={this.onTimeChange}
              action={this.props.action}
             />
          </reactbootstrap.Tab>}
          {selectedPlannerType.value && selectedPlannerType.value === 1 && <reactbootstrap.Tab eventKey={4} title={t("Recurrent task")}>
            <RecurrentTaskSetting
              state={this.state}
              handleChangeDate={this.handleChangeDate}
              onTimeChange={this.onTimeChange}
              handleSelect={this.handleSelect}
              handleNumber={this.handleNumber}
              habdleChangeRecurrency={this.habdleChangeRecurrency}
              handleChangeDuration={this.handleChangeDuration}
              handleRadioSelect={this.handleRadioSelect}
              action={this.props.action}
             />
          </reactbootstrap.Tab>}
          {selectedPlannerType.value && selectedPlannerType.value === 3 && <reactbootstrap.Tab eventKey={5} title={t("Import options")}>
            {this.uploadPopUp()}
            {this.fileReceiverPopUp()}
            <ImportOptionSettingsFile
              state={this.state}
              handleChangeDate={this.handleChangeDate}
              onTimeChange={this.onTimeChange}
              textOnChnage={this.textOnChnage}
              handleChangeInterval={this.handleChangeInterval}
              handleSelect={this.handleSelect}
              handleFile={this.handleFile}
              handleRadioSelect={this.handleRadioSelect}
              openCloseUploadPopup={this.openCloseUploadPopup}
              showCloseFileReceiver={this.showCloseFileReceiver}
              action={this.props.action}
            />
          </reactbootstrap.Tab>}
          {selectedPlannerType.value && selectedPlannerType.value === 4 && <reactbootstrap.Tab eventKey={6} title={t("Import options")}>
            {this.queryBuilderPopUp()}
            {this.fileReceiverPopUp()}
            <ImportOptionSettingsDb
              state={this.state}
              handleChangeDate={this.handleChangeDate}
              onTimeChange={this.onTimeChange}
              textOnChnage={this.textOnChnage}
              handleNumber={this.handleNumber}
              handleChangeDuration={this.handleChangeDuration}
              handleChangeInterval={this.handleChangeInterval}
              handleSelect={this.handleSelect}
              handleRadioSelect={this.handleRadioSelect}
              openCloseQueryBuilder={this.openCloseQueryBuilder}
              showCloseFileReceiver={this.showCloseFileReceiver}
            action={this.props.action} />
          </reactbootstrap.Tab>}
        </reactbootstrap.Tabs>
        <reactbootstrap.Row className='mt-3' style={{ float: 'right' }}>
           <a style={{ paddingTop: '15px' }}  onClick={e => this.props.cancel()}>{t('Cancel')}</a>&nbsp;&nbsp;&nbsp;
                <reactbootstrap.Button className='m-2' disabled = {disableFields}onClick={e => this.saveTaskPlan()}>{t('Save')}</reactbootstrap.Button>
        </reactbootstrap.Row>
      </reactbootstrap.Container>
    );
  }
}
export default translate(PlanningIndex);
