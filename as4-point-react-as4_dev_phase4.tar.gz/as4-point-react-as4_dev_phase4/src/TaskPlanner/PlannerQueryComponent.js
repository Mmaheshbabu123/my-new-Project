import React, { Component } from 'react';
import { translate } from '../language';
import  QueryBuilder from '../Webforms/QueryBuilder/QueryBuilder';
class PlannerQueryComponent extends Component{
  technicalQuery ='';
  constructor(props){
    super(props)
    this.IntialState()

  }
  IntialState = ()=>{
    this.state  ={
      set_query: '',
    }
  }
  componentDidMount(){
    this.setState({
      set_query:this.props.plannerDbQuery,
    })
  }
  UNSAFE_componentWillReceiveProps(prevProps){
    this.setState({
      set_query:this.props.plannerDbQuery,
    })
  }
  render(){
    return(
      <>
      <QueryBuilder
      callBackforQuery = {this.callBackforQuery}
      setQuery = {this.state.set_query}
      />
      </>
    )
  }

  callBackforQuery =(query = undefined)=>{
    if(query !== undefined){
      this.technicalQuery =query;
      this.props.callBackUpdate(query);
    }
    return this.technicalQuery;
  }
}
export default translate(PlannerQueryComponent);
