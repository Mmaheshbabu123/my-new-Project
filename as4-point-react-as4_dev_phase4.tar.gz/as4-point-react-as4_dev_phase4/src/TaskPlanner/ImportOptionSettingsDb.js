import React from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import moment from 'moment';
import TimeField from 'react-simple-timefield';
import MultiSelect from '../_components/MultiSelect';
import CheckBox from '../CheckBox';
function ImportOptionSettingsDb(props){
  const {startDate,endDate,nextStartTime,nextStartDate,startTime,inrevalNumber,intervalOptions,importReport,selectedInterval,onlySendOnError,
         sunday,monday,tuesday,wednesday,thursday,friday,saturday,runTaskDays,run_task_type_id} =props.state;
  const t = props.t;
  const formDisabled = (props.action === 'view') ? true : '';
  return(
    <reactbootstrap.Container>
      <reactbootstrap.Form >
        <fieldset disabled={formDisabled}>
    <reactbootstrap.Row>
        <reactbootstrap.Button className='m-2' onClick={(e) => props.openCloseQueryBuilder()}>{t('Query builder')}</reactbootstrap.Button>
    </reactbootstrap.Row>
    <reactbootstrap.Row className="mt-1">
    <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Start date:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
    <reactbootstrap.FormControl
           name="startDate"
           type="date"
           value={startDate}
           onChange={e=>props.handleChangeDate(e.target.value,'startDate')}
           min={moment().format("YYYY-MM-DD")}
           className="col-md-9 input_sw"
       />
    </reactbootstrap.Row>
    <reactbootstrap.Row className="mt-2">
    <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('End date:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
    <reactbootstrap.FormControl
           name="endDate"
           type="date"
           value={endDate}
           onChange={e=>props.handleChangeDate(e.target.value,'endDate')}
           min={startDate}
           className="col-md-9 input_sw"
       />
    </reactbootstrap.Row>
    <reactbootstrap.Row className="mt-2">
    <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Start time:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
    <TimeField
        name='startTime'
        value={startTime}
        style={{
            border: '1px solid lightgray',
            fontSize: 17,
            width: 120,
            padding: '5px 8px',
            color: '#333',
            borderRadius: 3,
            height: 37,
            textAlign: 'center',
            backgroundColor: '#fff'
        }}
          className="col-md-3 input_sw"
        onChange={e=>props.onTimeChange(e.target.value,'startTime')}/>
    </reactbootstrap.Row>
    <reactbootstrap.Row className="mt-2">
    <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Interval:')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
    <reactbootstrap.Col className='col-md-9 px-0 d-flex'>
    <reactbootstrap.FormControl
      className="col-md-6 input_sw"
      type='text'
      onChange={(e) => props.handleNumber(e.target.value,'inrevalNumber')}
      value={inrevalNumber}/>
      <reactbootstrap.Col className='col-md-6 px-0'>
    <MultiSelect
      disabled={formDisabled}
      options={intervalOptions}
      standards={selectedInterval}
      handleChange={e=>props.handleChangeDuration(e,'selectedInterval')}
      isMulti={false} />
      </reactbootstrap.Col>
    </reactbootstrap.Col>
    </reactbootstrap.Row>
    <reactbootstrap.Row className="mt-2  d-flex">
    <reactbootstrap.FormLabel className='col-md-3' style={{color: '#EC661C'}}>{t('Next start date:')}</reactbootstrap.FormLabel>
    <reactbootstrap.Col className='col-md-9 px-0 d-flex'>
    <reactbootstrap.FormControl
           name="nextStartDate"
           type="date"
           value={nextStartDate}
           onChange={e=>props.handleChangeDate(e.target.value,'nextStartDate')}
           min={moment().format("YYYY-MM-DD")}
           className="col-md-8 input_sw"
           disabled={true}
       />
       <TimeField
           name='startTime'
           value={nextStartTime}
           style={{
               border: '1px solid lightgray',
               fontSize: 17,
               width: 120,
               padding: '5px 8px',
               color: '#333',
               borderRadius: 3,
               height: 37,
               textAlign: 'center',
               backgroundColor: '#fff'
           }}
             className="col-md-4 input_sw"
           onChange={e=>props.onTimeChange(e.target.value,'nextStartTime')}
           disabled={true}/>
           </reactbootstrap.Col>
    </reactbootstrap.Row>
    <reactbootstrap.Row>
    <reactbootstrap.Col className='col-md-1'>
    <CheckBox
        tick={runTaskDays}
        onCheck={(e) => props.handleSelect(e.target.checked,'runTaskDays')}/>
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='col-md-9 pt-1'>{t('Read out database only on the following days')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>
    {runTaskDays && <div className='pl-3'>
    <reactbootstrap.Row>
    <reactbootstrap.Col className='col-md-1'>
    <CheckBox
        tick={sunday}
        onCheck={(e) => props.handleSelect(e.target.checked,'sunday')}/>
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='col-md-9 pt-1'>{t('Sunday')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>
    <reactbootstrap.Row>
    <reactbootstrap.Col className='col-md-1'>
    <CheckBox
        tick={monday}
        onCheck={(e) => props.handleSelect(e.target.checked,'monday')}/>
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='col-md-9 pt-1'>{t('Monday')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>
    <reactbootstrap.Row>
    <reactbootstrap.Col className='col-md-1'>
    <CheckBox
        tick={tuesday}
        onCheck={(e) => props.handleSelect(e.target.checked,'tuesday')}/>
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='col-md-9 pt-1'>{t('Tuesday')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>
    <reactbootstrap.Row>
    <reactbootstrap.Col className='col-md-1'>
    <CheckBox
        tick={wednesday}
        onCheck={(e) => props.handleSelect(e.target.checked,'wednesday')}/>
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='col-md-9 pt-1'>{t('Wednesday')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>
    <reactbootstrap.Row>
    <reactbootstrap.Col className='col-md-1'>
    <CheckBox
        tick={thursday}
        onCheck={(e) => props.handleSelect(e.target.checked,'thursday')}/>
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='col-md-9 pt-1'>{t('Thursday')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>
    <reactbootstrap.Row>
    <reactbootstrap.Col className='col-md-1'>
    <CheckBox
        tick={friday}
        onCheck={(e) => props.handleSelect(e.target.checked,'friday')}/>
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='col-md-9 pt-1'>{t('Friday')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>
    <reactbootstrap.Row>
    <reactbootstrap.Col className='col-md-1'>
    <CheckBox
        tick={saturday}
        onCheck={(e) => props.handleSelect(e.target.checked,'saturday')}/>
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='col-md-9 pt-1'>{t('Saturday')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>
    </div>}
    {!runTaskDays &&
      <div className='pl-3'><reactbootstrap.Row className='mt-1 pl-4'>
    <input type='radio'   name='radio'   checked = {run_task_type_id === 1} onChange = {(e)=>props.handleRadioSelect(1)} />{t('New start date calculated on last stop date')}
    </reactbootstrap.Row>
    <reactbootstrap.Row className='md-1 pl-4'>
    <input type='radio'   name='radio'   checked = {run_task_type_id === 2} onChange = {(e)=>props.handleRadioSelect(2)} />{t('New start date calculated on last starting date')}
    </reactbootstrap.Row>
     </div>}
    <reactbootstrap.Row>
    <reactbootstrap.Col className='col-md-1'>
    <CheckBox
        tick={importReport}
        onCheck={(e) => props.handleSelect(e.target.checked,'importReport')}/>
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='col-md-9 pt-1'>{t('Import report')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>
    {importReport &&<reactbootstrap.Row className='pl-4'>
    <reactbootstrap.Col className='col-md-1'>
    <CheckBox
        tick={onlySendOnError}
        onCheck={(e) => props.handleSelect(e.target.checked,'onlySendOnError')}/>
    </reactbootstrap.Col>
    <reactbootstrap.FormLabel className='col-md-9 pt-1'>{t('Only send in case of errors')}</reactbootstrap.FormLabel>
    </reactbootstrap.Row>}
    {importReport &&<reactbootstrap.Row className='pl-5'>
        <reactbootstrap.Button className='m-2' onClick={(e)=>props.showCloseFileReceiver()}>{t('Receivers')}</reactbootstrap.Button>
    {props.state[window.tabs.planningReceiver].length<1 &&<reactbootstrap.Button  variant="outline-warning" className='mr-2 mb-2 mt-2 d-none' onClick={(e)=>props.showCloseFileReceiver()}>{t('Receivers')}</reactbootstrap.Button>}
    {props.state[window.tabs.planningReceiver].length>0 &&<reactbootstrap.Button  variant="outline-success" className='mr-2 mb-2 mt-2 d-none' onClick={(e)=>props.showCloseFileReceiver()}>{t('Receivers')}</reactbootstrap.Button>}
    </reactbootstrap.Row>}
  </fieldset>
</reactbootstrap.Form >


    </reactbootstrap.Container>
  );
}
export default translate(ImportOptionSettingsDb);
