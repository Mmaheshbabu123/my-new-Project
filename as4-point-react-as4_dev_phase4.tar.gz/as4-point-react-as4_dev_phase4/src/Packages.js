import { Tabs, Tab } from 'react-bootstrap';
import React, { Component } from 'react';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import CheckBoxList from './CheckBoxList';
import './Package.css';
import Can from './_components/CanComponent/Can';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import { PagePermissions } from './_components/CanComponent/PagePermissions';
import { datasave } from './_services/db_services';
import { translate } from './language';

class Packages extends Component {
  constructor(props) {
    super(props)
    this.state = {
      save: props.t('Save'),
      savevalue: 'true',
      id: '',
      name_error: '',
      name: '',
      nametest: '',
      description: '',
      package_details: [],
      functions: [],
      allFunctions: [],
      checkedItems: new Map(),
      checklist: [],
      checkedItems_values: [],
      checkedItems_keys: [],
      active_tab: "Dashboard",
      ItemsChecked: [false, false, false],
      package_functions: [],
      t: props.t,
    }
    this.handleSelect = this.handleSelect.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
  }
  handleSelect(key) {
    this.setState({
      active_tab: key,
    })
  }

  async componentDidMount() {
    const package_id = this.props.match.params.id;
    if (this.props.handleSelect !== undefined) {
      this.props.handleSelect('/appsettings/createpackage');
    }
    if (this.props.match.params.id) {
      var url = window.packages + '/' + package_id;
      datasave.service(url, "GET")
        .then(response => {
          this.setState({
            name: response[0]['name'],
            package_details: response,
            description: response['description'],
          })
        })
      var functions = window.FUNCTIONS_PACKAGES + '/' + package_id;
      datasave.service(functions, "GET")
        .then(response => {
          this.setState({
            functions: [],
            allFunctions: [],
          });
          var responsibilites = response;
          this.setState({
            functions: response['function'],
            allFunctions: response['allfunctions'],
          })
        })
    }
    else {
      var url = window.FUNCTIONS_CLASSIFICATION;
      datasave.service(url, "GET")
        .then(response => {
          this.setState({
            functions: response['function'],
            allFunctions: response['allfunctions'],
          })
        })
    }
  }
  handleSubmit(event) {
    event.preventDefault()
    const { history } = this.props
    const details = {
      name: this.state.name,
      description: this.state.description,
      checkedItems: this.state.allFunctions,
    }
    if (this.props.match.params.id) {
      const packageId = this.props.match.params.id;
      var url = window.packages + '/' + packageId;
      datasave.service(url, 'PUT', details)
        .then(response => {
          if (response.name) {
            this.setState({
              name_error: response.name,
            })
          }
          else {
            history.push('/appsettings/managepackage');
            if (this.props.handleSelect !== undefined)
              this.props.handleSelect('/appsettings/managepackage');
          }
        })
        .catch(error => {
          this.setState({
            error: error.response.errors
          })
        })
    }
    else {

      var url = window.packages
      datasave.service(url, 'POST', details)
        .then(response => {
          if (response.name) {
            this.setState({
              name_error: response.name
            })
          }
          else {
            history.push('/appsettings/managepackage')
            if (this.props.handleSelect !== undefined)
              this.props.handleSelect('/appsettings/managepackage');
          }
        })
        .catch(error => {
          this.setState({
            error: error.response.errors
          })
        })
    }
  }
  handleCancel(event) {
    const { history } = this.props
    // if (this.props.match.params.id) {
    history.push('/appsettings/managepackage')
    if (this.props.handleSelect !== undefined)
      this.props.handleSelect('/appsettings/managepackage');
    // } else {
    //   history.push('/appsettings/managepackage')
    //   this.props.handleSelect('/appsettings/managepackage');
    // }
  }
  onCheckBoxChange(checkName, isChecked, classification) {
    let isAllChecked = (checkName === 'all' && isChecked);
    let isAllUnChecked = (checkName === 'all' && !isChecked);
    var pack_func = this.state.allFunctions;
    const functions = Object.values(this.state.functions).map((city, index) => {
      const ObjectList = Object.values(city['values']).map((value, key) => {
        if ((isAllChecked || value.function_id === checkName) && classification === city.title) {
          city.selectall = isAllChecked;
          value.checked = isChecked;
          pack_func.filter(function (i, key) {
            if (i.function_id == value.function_id) {
              pack_func[key].checked = (isChecked) ? true : false;
            }
          });
          return Object.assign({}, value, {
            value,
          });
        } else if (isAllUnChecked && classification === city.title) {
          city.selectall = false;
          value.checked = false;
          pack_func.filter(function (i, key) {
            if (i.function_id == value.function_id) {
              pack_func[key].checked = (isChecked) ? true : false;
            }
          });
          return Object.assign({}, value, {
            value,
          });
        }
        return value;
      });
      Object.assign({}, city);
      return city;
    });
    this.setState({
      functions,
      allFunctions: pack_func,
    });
  }
  render() {
    const as4_or_site = PagePermissions()
    const { name_error } = this.state;
    const { t } = this.state;
    var userres = Object.keys(this.state.functions).map(
      function (key) {
        return (

          <Tab eventKey={this.state.functions[key]['title']} title={this.state.functions[key]['title']}>
            <Form.Group>
              <div className=" ">
                <CheckBoxList
                  options={this.state.functions[key]['values']}
                  isCheckedAll={this.state.functions[key]['selectall']}
                  onCheck={this.onCheckBoxChange.bind(this)}
                  category={this.state.functions[key]['title']}
                />
              </div>
            </Form.Group>
          </Tab>
        )
      }, this
    );

    if (as4_or_site) {
      return (
        <div className=" row col-md-12">
          <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
          <div style={{  }} className='col-md-11' >
            <Can
              perform="E_package"
              yes={() => (
                <div className='row' >
                  {/* <div style={{visibility: 'hidden'}} className="col-md-1">
                <p>welcome</p>
              </div> */}
                  <div className='col-md-12 mt-5 mb-5' >
                    <div style={{ border: '1px solid lightgray' }} className='organisation_list mb-5'>
                      <div className='header'>
                        <div className='card-header' > {t('Create package')} </div>
                        <div className='card-body' >
                          <Container className=" pt-0">
                            <Form onSubmit={this.handleSubmit}>
                              <FormGroup>
                                <div className=" row input-overall-sec ">
                                  <InputGroup className="">
                                    <div className="col-md-4">
                                      <InputGroup.Prepend>
                                        <InputGroup style={{ paddingTop: '8px', color: '#EC661C' }} id="basic-addon1">{t('Package name')}:<span style={{ color: "red" }}>*</span></InputGroup>
                                      </InputGroup.Prepend>
                                    </div>
                                    <div class="col-md-7 input-padd">
                                      <FormControl
                                        placeholder={t("Package name")}
                                        aria-label="Packagename"
                                        aria-describedby="basic-addon1"
                                        value={this.state.name}
                                        onChange={e => this.setState({ name: e.target.value })}
                                        className="input_sw"
                                      />
                                      <div style={{ color: 'red' }} className="error-block mt-2">{name_error}</div>
                                    </div>
                                  </InputGroup>

                                </div>
                              </FormGroup>
                              <div className=" row input-overall-sec ">
                                <div className="col-md-4">
                                  <InputGroup.Prepend>
                                    <InputGroup style={{ paddingTop: '8px', color: '#EC661C', marginBottom: '1rem' }} id="basic-addon1">{t('Roles and responsibilities')}:</InputGroup>
                                  </InputGroup.Prepend>
                                </div>
                              </div>
                              <Tabs className="test-tab packages-tab-list" activeKey={this.state.active_tab} onSelect={this.handleSelect} id="controlled-tab-example">
                                {userres}

                              </Tabs>
                              <FormGroup>
                                <div style={{ float: 'right' }} className="">
                                  <a  onClick={this.handleCancel} >{t('Cancel')}</a>
                                  &nbsp;&nbsp;&nbsp;
                            <Button style={{fontSize: '14px'}} type="submit" disabled={!this.state.savevalue} color="primary">{t('Save')}</Button>


                                </div>
                              </FormGroup>
                            </Form>
                          </Container>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              no={() =>
                <AccessDeniedPage />
              }
            />
          </div>
        </div>
      );
    }
    else {
      return (
        <AccessDeniedPage />
      );
    }
  }
}
export default translate(Packages)
