import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { userService } from './_services/user.services';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from './language';
import './LoginScreen.css';
import logo_as4 from './images/normecfoodcarelogo.png';
import {datasave} from'../src/_services/db_services';
// import login_banner from './images/LPBG.jpg';
import new_login_screen from './images/loginbg.png';
import SetUserData from './Actions/SetUserData';
import { connect } from "react-redux";
import queryString from 'query-string';
import { Form } from 'react-bootstrap';
import { BrowserRouter, Switch, Route, Redirect } from 'react-router-dom';

const base64 = require('base-64');

class LoginScreen extends Component {

    constructor(props) {
        super(props)
        userService.logout();
        let querystring = queryString.parse(this.props.location.search);
        this.siteDetials = window ?.siteDetials ?? {};
        this.state = {
            t: props.t,
            email: '',
            password: '',
            showerror: false,
            // submitted: false,
            // loading: false,
            error: '',
            maintext: this.siteDetials['main_text'],
            subtext: this.siteDetials['sub_text'],
            loadEmbeding: (querystring.u !== undefined && querystring.sha !== undefined) ? false : true,
            carenetDetails : [],
            termsnconditions : 0,

        }
        this.divRef = React.createRef();
        this.hasErrorFor = this.hasErrorFor.bind(this)
        this.renderErrorFor = this.renderErrorFor.bind(this)
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

    }

    handleChange(e) {
        const { name, value } = e.target;
        this.setState({
            [name]: value,
            email_error: '',
            password_error: '',
            error: '',
         });
    }

    handleSubmit() {
      // this.setState({ submitted: true });
      const { email, password, termsnconditions, carenetDetails } = this.state;
      // this.setState({ loading: true });

      userService.login(email, password, termsnconditions, carenetDetails)
      .then(user => {
          if (user.email || user.password) {
              this.setState({
                  email_error: user.email,
                  password_error: user.password
              });
          }
          else {
              const { history }= this.props;
              this.props.SetUserData(user.user_data);
              window.location.href = '/';
          }
        },
              // error => this.setState({ error, loading: false })
      )
      .catch(error => {
        this.setState({
          error: error,
          // loading: false
         })
      })
    }

    handleKeyPress = event => {
      if (event.key == 'Enter') {
        this.handleSubmit(event);
      }
    }

    hasErrorFor(field) {
        return !!this.state.errors[field]
    }
    renderErrorFor(field) {
        if (this.hasErrorFor(field)) {
            return (
                <span className='invalid-feedback'>
                    <strong>{this.state.errors[field][0]}</strong>
                </span>
            )
        }
    }


    componentDidMount() {
        let querystring = queryString.parse(this.props.location.search);
        let loadEmbeding = true;
        if (querystring.u !== undefined && querystring.sha !== undefined) {
          loadEmbeding = false;
          let details = {
            userEmail : base64.decode(querystring.u),
            sha : querystring.sha,
            backUrl : querystring.back_url,
          }
          this.setState({
            carenetDetails : details,
            email : details.userEmail,
          })
        }
        let ref = this.divRef && this.divRef.current ? this.divRef.current : 0;
        let rightSideColMd =  'col-md-5';
        if(ref)
           rightSideColMd = ref.offsetWidth === 0 && ref.offsetHeight === 0 ? 'col-md-12' : rightSideColMd;
        this.setState({rightSideColMd: rightSideColMd})
    }

    render() {
        let ref = this.divRef && this.divRef.current ? this.divRef.current : 0;
        let rightSideColMd =  'col-md-5';
        rightSideColMd = this.state.rightSideColMd ? this.state.rightSideColMd : rightSideColMd;
        const { color, login_logo, logo_width, logo_height} = this.siteDetials;
        const { email, password, error, password_error, email_error, maintext, subtext,t, loadEmbeding, termsnconditions} = this.state;
        if (loadEmbeding === false) {
          return (
            <div>
               {error === '' &&
                  <>
                    {this.handleSubmit()}
                  </>
               }
               {error !== '' &&
                 <div className="col-md-12 row">
                 <div style={{visibility: 'hidden'}} className="col-md-1"><p>welcome</p></div>
                   <div style={{marginLeft: '-0.5rem'}} className='col-md-11' >
                     <div className='row justify-content-center' >
                       <div className='col-md-9 mt-5 mb-5' >
                         <div className='card' >
                         <div className='card-header' > {t('Login status')}</div>
                           <div className='card-body' >
                             {(error === 'Email does not exist' || error === 'Invalid_credentials') &&
                                <div className='col-md-9 mt-5 mb-5' style={{ color: 'red' ,textAlign: "center" }}>{t('You are not registered in AS4 Point. Please register in AS4 Point and try to login')}</div>
                             }
                             {error === 'could_not_create_token' &&
                               <div className='col-md-9 mt-5 mb-5' style={{ color: 'red' ,textAlign: "center" }}>{t('We are unable to login you.Please try again')}</div>
                             }
                             {error === 'Not activated your AS4 account' &&
                               <div className='col-md-9 mt-5 mb-5' style={{ color: 'red' ,textAlign: "center" }}>{t('You are not activated your account in AS4 Point.Please activate your account')}</div>
                             }
                             {error === 'Accept terms and conditions' &&
                               <div className='col-md-9 mt-5 mb-5' style={{ color: 'red' ,textAlign: "center" }}>{t('You did not accepted terms and conditions yet')}</div>
                             }
                           </div>
                         </div>
                       </div>
                     </div>
                   </div>
                 </div>
               }
            </div>
          );
        }
        else {
          return (
            <div className="container-fluid fulll-body" style={{ overflow: "auto" }} onKeyPress={e => this.handleKeyPress(e)}>
                <div className="row login-container ">
                    <div className="col-md-7 col-lg-7  tab-sec">
                        <div className="row">
                            <div className="col-md-2 col-lg-2 col-sm-2 bg-blue" style={{backgroundColor: color}}></div>
                            <div className="col-md-10 col-sm-10  d-lg-block col-lg-10 justify-content-center left-section"  ref = {this.divRef}>
                            <div className="left-body-content">
                                    <h1 style={{wordBreak: 'break-word'}}> {maintext} </h1>
                                    <p style={{wordBreak: 'break-word'}}> {subtext} </p>
                                </div>
                                <div className="login-image-section">
                                <svg width="100%" height="100%" viewBox="0 0 400.000000 300.000000" preserveAspectRatio="none">
                                     <g transform="translate(0.000000,300.000000) scale(0.019881,-0.012310)"
                                     fill={color} stroke="none">
                                       <path d="M0 12185 l0 -12185 6383 0 6384 0 189 108 c1675 959 3101 2219 4255  3757 1596 2127 2543 4661 2733 7320 52 721 45 1569 -19 2270 -230 2510 -1109 4856 -2583 6895 -284 393 -613 797 -966 1190 -168 187 -769 788 -956 956 -791 712 -1633 1320 -2516 1817 l-100 57 -6402 0 -6402 0 0 -12185z" />
                                     </g>
                                  </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className={"col-lg-5 col-xs-12  col-sm-12 justify-content-center right-section " + rightSideColMd}>
                        <div className="header-content  container">
                        <Link to='/needhelp'>
                            <p style={{color:color}}>{t('Need help?')}</p>
                        </Link>
                        </div>
                        <div className="left-body-container">
                            <div className="img-responsive login-logo">
                                <img src={login_logo} width={logo_width + 'px'} height={logo_height + 'px'} className="d-inline-block" ></img>
                            </div>
                            <reactbootstrap.Form action="/" method="post" className="user-details">
                                <div className="form-group email-sec ">
                                    <div className="login-email-head">
                                        {/* <span class="login-email-icon-sec"> <img src={icon_email} class="d-inline-block input-icon-sec "  ></img> </span> */}
                                        <span className="login-email-input-sec">
                                        {/* <span  className="icon_gmail">gmail</span> */}
                                        <span  className="icon_gmail"></span>
                                            <input
                                            name="email"
                                            value={email}
                                            type="email"
                                            className="form-control email-input"
                                            id="exampleInputEmail1"
                                            placeholder={t("Email")}
                                            onChange={this.handleChange}
                                            autoComplete="off" />
                                         </span>
                                    </div>
                                    <div style={{ color: 'red' }}>{email_error}</div>
                                </div>
                                <div className="form-group password-sec">
                                    <div className="login-email-head">
                                        {/* <span class="login-password-icon-sec"> <img src={icon_password} class="d-inline-block  input-icon-sec"  ></img></span> */}
                                        <span className="login-password-input-sec">
                                        {/* <span className="icon_password">password</span> */}
                                        <span className="icon_password"></span>
                                            <input
                                            name="password"
                                            value={password}
                                            type="password"
                                            className="form-control password-input"
                                            id="exampleInputPassword1"
                                            placeholder={t("Password")}
                                            onChange={this.handleChange}
                                            autoComplete="off" />
                                        </span>
                                    </div>
                                    <div style={{ color: 'red' }}>{password_error}</div>
                                </div>
                                <div className="content-forgot">
                                    <p>
                                        <Link to='/forgotpassword' style={{color:color}}>
                                            {t('Forgot your password')}
                                        </Link>
                                    </p>
                                </div>
                                {/* <div>
                                  <Form.Check
                                      onChange={e => this.setState({ termsnconditions: !termsnconditions })}
                                      name='termsnconditions'
                                      style={{ color: '#656866' }}
                                      checked={termsnconditions}
                                      label={t("Accept terms and conditions")}
                                  />
                                </div>
                                */}
                                {error &&
                                    <div style={{ color: 'red' ,textAlign: "center" }}>{error}</div>
                                }
                            </reactbootstrap.Form>
                            <div className=" btn-login ">

                              <reactbootstrap.Button type="submit" id = 'login-screen-login-btn' onClick={e => this.handleSubmit(e)}
                                onMouseEnter = {() => this.changeColorOnHover(1)}
                                onMouseLeave = {() => this.changeColorOnHover(0)}
                                className="log-in-btn">
                                    {t('Log in')}
                                </reactbootstrap.Button>

                            </div>
                        </div>
                    </div>
                </div>
              </div>
              );
            }
          }

          changeColorOnHover = (hover) => {
            const { color } = this.siteDetials;
            let loginBtn = document.getElementById('login-screen-login-btn');
            hover === 1 ?
              loginBtn.setAttribute('style', `background: ${color ? color : '#EC661C'} !important; border-color: ${color ? color : '#EC661C'} !important;`)
            : loginBtn.setAttribute('style', `background: ${'#656866'}; border-color: ${'#656866'};`);
          }
      }
      const mapStateToProps = state => ({  ...state});
      const mapDispatchToProps = dispatch => ({
          SetUserData: (payload) => dispatch(SetUserData(payload)),
        });
      export default translate(connect(mapStateToProps, mapDispatchToProps)(LoginScreen));
