import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../src/_services/db_services';
import { connect } from "react-redux";
import { translate } from "../src/language";
import { store } from './store'
import { OCAlert } from '@opuscapita/react-alerts';
import BlockBoxTagBuild from '../src/BlockBox/BlockBoxTagBuild';
import '../src/BlockBoxPopUp.css';

class BlockBoxPopUp extends Component {
    constructor(props) {
      let storage = store.getState()
      let personLinkedOrg = storage.UserData.LinkedOrgUnits;
      let loggedPerson = storage.UserData.user_details.person_id;
      let loggedPersonName = storage.UserData.user_details.user_name;
        super(props)
        this.state = {
            save: props.t('Save'),
            switch_case: true,
            credentials: this.props.credentials,
            use_existing_file_name: props.t('Choose file'),
            savevalue: 'true',
            loading: false,
            error: '',
            description: '',
            batch_code:'',
            status: 1,
            submitted: false,
            showpopup: true,
            sucess: '',
            loggedPerson:loggedPerson,
            loggedPersonName:loggedPersonName,
            t: props.t,
                errors: {},
            blocked_element_data :[],
            OrgUnits:[],
            showRelease:false,
            release_actor_name:'',


        }
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleRelease = this.handleRelease.bind(this);
        this.cancelPopup = this.cancelPopup.bind(this);
        this.showPopup = this.showPopup.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.Goback = this.Goback.bind(this);
        this.showRelease = this.showRelease.bind(this);
        //alert('no');

    }
    showRelease() {
this.setState({showRelease:!this.state.showRelease})
}

Goback() {
  this.props.history.push(localStorage.getItem('prevLocation'));
}
    handleSubmit(event) {
        const { history } = this.props;
        const {t} = this.state;
        event.preventDefault()
        this.setState({ submitted: true });
        this.setState({
            savevalue: '',
            save: t('Please wait')
        })



        let description = this.state.description.toString().replace(/\s+/g, ' ').trim();
        const details4 = {
            task_id: this.props.task_id,
            person_id: this.props.UserData.user_details.person_id,
            comment: description,
        }
      //this.handleService(window.COMMENT_STORE, "POST", details4);
        if (description) {

            OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
            // alert('Submited successfully');
            //this.props.history.push(localStorage.getItem('prevLocation'));


        } else {
            this.setState({
                error: t('Comment is required'),
            })

        }



    }
    handleChange(event) {
        const { name, value } = event.target;
        this.state.errors[name] = '';
        this.setState({
            [name]: value,
        })
      }
    componentDidMount() {
      let blocked_element_data = this.props.blocked_element_data;
      const { t } = this.state;
      datasave.service(window.GET_TEXTFIELD_LIST_ORG + '/' + 123, 'GET')
          .then(response => {
              if (response['status'] == 200) {
                let org_string = parseInt(this.props.release_actor_type) === window.PERSON_ENTITY ? 'person' : parseInt(this.props.release_actor_type) === 2 ? 'jobs' : parseInt(this.props.release_actor_type) === 3 ? 'departments' : 'groups';
                let org_options = response[org_string];
                let last_data =  Object.values(org_options).filter(item => item.id === this.props.release_actor_id);
                let acton_type_org = last_data.length>0?last_data[0].name:'';
                  this.setState({
                  release_actor_name:acton_type_org,
                  })
              } else {
                  OCAlert.alertError(t(response['Msg']), { timeOut: window.TIMEOUTNOTIFICATION });
              }
          })


    }
    // updateCycles(doc_id, doc_status, person_id) {
    //     const { history } = this.props;
    //     var url = window.GET_CYCLE + '/' + doc_id + '/' + doc_status + '/' + person_id;
    //     datasave.service(url, "POST")
    //         .then(result => {
    //             if (result) {

    //                 //  history.push('/workarea');

    //             }

    //         });
    // }
    handleCancel(event) {
        this.cancelPopup();

    }
    formValidate() {
          let errors = {};
          let formIsValid = true;
          let description = this.state.description.toString().replace(/\s+/g, ' ').trim();
          if (!description) {
            formIsValid = false;
            errors["description"] = "*comment is required";
          }
          if (!this.state.batch_code) {
           formIsValid = false;
           errors["batch_code"] = "*Batch code is required";
         }
         this.setState({
            errors: errors
          });
          return formIsValid;

      }
    cancelPopup() {
        this.setState({ showpopup: false });
        this.props.handleClicktrTask(this.props.result_obj,0,false);
        //   {this.state.switch_case &&
        //   <FourthCycleComponent status_id = {this.props.status_id} doc_id = {this.props.doc_id} status_name = {this.props.status_name}/>}
        // }
    }
    handleRelease(e,type) {
     if(this.formValidate()) {
       let description = this.state.description.toString().replace(/\s+/g, ' ').trim();
       console.log(this.props.blocked_element_data);
       let release_type_id = this.props.blocked_element_data[0].release_method_id;
       const details = {
           webform_id:this.props.webform_id ,
           person_id: this.state.loggedPerson,
           comment:description ,
           person_name:this.state.loggedPersonName,
           batch_code:this.state.batch_code,
           ref_id:(release_type_id == 2)?localStorage.getItem('blockbox_ref_id'):this.props.ref_id,
           blocked_ref_id:this.props.blocked_ref_id,
           step_id:(release_type_id == 2)?localStorage.getItem('blockbox_step_id'):this.props.step_id,
           block_box_type:type,
           org_unit:this.props.org_unit,
           release_method_type:release_type_id,
           //this.props.blocked_element_data[0].release_method_id,
       }
       datasave.service(window.STORE_BLOCKBOX_RELEASE_DETAILS, 'POST', details)
         .then(response => {
          if(response.result.status === "200") {
            OCAlert.alertSuccess('Block box release successfully', { timeOut: window.TIMEOUTNOTIFICATION });
            details['person_id'] = response.release_person_id;
            details['blockbox_todo_id'] = (response.blockbox_todo_id !== 0)?response.blockbox_todo_id:-999;
            this.props.handleBlockBoxsubmit(e,details);
            this.props.handleclosepopup();
          }
          else {
            OCAlert.alertError(response.result.error, { timeOut: window.TIMEOUTNOTIFICATION });

          }
        })
     }
    }
    showPopup() {
        this.setState({ showpopup: true });
    }

    handleService(url, request_type, data) {
        datasave.service(url, request_type, data)
            .then(response => {
            });
    }

    render() {
      console.log(this.props);
      var new_value = 0;
//       localStorage.removeItem('webform_content');
//       let web_obj = this.props.webform_content_obj;
//       console.log(obj)
//       console.log(this.props)
// localStorage.setItem('webform_content', {web_obj});
        const { description, loading, errors,error,blocked_element_data,t } = this.state;
        let obj = this.props.release_org_options;
        this.props.latest_blocked_element.map(item => {
            if((item.blockbox_ro_type === 1 || item.blockbox_ro_type === 3)){
              new_value = 1;
              return;
            }

        })
        console.log(new_value)
      const webform_todos_result_details = this.props.blocked_element_data.map(item => {
        return(
          <tr>
        {/*  <td style={{'backgroundColor':item.colour,textAlign:'center'}}>{window.ELEMENT_ACTIONS[item.action_type.toString()]}</td>*/}
          <td style={{'backgroundColor':'#FFFFF',textAlign:'center'}}>{item.label.replace(/ *\([^)]*\) */g, "")}</td>
        <td style={{'backgroundColor':item.background_colour,'color':item.colour,textAlign:'center'}}>{item.resullt_value}</td>
        {/*  <td style={{'backgroundColor':item.colour,textAlign:'center'}} >{item.block_box_name}</td>*/}
          </tr>
        )
      })
    const  webform_todo_result =  (
     <div style={{width: '100%', float: "left"}} >
       <reactbootstrap.Table striped bordered hover size="sm">
           <thead style={{backgroundColor: '#EC661C', color: '#fff',position: 'sticky',top: '0',textAlign:'center'}}>
               <tr>
                {/*   <th >{'Action'}</th>*/}
                   <th>{'Blocked elements overview'}</th>
                   <th>{'Value'}</th>
                  {/* <th>{'Blockbox name'}</th>*/}

               </tr>
               </thead>
               <tbody>
                {this.props.blocked_element_data.length > 0 &&  webform_todos_result_details}
           </tbody>

       </reactbootstrap.Table>
       </div>
     );
     let blocked_details = this.props.latest_blocked_element.map(item => {
            return Object.keys(this.props.webform_content_obj).map(function (item1, key) {
              if(item1.toString() === item.element_id.toString() && (item.blockbox_ro_type === 1 || item.blockbox_ro_type === 3)){

            return(
    <BlockBoxTagBuild
    handleDateChange = {this.props.handleDateChange}
    form_content={this.props.webform_content_obj[item1]}
     datavalue = {this.props.simulation_state[this.props.webform_content_obj[item1]['id']]}
     validateNumberFields = {['']}
     handleChange = {this.props.handleChange}
     PJDG = {this.props.PJDG}
     JDG_personlist = {this.props.JDG_personlist}
     handleSelectChange={this.props.handleSelectChange}
     />
            /*  <tr>
              <td style={{'backgroundColor':item.colour,textAlign:'center'}}>{window.ELEMENT_ACTIONS[item.action_type.toString()]}</td>
              <td style={{'backgroundColor':item.colour,textAlign:'center'}}>{item.label}</td>
              <td style={{'backgroundColor':item.colour,textAlign:'center'}}>{item.resullt_value}</td>
              <td style={{'backgroundColor':item.colour,textAlign:'center'}} >{item.block_box_name}</td>
              </tr>*/
            )}

          },this)
        } )
        let childformdata = this.props.block_box_child_form.map(item =>{
          const details  = {type:14,id:item.id,name:item.name,data:JSON.parse(item.json_data)};
            return(
           <BlockBoxTagBuild
           form_content = {details}
          handleDateChange = {this.props.handleDateChange}
           validateNumberFields = {['']}
           handleChange = {this.props.handleChange}
           PJDG = {this.props.PJDG}
           simulate = {this.props.simulate}
            autoGenerateChildform={this.props.autoGenerateChildform}
            parent_id = {this.props.parent_id}
            child_linked_unique_id = {this.props.child_linked_unique_id}
            getParentUpdateState = {this.props.getParentUpdateState}
            disable_field = {this.props.disable_field}
            submit_id = {this.props.submit_id}
            step_id = {this.props.step_id}
            webform_id = {this.props.webform_id}
            handleSubmit = {this.props.handleSubmit}
            parentSaved = {this.props.parentSaved}
            ref_id = {this.props.refid}
           JDG_personlist = {this.props.JDG_personlist}
           handleSelectChange={this.props.handleSelectChange}
           />
         )
        })
        return (
          <div>
            <reactbootstrap.Modal   backdrop="static"
                   keyboard={false} show={this.state.showpopup} onHide={this.cancelPopup}
                   dialogClassName="modal-90w modal-pop-up-wrapper"
                   aria-labelledby="example-custom-modal-styling-title"
                   >
                      <reactbootstrap.Modal.Header >
                            <reactbootstrap.Modal.Title style={{ color : '#EC661C', fontSize : '1.3rem'}}><a onClick = {this.showRelease} >{'Please contact the person responsible for release'}</a></reactbootstrap.Modal.Title>
                          <a onClick= {this.Goback} href= ''>{'Go back'} </a>
                      </reactbootstrap.Modal.Header>
          <div className='container py-2' >
            <div className='justify-content-center' style={{width: '100%', float: 'left'}} >
              <div className='col-lg-12 col-md-12 float-left px-0'>
                  <reactbootstrap.Container className="p-1">
                      <reactbootstrap.Form >
                          <reactbootstrap.Modal.Body>
                          {this.state.showRelease !== false && <div>
                            <reactbootstrap.FormGroup>
                             <reactbootstrap.InputGroup className="">
                             <div className=" row input-overall-sec ">
                                 <reactbootstrap.InputGroup className="">
                                     <div className="col-md-4">
                                         <reactbootstrap.InputGroup.Prepend>
                                             <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Release actor type:')}</reactbootstrap.InputGroup>
                                         </reactbootstrap.InputGroup.Prepend>
                                     </div>
                                     <div class="col-md-8 input-padd">
                                   <reactbootstrap.Form.Control
                                   name="release_actor_type"
                                   as="select"
                                   value={this.props.release_actor_type}
                                   onChange={this.props.handleChange} >
                                       <option value={window.PERSON_ENTITY}>{t('Person')}</option>
                                       <option value={window.JOB_ENTITY}>{t('Job')}</option>
                                       <option value={window.DEPARTMENT_ENTITY}>{t('Department')}</option>
                                       <option value={window.GROUP_ENTITY}>{t('Group')}</option>
                                   </reactbootstrap.Form.Control>
                                   </div>
                                 </reactbootstrap.InputGroup>
                             </div>

                             <div className=" row input-overall-sec ">
                                 <reactbootstrap.InputGroup className="  ">
                                     <div className="col-md-4">
                                         <reactbootstrap.InputGroup.Prepend>
                                             <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Release organisation type name')}</reactbootstrap.InputGroup>
                                         </reactbootstrap.InputGroup.Prepend>
                                     </div>
                                     <div class="col-md-8 input-padd">
                                         <reactbootstrap.FormControl
                                             name="name"
                                             placeholder={("Name")}
                                             aria-label="title"
                                             aria-describedby="basic-addon1"
                                             value={this.state.release_actor_name}
                                             disabled = {true}
                                             className="input_sw"
                                         />
                                     </div>
                                 </reactbootstrap.InputGroup>
                             </div>
                            {this.props.release_actor_type !== 1 && <div className=" row input-overall-sec ">
                                 <reactbootstrap.InputGroup className="">
                                     <div className="col-md-4">
                                         <reactbootstrap.InputGroup.Prepend>
                                             <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C'}} id="basic-addon1">{t('Relase organisation units:')}</reactbootstrap.InputGroup>
                                         </reactbootstrap.InputGroup.Prepend>
                                     </div>
                                     <div class="col-md-8 input-padd">
                                         <reactbootstrap.FormControl as="select" name="manual_id"
                                             value={this.props.release_actor_id}
                                             name = {'release_actor_type_id'}
                                             // disabled={details.disableFields || details.exp_his_disabled}
                                             //onChange={}
                                             className="input_sw"
                                         >   <option value={0}>{'---Select---'}</option>
                                         { (obj !== undefined && obj.length > 0) ? obj.map(org => <option value={org.person_id}>{org.person_name}</option>):[]}
                                         </reactbootstrap.FormControl>
                                     </div>
                                 </reactbootstrap.InputGroup>

                             </div>}
                            </reactbootstrap.InputGroup>
                        </reactbootstrap.FormGroup></div>}
                          <reactbootstrap.FormGroup>
                           <reactbootstrap.InputGroup className="">
                          <div className="col-md-12">
                          {/*  <reactbootstrap.InputGroup.Prepend>
                              <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Blocked elements overview')}:</reactbootstrap.InputGroup>
                            </reactbootstrap.InputGroup.Prepend> */}
                            </div>
                            <div className = "col-md-12">
                            {this.props.blocked_element_data.length > 0 && webform_todo_result}
                            </div>
                          </reactbootstrap.InputGroup>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                         <reactbootstrap.InputGroup className="">
                      {this.props.blocked_element_data.length > 0 && new_value === 1 &&  <div className="col-md-12">
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('New values for blocked elements ')}:</reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                        </div>}
                          <div className = "col-md-12">
                            {this.props.blocked_element_data.length > 0 && blocked_details}
                            </div>

                          </reactbootstrap.InputGroup>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                         <reactbootstrap.InputGroup className="">
                  {  this.props.block_box_child_form.length > 0 &&    <div className="col-md-12">
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Child form ')}:</reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                        </div>}
                        <div className = "col-md-12">
                          {this.props.block_box_child_form.length > 0 &&childformdata }
                          </div>
                          </reactbootstrap.InputGroup>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                         <reactbootstrap.InputGroup className="">
                    {this.props.resolve  === 1 &&     <div className="col-md-12">
                         <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Resolve time ')}:</reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                          </div>}
                  {this.props.resolve  === 1 &&      <div className = "col-md-12">
                        <reactbootstrap.Form.Label className="col-md-8"  >
                            {this.props.resolve_interval}
                        </reactbootstrap.Form.Label>
                        <reactbootstrap.Form.Label className="col-md-8"  >
                            {this.props.resolve_type}
                        </reactbootstrap.Form.Label>
                        </div>}
                          </reactbootstrap.InputGroup>
                        </reactbootstrap.FormGroup>
                          <reactbootstrap.FormGroup>
                              <div className=" row input-overall-sec ">
                                  <reactbootstrap.InputGroup className="  ">
                                      <div className="col-md-4">
                                          <reactbootstrap.InputGroup.Prepend>
                                              <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Please enter batch code')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                          </reactbootstrap.InputGroup.Prepend>
                                      </div>
                                    <div class="col-md-8 input-padd">
                                        <reactbootstrap.FormControl
                                            name="batch_code"
                                            placeholder={t("Please enter batch code")}
                                            aria-label="title"
                                            aria-describedby="basic-addon1"
                                            value={this.state.batch_code}
                                              type="password"
                                          onChange={e => this.handleChange(e)}
                                            className="input_sw"
                                        />
                                        <div style={{ color: 'red'  }} className="error-block mt-2">{this.state.errors.batch_code}</div>
                                    </div>

                                </reactbootstrap.InputGroup>

                            </div>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                            <div className=" row input-overall-sec ">
                                <reactbootstrap.InputGroup className="  ">
                                    <div className="col-md-4">
                                        <reactbootstrap.InputGroup.Prepend>
                                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Comment')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                        </reactbootstrap.InputGroup.Prepend>
                                    </div>
                                    <div class="col-md-8 input-padd">
                                    <reactbootstrap.FormControl
                                        style={{ height: '20<reactbootstrap.Modal show={this.state.showpopup} 0px' }}
                                        as="textarea" rows="3"
                                        name="description"
                                        placeholder={this.props.placeholder}
                                        value={this.state.description}
                                        onChange={e => this.handleChange(e)}
                                    />
                                      <div style={{ color: 'red'  }} className="error-block mt-2">{this.state.errors.description}</div>
                                    </div>
                                </reactbootstrap.InputGroup>

                            </div>
                        </reactbootstrap.FormGroup>
                        </reactbootstrap.Modal.Body>
                        <div style={{ color: 'red' }} className="error-block">{error}</div>
                        <reactbootstrap.Modal.Footer style={{ borderTop: '0px' }}>
                            <reactbootstrap.Modal.Footer style={{ borderTop: '0px' }}></reactbootstrap.Modal.Footer>
                            <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={e => this.handleRelease(e,1)} >{t('Release')}</reactbootstrap.Button>


                          {/*(this.props.resolve  === 1) && <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={e => this.handleRelease(e,2)} >{t('Not possible to resolve')}</reactbootstrap.Button>*/}
                                              {(this.props.stopwebform === 1) && <reactbootstrap.Button type="button" disabled={loading}onClick={e => this.handleRelease(e,3)} color="primary">{t('Stop')}</reactbootstrap.Button>}
                            {loading &&
                                <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                            }
                            &nbsp;&nbsp;&nbsp;
                        </reactbootstrap.Modal.Footer>
                    </reactbootstrap.Form>
                </reactbootstrap.Container>
              </div>
            </div>
          </div>
            </reactbootstrap.Modal >
            </div>
        );
    }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(BlockBoxPopUp));
