//import axios from 'axios'
import { Tabs, Tab } from 'react-bootstrap';
import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import { datasave } from './_services/db_services';
import * as reactbootstrap from 'react-bootstrap';
import Pagination from 'react-bootstrap/Pagination';
import './Organisations.css';
import Can from './_components/CanComponent/Can';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import { translate } from './language';
import { OCAlert } from '@opuscapita/react-alerts';
import './GroupsList.css';
import Group from './Groups';

class GroupsList extends Component {
  constructor(props) {
    super(props)
    this.handleSelect = this.handleSelect.bind(this);
    // this.handleImpactSelect = this.handleImpactSelect.bind(this);
    //this.handleMakeactive = this.handleMakeactive.bind(this)
    //this.handleMakeinactive = this.handleMakeinactive.bind(this)
    this.state = {
      groups: [],
      active_tab: 'Active_groups',
      inactivegroupsdata: [],
      activegroupsdata: [],
      show: false,
      groupdetails: [],
      delid: '',
      count1: '',
      sucess: '',
      currentPage: 1,
      todosPerPage: 5,
      links: '',
      nolinks: '',
      count: 0,
      active: 1,
      filetrFullList: [],
      id: '',
      items: [],
      page: 5,
      searchTerm: '',
      name: '',
      docs:'',
      t: props.t,
      allimpactData: [],
      activeImapctTab: 0,
      impactTabName: 'Webform LOU',
      mainkey : 1,
    }
    this.searchData = this.searchData.bind(this);
    this.handleMainTabSelect = this.handleMainTabSelect.bind(this)

  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
      datasave.service(window.GET_GROUPS, 'GET', '')
        .then(response => {
          const pageData = this.getPageData(this.state.active, response['activegroups']);
          const count = this.getCountPage(response['activegroups']);
          this.setState({
            groups: response['activegroups'],
            items: pageData,
            count: count,
            saveComponent: "",
            didupdate: 'true',
            temp: 'did',
          })
        });
    }
  }
  getCountPage(items) {
    const itemLength = items.length;

    return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }

  searchData(e) {
    var list = [...this.state.groups];
    list = list.filter(function (item) {
      if (item.name !== null) {
        return item.name.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
    });
    const page_data = this.getPageData(1, list);
    const count = this.getCountPage(list);
    this.setState({
      items: page_data,
      count: count,
      active: 1,
      searchTerm: e.target.value,
      filterFullList: list,
    });
  }
  handleSelect(key) {
    const {t} = this.state
    if (key == 1) {
      this.setState({
        active_tab: 'Active_groups',
      })
    }
    else {
      this.setState({
        active_tab: 'inActive_groups',
      })
    }
  }

  handleMainTabSelect(key) {
    this.setState({
      mainkey : key,
    })
  }

  // handleImpactSelect(key) {
  //   this.setState({
  //     activeImapctTab: key,
  //     currentPage: 1,
  //   })
  // }

  componentWillMount() {
    var url = window.GET_GROUPS;
    datasave.service(url, "GET", '')
      .then(response => {
        this.setState({
          activegroupsdata: response['activegroups'],
          inactivegroupsdata: response['inactivegroups'],
          items: this.state.groups,
        })

      })

  }

  componentDidMount() {
    var url = window.GET_GROUPS;
    datasave.service(url, "GET", '')
      .then(response => {
        const pageData = this.getPageData(1, response['activegroups']);
        const count = this.getCountPage(response['activegroups']);
        this.setState({
          activegroupsdata: response['activegroups'],
          inactivegroupsdata: response['inactivegroups'],
          groups: response['activegroups'],
          count: count,
          items: pageData,
        })
      })
  }
  changePage(e, id = 1) {
    const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
    const page_data = this.getPageData(id, list);
    this.setState({
      items: page_data,
      active: id,
    });
  }
  getPageData(id, list = '') {


    const page = this.state.page;

    const items = (list !== '') ? list : this.state.groups;
    const page_data = items.slice(page * (id - 1), page * id);

    return page_data;
  }

  /*handleMakeactive(id, e) {

    const details = {
      status: 1
    }
    const groupId = id;
    var url = window.GROUP_ACTIVITIES + '/' + groupId;
    var method = 'PUT';
    var data = details;
    datasave.service(url, method, data)
      .then(result => {
        if (result === 1) {
          window.location.reload()

        }

      })
      .catch(error => {
        this.setState({
          errors: error.result.data.errors
        })
      })

  }*/

  handleExport() {
    const gid = this.state.delid;
    var url = window.EXPORT_GROUPS+gid;
    datasave.service(url,'PUT','')
    .then(response =>{
      window.open(response);
      window.close();
    })
    this.setState({
      show:false,
      impactTabName: 'Webform LOU',
    })
  }
  handlePageClick(event) {
    this.setState({
      currentPage: Number(event.target.id)
    });
  }
  /*handleMakeinactive(id, e) {

    const details = {
      status: 0
    }
    const groupId = id;
    var url = window.GROUP_ACTIVITIES + '/' + groupId;
    var method = 'PUT';
    var data = details;
    datasave.service(url, method, data)
      .then(result => {
        if (result === 1) {
          window.location.reload()

        }

      })
      .catch(error => {
        this.setState({
          errors: error.result
        })
      })
  }*/
  handleDetails(id) {
    var url = window.GROUP_DETAILS + id;
    datasave.service(url, 'GET')
      .then(response => {
        this.setState({
          // groupdetails: response.selected,
          allimpactData: response.impactData,
          show: true,
          delid: id,
          didupdate: 'true',
          count1: response.selected.length,
          links: false,
          // activeImapctTab: 0,
        })
        if (this.state.count1 == 0) {
          this.handleDelete(id);
          this.setState({
            nolinks: true,
            links: false,
          })
        }
        else {
          this.setState(
            {
              links: true,
              nolinks: false,
            }
          )
        }
      })
    this.setState({ currentPage: 1 })
  }

  handleDelete(pid) {
    const {t} = this.state;
    this.setState(
      { show: false, didupdate: '1', }
    )
    var url = window.DELETE_GROUP;
    var details = {
      pid: pid,
    }
    datasave.service(url, 'PUT', details)
      .then(response => {
            if(response === 'Linked with docs'){
             OCAlert.alertWarning(t('Linked with document cycle'), { timeOut: window.TIMEOUTNOTIFICATION1});
            }
        // this.setState({
        //   activegroupsdata: response,
        // })
      })
  }
  handleHide = () => {
    this.setState({
      show: false,
      impactTabName: 'Webform LOU',
    })
  }

  handleCancel() {
    this.setState({
      show: false,
      impactTabName: 'Webform LOU',
    })
  }

  handlePageChange () {
    this.setState({
      mainkey : 1,
    })
    datasave.service(window.GET_GROUPS, 'GET', '')
        .then(response => {
          const pageData = this.getPageData(this.state.active, response['activegroups']);
          const count = this.getCountPage(response['activegroups']);
          this.setState({
            groups: response['activegroups'],
            items: pageData,
            count: count,
            saveComponent: "",
            didupdate: 'true',
            temp: 'did',
          })
        });
  }

  render() {
    const filtered = this.state.items;
    const { t } = this.state;
    let active = this.state.active;
    let pages = [];
    if (this.state.count > 0) {
      for (let number = 1; number <= this.state.count; number++) {
        pages.push(
          <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
            {number}
          </Pagination.Item>,
        );
      }
    }
    const { activegroupsdata, groupdetails, currentPage, todosPerPage, links, nolinks, activeImapctTab } = this.state
    const indexOfLastTodo = currentPage * todosPerPage;
    const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
    // const currentTodos = groupdetails.slice(indexOfFirstTodo, indexOfLastTodo);
    // const pagerender = currentTodos.map(doc => {
    //   return <tr>
    //     <td>{doc.name}</td>
    //     <td>{doc.category}</td>
    //   </tr>
    // });

    let currentTabData = [];
    Object.keys(this.state.allimpactData).map((tab, value) => {
      this.state.allimpactData[tab].map((item) => {
        currentTabData.push(item);
      })
      // if (value === parseInt(activeImapctTab)) {
      //   currentTabData = this.state.allimpactData[tab]
      // }
    })
    const currentTodos = currentTabData.slice(indexOfFirstTodo, indexOfLastTodo);

    const pagerender = currentTodos.map(item => {
      return <tr>
        <td>{item.name}</td>
        <td>{item.category}</td>
      </tr>
    });

    const pageNumbers = [];
    if(currentTabData.length > 5){
    for (let i = 1; i <= Math.ceil(currentTabData.length / todosPerPage); i++) {
      pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
        {i}
      </Pagination.Item>);
    }
  }
    const popupData = (
      <reactbootstrap.Modal
        show={this.state.show}
        onHide={this.handleHide}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
          </reactbootstrap.Modal.Title>
          <reactbootstrap.Modal.Body col-md-12 pr-0>
            {/* <Tabs activeKey={activeImapctTab} onSelect={this.handleImpactSelect} id="controlled-tab-example">
                {Object.keys(this.state.allimpactData).map((tab, value) => (
                  <Tab eventKey={value} title={tab}> */}
                    <reactbootstrap.Table striped bordered hover variant="dark">
                      <thead>
                        <tr>
                          <td>{t('Name')}</td>
                          <td>{t('Category')}</td>
                        </tr>
                      </thead>
                      <tbody>
                        {pagerender}
                      </tbody>
                    </reactbootstrap.Table>
                  {/* </Tab>
                ))}
            </Tabs> */}
            <Pagination size="sm" style={{width: '410px', overflow: 'auto'}}>{pageNumbers}</Pagination>
          </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal.Header>
        {this.state.links && <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={() => this.handleCancel()}>{t('Cancel')}</reactbootstrap.Button>
          <reactbootstrap.Button onClick={() => this.handleExport()}>{t('Export')}</reactbootstrap.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
          </reactbootstrap.Modal.Footer>}
      {/*  {this.state.nolinks &&  <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={(e) => this.handleDelete(this.state.delid)}>{t('Ok')}</reactbootstrap.Button>
        </reactbootstrap.Modal.Footer>} */}
      </reactbootstrap.Modal>
    );

    if (this.state.active_tab === 'Active_groups') {
      return (
        <div className=" row col-md-12">
      <div style={{visibility: 'hidden'}} className="col-md-1"><p>welcome</p></div>
      <div style={{}} className='col-md-11' >
        <Can
          perform="E_group,R_group,D_group,LOU"
          yes={() => (
            <div className='' >
              <div className='' >
                <div  className='col-md-12 mt-0 border-radius' >
                  <div class='organisation_list'>
                    <div className='header'>
                     <reactbootstrap.Tabs activeKey={this.state.mainkey} onSelect={this.handleMainTabSelect} id="controlled-tab-example">
                    <reactbootstrap.Tab eventKey={1} title={t("Manage groups")}>

                      <reactbootstrap.Tabs activeKey={this.state.key} onSelect={this.handleSelect} id="controlled-tab-example">
                        <reactbootstrap.Tab eventKey={1} title={t("Active groups")}></reactbootstrap.Tab>
                        {/* <reactbootstrap.Tab eventKey={2} title="Inactive groups"></reactbootstrap.Tab> */}
                      </reactbootstrap.Tabs>

                    <div className='card-body'>
                      <input  className="form-control search-box-border col-md-4 mb-2" placeholder={t("Search")} onChange={this.searchData} />
                      {/* <div style={{height: '400px', overflowY: 'auto'}}> */}
                      <div style={{}}>
                      <reactbootstrap.Table  className="site-table-main" >
                        <thead>
                        <tr >
                            <th>{t('Name of group')}</th>
                            <th style={{ textAlign: 'right',paddingRight: '1.5rem' }} colspan="2">{t('Actions')}</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.map(group => (
                            <tr style={{borderBottom: '1px solid #dee2e6'}}>
                              <td> {group.name}</td>
                              {/* <td></td> */}
                             {/* <div className="sammmm"> */}
                              <td style={{display: 'flex', float: 'right', border: '0px'}}>
                                <Can
                                  perform="E_group"
                                  yes={() => (
                                    <Link  style={{float: 'right', padding: '10px'}}
                                      to={`/groups/${group.id}`}
                                      key={group.id}
                                    >
                                      <i title={t("Edit")} class="overall-sprite overall-sprite-myeditc"></i>
                                      {/* {t('Edit')} */}
                                    </Link>
                                  )}
                                />

                                <br></br>
                                {/* <a
                                onClick={this.handleMakeinactive.bind(this, group.id)}
                              >
                                Make archive
                                  </a><br></br> */}

                                <Can
                                  perform="D_group"
                                  yes={() => (
                                    <a  style={{float: 'right', padding: '10px'}} onClick={this.handleDetails.bind(this, group.id)}>
                                      {/* {t('Delete')} */}
                                      <i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec"></i>
                                    </a>
                                  )}
                                />
                              </td>
                              {/* </div> */}
                            </tr>
                          ))}
                        </tbody>
                      </reactbootstrap.Table>
                      </div>
                      {/* <Pagination size="md">{pages}</Pagination> */}
                      <div className="page-nation-sec col-md-12">
                        <Pagination style={{width: '500px',overflow: 'auto'}} size="md">{pages}</Pagination>
                        </div>
                      {popupData}
                    </div>
                    </reactbootstrap.Tab>
                    <reactbootstrap.Tab eventKey={2} title={t("Create group")}>
                    <Group handlePageChange={this.handlePageChange.bind(this)} uniqueId={Math.floor((Math.random() * 1000) + 1)}></Group>
                  </reactbootstrap.Tab>
                    </reactbootstrap.Tabs>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          no={() =>
            <AccessDeniedPage />
          }
        />
        </div>
        </div>
      );
    }
  }
}
export default translate(GroupsList)

{/* <i class="overall-sprite overall-sprite-mtdeletec"></i>
<i class="delete-edit delete-edit-deletemc"></i>
<i class="overall-sprite overall-sprite-myeditc"></i>
<i class="delete-edit delete-edit-editmc"></i> */}
