import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import CKEditor from '@ckeditor/ckeditor5-react';
import ClassicEditor from 'ckeditor5-build-classic-plus';
import { datasave } from '../_services/db_services';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { PagePermissions } from '../_components/CanComponent/PagePermissions';
import { translate } from '../language';

class EmailOverview extends Component {
  constructor(props) {
    super(props);
    this.state = {
      emailList: '',
      check: false,
      t: props.t,
    };
    this.emailsData = this.emailsData.bind(this);
    this.handleClick = this.handleClick.bind(this);

  }

  componentDidMount() {
    let self = this;
    datasave.service(window.get_emails, 'GET', this.state).then(result => {
      if (result != '') {
        self.setState({
          emailList: result,
          check: true,
        });
      }
      /*else {
      }*/
    });
  }

  emailsData() {
    let data = [];
    const { t } = this.state;
    if (this.state.check) {
      this.state.emailList.map(emails => {
        data.push(
          <tr>
            <td>{emails.name}</td>
            <td>{emails.description}</td>
            <td style={{ textAlign: 'center' }}>
              <Can
                perform="E_email_template"
                yes={() => (

                  <i
                    variant="link"
                    id={emails.id}
                    name="edit"
                    onClick={this.handleClick}
                    title="Edit" class="overall-sprite overall-sprite-myeditc"></i>

                )}
              />
            </td>
            {/*<td style={{ textAlign: 'center' }}>
              <Can
                perform="D_email_template"
                yes={() => (
                  < i
                    variant="link"
                    id={emails.id}
                    name="delete"
                    onClick={this.handleDelete}

                    title="Delete" tit class="overall-sprite overall-sprite-mtdeletec"></i>

                )}
              />
            </td>*/}
          </tr>
        );
      });
      return data;
    }
  }

  handleClick(event) {
    const id = event.target.id;
    this.props.history.push({
      pathname: '/appsettings/emailtemplate/' + id,

    });
  }

  handleDelete(event) {
    const id = event.target.id;
    var data = {
      id: id,
    };
    datasave.service(window.delete_user, 'POST', data).then(result => {
      window.location.reload();
    });
  }

  render() {
    const as4_or_site = 1;//PagePermissions()
    const { t } = this.state;

    if (as4_or_site) {
      return (
        <div className=" row col-md-12">
        <div style={{visibility: 'hidden'}} className="col-md-1"><p>welcome</p></div>
        <div style={{}} className='col-md-11' >
        <Can
          perform="R_email_template,E_email_template"
          yes={() => (
            <div className='row' >
              <div className='col-md-12 mb-5 mt-5' >
                <div id="emailoverview" className='col-md-12 p-0' >
                  <div className='card' >
                    <div>
                      <div>
                        <reactbootstrap.Table striped responsive bordered>
                          <thead>
                            <tr>
                              <th style={{position: 'sticky',top: '0',backgroundColor: '#fff' }}>{t('Email')}</th>
                              <th style={{position: 'sticky',top: '0',backgroundColor: '#fff' }}>{t('Description')}</th>
                              <th style={{position: 'sticky',top: '0',backgroundColor: '#fff' }}>{t('Edit')}</th>
                            </tr>
                          </thead>
                          <Can
                            perform="R_email_template,E_email_template"
                            yes={() => (
                              <tbody> {this.emailsData()}</tbody>
                            )}
                          />
                        </reactbootstrap.Table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          no={() =>
            <AccessDeniedPage />
          }
        />
      </div>
    </div>
      );
    }
    else {
      return (
        <AccessDeniedPage />
      )
    }
  }
}

export default translate(EmailOverview);
