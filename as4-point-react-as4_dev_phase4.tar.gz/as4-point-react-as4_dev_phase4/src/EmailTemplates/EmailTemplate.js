import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import CKEditor from '@ckeditor/ckeditor5-react';
import ClassicEditor from 'ckeditor5-build-classic-plus';
import { Button, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Select from 'react-select';
import { translate } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';

class EmailTemplate extends Component {
  constructor(props) {
    super(props);
    this.state = {
      check: false,
      lang_code: 'en',
      email_type_id: this.props.match.params.id,
      updated_by: '',
      tokens: [],
      templates: {},
      options: [],
      t: props.t,
      selectedLang: [{ value: 'en', label: 'English' }],
    };
    this.submitCkdata = this.submitCkdata.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.tokenList = this.tokenList.bind(this);
    this.handleLangChange = this.handleLangChange.bind(this);
  }

  submitCkdata(e) {
    const { t } = this.state;
    datasave
      .service(window.insert_emailtemplate, 'POST', this.state)
      .then(result => {
        if (result != '') {
          OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
          this.props.history.push({
            pathname: '/appsettings/emailoverview',
          });
        }
        /*else {
        }*/
      });
  }


  handleChange(event) {
    var lang = this.state.selectedLang[0].value;
    var name = event.target.name;
    var value = event.target.value;
    var templates = 'templates';
    var temp = this.state.templates;
    temp[lang][name] = value;
    this.setState(prevState => ({
      [templates]: temp,
    }));
  }

  componentDidMount() {
    var data = {
      id: this.state.email_type_id,
    };

    this.getTokens(data)
  }
  getTokens(data) {
    datasave.service(window.get_tokens, 'POST', data).
      then(result => {

        this.getLanguages(data, result)
        //tokens check
        /*if (this.getLanguages(data, result)) {
        } else {
        }*/
      });
    return true;
  }
  getLanguages(data, tokenResult) {
    datasave.service(window.get_languages, 'GET', '').then(result => {
      var items = {};
      result.map(function (item, id) {
        items = Object.assign(items, {
          [item.value]: { subject: '', body: '', tokenid: [] },
        });
      });
      var selectedLang = [{ value: 'en', label: 'English' }];
      this.getEmailTemplates(data, tokenResult, result, selectedLang, items)
      /*if (this.getEmailTemplates(data, tokenResult, result, selectedLang, items)) {
      } else {
      }*/
    });
    return true;
  }

  getEmailTemplates(
    data,
    tokenResult,
    optionsResult,
    selectedLang,
    templatesResult
  ) {
    datasave.service(window.get_emailtemplates, 'POST', data).then(result => {

      var temp = templatesResult;
      result.map(key => {
        if (temp[key.lang_code] != undefined) {
          temp[key.lang_code]['subject'] = key.subject === null ? '' : key.subject;
          temp[key.lang_code]['body'] = key.body === null ? '' : key.body;
        }
      });
      this.usertokens(data, tokenResult, optionsResult, selectedLang, temp)
      /*if (this.usertokens(data, tokenResult, optionsResult, selectedLang, temp)) {
      } else {
      }*/

    });
    return true;
  }
  usertokens(data, tokenResult, optionsResult, selectedLang, templatesResult) {
    datasave.service(window.user_tokens, 'POST', data).then(result => {
      var temp = templatesResult;

      temp.en.tokenid = [];
      result.map(key => {
        temp[key.lang_code]['tokenid'].push(key.ref_id);
      });
      //templates
      this.setState({
        tokens: tokenResult,
        options: optionsResult,
        selectedLang: selectedLang,
        templates: temp,
        check: true,
      });
    });
    return true;
  }



  tokenList() {
    if (this.state.check) {
      let list = [];
      this.state.tokens.map(token => {
        list.push(
          <tr>
            <td>{token.token_ref}</td>
            <td>{token.name}</td>
          </tr>
        );
      });
      return list;
    }
  }

  handleLangChange(e) {
    this.setState({
      selectedLang: [e],
    });
  }

  render() {
    const { t } = this.state;
    if (
      Object.keys(this.state.templates).length !== undefined &&
      Object.keys(this.state.templates).length > 0
    ) {
      return (
        <Can
          perform="E_email_template"
          yes={() => (
            <div className='container py-4' >
              <div className='row justify-content-center' >
                <div className='col-md-12 mb-4' >
                  <div className='card p-3' >
                    <FormGroup>
                      <div style={{ display: 'flex' }} className=" input-overall-sec ">
                        <div style={{ alignSelf: 'center' }} className="col-md-3">
                          <span style={{ color: '#EC661C', padding: '8px' }}> {t('Language')}:</span>
                        </div>
                        <div className="col-md-9 input-padd " >
                          <div className="input_sw">
                            <Select
                            className="select-section"
                              name="lang"
                              value={this.state.selectedLang}
                              onChange={this.handleLangChange}
                              options={this.state.options}
                            />
                          </div>
                        </div>
                      </div>
                    </FormGroup>
                    <FormGroup>
                      <div style={{ display: 'flex' }} className=" input-overall-sec ">

                        <div style={{ alignSelf: 'center' }} className="col-md-3">
                          <span style={{ color: '#EC661C', padding: '8px' }}> {t('Subject')}:</span>
                        </div>
                        <div className="col-md-9 input-padd " >
                          <reactbootstrap.Form.Control
                          className="input_sw"
                            type="text"
                            placeholder="Enter Subject"
                            name="subject"
                            onChange={this.handleChange}
                            value={
                              this.state.templates[this.state.selectedLang[0].value]
                                .subject || ''
                            }
                          />
                        </div>

                      </div>

                    </FormGroup>
                    <FormGroup>
                    <div style={{ display: 'flex' }} className=" input-overall-sec ">
                    <div  className="col-md-3">
                          <span style={{ color: '#EC661C', padding: '8px' }}> {t('Body')}:</span>
                        </div>
                        <div className="col-md-9 input-padd input_sw" >
                        <CKEditor
                          type="textarea"
                          editor={ClassicEditor}
                          data={
                            this.state.templates[this.state.selectedLang[0].value]
                              .body || ''
                          }
                          config={{
                            removePlugins: ['Image', 'ImageCaption', 'ImageStyle', 'ImageToolbar', 'ImageUpload', 'MediaEmbed'],
                          }}
                          onInit={editor => {
                            // You can store the "editor" and use when it is needed.
                          }}
                          onChange={(event, editor) => {
                            const data = editor.getData();
                            var lang = this.state.selectedLang[0].value;
                            var name = 'body';
                            var templates = 'templates';
                            var tid = 'tokenid';
                            var temp = this.state.templates;
                            temp[lang][name] = data;
                            var arr = [];
                            temp[lang].tokenid = [];
                            this.state.tokens.map(token => {
                              var regexp = new RegExp(token.token_ref, 'g');
                              var res = data.match(regexp);
                              if (res != null) {
                                arr.push(token.id);
                              }
                            });
                            temp[lang].tokenid = arr;

                            this.setState({
                              [templates]: temp,
                            });
                          }}

                        />
                        </div>
                        </div>
                    </FormGroup>
                    <div style={{textAlign: 'right'}}>
                    <reactbootstrap.Button
                      onClick={e => this.submitCkdata()}
                      as="input"
                      type="submit"
                      value={t("Submit")}
                    />
                    </div>

                    <div className="mt-3">
                      <reactbootstrap.Table striped bordered>
                        <thead>
                          <tr>
                            <th>{t('Token id')}</th>
                            <th>{t('Token name')}</th>
                          </tr>
                        </thead>
                        <tbody>{this.tokenList()}</tbody>
                      </reactbootstrap.Table>
                      {this.state.id}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          no={() =>
              <AccessDeniedPage />
          }
        />
      );
    } else {
      return <div>{t('...loading')}</div>;
    }
  }
}

export default translate(EmailTemplate);
