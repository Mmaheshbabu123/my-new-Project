import React, { Component } from 'react';
import axios from 'axios';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from './language';
import { Line, Circle } from 'rc-progress';
class Importblanco extends Component {
    constructor(props) {
        super(props)
        this.state = {
            save: 'Save',
            credentials: this.props.credentials,
            file: '',
            file_details: '',
            showpopup: false,
            t: props.t,
            eventcancel: false,
            thruprops: true,
            percent: 0,
            errorMessage:false
        }
        this.handleChangeFile = this.handleChangeFile.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.cancelPopup = this.cancelPopup.bind(this);
        this.showPopup = this.showPopup.bind(this);
    }
    handleChangeFile(e) {
        //    e.preventDefault(e);
        this.setState({
            file_details: e.target.value,
            file: e.target.files[0],
            errorMessage:false
        })
    }
async   handleSubmit() {
        const formData = new FormData();
        if(this.state.file.length<1 || this.state.file_details.length<1) {
          return;
        }
        const details = {
            file: this.state.file
        }
        for (var key in details) {
            formData.append(key, details[key]);
        }
        this.restart();
        document.getElementById("progress").setAttribute("style", "display:block;");
                    /**document.getElementById("loding-icon").setAttribute("style", "display:block;");*/
        axios.post(window.backendURL + '/api/getblancoZipfile', formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
            .then(async response => {
                if (response['data']!=='failure') {
                    /**document.getElementById("loding-icon").setAttribute("style", "display:none;");*/
                    this.setState({ 'thruprops': false,percent:100  });
                    await this.sleep(1000);
                    this.cancelPopup();
                    this.props.importBlanco(response.data);
                }
                else {
                  this.setState({errorMessage:true});
                    document.getElementById("progress").setAttribute("style", "display:none;");
                }
            });
    }
    sleep=(ms)=> {
      return new Promise(resolve => setTimeout(resolve, ms));
    }
    handleCancel(e) {
        this.cancelPopup();

    }
    cancelPopup() {
        this.setState({ showpopup: false, eventcancel: true ,file: '',file_details: '',errorMessage:false});
         window.location.href = '/manuals/management';

    }
    showPopup() {
        this.setState({ showpopup: true });
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.import !== this.props.import) {
            this.setState({
                showpopup: true,
                file_details: '',
            });
        }
    }
    progressBar = () =>{
      const { percent } = this.state;
      return( <div  style={{textAlign:'center'}}>
      <Line strokeWidth="4" percent={percent} id="loding-icon1"/>{percent!==''?'Importing '+percent+' %':'Importing fails pleace select correct file'}
      </div>)
    }
    restart=()=> {
      clearTimeout(this.tm);
      this.setState({ percent: 0 }, () => {
        this.increase();
      });
    }
    increase=()=> {
      const { percent } = this.state;
      const newPercent = percent +Math.floor((Math.random() * 10) + 1);
      if (newPercent >= 90 || percent===100) {
        clearTimeout(this.tm);
        return;
      }
      this.setState({ percent: percent!==100?newPercent: percent});
      this.tm = setTimeout(this.increase, 200);
    }
    componentDidMount(){
      this.setState({showpopup:true})
    }
    render() {
        const { t, description, loading, updateImageUpload, use_existing_file_edit_img, memo_data, error, id } = this.state;
        return (
          <div>
            <reactbootstrap.Modal show={this.state.showpopup} onHide={this.cancelPopup}>
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title>{t('Import blanco')}</reactbootstrap.Modal.Title>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Container className="">
                    {/* <reactbootstrap.Form onSubmit={this.handleSubmit}> */}
                    <reactbootstrap.Modal.Body>
                        <reactbootstrap.FormGroup>
                            <reactbootstrap.InputGroup.Prepend>{t('Upload file')}</reactbootstrap.InputGroup.Prepend>
                            <input
                                id="file"
                                type="file"
                                name="file"
                                onChange={this.handleChangeFile}
                                value={this.state.file_details}
                                accept=".zip"
                            />
                            <div>{t('Upload only .zip format files.')}</div>
                        </reactbootstrap.FormGroup>
                    </reactbootstrap.Modal.Body>
                    <div style={{ color: 'red' }} className="error-block">{error}</div>
                    <reactbootstrap.Modal.Footer style={{borderTop: '0px'}}>
                        <reactbootstrap.Modal.Footer style={{borderTop: '0px'}}></reactbootstrap.Modal.Footer>
                      <reactbootstrap.Col classname='col-md-6' >
                      <div id='progress' style={{display:'none'}}>
                      {this.progressBar()}
                      </div>
                       {this.state.errorMessage===true &&<span style={{color:'red'}}>{"Something went wrong in the file please select correct file"}</span>}
                      </reactbootstrap.Col>
                      <div style={{float:'right'}}>
                        {/* <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.handleCancel} >{t('Cancel')}</reactbootstrap.Button> */}
                        <a onClick={this.handleCancel} > {t('Cancel')} </a>
                        {loading &&
                            <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                        }
                        &nbsp;&nbsp;&nbsp;
                        {!this.state.errorMessage && <reactbootstrap.Button type="submit" disabled={loading} onClick={this.handleSubmit} color="primary">{t('Save')}</reactbootstrap.Button>}
                        {this.state.errorMessage===true &&<reactbootstrap.Button type="submit" disabled={true} onClick={this.handleSubmit} color="primary">{t('Save')}</reactbootstrap.Button>}
                 </div>
                    </reactbootstrap.Modal.Footer>
                    {/* </reactbootstrap.Form> */}
                </reactbootstrap.Container>
            </reactbootstrap.Modal>
            </div>
        );
    }
}
export default translate(Importblanco)
