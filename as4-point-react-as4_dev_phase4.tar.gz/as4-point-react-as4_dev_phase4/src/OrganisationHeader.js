import React, { Component } from 'react';
const OrganisationHeader = () => (
            <div className='container py-4'>
            <div className='row justify-content-center'>
              <div className='col-md-6'>
                <div className='card'>
                  <div className='card-header'>Create New Organization</div>
                  <div className='card-body'>
                    <form onSubmit={this.handleSubmit}>
                      <div className='form-group'>
                        <label >Organization name</label>
                        <input
                          id='name'
                          type='text'
                          name='name'
                         
                        />
                        
                      </div>
                        <div className='form-group'>
                          <label >Organization description</label>
                             <textarea
                             id='description'
                             name='description'
                             />
                        
                        </div>
	                  <div className = 'form-group'>
	                    <label >Organization logo</label>
	                    <input type='file' name = 'logo'/>
	                  </div>
	                     <div className = 'form-group'>
                               <label >Package</label>
                                 <select name='package_id'>
                                   <option value="0">Basic</option>
                                   <option value="1">Essential</option>
                                   <option value="2">Premium</option>
                                 </select>
                            </div>
                               <div className = 'form-group'>
	                         <label>Types Of Industry</label>
	                         <input type = 'text' name='industry_id'/>
                              </div>
	                        <div className = 'form-group'>
	                          <label>Select Database</label>
	                           <select name='select_database'>
                                     <option value="0">Basic</option>
                                     <option value="1">Essential</option>
                                     <option value="2">Premium</option>
                                   </select>
                                </div>
	                           <div className = 'form-group'>
	                             <label >Country Details</label>
	                             <input type = 'text' name='country_details'/>
	                           </div>
	                             <div className = 'form-group'>
                                       <label >No Of Sites</label>
                                       <input type = 'text' name='No_Of_Sites'/>
                                     </div>
	                               <div className = 'form-group'>
                                         <label >TimeZone</label>
                                         <input type = 'text' name='time_zone'/>
                                       </div>
	                                 <div className = 'form-group'>
                                            <label>Country Details</label>
                                            <input type = 'text' name='location_id'/>
                                          </div>
                                              <div className = 'form-group'>
                                                 <label >Language</label>
                                                 <select name='language_id'>
                                                 <option value="0">English</option>
                                                 <option value="1">Dutch</option>
                                                 <option value="2">French</option>
                                                 </select>
                                              </div>
	                                        
                       


	                <button className = 'btn btn-primary'>Save</button>            
                      <button className='btn btn-primary'>Cancel</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
export default OrganisationHeader
