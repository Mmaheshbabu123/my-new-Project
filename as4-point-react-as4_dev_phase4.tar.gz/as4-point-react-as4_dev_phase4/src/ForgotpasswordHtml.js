import React from 'react'
import * as reactbootstrap from 'react-bootstrap';


const ForgotpasswordHtml = () => (
    <div className="container">
    <div className="row justify-content-center">
        <div className="col-md-8">
            <div className="card">
                <div className="card-header">Forgotpassword</div>
                    <reactbootstrap.Container className="p-5">
                      <reactbootstrap.Form>
                        <reactbootstrap.FormGroup>
                          {/* <reactbootstrap.Label>Email:</reactbootstrap.Label> */}
                          {/* <reactbootstrap.Input
                            type="email"
                            name="email"
                            placeholder="Email"
                            required="1"
                          /> */}
                          <reactbootstrap.InputGroup className="mb-3">
    <reactbootstrap.InputGroup.Prepend>
      <reactbootstrap.InputGroup  id="basic-addon1">@</reactbootstrap.InputGroup>
    </reactbootstrap.InputGroup.Prepend>
    <reactbootstrap.FormControl
      placeholder="Username"
      aria-label="Username"
      aria-describedby="basic-addon1"
    />
  </reactbootstrap.InputGroup>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.Button type="submit" color="primary">Send</reactbootstrap.Button>
                      </reactbootstrap.Form>
                    </reactbootstrap.Container>
            </div>
        </div>
    </div>
</div>
        );
export default ForgotpasswordHtml
