import React from 'react';
import CheckBox from './CheckBox';

export default function CheckBoxList({ options, isCheckedAll, onCheck, category, className }) {


    const buffer = 14;
    const count = Math.ceil(options.length / buffer);
    const loopRender = () =>
       {
         let table = [];
         let z = buffer;
         let x = 0;
         for(let i = 0; i < count; i++) {
            // let classId = "col-md-" + Math.floor(12/count);
            let classId = className ? className : "col-md-3";
            let optionsList = options.slice(x, z);
            let openActiveWebformDoc = localStorage.getItem('open_active_webform_documents') ? parseInt(localStorage.getItem('open_active_webform_documents')) : 0;
            let environment = process.env.REACT_APP_ENV ? process.env.REACT_APP_ENV === 'prod' ? 'PROD' :  'NOT_PROD' : 'NOT_PROD';
            if(!openActiveWebformDoc && environment === 'PROD'){optionsList = optionsList.filter(val => (val.name !== 'Open active webforms/documents'))}
            table.push(<div class={classId}>
                       {optionsList.map(function(option, index ) {
                         z = z + 1;
                         x = x + 1;
                         return (
                             <CheckBox
                                 key={option.function_id}
                                 name={option.name}
                                 value={option.function_id}
                                 tick={option.checked}
                                 classification={option.classification}
                                 onCheck={(e) => onCheck(option.function_id, e.target.checked, category)}
                                 keyvalue={option.function_id}
                             />

                        );
                 })}
                 </div>)
        }
        return table;
    }
    const checkBoxOptions = (

        <div className="checkbox-list">
            <div className="select-all sub-checkboxes">
                <CheckBox
                    name="Select all"
                    value="ALL"
                    tick={isCheckedAll}
                    onCheck={(e) => onCheck('all', e.target.checked, category)}
                />
            </div>

            <div className="sub-checkboxes row">
               {loopRender()}

            </div>

        </div>
    );

    return (
        <div className="checkbox-list">
            {checkBoxOptions}
        </div>
    );
}
