import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import ManualHeader from '../ManualManagement/ManualHeader';
import BlancoStructure from '../Blanco/BlancoStructure';
//import BlancoStructure from '../Blanco/BlancoStructurePerformance';
import { PrivateRoute } from '../_components/PrivateRoute';
import Importblanco from '../Importblanco';
import Can from '../_components/CanComponent/Can';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';

var defaultmanualid = '';
class ManualIndex extends Component {
    constructor(props) {
        super(props)
        this.state = {
            manual_id: '',
            blanco_id: '',
            addmanual: true,
            addnewmanual:this.props.AddManual,
        }
        this.handleChange = this.handleChange.bind(this);
        this.importBlanco = this.importBlanco.bind(this);
        this.updateManualId = this.updateManualId.bind(this);
    }

    componentDidMount() {
        var url = window.FETCH_MANUAL_NAMES;
        datasave.service(url, "GET")
            .then(response => {
              let result = response.filter(manual => (manual.corporate === 1 && CanPermissions('Show_corporatemanual')) || manual.corporate !== 1);
              if(localStorage.getItem('manual_id') !== null && result[0]['id'] !== localStorage.getItem('manual_id'))
              {
                defaultmanualid = result[0]['id'];
                this.setState({
                    manual_id: localStorage.getItem('manual_id') ,
                })
              }
              else{
                defaultmanualid = result[0]['id'];
                this.setState({
                    manual_id: result[0]['id'],
                    blanco_id: result[0]['blanco_id'],
                })
              }

            });
    }
    componentDidUpdate(prevProps, prevState) {

    }

    async updateManualId(id, random_num = 1) {
      if (id === '' || id === undefined || id === null){
        id = defaultmanualid;
      }
      localStorage.setItem('manual_id',id);
        this.setState({
            manual_id: id,
            random_num : random_num,
        })
    }
    handleChange(e) {
        var result = e.split('-');
        this.removeEditorFrame();
        localStorage.setItem('manual_id',result[0]);
        this.setState(  {
            manual_id: result[0],
            blanco_id: result[1],
        })
    }
    importBlanco(manual_id) {
        this.setState({
            manual_id: manual_id,
        })
    }
    removeEditorFrame() {
        document.getElementById('manualstructure').setAttribute("style", "display:block;");
        document.getElementById('fde-wrapper').setAttribute("class", "col-lg-8 col-md-8 float-left px-0 pt-0");
        document.getElementById('fde-wrapper').setAttribute("style", "display:none;");
    }

    render() {
      const accessToManuals = "Manual_management,E_manual,D_manual,R_manual,AIS_masterdata,AIS_masterdata,R_sandbox,E_sandbox,AIS_role_sandbox,PRIOR_sandbox,Archive_doc_in_sandbox,Preview_doc_in_sandbox";
          return (
            <Can
              perform = {accessToManuals}
              // perform = {window.ACCESS_MANUALMANAGEMENT}
              yes = {() => (
                <>
                    <ManualHeader manual_id={this.state.manual_id} random_num={this.state.random_num} handleChange={this.handleChange.bind(this)} />
                    {this.props.import &&
                        <Importblanco import={this.props.import} importBlanco={this.importBlanco.bind(this)} ></Importblanco>
                    }
                    <BlancoStructure manual_id={this.state.manual_id} blanco_id={this.state.blanco_id} updateManualId={this.updateManualId.bind(this)} addnewmanual={this.state.addnewmanual} docobj ={this.props.match !== undefined ? this.props.match.params.docobj:undefined}/>
                </>
              )}
              no = {() =>
                  <AccessDeniedPage />
              }
            />
          );
    }
}

export default ManualIndex
