import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Can from '../_components/CanComponent/Can'
import { CanPermissions } from '../_components/CanComponent/CanPermissions';

class ManualHeader extends Component {
    constructor(props) {
        super(props)
        this.state = {
            manual_list: [],
            manual_id: this.props.manual_id,
            handleChange: this.props.handleChange,
        }

    }
    componentDidMount() {
        var url = window.FETCH_MANUAL_NAMES;
        datasave.service(url, "GET")
            .then(result => {
                this.setState({
                    manual_list: result.filter(manual => (manual.corporate === 1 && CanPermissions('Show_corporatemanual')) || manual.corporate !== 1),
                })
            });
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.manual_id !== this.props.manual_id) {
          this.getManualList();
        }
        else if (prevProps.random_num !== this.props.random_num) {
          this.getManualList();
        }
    }

    getManualList = () => {
      var url = window.FETCH_MANUAL_NAMES;
      datasave.service(url, "GET")
          .then(result => {
              this.setState({
                  manual_list: result.filter(manual => (manual.corporate === 1 && CanPermissions('Show_corporatemanual')) || manual.corporate !== 1),
                  manual_id: this.props.manual_id,
              })
          });
    }

    render() {
        return (
            // <div className="container" >
            // <div className="">
            // <div className="row">
            //     <div className="container mt-3">
            //        <div className="col-md-6 manual-title-wrapper">
            //            <div className="manual-structure-name col-md-6">Manual Structure</div>
            //              <div className="col-md-6">
            //                <div className="col-md-10 ml-5 manual-structure-name-sandbox">
            //                  <i className="sprite-manual sprite-sandbox2x"></i><span>Manage Sandbox</span>
            //                </div>
            //              </div>
            //        </div>
            //     </div>
            //     </div>
            //     <div>
            // <div style={{ marginLeft: '4.4rem' }} id = "manual-list-wrapper" className="container input-padd">
            <Can
                perform="R_manual,E_manual,Manual_management,R_sandbox,E_sandbox,AIS_role_sandbox,PRIOR_sandbox,Archive_doc_in_sandbox,Preview_doc_in_sandbox"
                yes={() => (
                <div className="row" id="manual-list-wrapper-main">
                    <div style={{ visibility: 'hidden' }} className="col-md-1">
                        <p>welcome</p>
                    </div>
                    <div style={{ marginLeft: '-1.5rem' }} className='col md-11 col-lg-11 p-0' >
                        <div id="manual-list-wrapper" className=" input-padd">
                            <div style={{maxWidth: '35.6%'}} className="col-md-4 col-lg-4 manual-select input-padd">
                            <Can
                                perform="R_manual,E_manual,Manual_management"
                                yes={() => (
                                <reactbootstrap.Form.Control as="select" name="manual_id" className="selectpicker"
                                    value={this.state.manual_id + '-null'}
                                    onChange={e => this.props.handleChange(e.target.value)} >
                                    {this.state.manual_list.map(manuals =>
                                      <>
                                       {manuals.corporate === 1 &&
                                          <Can
                                              perform="Show_corporatemanual"
                                              yes={() => (
                                                <option value={manuals.id + '-' + manuals.blanco_id} >{manuals.name}</option>
                                              )}
                                          />
                                        }
                                        {manuals.corporate === 0 &&
                                          <option value={manuals.id + '-' + manuals.blanco_id} >{manuals.name}</option>
                                        }
                                      </>
                                    )}
                                </reactbootstrap.Form.Control>
                                )}
                              />
                            </div>
                        </div>
                    </div>
                </div>
              )}
            />

        );
    }
}

export default ManualHeader
// backup code
{/* <div className="container" >
            <div className="">
            <div className="row">
                <div className="container mt-3">
                   <div className="col-md-6 manual-title-wrapper">
                       <div className="manual-structure-name col-md-6">Manual structure</div>
                         <div className="col-md-6">
                           <div className="col-md-10 ml-5 manual-structure-name-sandbox">
                             <i className="sprite-manual sprite-sandbox2x"></i><span>Manage sandbox</span>
                           </div>
                         </div>
                   </div>
                </div>
                </div>
                <div>
                    <div className="container input-padd">
                        <div className="col-4 input-padd">
                            <reactbootstrap.Form.Control as="select" name="manual_id"
                                value={this.state.manual_id}
                                onChange={e => this.props.handleChange(e.target.value)} >
                                {this.state.manual_list.map(manuals => <option value={manuals.id + '-' + manuals.blanco_id} >{manuals.name}</option>)}
                            </reactbootstrap.Form.Control>
                        </div>
                    </div>
                </div>
            </div>
            </div> */}
