import React, { Component } from 'react';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import { translate } from './language';
import Can from './_components/CanComponent/Can';
import { PagePermissions } from './_components/CanComponent/PagePermissions';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';

class Ifo extends Component {
    constructor(props) {
        super(props)
        this.state = {
            createOrganisation: '',
            showerror: false,
            errors: [],
            t: props.t
        }
    }
    handleCreateOrganisation(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/organisation')

    }
    handleManageOrganisation(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/manageorganisations')
    }
    handleCreatePackage(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/packages')
    }
    handleManagePackage(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/managepackages')
    }
    handleCreateIndustries(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/sectors')
    }
    handleManageIndustries(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/managesectors')
    }
    handleImportUsers(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/importusers')
    }
    handleCreateGroup(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/groups')
    }
    handleManageGroups(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/managegroups')
    }
    handleCreateJob(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/jobs')
    }
    handleManageJobs(event) {
        event.preventDefault();
        const { history } = this.props
        history.push('/managejobs')
    }
    handleCreateDepartment(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/departments')
    }
    handleManageDepartments(event) {
        event.preventDefault();
        const { history } = this.props
        history.push('/managedepartments')
    }
    handleCreateRole(event) {
        event.preventDefault();
        const { history } = this.props
        history.push('/roles')
    }
    handleManageRoles(event) {
        event.preventDefault();
        const { history } = this.props
        history.push('/manageroles')
    }
    handleCreatePerson(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/persons')
    }
    handleMangePersons(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/managepersons')
    }
    handleCreateTemplates(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/templates')
    }
    handleManageTemplates(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/managetemplates')
    }
    handleCreateLayout(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/layouts')
    }
    handleManageLayout(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/managelayouts')
    }
    handleCreateBlanco(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/create-blanco')
    }
    handleOptionsTab(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/Settings')
    }
    handleManageStrings(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/managestrings')
    }
    handleManageMasterData(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/manage-master-data')
    }
    handleManageBlanco(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/manage-blanco')
    }
    handleGridTab(e) {
        e.preventDefault()
        this.props.history.push('/grids')
    }
    handleGridDisplay(e) {
        e.preventDefault();
        this.props.history.push('/griddisplayview');
    }
    handleSiteTab(e) {
        e.preventDefault()
        this.props.history.push('/site')
    }
    handleLanguage(e) {
        e.preventDefault()
        this.props.history.push('/language')
    }
    handleManageSpace() {
        this.props.history.push('/manage-spaces')
    }
    handleManageLanguage(e) {
        e.preventDefault()
        this.props.history.push('/managelanguage')
    }
    handleWelcomeNote(e) {
        e.preventDefault()
        this.props.history.push('/insertdata')
    }
    handleManageWelcomeNote(e) {
        e.preventDefault()
        this.props.history.push('/datasaved')
    }
    handleMaster(e) {
        e.preventDefault()
        this.props.history.push('/FrameMasterData')
    }

    classes_lg = {
        'lg': "col-lg-4"
    }
    handleEmailOverview(e) {
        e.preventDefault()
        this.props.history.push('/emailoverview')
    }
    handleEmail(e) {
        e.preventDefault()
        this.props.history.push('/email')
    }
    handleDashboard(e) {
        e.preventDefault()
        this.props.history.push('/listDashboards')
    }
    handleManageSite(e) {
        e.preventDefault()
        this.props.history.push('/managesite')
    }
    handleActiveDirectory(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/activedirectory-users')
    }
    handleTableContent(e) {
        e.preventDefault()
        this.props.history.push('/tablecontentform')
    }
    handleStatus(e) {
        e.preventDefault()
        this.props.history.push('/status')

    }
    handleLayoutsTemplates(event) {
        event.preventDefault()
        const { history } = this.props
        history.push('/manage-layouts-templates')
    }
    handleGridLists(e) {
        e.preventDefault()
        this.props.history.push('/listGrids')
    }
    handleObjects(e) {
        e.preventDefault()
        this.props.history.push('/objects')
    }
    handleShouts(e) {
        e.preventDefault()
        this.props.history.push('/shoutsmanager')
    }
    handlesTagDocsOverview(e) {
      e.preventDefault()
      this.props.history.push('/tagsdocsoverview')
    }
    handlesDocsTagsOverview(e) {
      e.preventDefault()
      this.props.history.push('/docstagsoverview')
    }
    handlesStandardsDocsOverview(e) {
      e.preventDefault()
      this.props.history.push('/standardsdocsoverview')
    }
    handlesDocsStandardsOverview(e) {
      e.preventDefault()
      this.props.history.push('/docsstandardsoverview')
    }
    handlesSpceDocsOverview(e) {
      e.preventDefault()
      this.props.history.push('/spacedocsoverview')
    }
    handlesDocsSpaceOverview(e) {
      e.preventDefault()
      this.props.history.push('/docsspacesoverview')
    }
    handleComments(e) {
        e.preventDefault()
        this.props.history.push('/commentsoverview')
      }
      handleSignature(e) {
        e.preventDefault()
        this.props.history.push('/signature_pad')
      }
      
    
    render() {
        const as4_or_site = PagePermissions()
        const { t } = this.state;

        return (
            <div className="container py-4">
                <div className="row justify-content-center">
                    <div className="col-md-9">
                        <div className="card">
                            <div className="card-header">IFO</div>
                            <Container className="p-5">
                                <Form class="row">
                                    <div class="row">
                                        <div class={this.classes_lg.lg}>
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_organisation"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleCreateOrganisation.bind(this)} color="primary">{t('Create organisation')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="E_organisation,R_organisation,D_organisation"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleManageOrganisation.bind(this)} color="primary">{t('Manage organisations')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_package"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleCreatePackage.bind(this)} color="primary">{t('Create package')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="E_package,R_package,D_package"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleManagePackage.bind(this)} color="primary">{t('Manage packages')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_sector"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleCreateIndustries.bind(this)} color="primary">{t('Create sector')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_sector,R_sector,D_sector"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleManageIndustries.bind(this)} color="primary">{t('Manage sectors')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            <Can
                                                perform="IMU_ext"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleImportUsers.bind(this)} color="primary">{t('Import users')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="C_group"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleCreateGroup.bind(this)} color="primary">{t('Create group')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="E_group,R_group,D_group"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleManageGroups.bind(this)} color="primary">{t('Manage groups')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="C_job"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleCreateJob.bind(this)} color="primary">{t('Create job')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="E_job,R_job,D_job"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleManageJobs.bind(this)} color="primary">{t('Manage jobs')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="C_department"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleCreateDepartment.bind(this)} color="primary">{t('Create department')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="E_department,R_department,D_department"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleManageDepartments.bind(this)} color="primary">{t('Manage departments')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="C_role"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleCreateRole.bind(this)} color="primary">{t('Create default role')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                        </div>
                                        <div class={this.classes_lg.lg}>
                                            <Can
                                                perform="E_role,R_role,D_role"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12" >
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleManageRoles.bind(this)} color="primary">{t('Manage roles')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="C_user"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleCreatePerson.bind(this)} color="primary">{t('Create person')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="E_user,R_user,D_user"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleMangePersons.bind(this)} color="primary">{t('Manage persons')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_template"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleCreateTemplates.bind(this)} color="primary">{t('Create template')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="E_template,R_template,D_template"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleManageTemplates.bind(this)} color="primary">{t('Manage templates')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_department"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleCreateBlanco.bind(this)} color="primary">{t('Create blanco database')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                        </div>
                                        <div class={this.classes_lg.lg}>
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_blanco"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleManageBlanco.bind(this)} color="primary">{t('Manage blanco')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_layout"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleCreateLayout.bind(this)} color="primary">{t('Create layout')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="E_layout,R_layout,D_layout"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleManageLayout.bind(this)} color="primary">{t('Manage layouts')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="E_settings,R_settings"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleOptionsTab.bind(this)} color="primary">{t('Settings')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            <Can
                                                perform="E_space,R_space,D_space"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={() => this.handleManageSpace()} color="primary">{t('Manage spaces')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            {as4_or_site &&
                                                <Can
                                                    perform="R_lang_interface"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleManageStrings.bind(this)} color="primary">{t('Manage strings')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            <Can
                                                perform="E_masterdata,R_masterdata,D_masterdata"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleManageMasterData.bind(this)} color="primary">{t('Manage Master data')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            {/* {as4_or_site && */}
                                                <Can
                                                    perform="C_grid"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleGridTab.bind(this)} color="primary">{t('Add Grid')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            {/* } */}
                                            <Can
                                                perform="C_grid,C_grid_template,R_grid_template,E_grid_template"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleGridDisplay.bind(this)} color="primary">{t('Grid Display')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="C_welcomnote"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleWelcomeNote.bind(this)} color="primary">{t('Welcome Note')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="E_welcomnote"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div>
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleManageWelcomeNote.bind(this)} color="primary">{t('Manage WelcomeNote')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="C_site"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div className="col-lg-12">
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleSiteTab.bind(this)} color="primary">{t('Create Site')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <Can
                                                perform="E_site,R_site,D_site"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div>
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleManageSite.bind(this)} color="primary">{t('Manage Site')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_language"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleLanguage.bind(this)} color="primary">{t('Create language')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="E_language,R_language,D_language"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleManageLanguage.bind(this)} color="primary">{t('Manage language')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_email"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleEmail.bind(this)} color="primary">{t('Email')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            {as4_or_site &&
                                                <Can
                                                    perform="C_email_template,R_email_template,E_email_template"
                                                    yes={() => (
                                                        <FormGroup>
                                                            <div className="col-lg-12">
                                                                <Button className="btn btn-primary" type="submit" onClick={this.handleEmailOverview.bind(this)} color="primary">{t('Email overview')}</Button>
                                                            </div>
                                                        </FormGroup>
                                                    )}
                                                />
                                            }
                                            <Can
                                                perform="C_dashboard,R_dashboard,E_dashboard,D_dashboard,Clone_dashboard,C_tile"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div>
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleDashboard.bind(this)} color="primary">{t('Dashboard')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />

                                            <Can
                                                perform="C_TOC"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div>
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleTableContent.bind(this)} color="primary">{t('Table of contents')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <FormGroup>
                                                <div>
                                                    <Button className="btn btn-primary" type="submit" onClick={this.handleStatus.bind(this)} color="primary">{t('Status')}</Button>
                                                </div>
                                            </FormGroup>
                                            <FormGroup>

                                                <div className="col-lg-8">
                                                    <Button className="btn btn-primary" type="submit" onClick={this.handleLayoutsTemplates.bind(this)} color="primary">{t('Manage Layouts Templates')}</Button>
                                                </div>

                                            </FormGroup>
                                            <FormGroup>
                                                <div>
                                                    <Button className="btn btn-primary" type="submit" onClick={this.handleActiveDirectory.bind(this)} color="primary">{t('Active Directory Users')}</Button>
                                                </div>
                                            </FormGroup>
                                            <FormGroup>
                                                <div>
                                                    <Button className="btn btn-primary" type="submit" onClick={this.handleObjects.bind(this)} color="primary">{t('Objects')}</Button>
                                                </div>
                                            </FormGroup>
                                            <FormGroup>

                                                <div className="col-lg-8">
                                                    <Button className="btn btn-primary" type="submit" onClick={this.handlesTagDocsOverview.bind(this)} color="primary">{t('Docs & tags')}</Button>
                                                </div>

                                            </FormGroup>
                                            <FormGroup>

                                                <div className="col-lg-8">
                                                    <Button className="btn btn-primary" type="submit" onClick={this.handlesStandardsDocsOverview.bind(this)} color="primary">{t('Docs & standards')}</Button>
                                                </div>
                                            </FormGroup>
                                            <FormGroup>

                                                <div className="col-lg-8">
                                                    <Button className="btn btn-primary" type="submit" onClick={this.handlesSpceDocsOverview.bind(this)} color="primary">{t('Docs & spaces')}</Button>
                                                </div>

                                            </FormGroup>
                                            <Can
                                                perform="ADD_shoutboard,R_shout,E_shout,D_shout"
                                                yes={() => (
                                                    <FormGroup>
                                                        <div>
                                                            <Button className="btn btn-primary" type="submit" onClick={this.handleShouts.bind(this)} color="primary">{t('Shouts')}</Button>
                                                        </div>
                                                    </FormGroup>
                                                )}
                                            />
                                            <FormGroup>
                                            <div className="col-lg-8">
                                                <Button className="btn btn-primary" type="submit" onClick={this.handleComments.bind(this)} color="primary">{t('Comments')}</Button>
                                            </div>
                                            </FormGroup>
                                            <FormGroup>
                                            <div className="col-lg-8">
                                                <Button className="btn btn-primary" type="submit" onClick={this.handleSignature.bind(this)} color="primary">{t('signature pad')}</Button>
                                            </div>
                                            </FormGroup>
                                        </div>
                                    </div>
                                </Form>
                            </Container>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

// /tags
export default translate(Ifo)
