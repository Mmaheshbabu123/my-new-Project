import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import './Sectors.css';
import { datasave } from './_services/db_services';
import Can from './_components/CanComponent/Can';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import {PagePermissions} from './_components/CanComponent/PagePermissions';
import Pagination from 'react-bootstrap/Pagination';
import {translate} from './language';
import './industriesList.css';

class IndustriesList extends Component {
  constructor(props) {
    super(props)
    this.state = {
      industries: [],
      industry:[],
      result: '',
      parentsData:[],
      items:[],
      searchTerm:'',
      id:'',
      page: 5,
      count: 0,
      active: 1,
      filterFullList:[],
      t:props.t,
    }
    this.searchData = this.searchData.bind(this);
  }

  componentDidMount() {
    var url = window.sectorslist;
    datasave.service(url, "GET")
      .then(response => {
        var tempArr = [];
        Object.keys(response).map((item, i) => (
          // tempArr.push(response[item])
          tempArr.push(response[item])

        ))
        const pageData = this.getPageData(1, tempArr);
        const count = this.getCountPage(tempArr);

        this.setState({
          industries: response,
          industry:tempArr,
          parentsData:tempArr,
          count:count,
          items:pageData,
        })
      })
  }
  componentDidUpdate(prevProps, prevState) {
      if (prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
          datasave.service(window.sectorslist, 'GET', '')
              .then(response => {
                  const pageData = this.getPageData(this.state.active, this.state.tempArr);
                  const count = this.getCountPage(this.state.tempArr);
                  this.setState({
                      industries: response,
                      industry:this.state.tempArr,
                      items :pageData,
                      count: count,
                  })
              });
      }
  }
  getCountPage(items) {
      const itemLength = items.length;
      return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }
  componentWillMount() {
      this.setState({ items: this.state.industry })
  }
  searchData(e) {
      var list = [...this.state.industry];
      list = list.filter(function (item) {
          if (item.parent.name !== null) {
              return item.parent.name.toLowerCase().search(
                  e.target.value.toLowerCase()) !== -1;
          }
          // else if (item.name !== null) {
          //     return item.name.toLowerCase().search(
          //         e.target.value.toLowerCase()) !== -1;
          // }
      });
      const page_data = this.getPageData(1, list);
      const count = this.getCountPage(list);
      this.setState({
          items: page_data,
          count: count,
          active: 1,
          searchTerm: e.target.value,
          filterFullList: list,
      });

  }
  changePage(e, id = 1) {
      const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
      const page_data = this.getPageData(id, list);
      this.setState({
          items : page_data,
          active: id,
      });
  }
  getPageData(id, list = '') {
      const page = this.state.page;
      const items = (list !== '') ? list : this.state.industry;
      const page_data = items.slice(page * (id - 1), page * id);
      return page_data;
  }

  handleDelete(id, e) {

    var url = window.DELETE_ITEM + id;

    const details = {
      table: window.industries_table,
    }
    datasave.service(url, 'PUT', details)
      .then(response => {
        if (response === 1) {
          window.location.reload()
        }
      })
      .catch(error => {
        this.setState({
          errors: error.response.data.errors
        })
      })

  }

  render() {
    const as4_or_site = PagePermissions()
    const { industries,t } = this.state
    const result = Object.values(industries);

    result.map(function (details) {
      Object.values(Object.values(details.child)).map(function (subdetails) {
        return details;
      }, this);
      return details;
    }, this)


      const filtered = this.state.items;
      let active = this.state.active;
      let pages = [];

      if(this.state.count > 0)
      {
          for (let number = 1; number <= this.state.count; number++) {
              pages.push(
                  <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                      {number}
                  </Pagination.Item>,
              );
          }
      }

      if (as4_or_site) {
      return (
        <div className=" row col-md-12">
            <div style={{visibility: 'hidden'}} className="col-md-1"><p>welcome</p></div>
            <div className='col-md-11' >
        <Can
          perform = "E_sector,D_sector,R_sector"
          yes = {() => (

            <div className=''>
              <div className='col-md-12 p-0 mt-5 mb-5'>
                <div className='card'>
                  <div className='card-header'>{t('All sectors')}</div>
                  <div className='card-body industries'>
                  <input  className="form-control search-box-border col-md-4 mb-2" placeholder={t("Search")} onChange={this.searchData} /><br />
                  <div style={{}}>
                  <reactbootstrap.Table  className="site-table-main" >
                      <thead>
                        <tr>
                          <th>{t('Name of sector')}</th>
                          <th style={{textAlign: 'right', paddingRight: '1.5rem'}} colspan="2">{t('Actions')}</th>
                        </tr>
                      </thead>
                      {filtered.map(details => (
                        <tbody>
                           <tr style={{ borderBottom: '1px solid #dee2e6' }}>
                            <td>
                              {details.parent.name}
                            </td>
                            <td style={{ display: 'flex', float: 'right', border: '0px' }}>


                              <Can
                                perform="E_sector"
                                yes={() => (

                                  <Link style={{ float: 'right', padding: '10px' }}
                                    to={`/sectors/${details.parent.id}`}
                                    key={details.parent.id}
                                  >
                                    {/* {t('Edit')} */}
                                    <i title="Edit" class="overall-sprite overall-sprite-myeditc"></i>
                                  </Link>

                              )}
                              />

                              <br></br>

                              <Can
                                perform="D_sector"
                                yes={() => (

                                  <a  style={{ float: 'right', padding: '10px' }} href='#'
                                    onClick={this.handleDelete.bind(this, details.parent.id)}
                                  >
                                    {/* {t('Delete')} */}
                                    <i title="Delete" class="overall-sprite overall-sprite-mtdeletec"></i>
                                  </a>

                              )}
                              />

                            </td>
                          </tr>
                          {Object.values(Object.values(details.child)).map(subdetails => (
                            <tr style={{ borderBottom: '1px solid #dee2e6' }}>
                              <td className='child'>
                                {subdetails.name}
                              </td>
                              <td style={{ display: 'flex', float: 'right', border: '0px' }}>

                              <Can
                                perform="E_sector"
                                yes={() => (
                                  <Link style={{ float: 'right', padding: '10px' }}
                                    to={`/sectors/${subdetails.id}`}
                                    key={subdetails.id}
                                  >
                                    {/* {t('Edit')} */}
                                    <i title="Edit" class="overall-sprite overall-sprite-myeditc"></i>
                                  </Link>
                              )}
                              />

                                <br></br>

                              <Can
                                perform="D_sector"
                                yes={() => (
                                  <a style={{ float: 'right', padding: '10px' }} href='#'
                                  onClick={this.handleDelete.bind(this, subdetails.id)}
                                >
                                  {/* {t('Delete')} */}
                                  <i title="Delete" class="overall-sprite overall-sprite-mtdeletec"></i>
                                </a>
                                )}
                                />

                              </td>
                            </tr>
                          ))}
                        </tbody>
                      ))}
                    </reactbootstrap.Table>
                    </div>
                  </div>
                  {/* <div className="ml-3">
                  <Pagination size="md">{pages}</Pagination>
                  </div> */}
                  <div className="page-nation-sec col-md-12">
                        <Pagination style={{width: '500px',overflow: 'auto',scrollbarWidth: 'thin'}} size="md">{pages}</Pagination>
                        </div>
                </div>
              </div>
            </div>

          )}
          no = {() =>
            <AccessDeniedPage/>
          }
        />
        </div>
        </div>
      );
    }
    else {
      return(
          <AccessDeniedPage />
      )
    }
  }

}

export default translate(IndustriesList)


{/* <i class="overall-sprite overall-sprite-mtdeletec"></i>
<i class="delete-edit delete-edit-deletemc"></i>
<i class="overall-sprite overall-sprite-myeditc"></i>
<i class="delete-edit delete-edit-editmc"></i> */}








// import React, { Component } from 'react'
// import { Link } from 'react-router-dom'
// import * as reactbootstrap from 'react-bootstrap';
// import './Sectors.css';
// import { datasave } from './_services/db_services';
// import Can from './_components/CanComponent/Can';
// import AccessDeniedPage from './_components/Errorpages/AccessDenied';
// import {PagePermissions} from './_components/CanComponent/PagePermissions';
// import Pagination from 'react-bootstrap/Pagination';
//
// class IndustriesList extends Component {
//   constructor() {
//     super()
//     this.state = {
//       industries: [],
//       result: '',
//       items:[],
//       searchTerm:'',
//       id:'',
//       page: 5,
//       count: 0,
//       active: 1,
//       filterFullList:[],
//     }
//     this.searchData = this.searchData.bind(this);
//   }
//
//   componentDidMount() {
//     var url = window.sectorslist;
//     datasave.service(url, "GET")
//       .then(response => {
//         const pageData = this.getPageData(1, response);
//         const count = this.getCountPage(response);
//         this.setState({
//           industries: response,
//           count: count,
//           items : pageData,
//
//         })
//       })
//   }
//   componentDidUpdate(prevProps, prevState) {
//       if (prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
//           datasave.service(window.sectorslist, 'GET', '')
//               .then(response => {
//                   const pageData = this.getPageData(this.state.active, response);
//                   const count = this.getCountPage(response);
//                   this.setState({
//                       industries: response,
//                       items :pageData,
//                       count: count,
//                   })
//               });
//       }
//   }
//   getCountPage(items) {
//       const itemLength = items.length;
//       return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
//   }
//   componentWillMount() {
//       this.setState({ items: this.state.industries })
//   }
//   searchData(e) {
//       var list = [...this.state.industries];
//       list = list.filter(function (item) {
//           if (item.name !== null) {
//               return item.name.toLowerCase().search(
//                   e.target.value.toLowerCase()) !== -1;
//           }
//       });
//       const page_data = this.getPageData(1, list);
//       const count = this.getCountPage(list);
//       this.setState({
//           items: page_data,
//           count: count,
//           active: 1,
//           searchTerm: e.target.value,
//           filterFullList: list,
//       });
//
//   }
//   changePage(e, id = 1) {
//       const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
//       const page_data = this.getPageData(id, list);
//       this.setState({
//           items : page_data,
//           active: id,
//       });
//   }
//   getPageData(id, list = '') {
//       const page = this.state.page;
//       const items = (list !== '') ? list : this.state.industries;
//       const page_data = items.slice(page * (id - 1), page * id);
//       return page_data;
//   }
//
//   handleDelete(id, e) {
//
//     var url = window.DELETE_ITEM + id;
//     const details = {
//       table: window.industries_table,
//     }
//     datasave.service(url, 'PUT', details)
//       .then(response => {
//         if (response === 1) {
//           window.location.reload()
//         }
//       })
//       .catch(error => {
//         this.setState({
//           errors: error.response.data.errors
//         })
//       })
//
//   }
//
//   render() {
//     const as4_or_site = PagePermissions()
//     const { industries } = this.state
//     const filtered = this.state.items;
//     let active = this.state.active;
//     let pages = [];
//     if(this.state.count > 0)
//     {
//         for (let number = 1; number <= this.state.count; number++) {
//             pages.push(
//                 <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
//                     {number}
//                 </Pagination.Item>,
//             );
//         }
//     }
//     const result = Object.values(industries);
//
//     result.map(function (details) {
//       Object.values(Object.values(details.child)).map(function (subdetails) {
//         return details;
//       }, this);
//       return details;
//     }, this)
//
//     if (as4_or_site) {
//
//       return (
//         <Can
//           perform = "E_sector,D_sector,R_sector"
//           yes = {() => (
//           <div className='container py-4'>
//             <div className='row justify-content-center'>
//               <div className='col-md-9'>
//                 <div className='card'>
//                   <div className='card-header'>All sectors</div>
//                   <div className='card-body industries'>
//                     <reactbootstrap.Table responsive>
//                       <thead>
//                         <tr>
//                           <th>Name of sector</th>
//                           <th colspan="2">Actions</th>
//                         </tr>
//                       </thead>
//                       {result.map(details => (
//                         <tbody>
//                           <tr>
//                             <td>
//                               {details.parent.name}
//                             </td>
//                             <td>
//                               <Can
//                                 perform="E_sector"
//                                 yes={() => (
//                                   <Link
//                                     to={`/sectors/${details.parent.id}`}
//                                     key={details.parent.id}
//                                   >
//                                     Edit
//                                   </Link>
//                               )}
//                               />
//                               <br></br>
//                               <Can
//                                 perform="D_sector"
//                                 yes={() => (
//                                   <a href='#'
//                                     onClick={this.handleDelete.bind(this, details.parent.id)}
//                                   >
//                                     Delete
//                                   </a>
//                               )}
//                               />
//                             </td>
//                           </tr>
//                           {Object.values(Object.values(details.child)).map(subdetails => (
//                             <tr>
//                               <td className='child'>
//                                 {subdetails.name}
//                               </td>
//                               <td>
//                               <Can
//                                 perform="E_sector"
//                                 yes={() => (
//                                   <Link
//                                     to={`/sectors/${subdetails.id}`}
//                                     key={subdetails.id}
//                                   >
//                                     Edit
//                                   </Link>
//                               )}
//                               />
//                                 <br></br>
//                               <Can
//                                 perform="D_sector"
//                                 yes={() => (
//                                 <a href='#'
//                                   onClick={this.handleDelete.bind(this, subdetails.id)}
//                                 >
//                                   Delete
//                                 </a>
//                                 )}
//                                 />
//                               </td>
//                             </tr>
//                           ))}
//                         </tbody>
//                       ))}
//                     </reactbootstrap.Table>
//                   </div>
//                   <Pagination size="md">{pages}</Pagination>
//                 </div>
//               </div>
//             </div>
//           </div>
//           )}
//           no = {() =>
//             <AccessDeniedPage/>
//           }
//         />
//       );
//     }
//   }
//
// }
//
// export default IndustriesList
