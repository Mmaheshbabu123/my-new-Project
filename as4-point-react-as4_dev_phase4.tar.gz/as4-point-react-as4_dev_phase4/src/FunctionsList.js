import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from './_services/db_services';
import { translate } from './language';

class FunctionsList extends Component {
  constructor(props) {
    super(props)
    this.state = {
      functions: [],
      t:props.t,
    }
  }
  componentDidMount() {
    var functions = window.MANAGEFUNCTIONS;
      datasave.service(functions, "GET")
        .then(response => {
          this.setState({
            functions: response.allfunctions
          })
        })
  }

  handleDetails(id) {
    var functions = window.DELETE_FUNCTION + '/' + id;
      datasave.service(functions, "PUT")
        .then(response => {
          if (response == 'Success') {
            window.location.reload();
          }
        })
  }

  render() {
    const { functions,t } = this.state
    return (
      <div className='container py-4'>
        <div className='row justify-content-center'>
          <div className='col-md-8'>
            <div className='card'>
              <div className='card-header'>{t('All functions')}</div>
              <div className='card-body'>
                <reactbootstrap.Table responsive>
                  <thead>
                    <tr>
                      <th>{t('Name of function')}</th>
                      <th colspan="2">{t('Actions')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {functions.map(functionItem => (
                      <tr>
                        <td>
                          {functionItem.name}
                        </td>
                        <td>
                          <Link
                            className='list-group-item list-group-item-action d-flex justify-content-between align-items-center'
                            to={`/functions/${functionItem.function_id}`}
                            key={functionItem.function_id}
                          >
                            {t('Edit')}
                        </Link>
                        </td>
                        <td>
                          <a href='#'
                              onClick={(e) => this.handleDetails(functionItem.function_id)}>
                              {t('Delete')}
                          </a>
                          </td>
                      </tr>
                    ))}
                  </tbody>
                </reactbootstrap.Table>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default translate(FunctionsList)
