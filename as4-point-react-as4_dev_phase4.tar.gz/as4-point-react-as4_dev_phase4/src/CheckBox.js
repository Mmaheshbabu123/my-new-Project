import React from 'react';
import './DragnDrop.css';
import question from './Webforms/Simulation/Webelements/question.png';

export default function CheckBox({keyvalue, name, value, tick, classification, onCheck, id = "", disabled = "",approvalcycle_disabled,category, customStyle = {}}) {
  var show = false;
   if((parseInt(keyvalue) <= 8 && category === 'persons') || category !== 'persons') {
     show = true;
   }
   // if(category === 'persons'){
   //
   // }
      let styles_id = {};
      if (classification === 'verify_select_all' || classification === 'authorise_select_all') {
        styles_id = {
          display: 'flex',
          justifyContent: 'center',
        };
      }
      else {
        styles_id = {};
      }
      return (
        <>
        { show &&

          <label style={{...styles_id, ...customStyle}} className = "col-md-12 mt-2" id={classification}>
              <input
                  name={classification}
                  type="checkbox"
                  value={value}
                  checked={tick || false}
                  onChange={onCheck}
                  key={keyvalue}
                  disabled = {disabled ||approvalcycle_disabled}
                  id = {id}
                  style={{marginRight: '10px',opacity: '0'}}
              />
              <div className="check-approval mt-1">
                 <div className="inside"></div>
              </div>
              {name}
              {classification === 'na' && <img src= {question} style={{ width: '25px',marginLeft:'3px' }} title={('"Adds the option "Not applicable" in the list. This has an impact on the score calculation."')} />}
          </label>}
          </>


      );
  }
