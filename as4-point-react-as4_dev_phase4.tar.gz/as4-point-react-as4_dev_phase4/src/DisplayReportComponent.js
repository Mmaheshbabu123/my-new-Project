import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from './_services/db_services';
import Can from './_components/CanComponent/Can';
import { translate } from './language';
import { OCAlert } from '@opuscapita/react-alerts';

import DocumentManageList from '../src/Reports/DocumentMangeList';
import TodoDocStatus from '../src/Reports/TodoDocStatus';
import DocumentStatusAll from '../src/Reports/DocumentStatusAll';
import TodoStatusDueDate from '../src/Reports/TodoStatusDueDate';
import ReadUnderstandDue from '../src/Reports/ReadUnderstandDue';
import ReadUnderstandStatus from '../src/Reports/ReadUnderstandStatus';

import Grafiektitel from '../src/Reports/Grafiektitel';
import ReviewDueDate from '../src/Reports/ReviewDueDate';
import ReviewDoc from '../src/Reports/ReviewDoc';
import TodoAllDoc from '../src/Reports/TodoAllDoc'
import GrafiekDoc from '../src/Reports/GrafiekDoc';
import GrafiekReadUn from '../src/Reports/GrafiekReadUn';
import IntiatedTodo from '../src/Reports/IntiatedTodo';
import TotalAndRejTodo from '../src/Reports/TotalAndRejTodo';
import GrafiekOpenTodos from '../src/Reports/GrafiekOpenTodos';
import GrafiekAverageDue from '../src/Reports/GrafiekAverageDue';
import LayoutConBothRej from '../src/Reports/LayoutConBothRej';
import OpenTodoAmountDue from '../src/Reports/OpenTodoAmountDue';
import LeadTimeView from '../src/Reports/LeadTimeView';
import RejectionReason from '../src/Reports/RejectionReason';
class DisplayReportComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
        }
    }
    displayReport() {
        let table = [];
        let rkey = parseInt(this.props.rkey);
        if (rkey != undefined) {
            switch (rkey) {
                case 1:
                    table.push(<DocumentManageList history={this.props.history} />);
                    break;
                case 2:
                    table.push(<TodoDocStatus history={this.props.history} />);
                    break;
                case 3:
                    table.push(<DocumentStatusAll history={this.props.history} />);
                    break;
                case 4:
                    table.push(<TodoStatusDueDate history={this.props.history} />);
                    break;
                case 5:
                    table.push(<ReadUnderstandDue history={this.props.history} />);
                    break;
                case 6:
                    table.push(<ReadUnderstandStatus history={this.props.history} />);
                    break;
                case 7:
                    table.push(<Grafiektitel history={this.props.history} />);
                    break;
                case 8:
                    table.push(<ReviewDueDate history={this.props.history} />);
                    break;
                case 9:
                    table.push(<ReviewDoc history={this.props.history} />);
                    break;
                case 10:
                    table.push(<TodoAllDoc history={this.props.history} />);
                    break;
                case 11:
                    table.push(<GrafiekDoc history={this.props.history} />);
                    break;
                case 12:
                    table.push(<GrafiekReadUn history={this.props.history} />);
                    break;
                case 13:
                    table.push(<IntiatedTodo />);
                    break;
                case 14:
                    table.push(<TotalAndRejTodo />);
                    break;
                case 15:
                    table.push(<GrafiekOpenTodos />);
                    break;
                case 16:
                    table.push(<GrafiekAverageDue />);
                    break;
                case 17:
                    table.push(<LayoutConBothRej history={this.props.history} />);
                    break;
                case 18:
                    table.push(<OpenTodoAmountDue />);
                    break;
                case 19:
                    table.push(<LeadTimeView />);
                    break;
                case 20:
                    table.push(<RejectionReason />);
                    break;
                default:

                    alert(this.state.rkey);
                    break;
            }
            return table;
        }
    }


    render() {
        return <div className="container p-5">
            <>{this.displayReport()}</>
        </div>
    }
}
export default DisplayReportComponent;
