import React, { Component } from "react";
import { Link } from "react-router-dom";
import * as reactbootstrap from "react-bootstrap";
import Pagination from "react-bootstrap/Pagination";
import "./Organisations.css";
import { datasave } from "./_services/db_services";
import Can from "./_components/CanComponent/Can";
import AccessDeniedPage from "./_components/Errorpages/AccessDenied";
import { translate } from "./language";
import { OCAlert } from '@opuscapita/react-alerts';
import "./PersonsList.css";
import { persistor, store } from './store';
import { userService } from './_services/user.services';
import { Button, Form, FormGroup, InputGroup } from 'react-bootstrap'
import MultiSelect from './_components/MultiSelect';
import Persons from './Persons';
import { Router } from 'react-router';
import { createBrowserHistory } from 'history';
import { PrivateRoute } from './_components/PrivateRoute';
import ImportUsers from './ImportUsers';
import Userlogdetails from './_components/Userlogdetails';
import {CanPermissions} from './_components/CanComponent/CanPermissions';
import InactivePopup from './InactivePopup';


const history = createBrowserHistory();

class PersonsList extends Component {
  constructor(props) {
    super(props);
    let userData = store.getState();
    this.state = {
      person: [],
      persondetails: [],
      tabs: {
        Active: props.t("Active persons"),
        Archived: props.t("Inactive persons")
      },
      persons: {
        Active: [],
        Archived: []
      },
      activekey: "Active",
      show: false,
      delid: "",
      sucess: "",
      currentPage: 1,
      del_id: 1,
      todosPerPage: 5,
      count: "",
      links: "",
      nolinks: "",
      items: [],
      searchTerm: { Active: "", Archived: "" },
      id: "",
      page: 10,
      count: 0,
      active: { Active: 1, Archived: 1 },
      filterFullList: { Active: [], Archived: [] },
      getpersonsUrl: window.GET_Active_nd_Archive,
      changePersonStatusUrl: window.CHANGE_STATUS,
      // redirect:this.props.handleSelect('/managemyorganisation/createperson'),
      t: props.t,
      pid: "",
      deleteid: "",
      showChangeUserPopup: false,
      activeUsers: [],
      selectedUser: [],
      activityPersonId: null,
      activityPersonStatus : null,
      logedinRoleId: userData.UserData.user_details.role_id,
      as4PersonOrNot: 0,
      mainkey : (CanPermissions("E_user,R_user,D_user,active_person,inactive_person", "") === true) ? 1 : ((CanPermissions("IMU_ext", "") === true) ? 3 : 4),
      personId : 0,
      showActivePopup: false,
      statusId: 0,
    };
    this.handle_activities = this.handle_activities.bind(this);
    this.searchData = this.searchData.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.handleMainTabSelect = this.handleMainTabSelect.bind(this);
    this.closePopUp = this.closePopUp.bind(this);
  }

  componentDidMount() {
    let rolesURL = window.USERROLES + '/' + this.state.logedinRoleId;
    datasave.service(rolesURL, "GET")
      .then(response => {
        this.setState({
          as4PersonOrNot: response[0] ?  response[0]['as4member'] : 0,
        })
      })

    var url = this.state.getpersonsUrl + window.persons_table;
    datasave.service(url, "GET").then(response => {
      let pageData = {};
      let count = [];
      pageData = {
        Active: this.getPageData(1, response["Active"]),
        Archived: this.getPageData(1, response["Archived"])
      };
      count = {
        Active: this.getCountPage(response["Active"]),
        Archived: this.getCountPage(response["Archived"])
      };
      this.setState({
        person: response,
        count: count,
        items: pageData
      });
    });
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.deleteid !== this.state.deleteid || prevState.pid !== this.state.pid) {
      datasave.service(this.state.getpersonsUrl + window.persons_table, "GET", "")
        .then(response => {
          let pageData = {},
            count = {};
          pageData = {
            Active: this.getPageData(1, response["Active"]),
            Archived: this.getPageData(1, response["Archived"])
          };
          count = {
            Active: this.getCountPage(response["Active"]),
            Archived: this.getCountPage(response["Archived"])
          };
          this.setState({
            person: response,
            items: pageData,
            count: count,
            // delid: "",
            pid:""
          });
        });

    }
  }
  getCountPage(items) {
    const itemLength = items.length;
    return itemLength > this.state.page
      ? Math.ceil(itemLength / this.state.page)
      : 0;
  }
  searchData(e) {
    var list = this.state.person[this.state.activekey];
    list = list.filter(function(item) {
      if (item.name !== null) {
        return (
          item.name.toLowerCase().search(e.target.value.toLowerCase()) !== -1
        );
      }
    });
    const page_data = this.getPageData(1, list);
    const count = this.getCountPage(list);
    let prevPageid = this.state.active;
    prevPageid[this.state.activekey] = 1;
    let prevPageItems = this.state.items;
    prevPageItems[this.state.activekey] = page_data;
    let prevPageCount = this.state.count;
    prevPageCount[this.state.activekey] = count;
    let prevSearch = this.state.searchTerm;
    prevSearch[this.state.activekey] = e.target.value;
    let prevSearchList = this.state.filterFullList;
    prevSearchList[this.state.activekey] = list;
    this.setState({
      items: prevPageItems,
      count: prevPageCount,
      active: prevPageid,
      searchTerm: prevSearch,
      filterFullList: prevSearchList
    });
  }
  changePage(e, id = 1) {
    const list =
      this.state.searchTerm[this.state.activekey] !== ""
        ? this.state.filterFullList[this.state.activekey]
        : "";
    const page_data = this.getPageData(id, list);
    let prevPageid = this.state.active;
    prevPageid[this.state.activekey] = id;
    let prevPageItems = this.state.items;
    prevPageItems[this.state.activekey] = page_data;
    this.setState({
      items: prevPageItems,
      active: prevPageid
    });
  }
  getPageData(id, list = "") {
    const page = this.state.page;
    const items = list !== "" ? list : this.state.person[this.state.activekey];
    const page_data = items.slice(page * (id - 1), page * id);
    return page_data;
  }
  handleSelect(key) {
    const list =
      this.state.searchTerm[key] !== ""
        ? this.state.filterFullList[key]
        : this.state.person[key];
    let pageId = this.state.active[key];
    const page_data = this.getPageData(pageId, list);
    let prevPageid = this.state.active;
    prevPageid[key] = pageId;
    let prevPageItems = this.state.items;
    prevPageItems[key] = page_data;
    this.setState({
      items: prevPageItems,
      active: prevPageid,
      activekey: key
    });
  }
  handleMainTabSelect (key) {
    this.setState({
      mainkey : key
    })
  }
  componentWillMount() {
    // var url = this.state.getpersonsUrl + window.persons_table;
    // datasave.service(url, 'GET', '')
    //     .then(response => {
    //         this.setState({
    //             persons: response,
    //             items: this.state.person,
    //         })
    //     })
  }

  handle_activities(id, status, e) {

    // if (status === 1) {
    //   datasave.service(window.GET_PERSON_TODOS + '/' + id, 'GET', '')
    //     .then(response => {
    //       if (response.data.allTodos.length > 0) {
    //         this.setState({
    //             showChangeUserPopup: true,
    //             activeUsers: response.data.allPersons.Active,
    //             activityPersonId: id,
    //             activityPersonStatus : status,
    //         })
    //       } else {
    //         this.setState({
    //             activityPersonId: id,
    //             activityPersonStatus: status,
    //         })
    //         this.assignTodos();
    //       }
    //     })
    // } else {
    //
      if(this.state.activekey === 'Active') {
        this.setState({
          showActivePopup: true,
          personId: id,
          statusId: status,
        });

          } else {


            let userData = store.getState();
              var url = this.state.changePersonStatusUrl;
            const details = {
              id: id,
              table: window.persons_table,
              status: status ? 0 : 1
            };
              datasave .service(url, "PUT", details)
                .then(response => {
                  if (response === 1) {
                    this.setState({ status: "true", pid: id });
                    if(details.status === 0 && userData.UserData.user_details.person_id == id) {
                       userService.logout(id);
                       window.location.href = '/loginscreen';
                    }
                  }
                })
                .catch(error => {
                  this.setState({
                    errors: error.response.data.errors
                  });
                })
          }
    // }
  }

  handleDetails(id) {
    var url = window.PERSON_DETAILS + id;
    datasave.service(url, "GET", "").then(response => {
      this.setState({
        persondetails: response.selected,
        show: true,
        delid: id,
        count: response.selected.length,
        links: false
      });
      if (this.state.count === 0) {
        this.handleDelete(id);
        this.setState({
          nolinks: true,
          links: false
        });
      } else {
        this.setState({
          nolinks: false,
          links: true
        });
      }
    });
    this.setState({ currentPage: 1 });
  }

  handleExport() {
    var url = window.EXPORT_PERSONS + this.state.delid;
    datasave.service(url, "PUT", "").then(response => {
      window.open(response);
      window.close();
    });
  }

  handleDelete(pid) {
    this.setState({ show: false });
    var url = window.DROP_PERSON;
    var details = {
      pid: pid
      //   delid: del_id
    };
    datasave.service(url, "PUT", details).then(response => {
      this.setState({ persons: response, pid: pid });
    });
  }
  handleHide = () => {
    this.setState({
      show: false,
      showChangeUserPopup: false,
    });
  };

  handleCancel() {
    this.setState({ show: false });
  }

  handlePageClick(event) {
    this.setState({
      currentPage: Number(event.target.id)
    });
  }

  handleResendlink(person_id) {
    const {t} = this.state;
    var details = {
      person_id: person_id
    };
    var url = window.RESEND_LINK;

    datasave.service(url, "PUT", details)
    .then(response => {
      if(response === 'Unable to send link'){
        OCAlert.alertWarning(t('Unable to send link'), { timeOut: window.TIMEOUTNOTIFICATION});
      } else {
        OCAlert.alertSuccess(response, { timeOut: window.TIMEOUTNOTIFICATION});
      }

    });
  }

  selectUser(value) {
    this.setState({
      selectedUser: value,
    })
  }

  assignTodos() {
    let userData = store.getState();
    const details = {
      id: parseInt(this.state.activityPersonId),
      table: window.persons_table,
      status: this.state.activityPersonStatus ? 0 : 1,
      changeUser: parseInt(this.state.selectedUser.value),
    };
    datasave.service(window.ASSIGN_TODOS, "PUT", details)
      .then(response => {
        if (response === 1) {
          this.setState({
             status: "true",
             pid: this.state.activityPersonId,
             showChangeUserPopup: false,
          });
          if(details.status === 0 && userData.UserData.user_details.person_id == this.state.activityPersonId) {
             userService.logout(this.state.activityPersonId);
             window.location.href = '/loginscreen';
          }
        }
      })
      .catch(error => {
        this.setState({
          errors: error
        });
      });
  }

  closePopUp(){
    this.setState({
      showActivePopup: false,
    });
  }

  handlePageChange () {
    this.setState({
      mainkey : 1,
    })
    datasave.service(this.state.getpersonsUrl + window.persons_table, "GET", "")
        .then(response => {
          let pageData = {},
            count = {};
          pageData = {
            Active: this.getPageData(1, response["Active"]),
            Archived: this.getPageData(1, response["Archived"])
          };
          count = {
            Active: this.getCountPage(response["Active"]),
            Archived: this.getCountPage(response["Archived"])
          };
          this.setState({
            person: response,
            items: pageData,
            count: count,
            // delid: "",
            pid:""
          });
        });

  }

  render() {
    const {tabs,t,persons,currentPage,todosPerPage,persondetails, showActivePopup} = this.state;
    const personId = this.state.person.id;
    const indexOfLastTodo = currentPage * todosPerPage;
    const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
    const currentTodos = persondetails.slice(indexOfFirstTodo, indexOfLastTodo);
    const pagerender = currentTodos.map(doc => {
      return (
        <tr>
          <td>{doc.name}</td>
          <td>{doc.category}</td>
        </tr>
      );
    });
    const pageNumbers = [];
    if (this.state.persondetails.length > 5) {
      for (
        let i = 1;
        i <= Math.ceil(this.state.persondetails.length / todosPerPage);
        i++
      ) {
        pageNumbers.push(
          <Pagination.Item
            id={i}
            onClick={e => this.handlePageClick(e, this)}
            key={i}
            active={i === currentPage}
          >
            {i}
          </Pagination.Item>
        );
      }
    }

    const userChangePopup = (
        <reactbootstrap.Modal
            show={this.state.showChangeUserPopup}
            onHide={this.handleHide}
            dialogClassName="modal-90w"
            aria-labelledby="example-custom-modal-styling-title"
           >
          <reactbootstrap.Modal.Header closeButton>
              <reactbootstrap.Modal.Body>
                <div class="col-md-12 mt-3 mb-3 px-0">
                  <div class="col-md-12 px-0">
                      <div style={{ borderBottom: '1px solid lightgray' }} >
                          <span><h4>{t('Change user')}</h4></span>
                      </div>
                      <div>
                        <reactbootstrap.InputGroup className=" my-3 ">
                          <div className="col-md-4 pl-0">
                            <reactbootstrap.InputGroup.Prepend>
                              <reactbootstrap.InputGroup style={{ color: '#EC661C', fontSize: '17px' }} id="basic-addon1">{t("Select User")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                            </reactbootstrap.InputGroup.Prepend>
                          </div>
                          <div className="col-md-4 pl-0">
                            <MultiSelect
                              options={this.state.activeUsers}
                              standards={this.state.selectedUser}
                              handleChange={e => this.selectUser(e)}
                              isMulti={false} />
                          </div>
                        </reactbootstrap.InputGroup>
                        <reactbootstrap.Button onClick={() => this.assignTodos()}>
                          {t("Assign todo's")}
                        </reactbootstrap.Button>
                      </div>
                  </div>
                </div>
              </reactbootstrap.Modal.Body>
          </reactbootstrap.Modal.Header>
        </reactbootstrap.Modal>
    );

    const popupData = (
      <reactbootstrap.Modal
        show={this.state.show}
        onHide={this.handleHide}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title id="contained-modal-title-vcenter" />
          <reactbootstrap.Modal.Body col-md-12 pr-0>
            <reactbootstrap.Table striped bordered hover variant="dark">
              <thead>
                <tr>
                  <td>{t("Name")}</td>
                  <td>{t("Category")}</td>
                </tr>
              </thead>
              <tbody>{pagerender}</tbody>
            </reactbootstrap.Table>
            <Pagination size="sm" style={{width: '410px', overflow: 'auto'}} >{pageNumbers}</Pagination>
          </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal.Header>
        {this.state.links && (
          <reactbootstrap.Modal.Footer>
            <reactbootstrap.Button onClick={() => this.handleCancel()}>
              {t("Cancel")}
            </reactbootstrap.Button>
            <reactbootstrap.Button onClick={() => this.handleExport()}>
              {t("Export")}
            </reactbootstrap.Button>
          </reactbootstrap.Modal.Footer>
        )}
        {this.state.nolinks && (
          <reactbootstrap.Modal.Footer>
            <reactbootstrap.Button
              onClick={() => this.handleDelete(this.state.delid)}
            >
              {t("OK")}
            </reactbootstrap.Button>
          </reactbootstrap.Modal.Footer>
        )}
      </reactbootstrap.Modal>
    );
    let filtered =
      this.state.items[this.state.activekey] !== undefined
        ? this.state.items[this.state.activekey]
        : [];
    let active = this.state.active[this.state.activekey];
    let pages = { Active: [], Archived: [] };
    let pagesItem = [];
    if (this.state.count[this.state.activekey] !== undefined) {
      for (
        let number = 1;
        number <= this.state.count[this.state.activekey];
        number++
      ) {
        pagesItem.push(
          <Pagination.Item
            key={number}
            active={number === active}
            id={number}
            onClick={e => this.changePage(e, number)}
          >
            {number}
          </Pagination.Item>
        );
      }
      pages = { [this.state.activekey]: pagesItem };
    }
    var tabData = Object.keys(tabs).map(function(tab, value) {
      return (
        <reactbootstrap.Tab eventKey={tab} title={tabs[tab]}>
          <div className="card-body">
            <input
              className="form-control search-box-border col-md-4 mb-2"
              placeholder={t("Search")}
              onChange={this.searchData}
            />
            <br />
            <form method="POST">
              <div style={{}}>
                <reactbootstrap.Table className="site-table-main">
                  <thead>
                    <tr>
                      <th>{t("Person")}</th>
                      <th>{t("Email id")}</th>
                      {((CanPermissions("view_Batch_code", "") === true) && this.state.as4PersonOrNot === 1 && tab === 'Active') &&
                        <th>{t("Batch codes")}</th>
                      }
                      <th style={{ textAlign: 'center',paddingLeft: '1.5rem'}}>{t("Actions")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map(function(person) {
                      return (
                        <tr style={{ borderBottom: "1px solid #dee2e6" }}>
                          <td>{person.name}</td>
                          <td>{person.email}</td>
                          {((CanPermissions("view_Batch_code", "") === true) && this.state.as4PersonOrNot === 1  && tab === 'Active') &&
                            <td>{person.batch_code}</td>
                          }
                          <td
                            style={{
                              display: "flex",
                              float: "right",
                              border: "0px"
                            }}
                          >
                            <Can
                              perform="E_user"
                              yes={() => (
                                // <Link to={{
                                //       pathname: `/persons/${person.id}`,
                                //       state: {
                                //           redirect :this.props.handleSelect('/managemyorganisation/createperson'),
                                //       }
                                //       }}/>
                                <Link
                                  style={{ float: "right", padding: "10px" }}
                                  to={`/persons/${person.id}`}
                                  key={person.id}
                                >
                                  {/* {t('Edit')} */}
                                  <i
                                    title="Edit"
                                    class="overall-sprite overall-sprite-myeditc"
                                    onClick={(e)=>this.setState({personId:person.id})}
                                  />
                                </Link>
                              )}
                            />
                            {/* <br></br> */}
                            {/* <a href='#' onClick ={(e) => this.handle_activities(person.id,person.status, e)}> */}
                            {/* {person.status ? 'Archive' : 'Make active'} */}
                            {/* </a> */}

                            <br />
                            <a  style={{ float: 'right', padding: '10px' }}
                              href="#"
                              onClick={e =>
                                this.handle_activities(
                                  person.id,
                                  person.status,
                                  e
                                )
                              }
                            >
                              {person.status ?
                                  <Can
                                  perform = "inactive_person"
                                  yes = {() => (
                                    <i title="Make Inactive" class="overall-sprite overall-sprite-myinactivec"></i>
                                  )}
                                  />
                                 :
                                 <Can
                                 perform = "active_person"
                                 yes = {() => (
                                   <i title="Make Active" class="overall-sprite overall-sprite-myactivec"></i>
                                 )}
                                 />
                               }
                            </a>

                            <br />
                           <Can
                              perform="D_user"
                              yes={() => (
                              (person.status === 0) && <a
                                  style={{ float: "right", padding: "10px" }}
                                  href="#"
                                  onClick={e => this.handleDetails(person.id)}
                                >
                                  {/* {t('Delete')} */}
                                <i
                                    title="Delete"
                                    class="overall-sprite overall-sprite-mtdeletec"
                                  />
                                </a>
                             )}
                            />
                            <Can
                               perform="E_user"
                               yes={() => (
                               (person.status === 0) && (person.ustatus === 0) &&
                               <Button
                                   style={{ float: "right", padding: "10px" }}
                                   href="#"
                                   onClick={e => this.handleResendlink(person.id)}
                                >
                                    {t('Resend link')}
                                 </Button>
                              )}
                             />
                          </td>
                          {userChangePopup}
                        </tr>
                      );
                    }, this)}
                  </tbody>
                </reactbootstrap.Table>
              </div>
              <div className="page-nation-sec col-md-12">
                <Pagination
                  style={{
                    width: "500px",
                    overflow: "auto",
                    scrollbarWidth: "thin"
                  }}
                  size="md"
                >
                  {pages[this.state.activekey]}
                </Pagination>
              </div>
              {popupData}
            </form>
          </div>
        </reactbootstrap.Tab>
      );
    }, this);

    return (
      <div className=" row col-md-12">
        <div style={{ visibility: "hidden" }} className="col-md-1">
          <p>welcome</p>
        </div>

        <div style={{ }} className="col-md-11">
          <Can
            perform="E_user,R_user,D_user,active_person,inactive_person,LOU,IMU_ext,Access_Userlogs"
            yes={() => (
              // <div className='container'>
              <div className="">
                 {/* <Router history={history}>
                <>  */}
                <div className="col-md-12 p-0 mt-0 mb-0">
                  <div className="card">
                    {/* <div className="card-header">{t("All persons")}</div> */}
                    {/* <div className='card-body'></div> */}
                    <reactbootstrap.Tabs activeKey={this.state.mainkey} onSelect={this.handleMainTabSelect} id="controlled-tab-example">
                      {(CanPermissions("E_user,R_user,D_user,active_person,inactive_person", "") === true) &&
                        <reactbootstrap.Tab eventKey={1} title={t("Manage persons")}>
                          <reactbootstrap.Tabs
                            activeKey={this.state.activekey}
                            onSelect={this.handleSelect}
                            id="controlled-tab-example"
                          >
                          {tabData}
                          </reactbootstrap.Tabs>
                        </reactbootstrap.Tab>
                      }
                      {(CanPermissions("E_user", "") === true) &&
                        <reactbootstrap.Tab  eventKey={2} title={t("Create person")}>
                          <Persons handlePageChange={this.handlePageChange.bind(this)} uniqueId={Math.floor((Math.random() * 1000) + 1)}></Persons>
                        </reactbootstrap.Tab>
                      }
                      {(CanPermissions("IMU_ext", "") === true) &&
                          <reactbootstrap.Tab eventKey={3} title={t("Import users")}>
                            <ImportUsers></ImportUsers>
                          </reactbootstrap.Tab>
                      }
                      {(CanPermissions("Access_Userlogs", "") === true) &&
                          <reactbootstrap.Tab eventKey={4} title={t("User details")}>
                            <Userlogdetails></Userlogdetails>
                          </reactbootstrap.Tab>
                      }
                    </reactbootstrap.Tabs>
                  </div>
                  </div>
                  {showActivePopup &&
                    <InactivePopup
                      show={this.state.showActivePopup}
                      id={this.state.personId}
                      changePersonStatusUrl = {this.state.changePersonStatusUrl}
                      closePopUp={this.closePopUp}
                      status={this.state.statusId}
                      changePersonStatusUrl={this.state.changePersonStatusUrl}
                    />}
                  {/* <PrivateRoute history={history} path='/persons/:id' component={Persons} name='persons' /> */}
                  {/* <PrivateRoute history={history} path='/managemyorganisation/createperson' component={Persons} /> */}
                  {/* </>
                  </Router>  */}
              </div>
              // </div>
            )}
            no={() => <AccessDeniedPage />}
          />

        </div>

      </div>
    );
  }
}
export default translate(PersonsList);

{
  /* <i class="overall-sprite overall-sprite-myeditc"></i>
<i class="overall-sprite overall-sprite-mtdeletec"></i> */
}
