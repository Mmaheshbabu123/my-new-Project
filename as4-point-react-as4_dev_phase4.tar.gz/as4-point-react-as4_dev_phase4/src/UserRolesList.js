//import axios from 'axios'
import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from './_services/db_services';
import {translate} from './language';

class UserRolesList extends Component {
  constructor(props) {
    super(props)
    this.state = {
      roles: [],
      t:props.t,
    }
  }
  componentDidMount() {
    var url = window.USERROLES
    datasave.service(url, "GET")
    .then(response => {
    //axios.get(process.env.REACT_APP_serverURL + '/api/roles').then(response => {
      this.setState({
        roles: response
      })
    })
  }

  render() {
    const { roles,t } = this.state
    return (
      <div className='container py-4'>
        <div className='row justify-content-center'>
          <div className='col-md-9'>
            <div className='card'>
              <div className='card-header'>{t('All roles')}</div>
              <div className='card-body'>
                <reactbootstrap.Table responsive striped bordered hover size="sm">
                  <thead>
                    <tr>
                      <th>{t('Name of role')}</th>
                      <th colspan="2">{t('Actions')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {roles.map(roleItem => (
                      <tr>
                        <td>{roleItem.name}</td>
                        <td>
                          <Link
                            to={`/roles/${roleItem.id}`}
                            key={roleItem.id}
                          >
                            {t('Edit')}
                        </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </reactbootstrap.Table>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default translate(UserRolesList);
