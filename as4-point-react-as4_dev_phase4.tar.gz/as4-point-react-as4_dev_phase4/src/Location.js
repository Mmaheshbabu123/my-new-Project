import axios from 'axios'
import React, { Component } from 'react';
import { Button, FormControl, InputGroup} from 'react-bootstrap';
import {translate} from './language';

class Location extends Component {
    constructor(props) {
        super(props)
        this.handleSubmit = this.handleSubmit.bind(this);
        this.state = {
            locations: '',
            t:props.t,
        }

    }
handleSubmit(event) {
    event.preventDefault()
    const { history } = this.props
    const details = {
        locations: this.state.locations,
    }
   axios.post(process.env.REACT_APP_serverURL + '/api/location', details).then(response => {
          this.setState({
            details: response
          })
            if (response.status === 200) {
              history.push('/managelocations')
            }

        })
        .catch(error => {
            this.setState({
              errors: error.response
            })
          })
}
render() {
         const {t} = this.state;
     return (
        <div className = 'container py-4' >
           <div className = 'row justify-content-center' >
              <div className = 'col-md-6' >
                <div className = 'card' >
                  <div className = 'card-header' > {t('Create location')} </div>
                    <div className = 'card-body' >
                      <form onSubmit = { this.handleSubmit } encType="multipart/form-data">

                        <div>
                             <InputGroup className="mb-3">
                                <InputGroup.Prepend>
                                  <InputGroup  id="basic-addon1">{t('Location')}</InputGroup>
                                </InputGroup.Prepend>
                                <FormControl
                                    placeholder="Create new location"
                                    aria-label="Location"
                                    aria-describedby="basic-addon1"
                                    name = 'locations'
                                    value = { this.state.locations }
                                    onChange = { e => this.setState({ locations: e.target.value }) }
                                />
                             </InputGroup>
                              <Button variant="primary" type="submit">{t('Save')}</Button>
                      </div>
                  </form >
              </div>
              </div >
             </div>
            </div >
         </div>


        );
    }




}
export default translate(Location)
