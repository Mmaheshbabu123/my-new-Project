import React, { Component } from 'react';
import { Container, Input, Label } from 'reactstrap';
import { Button, Form, FormGroup, InputGroup, FormControl, FormCheck } from 'react-bootstrap';
import axios from 'axios';
import { datasave } from './_services/db_services';
import Can from './_components/CanComponent/Can';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import { translate } from './language';
import MultiSelect from './_components/MultiSelect';
import * as reactbootstrap from 'react-bootstrap';

const path = require('path')

class ImportUsers extends Component {

    constructor(props) {
        super(props);

        this.state = {
            file: '',
            save: 'Save',
            savevalue: 'true',
            extentionError: 'false',
            file_details: '',
            message: '',
            // organisations: [],
            organisation_id: 1,
            roles: [],
            selectedRole: [],
            t: props.t,
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.selectRole = this.selectRole.bind(this);
    }

    componentDidMount() {
        // const url = window.ORGANISATIONS;
        // datasave.service(url, 'GET')
        //   .then(response => {
        //       this.setState({
        //           organisations: response,
        //       })
        //   })

        datasave.service(window.GET_ROLES_FR_MULTISELECT, 'GET')
          .then(response => {
              this.setState({
                  roles: response,
              })
          })
    }

    handleCancel(event) {
        const { history } = this.props
        if (this.props.match.params.id) {
            history.push('/managesectors')
        } else {
            history.push('/ifo')
        }
    }

    handleChange(e) {
      const {t} = this.state;
        this.setState({
            file: e.target.value,
            submitted: 'false',
            message: '',
            savevalue: 'true',
            save: t('Save'),
            file_details: e.target.files[0]
        })
    }


    selectRole(value) {
      this.setState({
        selectedRole: value,
      })
    }

    uploadFile = (event) => {
        event.preventDefault()
        this.setState({
            submitted: 'true',
            extentionError: 'true',
        });

        const extensions = ['.csv', '.xlsx', '.xlsm', '.xlsb', '.xls', '.xlam'];
        const { file,t } = this.state;
        const uploadedFileExtension = path.extname(file);

        const details = {
            file: this.state.file_details,
            organisation_id: this.state.organisation_id
        }

        if (file !== '') {
            for (var index = 0; index < extensions.length; index++) {
                if (uploadedFileExtension === extensions[index]) {
                    this.setState({
                        savevalue: '',
                        save: t('Please wait'),
                        extentionError: 'false'
                    });

                    const formData = new FormData();
                    // formData.append('file',this.state.file_details)
                    for (var key in details) {
                        formData.append(key, details[key]);
                    }
                    var obj = JSON.parse(localStorage.getItem('user'));
                    var result = window.atob(obj.authdata);
                    result = result.substring(0, result.indexOf(":"));
                    formData.append('email', result);
                    formData.append('role', this.state.selectedRole.value);
                    /*const url = window.IMPORT;
                    datasave.service(url, 'POST', formData)
                      .then(response => {
                        if (response) {
                          this.setState({
                             message: 'success'
                          })
                        }
                        else {
                            this.setState({
                                message: 'failed'
                            });
                          //this.getMemos();
                        }
                      })
                      .catch(error => {
                        this.setState({
                          errors: error.response.data.errors
                        })
                      })  */
                    document.getElementById("loding-icon").setAttribute("style", "display:block;");
                    axios.post(window.backendURL + '/api/user/import', formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
                        .then(response => {
                            document.getElementById("loding-icon").setAttribute("style", "display:none;");
                            if (response.data !== 'Failure') {
                                this.setState({
                                    message: 'success',
                                    save: t('save'),
                                    savevalue: 'true'
                                });
                            } else {
                              //DataMissing
                              this.setState({
                                  message: 'failed',
                                  save: t('Please wait'),
                                  savevalue: ''
                              });
                            }
                        })
                }
            }
        } else {
            this.setState({
                extentionError: 'false',
            });
        }

    }

    render() {
        const { t, file, submitted, save, extentionError, message } = this.state;
        return (
            <div className="row col-md-12">
                {/* <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div> */}
                <div style={{  }} className="col-md-11">
                    <Can
                        perform="IMU_ext"
                        yes={() => (
                            <div className="">
                                <div className="col-md-12">
                                    {/* <div className="card"> */}
                                        <div className="p-0">
                                            <Form onSubmit={this.uploadFile}>
                                                <FormGroup>
                                                    <div className=" row input-overall-sec ">
                                                        <reactbootstrap.InputGroup className=" my-3 ">
                                                          <div className="col-md-2">
                                                            <reactbootstrap.InputGroup.Prepend>
                                                              <reactbootstrap.InputGroup style={{ color: '#EC661C', fontSize: '17px' }} id="basic-addon1">{t("Upload file")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                                            </reactbootstrap.InputGroup.Prepend>
                                                          </div>
                                                          <div className="col-md-4 pl-0">
                                                              <Input
                                                                  style={{ color: '#EC661C', fontSize: '17px' }}
                                                                  className="import-browse"
                                                                  id="file"
                                                                  type="file"
                                                                  name="file"
                                                                  onChange={this.handleChange}
                                                                  value={file}
                                                                  onClick={(e) => e.target.files[0] && this.handleChange(e)}
                                                                  accept=".csv, .xlsx, .xlsm, .xlsb, .xls, .xlam"
                                                              />
                                                          </div>
                                                        </reactbootstrap.InputGroup>
                                                        <div className="col-md-12">{t('Upload only csv and excel format files.')}</div>
                                                        {message === 'success' && (
                                                            <p style={{ color: "green" }}>{t('Your file is uploaded successfully')}</p>
                                                        )}
                                                        {submitted === 'true' && file === '' &&
                                                            <div style={{ color: 'red' }} className="help-block col-md-12">{t('Please upload file')}</div>
                                                        }
                                                        {submitted === 'true' && extentionError === 'true' &&
                                                            <div style={{ color: 'red' }} className="help-block col-md-12">{t('Please upload only csv and excel format files.')}</div>
                                                        }
                                                    </div>
                                                </FormGroup>
                                                {/* <FormGroup>
                                                  <InputGroup className="mb-3">
                                                      <InputGroup.Prepend>
                                                          <InputGroup.Text id="basic-addon1">Organisation</InputGroup.Text>
                                                      </InputGroup.Prepend>
                                                      <select name="organisation_id" id="organisation_id" onChange={ e => this.setState({ organisation_id: e.target.value }) }>
                                                          {state.organisations.map(organisation => <option value={organisation.id}>{organisation.name}</option>) }
                                                      </select>
                                                  </InputGroup>
                                                </FormGroup> */}
                                                <FormGroup>
                                                    <div>
                                                        <a href="https://as4-point.s3-eu-west-1.amazonaws.com/as4-point/docs/importusers.csv" download>{t('Download example CSV file')}</a>
                                                    </div>
                                                </FormGroup>
                                                <FormGroup>
                                                    <div>
                                                        <a href="https://as4-point.s3-eu-west-1.amazonaws.com/as4-point/docs/users.xls" download>{t('Download example XLS file')}</a>
                                                    </div>
                                                </FormGroup>
                                                <reactbootstrap.InputGroup className=" my-3 ">
                                                  <div className="col-md-2 pl-0">
                                                    <reactbootstrap.InputGroup.Prepend>
                                                      <reactbootstrap.InputGroup style={{ color: '#EC661C', fontSize: '17px' }} id="basic-addon1">{t("Select role:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                                    </reactbootstrap.InputGroup.Prepend>
                                                  </div>
                                                  <div className="col-md-4 pl-0">
                                                    <MultiSelect
                                                      options={this.state.roles}
                                                      standards={this.state.selectedRole}
                                                      handleChange={e => this.selectRole(e)}
                                                      isMulti={false} />
                                                  </div>
                                                  {submitted === 'true' && this.state.selectedRole.length === 0 &&
                                                      <div style={{ color: 'red' }} className="help-block col-md-12">{t('Please select role')}</div>
                                                  }
                                                </reactbootstrap.InputGroup>
                                                {message === 'failed' && (
                                                    <div className={'alert alert-danger'}>
                                                        <p>{t('Not even a single user is imported.Either those users may already exist or details may incomplete/invalid')}</p>
                                                    </div>
                                                )}
                                                {message === 'success' && (
                                                    <div className={'alert alert-success'}>
                                                        <p>{t('Your request has been registered. Once it is processed, you’ll receive a status report')}</p>
                                                    </div>
                                                )}
                                                <FormGroup>
                                                    <div style={{ float: 'right' }} className="organisation_list">
                                                      {/*
                                                        <a onClick={this.handleCancel} >{t('Cancel')}</a>
                                                       &nbsp;&nbsp;&nbsp;
                                                        */}
                                                    <Button className="btn btn-primary" disabled={!this.state.savevalue} type='submit' color="primary"> {t(save)} </Button>
                                                    </div>
                                                </FormGroup>
                                            </Form>
                                        </div>
                                    {/* </div> */}
                                </div>
                            </div>
                        )}
                        no={() =>
                            <AccessDeniedPage />
                        }
                    />
                </div>
            </div>
        );
    }
}
export default translate(ImportUsers)
