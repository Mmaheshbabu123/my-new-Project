import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import '../Organisations.css';
import { datasave } from '../_services/db_services';
import Pagination from "react-js-pagination";
import axios from 'axios'
import TagManager from './TagManager';
import DefinationsManager from './DefinationsManager';
import HyperlinksManager from './HyperlinksManager';
import { Tabs, Tab } from 'react-bootstrap';
import StandardsManager from './StandardsManager';
import ManageBundles from '../_components/BundleComponent/ManageBundles';
import './MasterData.css';
import manageedit from './manage-edit.png';
import Can from '../_components/CanComponent/Can';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import {translate} from '../language';

class ManageMasterData extends Component {
  constructor(props) {
    super(props)
    this.state = {
      list:'',
      t:props.t
    }
  }
  render() {
    return (
     <div>
     <TabbedMenu {...this.props} />
     </div>
    );
  }
}

class TabbedMenu extends React.Component{
      constructor(props){
      super(props)
      this.state = {
         key :'tags',
         component:'',
         disabled:false,
         t:props.t
      }
     this.handleTabclick.bind(this);
  }

  handleTabclick(e){
    this.setState({
      disabled:e,
    })
  }
  render() {

    const tags_tab = CanPermissions("R_tags,E_tags,D_tags", "");
    const hyperlinkes_tab = CanPermissions("R_hyperlink,E_hyperlink,D_hyperlink", "");
    const definitions_tab = CanPermissions("R_definitions,E_definitions,D_definitions", "");
    const standards_tab = CanPermissions("R_standards,E_standards,D_standards", "");
    const bundles_tab = CanPermissions("R_bundle,E_bundle,D_bundle", "");

    let tags_tab_disabled = (tags_tab) ? '' : 'disabled';
    let hyperlinkes_tab_disabled = (hyperlinkes_tab) ? '' : 'disabled';
    let definitions_tab_disabled = (definitions_tab) ? '' : 'disabled';
    let standards_tab_disabled = (standards_tab) ? '' : 'disabled';
    let bundles_tab_disabled = (bundles_tab) ? '' : 'disabled';
    const {t} = this.state;
    return(
      <Can
        perform="R_tags,E_tags,D_tags,R_hyperlink,E_hyperlink,D_hyperlink,R_definitions,E_definitions,D_definitions,R_standards,E_standards,D_standards,R_bundle,E_bundle,D_bundle"
        yes= {() => (
        <div className="ml-5 mb-2 py-3">
          <div className="container-fluid justify-content-center">
              <div className="container pl-0 mb-2">
                  <div className="card">
                      <div className="card-body">
                        <reactbootstrap.Tabs
                          id="controlled-tab-example" className="header_tabs"
                          activeKey={this.state.key}
                          onSelect={key => this.setState({ key })}
                        >
                          <reactbootstrap.Tab eventKey="tags" title={t("Tags")} disabled = {tags_tab_disabled || this.state.disabled} >
                            <Can
                              perform="R_tags,E_tags,D_tags"
                              yes= {() => (
                                <TagManager tab = {this.handleTabclick.bind(this)} />
                              )}
                            />
                          </reactbootstrap.Tab>
                          <reactbootstrap.Tab disabled = 'true' eventKey="hyperlinks" title={t("Hyperlinks")} disabled = {hyperlinkes_tab_disabled || this.state.disabled} >
                            <Can
                              perform="R_hyperlink,E_hyperlink,D_hyperlink"
                              yes= {() => (
                                <HyperlinksManager tab = {this.handleTabclick.bind(this)} />
                              )}
                            />
                          </reactbootstrap.Tab>
                          <reactbootstrap.Tab eventKey="definations" title={t("Definitions")} disabled = {definitions_tab_disabled || this.state.disabled}>
                            <Can
                              perform="R_definitions,E_definitions,D_definitions"
                              yes= {() => (
                                <DefinationsManager tab = {this.handleTabclick.bind(this)} />
                              )}
                            />
                          </reactbootstrap.Tab>
                          <Tab eventKey="standards" title={t("Standards")} disabled = {standards_tab_disabled || this.state.disabled}>
                            <Can
                              perform="R_standards,E_standards,D_standards"
                              yes= {() => (
                                <StandardsManager tab = {this.handleTabclick.bind(this)}/>
                              )}
                            />
                          </Tab>
                          <Tab eventKey="bundles" title={t("Bundles")} disabled = {bundles_tab_disabled || this.state.disabled} >
                            <Can
                              perform="R_bundle,E_bundle,D_bundle"
                              yes= {() => (
                                <ManageBundles tab = {this.handleTabclick.bind(this)} />
                              )}
                            />
                          </Tab>
                        </reactbootstrap.Tabs>
                      </div>
                  </div>
              </div>
          </div>
        </div>
        )}
        no={() =>
          <AccessDeniedPage/>
        }
      />
    );
  }
}


export default translate(ManageMasterData);
