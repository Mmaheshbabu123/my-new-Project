import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import Pagination from 'react-bootstrap/Pagination'

import {translate} from '../language';
import { datasave } from '../_services/db_services';
import Standards from '../Standards/Standards';
import managedelete from './manage-delete.png';
import manageedit from './manage-edit.png';
import addstandards from './addstandards.png';
import cstand from './cstand.png';
import { OCAlert } from '@opuscapita/react-alerts';
import StandardSubManager from '../MasterDataManagement/StandardManagerSub'
import Can from '../_components/CanComponent/Can'

const KEYS_TO_FILTERS = ['name', 'description']
class StandardsManager extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tag: [],
            searchTerm: '',
            tagId: '',
            standards_docs: [],
            currentPage: 1,
            todosPerPage: 5,
            alert: '',
            folder_data: [],
            manual_data: [],
            fcurrentPage: 1,
            mcurrentPage: 1,
            tabId: '',
            component: '',
            saveComponent: '',
            formId: '',
            id: '',
            page: 5,
            active: 1,
            count: 0,
            filterFullList: [],
            searchTerm: '',
            selected_class: 'inactive',
            img:addstandards,
            t:props.t,
            usedpage:1,
            itemsUsedIn:[],
            createdStd:'',
            pageIndex : [6,11,16,22,28,34,40,46,52,58,64,70,76]
        }
        this.searchData = this.searchData.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.changeComponent = this.changeComponent.bind(this);
    }
    componentDidMount() {
        datasave.service(window.GET_STANDARDS_LIST, 'GET', '')
            .then(response => {
                const pageData = this.getPageData(1, response[0]);
                const count = this.getCountPage(response[0]);
                this.setState({
                    tag: response[0],
                    tagId: response[0][0].id,
                    count : count,
                    items: pageData,
                })
            });
    }
    componentDidUpdate(prevProps, prevState) {

        if (prevState.saveComponent !== this.state.saveComponent || (prevState.didupdate !== this.state.didupdate && this.state.standards_docs.length ===0)) {
            datasave.service(window.GET_STANDARDS_LIST, 'GET', '')

            .then(response => {
                const pageData = this.getPageData(this.state.active, response[0]);
                const count = this.getCountPage(response[0]);
                this.setState({
                    tag: response[0],
                    // tagId: response[0][0].id,
                    items:pageData,
                    count:count,
                    saveComponent: "",
                    didupdate:'true',
                    searchTerm:''
                })
                if(this.state.createdStd!= ''){

                    this.handleCreatedStdPage(response[0])
                    this.setState({
                        createdStd:''
                    })
                }

            });
        }
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }
    componentWillMount() {
        this.setState({ items: this.state.tag })
    }
    searchData(e) {
      var list = [...this.state.tag];
      let res ='';
      list = list.filter(function (item) {
          if (item.name !== null) {
            res = item.name.toLowerCase().search(
                  e.target.value.toLowerCase()) !== -1;
          }
          if(res){
            return res;
          }
          else{
            if (item.description !== null) {
              return item.description.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
          }

      });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    handleClick(e, id) {
        this.setState({
            tagId: id,
             component: '',
            });
        this.props.tab(false);
    }

    handleDeleteStandards(id) {

     let  url = window.GET_MASTER_DATA + id;
        datasave.service(url, 'GET', id).then(
            response => {
                this.setState({ standards_docs: response, id: id, show: true, alert: '',component: '', })
                if (this.state.standards_docs.length == 0) {
                    this.setState({ alert: 'true' })
                }
            }
        )

         url = window.GetUsedInDocs_standards+id;
        datasave.service(url,'GET').then(
            response =>{
                if(response.length == 0){

                    this.setState({ itemsUsedIn  : response,Delete :true })
                }
          this.setState({ itemsUsedIn  : response, Delete:false })
            })

        this.setState({ currentPage: 1, mcurrentPage: 1, fcurrentPage: 1,didupdate:'true' })

    }
    handlePageUsedInClick(event){
        this.setState({
            usedpage: Number(event.target.id)
        });
    }
    handlePageClick(event) {
        this.setState({
            currentPage: Number(event.target.id)
        });
    }

    handleFolderPageClick(event) {
        this.setState({
            fcurrentPage: Number(event.target.id)
        });
    }
    handleManualPageClick(event) {
        this.setState({
            mcurrentPage: Number(event.target.id)
        });
    }

    handlehide = () => {
        this.setState(
            { show: false }
        )
    }
    handleCancel() {
        this.setState(
            { show: false }
        )
    }

    handleExport() {
     var url = window.GET_EXPORT+ this.state.id;
     datasave.service(url,'PUT','')
     .then(response =>{
         window.open(response)
         window.close();
     })

    }

    handleOk() {
        const { id, standards_docs,itemsUsedIn,t } = this.state;
        this.setState(
            { show: false,id:'',didupdate:'1',component:'1'}
        )

        if (standards_docs.length === 0 && itemsUsedIn.length === 0 ) {
            const url = window.DELETE_STANDARD_DATA + id;
            datasave.service(url, 'put', id).then(
                response => {

                });
            this.state.items.length = this.state.items.length-1;
            if(this.state.items.length === 0)
            {
                this.state.active = this.state.active - 1;
            }
        }
        else {
            OCAlert.alertWarning(t('Unable to delete standard because its been using in documents'), { timeOut: window.TIMEOUTNOTIFICATION});


        }
    }
    update(e) {
        if (e !== this.state.tabId) {
            this.setState({
                tabId: e,
            });
        }
    }
    changeComponent(e, id) {

        if(id !== undefined){

        this.setState({
            component: 'Standards',
            formId: (id !== '') ? id : '',
            name_error:'',
              error:'',
              tagId: (id == '')? this.state.tagId:id,
        });
    }else{

        this.setState({
            component: 'Standards',
            formId: (id !== '') ? id : '',
            name_error:'',
              error:'',
              tagId:this.state.tagId,
        })
    }
        this.props.tab(true);
    }
    updateComponent(e) {

        if (e) {
            this.setState({
                component: '',
                saveComponent: 1,
                name_error:'',
              error:'',

            })
            this.props.tab(false);
        }
    }

    handleMouseOver(e){
        this.setState({
            img:cstand,
        })
    }
    HandleMouseOut(e){
        this.setState({
            img:addstandards,
        });
    }
    changePage(e, id = 1) {
        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);
        this.setState({
            items : page_data,
            active: id,
            createdStd:''
        });
    }
    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.tag;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;
    }
    handleCreatedStandard = (standard) =>{
        this.setState({
            createdStd: standard
        })
    }

    handleCreatedStdPage=(stdlist) =>{


        var index = stdlist.map(function(e) { return e.name; }).indexOf(this.state.createdStd)

        let id  = stdlist[index].id
        var page = Math.floor(index/5)



        if(index%5>0){

            this.changePage('',(page+1));
             this.setState({
                tagId:id
                })
        }else{
                if(this.state.pageIndex.includes(index+1)){
                    this.setState({
                        tagId:id
                        })
                        this.changePage('temp',page+1)
                }else{
                    if(index == 0 ){

                        this.changePage('',1);
                         this.setState({
                            tagId:id
                            })
                    }else{
                    this.setState({
                        tagId:id
                        })
                        this.changePage('temp',page)
                }
            }
           }

   }




    render() {
        const { id,t, standards_docs, alert, todosPerPage, currentPage,itemsUsedIn,usedpage} = this.state;
        const indexOfLastTodo = currentPage * todosPerPage;
        const indexOfFirstTodo = indexOfLastTodo - todosPerPage;

    const indexOfLastTodo1 = usedpage * todosPerPage;
    const indexOfFirstTodo2 = indexOfLastTodo1 - todosPerPage;
    const currentTodos3 = itemsUsedIn.slice(indexOfFirstTodo2, indexOfLastTodo1);
    const data = currentTodos3.map(item => {

        return (
          <tr>
        <td>{item.d_code}</td>
       <td>{item.d_name}</td>
       <td>{item.d_version}</td>
       <td>{item.f_code}</td>
       <td>{item.f_name}</td>
       </tr>
        )
    });

        const currentTodos = standards_docs.slice(indexOfFirstTodo, indexOfLastTodo);
        const pagerender = currentTodos.map(doc => {
            return <tr><td>{doc.code}</td>
                <td>{doc.name}</td>
                <td>{doc.folder}</td>
                <td>{doc.manual}</td>
            </tr>
        });

        const pageNumbers = [];
        if(standards_docs.length > 5){
        for (let i = 1; i <= Math.ceil(standards_docs.length / todosPerPage); i++) {
            pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
                {i}
            </Pagination.Item>);
        }
      }
      const pageNumbers2 = [];
        if(itemsUsedIn.length > 5){
        for (let i = 1; i <= Math.ceil(itemsUsedIn.length / todosPerPage); i++) {
            pageNumbers2.push(<Pagination.Item id={i} onClick={(e) => this.handlePageUsedInClick(e, this)} key={i} active={i === usedpage}>
                {i}
            </Pagination.Item>);
        }
      }

        const popup = (
            <reactbootstrap.Modal
                size="lg"
                show={this.state.show}
                onHide={this.handlehide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title">
                <reactbootstrap.Modal.Header closeButton>

                    <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">

                    </reactbootstrap.Modal.Title>
                    <reactbootstrap.Modal.Body>
                        <reactbootstrap.Tabs id="controlled-tab-example">
                            <reactbootstrap.Tab eventKey={1} title={t("Documents")}>
                                <reactbootstrap.Table responsive striped bordered hover size="sm">
                                    <thead>
                                        <tr>
                                            <td>{t('Document code')}</td>
                                            <td>{t('Document name')}</td>
                                            <td>{t('Folder name')}</td>
                                            <td>{t('Manual name')}</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {pagerender}

                                    </tbody>
                                    {alert && <span className=" alert text-center">{t('No records found')}</span>}
                                </reactbootstrap.Table>
                                <Pagination size="sm"  style={{width: '410px', overflow: 'auto'}} >{pageNumbers}</Pagination>
                            </reactbootstrap.Tab>
                            <reactbootstrap.Tab eventKey={2} title={t("Used in documents")}>
                          <reactbootstrap.Table responsive bordered hover>
                                    <thead>
                                        <tr>
                                            <th>{t('Document code')}</th>
                                            <th>{t('Document name')}</th>
                                            <th>{t('Document version')}</th>
                                            <th>{t('Folder code')}</th>
                                            <th>{t('Folder name')}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    {data}
                                    {this.state.Delete && <tr>{t('No records found')}</tr>}
                                    </tbody>
                                </reactbootstrap.Table>
                                <Pagination size="sm"  style={{width: '410px', overflow: 'auto'}} >{pageNumbers2} </Pagination>

                            </reactbootstrap.Tab>
                            </reactbootstrap.Tabs>
                    </reactbootstrap.Modal.Body>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button onClick={() => this.handleCancel()}>{t('Cancel')}</reactbootstrap.Button>
                    &nbsp;&nbsp; &nbsp;&nbsp;
               <reactbootstrap.Button onClick={() => this.handleOk()}>{t('Delete')}</reactbootstrap.Button>
              {this.state.standards_docs.length>0 &&<reactbootstrap.Button onClick={() => this.handleExport()}>{t('Export')}</reactbootstrap.Button>}

                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );
        const filtered = this.state.items;
        let active = this.state.active;
        let pages = [];
        if (this.state.count > 0) {
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }
        }

        return (
            <reactbootstrap.Container>
                <reactbootstrap.Row>
                    <reactbootstrap.Col lg={5} className="pl-0 py-3">
                        {/*<h3 className="mt-2">{t('Standards')} </h3><hr />*/}
                        <div className="mb-2" style={{ display: 'flex', }}>
                            <input type="text"  value ={this.state.searchTerm} className="search-input form-control" placeholder = {t("What are you looking for ?")}  autoFocus  style={{'border-radius': "5px", 'border-color': "#EC661C"}} onChange={this.searchData} /><br />
                            <Can
                              perform = "E_standards"
                              yes = {() => (
                                <div className=" ml-4" style={{cursor: "pointer",alignSelf: 'center'}}  title={t("Add standard")} onMouseOut={(e)=>this.HandleMouseOut(e)}onMouseOver={(e)=>this.handleMouseOver(e)} onClick={(e) => this.changeComponent(e)} variant="link">
                                  <i class="overall-sprite overall-sprite-masterstandc"></i>
                                </div>
                              )}
                            />
                        </div>
                        <Can
                          perform = "R_standards,E_standards,D_standards"
                          yes = {() => (
                          <reactbootstrap.Table responsive bordered hover className="main-data-table">
                              <thead>
                                  <tr style={{backgroundColor: '#EC661C',color: '#fff'}}>
                                      <th>{t('Name')}</th>
                                      <th>{t('Description')}</th>
                                      <th>{t('Actions')}</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  {filtered.map(function (item, key) {
                                    let className = (item.id === this.state.tagId) ? 'active' : 'inactive';

                                      return (<tr>
                                          <td onClick={(e) => this.handleClick(e, item.id)} className={className} >{item.name}</td>
                                          <td onClick={(e) => this.handleClick(e, item.id)} className={className} >{item.description}</td>
                                          <td  className={className} style={{ }}>
                                              <div style={{ display: "flex" }}>
                                              <Can
                                                perform = "E_standards"
                                                yes = {() => (
                                                  <div  title={t("Edit")}  style={{ cursor: "pointer" }} onClick={(e) => this.changeComponent(e, item.id)} variant="link">
                                                    <a href="#"><i title="Edit" class="overall-sprite overall-sprite-myeditc"></i></a>
                                                  </div>
                                                )}
                                              />
                                              <br />
                                              {this.state.component !== 'Standards' &&
                                                <Can
                                                  perform = "D_standards"
                                                  yes = {() => (
                                                    <div title={t("Delete")} className="ml-3" style={{ color: "#007bf8", cursor: "pointer", }} onClick={() => this.handleDeleteStandards(item.id)}>
                                                    <a href="#"><i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec"></i></a>
                                                    </div>
                                                  )}
                                                />
                                              }
                                              </div>
                                          </td>

                                      </tr>)
                                  }, this)
                                  }
                              </tbody>
                          </reactbootstrap.Table>
                          )}
                        />
                        <Can
                          perform = "R_standards,E_standards,D_standards"
                          yes = {() => (
                            <Pagination  style={{width: '530px', overflow: 'auto'}} size="md">{pages}</Pagination>
                          )}
                        />
                        {id && popup}
                    </reactbootstrap.Col>
                    {this.state.component !== 'Standards' &&
                      <Can
                        perform = "R_standards,E_standards"
                        yes = {() => (
                           <reactbootstrap.Col lg={7} className="pl-0 py-3"> {/*<h3 className="mt-2">{t('Standard items')} </h3><hr />*/}
                             <StandardSubManager update={this.update.bind(this)} data={this.state.tagId} tabId={this.state.tabId} changeComponent = {this.state.saveComponent}/>
                           </reactbootstrap.Col>
                        )}
                      />
                    }
                    {this.state.component === 'Standards' && <reactbootstrap.Col lg={7} className="py-3"> {/*<h3 className="mt-4">{t('Create Standard')} </h3>*/}<Standards updateComponent={this.updateComponent.bind(this)} id={this.state.formId}  created = {this.handleCreatedStandard}/></reactbootstrap.Col>}
                </reactbootstrap.Row>
            </reactbootstrap.Container>
        );
    }
}
export default translate(StandardsManager);
