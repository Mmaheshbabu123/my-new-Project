import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import '../Organisations.css';
import { datasave } from '../_services/db_services';
import Col from 'react-bootstrap/Col';
import { Tabs, Tab } from 'react-bootstrap';
import SearchInput, {createFilter} from 'react-search-input';
import Pagination from 'react-bootstrap/Pagination'
import DEFINITIONS from '../Definitions/Definitions';
import adddefinition from './adddefination.png';
import cdef from './cdef.png';
import {translate} from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import Can from '../_components/CanComponent/Can'

const KEYS_TO_FILTERS = ['name','description'];
class DefinationsManager extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      tag :[],
      items:[],
      key:'inused',
      searchTerm: '',
      tagId:'',
      show: false,
      id: '',
      doc_data: [],
      alert:'',
      component:'usedIn',
      saveComponent: '',
      formId:'',
      id:'',
      page: 5,
      active: 1,
      count: 0,
      filterFullList:[],
      img:adddefinition,
      t:props.t,
      didupdate:false,
      itemsUsedIn:[],
      currentPage:1,
      definition:'',
      createddefination:'',
      pageIndex : [6,11,16,22,28,34,40,46,52,58,64,70,76]
    }
    this.searchData = this.searchData.bind(this);
  }
  componentDidMount() {
        datasave.service(window.GET_DEF_LIST,'GET','')
        .then(response => {
          const pageData = this.getPageData(1, response[0]['fullData']);
                const count = this.getCountPage(response[0]['fullData']);
            this.setState({
                tag: response[0]['fullData'],
                tagId:response[0]['firstTag']['id'],
                count: count,
                items : pageData,
            })
        });
  }
  componentDidUpdate(prevProps, prevState) {
    if(prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
        datasave.service(window.GET_DEF_LIST,'GET','')
        .then(response => {

          const pageData = this.getPageData(this.state.active, response[0]['fullData']);
          const count = this.getCountPage(response[0]['fullData']);
            this.setState({
                tag: response[0]['fullData'],
                // TagId:response[0]['firstTag']['id'],
                items:pageData,
                count: count,
                saveComponent: "",
                didupdate:false,
                searchTerm:''
            })
            if(this.state.createddefination != ''){
              this.handleCreatedDefinitionpage(response[0]['fullData'])
              this.setState({
                createddefination :''
              })
            }
        });

  }
}
getCountPage(items) {
    const itemLength = items.length;
    return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
}
componentWillMount() {
    this.setState({ items: this.state.tag })
}
searchData(e) {

  var list = [...this.state.tag];
  let res ='';
  list = list.filter(function (item) {
      if (item.name !== null) {
        res = item.name.toLowerCase().search(
              e.toLowerCase()) !== -1;
      }
      if(res){
        return res;
      }
      else{
        if (item.description !== null) {
          return item.description.toLowerCase().search(
                e.toLowerCase()) !== -1;
        }
      }

  });
    const page_data = this.getPageData(1, list);
    const count = this.getCountPage(list);
    this.setState({
        items: page_data,
        count: count,
        active: 1,
        searchTerm: e,
        filterFullList: list,
    });

}

  handleClick(e, id) {
        this.setState({
          tagId: id,
        });


}
handleDeleteDefinations(id){
  datasave.service(window.GetUsedInDocs_definations+id, 'GET', '')
  .then(response => {
    if(response.length === 0){
 this.setState({
    id: id, show: true,alert:'',itemsUsedIn:[],Delete:true
  })
}else{
  this.setState({
    id: id, show: true,alert:'',itemsUsedIn: response,Delete:false,currentPage:1
  })
}
})
}
handlehide = () => {
  this.setState(
      { show: false }
  )
}
handleCancel() {

  this.setState(
      { show: false }
  )
}
handleOk() {
  const {t} = this.state;
  if(this.state.Delete){
  datasave.service(window.DELETEDEFINATION+this.state.id, 'PUT')
  .then(response => {
              this.setState({
                didupdate:true,
                show: false
              })
  });

  this.state.items.length = this.state.items.length-1;
  if(this.state.items.length === 0)
  {
    this.state.active = this.state.active -1
  }
}else{
  this.setState({show:false})
  OCAlert.alertWarning(t('Unable to delete definitions because its been using in doocuments'), { timeOut: window.TIMEOUTNOTIFICATION});

}

}
changeComponent(e, id){
  this.setState({
    component:'',
    formId:id,
    tagId : id === undefined? this.state.tagId:id
  });
  this.props.tab(true);
}
updateComponent(e){
  this.setState({
      component:'usedIn',
      saveComponent: 1,
  });
  this.props.tab(false);
}
changePage(e,id){
  this.setState({
    page: 5 * id,
    active: id,
  });
}

handleMouseOver(e){
  this.setState({
    img:cdef,
  })
}
changePage(e, id = 1) {
  const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
  const page_data = this.getPageData(id, list);
  this.setState({
      items : page_data,
      active: id,
  });
}
getPageData(id, list = '') {
  const page = this.state.page;
  const items = (list !== '') ? list : this.state.tag;
  const page_data = items.slice(page * (id - 1), page * id);
  return page_data;
}
HandleMouseOut(e){
  this.setState({
      img:adddefinition,
  });
}
handlePageClick(event) {
  this.setState({
      currentPage: Number(event.target.id)
  });
}

handleExport(id){

 var url =window.EXPORT_DEFINATIONS;
 const details = {
   id:id
 }
 datasave.service(url,'PUT',details).then(response =>{
   window.open(response);
   window.close();
 })
}
handleCreatedDefination =(definition) =>{

  this.setState({
    createddefination :definition
  })
  }

handleCreatedDefinitionpage = (definitions)=>{
  console.log(definitions)
  var index = definitions.map(function(e) { return e.name; }).indexOf(this.state.createddefination)

  let id  = definitions[index].id


  var page = Math.floor(index/5)


  if(index%5>0){

      this.changePage('',(page+1));
       this.setState({
          tagId:id
          })
  }else{
          if(this.state.pageIndex.includes(index+1)){
              this.setState({
                  tagId:id
                  })
                  this.changePage('temp',(page+1))
          }else{
              this.setState({
                  tagId:id
                  })
                  if(index ==0 ){
                    this.changePage('temp',1)
                  }else{
                  this.changePage('temp',page)
                  }
          }
     }

}



render() {
  const {id,t,itemsUsedIn,currentPage,page}=this.state;


    const indexOfLastTodo = currentPage * page;
    const indexOfFirstTodo = indexOfLastTodo - page;
    const currentTodos = itemsUsedIn.slice(indexOfFirstTodo, indexOfLastTodo);
    const data = currentTodos.map(item => {
        return (
          <tr>
        <td>{item.d_code}</td>
       <td>{item.d_name}</td>
       <td>{item.f_name}</td>
       <td>{item.m_name}</td>
       </tr>
        )
    });

    const pageNumbers = [];
    if(itemsUsedIn.length > 5) {
        for (let i = 1; i <= Math.ceil(itemsUsedIn.length / page); i++) {
        pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
            {i}
        </Pagination.Item>);
    }
  }

  const popup = (

    <reactbootstrap.Modal
    size="lg"
    show={this.state.show}
    onHide={this.handlehide}
    dialogClassName="modal-90w"
    aria-labelledby="example-custom-modal-styling-title"
  >
    <reactbootstrap.Modal.Header closeButton>
  <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">

  </reactbootstrap.Modal.Title>
  <reactbootstrap.Modal.Body>

     <reactbootstrap.Table responsive striped bordered hover size="sm">
          <thead>
              <tr>
                  <th>{t('Document code')}</th>
                  <th>{t('Document name')}</th>
                  {/* <th> Document version</th> */}
                  <th>{t('Folder name')}</th>
                  <th>{t('Manual name')}</th>
              </tr>
          </thead>
          <tbody>
          {data}
          {this.state.Delete && <tr class =  "text-center"><span style = {{marginLeft:'20px'}} >{t("No record found")}</span></tr>}
          </tbody>
      </reactbootstrap.Table>
      <Pagination size="sm" style={{width: '410px', overflow: 'auto'}} >{pageNumbers}</Pagination>
              </reactbootstrap.Modal.Body>
          </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Footer>
              <reactbootstrap.Button onClick={() => this.handleCancel()}>{t('Cancel')}</reactbootstrap.Button>
              &nbsp;&nbsp; &nbsp;&nbsp;
              <reactbootstrap.Button onClick={() => this.handleOk()}>{t('OK')}</reactbootstrap.Button>
              &nbsp;&nbsp; &nbsp;&nbsp;
              <reactbootstrap.Button onClick={() => this.handleExport(this.state.id)}>{t('Export')}</reactbootstrap.Button>
          </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
  );

  const filtered = this.state.items;
  let active = this.state.active;
  let pages = [];
  if(this.state.count > 0)
  {
    for (let number = 1; number <= this.state.count; number++) {
        pages.push(
          <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
              {number}
          </Pagination.Item>,
                  );
    }
}
  return(
   <reactbootstrap.Container>
  <reactbootstrap.Row>
    <Col lg={6} className="pl-0 py-3">
        {/*<h3 className="mt-2">{t('Definitions')} </h3><hr/>*/}
        <div className="mb-2" style={{ display: 'flex', }}>
        <input type="text" className="search-input form-control" value = {this.state.searchTerm} style={{'border-radius': "5px", 'border-color': "#EC661C"}}  placeholder = {t("What are you looking for ?")}  autoFocus onChange={(e) =>this.searchData(e.target.value)} /><br/>
        <Can
          perform = "E_definitions"
          yes = {() => (
              <div className=" ml-4" style={{cursor: "pointer",alignSelf: 'center'}}  title={t("Add Definition")} onMouseOut={(e)=>this.HandleMouseOut(e)}onMouseOver={(e)=>this.handleMouseOver(e)} onClick={(e) => this.changeComponent(e)} variant="link">
              <i class="overall-sprite overall-sprite-masterdefc"></i>
              </div>
            )}
          />
        </div>

        <Can
          perform = "R_definitions,E_definitions,D_definitions"
          yes = {() => (
          <reactbootstrap.Table responsive bordered hover className="main-data-table">
              <thead>
                  <tr style={{backgroundColor: '#EC661C',color: '#fff'}}>
                      <th>{t('Name')}</th>
                      <th>{t('Description')}</th>
                      <th>{t('Actions')}</th>
                  </tr>
              </thead>
              <tbody>
                  {filtered.map(function(item, key) {
                      let className = (item.id === this.state.tagId) ? 'active': 'inactive';
                      return (<tr>
                          <td className={className} onClick={(e) => this.handleClick(e, item.id)}>{item.name}</td>
                          <td className={className} onClick={(e) => this.handleClick(e, item.id)}>{item.description}</td>
                          <td className={className} style={{}}>
                          <div style={{display: "flex"}}>
                          <Can
                            perform = "E_definitions"
                            yes = {() => (
                                <div  className={className} title={t("Edit")} style={{ cursor: "pointer" }} onClick={(e) => this.changeComponent(e, item.id)} variant="link">
                                  <i title={t("Edit")} class="overall-sprite overall-sprite-myeditc"></i>
                                </div>
                              )}
                            />
                            <br/>
                            {this.state.component ==='usedIn'&&
                                <Can
                                  perform = "D_definitions"
                                  yes = {() => (
                                    <div title={t("Delete")}  className="ml-3"   style ={{color:"#007bf8",cursor:"pointer"}}onClick={() => this.handleDeleteDefinations(item.id)}>
                                      <i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec"></i>
                                    </div>

                                  )}
                                />
                            }
                            {popup}
                         </div>
                          </td>
                              </tr>)
                      },this)
                  }
              </tbody>
          </reactbootstrap.Table>
          )}
        />
        <Can
          perform = "R_definitions,E_definitions,D_definitions"
          yes = {() => (
            <Pagination  style={{width: '530px', overflow: 'auto'}} size="md">{pages}</Pagination>
          )}
        />
    </Col>
    <Can
      perform = "R_definitions"
      yes = {() => (
        <Col lg={6} className="py-3">{/*<h3 className="mt-2">{t('Used in')} </h3><hr/>*/}
          {this.state.component !=='usedIn' && <DEFINITIONS updateComponent = {this.updateComponent.bind(this)} id = {this.state.formId} created = {this.handleCreatedDefination} />}
          {this.state.component ==='usedIn' && <UsedInTable  id = {this.state.tagId} {...this.props}/>}
        </Col>
      )}
    />
  </reactbootstrap.Row>
</reactbootstrap.Container>
  );
  }

}

class UsedInTable extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      data:[],
      id:'',
      page: 5,
      active: 1,
      items:[],
      count:0,
      t:props.t,
    }
  }

  componentWillMount(){
    if(this.props.id!== undefined){
    datasave.service(window.GetUsedInDocs_definations+this.props.id, 'GET', '')
    .then(response => {
      const pageData = this.getPageData(1, response);
      const count = this.getCountPage(response);
         this.setState({
           data:response,
           count: count,
          items : pageData,
         })
    })
  }
  }
  componentDidUpdate(prevProps,prevState){
  if(prevProps.id!== this.props.id){
    datasave.service(window.GetUsedInDocs_definations+this.props.id, 'GET',)
    .then(response => {
      const pageData = this.getPageData(1, response);
      const count = this.getCountPage(response);
         this.setState({
           data:response,
           count: count,
          items : pageData
         })
    })
  }
  }
  getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.data;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;

    }

     getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }


       changePage(e, id = 1) {
        const list = this.state.LayoutLinkedDocs;
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
            createddefination:''
        });
    }
render(){
  const items = this.state.items;



  const data = items.map(item=>{
      return(
      <tr>
       <td>{item.d_code}</td>
       <td>{item.d_name}</td>
       <td>{item.d_version}</td>
       <td>{item.f_code}</td>
       <td>{item.f_name}</td>
    </tr>
      )
    })
    let active = this.state.active;
        let pages = [];
        if (this.state.count > 0)
        for (let number = 1; number <= this.state.count; number++) {
            pages.push(
                <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                    {number}
                </Pagination.Item>,
            );
        }

    return(
      <div>
      <reactbootstrap.Table responsive bordered hover>
          <thead>
              <tr style={{backgroundColor: '#EC661C',color: '#fff'}}>
              <th>{this.props.t('Document code')}</th>
              <th>{this.props.t('Document name')}</th>
              <th>{this.props.t('Document version')}</th>
              <th>{this.props.t('Folder code')}</th>
              <th>{this.props.t('Folder name')}</th>
              </tr>
          </thead>
          <tbody>
          {data}
          </tbody>

      </reactbootstrap.Table>
      <Pagination  style={{width: '530px', overflow: 'auto'}} size="md">{pages}</Pagination>
      </div>

    );
  }
}


export default translate(DefinationsManager);
