import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap';
import '../Organisations.css';
import { datasave } from '../_services/db_services';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import ExternalLinks from '../ExternalLinks/ExternalLinks';
import Pagination from 'react-bootstrap/Pagination';
import addlink from './addhplink.png';
import clink from './clink.png';
import {translate} from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';




class HyperlinksManager extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tag: [],
      key: 'inused',
      searchTerm: '',
      inused: [],
      component: 'usedIn',
      saveComponent: '',
      formId: '',
      id:'',
      page: 5,
      active: 1,
      count:0,
      filterFullList: [],
      img:addlink,
      t:props.t,
      usedIn:[],
      didupdate:false,
      itemsUsedIn:[],
      todosPerPage:5,
      currentPage:1,
      hid:'',
      createdLink:'',
      pageIndex : [6,11,16,22,28,34,40,46,52,58,64,70,76]
    }
    this.searchData = this.searchData.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.changeComponent = this.changeComponent.bind(this);
    this.updateComponent = this.updateComponent.bind(this);
    this.handleExport = this.handleExport.bind(this);
  }
  componentDidMount() {

    datasave.service(window.GET_HYP_LIST, 'GET', '')
      .then(response => {
        const pageData = this.getPageData(1, response[0]);
        const count = this.getCountPage(response[0]);
        this.setState({
          tag: response[0],
          tagId: response[0][0].id,
          count: count,
          items : pageData,
        })
      });

  }
  componentDidUpdate(prevProps, prevState) {
    if (prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
      datasave.service(window.GET_HYP_LIST, 'GET', '')
        .then(response => {
          const pageData = this.getPageData(this.state.active, response[0]);
          const count = this.getCountPage(response[0]);
          this.setState({
            didupdate:false,
            tag: response[0],
            items :pageData,
            // tagId: response[0][0].id,
            count: count,
            saveComponent: "",
            searchTerm:'',
          })
          if(this.state.createdLink !==''){
            this.handleCreatedLinkpage(response[0])
            this.setState({createdLink:''})
          }
        });
    }
  }
  getCountPage(items) {
    const itemLength = items.length;
    return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
}
componentWillMount() {
    this.setState({ items: this.state.tag })
}
searchData(e) {        var list = [...this.state.tag];
        let res ='';
        list = list.filter(function (item) {
            if (item.name !== null) {
              res = item.name.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
            if(res){
              return res;
            }
            else{
              if (item.description !== null) {
                return item.description.toLowerCase().search(
                      e.target.value.toLowerCase()) !== -1;
              }
            }

        });
    const page_data = this.getPageData(1, list);
    const count = this.getCountPage(list);
    this.setState({
        items: page_data,
        count: count,
        active: 1,
        searchTerm: e.target.value,
        filterFullList: list,
    });

}
  handleClick(e, id) {
        this.setState({
          tagId: id,
        });

  }
  handleDeleteLinks(id) {
    datasave.service(window.GetUsedInDocs_links+id, 'GET',)
    .then(response => {
       if(response.length===0){
        this.setState({
          id: id, show: true, alert: '',noDelete:false,itemsUsedIn:[],hid:id
        })
       }else{
         this.setState({
          show: true, alert: '',noDelete:true,itemsUsedIn:response,hid:id
         })
       }



    })
  }
  getchildstate(data){
    this.setState({
      usedIn :data
    })
  }
  handlehide = () => {
    this.setState(
      { show: false }
    )
  }
  handleCancel() {
    this.setState(
      { show: false }
    )
  }
  handleOk() {

    const {id,noDelete,t} =  this.state;

    if(!noDelete){
    datasave.service(window.DELETELINKS+id, 'PUT',)
    .then(response => {
                this.setState({
                  didupdate:true,
                  show: false
                })
    });
    this.state.items.length = this.state.items.length-1;
    if(this.state.items.length === 0)
    {
      this.state.active = this.state.active -1;
    }
  }else{
    this.setState({show:false})
    OCAlert.alertWarning(t('Unable to delete hyperlink because its been using in documents'), { timeOut: window.TIMEOUTNOTIFICATION});
  }
  }
  handleExport(id) {
    var url = window.EXPORT_HYPERLINK_DOCS;
    const details = {
      id:id
    }
    datasave.service(url,'PUT',details).then(response => {
      window.open(response);
      window.close();
    })
  }
  changeComponent(e, id) {
    this.setState({
      component: '',
      formId: id,
      tagId :(id === undefined ? this.state.tagId:id)
    });
    this.props.tab(true);
  }
  updateComponent(e) {
    this.setState({
      component: 'usedIn',
      saveComponent: 1,
    });
    this.props.tab(false);
  }
  changePage(e, id) {
    this.setState({
      page: 5 * id,
      active: id,
    });
  }
  handleMouseOver(e){
    this.setState({
        img:clink,
    })
}
HandleMouseOut(e){
    this.setState({
        img:addlink,
    });
}
changePage(e, id = 1) {
  const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
  const page_data = this.getPageData(id, list);
  this.setState({
      items : page_data,
      active: id,
  });

}
handlePageClick(event) {
  this.setState({
      currentPage: Number(event.target.id)
  });
}
handleCreatedLink =(link) =>{
this.setState({
  createdLink :link
})
}

handleCreatedLinkpage = (links)=>{
  var index = links.map(function(e) { return e.name; }).indexOf(this.state.createdLink)

  let id  = links[index].id


  var page = Math.floor(index/5)


  if(index%5>0){

      this.changePage('',(page+1));
       this.setState({
          tagId:id
          })
  }else{
          if(this.state.pageIndex.includes(index+1)){
              this.setState({
                  tagId:id
                  })
                  this.changePage('temp',page+1)
          }else{
              this.setState({
                  tagId:id
                  })
                  if(index ==0 ){
                    this.changePage('temp',1)
                  }else{
                  this.changePage('temp',page)
                  }
          }
     }

}

getPageData(id, list = '') {
  const page = this.state.page;
  const items = (list !== '') ? list : this.state.tag;
  const page_data = items.slice(page * (id - 1), page * id);
  return page_data;
}
  render() {
    const { id,t, noDelete,itemsUsedIn,todosPerPage,currentPage } = this.state;
    const indexOfLastTodo = currentPage * todosPerPage;
    const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
    const currentTodos = itemsUsedIn.slice(indexOfFirstTodo, indexOfLastTodo);
    const data = currentTodos.map(item => {
        return (
          <tr>
        <td>{item.d_code}</td>
       <td>{item.d_name}</td>
       {/* <td>{item.d_version}</td> */}
       <td>{item.f_name}</td>
       <td>{item.m_name}</td>
       </tr>
        )
    });

    const pageNumbers = [];
    if(itemsUsedIn.length > 5) {
        for (let i = 1; i <= Math.ceil(itemsUsedIn.length / todosPerPage); i++) {
        pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
            {i}
        </Pagination.Item>);
    }
  }
    const popup = (
      <reactbootstrap.Modal
        size="lg"
        show={this.state.show}
        onHide={this.handlehide}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >

        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">

          </reactbootstrap.Modal.Title>
          <reactbootstrap.Modal.Body>



      <reactbootstrap.Table responsive striped bordered hover size="sm">
        <thead>
          <tr>
            <th>{t('Document code')}</th>
            <th>{t('Document name')}</th>

            <th>{t('Folder name')}</th>
            <th>{t('Manual name')}</th>
          </tr>
        </thead>
        <tbody>
          {data}
          {!this.state.noDelete && <tr class =  "text-center"><span style = {{marginLeft:'20px'}} >{t('No records found')}</span></tr>}
        </tbody>
      </reactbootstrap.Table>
        <Pagination size="sm" style={{width: '410px', overflow: 'auto'}} >{pageNumbers}</Pagination>
          </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={() => this.handleCancel()}>{t('Cancel')}</reactbootstrap.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
           <reactbootstrap.Button onClick={() => this.handleOk()}>{t('OK')}</reactbootstrap.Button>
           &nbsp;&nbsp; &nbsp;&nbsp;
           <reactbootstrap.Button onClick={() => this.handleExport(this.state.hid)}>{t('Export')}</reactbootstrap.Button>
        </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
    );
    const filtered = this.state.items;
    let active = this.state.active;
    let pages = [];
    if (this.state.count > 0)
    {
      for (let number = 1; number <= this.state.count; number++) {
        pages.push(
          <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
            {number}
          </Pagination.Item>,
        );
      }
    }
    return (
      <Container>
        <Row>
          <Col lg={6} className="px-0 py-3" style={{marginLeft: '-1'}}>
            {/*<h3 className="mt-2">{t('External Hyperlink')} </h3><hr />*/}
            <div className="mb-2" style={{ display: 'flex', }}>
              <input type="text" className="search-input form-control"  value ={this.state.searchTerm} style={{'border-radius': "5px", 'border-color': "#EC661C"}} placeholder = {t("What are you looking for ?")} autoFocus onChange={this.searchData} /><br />
              <Can
                perform = "E_hyperlink"
                yes = {() => (
                  <div className=" ml-4" style={{cursor: "pointer",alignSelf: 'center'}}  title={t("Add Hyperlink")} onMouseOut={(e)=>this.HandleMouseOut(e)}onMouseOver={(e)=>this.handleMouseOver(e)} onClick={(e) => this.changeComponent(e)} variant="link">
                    <i class="overall-sprite overall-sprite-masterhyperlinkc"></i>
                  </div>
                )}
              />
            </div>
            <Can
              perform = "R_hyperlink,E_hyperlink,D_hyperlink"
              yes = {() => (
              <reactbootstrap.Table responsive bordered hover className="main-data-table">
                <thead>
                  <tr style={{backgroundColor: '#EC661C',color: '#fff'}}>
                    <th>{t('Name')}</th>
                    <th>{t('Description')}</th>
                    <th>{t('Actions')}</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(function (item, key) {
                    let className = (item.id === this.state.tagId) ? 'active' : 'inactive';
                    return (<tr  >
                      <td className={className} onClick={(e) => this.handleClick(e, item.id)}>{item.name}</td>
                      <td className={className} onClick={(e) => this.handleClick(e, item.id)}>{item.description}</td>

                      <td className={className} style={{}}>
                        <div style={{ display: "flex" }}>
                          <Can
                            perform = "E_hyperlink"
                            yes = {() => (
                              <div title={t("Edit")} style={{ cursor: "pointer" }} onClick={(e) => this.changeComponent(e, item.id)} variant="link">
                              <i title={t("Edit")} class="overall-sprite overall-sprite-myeditc"></i>
                              </div>
                            )}
                          />
                          <br />
                          {this.state.component === 'usedIn' &&
                            <Can
                              perform = "D_hyperlink"
                              yes = {() => (
                                 <div title={t("Delete")} className="ml-3" style={{ color: "#007bf8", cursor: "pointer", }} onClick={(e) => this.handleDeleteLinks(item.id)} >
                                   <a href="#"><i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec"></i></a>
                                 </div>
                               )}
                            />
                          }
                        </div>
                      </td>

                    </tr>)
                  }, this)
                  }
                </tbody>
              </reactbootstrap.Table>
              )}
            />
            <Can
              perform = "R_hyperlink,E_hyperlink,D_hyperlink"
              yes = {() => (
                <Pagination style={{width: '530px', overflow: 'auto'}} size="md">{pages}</Pagination>
              )}
            />
          </Col>

              <Col lg={6} className="py-3">{/*<h3 className="mt-2">{t('Used in')}</h3><hr />*/}
                {this.state.component !== 'usedIn' &&
                  <Can
                    perform = "E_hyperlink"
                    yes = {() => (
                        <ExternalLinks updateComponent={this.updateComponent.bind(this)} id={this.state.formId}  created = {this.handleCreatedLink}/>
                      )}
                  />
                }
                {this.state.component === 'usedIn' &&
                  <Can
                    perform = "R_hyperlink"
                    yes = {() => (
                     <UsedInTable useddata = {this.getchildstate.bind(this)} id = {this.state.tagId} {...this.props}/>
                   )}
                 />
                }
              </Col>
        </Row>
        {popup}
      </Container>
    );
  }
}


class UsedInTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data:[],
      id:'',
      page: 5,
      active: 1,
      items:[],
      count:0,
    }
  }
  componentWillMount(){
    if(this.props.id!== undefined){
    datasave.service(window.GetUsedInDocs_links+this.props.id, 'GET', '')
    .then(response => {
      const pageData = this.getPageData(1, response);
      const count = this.getCountPage(response);
      this.props.useddata(response);
         this.setState({
           data:response,
           count: count,
          items : pageData,

         })

    })
  }

  }
  componentDidUpdate(prevProps,prevState){
  if(prevProps.id!== this.props.id){
    datasave.service(window.GetUsedInDocs_links+this.props.id, 'GET',)
    .then(response => {
      const pageData = this.getPageData(1, response);
      const count = this.getCountPage(response);
      this.props.useddata(response);
         this.setState({
           data:response,
           count: count,
          items : pageData,
          active:1,

         })
    })
  }
  }

    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.data;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;

    }

     getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }


       changePage(e, id = 1) {
        const list = this.state.LayoutLinkedDocs;
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });
    }

  render() {
    const items = this.state.items;
const {t} =this.state;
    const data = items.map(item=>{
        return(
        <tr>
         <td>{item.d_code}</td>
         <td>{item.d_name}</td>
         <td>{item.d_version}</td>
         <td>{item.f_code}</td>
         <td>{item.f_name}</td>
      </tr>
        )
      })

      let active = this.state.active;
        let pages = [];
        if (this.state.count > 0)
        for (let number = 1; number <= this.state.count; number++) {
            pages.push(
                <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                    {number}
                </Pagination.Item>,
            );
        }

    return (
      <Can
        perform = "R_hyperlink"
        yes = {() => (
          <div>
            <reactbootstrap.Table responsive bordered hover>
              <thead>
                <tr style={{backgroundColor: '#EC661C',color: '#fff'}}>
                <th>{this.props.t('Document code')}</th>
                <th>{this.props.t('Document name')}</th>
                <th>{this.props.t('Document version')}</th>
                <th>{this.props.t('Folder code')}</th>
                <th>{this.props.t('Folder name')}</th>
                </tr>
              </thead>
              <tbody>
                {data}
              </tbody>
            </reactbootstrap.Table>
            <div>
              <Pagination style={{width: '530px', overflow: 'auto'}} size="md">{pages}</Pagination>
            </div>
        </div>
      )}
      no = {() =>
        <AccessDeniedPage />
      }
    />
    );
  }
}

export default translate(HyperlinksManager);
