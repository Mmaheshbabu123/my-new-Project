import React, { Component } from 'react';
import StandardsFolderStructure from './StandardsFolderStructure';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Pagination from 'react-bootstrap/Pagination'
import Can from '../_components/CanComponent/Can'
import { CanPermissions } from '../_components/CanComponent/CanPermissions';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import {translate} from '../language';


class StandardManagerSub extends React.Component {
    constructor(props) {
        super(props);
        this.state ={
          data:[],
          id:'',
          page: 5,
          active: 1,
          items:[],
          count:0,
          t:props.t,
        }
    }
    componentWillMount(){
        let url = window.GetUsedInDocs_standards+this.props.data;
        datasave.service(url,'GET').then(
            response =>{
              const pageData = this.getPageData(1, response);
              const count = this.getCountPage(response);
              this.setState({
                data:response,
                count: count,
                items : pageData
              })
            }
        )
    }
    componentDidUpdate(prevProps,prevState){

    if(this.props.data!= prevProps.data){
      let url = window.GetUsedInDocs_standards+this.props.data;
        datasave.service(url,'GET').then(
            response =>{
              const pageData = this.getPageData(1, response);
              const count = this.getCountPage(response);
              this.setState({
                data:response,
                count: count,
                items : pageData,
                active:1
              })
            }
        )
    }
    }
    getPageData(id, list = '') {
      const page = this.state.page;
      const items = (list !== '') ? list : this.state.data;
      const page_data = items.slice(page * (id - 1), page * id);
      return page_data;

  }

   getCountPage(items) {
      const itemLength = items.length;
      return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }


     changePage(e, id = 1) {
      const list = this.state.LayoutLinkedDocs;
      const page_data = this.getPageData(id, list);
      this.setState({
          items: page_data,
          active: id,
      });
  }

    render() {
      const link_tab_diable = CanPermissions("R_standards,E_standards", "");
      let link_tab_access = (link_tab_diable) ? '' : 'disabled';
      const usedin_tab_diable = CanPermissions("R_standards", "");
      let usedin_tab_access = (usedin_tab_diable) ? '' : 'disabled';
      const {t} = this.state;

      const items = this.state.items;
      const data = items.map(item=>{
          return(
          <tr>
           <td>{item.d_code}</td>
           <td>{item.d_name}</td>
           <td>{item.d_version}</td>
           <td>{item.f_code}</td>
           <td>{item.f_name}</td>
        </tr>
          )
        })
        let active = this.state.active;
        let pages = [];
        if (this.state.count > 0)
        for (let number = 1; number <= this.state.count; number++) {
            pages.push(
                <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                    {number}
                </Pagination.Item>,
            );
        }

    return(
      <Can
        perform = "R_standards,E_standards"
        yes = {() => (
          <div>
            <reactbootstrap.Tabs defaultActiveKey="home" id="uncontrolled-tab-example">
              <reactbootstrap.Tab disabled = {link_tab_access} eventKey="home" title="Link">
              <Can
                perform = "R_standards,E_standards"
                yes = {() => (
                  <StandardsFolderStructure update={this.props.update} data={this.props.data} tabId={this.props.tabId} changeComponent = {this.props.changeComponent} />
                )}
              />
              </reactbootstrap.Tab>
              <reactbootstrap.Tab disabled = {usedin_tab_access} eventKey="used" title={t("Used in")}>
                <Can
                  perform = "R_standards"
                  yes = {() => (
                    <reactbootstrap.Table responsive bordered hover>
                      <thead>
                        <tr style={{backgroundColor: '#EC661C',color: '#fff'}}>
                        <th>{t('Document code')}</th>
                          <th>{t('Document name')}</th>
                          <th>{t('Document version')}</th>
                          <th>{t('Folder code')}</th>
                          <th>{t('Folder name')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data}
                      </tbody>
                    </reactbootstrap.Table>
                  )}
                />
                <Pagination size="md">{pages}</Pagination>
              </reactbootstrap.Tab>
            </reactbootstrap.Tabs>
          </div>
        )}
        no = { () =>
          <AccessDeniedPage/>
        }
      />
    );


}
}
export default translate(StandardManagerSub);
