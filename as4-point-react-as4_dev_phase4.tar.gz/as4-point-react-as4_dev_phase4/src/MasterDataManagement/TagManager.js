import React, { Component, Suspense } from 'react';
// import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd'
// import ReactDOM from 'react-dom';
import * as reactbootstrap from 'react-bootstrap';
// import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import Pagination from 'react-bootstrap/Pagination'

import { datasave } from '../_services/db_services';
// import FoldersStructure from './FoldersStructure';

// import SearchInput, { createFilter } from 'react-search-input';
import Tags from '../Tags/Tags';
import addtag from './addtagm.png';
import ctag from './ctag.png';
import {translate} from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import Can from '../_components/CanComponent/Can';
const FoldersStructure = React.lazy(() => import('./FoldersStructure'));
// import AccessDeniedPage from '../_components/Errorpages/AccessDenied';

const KEYS_TO_FILTERS = ['name', 'description'];


class TagManager extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tag: [],
            items:[],
            searchTerm: '',
            searchItems:[],
            tagId: '',
            show: false,
            id: '',
            doc_data: [],
            folder_data: [],
            manual_data: [],
            alert: '',
            malert: '',
            falert: '',
            currentPage: 1,
            todosPerPage: 5,
            tabId: '',
            fcurrentPage: 1,
            mcurrentPage: 1,
            component: '',
            saveComponent: '',
            formId: '',
            page: 5,
            active: 1,
            img:addtag,
            count: 0,
            filterFullList: [],
            t:props.t,
            createdTag:'',
            didupdate:undefined,
            pageIndex : [6,11,16,22,28,34,40,46,52,58,64,70,76]
        }
        this.searchData = this.searchData.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.changeComponent = this.changeComponent.bind(this);
        this.handleCreatedTag  = this.handleCreatedTag.bind(this);

    }
    componentDidMount() {
        datasave.service(window.GET_TAGS_LIST, 'GET', '')
            .then(response => {
              if(response.length > 0){
                const pageData = this.getPageData(1, response[0]);
                const count = this.getCountPage(response[0]);
                this.setState({
                    tag: response[0],
                    tagId: response[0][0].id,
                    count: count,
                    items : pageData,
                })
              }
            });
    }
    componentDidUpdate(prevProps, prevState) {
        if (prevState.saveComponent !== this.state.saveComponent || (prevState.didupdate !== this.state.didupdate && this.state.doc_data.length === 0)) {
            this.getDataAfterUpdate();
        }
    }
    getDataAfterUpdate =()=>{
        datasave.service(window.GET_TAGS_LIST, 'GET', '')
        .then(response => {
            if(response!=''){

                const pageData = this.getPageData(this.state.active, response[0]);
                const count = this.getCountPage(response[0]);
                this.setState({
                    tag: response[0],
                    items :pageData,

                    count: count,
                    saveComponent: "",
                    didupdate:undefined,
                    temp:'did',
                    searchTerm:''
                })

                if(this.state.createdTag!=''){

                    this.handleCreatedTagPage(response[0]);
                    this.setState({
                        createdTag:''
                    })
                }

            }else{
                this.setState({
                    tag: [],
                })
            }
        });
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }
    componentWillMount() {
        this.setState({ items: this.state.tag })
    }
    searchData(e) {
        var list = [...this.state.tag];
        let res ='';
        list = list.filter(function (item) {
            if (item.name !== null) {
              res = item.name.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
            if(res){
              return res;
            }
            else{
              if (item.description !== null) {
                return item.description.toLowerCase().search(
                      e.target.value.toLowerCase()) !== -1;
              }
            }

        });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    handleExport() {
        var url = window.EXPORT_TAGS + this.state.tagId;
        datasave.service(url,'PUT','')
        .then(response =>{
          window.open(response)
          window.close();

        })

      }
    handleClick(e, id) {
        e.preventDefault();
        this.setState({
            tagId: id,
            component: '1',

        });
        this.props.tab(false);
    }
    handlePageClick(event) {
        this.setState({
            currentPage: Number(event.target.id)
        });
    }
    handleFolderPageClick(event) {
        this.setState({
            fcurrentPage: Number(event.target.id)
        });
    }
    handleManualPageClick(event) {
        this.setState({
            mcurrentPage: Number(event.target.id)
        });
    }
    handleDeleteTags(id) {
        const url = window.GET_MASTER_DATA_TAGS + id;

        datasave.service(url, 'GET', id).then(
            response => {

                this.setState({ doc_data: response, id: id, show: true,  alert: '', currentPage: 1, mcurrentPage: 1, fcurrentPage: 1})
                if (this.state.doc_data.length == 0) {
                    this.setState({ alert: 'true', currentPage: 1, mcurrentPage: 1, fcurrentPage: 1, id: id  })
                }
            }
        )
    }
    handlehide = () => {
        this.setState(
            { show: false }
        )
    }
    handlepopCancel() {
        this.setState(
            { show: false }
        )
    }
    handleOk() {
        const { id, doc_data, folder_data, manual_data,t } = this.state;

        if (doc_data.length == 0) {
            const url = window.DELETE_TAGS_DATA + id;
            datasave.service(url, 'put', id).then(
                response => {
                    this.setState(
                        { show: false, id: '', didupdate: '1' ,component: 1})
                }
            )
            this.state.items.length = this.state.items.length-1;
            if(this.state.items.length === 0)
            {
                this.state.active = this.state.active - 1
            }
        } else {
            OCAlert.alertWarning(t('Unable to delete tag  because its been using in documents'), { timeOut: window.TIMEOUTNOTIFICATION});
            this.setState(
                { show: false, id: ''}
            )
            // alert("Unlink associated records and try again!")
        }
        // console.log(this.state.didupdate)


    }
    update(e) {
        if (e !== this.state.tabId) {
            this.setState({
                tabId: e,
            });
        }
    }
    changeComponent(e, id) {


        this.setState({
            component: 'Tags',
            formId: (id !== '') ? id : '',
            tagId:(id === undefined? this.state.tagId:id)
        });
        this.props.tab(true);
    }
    updateComponent(e) {
        if (e) {
            this.setState({
                component: 1,
                saveComponent: 1,
            });
            this.props.tab(false);
        }
    }
    handleMouseOver(e){
        this.setState({
            img:ctag,
        })
    }
    HandleMouseOut(e){
        this.setState({
            img:addtag,
        });
    }
    changePage(e, id = 1) {
        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);
        this.setState({
            items : page_data,
            active: id,
            createdTag:'',
        });
    }
    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.tag;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;
    }

    handleCreatedTag (tag){

        this.setState({
            createdTag:tag
        })
    }
    handleCreatedTagPage = (tagslist) =>{

        if(this.state.createdTag!= ''){
        var index = tagslist.map(function(e) { return e.name; }).indexOf(this.state.createdTag)

    let id  = tagslist[index].id


    var page = Math.floor(index/5)

    if(index%5>0){

        this.changePage('',(page+1));
         this.setState({
            tagId:id
            })
    }else{

        this.setState({
            tagId:id
            })
            if(this.state.pageIndex.includes(index+1)){
        this.changePage('temp',page+1)
            }else{
                if(index == 0 ){

                    this.changePage('',1);
                }else{
                this.changePage('temp',page)
                }
            }
    }

        }


    }


    render() {
        const { id,t, doc_data, alert, todosPerPage, currentPage, folder_data, manual_data, mcurrentPage, fcurrentPage, malert, falert } = this.state;
        const indexOfLastTodo = currentPage * todosPerPage;
        const indexOfFirstTodo = indexOfLastTodo - todosPerPage;


        const currentTodos = doc_data.slice(indexOfFirstTodo, indexOfLastTodo);
        const pagerender = currentTodos.map(doc => {
            return <tr><td>{doc.code}</td>
                <td>{doc.name}</td>
                <td>{doc.folder}</td>
                <td>{doc.manual}</td>
            </tr>
        });

        const pageNumbers = [];
        if(doc_data.length > 5) {
            for (let i = 1; i <= Math.ceil(doc_data.length / todosPerPage); i++) {
            pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
                {i}
            </Pagination.Item>);
        }
      }

        const popup = (
            <reactbootstrap.Modal
                size="lg"
                show={this.state.show}
                onHide={this.handlehide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title">
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                    </reactbootstrap.Modal.Title>
                    <reactbootstrap.Modal.Body>
                                <reactbootstrap.Table responsive striped bordered hover size="sm">
                                    <thead>
                                        <tr>
                                            <td>{t('Document code')}</td>
                                            <td>{t('Document name')}</td>
                                            <td>{t('Folder name')}</td>
                                            <td>{t('Manual name')}</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {pagerender}

                                    </tbody>
                                    {alert && <span className=" alert text-center">{t('No  Record found !')}</span>}
                                </reactbootstrap.Table>
                                <Pagination style={{width: '530px', overflow: 'auto'}} size="sm">{pageNumbers}</Pagination>

                    </reactbootstrap.Modal.Body>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button onClick={() => this.handlepopCancel()}>{t('Cancel')}</reactbootstrap.Button>
                    &nbsp;&nbsp; &nbsp;&nbsp;
                <reactbootstrap.Button onClick={() => this.handleOk()}>{t('Delete')}</reactbootstrap.Button>
               {this.state.doc_data.length>0 && <reactbootstrap.Button onClick={() => this.handleExport()}>{t('Export')}</reactbootstrap.Button>}
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );
        const filtered = this.state.items;
        let active = this.state.active;
        let pages = [];
        if(this.state.count > 0)
        {
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }
        }
        return (
            <reactbootstrap.Container>
                <reactbootstrap.Row>
                    <reactbootstrap.Col lg={5} className="pl-0 py-3" style={{marginLeft: '-1px'}}>
                        {/*<h3 className="mt-2">{t('Tags')} </h3><hr />*/}
                        <div className="mb-2" style={{ display: 'flex', }}>
                            <input type="text" value ={this.state.searchTerm} className="search-input form-control" style={{'border-radius': "5px", 'border-color': "#EC661C"}}  placeholder = {t("What are you looking for ?")} autoFocus onChange={this.searchData} /><br />
                            <Can
                              perform = "E_tags"
                              yes = {() => (
                                <div className=" ml-4" style={{cursor: "pointer",alignSelf: 'center'}} title={t("Add tag")}  onMouseOut={(e)=>this.HandleMouseOut(e)} onMouseOver={(e)=>this.handleMouseOver(e)} onClick={(e) => this.changeComponent(e)} variant="link">

                                    <i class="overall-sprite overall-sprite-mastertagc"></i>
                                </div>
                              )}
                            />
                        </div>
                        <Can
                          perform = "R_tags,E_tags,D_tags"
                          yes = {() => (
                          <reactbootstrap.Table responsive bordered hover className="main-data-table">
                              <thead>
                                  <tr style={{backgroundColor: '#EC661C',color: '#fff'}}>
                                      <th>{t('Name')}</th>
                                      <th>{t('Description')}</th>
                                      <th>{t('Actions')}</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  {filtered.map(function (item, key) {
                                    let className = (item.id === this.state.tagId) ? 'active' : 'inactive';
                                      return (<tr>
                                          <td onClick={(e) => this.handleClick(e, item.id)} className={className} >{item.name}</td>
                                          <td onClick={(e) => this.handleClick(e, item.id)} className={className}>{item.description}</td>
                                          <td className={className} style={{}}>
                                              <div style={{ display: "flex" }}>
                                                  <Can
                                                    perform = "E_tags"
                                                    yes = {() => (
                                                      <div title={t("Edit")} style={{ cursor: "pointer" }} onClick={(e) => this.changeComponent(e, item.id)} >
                                                          <i title={t("Edit")} class="overall-sprite overall-sprite-myeditc"></i>
                                                      </div>
                                                    )}
                                                  />
                                                  <br />
                                                  {this.state.component !== 'Tags' &&
                                                  <Can
                                                    perform = "D_tags"
                                                    pageIndex        yes = {() => (
                                                        <div title={t("Delete")} className="ml-3" style={{ color: "#007bf8", cursor: "pointer", }} onClick={() => this.handleDeleteTags(item.id)}>
                                                            <i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec"></i>
                                                        </div >
                                                      )}
                                                    />
                                                  }
                                              </div>
                                          </td>
                                      </tr>)
                                  }, this)
                                  }
                              </tbody>
                          </reactbootstrap.Table>
                          )}
                        />
                        <Can
                          perform = "R_tags,E_tags,D_tags"
                          yes = {() => (
                            <Pagination style={{width: '530px', overflow: 'auto'}} size="md">{pages}</Pagination>
                          )}
                        />
                        {id && popup}
                        {/* {console.log(this.state.tagId,'hello')} */}
                    </reactbootstrap.Col>
                    {this.state.component !== 'Tags' &&
                      <Can
                        perform = "R_tags,E_tags"
                        yes = {() => (
                          <reactbootstrap.Col lg={7} className="py-3" >
                            {/*<h3 className="mt-2" >{t('Tag items')} </h3><hr />*/}
                          <Suspense  fallback = {<div> <p> {t(".....Loading blanco strucutre")} </p></div> }>

                           <FoldersStructure update={this.update.bind(this)} data={this.state.tagId} tabId={this.state.tabId } savecomponent = {this.state.saveComponent}  />
                           </Suspense>
                          </reactbootstrap.Col>
                        )}
                      />
                    }
                    {this.state.component === 'Tags' && <reactbootstrap.Col lg={7} className="py-3"> {/*<h3 className="mt-4">{t('Create tag')} </h3>*/}<Tags updateComponent={this.updateComponent.bind(this)} id={this.state.formId} created = {this.handleCreatedTag} /></reactbootstrap.Col>}
                </reactbootstrap.Row>
            </reactbootstrap.Container>
        );
    }
}
export default translate(TagManager);
