import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import * as reactbootstrap from 'react-bootstrap';
import { Link } from 'react-router-dom';
import TreeMenu from 'react-simple-tree-menu'
import renderhtml from 'react-render-html';
import { datasave } from '../_services/db_services';
import FolderStructure from '../Folder/Folder';
import DocumentStructure from '../Document/Document';
import Select from 'react-select';
import {translate} from '../language';
import { Button, Container, Form, FormGroup, Input, Label, ListGroup, ListGroupItem } from 'reactstrap';
import folderlogo from '../Blanco/folder-icon.png';
import { Draggable, Droppable } from 'react-drag-and-drop'
import { OCAlert } from '@opuscapita/react-alerts';

class DraggableFoldersStructure extends Component {
    constructor(props) {
        super(props)
        this.state = {
            blanco_data: {},
            testdata: "testdata",
            showDocHeader: false,
            showFolder: false,
            credentials: {},
            t:props.t,
        }
        this.dragStart = this.dragStart.bind(this);
    }
    componentDidMount() {
        var url = window.GET_FOLDER_STRUCT;
        datasave.service(url, "GET")
            .then(result => {
                this.displayFolder(result)
            });
    }

    /*
    *@param data takes the folder object which is to be created.
    * Creates an object with the childrens which is specified in data param and sets to the blanco state.
    */
    displayFolder(data) {
        let finalData = {};
        let folderData = data;
        var touched_ids = [];
        Object.keys(folderData).map(function (key) {
            folderData[key].childrens.forEach(function (id) {
                folderData[key].nodes[id] = folderData[id];
                touched_ids.push(id);
            });
            finalData[key] = folderData[key];
        });
        touched_ids.forEach(function (id) {
            delete finalData[id];
        });
        this.setState({
            blanco_data: finalData,
        })
    }
    onDragEnd(){
    }
    render() {
        const {t} = this.state;
        const DEFAULT_PADDING = 16;
        const ICON_SIZE = 8;
        const LEVEL_SPACE = 16;
        const WIDTH = '9%';
        const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }}>{on ? '-' : '+'}</span>;
        const logo = renderhtml('<img  src=' + folderlogo + ' alt="Logo" style="width:5%" />');
        const ListItem = ({
            level = 0,
            key,
            hasNodes,
            isOpen,
            type_id,
            current_type,
            manual_id,
            label,
            searchTerm,
            openNodes,
            ...props,

        }) => (
                < div >
                    <ListGroupItem
                        {...props}
                        style={{
                            paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
                            cursor: 'pointer',
                        }}
                        key={key}
                    >
                        {hasNodes && <ToggleIcon on={isOpen} />}
                        {logo}{label}
                    </ListGroupItem>
                </div >
            );
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-lg-12">
                            <TreeMenu
                                data={this.state.blanco_data}
                                onClickItem={({ key, label, ...props }) => {
                                }}
                                debounceTime={125}>
                                {({ search, items }) => (
                                    <>
                                        <Input onChange={e => search(e.target.value)} placeholder={t("Search")} />
                                        <ListGroup>
                                           {items.map(props => (
                                                <div>
                                                    <Draggable type={props.type_id} data={props.key} onDragStart={(e) => this.dragStart(e, props.type_id, props)}><ListItem {...props} /></Draggable>
                                                </div>
                                            ))}
                                        </ListGroup>
                                    </>
                                )}
                            </TreeMenu>
                        {this.state.showFolder &&
                            <FolderStructure credentials={this.state.credentials} />
                        }
                        {this.state.showDocument &&
                            <DocumentStructure credentials={this.state.credentials}/>
                        }
                    </div>
                </div>
            </div >
        );
    }
    dragStart = (event, type, props) => {
        if(type==='folder')
            {
                OCAlert.alertWarning(t('Folders are not allowed to link to tags!'), { timeOut: window.TIMEOUTNOTIFICATION1});

                // alert('Folders are not allowed to Link to Tags');
            }
  }
}

export default translate(DraggableFoldersStructure)
