import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import './Organisations.css';
import { datasave } from './_services/db_services';
import SearchInput, { createFilter } from 'react-search-input';
import Can from './_components/CanComponent/Can';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import Pagination from 'react-bootstrap/Pagination';
import { translate } from './language';
import { PagePermissions } from './_components/CanComponent/PagePermissions';
import './Languagelist.css'
import Language from './multilangform';
import ManageStrings from './managestrings';
import { createBrowserHistory } from 'history';


const KEYS_TO_FILTERS = ['language']
// import Pagination from "react-js-pagination";
// import axios from 'axios'
const history = createBrowserHistory();
class LanguageList extends Component {
    constructor(props) {
        super(props);
        // this.handleSubmit = this.handleSubmit.bind(this)
        // this.searchUpdated = this.searchUpdated.bind(this);
        this.state = {
            language: [],
            count: 0,
            error: "",
            empty: "",
            items: [],
            searchTerm: '',
            id: '',
            page: 5,
            active: 1,
            filterFullList: [],
            t: props.t,
            // activeTab: 1,
            activeTab: (this.props.match && this.props.match.params && this.props.match.params.id)? 2:1,
        }
        this.searchData = this.searchData.bind(this);
        this.handleSelect = this.handleSelect.bind(this);
    }

    handleSelect(key) {
      this.setState({
        activeTab: key
      });
    }
    componentDidMount() {
        datasave.service(window.GET_ALL_LANGUAGES, 'GET')
            .then(response => {
                const pageData = this.getPageData(1, response);
                const count = this.getCountPage(response);
                this.setState({
                    language: response,
                    count: count,
                    items: pageData,
                });
            });
    }
    componentDidUpdate(prevProps, prevState) {
        if (prevState.saveComponent !== this.state.saveComponent || prevState.didupdate !== this.state.didupdate) {
            datasave.service(window.GET_ALL_LANGUAGES, 'GET', '')
                .then(response => {
                    const pageData = this.getPageData(this.state.active, response);
                    const count = this.getCountPage(response);
                    this.setState({
                        language: response,
                        items: pageData,
                        count: count,
                    })
                });
        }
    }
    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }
    componentWillMount() {
        this.setState({ items: this.state.language })
    }
    searchData(e) {
        var list = [...this.state.language];
        list = list.filter(function (item) {
            if (item.language !== null) {
                return item.language.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
        });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    changePage(e, id = 1) {
        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });
    }
    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.language;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;
    }

    handleDetails(id) {
        var url = window.LANGUAGE_DELETE;
        const details = {
            id: id
        }
        datasave.service(url, 'POST', details)
            .then(response => {
                if (response === 'success') {
                    window.location.reload()
                }
            })
    }

    render() {
        // const filtered = this.state.language.filter(createFilter(this.state.searchTerm, KEYS_TO_FILTERS));
        const as4_or_site = PagePermissions()
        let id = (this.props.match && this.props.match.params && this.props.match.params.id) ? this.props.match.params.id : 0;
        const filtered = this.state.items;
        let active = this.state.active;
        const { t } = this.state
        let pages = [];
        if (this.state.count > 0) {
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }
        }
        return (
            <div className=" row col-md-12">
            <div style={{visibility: 'hidden'}} className="col-md-1"><p>welcome</p></div>
            <div style={{}} className='col-md-11' >
            <reactbootstrap.Tabs activeKey={this.state.activeTab} onSelect={this.handleSelect} id="controlled-tab-example" style={{border:'none'}}>
            <reactbootstrap.Tab eventKey={1} title={t("Manage language")}>

            <Can
                perform="E_language,R_language,D_language"
                yes={() => (
                        <div className="row">
                            <div className="col-md-12 mb-5 mt-5">
                                <div className="card">
                                    <div className="card-body">
                                        <input  className="form-control search-box-border col-md-4 mb-2" placeholder={t("Search")} onChange={this.searchData} /><br />
                                        <form method='POST'>
                                        <div style={{}}>
                                        <reactbootstrap.Table  className="site-table-main" >
                                                <thead>
                                                    <tr>
                                                        <th>{t('String')}</th>
                                                        <th style={{ textAlign: 'right',paddingRight: '1.5rem' }}>{t('Actions')}</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {/* <div style={{textAlign: 'center' }} className="error-block">{this.state.error} */}
                                                    {/* </div> */}
                                                    {filtered.map(
                                                        function (string) {
                                                            return (
                                                                <tr style={{ borderBottom: '1px solid #dee2e6' }}>
                                                                    <td>{t(string.language)}</td>
                                                                    <td style={{ display: 'flex', float: 'right', border: '0px' }}>
                                                                        <Can
                                                                            perform="E_language"
                                                                            yes={() => (
                                                                                <Link style={{ float: 'right', padding: '10px' }}
                                                                                    to={`/language/${string.id}`}
                                                                                    key={string.id}
                                                                                >
                                                                                    {/* {t('Edit')} */}
                                                                                    <i title={t("Edit")}  class="overall-sprite overall-sprite-myeditc"></i>
                                                                                </Link>
                                                                            )}
                                                                        />
                                                                        <br></br>
                                                                        <Can
                                                                            perform="D_language"
                                                                            yes={() => (
                                                                                <a style={{ float: 'right', padding: '10px' }} href='#' onClick={this.handleDetails.bind(this, string.id)}>
                                                                                    {/* {t('Delete')} */}
                                                                                    <i title={t("Delete")} tit class="overall-sprite overall-sprite-mtdeletec"></i>
                                                                                </a>
                                                                            )}
                                                                        />
                                                                    </td>
                                                                </tr>
                                                            )
                                                        }, this)
                                                    }
                                                </tbody>
                                            </reactbootstrap.Table>
                                            </div>
                                            {/* <Pagination size="md">{pages}</Pagination> */}
                                            <div className="page-nation-sec col-md-12">
                                                    <Pagination style={{ width: '500px', overflow: 'auto',scrollbarWidth: 'thin' }} size="md">{pages}</Pagination>
                                                </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>


                )}
                no={() =>
                    <AccessDeniedPage />
                }
            />
            </reactbootstrap.Tab >

            <reactbootstrap.Tab eventKey={2} title={t("Create language")}>
              <Language location={this.props.location} history={history} id={id}/>
              </reactbootstrap.Tab >

            <reactbootstrap.Tab eventKey={3} title={t("Manage strings")}>
            <ManageStrings location={this.props.location}/>

            </reactbootstrap.Tab >
              </reactbootstrap.Tabs>
              </div>
              </div>


        )

    }
}

export default translate(LanguageList)
