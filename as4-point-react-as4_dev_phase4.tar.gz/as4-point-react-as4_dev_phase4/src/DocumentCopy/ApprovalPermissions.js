export default function permissions(status,state) {
  let obj = {
    reviewing_period_days_disabled: false,
    expiration_period_days_disabled: false,
    doc_details_disabled: false,
    show_whats_new_disabled: false,
    rev_details_disabled: false,
    revision_date_behaviour_disabled: false,
    to_review_date_disabled: false,
    communication_disabled: false,
    extra_tab_disabled: false,
    approvalcycle_disabled: false,
    due_date_disabled: false,
    default_tab_disabled: false,
    exp_his_disabled: false,
  }
  if (status === 1 || status === 39 || status === 40||status === 2 ) {
          obj.due_date_disabled= false;
        obj.reviewing_date_disabled=true;

      }
  if (status === 3) {
            obj.doc_details_disabled= true;
            obj.show_whats_new_disabled= false;
            obj.rev_details_disabled= true;
            obj.revision_date_behaviour_disabled= false;
            obj.to_review_date_disabled= (state.reviewing_period_days == '' || state.reviewing_period_days == null) ? false : true;
          obj.extra_tab_disabled= false;
          obj.approvalcycle_disabled= true;
            obj.due_date_disabled= true;
            obj.default_tab_disabled= false;
            obj.roc= true;
            obj.expiration_period_days_disabled= false;
            obj.review_date_disabled= true;
            obj.reviewing_date_disabled=true;

  }
  else if (status === 4 || status === 6 || status === 8) {

            obj.doc_details_disabled= true;
            obj.show_whats_new_disabled= false;
            obj.rev_details_disabled= true;
            obj.revision_date_behaviour_disabled= false;
            obj.to_review_date_disabled= (state.reviewing_period_days == '' || state.reviewing_period_days == null) ? false : true;
            obj.extra_tab_disabled= true;
            obj.approvalcycle_disabled= true;
            obj.due_date_disabled= true;
            obj.default_tab_disabled= true;
            obj.roc= true;
            obj.reviewing_period_days_disabled= false;
            obj.expiration_period_days_disabled= false;
            obj.review_date_disabled= true;
          obj.reviewing_date_disabled=true;

  }
  else if (status === 9) {

            obj.doc_details_disabled= true;
            obj.show_whats_new_disabled= true;
            obj.rev_details_disabled= true;
            obj.revision_date_behaviour_disabled= true;
            obj.to_review_date_disabled= (state.reviewing_period_days == '' || state.reviewing_period_days == null) ? false : true;
            obj.extra_tab_disabled= false;
            obj.approvalcycle_disabled= true;
            obj.due_date_disabled= true;
            obj.default_tab_disabled= true;
            obj.review_date_disabled= true;
            obj.roc= true;
            obj.reviewing_period_days_disabled= false;
            obj.expiration_period_days_disabled= false;
            obj.reviewing_date_disabled=false;

  }
  else if (status === 10 || status === 11 || status === 13 || status === 15 || status === 16 || status === 18) {
      let review_date_disabled = false;
      let to_review_date_disabled = false;
      if (status === 10 || status === 11 || status === 13) {
          review_date_disabled =true;
          // (state.reviewing_period_days === '' || state.reviewing_period_days === null) ? false = true;
      }
      if (status === 15 || status === 16 || status === 18) {
            obj.review_date_disabled = true;
      }
            obj.doc_details_disabled= true;
            obj.show_whats_new_disabled= true;
            obj.rev_details_disabled= true;
            obj.revision_date_behaviour_disabled= true;
            obj.reviewing_date_disabled= true;
            obj.to_review_date_disabled= review_date_disabled;
            obj.extra_tab_disabled= false;
            obj.approvalcycle_disabled= true;
            obj.due_date_disabled= true;
            obj.default_tab_disabled= true;
            obj.roc= true;
            obj.reviewing_period_days_disabled= false;
            obj.expiration_period_days_disabled= false;

  }
else if (status === 39 || status === 40) {
        obj.doc_details_disabled= false;
        obj.show_whats_new_disabled= false;
        obj.rev_details_disabled= false;
        obj.revision_date_behaviour_disabled= false;
        obj.to_review_date_disabled= false;
        obj.extra_tab_disabled= false;
        obj.approvalcycle_disabled= false;
        obj.due_date_disabled= false;
        obj.default_tab_disabled= false;
        obj.roc= false;
        obj.expiration_period_days_disabled= false;
        obj.review_date_disabled= true;
        obj.reviewing_date_disabled=true;

}
else {
        obj.doc_details_disabled= false;
        obj.show_whats_new_disabled= false;
        obj.rev_details_disabled= false;
        obj.revision_date_behaviour_disabled= true;
        obj.to_review_date_disabled= false;
        obj.reviewing_date_disabled= false;
        obj.communication_disabled= false;
        obj.extra_tab_disabled= false;
        obj.approvalcycle_disabled= false;
        obj.due_date_disabled= false;
        obj.default_tab_disabled= false;
        obj.roc= false;
        obj.reviewing_period_days_disabandlepropsled= false;

}

if (status === 22 || status === 23) {
        obj.doc_details_disabled= true;
        obj.show_whats_new_disabled= true;
        obj.rev_details_disabled= true;
        obj.revision_date_behaviour_disabled= true;
        obj.to_review_date_disabled= true;
        obj.extra_tab_disabled= true;
        obj.approvalcycle_disabled= true;
        obj.due_date_disabled= true;
        obj.default_tab_disabled= true;
        obj.reviewing_date_disabled= false;
        obj.exp_his_disabled= true;
        obj.diable_ExpirationPeriod= (status === 22) ? false : true;
        obj.roc= true;
      obj.reviewing_period_days_disabled= true;
      obj.expiration_period_days_disabled= false;

}
return obj;
}
