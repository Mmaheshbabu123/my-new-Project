import React, { useState, useEffect,useCallback,useMemo,useRef } from 'react'
import { PrivateRoute } from '../_components/PrivateRoute'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import 'moment-timezone/builds/moment-timezone-with-data-2012-2022';
import moment from 'moment';
import timezone from 'moment-timezone'
import DocumentComponent from '../_components/DocumentHooksComponents/DocumentComponent';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css';
import { connect } from "react-redux";
import { translate } from '../language';
import Can from '../_components/CanComponent/Can';
import {store } from '../store';
import { OCAlert } from '@opuscapita/react-alerts';
import axios from 'axios';
import permissions from './ApprovalPermissions';
import DocumentContext from './DocumentContext';
import SetDocumentsData from '../Actions/SetDocumentData';
import DocumenTranslation from '../Document/DocumentTitleTranslation';
import FourthCycleComponent from '../_components/DocumentCycleComponent/FourthCycleHook';
import  RevisionDetailsComponent from '../_components/DocumentHooksComponents/details/RevisionDetailsComponent';
// var moment =require('moment');
const mandatory_fields = ['name', 'code', 'layout_id'];
let permissions_data = {
  reviewing_period_days_disabled: false,
  expiration_period_days_disabled: false,
  doc_details_disabled: false,
  show_whats_new_disabled: false,
  rev_details_disabled: false,
  revision_date_behaviour_disabled: false,
  to_review_date_disabled: false,
  communication_disabled: false,
  extra_tab_disabled: false,
  approvalcycle_disabled: false,
  due_date_disabled: false,
  default_tab_disabled: false,
  exp_his_disabled: false,
};
let folder_options = [];

const Document = props => {

      //const manual_options = useFetch(window.GET_FOLDERS_IDS + '/' + props.credentials.manual_id,'GET');
      const [state, setState] = useState({
            get_insert_url:  window.GET_INSERT_DOCUMENT_DETAILS,
            credentials   :     props.credentials,
            cancelPopup   :      props.cancelPopup,
            code: '',
            name: '',
            doc_use_existing_file: '',
            version: '001',
            status: 'New',
            submitted: false,
            parent_folder: '',
            layouts: [],
            layout_id: '',
            reason_of_change: '',
            reason_of_change_text: '',
            doc_types: [],
            doc_type_id: 1,
            cancel:0,
            showComment: false,
            roc: false,
            use_existing_file: '',
            use_existing_file_name: props.t('Choose file'),
            use_existing_file_edit_img: '',
            reason_of_expiration: '',
            reason_of_expiration_extra: '',
            index_doc: 1,
            export_format: 1,
            tags: [],
            standards: [],
            tag_options: [],
            standard_options: [],
            owner_options: [],
            owners: [],
            available_in_masterdata: 1,
            use_in_statistics: 1,
            show_in_whats_new: 1,
            table_of_contents: 1,
            bundle_revise_status:1,
            fundamental: 1,
            webform:1,
            code_error: '',
            name_error: '',
            doc_status: '',
            cycle_status: 3,
            version_error: '',
            parent_folder_error: '',
            layout_error: '',
            type_error: '',
            doc_status_id: 1,
            current_status_id :1,
            use_existing_file_error: '',
            export_format_error: '',
            revision_date:  moment().format('YYYY-MM-DD'),
            to_revsion_date: '',
            to_revision_date: '',
            revision_date_behaviour: '1',
            publish_date: '',
            archive_period_days: '',
            archive_period_type: 'days',
            reviewing_period_days: '',
            reviewing_period_type: 'days',
            reviewing_warning_days: '',
            reviewing_warning_type: 'days',
            reviewing_date: '',
            expiration_period_days: '',
            expiration_period_type: 'days',
            revision_date_error: '',
            publish_date_error: '',
            reviewing_date_error: '',
            notifications: [],
            due_date_days: '',
            spaces: [],
            historical_date: '',
            type:'document',
            clone_credentials:'',
            expired_date: '',
            doc_id: '',
            Bundle_options: [],
            bundle_options_maindoc: [],
            bundles: [],
            selectedmaindocuments: [],       // here................
            spaces_types: [],
            tasks: [],
            items: [],
            types: [],
            selected: [],
            manuals:[],
            parent_id: '',
            active_tab: 1,
            [window.tabs.approval_cycle]: [],
            [window.tabs.r_u_extra]: [],
            [window.tabs.r_u_default]: [],
            [window.tabs.notification]: [],
            [window.tabs.spaces]: [],
            document_flag: [],
            disableFields: false,
            file_id: '',
            file_path: '',
            sucess: '',
            upload_valid: '',
            upload_error: '',
            due_date_disabled: false,
            t: props.t,
            namedata: [],
            codedata: [],
            combined: [],
            both: true,
            diable_ExpirationPeriod: false,
            defaultKeyForSpace : undefined,
            corporate : 0,
            showtranslation : false,
            language_title : [],
            entity_type : 3,
            dataLoading : false,
            show_confirm_popup:true,


    })
    const [approvalCycle,setApprovalCycyle] = useState({
        [window.tabs.approval_cycle]: [],
    });
    const [defaultExtraData,setDefaultExtra] = useState({
      [window.tabs.r_u_extra]:[],
      [window.tabs.r_u_default]:[],
    })
    const [notificationData,setNotification] = useState({
       [window.tabs.notification]:[],
         notifications: [],

    })
    const [spacesData,setSpaces] = useState({
      [window.tabs.spaces]: [],
    })
    const prevState = usePrevious(state,state);
    const prevProps = usePrevious(props,{credentials:{id:-999}});
  //   useEffect(() => {
  // if(prevProps.credentials.manual_id !== props.credentials.manual_id) {
  //     fetchData();
  //   }
  //   },[props.credentials.manual_id])
        let documentData = {};
  async  function  fetchData() {
    await datasave.service(state.get_insert_url, 'GET', '')
         .then(async result => {
             // setState({
             //   ...state,
             documentData ={
                 layouts: result.layouts,
                 doc_types: result.doc_type,
                 spaces: result.spaces,
                 spaces_types: result.spaces_types,
                 tasks: result.rights.jgd,
                 items: result.rights.jgd,
                 types: result.rights.types,
                 standard_options: result.standard_data.standards,
                 tag_options: result.standard_data.tags,
                 owner_options: result.standard_data.owners,
                 Bundle_options: result.bundles,
                 notifications:result.notifications,
                 selected: [],
               }

         })
          props.SetDocumentsData({'value':documentData, 'type': 'DocumentData'});
  }
useEffect(()=>{
  if(prevProps.credentials.manual_id !== props.credentials.manual_id) {
    datasave.service(window.GET_FOLDERS_IDS + '/' + props.credentials.manual_id, 'GET', '')
         .then(result => {
           folder_options  =  result;
         })
  }
},[props.credentials.manual_id])
 useEffect(() => {
   if(props.credentials.action === 'edit')
   {
     SetDocumentsDetails(props.credentials.action)
    }
 },[props.credentials.manual_id,props.credentials.parent_id])
 useEffect(() => {
   props.credentials.manual_flag = 0;
   setState({
      ...state,
      disableFields: (props.credentials.action == 'view') ? true : false,

    })

    // if(props.credentials.action === 'create') {
    //   CreateDocument();
    // }
 },[props.credentials.action,props.credentials.parent_id]);

    const   Getposition = (position = '', sample = 1, template) => {
          var seq = (position) ? position : state.position;
          var s = sample + "";
          while (s.length < seq) {
              s = "0" + s;
          }
          template = template.replace('<NR>', s);
          return template;
      }
    const  GetUpdateCode = (next_fol_id, next_template, next_position) => {
        var next_position = Getposition(next_position, next_fol_id, next_template);
        next_template = (next_template != null) ? next_template : '';
        var combine = next_position;
        return combine;
    }

        const  handleChangenum = useCallback((event) => {
              const { name, value } = event.target;
              const re = /^[0-9\b]+$/;
              if (name == 'reviewing_period_days' && value != '') {
                var rev = state.revision_date;
                rev = (rev !== null)?rev:moment().format('YYYY-MM-DD');
                  var d = moment(rev, 'YYYY-MM-DD').add(value, state.reviewing_period_type);
                  setState({
                     ...state,
                      to_revision_date: d.format('YYYY-MM-DD'),
                      to_review_date_disabled:true,
                      [name]: value,
                  })
              }
              else if (name == 'reviewing_period_days' && value === '') {
                  setState({
                      ...state,
                      to_revision_date: '',
                      to_review_date_disabled:false,
                      [name]: value,
                  })
              }
              if ( (value != ''&& re.test(value))  || value === '') {
                  setState({
                     ...state,
                    [name]: value
                  })
              }
          },[[name]]);
      const  handleChange = useCallback((event) => {
            const { name, value } = event.target;
            if (name == 'code') {
                setState({
                    ...state,
                   [name]: value,
                    code_error: ''
                  });
            }
            else if (name == 'reviewing_period_type') {
                var d = moment(state.revision_date, 'YYYY-MM-DD').add(state.reviewing_period_days, value);
                setState({
                    ...state,
                    to_revision_date: d.format('YYYY-MM-DD'),
                    [name]: value,
                })
            }
            else if(name == 'doc_type_id' && value != state.doc_type_id){
              setState({
                  ...state,
                  use_existing_file_name:null,
                  use_existing_file_edit_img:'',
                  file_path:'',
                  file_id:'',
                  sucess:'',
                  [name]: value,
              })
            }
            else {
                setState({
                    ...state,
                  [name]: value
                });
            }
        },[[name]]);

    const updateImageUpload = (response) => {
        setState({
          ...state,
            sucess: window.FILE_UPLOAD_SUCCESS,
            edit_img: '',
            file_id: response.data.file_id[0],
            file_path: response.data.filepath,
            use_existing_file_name: response.data.filepath
        });

    }



    const  handleChangeReviewdate = (value,type) => {
        var d = moment().format('YYYY-MM-DD');
        if (value != '' && value != null) {
            var rev = moment(d, 'YYYY-MM-DD').add(value, type);
            return rev.format('YYYY-MM-DD')
        }
        else if(value === 0) {
            return d;
        }
        else{
          return null;
        }
      }
    /**
     * clone document from parent document
     */
  const   handleCopyDocument = () =>{
        const { t } = state;
        var url = state.get_insert_url + '/' + props.credentials.parent_id;
        var clone_credentials = props.credentials;
        datasave.service(url, "GET")
            .then(result => {
              // const latest_code = useMemo(()=>GetUpdateCode(result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position),[result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position]);
                var to_revision_date = handleChangeReviewdate(result.document.review_period_days,result.document.review_period_type);
              //  props.credentials.manual_flag = 0;
                var parent_type = props.credentials.parent_type;
                updateTabsData(result);
                setState({
                  ...state,
                    [window.tabs.notification]: result.notifications,
                    [window.tabs.r_u_default]: (result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
                    [window.tabs.r_u_extra]: (result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
                    [window.tabs.approval_cycle]: result.rights,
                    [window.tabs.spaces]: result.spaces,
                    notifications: result.notifications_behaviour,
                    tags: result.tags,
                    owners: result.owners,
                    type:parent_type,
                    clone_credentials :clone_credentials,
                    name: '',
                    export_format: 1,
                    standards: result.standards,
                    disableFields: false,
                    code:GetUpdateCode(result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position),
                    //latest_code,
                    parent_id: result.document.parent_id,
                    manual_id: result.document.parent_id + '-' + result.document.parent_type + '-' + result.document.manual_id,
                    parent_type: result.document.parent_type,
                    version: result.document.version,
                    layout_id: (result.document.layout_id == null) ? '' : result.document.layout_id,
                    layouts: result.layouts,
                    status: 'New',
                    doc_status_id: 1,
                    current_status_id:1,
                    version: '001',
                    sucess:'',
                    parent_id: result.document.parent_id,
                    reason_of_change: '',
                    reason_of_change_text: '',
                    doc_type_id: result.document.doc_type_id,
                    use_existing_file_name: (result.document.file_path == null) ? t('Choose file') : result.document.file_path,
                    use_existing_file_edit_img: (result.document.file_path !== null && result.document.doc_type_id >= 4) ? t('Click here to preview') : '',
                    file_path: result.document.file_path,
                    file_id:result.document.file_id,
                    bundles: result.selected_bundles,
                    selectedmaindocuments: (result.selected_bundles !== undefined) ? result.selected_bundles.filter(items => (items.main_document === 1)) : [],
                    bundle_options_maindoc: result.selected_bundles,
                    reason_of_expiration: result.document.reason_of_expiration,
                    reason_of_expiration_extra: result.document.reason_of_expiration_extra,
                    index_doc: result.document.index_doc,
                    export_format: result.document.export_format,
                    use_in_statistics: (result.document.use_in_statistics !== null)?result.document.use_in_statistics:0,
                    show_in_whats_new: result.document.show_in_whats_new,
                    available_in_masterdata: (result.document.available_in_masterdata !== null)?result.document.available_in_masterdata:0,
                    table_of_contents: (result.document.table_of_contents !== null)?result.document.table_of_contents:0,
                    fundamental: (result.document.fundamental !== null)?result.document.fundamental:0,
                    webform:(result.document.webform !== null)?result.document.webform:0,
                    revision_date: moment().format('YYYY-MM-DD'),
                    revision_date_behaviour: result.document.revision_date_behaviour,
                    archive_period_days: result.document.archive_period_days,
                    archive_period_type: result.document.archive_period_type,
                    reviewing_period_days: result.document.review_period_days,
                    reviewing_period_type: result.document.review_period_type,
                    reviewing_warning_days: result.document.review_warning_days,
                    reviewing_warning_type: result.document.review_warning_type,
                    expiration_period_days: result.document.experiration_period_days,
                    expiration_period_type: result.document.experiration_period_type,
                    publish_date: '',
                    to_revision_date: to_revision_date,
                    reviewing_date: '',
                    due_date_days: '',
                    disableFields: false,
                    corporate:result.document.corporate,
                 dataLoading :true,

                })
                props.credentials.manual_flag = 0;
            });
    }


    /**
     * clone the document from parent folder
     */
  const   handleCopyData = () => {
        const { t } = state;
        if (props.credentials.parent_type === 'document'||props.credentials.parent_type === 'webform') {
            handleCopyDocument();
        }
        else if (props.credentials.parent_type === 'folder') {
            var url = window.GET_FOLDER_DETAILS + props.credentials.parent_id;
            datasave.service(url, "GET")
                .then(result => {
                    props.credentials.manual_flag = 0;
                    var to_revision_date = handleChangeReviewdate(result.folder.review_period_days,result.folder.review_period_type);
                    updateTabsData(result);
                    setState(prevState=>({
                      ...prevState,
                        [window.tabs.notification]: result.notifications,
                        [window.tabs.r_u_default]: (result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
                        [window.tabs.r_u_extra]: (result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
                        [window.tabs.approval_cycle]: result.rights,
                        [window.tabs.spaces]: result.spaces,
                        notifications: result.notifications_behaviour,
                        tags: result.tags,
                        standards: result.standards,
                        bundles:[],
                        selectedmaindocuments:[],
                        bundle_options_maindoc:[],
                        export_format: 1,
                        index_doc: 1,
                        show_in_whats_new: 1,
                        webform:0,
                        name: '',
                        fundamental: 0,
                        status: 'New',
                        version: '001',
                        reason_of_change: '',
                        reason_of_change_text: '',
                        to_revision_date: to_revision_date,
                        table_of_contents: (result.folder.table_of_contents !== null)?result.folder.table_of_contents:0,
                        owners: result.owners,
                        disableFields: false,
                        due_date_disabled: false,
                        doc_status_id: 1,
                        current_status_id:1,
                        doc_type_id :1,
                        publish_date: '',
                        reviewing_date: '',
                        use_existing_file_name: t('Choose file'),
                        use_existing_file_edit_img: '',
                        layout_id: (result.folder.layout_id == null) ? '' : result.folder.layout_id,
                        manual_id: result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id,
                        archive_period_days: result.folder.archive_period_days,
                        revision_date: moment().format('YYYY-MM-DD'),
                        due_date_days: '',
                        archive_period_type: result.folder.archive_period_type,
                        reviewing_period_days: result.folder.review_period_days,
                        reviewing_period_type: result.folder.review_period_type,
                        reviewing_warning_days: result.folder.review_warning_days,
                        reviewing_warning_type: result.folder.review_warning_type,
                        expiration_period_days: result.folder.expiration_behaviour_days,
                        expiration_period_type: result.folder.expiration_behaviour_type,
                        roc: false,
                        sucess:'',
                        bundle_revise_status:1,
                        language_title :[],
                        dataLoading:true,
                    }));

               permissions_data = permissions(1,state);

                });
        }
    }
    /**
     * Edit Document
     */
const   handleDocumentdata = (action,type = 1) => {
        const { t } = state;
        var codedata = [];
        var namedata  = [];
        var combined = [];
        var current_date = moment().format('YYYY-MM-DD');
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        var url = state.get_insert_url + '/' + props.credentials.parent_id + '?pid=' + person_id;
        let url2 = window.GET_USED_DOC_FOR_DOC + '/' + props.credentials.parent_id;
          props.credentials.manual_flag = 0;
        datasave.service(url, "GET")
            .then(  result => {
              if (action === "edit") {
                datasave.service(url2, 'GET').then(
                    response => {
                       codedata = response.code;
                       namedata  = response.name;
                       combined = response.all;
                    })
                  }
                var status_id = result.document.docstatusId;
                if(result.document.docstatusId == 8){
                status_id = (result.document.publish_date <= current_date) ? 6:result.document.docstatusId;
                }
                updateTabsData(result);
                // setApprovalCycyle({
                //   ...approvalCycle,
                //   [window.tabs.approval_cycle]: result.rights,
                // })
                //  setDefaultExtra({
                //    ...defaultExtraData,
                //   [window.tabs.r_u_extra]:(result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
                //   [window.tabs.r_u_default]:(result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
                // })
                // setNotification({
                //   ...notificationData,
                //   [window.tabs.notification]: result.notifications,
                //     notifications: result.notifications_behaviour,
                // })
                // setSpaces({
                //   ...spacesData,
                //   [window.tabs.spaces]: result.spaces,
                // })
                setState(prevState =>({
                  ...prevState,
                    [window.tabs.notification]: result.notifications,
                    [window.tabs.r_u_default]: (result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
                    [window.tabs.r_u_extra]: (result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
                    [window.tabs.approval_cycle]: result.rights,
                    [window.tabs.spaces]: result.spaces,
                    notifications: result.notifications_behaviour,
                    codedata: codedata,
                    namedata: namedata,
                    combined: combined,
                    tags: result.tags,
                    owners: result.owners,
                    standards: result.standards,
                    code: result.document.code,
                    clonecode: result.document.code,
                    pid: person_id,
                    name: result.document.name,
                    clonename: result.document.name,
                    parent_id: result.document.parent_id,
                    manual_id: result.document.parent_id + '-' + result.document.parent_type + '-' + result.document.manual_id,
                    parent_type: result.document.parent_type,
                    version: result.document.version,
                    layout_id: result.document.layout_id,
                    doc_id: result.document.id,
                    doc_status_id: status_id,
                    current_status_id:result.document.docstatusId,
                    due_date_disabled: (window.INITATE_CYCLE.includes(result.document.docstatusId.toString())) ? false : true,
                    layouts: result.layouts,
                    status: result.document.status,
                    parent_id: result.document.parent_id,
                    reason_of_change: result.document.reason_of_change,
                    reason_of_change_text: result.document.reason_of_change_text,
                    doc_type_id: result.document.doc_type_id,
                    use_existing_file_name: (result.document.file_path == null) ? t('Choose file') : result.document.file_path,
                    use_existing_file_edit_img: (result.document.file_path !== null && result.document.doc_type_id >= 4) ? t('Click here to preview') : '',
                    file_path: result.document.file_path,
                    file_id:result.document.file_id,
                    reason_of_expiration: result.document.reason_of_expiration,
                    reason_of_expiration_extra: result.document.reason_of_expiration_extra,
                    index_doc: result.document.index_doc,
                    export_format: result.document.export_format,
                    use_in_statistics: (result.document.use_in_statistics !== null)?result.document.use_in_statistics:0,
                    show_in_whats_new: result.document.show_in_whats_new,
                    available_in_masterdata: (result.document.available_in_masterdata !== null)?result.document.available_in_masterdata:0,
                    table_of_contents: (result.document.table_of_contents !== null)?result.document.table_of_contents:0,
                    revision_date: (result.document.revision_date !== null)?result.document.revision_date:moment().format('YYYY-MM-DD'),
                    revision_date_behaviour: result.document.revision_date_behaviour,
                    publish_date: result.document.publish_date,
                    to_revision_date: result.document.to_revision_date,
                    archive_period_days: result.document.archive_period_days,
                    archive_period_type: result.document.archive_period_type,
                    reviewing_period_days: result.document.review_period_days,
                    reviewing_period_type: result.document.review_period_type,
                    reviewing_warning_days: result.document.review_warning_days,
                    reviewing_warning_type: result.document.review_warning_type,
                    fundamental: (result.document.fundamental !== null)?result.document.fundamental:0,
                    reviewing_date: result.document.reviewing_date,
                    expiration_period_days: result.document.experiration_period_days,
                    expiration_period_type: result.document.experiration_period_type,
                    due_date_days: result.document.due_date_days,
                    disableFields: (action === 'view' || action === 'info') ? true : false,
                    bundles: result.selected_bundles,
                    to_review_date_disabled: (result.document.review_period_days == '' || result.document.review_period_days == null) ? false : true,
                    webform:(result.document.webform == 1)?result.document.webform:0,
                    expired_date: result.document.expired_date,
                    bundle_revise_status:result.document.bundle_revise_status,
                    historical_date: result.document.historical_date,
                    selectedmaindocuments: (result.selected_bundles !== undefined) ? result.selected_bundles.filter(items => (items.main_document === 1)) : [],
                    bundle_options_maindoc: result.selected_bundles,
                    priority: result.priority,
                    cancel:(type ==0)?1:0,
                    sucess:'',
                    corporate : result.document.corporate,
                    dataLoading:true,
                  //  disableFields: (props.credentials.action == 'view') ? true : false,
                })

              );

                if((action === 'edit'))  {
              permissions_data = permissions(status_id,state);
              }
            });

    }
    /**
     * empty document data
     */
    const handleDocumentEmptyData = () => {
        const { t } = state;
            var doc_type_id = 1;
            var  use_existing_file_name = 'Choose file';
            var  use_existing_file_edit_img = '';
            var  file_path = '';
            var  file_id = '';
        var result = [];
        result.folder = [];
        result.standards = [];
        result.tags = [];
        result.spaces = [];
        result.r_u = [];
        result.r_u[1] = [];
        result.notifications = [];
        result.rights = [];
        result.r_u[2] = [];
        props.credentials.manual_flag = 0;
        var parent_type = props.credentials.parent_type;
        updateTabsData(result);
        setState({
          ...state,
            [window.tabs.notification]: result.notifications,
            [window.tabs.r_u_default]: result.r_u[1],
            [window.tabs.r_u_extra]: result.r_u[2],
            [window.tabs.approval_cycle]: result.rights,
            [window.tabs.spaces]: result.spaces,
            tags: result.tags,
            standards: result.standards,
            name: '',
            type:parent_type,
            parent_id: '',
            parent_type: '',
            disableFields: false,
            version: '001',
            layout_id: '',
            status: 'New',
            parent_id: '',
            reason_of_change: '',
            reason_of_change_text: '',
            doc_type_id: doc_type_id,
            use_existing_file_name: use_existing_file_name,
            use_existing_file_edit_img: use_existing_file_edit_img,
            file_path: file_path,
            file_id:file_id,
            owners: [],
            bundles:[],
            selectedmaindocuments:[],
            bundle_options_maindoc:[],
            reason_of_expiration: '',
            reason_of_expiration_extra: '',
            to_revision_date:'',
            index_doc: 1,
            export_format: 1,
            doc_status_id: -1,
            current_status_id: -1,
            reason_of_change: '',
            reason_of_change_text: '',
            available_in_masterdata: 1,
            bundle_revise_status:1,
            use_in_statistics: 1,
            show_in_whats_new: 1,
            table_of_contents: 1,
            fundamental: 0,
            revision_date: moment().format('YYYY-MM-DD'),
            due_date_days: '',
            revision_date_behaviour: 1,
            publish_date: '',
            archive_period_days: '',
            archive_period_type: 'days',
            reviewing_period_days: '',
            reviewing_period_type: 'days',
            reviewing_warning_days: '',
            reviewing_warning_type: 'days',
            reviewing_date: '',
            expiration_period_days: '',
            expiration_period_type: 'days',
            showComment: false,
            sucess:'',
            language_title : [],
             })

    }
const updateTabsData = (result) => {
  setApprovalCycyle({
                  ...approvalCycle,
                  [window.tabs.approval_cycle]: result.rights,
                })
                 setDefaultExtra({
                   ...defaultExtraData,
                  [window.tabs.r_u_extra]:(result.r_u.length > 0) ? result.r_u.filter(item => item.r_u_type === 1) : [],
                  [window.tabs.r_u_default]:(result.r_u.length > 0) ? result.r_u.filter(item2 => item2.r_u_type === 2) : [],
                })
                setNotification({
                  ...notificationData,
                  [window.tabs.notification]: result.notifications,
                    notifications: result.notifications_behaviour,
                })
                setSpaces({
                  ...spacesData,
                  [window.tabs.spaces]: result.spaces,
                })
}



  const  handleDocumentCloneEmptyData = () => {
      const { t } = state;
      if(props.credentials.parent_type == 'document' || props.credentials.parent_type == 'webform') {
          var url = state.get_insert_url + '/' + props.credentials.parent_id;
          }
          else{
      var url = window.GET_FOLDER_DETAILS + props.credentials.parent_id;
          }
      datasave.service(url, "GET")
          .then(result => {
            if(props.credentials.parent_type == 'document'||props.credentials.parent_type == 'webform') {
          var doc_type_id = result.document.doc_type_id;
          var  use_existing_file_name =  (result.document.file_path == null) ? t('Choose file') : result.document.file_path;
          var  use_existing_file_edit_img =  (result.document.file_path !== null && result.document.doc_type_id >= 4) ? t('Click here to preview') : '';
          var  file_path = result.document.file_path;
          var  file_id = result.document.file_id;
          var  webform =(result.document.webform == 1)?result.document.webform:0;
          var parent_id =  result.document.parent_id;
          var manual_id = result.document.parent_id + '-' + result.document.parent_type + '-' + result.document.manual_id;
           var parent_type= result.document.parent_type;
        }else {
          var doc_type_id = 1;
          var  use_existing_file_name = 'Choose file';
          var  use_existing_file_edit_img = '';
          var  file_path = '';
          var  file_id = '';
          var  manual_id = result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id;
          var webform = 0;
        }
      var result = [];
      result.folder = [];
      result.standards = [];
      result.tags = [];
      result.spaces = [];
      result.r_u = [];
      result.r_u[1] = [];
      result.notifications = [];
      result.rights = [];
      result.r_u[2] = [];
      props.credentials.manual_flag = 0;
      var parent_type = props.credentials.parent_type;
      var clone_credentials = props.credentials;
      setState(prevState=>({
        ...prevState,
          [window.tabs.notification]: result.notifications,
          [window.tabs.r_u_default]: result.r_u[1],
          [window.tabs.r_u_extra]: result.r_u[2],
          [window.tabs.approval_cycle]: result.rights,
          [window.tabs.spaces]: result.spaces,
          notifications:(props.DocumentData !== undefined && props.DocumentData.value !== undefined)?props.DocumentData.value.notifications:[],
          tags: result.tags,
          standards: result.standards,
          clone_credentials :clone_credentials,
          name: '',
          type:parent_type,
          parent_type: '',
          disableFields: false,
          version: '001',
          layout_id: '',
          status: 'New',
          parent_id: parent_id,
          manual_id:manual_id,
          reason_of_change: '',
          reason_of_change_text: '',
          doc_type_id: doc_type_id,
          use_existing_file_name: use_existing_file_name,
          use_existing_file_edit_img: use_existing_file_edit_img,
          file_path: file_path,
          file_id:file_id,
          owners: [],
          reason_of_expiration: '',
          reason_of_expiration_extra: '',
          to_revision_date: '',
          index_doc: 1,
          export_format: 1,
          doc_status_id: -1,
          reason_of_change: '',
          reason_of_change_text: '',
          available_in_masterdata: 1,
          bundle_revise_status:1,
          use_in_statistics: 1,
          show_in_whats_new: 1,
          table_of_contents: 1,
          fundamental: 0,
          revision_date: moment().format('YYYY-MM-DD'),
          due_date_days: '',
          revision_date_behaviour: 1,
          publish_date: '',
          archive_period_days: '',
          archive_period_type: 'days',
          reviewing_period_days: '',
          reviewing_period_type: 'days',
          reviewing_warning_days: '',
          reviewing_warning_type: 'days',
          reviewing_date: '',
          expiration_period_days: '',
          expiration_period_type: 'days',
          showComment: false,
          webform:webform,
          sucess:'',
            dataLoading:true,
          language_title : [],
        }))
      })
    }


  // const  handleParentData = () => {
  //       var url = window.GET_FOLDERS_IDS + '/' + props.credentials.manual_id;
  //       datasave.service(url, "GET")
  //           .then(result => {
  //               if (result.length > 0) {
  //                   if (state.manual_id === '') {
  //                       setState({
  //                         ...state,
  //                           manuals: result,
  //                       })
  //
  //                   }
  //                   else {
  //                       setState({
  //                           ...state,
  //                           manuals: result
  //                       })
  //                   }
  //                   props.credentials.manual_flag = 0;
  //               }
  //           });
  //   }

  const  removeFileUpload = () => {
      const {t} = state;
      if(state.file_id != '') {
       var url = window.DELETE_UPLOADED_FILE + '/' + state.file_id;
       datasave.service(url, "POST")
           .then(result => {
               setState({
                   ...state,
                 use_existing_file_name: t('Choose file'),
                 use_existing_file_edit_img: '',
                 sucess : '',
                 file_id: '',
                 file_path: '',
                 file_name:'',
               })
               OCAlert.alertSuccess(t('File deleted successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
          });
      }
    }
const    handleCancel= (event)=>{
        if (props.credentials.action == 'create') {
            props.cancelData();
            handleDocumentEmptyData();
        }
        else if (props.credentials.action == 'edit') {
            props.cancelData();
            handleDocumentEmptyData();

        }
    }
const   handleSubmit = (event) => {
        var formvalid = true;
        event.preventDefault()
        setState({
          ...state,
            submitted: 'true'
        });
        for (var i = 0; i < mandatory_fields.length; i++) {
            if (state[mandatory_fields[i]].length === 0 || state.layout_id == '0' || state.layout_id == '') {
                formvalid = false;
            }

        }

        if (formvalid) {
            if ((state.clonename === state.name) && (state.code === state.clonecode) || props.credentials.action === "create") {
                formSave();
            } else {
                if (state.namedata.length > 0 && state.clonename !== state.name) {
                    if (state.clonecode !== state.code && state.name !== state.clonename) {
                        setState({
                           ...state,
                            show: true, both: false
                        })
                    } else {
                        setState({
                            ...state,
                            show: true
                        })
                    }

                } else {
                    if (state.codedata.length > 0 && state.clonecode !== state.code) {

                        setState({
                           ...state,
                            show: true
                        })
                    } else {
                        formSave();
                    }
                }

            }
        }else {
          OCAlert.alertWarning('You still have empty fields that are required, please fill these in and try again',{timeOut: window.TIMEOUTNOTIFICATION})
        }

    }
const    formSave = () =>{
        const { t } = state;
        const { history } = props
        if (props.credentials.action === 'edit') {
            if (props.credentials.parent_type === 'document') {
                var url = state.get_insert_url + '/' + props.credentials.parent_id;
                datasave.service(url, 'PUT', state)
                    .then(response => {
                        if (response != window.SUCCESS) {
                            setState({
                               ...state,
                                code_error: (response.updatedObjDocument) ? response.updatedObjDocument : '',
                            })
                            OCAlert.alertWarning('Something went wrong,please try again', {timeOut: window.TIMEOUTNOTIFICATION})
                        } else {
                            setState(prevState=>({
                              ...prevState,
                                disableFields: true,
                            }));
                            props.updateFolder(props.credentials.manual_id);
                            OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
                        }
                    })

            }
        } else {
            datasave.service(state.get_insert_url, 'POST', state)
                .then(resultObj => {
                    if (resultObj.updatedObjDocument.datafolder === undefined) {
                        setState({
                            ...state,
                            code_error: (resultObj.updatedObjDocument) ? resultObj.updatedObjDocument : '',

                        })
                        OCAlert.alertWarning('Something went wrong,please try again', {timeOut: window.TIMEOUTNOTIFICATION})
                    }
                    else {
                        props.updateFolder(props.credentials.manual_id, 'D' + resultObj.updatedObjDocument.id);
                        setState({
                           ...state,
                            disableFields: true,
                        });
                        OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
                    }
                })
                .catch(error => {

                })
        }
    }
const handleMultiSelect = (event,type) => {

  setState({
     ...state,
     [type]:event,
   })
}
  const  filterArray = (allList, selectedList) => {
        var pack_func = allList;
        Object.values(selectedList).map(
            function (item, key) {
                pack_func = pack_func.filter(selected => (selected.id !== item.id));
            });
        return pack_func;
    }
  const  handleSelect = (event) => {
        const { name, value } = event.target;
        setState({
           ...state,
            [name]: !state[name],
        })
    }


  const  handleChangeMultiBundle = (event) => {
        let difference = state.bundles.filter(x => !event.includes(x));

        setState({
             ...state,
            bundles: event,
            bundle_options_maindoc: event,
        });
        if (difference.length > 0) {
            var removed_list = state.selectedmaindocuments;
            difference.map(function (items, key) {
                removed_list = removed_list.filter(remove => (remove.value !== items.value))
            }, this);
            setState(prevState => ({
                  ...state,
                selectedmaindocuments: removed_list,
            }));
        }
    }
  const  handleFile = (event) => {
        const { t } = state;
        if (event.target.files[0] !== undefined || event.target.files[0] !== null) {
            setState({
                ...state,
                doc_use_existing_file: event.target.files[0],
                use_existing_file_name: event.target.files[0]['name'],
                use_existing_file_sucess: t('file uploaded sucessfully'),
                use_existing_file_edit_img: '',

            })
            let files = event.target.files || event.dataTransfer.files;
            if (!files.length)
                return;
            createImage(files[0]);
        }
    }
  const  createImage = (file) => {
        let reader = new FileReader();
        reader.onload = (e) => {
            setState({
               ...state,
                doc_use_existing_file: e.target.result
            })
        };
        reader.readAsDataURL(file);
    }
    const updateSelected = (latestDropped, result, type, id = '') => {

        var array = [...state[type]]; // make a separate copy of the array
        if (result.type === 'remove') {
            var filterArray = array.filter(selected => (selected.name !== latestDropped.name));
        }
        if (result.type === 'remove') {
            if(type === 'r_u_extra'|| type === 'r_u_default') {// read and default
              setDefaultExtra({
                ...defaultExtraData,
                [type]:filterArray
              })
            }else if(type === 'spaces_selected'){
              setSpaces({
                  ...spacesData,
                  [type]: filterArray,
                })
            }
            else{
              setState({
                  ...state,
                  [type]: filterArray
              })
            }
        }
      else {
          if(type === 'r_u_extra'|| type === 'r_u_default') {// read and default
            setDefaultExtra(prevState =>({
              ...defaultExtraData,
                [type]: [...prevState[type], latestDropped]
            }))
          }
          else if(type === 'spaces_selected'){
            setSpaces(prevState=>({
                ...spacesData,
                [type]: [...prevState[type], latestDropped],
              }))
          }
          else {
              setState(prevState => ({
                   ...state,
                  [type]: [...prevState[type], latestDropped]
              }));
          }
      }
    };
  const  updateSelectedRights = (latestList) => {
    setApprovalCycyle({
      ...approvalCycle,
      [window.tabs.approval_cycle]: latestList,
    })

    }
  const  handleActiveTab = (key) =>{
        setState({
            ...state,
            active_tab: key,
        });
    }
  const  handleNotification = (latestDropped, result, type, id) => {
        var array = [];
        if (state[type] !== undefined && state[type].length > 0) {
            array = [...state[type]];
            var selectedArrayMatched = array.filter(selected => (selected.n_id === id));
            var selectedArrayUnmatched = array.filter(selected => (selected.n_id !== id));
        }
        if (result.type === 'remove' && array.length > 0) {
            var filterArrayObj = selectedArrayMatched.filter(selected => (selected.id !== latestDropped.id));
            Array.prototype.push.apply(selectedArrayUnmatched, filterArrayObj)
            setNotification({
              ...notificationData,
              [type]: selectedArrayUnmatched,

            })
            // setState({
            //      ...state,
            //     [type]: selectedArrayUnmatched,
            // })
        } else {
            var obj = {};
            Object.keys(latestDropped).forEach(function (key) {
                obj[key] = latestDropped[key];
            })
            obj['n_id'] = id;
            setNotification(prevState => ({
              ...notificationData,
              [type]: [...prevState[type], obj],

            }));
            // setState(prevState => ({
            //      ...state,
            //     [type]: [...prevState[type], obj]
            // }));
        }
    }
  const  handleNotificationSelect = (data) => {
    setNotification({
      ...notificationData,

        notifications: data,
    })
        // setState({
        //     ...state,
        //     notifications: data
        // })
    }
    const handlehide = () =>{
        setState({
           ...state,
            show: false
        })
    }
  const  handlePopOk = () => {
        formSave();
        handlehide()
    }
  const  handleChangeFileUpload = (e) => {
        const { t } = state;
        let Userdata = store.getState();
        let systemsettings = Userdata.UserData.systemsettings;
        let doc_type = state.doc_type_id;
        const name = e.target.files[0].name;
        const lastDot = name.lastIndexOf('.');

        const fileName = name.substring(0, lastDot);
        const ext = name.substring(lastDot + 1);
        const validateType = window.DOC_TYPES_validate[doc_type].includes(ext);
        if (doc_type <= 4 && validateType === false) {
          OCAlert.alertError(t('Please upload respective format ' + window.DOC_TYPES[doc_type]), { timeOut: window.TIMEOUTNOTIFICATION });
          return false;
        }
        let kilobytes = (e.target.files[0]['size'] / 1000).toFixed(1);
        let megabytes = kilobytes / 1024;
        let sizeType = 4;
        let specifiedSize = 1024;
        if (doc_type <= 3) {
          sizeType = systemsettings['18-1'] == undefined ? 4 : parseInt(systemsettings['18-1']);
          specifiedSize = systemsettings['17-1'] == undefined ? 1024 : parseInt(systemsettings['17-1']);
        }
        else if (doc_type > 3) {
          sizeType = systemsettings['20-1'] == undefined ? 4 : parseInt(systemsettings['20-1']);
          specifiedSize = systemsettings['19-1'] == undefined ? 1024 : parseInt(systemsettings['19-1']);
        }

        if (sizeType == 4 && kilobytes > specifiedSize || sizeType == 5 && megabytes > specifiedSize) {
            OCAlert.alertError(t('Size of a document is more than specified size in settings'), { timeOut: window.TIMEOUTNOTIFICATION });
        } else {
            handleUpload(e);
        }
    }
  const  handleUpload = (e) => {
        setState({
           ...state,
            file_name: e.target.files[0]['name'],
            // location: props.state.location,
            // folder: props.state.folder,
        })
        if (e.target.name === 'image') {
            if (e.target.files[0] !== undefined || e.target.files[0] !== null) {
                const formData = new FormData();
                formData.append('file', e.target.files[0])
                const url = window.UPLOAD_FILE + '/' + parseInt(state.doc_type_id);
                document.getElementById("loding-icon").setAttribute("style", "display:block;");
                axios.post(window.backendURL + url, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
                    .then(response => {
                        document.getElementById("loding-icon").setAttribute("style", "display:none;");
                        updateImageUpload(response);
                    })
                    .catch(error => {
                        document.getElementById("loding-icon").setAttribute("style", "display:none;");
                        setState({
                            ...state,
                            errors: error.response.data.errors
                        })
                    })
            }
        }
    }
  const  disableAllTabs = () => {
      setState({
         ...state,
        active_tab : undefined,
      });
    }
  const  handleAddSpace = () => {
      props.actionEdit(props.credentials.parent_id, props.credentials.parent_type, 'edit', props.credentials.addtype, props.credentials.manual_id, props.credentials.access_details);
      setState({
          ...state,
        defaultKeyForSpace : 3,
        active_tab : 1,
      });
    }
  const  handleChangeTransaltion = () => {
        setState({
           ...state,
            showtranslation:true,
        })
    }
  const  handleTranslationCancel = (translatedstring) => {
      setState({
         ...state,
        showtranslation:false,
        language_title : translatedstring,
        entity_type : 3,
      })
    }

        const { clonecode, clonename, code, name, t } = state
        const data1 = state.codedata.map(item => {
            return (
                <tr>
                    <td>{item.code}</td>
                    <td>{item.name}</td>
                </tr>
            )
        })
        const data2 = state.namedata.map(item => {
            return (
                <tr>
                    <td>{item.code}</td>
                    <td>{item.name}</td>
                </tr>
            )
        })
        const data3 = state.combined.map(item => {
            return (
                <tr>
                    <td>{item.code}</td>
                    <td>{item.name}</td>
                </tr>
            )
        })

        const popup = (

            <reactbootstrap.Modal
                size="lg"
                show={state.show}
                onHide={handlehide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title">
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                    </reactbootstrap.Modal.Title>
                    <reactbootstrap.Modal.Body>
                        <reactbootstrap.Tabs id="controlled-tab-example">
                            <reactbootstrap.Tab eventKey={1} title={t("Used in")}>
                                <reactbootstrap.Table striped bordered hover size="sm">
                                    <thead>
                                        <tr>
                                            <th>{t('Document code')}</th>
                                            <th>{t('Document name')}</th>
                                        </tr>
                                    </thead>

                                    {state.both &&
                                        <>
                                            {clonename !== name &&
                                                data1}
                                            {clonecode !== code &&
                                                data2}
                                        </>}

                                    {(clonename !== name) && (clonecode !== code) && data3}
                                </reactbootstrap.Table>
                                {/* <Pagination   size="sm">{pageNumbers}</Pagination> */}
                                <reactbootstrap.Table striped bordered hover size="sm">
                                    <thead>
                                        {clonename !== name &&
                                            <tr>
                                                <th className="taghead" style={{ width: '30%' }}>{t('Previous name')}</th>
                                                <td>{clonename}</td>
                                            </tr>
                                        }
                                        {clonename !== name &&
                                            <tr>
                                                <th className="taghead" style={{ width: '30%' }}>{t('Updated name')}</th>
                                                <td>{name}</td>
                                            </tr>}
                                        {clonecode !== code &&
                                            <tr>
                                                <th className="taghead" style={{ width: '30%' }}>{t('Previous code')}</th>
                                                <td>{clonecode}</td>
                                            </tr>
                                        }{clonecode !== code &&
                                            <tr>
                                                <th className="taghead" style={{ width: '30%' }}>{t('Updated code')}</th>
                                                <td>{code}</td>
                                            </tr>
                                        }
                                    </thead>
                                </reactbootstrap.Table>
                            </reactbootstrap.Tab>
                        </reactbootstrap.Tabs>
                    </reactbootstrap.Modal.Body>
                </reactbootstrap.Modal.Header>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button onClick={() => handlehide()}>{t('Cancel')}</reactbootstrap.Button>
                    &nbsp;&nbsp; &nbsp;&nbsp;
              <reactbootstrap.Button onClick={() => handlePopOk()}>{t('Edit')}</reactbootstrap.Button>
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );


const SetDocumentsDetails = (type) => {
       if (props.credentials.parent_type === 'document' && props.credentials.action !== 'create' ) {
         handleDocumentdata(props.credentials.action);
       }
    //    else {
    // CreateDocument();
    // }
}
const CreateDocument = () => {
  //handleParentData();
  if (props.credentials.action === 'create'&& props.credentials.manual_flag === 1) {
  ConfirmPopup();
}
else if((props.credentials.action === 'view' || props.credentials.action === 'info')&& props.credentials.manual_flag === 1 ) {
  SetDocumentsDetails(props.credentials.action);
}

}
 const  ConfirmPopup = () => {
      const { t } = state;
      let parent_type=props.credentials.parent_type;
      props.credentials.manual_flag = 0;
      var url = (props.credentials.parent_type == 'document' || props.credentials.parent_type == 'webform') ?
      state.get_insert_url + '/' + props.credentials.parent_id :window.GETFOLDERCODEGENERATOR + '/' + props.credentials.parent_id;
      datasave.service(url, "GET")
          .then(result => {
            setState(prevState=>({
              ...prevState,
                code: GetUpdateCode(result.next_code[0].doc_next_id, result.next_code[0].template, result.next_code[0].position),
                manual_id: (props.credentials.parent_type == 'document' || props.credentials.parent_type == 'webform') ? state.manual_id
                :result.folder.id + '-' + window.FOLDER_ENTITY + '-' + result.folder.manual_id,
            }))
          })

      let message='';
      if(parent_type == 'document'){
        message=t('Do you want to copy parent document settings?')
      }
      else if (parent_type == 'folder') {
        message=t('Do you want to copy parent folder settings?')
      }
      confirmAlert({
          title: t('Document settings'),
          message: message,
          buttons: [
              {
                  label: props.t('Yes'),
                  onClick:  () => handleCopyData()
              },
              {
                  label: props.t('No'),
                  onClick:  () =>  handleDocumentCloneEmptyData()
              }
          ]
      });
  };
  const DocumentRender = () => {
    return(
    <div>
                {}
               {state.dataLoading !== false ?
                <DocumentComponent
                  //renderSwitch = {renderSwitch.bind(this)}
                    handleChange={handleChange}
                    handleSubmit={handleSubmit}
                    handleCancel={handleCancel}
                    handleSelect={handleSelect}
                    handleFile={handleFile}
                    handleMultiSelect = {handleMultiSelect}
                    handleChangenum={handleChangenum}
                    updateSelected={updateSelected}
                    handleActiveTab={handleActiveTab}
                    updateSelectedRights={updateSelectedRights}
                    updateImageUpload={updateImageUpload}
                    handleNotification={handleNotification}
                    notificationObject={notificationData}
                    handleNotificationSelect={handleNotificationSelect}
                    handleChangeFileUpload = {handleChangeFileUpload}
                    removeFileUpload = {removeFileUpload}
                    filterArray={filterArray}
                    handleChangeMultiBundle={handleChangeMultiBundle}
                    credentials={props.credentials}
                    handlecycle={props.handleCycle}
                    handleprops={props}
                    appovalCycleObj = {approvalCycle}
                    rdObject = {defaultExtraData}
                    data = {props}
                    handleAddSpace = {handleAddSpace}
                    disableAllTabs = {disableAllTabs}
                    handleChangeTransaltion = {handleChangeTransaltion}
                    details ={state}
                    code_error={state.code_error}
                    spacesExist={state.spaces.length > 0 ? true : false}
                    defaultKeyForSpace = {state.defaultKeyForSpace}
                      corporate={state.corporate}
                      manual_options={folder_options}
                      object={state}
                      disableObj={permissions_data}
                      name_error={state.name_error}
                      spacesObj = {spacesData}
                /> : <div style={{textAlign:'center'}}>
    <reactbootstrap.Spinner animation="grow" variant="success" />
    <p>{t('Loading')}...</p>
  </div> }
        {state.showtranslation &&
        <DocumenTranslation name={state.name} showtranslation={state.showtranslation} handleTranslationCancel={handleTranslationCancel.bind(this)} doc_id={props.credentials.parent_id} parent_type={props.credentials.parent_type} action={props.credentials.action} entity_type={3}></DocumenTranslation>}
      </div>

);

  }
        return (
            <div>
                {CreateDocument()}
                {DocumentRender()}
                {/*props.credentials.action === 'view' && <FourthCycleComponent
                    status_id={state.doc_status_id}
                    credentials={props.credentials}
                    handlecycle={props.handleCycle}
                    todoflow={true}
                    status_name={state.doc_status}
                    doc_id={state.doc_id}
                    webform = {state.webform}
                    rand={Math.random()}
                    priority={state.priority}
                    //spacesExist={spacesExist}
                    bundle_revise_status={state.bundle_revise_status}
                // spacesExist={this.props.spacesExist}
                    handleAddSpace = {handleAddSpace}
                    disableAllTabs = {disableAllTabs}
                />*/}
            </div>


        );
    }

const mapStateToProps = state => ({ ...state });
const mapDispatchToProps = dispatch => ({
  SetDocumentsData: (payload) => dispatch(SetDocumentsData(payload)),
});
export default translate(React.memo(connect(mapStateToProps,mapDispatchToProps)(Document)));
function usePrevious(value, initialValue) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  });
  if (ref.current === undefined && initialValue !== undefined) {
    return initialValue;
  }
  return ref.current;
}
