import React, { useState, useEffect} from 'react'
import FourthCycleComponent from '../_components/DocumentCycleComponent/FourthCycleHook';
import {store } from '../store';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import * as reactbootstrap from 'react-bootstrap';
import DocumentStructure from './Document';
import 'moment-timezone/builds/moment-timezone-with-data-2012-2022';
import moment from 'moment';

const DocumentCycle = (props) => {
  const[state,setState] = useState({
    get_insert_url:window.GET_INSERT_DOCUMENT_DETAILS,
      doc_status_id: 1,
        active_tab: 1,
        defaultKeyForSpace : undefined,
          doc_id: '',
          bundle_revise_status:1,
          webform:1,
          doc_status:'',
          priority:[],
          dataLoading:false,
          show_extended_doc:false,
          credentials : props.credentials,
  })
  // useEffec(()=>{
  //   handleDocumentdata(props.credentials.action);
  //
  // },[props.credentials.parent_id])
  const CreateDocument = () => {
  if(props.credentials.action === 'view'&& props.credentials.manual_flag === 1 ) {
    handleDocumentdata(props.credentials.action);
  }
}
const handleShowDoc = () => {
  props.handleCycle(props.credentials.parent_id, props.credentials.parent_type, 'info', props.credentials.addtype, props.credentials.manual_id, props.credentials.rights, '', 'D' + props.credentials.parent_id,1);
  // setState({
  //   ...state,
  //   show_extended_doc:true,
  // })
}
  const  disableAllTabs = () => {
      setState({
         ...state,
        active_tab : undefined,
      });
    }
  const  handleAddSpace = () => {
      props.actionEdit(props.credentials.parent_id, props.credentials.parent_type, 'edit', props.credentials.addtype, props.credentials.manual_id, props.credentials.access_details);
      setState({
          ...state,
        defaultKeyForSpace : 3,
        active_tab : 1,
      });
    }
  const   handleDocumentdata = (action,type = 1) => {
      props.credentials.manual_flag = 0;
          const { t } = state;
          var current_date = moment().format('YYYY-MM-DD');
          let Userdata = store.getState();
          let person_id = Userdata.UserData.user_details.person_id;
          var url = state.get_insert_url + '/' + props.credentials.parent_id + '?pid=' + person_id;
          datasave.service(url, "GET")
              .then(  result => {
                  var status_id = result.document.docstatusId;
                  if(result.document.docstatusId == 8){
                  status_id = (result.document.publish_date <= current_date) ? 6:result.document.docstatusId;
                  }
                  setState(prevState =>({
                    ...prevState,
                      doc_id: result.document.id,
                      doc_status_id: status_id,
                      current_status_id:result.document.docstatusId,
                      status: result.document.status,
                      webform:(result.document.webform == 1)?result.document.webform:0,
                      bundle_revise_status:result.document.bundle_revise_status,
                      sucess:'',
                      corporate : result.document.corporate,
                      dataLoading:true,
                        priority: result.priority,
                        credentials:props.credentials,
                    //  disableFields: (props.credentials.action == 'view') ? true : false,
                  })

                );

              });

      }

      let css  = (window.MANUAL_HTML_CSS[props.credentials.action] !== undefined)?window.MANUAL_HTML_CSS[props.credentials.action]:{};
      let cycleTypeName = '';
          if ((state.doc_status_id >= 3 && state.doc_status_id <= 9) || state.doc_status_id === 39 || state.doc_status_id === 40) {
                 cycleTypeName = 'Activation cycle';
             }
             else if (state.doc_status_id > 9 && state.doc_status_id <= 14) {
                 cycleTypeName = 'Reviewing cycle';
             }
             else if (state.doc_status_id > 14 && state.doc_status_id <= 19) {
                 cycleTypeName = 'Expiration cycle';
             }
      return (
          <div style = {css}>
            {CreateDocument()}
            {cycleTypeName !== '' && <h6 style = {{'position': 'absolute'}}>{('Current running cycle:')} {(cycleTypeName)}</h6>}
          {  state.dataLoading  && (props.credentials.action === 'view' || props.credentials.action === 'info')&& <FourthCycleComponent
                status_id={state.doc_status_id}
                credentials={state.credentials}
                handlecycle={props.handleCycle}
                todoflow={true}
                status_name={state.doc_status}
                doc_id={state.doc_id}
                webform = {state.webform}
                rand={Math.random()}
                priority={state.priority}
                //spacesExist={spacesExist}
                bundle_revise_status={state.bundle_revise_status}
            // spacesExist={this.props.spacesExist}
                handleAddSpace = {handleAddSpace}
                disableAllTabs = {disableAllTabs}
            />}

            {  <reactbootstrap.Button variant="outline-danger" className="cycle-margin-btn" onClick = {e=>handleShowDoc()}>{'Extended Info'}</reactbootstrap.Button>}
          </div>
          )
}
export default translate(React.memo(DocumentCycle));
