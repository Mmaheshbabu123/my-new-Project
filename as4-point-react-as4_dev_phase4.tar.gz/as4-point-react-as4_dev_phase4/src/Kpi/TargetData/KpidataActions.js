
import React, { useState, useEffect, useRef } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import MultiSelect from '../../_components/MultiSelect';
import { datasave } from '../../_services/db_services';
import DatePicker from "react-datepicker";
import './kpidataaction.css';


const KpidataActions =(props)=>{
  const prevProps = usePrevious(props);
  const t =props.t;
  const [state, setState] = useState({
    sublist : [],
    select_sublist : props.select_sublist,
  //   text_field_value : props.text_field_value,
  //   textbox_value : props.textbox_value,
    date : props.date,
    sublist_type: props.sublist_type,
    operater : props.operater,
  })
  useEffect(()=>{
    setState({
      ...state,
      date:props.date,
      select_sublist : props.select_sublist,
      operater : props.operater
    })
    fetchSublist(props.webelement);
    if(props.kpiId!=0){
      setVariables(props.select_sublist,props.operater,props.date)
    }
  },[])
  useEffect(()=>{
    if(prevProps){
      if(prevProps.webelement!=props.webelement||props.num!=prevProps.num) {
         setState({
          ...state,
          date:props.date,
          select_sublist : props.select_sublist,
          operater : props.operater
        })
        fetchSublist(props.webelement);
        if(props.kpiId!=0){
          setVariables(props.select_sublist,props.operater,props.date)
        }
      }
    }
  },[props])
  

  async function setVariables (select_sublist,operater,date) {
    // if(window.KPI_ACTIONS.includes(props.webelement.type.toString())&&select_sublist!=undefined) {
    //   datasave.service(window.FETCH_WEBELEMENT_DETAILS+'/'+props.webelement.list_id,'GET')
    //   .then(async response=>{
    //     var value =  response.data.filter((menu) =>menu.value==select_sublist)
    //     await setState({
    //       ...state,
    //       select_sublist : value[0],
    //       sublist : response.data,
    //       operater : operater
    //     })
    //   })
    // }
    // else {
      await setState({
        ...state,
        date:date,
        select_sublist : select_sublist,
        operater : operater
      })
    // }
    
  }

  async function fetchSublist (webelement) {
    if(window.KPI_ACTIONS.includes(webelement.type.toString())){
      datasave.service(window.FETCH_WEBELEMENT_DETAILS+'/'+webelement.list_id,'GET')
      .then(async response=>{
        await setState({
          ...state,
          sublist : response.data,
          date:props.date,
        select_sublist : props.select_sublist,
        operater : props.operater
        })
      })

    }
  }
  function setTextField (e,sublist_type) {
    if(props.webelement.type === window.DECIMALFIELD || props.webelement.type === window.NUMERICFIELD || props.webelement.type===window.FORMNUMBER ){
      const re = /^(?:[0-9]*)$/;
      if (re.test(e.target.value)) {
        console.log("if");
        setState({
          ...state,
          select_sublist : e.target.value,
          sublist_type : sublist_type,
        })
      }
      // if(e.target.value.match("[0-9]+(,[0-9]+)*,?")!=null) {
      //   setState({
      //     ...state,
      //     select_sublist : e.target.value,
      //     sublist_type : sublist_type,
      //   })
      // }
      // else {
      //   console.log("else");
      //   setState({
      //     ...state,
      //     select_sublist : e.target.value,
      //     sublist_type : sublist_type,
      //   })
      // }
    }
    else {
      setState({
        ...state,
        select_sublist : e.target.value,
        sublist_type : sublist_type
      })
    }
  }

  useEffect(()=>{
    if(props.type==1) {
      props.targetlist(state)
    }
    else{
      props.actuallist(state)
    }
  },[state])
 
  return(
    <reactbootstrap className=" row ">
    <div className="col-md-12 pr-0" >
    {window.KPI_TOTAL_ACTIONS.includes(props.webelement.type.toString()) &&
      <reactbootstrap.Container className=" pb-4 px-0">
        <reactbootstrap.Form>
        <div>
            {/* <reactbootstrap.FormGroup>
            <reactbootstrap.InputGroup className="  ">
                  <div className="col-md-4 pl-0">
                    <reactbootstrap.InputGroup.Prepend>
                      <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Select operator:")}</reactbootstrap.InputGroup>
                    </reactbootstrap.InputGroup.Prepend>
                  </div>
                  <div class="col-md-8 input-padd webselectfiel" style={{marginLeft: '-9px'}} >
                  <MultiSelect
                    style={{width: '102%'}}
                    options={window.KPI_TRIGGER_OPERATOR}
                    standards={state.operater}
                    handleChange={e => setState({...state,operater:e})}
                    disabled={props.formDisable||props.isDisable}
                    placeholder="Select operator"
                    isMulti={false} />
                  </div>
                </reactbootstrap.InputGroup>
              </reactbootstrap.FormGroup> */}
              <reactbootstrap.FormGroup>
                {window.KPI_TOTAL_ACTIONS.includes(props.webelement.type.toString()) &&
                <reactbootstrap.InputGroup className="  ">
                  <div className="col-md-4 px-0">
                    <reactbootstrap.InputGroup.Prepend>
                      <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Filter:")}</reactbootstrap.InputGroup>
                    </reactbootstrap.InputGroup.Prepend>
                  </div>
                  <div class="col-md-4 mb-2 " style={{marginLeft: '-9px'}}>
                  <MultiSelect
                    style={{width: '102%'}}
                    options={window.KPI_TEXT_OPERATOR_ACTIONS.includes(props.webelement.type.toString())?window.KPI_TEXT_OPERATOR:window.KPI_TRIGGER_OPERATOR}
                    standards={state.operater}
                    handleChange={e => setState({...state,operater:e})}
                    disabled={props.formDisable||props.isDisable}
                    placeholder="Select operator"
                    isMulti={false} />
                    
                    </div>
                  <div class="col-md-4 mb-2 " style={{marginLeft: '-9px'}} >
                  {window.KPI_TEXT_ACTIONS.includes(props.webelement.type.toString()) &&
                    <reactbootstrap.FormControl
                      type="text"
                      name="value"
                      placeholder="Enter value"
                      onChange={(e)=>setTextField(e,1)}
                      value={state.select_sublist}
                      // disabled={props.formDisable||props.isDisable}
                      className="input_sw"
                    />}
                    {props.webelement.type === window.TEXTBOX &&
                     <reactbootstrap.FormControl as="textarea"
                      name="description"
                      placeholder="Enter data"
                      value={state.select_sublist}
                      onChange={(e) => setState({ ...state, select_sublist: e.target.value,sublist_type : 2 })}
                      // disabled={state.isDisable}
                      className="input_sw"
                    />}
                    {props.webelement.type === window.DATEFIELD &&
                    <DatePicker
                      className="form-control input_sw"
                      name="date"
                      selected={ state.date !== undefined &&state.date!=null&&state.date!='' ? new Date(state.date):undefined}
                      onChange={(date) => setState({...state,date:date,sublist_type:3})}
                      // disabled={state.isDisable || state.dateisDisable}
                      dateFormat="dd-MM-yyyy"
                      placeholderText="dd/mm/yyyy"
                      isOutsideRange={() => false}
                    />}
                    {window.KPI_ACTIONS.includes(props.webelement.type.toString())&&
                    <MultiSelect
                    options={state.sublist}
                    standards={state.select_sublist}
                    handleChange={e => setState({...state,select_sublist:e,sublist_type : 4})}
                    disabled={props.formDisable||props.isDisable}
                    placeholder="Select sub list"
                    isMulti={true} />}
                  </div>
                </reactbootstrap.InputGroup>}
            </reactbootstrap.FormGroup>
            </div>
        </reactbootstrap.Form>
      </reactbootstrap.Container>}
    </div>
  </reactbootstrap>
  );
}

export default translate(KpidataActions);
function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
