import React, { useState, useEffect, useRef } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import MultiSelect from '../../_components/MultiSelect';
import { datasave } from '../../_services/db_services';
import QueryBuilder from '../../Webforms/QueryBuilder/QueryBuilder';
import ManageQuery from '../KpiData/ManageQuery';
import KpidataActions from './KpidataActions';
const TargetData =(props)=>{
    const t = props.t;
    const prevProps = usePrevious(props);
    const manualOptions   = (props.allvalues['details']['manualOptions'].length > 0 || props.allvalues['details']['manualOptions'].length === undefined) ? props.allvalues['details']['manualOptions']:[];
    const folderOptions   = (props.allvalues['details']['folderOptions'].length > 0 || props.allvalues['details']['folderOptions'].length === undefined) ? props.allvalues['details']['folderOptions']:[];
    const documentOptions = (props.allvalues['details']['documentOptions'].length > 0 || props.allvalues['details']['documentOptions'].length === undefined) ? props.allvalues['details']['documentOptions']:[];
    const operationOptions =[{
      value : 1,
      label : 'Sum',
    },
    {
      value : 2,
      label : 'Average',
    },
    {
      value : 3,
      label : 'Median',
    },
    {
      value : 4,
      label : 'Min',
    },
    {
      value : 5,
      label : 'Max',
    },
    {
      value : 6,
      label : 'Count',
    },
    {
      value : 7,
      label : 'Standard deviation',
    },
    {
      value : 8,
      label : 'Product',
    }
  ]
    const [state, setState] = useState({
      operationOptions   : props.action === 'Edit' ? operationOptions :  props.allvalues['kpidata']['targetdata']['operationOptions'],

      kpiValueOptions : props.allvalues['kpidata']['targetdata']['kpiValueOptions'],
      target_type     : props.allvalues['kpidata']['targetdata']['target_type'],
      target_value    : props.allvalues['kpidata']['targetdata']['target_value'],
      maximumKPI         : props.allvalues['kpidata']['targetdata']['maximumKPI'],
      minimumKPI         : props.allvalues['kpidata']['targetdata']['minimumKPI'],
      maximumKPI_option  : props.allvalues['kpidata']['targetdata']['maximumKPI_option'],
      minimumKPI_option  : props.allvalues['kpidata']['targetdata']['minimumKPI_option'],
      // folderOptions      : props.action === 'Edit' ? props.allvalues['kpidata']['targetdata']['folderOptions'] : [],
      // documentOptions    : props.action === 'Edit' ? props.allvalues['kpidata']['targetdata']['documentOptions'] : [],
      // webelementOptions  : props.action === 'Edit' ? props.allvalues['kpidata']['targetdata']['webelementOptions'] : [],
      folderOptions      : props.action === 'Create' && props.allvalues['details']['folderOptions'] !==undefined? props.allvalues['details']['folderOptions']:props.allvalues['kpidata']['targetdata']['folderOptions'] ,
      documentOptions    : props.action === 'Create' && props.allvalues['details']['documentOptions'] !==undefined? props.allvalues['details']['documentOptions']:props.allvalues['kpidata']['targetdata']['documentOptions'] ,
      webelementOptions  : props.action === 'Create'? props.allvalues['details']['webelementOptions']:props.allvalues['kpidata']['targetdata']['webelementOptions'] ,
      selectedManuals    : props.action === 'Create'? props.allvalues['details']['selectedManuals']:props.allvalues['kpidata']['targetdata']['selectedManuals'],
      selectedFolders    : props.action === 'Create'? props.allvalues['details']['selectedFolders']:props.allvalues['kpidata']['targetdata']['selectedFolders'],
      selectedWebform    : props.action === 'Create'? props.allvalues['details']['selectedWebform']:props.allvalues['kpidata']['targetdata']['selectedWebform'],
      selectedWebelement : props.allvalues['kpidata']['targetdata']['selectedWebelement'],
      cumulative         : props.allvalues['kpidata']['targetdata']['cumulative'],
      date_type_options  : props.allvalues['kpidata']['targetdata']['date_type_options'],
      individual_targets : props.allvalues['kpidata']['targetdata']['individual_targets'],
      date_type          : props.allvalues['kpidata']['targetdata']['date_type'],
      Submitted : props.Submitted,
      isDisable : false,
      select_sublist :   props.allvalues['kpidata']['targetdata']['select_sublist'],
      // text_field_value : props.allvalues['kpidata']['targetdata']['text_field_value'],
      // textbox_value : props.allvalues['kpidata']['targetdata']['textbox_value'],
      date : props.allvalues['kpidata']['targetdata']['date'],
      sublist_type : props.allvalues['kpidata']['targetdata']['sublist_type'],
      operater : props.allvalues['kpidata']['targetdata']['operater'],
      webelement_type :  props.allvalues['kpidata']['targetdata']['webelement_type'],
      selectedOperation  : props.allvalues['kpidata']['targetdata']['selectedOperation'],


    })
    useEffect (() =>{
      setVariables ();
    },[])

    useEffect (() =>{
      props.allvalues['kpidata']['targetdata']['target_type']  = state.target_type;
      props.allvalues['kpidata']['targetdata']['target_value'] = state.target_value ;
      props.allvalues['kpidata']['targetdata']['maximumKPI_option']      = state.maximumKPI_option;
      props.allvalues['kpidata']['targetdata']['minimumKPI_option']      = state.minimumKPI_option;
      props.allvalues['kpidata']['targetdata']['maximumKPI']             = state.maximumKPI;
      props.allvalues['kpidata']['targetdata']['minimumKPI']             = state.minimumKPI;
      props.allvalues['kpidata']['targetdata']['selectedManuals'] = state.selectedManuals!=undefined?state.selectedManuals:[];
      props.allvalues['kpidata']['targetdata']['selectedFolders'] = state.selectedFolders!=undefined?state.selectedFolders:[];
      props.allvalues['kpidata']['targetdata']['selectedWebform'] = state.selectedWebform!=undefined?state.selectedWebform:[];
      props.allvalues['kpidata']['targetdata']['selectedWebelement'] = state.selectedWebelement!=undefined?state.selectedWebelement:[];
      props.allvalues['kpidata']['targetdata']['cumulative']         = state.cumulative;
      props.allvalues['kpidata']['targetdata']['individual_targets'] = state.individual_targets;
      props.allvalues['kpidata']['targetdata']['date_type']          = state.date_type!=undefined?state.date_type:[];
      props.allvalues['kpidata']['targetdata']['select_sublist']          = state.select_sublist;
      // props.allvalues['kpidata']['targetdata']['text_field_value']          = state.text_field_value;
      // props.allvalues['kpidata']['targetdata']['textbox_value']          = state.textbox_value;
      props.allvalues['kpidata']['targetdata']['date']          = state.date;
      props.allvalues['kpidata']['targetdata']['sublist_type']  = state.sublist_type;
      props.allvalues['kpidata']['targetdata']['operater']          = state.operater;
      props.allvalues['kpidata']['targetdata']['webelement_type']  =  state.webelement_type;
      props.allvalues['kpidata']['targetdata']['selectedOperation']  = state.selectedOperation!=undefined?state.selectedOperation:[];
      props.allvalues['kpidata']['targetdata']['operationOptions']  = state.operationOptions!=undefined?state.operationOptions:[];
     props.allvalues['kpidata']['targetdata']['folderOptions'] = state.folderOptions!=undefined?state.folderOptions:[];
     props.allvalues['kpidata']['targetdata']['documentOptions'] = state.documentOptions!=undefined?state.documentOptions:[];
     props.allvalues['kpidata']['targetdata']['webelementOptions'] = state.webelementOptions!=undefined?state.webelementOptions:[];
      props.kpidataVariables(props.allvalues);
    },[state])

    function setVariables () {
      console.log(props.allvalues['kpidata']['targetdata'],props.allvalues['details']);
     setState({...state,
       // folderOptions      : props.action === 'Edit' ? props.allvalues['kpidata']['targetdata']['folderOptions'] : [],
       // documentOptions    : props.action === 'Edit' ? props.allvalues['kpidata']['targetdata']['documentOptions'] : [],
       // webelementOptions  : props.action === 'Edit' ? props.allvalues['kpidata']['targetdata']['webelementOptions'] : [],
       folderOptions      : props.action === 'Create' && props.allvalues['details']['folderOptions'] !==undefined? props.allvalues['details']['folderOptions']:props.allvalues['kpidata']['targetdata']['folderOptions'] ,
       documentOptions    : props.action === 'Create' && props.allvalues['details']['documentOptions'] !==undefined? props.allvalues['details']['documentOptions']:props.allvalues['kpidata']['targetdata']['documentOptions'] ,
       webelementOptions  : props.action === 'Create'? props.allvalues['details']['webelementOptions']:props.allvalues['kpidata']['targetdata']['webelementOptions'] ,
       target_type       : props.allvalues['kpidata']['targetdata']['target_type'],
       target_value      : props.allvalues['kpidata']['targetdata']['target_value'],
       maximumKPI_option : props.allvalues['kpidata']['targetdata']['maximumKPI_option'] ,
       minimumKPI_option : props.allvalues['kpidata']['targetdata']['minimumKPI_option'] ,
       maximumKPI        : props.allvalues['kpidata']['targetdata']['maximumKPI'],
       minimumKPI        : props.allvalues['kpidata']['targetdata']['minimumKPI'],
       selectedManuals   : props.action === 'Create'? props.allvalues['details']['selectedManuals']:props.allvalues['kpidata']['targetdata']['selectedManuals'],
       selectedFolders   : props.action === 'Create'? props.allvalues['details']['selectedFolders']:props.allvalues['kpidata']['targetdata']['selectedFolders'],
       selectedWebform    : props.action === 'Create'? props.allvalues['details']['selectedWebform']:props.allvalues['kpidata']['targetdata']['selectedWebform'],
       selectedWebelement : props.allvalues['kpidata']['targetdata']['selectedWebelement'],
       cumulative         : props.allvalues['kpidata']['targetdata']['cumulative'],
       individual_targets : props.allvalues['kpidata']['targetdata']['individual_targets'],
       date_type          : props.allvalues['kpidata']['targetdata']['date_type'],
       sublist_type : props.allvalues['kpidata']['targetdata']['sublist_type'],
       operater : props.allvalues['kpidata']['targetdata']['operater'],
       select_sublist : props.allvalues['kpidata']['targetdata']['select_sublist'],
       date : props.allvalues['kpidata']['targetdata']['date'],
       webelement_type : props.allvalues['kpidata']['targetdata']['webelement_type'],
       Submitted       :  props.Submitted,
       isDisable       :  props.action=='View'? true :((props.Submitted === true &&(props.Valid === true && props.nameError=='')) ? true : false),
       selectedOperation  : props.allvalues['kpidata']['targetdata']['selectedOperation'],
       operationOptions   : props.action === 'Edit' ? operationOptions :  props.allvalues['kpidata']['targetdata']['operationOptions'],

     })
   }
    useEffect(() => {
      if(prevProps) {
        if(prevProps.Submitted!= props.Submitted||prevProps.num!=props.num){
           setVariables ();
        }
      }
    })
    const handleChange=(event)=>{
      const {name , value} = event.target;
      setState({...state,
          [name]:value,
          operater : [],
          sublist_type : 0,
          select_sublist : [],
          date : undefined,
          webelement_type : 0,
        })
    }
    const targetMaxMinChanges = (e, name) => {
      let value=(name=='minimumKPI_option'?'minimumKPI':'maximumKPI');
      setState({...state, [name] : e,
                [value]:0})
    }
    const handlenum=(name,value)=>{
      const re = /^[0-9\b]+$/;
        if(value === undefined || value === ''|| re.test(value) ){
          setState({...state,
              [name]:value
            })
          props.allvalues['kpidata'][name] = value;
        }
    }

    const getFieldBasedOnSelection = (target, obj) => {
      if (obj !== undefined) {
        switch (obj.value) {
          case 1:
            return (
              <div class="col-md-8">
                <reactbootstrap.FormControl
                  placeholder="Enter Percentage"
                  onChange={(e)=>handlenum(target,e.target.value)}
                  value={target === 'maximumKPI' ? state.maximumKPI : state.minimumKPI}
                  disabled={state.isDisable}
                  className="input_sw"
                />
              </div>
            );
          case 2:
            return (
              <div class="col-md-8">
                <reactbootstrap.FormControl
                  placeholder="Enter Value"
                  onChange={(e)=>handlenum(target,e.target.value)}
                  value={target === 'minimumKPI' ? state.minimumKPI : state.maximumKPI}
                  disabled={state.isDisable}
                  className="input_sw"
                />
              </div>
            );
          default:
            return (
              <> </>
            );
        }
      }
    }
    const getQueryField = (target, obj) => {
      if (obj !== undefined) {
        switch (obj.value) {
          case 3:
            return (
              <ManageQuery
                  allvalues={props.allvalues}
                  Submitted={state.Submitted} action= {props.action} kpidataVariables={props.kpidataVariables}
                  kpiId={props.id} num={props} Valid={state.Valid} data={target}
                />
            );
         default:
           return (
              <> </>
           );
        }
      }
    }
    const handleManualChange = async (e) => {
      // var ids = await getSelectedIDs(e);
      let folders = folderOptions.filter((menu) =>menu.manual_id==e['value']);
      setState({...state,
            selectedManuals : e,
            folderOptions   : folders,
            selectedWebform  : [],
            selectedFolders  : [],
            selectedWebelement:[],
            selectedOperation  : [],
            documentOptions : [],
            webelementOptions : [],
            operationOptions  : []

      });
    }
    const handleChangeFolders = async (e) => {
       // var ids = await getSelectedIDs(e);
       let docs = documentOptions.filter((menu) =>menu.parent_id==e['value']);
       setState({...state,
            selectedFolders :  e,
            documentOptions : docs,
            selectedWebform : [],
            selectedWebelement :[],
            selectedOperation : [],
            webelementOptions : [],
            operationOptions  : []
         });
     }

     const handleChangeDocs = async (e) => {
           let id = e.value;
           datasave.service(window.FETCHALLWEBELEMENTS + '/'+id ,'GET')
           .then(async response=>{
           await setState({...state,
             selectedWebform   : e,
             webelementOptions : response.data,
             selectedWebelement: [],
             selectedOperation : [],
             operationOptions  : []

           })
           })
       }
     const handleChangeElements = async(e) => {
       setState({...state,
          selectedWebelement :e,
          webelement_type :   e.type,
          operater : [],
          sublist_type : 0,
          select_sublist : [],
          date : undefined,
          selectedOperation : [],
          operationOptions   : operationOptions,

          // webformWarning : false
        });
     }
    const formDisable =  (props.Submitted === true &&(props.Valid === true && props.nameError=='')) ? 'disabled' :(props.action ==='View' ? 'disabled': false);
    const targetlist = async(data)=> {
      await setState({...state,
        select_sublist : data.select_sublist,
        // text_field_value : data.text_field_value,
        // textbox_value : data.textbox_value,
        date : data.date,
        sublist_type : data.sublist_type,
        operater : data.operater,
      })
    }
    const handleChangeOperation=(e)=>{
      setState({...state,
      selectedOperation: e})
    }

  return (
    <reactbootstrap className=" row ">
      <div className="col-md-12" >
        <reactbootstrap.Container className=" pb-4">
           <reactbootstrap.Form>
              <fieldset disabled={formDisable}>
                <reactbootstrap.FormGroup>
                   <div className=" row input-overall-sec ">
                      <reactbootstrap.InputGroup className="  ">
                          <div className="col-md-4">
                               <reactbootstrap.InputGroup.Prepend>
                                   <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Select the target data:')}</p><span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                               </reactbootstrap.InputGroup.Prepend>
                          </div>
                          <div class="col-md-8 input-padd" >
                               <div class="custom-control custom-radio">
                                    <input type="radio" class="custom-control-input" id="value" value ="1" disabled={state.isDisable} checked={state.target_type ==1} onChange={handleChange} name="target_type"/>
                                    <label class="custom-control-label" for="value">Value</label>
                               </div>
                               <div class="custom-control custom-radio">
                                    <input type="radio" class="custom-control-input" id="fields" value ="2" disabled={state.isDisable} checked={state.target_type ==2} onChange={handleChange}  name="target_type"/>
                                    <label class="custom-control-label" for="fields">Fields</label>
                               </div>
                               <div class="custom-control custom-radio">
                                    <input type="radio" class="custom-control-input" id="query" value ="3" disabled={state.isDisable} checked={state.target_type ==3} onChange={handleChange}  name="target_type"/>
                                    <label class="custom-control-label" for="query">Query</label>
                               </div>
                               {state.Submitted && state.target_type == "0" && <div style={{ color: 'red' }} className="error-block">{t('Select target data field is required')}</div>}
                           </div>
                      </reactbootstrap.InputGroup>
                   </div>
                </reactbootstrap.FormGroup>
                {state.target_type ==1 && <reactbootstrap.FormGroup>
                   <div className=" row input-overall-sec ">
                      <reactbootstrap.InputGroup className="  ">
                         <div className="col-md-4">
                              <reactbootstrap.InputGroup.Prepend>
                                  <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Enter value:')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                              </reactbootstrap.InputGroup.Prepend>
                         </div>
                         <div class="col-md-8 input-group input-padd">
                            <div className="col-md-8 input-padd p-0">
                              <reactbootstrap.FormControl
                                  name="target_value"
                                  placeholder="Enter Value"
                                  disabled={state.isDisable}
                                  value={state.target_value}
                                  onChange={(e)=>handlenum('target_value',e.target.value)}
                                  className="input_sw"
                              />
                            </div>
                            {state.Submitted && state.target_value == 0 && <div style={{ color: 'red' }} className="error-block">{t('Enter value field is required')}</div>}
                         </div>
                     </reactbootstrap.InputGroup>
                  </div>
              </reactbootstrap.FormGroup>}
             {state.target_type ==2 && <reactbootstrap.FormGroup>
               <div className=" row input-overall-sec ">
                 <reactbootstrap.InputGroup className="  ">
                   <div className="col-md-4">
                     <reactbootstrap.InputGroup.Prepend>
                       <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Select webform:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                     </reactbootstrap.InputGroup.Prepend>
                   </div>
                   <div class="col-md-8 p-0">
                     <div className="col-md-12 p-0">
                      <div className="row">
                        <div style={{}} className='col-md-12 mb-2' >
                          <MultiSelect
                            options={manualOptions}
                            standards={state.selectedManuals}
                            id="manuals"
                            handleChange={(e) => handleManualChange(e)}
                            isMulti={true}
                            disabled={state.isDisable}
                            isMulti={false}
                            placeholder={'Select manuals'}
                          />
                        </div>
                        <div style={{}} className='col-md-12 mb-2'>
                          <MultiSelect
                            options={state.folderOptions}
                            standards={state.selectedFolders}
                            disabled={state.isDisable}
                            id="folders"
                            isMulti={true}
                            handleChange={(e) => handleChangeFolders(e)}
                            isMulti={false}
                            placeholder={'Select folders'}
                          />
                        </div>
                        <div style={{}} className='col-md-12 mb-2'>
                          <MultiSelect
                            options={state.documentOptions}
                            standards={state.selectedWebform}
                            id="webform"
                            disabled={state.isDisable}
                            handleChange={(e) => handleChangeDocs(e)}
                            isMulti={false}
                            placeholder={'Select webform'}
                          />
                        </div>
                        <div style={{}} className='col-md-12 mb-2'>
                          <MultiSelect
                            options={state.webelementOptions}
                            standards={state.selectedWebelement}
                            disabled={state.isDisable}
                            id="elements"
                            isMulti={true}
                            handleChange={(e) => handleChangeElements(e)}
                            isMulti={false}
                            placeholder={'Select web element'}
                          />
                          {/*{state.Submitted && (state.selectedWebelement === undefined ? true :(state.selectedWebelement.length === 0 ? true : false) )
                            && <div style={{ color: 'red' }} className="error-block">{t('Web element field is required')}</div>}*/}
                        </div>
                        <div style={{}} className='col-md-12 mb-2'>
                            <MultiSelect
                              options={state.operationOptions}
                              standards={state.selectedOperation}
                              disabled={state.isDisable||formDisable}
                              id="operation"
                              isMulti={true}
                              handleChange={(e) => handleChangeOperation(e)}
                              isMulti={false}
                              placeholder={'Select operation'}
                            />
                            {state.Submitted && (state.selectedOperation!==undefined?state.selectedOperation.length==0:true) && <div style={{ color: 'red' }} className="error-block">{t('select operation field is required')}</div>}
                          </div>
                      </div>
                    </div>
                  </div>
                </reactbootstrap.InputGroup>
              </div>
            </reactbootstrap.FormGroup>}
              {state.target_type ==2 && state.selectedWebelement!=undefined&&state.selectedWebelement.length!=0 &&
                <KpidataActions webelement = {state.selectedWebelement}  select_sublist = {state.select_sublist}
                // text_field_value = {state.text_field_value}
                // textbox_value = {state.textbox_value}
                formDisable = {formDisable}
                isDisable = {state.isDisable}
                kpiId = {props.kpiId}
                date = {state.date}
                sublist_type  = {state.sublist_type}
                operater = {state.operater} type={1} targetlist={targetlist} ></KpidataActions>
              }
            {state.target_type ==3 &&  <ManageQuery
                allvalues={props.allvalues}
                Submitted={state.Submitted} action= {props.action} kpidataVariables={props.kpidataVariables}
                kpiId={props.id} num={props} Valid={state.Valid} data={'targetdata'}
                />
            }
            <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                  <reactbootstrap.InputGroup className="  ">
                    <div className="col-md-4">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Minimum KPI:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div class="col-md-8 row m-0 p-0">
                      <div className="col-md-4 p-0">
                        <MultiSelect
                          options={state.kpiValueOptions}
                          standards={state.minimumKPI_option}
                          id="kpi_option2"
                          handleChange={(e) => targetMaxMinChanges(e, 'minimumKPI_option')}
                          isMulti={false}
                          disabled={state.isDisable}
                          placeholder={'Select'}
                        />
                        {state.Submitted && (state.minimumKPI_option.length !==0 ? (state.minimumKPI_option['value'] !== 3 && state.minimumKPI == 0) : false)
                         && <div style={{ color: 'red' }} className="error-block">{t('Minimum KPI field is required')}</div>}
                      </div>
                      <div className="col-md-8 input-padd p-0">
                        {getFieldBasedOnSelection('minimumKPI', state.minimumKPI_option)}
                      </div>
                      <div className="col-md-12 input-padd p-0">
                        {getQueryField('minimumKPI', state.minimumKPI_option)}
                      </div>
                    </div>
                  </reactbootstrap.InputGroup>
                </div>
              </reactbootstrap.FormGroup>
              <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                  <reactbootstrap.InputGroup className="  ">
                    <div className="col-md-4">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Maximum KPI:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div class="col-md-8 row m-0 p-0">
                      <div className="col-md-4 p-0">
                        <MultiSelect
                          options={state.kpiValueOptions}
                          standards={state.maximumKPI_option}
                          id="kpi_option1"
                          handleChange={(e) => targetMaxMinChanges(e, 'maximumKPI_option')}
                          isMulti={false}
                          disabled={state.isDisable}
                          placeholder={'Select'}
                        />
                        {state.Submitted && (state.maximumKPI_option.length !==0 ? (state.maximumKPI_option['value'] !== 3 && state.maximumKPI == 0) : false)
                          && <div style={{ color: 'red' }} className="error-block">{t('Maximum KPI field is required')}</div>}
                      </div>
                      <div className="col-md-8 input-padd p-0">
                        {getFieldBasedOnSelection('maximumKPI', state.maximumKPI_option)}
                      </div>
                      <div className="col-md-12 input-padd p-0">
                        {getQueryField('maximumKPI', state.maximumKPI_option)}
                      </div>
                    </div>
                  </reactbootstrap.InputGroup>
                </div>
              </reactbootstrap.FormGroup>
              <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                  <div className="col-md-4 pl-4">
                    <reactbootstrap.Form.Check
                          className="input-document"
                          onChange={(e) => setState({ ...state, cumulative:!state.cumulative})}
                          name='cumulative'
                          checked={state.cumulative}
                          disabled={state.isDisable}
                          label={t("Cumulative")}
                      />
                  </div>
                  {(state.target_type == 2 || state.target_type == 3) &&  <div className="col-md-4 pl-0">
                    <reactbootstrap.Form.Check
                      className="input-document"
                        onChange={(e) => setState({ ...state, individual_targets:!state.individual_targets})}
                        name='individual_targets'
                        checked={state.individual_targets}
                        disabled={state.isDisable}
                        label={t("Individual targets")}
                    />
                  </div>}
                </div>
              </reactbootstrap.FormGroup>
              {(state.target_type == 2 || state.target_type == 3) && <reactbootstrap.FormGroup>
                  <div className=" row input-overall-sec ">
                    <reactbootstrap.InputGroup className="  ">
                        <div className="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Select date type:')}</p>
                            </reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd" >
                          <div style={{}} className='col-md-12 mb-2 pl-0' >
                            <MultiSelect
                              options={state.date_type_options}
                              standards={state.date_type}
                              id="date_type"
                              handleChange={(e)=>setState({...state, date_type : e})}
                              disabled={state.isDisable}
                              isMulti={false}
                              placeholder={t('Select date type')}
                            />
                          </div>
                         </div>
                    </reactbootstrap.InputGroup>
                  </div>
              </reactbootstrap.FormGroup>}
           </fieldset>
          </reactbootstrap.Form>
        </reactbootstrap.Container>
      </div>
    </reactbootstrap>
  );
  }
  export default translate(TargetData)
  function usePrevious(value) {
  	const ref = useRef();
  	useEffect(() => {
      ref.current = value;
  	}, [value]);
  	return ref.current;
  }
