import React, { useState, useEffect, useRef } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import MultiSelect from '../../_components/MultiSelect';
import { datasave } from '../../_services/db_services';
import ManageQuery from '../KpiData/ManageQuery';
import KpidataActions from '../TargetData/KpidataActions';

const ActualData =(props)=>{
    const t = props.t;
    const prevProps = usePrevious(props);
    const manualOptions   = (props.allvalues['details']['manualOptions'].length > 0 || props.allvalues['details']['manualOptions'].length === undefined) ? props.allvalues['details']['manualOptions']:[];
    const folderOptions   = (props.allvalues['details']['folderOptions'].length > 0 || props.allvalues['details']['folderOptions'].length === undefined) ? props.allvalues['details']['folderOptions']:[];
    const documentOptions = (props.allvalues['details']['documentOptions'].length > 0 || props.allvalues['details']['documentOptions'].length === undefined) ? props.allvalues['details']['documentOptions']:[];
    const operationOptions =[{
                  value : 1,
                  label : 'Sum',
                },
                {
                  value : 2,
                  label : 'Average',
                },
                {
                  value : 3,
                  label : 'Median',
                },
                {
                  value : 4,
                  label : 'Min',
                },
                {
                  value : 5,
                  label : 'Max',
                },
                {
                  value : 6,
                  label : 'Count',
                },
                {
                  value : 7,
                  label : 'Standard deviation',
                },
                {
                  value : 8,
                  label : 'Product',
                }
              ]
    const [state, setState] = useState({
      operationOptions   : props.action === 'Edit' ? operationOptions : props.allvalues['kpidata']['actualdata']['operationOptions'],
      manualOptions      : [],
      // folderOptions      : props.action === 'Edit' ? props.allvalues['kpidata']['actualdata']['folderOptions'] : [],
      // documentOptions    : props.action === 'Edit' ? props.allvalues['kpidata']['actualdata']['documentOptions'] : [],
      // webelementOptions  : props.action === 'Edit' ? props.allvalues['kpidata']['actualdata']['webelementOptions'] : [],
      folderOptions      : props.action === 'Create' && props.allvalues['details']['folderOptions'] !==undefined? props.allvalues['details']['folderOptions']:props.allvalues['kpidata']['actualdata']['folderOptions'] ,
      documentOptions    : props.action === 'Create' && props.allvalues['details']['documentOptions'] !==undefined? props.allvalues['details']['documentOptions']:props.allvalues['kpidata']['actualdata']['documentOptions'] ,
      webelementOptions  : props.action === 'Create'? props.allvalues['details']['webelementOptions']:props.allvalues['kpidata']['actualdata']['webelementOptions'],
      selectedManuals    : props.action === 'Create'? props.allvalues['details']['selectedManuals']:props.allvalues['kpidata']['actualdata']['selectedManuals'],
      selectedFolders    : props.action === 'Create'? props.allvalues['details']['selectedFolders']:props.allvalues['kpidata']['actualdata']['selectedFolders'],
      selectedWebform    : props.action === 'Create'? props.allvalues['details']['selectedWebform']:props.allvalues['kpidata']['actualdata']['selectedWebform'],
      selectedWebelement : props.allvalues['kpidata']['actualdata']['selectedWebelement'],
      selectedOperation  : props.allvalues['kpidata']['actualdata']['selectedOperation'],
      actual_type     : props.allvalues['kpidata']['actualdata']['actual_type'],
      individual_data : props.allvalues['kpidata']['actualdata']['individual_data'],
      Submitted       : props.Submitted,
      isDisable       : false,
      select_sublist :  props.allvalues['kpidata']['actualdata']['select_sublist'],
      // text_field_value : props.allvalues['kpidata']['actualdata']['text_field_value'],
      // textbox_value : props.allvalues['kpidata']['actualdata']['textbox_value'],
      // date : props.allvalues['kpidata']['actualdata']['date'],
      operater : props.allvalues['kpidata']['actualdata']['operater'],
      sublist_type : props.allvalues['kpidata']['actualdata']['sublist_type'],
      webelement_type :  props.allvalues['kpidata']['actualdata']['webelement_type'],
      cumulative         : props.allvalues['kpidata']['actualdata']['cumulative'],
    })

    useEffect (() =>{
       props.allvalues['kpidata']['actualdata']['actual_type']     = state.actual_type;
       props.allvalues['kpidata']['actualdata']['selectedManuals'] = state.selectedManuals!=undefined?state.selectedManuals:[];
       props.allvalues['kpidata']['actualdata']['selectedFolders'] = state.selectedFolders!=undefined?state.selectedFolders:[];
       props.allvalues['kpidata']['actualdata']['selectedWebform'] = state.selectedWebform!=undefined?state.selectedWebform:[];
       props.allvalues['kpidata']['actualdata']['selectedWebelement'] = state.selectedWebelement!=undefined?state.selectedWebelement:[];
       props.allvalues['kpidata']['actualdata']['selectedOperation']  = state.selectedOperation!=undefined?state.selectedOperation:[] ;
       props.allvalues['kpidata']['actualdata']['individual_data']    = state.individual_data;
       props.allvalues['kpidata']['actualdata']['select_sublist']          = state.select_sublist;
      // props.allvalues['kpidata']['actualdata']['text_field_value']          = state.text_field_value;
      // props.allvalues['kpidata']['actualdata']['textbox_value']          = state.textbox_value;
      props.allvalues['kpidata']['actualdata']['date']          = state.date;
      props.allvalues['kpidata']['actualdata']['sublist_type']  = state.sublist_type;
      props.allvalues['kpidata']['actualdata']['operater']          = state.operater;
      props.allvalues['kpidata']['actualdata']['webelement_type'] = state.webelement_type ;
      props.allvalues['kpidata']['actualdata']['operationOptions']  = state.operationOptions!=undefined?state.operationOptions:[];
      props.allvalues['kpidata']['actualdata']['folderOptions'] = state.folderOptions!=undefined?state.folderOptions:[];
      props.allvalues['kpidata']['actualdata']['documentOptions'] = state.documentOptions!=undefined?state.documentOptions:[];
      props.allvalues['kpidata']['actualdata']['webelementOptions'] = state.webelementOptions!=undefined?state.webelementOptions:[];
      props.allvalues['kpidata']['actualdata']['cumulative']         = state.cumulative;
      props.kpidataVariables(props.allvalues);
    },[state])
    useEffect (() =>{
      setVariables ();
    },[])
    function setVariables () {
     setState({...state,
       actual_type        : props.allvalues['kpidata']['actualdata']['actual_type'],
       // folderOptions      : props.action === 'Edit' ? props.allvalues['kpidata']['actualdata']['folderOptions'] : [],
       // documentOptions    : props.action === 'Edit' ? props.allvalues['kpidata']['actualdata']['documentOptions'] : [],
       // webelementOptions  : props.action === 'Edit' ? props.allvalues['kpidata']['actualdata']['webelementOptions'] : [],
       operationOptions   : props.action === 'Edit' ? operationOptions : props.allvalues['kpidata']['actualdata']['operationOptions'],
       folderOptions      : props.action === 'Create' && props.allvalues['details']['folderOptions'] !==undefined? props.allvalues['details']['folderOptions']: props.allvalues['kpidata']['actualdata']['folderOptions'] ,
       documentOptions    : props.action === 'Create' && props.allvalues['details']['documentOptions'] !==undefined? props.allvalues['details']['documentOptions']:props.allvalues['kpidata']['actualdata']['documentOptions'] ,
       webelementOptions  : props.action === 'Create'? props.allvalues['details']['webelementOptions']:props.allvalues['kpidata']['actualdata']['webelementOptions'],
       selectedManuals    : props.action === 'Create'? props.allvalues['details']['selectedManuals']:props.allvalues['kpidata']['actualdata']['selectedManuals'],
       selectedFolders    : props.action === 'Create'? props.allvalues['details']['selectedFolders']:props.allvalues['kpidata']['actualdata']['selectedFolders'],
       selectedWebform    : props.action === 'Create'? props.allvalues['details']['selectedWebform']:props.allvalues['kpidata']['actualdata']['selectedWebform'],
       selectedWebelement : props.allvalues['kpidata']['actualdata']['selectedWebelement'],
       selectedOperation  : props.allvalues['kpidata']['actualdata']['selectedOperation'],
       individual_data    : props.allvalues['kpidata']['actualdata']['individual_data'],
       cumulative         : props.allvalues['kpidata']['actualdata']['cumulative'],
       Submitted          : props.Submitted,
       isDisable          : props.action=='View'? true :((props.Submitted === true &&(props.Valid === true && props.nameError=='')) ? true : false),
       sublist_type : props.allvalues['kpidata']['actualdata']['sublist_type'],
       operater : props.allvalues['kpidata']['actualdata']['operater'],
       select_sublist : props.allvalues['kpidata']['actualdata']['select_sublist'],
       date : props.allvalues['kpidata']['actualdata']['date'],
       webelement_type : props.allvalues['kpidata']['actualdata']['webelement_type'],
     })
   }
    useEffect(() => {
      if(prevProps) {
        if(prevProps.Submitted!=props.Submitted||prevProps.num!=props.num){
           setVariables ();
        }
      }
    })

    const handleManualChange = async (e) => {
      // var ids = await getSelectedIDs(e);
      let folders = folderOptions.filter((menu) =>menu.manual_id==e['value']);
      setState({...state,
            selectedManuals  : e,
            folderOptions    : folders,
            selectedWebform  : [],
            selectedFolders  : [],
            selectedWebelement : [],
            selectedOperation  : [],
            documentOptions : [],
            webelementOptions : [],
            operationOptions  : []
      });
    }

    const handleChange=(event)=>{
      const {name , value} = event.target;
      setState({...state,
          [name]:value,
          operater : [],
          sublist_type : 0,
          select_sublist : [],
          date : undefined,
          webelement_type : 0,
        })
    }
    const handleChangeFolders = async (e) => {
       let docs = documentOptions.filter((menu) =>menu.parent_id==e['value']);
       setState({...state,
            selectedFolders :  e,
            documentOptions : docs,
            selectedWebform : [],
            selectedWebelement: [],
            selectedOperation : [],
            webelementOptions : [],
            operationOptions  : []
         });
     }
     const handleChangeDocs = async (e) => {
       let id = e.value;
       datasave.service(window.FETCHALLWEBELEMENTS + '/'+id ,'GET')
       .then(async response=>{
       await setState({...state,
         selectedWebform   : e,
         webelementOptions : response.data,
         selectedWebelement: [],
         selectedOperation : [],
         operationOptions  :[],
       })
       })
     }

     const handleChangeElements = async(e) => {
       setState({...state,
          selectedWebelement : e,
          selectedOperation : [],
          operationOptions   : operationOptions,
          webelement_type :   e.type,
          operater : [],
          sublist_type : 0,
          select_sublist : [],
          date : undefined,
          // webformWarning : false
        });
     }

      const actuallist = async(data)=> {
       await setState({...state,
        select_sublist : data.select_sublist,
        // text_field_value : data.text_field_value,
        // textbox_value : data.textbox_value,
        date : data.date,
        sublist_type : data.sublist_type,
        operater : data.operater,
      })
     }

     const handleChangeOperation=(e)=>{
       setState({...state,
       selectedOperation: e})
     }
     const formDisable =  (props.Submitted === true &&(props.Valid === true && props.nameError=='')) ? 'disabled' :(props.action ==='View' ? 'disabled': false);
     console.log(formDisable);
    return (
      <reactbootstrap className=" row ">
        <div className="col-md-12 pb-10" >
          <reactbootstrap.Container className=" pb-4">
             <reactbootstrap.Form>
                <fieldset disabled={formDisable}>
                <reactbootstrap.FormGroup>
                   <div className=" row input-overall-sec ">
                        <reactbootstrap.InputGroup className="  ">
                            <div className="col-md-4">
                                 <reactbootstrap.InputGroup.Prepend>
                                     <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Select the actual data:')}</p><span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                 </reactbootstrap.InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd" >
                                 <div class="custom-control custom-radio">
                                      <input type="radio" class="custom-control-input" id="fields2" value ="1" disabled={state.isDisable} checked={state.actual_type ==1} onChange={handleChange}  name="actual_type"/>
                                      <label class="custom-control-label" for="fields2">Fields</label>
                                 </div>
                                 <div class="custom-control custom-radio">
                                      <input type="radio" class="custom-control-input" id="query2" value ="2" disabled={state.isDisable} checked={state.actual_type ==2} onChange={handleChange}  name="actual_type"/>
                                      <label class="custom-control-label" for="query2">Query</label>
                                 </div>
                                 {state.Submitted && state.actual_type == "0" && <div style={{ color: 'red' }} className="error-block">{t('Select the actual data field is required')}</div>}
                            </div>
                        </reactbootstrap.InputGroup>
                    </div>
                </reactbootstrap.FormGroup>
              {state.actual_type ==1 && <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                  <reactbootstrap.InputGroup className="  ">
                    <div className="col-md-4">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Select webform:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div class="col-md-8 p-0">
                      <div className="col-md-12 p-0">
                        <div className="row">
                          <div style={{}} className='col-md-12 mb-2' >
                            <MultiSelect
                              options={manualOptions}
                              standards={state.selectedManuals}
                              id="manuals"
                              handleChange={(e) => handleManualChange(e)}
                              isMulti={true}
                              disabled={state.isDisable||formDisable}
                              isMulti={false}
                              placeholder={'Select manuals'}
                            />
                          </div>
                          <div style={{}} className='col-md-12 mb-2'>
                            <MultiSelect
                              options={state.folderOptions}
                              standards={state.selectedFolders}
                              disabled={state.isDisable||formDisable}
                              id="folders"
                              isMulti={true}
                              handleChange={(e) => handleChangeFolders(e)}
                              isMulti={false}
                              placeholder={'Select folders'}
                            />
                          </div>
                          <div style={{}} className='col-md-12 mb-2'>
                            <MultiSelect
                              options={state.documentOptions}
                              standards={state.selectedWebform}
                              id="webform"
                              disabled={state.isDisable||formDisable}
                              handleChange={(e) => handleChangeDocs(e)}
                              isMulti={false}
                              placeholder={'Select webform'}
                            />
                          </div>
                          <div style={{}} className='col-md-12 mb-2'>
                            <MultiSelect
                              options={state.webelementOptions}
                              standards={state.selectedWebelement}
                              disabled={state.isDisable||formDisable}
                              id="elements"
                              isMulti={true}
                              handleChange={(e) => handleChangeElements(e)}
                              isMulti={false}
                              placeholder={'Select web element'}
                            />
                          </div>
                          <div style={{}} className='col-md-12 mb-2'>
                            <MultiSelect
                              options={state.operationOptions}
                              standards={state.selectedOperation}
                              disabled={state.isDisable||formDisable}
                              id="operation"
                              isMulti={true}
                              handleChange={(e) => handleChangeOperation(e)}
                              isMulti={false}
                              placeholder={'Select operation'}
                            />
                            {state.Submitted && (state.selectedOperation!==undefined?state.selectedOperation.length==0:true) && <div style={{ color: 'red' }} className="error-block">{t('select operation field is required')}</div>}
                          </div>
                        </div>
                      </div>
                    </div>
                  </reactbootstrap.InputGroup>
                </div>
              </reactbootstrap.FormGroup>}
               {state.actual_type ==1 && state.selectedWebelement!=undefined&&state.selectedWebelement.length!=0 &&
                 <KpidataActions webelement = {state.selectedWebelement}  select_sublist = {state.select_sublist}
                 // text_field_value = {state.text_field_value}
                 // textbox_value = {state.textbox_value}
                 formDisable = {formDisable}
                isDisable = {state.isDisable}
                 kpiId = {props.kpiId}
                 date = {state.date}
                 sublist_type  = {state.sublist_type}
                 operater = {state.operater} type={2} actuallist={actuallist} ></KpidataActions>
               }
              {state.actual_type ==2 && <ManageQuery
                  allvalues={props.allvalues}
                  Submitted={state.Submitted} action= {props.action} kpidataVariables={props.kpidataVariables} kpiId={props.id} num={props} Valid={state.Valid} data={'actualdata'}
                />}
                <reactbootstrap.FormGroup className="pl-2 mt-3">
                      <reactbootstrap.Form.Check
                        className="input-document"
                          onChange={(e) => setState({ ...state, individual_data:!state.individual_data})}
                          name='individual_data'
                          checked={state.individual_data}
                          disabled={state.isDisable}
                          label={t("Individual data")}
                      />
                      <reactbootstrap.Form.Check
                            className="input-document"
                            onChange={(e) => setState({ ...state, cumulative:!state.cumulative})}
                            name='cumulative'
                            checked={state.cumulative}
                            disabled={state.isDisable}
                            label={t("Cumulative")}
                        />
                </reactbootstrap.FormGroup>
             </fieldset>
            </reactbootstrap.Form>
          </reactbootstrap.Container>
        </div>
      </reactbootstrap>
    );
  }
  export default translate(ActualData)
  function usePrevious(value) {
  	const ref = useRef();
  	useEffect(() => {
      ref.current = value;
  	}, [value]);
  	return ref.current;
  }
