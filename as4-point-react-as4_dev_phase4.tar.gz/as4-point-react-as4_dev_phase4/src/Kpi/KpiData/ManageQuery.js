import React ,{Suspense} from 'react'
import * as Reactbootstrap from 'react-bootstrap'
import { translate } from '../../language'
import { OCAlert } from '@opuscapita/react-alerts'
import  QueryBuilder from '../../Webforms/QueryBuilder/QueryBuilder';
class ManageQuery extends React.Component{
    technicalQuery ='';
    constructor(props){
        super(props)
        this.IntialState()

    }

    IntialState = ()=>{
        this.state  ={
          set_query: '',
          Submitted : this.props.Submitted,
          isDisable : false,
          actual_type : this.props.allvalues['kpidata']['actualdata']['actual_type'],
          actualquery : this.props.allvalues['kpidata']['actualdata']['actualquery'],
          target_type : this.props.allvalues['kpidata']['targetdata']['target_type'],
          targetquery : this.props.allvalues['kpidata']['targetdata']['targetquery'],
          maximumKPI_option : this.props.allvalues['kpidata']['targetdata']['maximumKPI_option'],
          minimumKPI_option : this.props.allvalues['kpidata']['targetdata']['minimumKPI_option'],
          minimumKPI_query : this.props.allvalues['kpidata']['targetdata']['minimumKPI_query'],
          maximumKPI_query : this.props.allvalues['kpidata']['targetdata']['maximumKPI_query'],
          data:''

        }
    }
    componentDidMount(){
      // console.log(this.props);
      let query ='';
      if(this.props.data==='targetdata'){
        query=this.props.allvalues['kpidata']['targetdata']['targetquery'];
      }
      else if (this.props.data === 'actualdata') {
        query=this.props.allvalues['kpidata']['actualdata']['actualquery'];
      }
      else if (this.props.data === 'minimumKPI') {
        query=this.props.allvalues['kpidata']['targetdata']['minimumKPI_query'];
      }
      else{
        query=this.props.allvalues['kpidata']['targetdata']['maximumKPI_query'];
      }
      this.setState({
        Submitted : this.props.Submitted,
        data:this.props.data,
        set_query:query,
        actual_type : this.props.allvalues['kpidata']['actualdata']['actual_type'],
        actualquery : this.props.allvalues['kpidata']['actualdata']['actualquery'],
        target_type : this.props.allvalues['kpidata']['targetdata']['target_type'],
        targetquery : this.props.allvalues['kpidata']['targetdata']['targetquery'],
        maximumKPI_option : this.props.allvalues['kpidata']['targetdata']['maximumKPI_option'],
        minimumKPI_option : this.props.allvalues['kpidata']['targetdata']['minimumKPI_option'],
        minimumKPI_query : this.props.allvalues['kpidata']['targetdata']['minimumKPI_query'],
        maximumKPI_query : this.props.allvalues['kpidata']['targetdata']['maximumKPI_query'],

      })

    }
    // componentDidUpdate(prevProps) {
    //   if (this.props!== prevProps) {
    //     console.log(this.props);
    //     this.setState({
    //       Submitted:this.props.Submitted
    //     })
    //
    //   }
    // }

      UNSAFE_componentWillReceiveProps(prevProps){
        // console.log(this.props);
        let query ='';
        if(this.props.data==='targetdata'){
          query=this.props.allvalues['kpidata']['targetdata']['targetquery'];
        }
        else if (this.props.data === 'actualdata') {
          query=this.props.allvalues['kpidata']['actualdata']['actualquery'];
        }
        else if (this.props.data === 'minimumKPI') {
          query=this.props.allvalues['kpidata']['targetdata']['minimumKPI_query'];
        }
        else{
          query=this.props.allvalues['kpidata']['targetdata']['maximumKPI_query'];
        }
      this.setState({
        Submitted : this.props.Submitted,
        data:this.props.data,
        set_query:query,
        actual_type : this.props.allvalues['kpidata']['actualdata']['actual_type'],
        actualquery : this.props.allvalues['kpidata']['actualdata']['actualquery'],
        target_type : this.props.allvalues['kpidata']['targetdata']['target_type'],
        targetquery : this.props.allvalues['kpidata']['targetdata']['targetquery'],
        maximumKPI_option : this.props.allvalues['kpidata']['targetdata']['maximumKPI_option'],
        minimumKPI_option : this.props.allvalues['kpidata']['targetdata']['minimumKPI_option'],
        minimumKPI_query : this.props.allvalues['kpidata']['targetdata']['minimumKPI_query'],
        maximumKPI_query : this.props.allvalues['kpidata']['targetdata']['maximumKPI_query'],
        isDisable : false,
      })
    }
    render(){
      const actualdata_requiredField = (this.state.data ==='actualdata' && (this.state.actual_type == '2' && this.state.actualquery ==='')) ? true : false;
      const targetdata_requiredField = (this.state.data ==='targetdata' && (this.state.target_type == '3' && this.state.targetquery ==='')) ? true : false;
      const minkpi_requiredField = (this.state.data ==='minimumKPI' && this.state.minimumKPI_query === '') ? true : false;
      const maxkpi_requiredField = (this.state.data ==='maximumKPI' && this.state.maximumKPI_query === '') ? true : false;
        return(
        <Suspense fallback = {<div className = "mt-4 ml-5" ></div>}>
        {this.props.Submitted && (minkpi_requiredField) && <div style={{ color: 'red' }} className="error-block">{('Minimum KPI field is required')}</div>}
        {this.props.Submitted && (maxkpi_requiredField) && <div style={{ color: 'red' }} className="error-block">{('Maximum KPI field is required')}</div>}
        <QueryBuilder
            webelement_id={undefined}
            callBackforQuery = {this.callBackforQuery}
            setQuery = {this.state.set_query}
            webform_id ={undefined}
            id ={undefined}
        />
        {this.props.Submitted && (targetdata_requiredField || actualdata_requiredField) &&
           <div style={{ color: 'red' }} className="error-block">{('Query field is required')}</div>}
        </Suspense>
        )
    }

    callBackforQuery =(query = undefined)=>{
      console.log(query);
        if(query !== undefined){
          let kpidata='';
          this.technicalQuery =query;
          if(this.state.data == 'targetdata'){
             kpidata={"type":"targetdata","query":this.technicalQuery }
            this.props.kpidataVariables(kpidata);
          }
          else if(this.state.data == 'actualdata'){
            kpidata={"type":"actualdata","query":this.technicalQuery}
            this.props.kpidataVariables(kpidata);
          }
          else if (this.state.data == 'minimumKPI') {
            kpidata={"type":"minimumKPI_query","query":this.technicalQuery}
            this.props.kpidataVariables(kpidata);
          }
          else{
            kpidata={"type":"maximumKPI_query","query":this.technicalQuery}
            this.props.kpidataVariables(kpidata);
          }
      }
        return this.technicalQuery
    }

}
export default translate(ManageQuery)
