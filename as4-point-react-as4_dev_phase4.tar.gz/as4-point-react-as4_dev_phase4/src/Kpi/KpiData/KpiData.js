import React, { useState, useEffect, useRef } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import TargetData from '../TargetData/TargetData';
import ActualData from '../ActualData/ActualData';
const KpiData =(props)=>{
  const prevProps = usePrevious(props);
  const t =props.t;
  const [state, setState] = useState({
    active_tab : 1,
  })
  const handlePageClick =(key) =>{
    setState({...state,
        active_tab:Number(key)
      })
  }

      return(
          <div className="container px-0 mt-2">
          <reactbootstrap.Container className="px-0">
          <reactbootstrap.Tabs activeKey={state.active_tab} onSelect={handlePageClick} id="controlled-tab-example">
                <reactbootstrap.Tab eventKey={1} title={t("Target data")}>
                    <TargetData allvalues={props.allvalues}  Submitted={props.Submitted} action= {props.action} kpidataVariables={props.kpidataVariables}  kpiId={props.kpiId} num={props} nameError={props.nameError} Valid={props.Valid}></TargetData>
                </reactbootstrap.Tab>
                <reactbootstrap.Tab  eventKey={2} title={t("Actual data")}>
                    <ActualData allvalues={props.allvalues}  Submitted={props.Submitted} action= {props.action} kpidataVariables={props.kpidataVariables} kpiId={props.kpiId} num={props} nameError={props.nameError} Valid={props.Valid}></ActualData>
                </reactbootstrap.Tab>
          </reactbootstrap.Tabs>
          </reactbootstrap.Container>
          </div>
      );
}

export default translate(KpiData);
function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  }, [value]);
  return ref.current;
}
