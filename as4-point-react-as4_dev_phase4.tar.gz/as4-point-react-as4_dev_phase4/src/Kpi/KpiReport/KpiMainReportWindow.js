import React,{useState ,useEffect} from 'react'
import * as Reactbootstrap from 'react-bootstrap'
import { datasave } from '../../_services/db_services'
import { translate } from '../../language'
import { OCAlert } from '@opuscapita/react-alerts'
import KpiMiddleReportWindow from './KpiMiddleReportWindow';
import { CanPermissions } from '../../_components/CanComponent/CanPermissions';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
const KpiMainReportWindow = props => {
const t = props.t;
const [state, setState] = useState({fromDate: '', toDate: '', select_date_type: 0, bundle_type: 0, graph_type: 0,
	target_type: 0, target_direct_value: 0, target_element_value: [], target_date_type: 0, target_individual: 0,
	actual_type:0, operation:0, actual_individual: 0, actual_element_value: [], min_value: 0, max_value: 0, errorMesg: '', accessDenied: false,
	min_value_type: 0, max_value_type: 0, cummulative: 0, kpi_name: '', actual_element_type: 0, target_cummulative: 0, actual_cummulative: 0});

useEffect(()=>{
	const kpiReportDataSave = async() =>{
	await getKpiReportDetails();
	}
	kpiReportDataSave();
}, [props.kpiId]);
    async function getKpiReportDetails(){
      datasave.service(window.GET_KPI_REPORT + '/' + (props.kpiId !== undefined ? props.kpiId : props.match.params.kpiId), 'GET').then(
      async response => {
        if(response['status'] == 200){
	const tempKpiDetails = response['data']['kpiDetails'] !== undefined ? response['data']['kpiDetails'] : {};
	const tempActualTargetElementData = response['data']['actual_target_data'] !== undefined ? response['data']['actual_target_data'] : {};
        let tempFromDate = tempActualTargetElementData['fromDate'] !== undefined ? tempActualTargetElementData['fromDate'] : '';
	let tempToDate = tempActualTargetElementData['toDate'] !== undefined ? tempActualTargetElementData['toDate'] : '';
		setState({...state, ...{
		fromDate: tempFromDate,
		toDate: tempToDate,
		select_date_type: tempKpiDetails['select_date_type'] !== undefined ? tempKpiDetails['select_date_type'] : 0,
		bundle_type: tempKpiDetails['bundle_type'] !== undefined ? tempKpiDetails['bundle_type'] : 0,
		graph_type: tempKpiDetails['graph_type'] !== undefined ? tempKpiDetails['graph_type'] : 0,
		target_type: tempKpiDetails['target_type'] !== undefined ? tempKpiDetails['target_type'] : 0,
		target_direct_value: tempKpiDetails['target_value'] !== undefined ? tempKpiDetails['target_value'] : 0,
		target_element_value: tempActualTargetElementData['targetData'] !== undefined ?
		tempActualTargetElementData['targetData'] : [],
		target_date_type: tempKpiDetails['target_date_type'] !== undefined && tempKpiDetails['target_date_type'] !== null ? tempKpiDetails['target_date_type'] : window.KPI_TAREGET_DATE_LAST_PERIOD,
		target_individual: tempKpiDetails['target_individual'] !== undefined ? tempKpiDetails['target_individual'] : 0,
		actual_type: tempKpiDetails['actual_type'] !== undefined ? tempKpiDetails['actual_type'] : 0,
		operation: tempKpiDetails['operation'] !== undefined ? tempKpiDetails['operation'] : 0 ,
		actual_individual: tempKpiDetails['actual_individual'] !== undefined ? tempKpiDetails['actual_individual'] : 0 ,
		actual_element_value:  tempActualTargetElementData['actualData'] !== undefined ?
		tempActualTargetElementData['actualData'] : [],
		min_value: tempKpiDetails['min_value'] !== undefined ? tempKpiDetails['min_value'] : 0 ,
		max_value: tempKpiDetails['max_value'] !== undefined ? tempKpiDetails['max_value'] : 0 ,
                min_value_type: tempKpiDetails['min_value_type'] !== undefined ? tempKpiDetails['min_value_type'] : 0 ,
                max_value_type: tempKpiDetails['max_value_type'] !== undefined ? tempKpiDetails['max_value_type'] : 0 ,
		cummulative: tempKpiDetails['cummulative'] !== undefined ? tempKpiDetails['cummulative'] : 0,
		target_cummulative: tempKpiDetails['target_cummulative'] !== undefined ? tempKpiDetails['target_cummulative'] : 0,
		actual_cummulative: tempKpiDetails['actual_cummulative'] !== undefined ? tempKpiDetails['actual_cummulative'] : 0,
		kpi_name: tempKpiDetails['name'] !== undefined ? tempKpiDetails['name'] +' '+ ('('+tempFromDate + ' - ' + tempToDate+')') : (tempFromDate + ' - ' + tempToDate),
		actual_element_type: tempKpiDetails['actual_element_type'] !== undefined ? tempKpiDetails['actual_element_type'] : 0
	}})
	}else{
		setState({...state, accessDenied: response['status'] === 410 ? true : false, errorMesg: response['Msg'] });
		if(response['status'] === 410) return ;
  	OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
	}
      })
    }

  const parentSetState = (paramState) =>{
  setState({...state, ...paramState});
  }
	return (
	<div>{state.accessDenied === false && (CanPermissions("Overview_KPI", "") === true) ?
	<KpiMiddleReportWindow
		state = {state}
		setState = {parentSetState}
		filter = {1}
		kpiId = {props.kpiId !== undefined ? props.kpiId : props.match.params.kpiId}
	/>: <AccessDeniedPage />}
	</div>
	);
}
export default translate(KpiMainReportWindow)
