import React,{useState ,useEffect} from 'react'
import * as Reactbootstrap from 'react-bootstrap'
import { datasave } from '../../_services/db_services'
import { translate } from '../../language'
import { OCAlert } from '@opuscapita/react-alerts'
import KpiMiddleReportWindow from './KpiMiddleReportWindow';
import * as reactbootstrap from 'react-bootstrap';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
import { Button} from 'react-bootstrap';
import KpiComment from '../../KpiComments';
import {store } from '../../store';
const KpiTodoReportView = props => {
const t = props.t;
const [state, setState] = useState({fromDate: '', toDate: '', select_date_type: 0, bundle_type: 0, graph_type: 0,
	target_type: 0, target_direct_value: 0, target_element_value: [], target_date_type: 0, target_individual: 0,
	actual_type:0, operation:0, actual_individual: 0, actual_element_value: [], min_value: 0, max_value: 0, errorMesg: '', accessDenied: false,
	min_value_type: 0, max_value_type: 0, cummulative: 0, kpi_name: '', actual_element_type: 0, target_cummulative: 0, actual_cummulative: 0,selectedEntity : 'general',subTabKey : 'general',frequencyType:2,TodoUserName:'',
  write_access:1,view_access:1,todo_access:1,formManage:(window.location.href.includes('formkpitodomanagement') !== undefined)?1:0,
});

useEffect(()=>{
	const kpiReportDataSave = async() =>{
	await getKpiReportDetails();
	}
	kpiReportDataSave();
}, [props.kpiId]);
const UpdateTodo =() => {
	const {history} = props;
	let goback = window.location.search.replace('?q=', '');
	const kpiTodoId = props.match.params.TodoId !== undefined ? props.match.params.TodoId :0;
	datasave.service(window.UPDATE_KPI_TODO_DETAILS + '/'+kpiTodoId,'POST').then(response => {
		if(response.status == 200) {


			OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });

history.push(goback);
window.location.reload();



		 // window.open('/notifications','_blank')
		}

	})

}
    async function getKpiReportDetails(){
      datasave.service(window.GET_KPI_REPORT + '/' + (props.kpiId !== undefined ? props.kpiId : props.match.params.kpiId) + '/' + (props.match.params.TodoId !== undefined ? props.match.params.TodoId :0) , 'GET').then(
      async response => {
        if(response['status'] == 200){
					let StoreData= store.getState();
					let loggedPerson = StoreData.UserData.user_details.user_name;
				
					console.log(response)
	const tempKpiDetails = response['data']['kpiDetails'] !== undefined ? response['data']['kpiDetails'] : {};
	const kpi_type = response['frequencyType'] !== undefined ?response['frequencyType']:2;
	const tempActualTargetElementData = response['data']['actual_target_data'] !== undefined ? response['data']['actual_target_data'] : {};
        let tempFromDate = tempActualTargetElementData['fromDate'] !== undefined ? tempActualTargetElementData['fromDate'] : '';
	let tempToDate = tempActualTargetElementData['toDate'] !== undefined ? tempActualTargetElementData['toDate'] : '';
  let access = response['access'] !== undefined?response['access']:[];
	let TodoPersonName = response['userName'] !== undefined ? response['userName']:'';
  console.log(access);
	console.log(access.view)
		setState({...state, ...{
		fromDate: tempFromDate,
		toDate: tempToDate,
		select_date_type: tempKpiDetails['select_date_type'] !== undefined ? tempKpiDetails['select_date_type'] : 0,
		bundle_type: tempKpiDetails['bundle_type'] !== undefined ? tempKpiDetails['bundle_type'] : 0,
		graph_type: tempKpiDetails['graph_type'] !== undefined ? tempKpiDetails['graph_type'] : 0,
		target_type: tempKpiDetails['target_type'] !== undefined ? tempKpiDetails['target_type'] : 0,
		target_direct_value: tempKpiDetails['target_value'] !== undefined ? tempKpiDetails['target_value'] : 0,
		target_element_value: tempActualTargetElementData['targetData'] !== undefined ?
		tempActualTargetElementData['targetData'] : [],
		target_date_type: tempKpiDetails['target_date_type'] !== undefined && tempKpiDetails['target_date_type'] !== null ? tempKpiDetails['target_date_type'] : window.KPI_TAREGET_DATE_LAST_PERIOD,
		target_individual: tempKpiDetails['target_individual'] !== undefined ? tempKpiDetails['target_individual'] : 0,
		actual_type: tempKpiDetails['actual_type'] !== undefined ? tempKpiDetails['actual_type'] : 0,
		operation: tempKpiDetails['operation'] !== undefined ? tempKpiDetails['operation'] : 0 ,
		actual_individual: tempKpiDetails['actual_individual'] !== undefined ? tempKpiDetails['actual_individual'] : 0 ,
		actual_element_value:  tempActualTargetElementData['actualData'] !== undefined ?
		tempActualTargetElementData['actualData'] : [],
		min_value: tempKpiDetails['min_value'] !== undefined ? tempKpiDetails['min_value'] : 0 ,
		max_value: tempKpiDetails['max_value'] !== undefined ? tempKpiDetails['max_value'] : 0 ,
                min_value_type: tempKpiDetails['min_value_type'] !== undefined ? tempKpiDetails['min_value_type'] : 0 ,
                max_value_type: tempKpiDetails['max_value_type'] !== undefined ? tempKpiDetails['max_value_type'] : 0 ,
		cummulative: tempKpiDetails['cummulative'] !== undefined ? tempKpiDetails['cummulative'] : 0,
		target_cummulative: tempKpiDetails['target_cummulative'] !== undefined ? tempKpiDetails['target_cummulative'] : 0,
		actual_cummulative: tempKpiDetails['actual_cummulative'] !== undefined ? tempKpiDetails['actual_cummulative'] : 0,
		kpi_name: tempKpiDetails['name'] !== undefined ? tempKpiDetails['name'] +' '+ ('('+tempFromDate + ' - ' + tempToDate+')') : (tempFromDate + ' - ' + tempToDate),
		actual_element_type: tempKpiDetails['actual_element_type'] !== undefined ? tempKpiDetails['actual_element_type'] : 0,
		frequencyType:kpi_type,
		TodoUserName:state.formManage === 1 ? TodoPersonName: loggedPerson,
		  write_access:(access.write !== undefined)?access.write:1,
			view_access:(access.view !== undefined)?access.view:1,
			todo_access:(access.todo_access !== undefined)?access.todo_access:1,
	}})
	}else{
		setState({...state, accessDenied: response['status'] === 410 ? true : false, errorMesg: response['Msg'] });
		if(response['status'] === 410) return ;
  	OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
	}
      })
    }

  const parentSetState = (paramState) =>{
  setState({...state, ...paramState});
  }
	console.log(state.formManage)
	return (
		<div>
				<reactbootstrap.Container className="">
						<reactbootstrap.Form >
							  <div style={{ padding: '3rem', paddingBottom: '0rem', paddingTop: '1rem', paddingLeft:'1.5rem' }} className="zero">
							<p>{'Hello '}{state.TodoUserName}{', your actual data '}{window.KPI_FREQUENCY_TYPES[state.frequencyType]}{' value of KPI-'}{state.kpi_name}</p>
						</div>
							<reactbootstrap.Tabs
				        onSelect={(key) => setState({ ...state, selectedEntity: key, subTabKey : key })}
				        defaultActiveKey={'Todo'}

				      >
				        <reactbootstrap.Tab eventKey={'Todo'} title={t('Kpi Report')}>
									<KpiMiddleReportWindow
										state = {state}
										setState = {parentSetState}
										filter = {1}
										kpiId = {props.kpiId !== undefined ? props.kpiId : props.match.params.kpiId}
								     kpiTodoId = {props.match.params.TodoId !== undefined ? props.match.params.TodoId :0 }
									/>
								<Button style = {{ position:"fixed",bottom:"0px"}} type = "button" onClick ={UpdateTodo} >{'Save'}</Button>
				        </reactbootstrap.Tab>
							{	 (state.view_access ===1 ||  state.write_access ===1 ) && <reactbootstrap.Tab eventKey={'Comment'} title={t('Kpi Comment')}>
									<KpiComment
										kpiTodoId = {props.match.params.TodoId !== undefined ? props.match.params.TodoId :0 }
										write_access = {state.write_access}
										view_access = {state.view_access}
										todo_access = {state.todo_access}
									 />
							 </reactbootstrap.Tab>}
							</reactbootstrap.Tabs>


	</reactbootstrap.Form>
		</reactbootstrap.Container>

			</div>








	);
}
export default translate(KpiTodoReportView)
