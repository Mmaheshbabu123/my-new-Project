import React, { useState ,useEffect,} from 'react';
import * as Reactbootstrap from 'react-bootstrap'
import * as Plotly from 'plotly.js';
import { datasave } from '../../_services/db_services'
import { translate } from '../../language'
import { OCAlert } from '@opuscapita/react-alerts'
import Plot from 'react-plotly.js';
import { Button} from 'react-bootstrap';


const KpiChartComponent = props =>{

const fromiFrame = props.fromiFrame;
const [plotAttributes, setPlotAttributes] = useState({data:[], layout:{}, frames:[], chartType: 0, status: false, tempKpiId : 0});
const {tempKpiId} = plotAttributes;

const {xAxisValue, actualData, targetData, minData, maxData, chartType, aggregateOperation, style, title} = props;
	useEffect(()=>{
    updateChartData();
  }, [chartType, aggregateOperation, props.kpiId]);

 const updateChartData = () =>{
    let tempPlotAttributes = Object.assign({}, plotAttributes);
     if(parseInt(tempKpiId) !== parseInt(props.kpiId) || parseInt(plotAttributes['chartType']) !==  parseInt(chartType)){
     tempPlotAttributes['data'] = getDataAccordingToChartType();
		 tempPlotAttributes['layout'] = { hovermode: "closest", title: title };
     tempPlotAttributes['chartType'] = chartType;
     tempPlotAttributes['status'] = true;
     tempPlotAttributes['tempKpiId'] = props.kpiId;
     setPlotAttributes(tempPlotAttributes)
     }else{
     tempPlotAttributes['data'] = getDataAccordingToChartType();
     tempPlotAttributes['layout'] = Object.assign({}, tempPlotAttributes['layout']);
     tempPlotAttributes['chartType'] = chartType;
     tempPlotAttributes['status'] = true;
     tempPlotAttributes['tempKpiId'] = props.kpiId;
     setPlotAttributes(tempPlotAttributes)
     }
    if (fromiFrame) {
      let [responsiveWidth, responsiveHeight] = getParentDiv_width_and_height();
      let [xlen, ylen] = getMarginOfLabels();
      tempPlotAttributes['layout'] = {
        ...tempPlotAttributes['layout'],
        hovermode: false,
        title: '',
        showlegend: false,
        dragMode: false,
        autosize: true,
        margin: {
          l: ylen ? ylen + 2 : 30,
          r: 30,
          b: xlen ? xlen : 40,
          t: 10,
        },
        width: responsiveWidth,
        height: responsiveHeight,
      }
    }
   }

  const getParentDiv_width_and_height = () => {
    let responsiveWidth = 170, responsiveHeight = 125;
    let currentElement = document.getElementById(props.id);
    let rootNode = document.querySelector('html');
    if (currentElement && rootNode) {
      responsiveWidth = rootNode.clientWidth - 5;
      responsiveHeight = rootNode.clientHeight - 5;
    }
    return [responsiveWidth, responsiveHeight];
  }

  const getMarginOfLabels = () => {
    let x = Object.keys(maxData);
    let y = Object.values(maxData);
    let xlen = 0;
    let ylen = 0;
    if (x.length) {
      let val = Math.max(...x);
      xlen = takeLength(val, x);
    }
    if (y.length) {
      let val = Math.max(...y);
      ylen = takeLength(val, y);
    }
    return [xlen * 5, ylen * 5]
  }

  const takeLength = (val, axis) => {
		return val ? Math.round(Math.max(...axis) / 1000) ? ('' + Math.round(Math.max(...axis) / 1000)).length + 2 : ('' + Math.round(Math.max(...axis))).length + 1
		           : axis.reduce((a, b) => ('' + a).length > ('' + b).length ? ('' + a) : ('' + b)).length;
  }

    const getDataAccordingToChartType = () =>{
    switch(parseInt(chartType)){
    case window.KPI_LINE_CHART :
    return constructXYAxisData('scatter', 'v', 'lines+markers');
    break;
    case window.KPI_BAR_CHART :
    return constructXYAxisData('bar', 'v', 'markers');
    break;
    }
   }
   const getValueOfData = (keys, valueObj) =>{
   return keys.map(key=>{ return valueObj[key] !== undefined ? valueObj[key] : 0 })
   }
   const constructXYAxisData = (type, orientation, mode) =>{
       let actualDataTrace = { y: getValueOfData(xAxisValue, actualData), x: xAxisValue,  type: type, orientation: orientation, mode: mode, name: 'Actual data',  line: { width: 3 }};
       let targetDataTrace = { y: getValueOfData(xAxisValue, targetData), x: xAxisValue, type: 'scatter', orientation: orientation, mode: 'lines', name: 'Target data', line: { width: 1.5}};
       let minDataTrace = { y: getValueOfData(xAxisValue, minData), x: xAxisValue, type: 'scatter', orientation: orientation, mode: 'lines', name: 'Minimum', line: { width: 1.5 }};
       let maxDataTrace = { y: getValueOfData(xAxisValue, maxData), x: xAxisValue, type: 'scatter', orientation: orientation, mode: 'lines', name: 'Maximum', line: { width: 1.5 }};
       return [minDataTrace, actualDataTrace, targetDataTrace, maxDataTrace];
       }

  const handleRender = (e) =>{
  let tempPlotAttributes = Object.assign({}, plotAttributes);
  tempPlotAttributes['data'] = e['data'] !== undefined ? e['data'] : [];
  tempPlotAttributes['layout'] = e['layout'] !== undefined ? e['layout'] : [];
  tempPlotAttributes['frames'] = e['frames'] !== undefined ? e['frames'] : [];
  tempPlotAttributes['chartType'] = chartType;
  setPlotAttributes(tempPlotAttributes);
 }
return (
	<>
  <div id ={props.id}>
    {plotAttributes['status'] ? <Plot
      data = {plotAttributes['data']}
      layout = {plotAttributes['layout']}
      frames = {plotAttributes['frames']}
      onUpdate = {(e)=>handleRender(e)}
      divId = {props.id}
      style = {style}
			useResizeHandler = {true}
      /> : <div>{fromiFrame ? '' : '...Loading'}</div>}
  </div>

	</>
)


}
export default KpiChartComponent;


///----------------TO-GET-IMAGE-BASE64-DATA dev.on 10/09/2021---------------//
/*const downloadMethod = () => {
	Plotly.plot(props.id, plotAttributes['data'], plotAttributes['layout']).then((gd) => {
        return Plotly.toImage(gd);
    }).then((dataURI) => {
        console.log(dataURI);
    });
}*/
