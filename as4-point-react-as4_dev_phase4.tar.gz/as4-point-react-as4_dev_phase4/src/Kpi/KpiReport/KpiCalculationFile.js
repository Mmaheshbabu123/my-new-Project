export const KpiCalculationFile = {
commonAggregationFunc
}
function median(numbers) {
    const sorted = numbers.slice().sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);

    if (sorted.length % 2 === 0) {
        return (sorted[middle - 1] + sorted[middle]) / 2;
    }

    return sorted[middle];
}
function numOr0(n, defaultVal){ return isNaN(n) ? defaultVal : n};

function sumFunc(data){
        return data.reduce((a, b)=>{ return numOr0(a, 0) + numOr0(b, 0)});
}
function productFunc(data){
        return data.reduce((a, b)=>{ return numOr0(a, 1) * numOr0(b, 1)});
}
function stdDev(data){
  let n = data.length;
  let mean = avgFunc(data);
  return Math.sqrt(data.map(x => Math.pow(x-mean,2)).reduce((a,b) => a+b)/n);
}
function avgFunc(data){
   return sumFunc(data)/data.length;
}
function commonAggregationFunc(agg, data, specialCaseCount){
  data = parseInt(agg) === window.KPI_OPERATION_COUNT && specialCaseCount !== 1 ? 
		data : data.map(key=>{ return !isNaN(key) ? parseFloat(key) : 0 });
	data = parseInt(agg) === window.KPI_OPERATION_MIN || parseInt(agg) ===  window.KPI_OPERATION_MEDIAN ? 
		data.filter(key=>{ return parseFloat(key) !== 0  }) : data;
	switch(parseInt(agg)){
         case window.KPI_OPERATION_SUM :
         return sumFunc(data);
         break;
         case window.KPI_OPERATION_AVERAGE:
         return avgFunc(data);
         break;
         case window.KPI_OPERATION_MEDIAN:
         return data.length > 0 ? median(data) : 0;
         break;
         case window.KPI_OPERATION_MIN:
         return  data.length > 0 ? Math.min(...data) : 0;
         break;
         case window.KPI_OPERATION_MAX :
         return Math.max(...data);
         break;
         case window.KPI_OPERATION_COUNT:
         return specialCaseCount !== 1 ? data.length : sumFunc(data);
         break;
         case window.KPI_OPERATION_STANDARD_DEVIATION:
         return stdDev(data);
         break;
         case window.KPI_OPERATION_PRODUCT:
         return productFunc(data);
         break;
         default:
         return sumFunc(data);
         break;
         }
        }

