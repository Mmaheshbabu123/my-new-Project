import {KpiCalculationFile} from './KpiCalculationFile';

export const kpiService = {
  kpiCalculationFunction,
}

const Months = [
  'Jan' , 'Feb' , 'Mar',
  'Apr' , 'May' , 'Jun',
  'July', 'Aug' , 'Sep',
  'Oct' , 'Nov' , 'Dec'
];

let finalReportData = {};
let kpiReportData = {};
let tileIndexId = '';
let fromDate = '';
let toDate = '';
let dateObj = new Date();
let currentYear = 0;
let weekKey = getCurrentWeek();
let monthKey = Months[dateObj.getMonth()] + ' ' + '(' + currentYear.toString().substr(-2) +')';
let quaterKey = 0;
let todayDate = dateObj.getFullYear() + '-' + ('0' + (dateObj.getMonth()+1)).slice(-2) + '-' + ('0' + dateObj.getDate()).slice(-2);
let currentDate = parseInt(dateObj.getFullYear() + ('0' + (dateObj.getMonth()+1)).slice(-2) + ('0' + dateObj.getDate()).slice(-2));


function kpiCalculationFunction(data){
  finalReportData = data;
  Object.values(data).forEach((item) => {
    tileIndexId = item.tile_id;
    getKpiReportData(item.kpiReportData);
    getActualValue(item.tile_id, kpiReportData);
  });
  return finalReportData;
}

function getKpiReportData(reportData){
  kpiReportData = {
    ...reportData['kpiDetails'],
    actual_element_value: (reportData && reportData.actual_target_data) ? reportData.actual_target_data.actualData:[],
    target_element_value: (reportData && reportData.actual_target_data) ? reportData.actual_target_data.actualData:[],
    target_direct_value: reportData['kpiDetails']['target_value'],
    fromDate: (reportData && reportData.actual_target_data) ? reportData.actual_target_data.fromDate:[],
    toDate: (reportData && reportData.actual_target_data) ? reportData.actual_target_data.toDate : '',
  };
  fromDate = kpiReportData.fromDate;
  toDate = todayDate;
}

function getActualValue(tileId, kpiReportData){
  let toDateInt = kpiReportData.toDate ? parseInt(kpiReportData.toDate.replaceAll('-', '')) : 0;
  if(fromDate !== '' && toDate !== '' && toDateInt >= currentDate){
    const dateList = getListOfDate(fromDate, toDate, 0);
    const noOfDays = numberOfDaysBetweenTwoDates(fromDate, toDate);
    let actualData = getActualchartData({...dateList}, noOfDays);
    actualData = (parseInt(kpiReportData.actual_cummulative) === 1 && (parseInt(kpiReportData.operation) !== 4 && parseInt(kpiReportData.operation) !== 5 && parseInt(kpiReportData.operation) !== 6)) ? applyCummulative(actualData) : actualData;
    if(actualData){
      let sortedKeys = (kpiReportData.bundle_type === window.KPI_BUNDLE_TYPE_DAYS) ? Object.keys(actualData).sort(sortAlphaNum) : '';
      let actualValKey = (kpiReportData.bundle_type === window.KPI_BUNDLE_TYPE_DAYS ? sortedKeys[sortedKeys.length-1] : kpiReportData.bundle_type === window.KPI_BUNDLE_TYPE_WEEKS ? weekKey : kpiReportData.bundle_type === window.KPI_BUNDLE_TYPE_MONTHS ? monthKey : quaterKey);
      let currentActualVal = (actualValKey && actualData[actualValKey]) ? actualData[actualValKey] :'';
      finalReportData[tileIndexId]['kpiReportData']['actualValue'] = currentActualVal;
      finalReportData[tileIndexId]['kpiReportData']['targetValue'] = kpiReportData.target_direct_value;
    }else{
      finalReportData[tileIndexId]['kpiReportData']['actualValue'] = '';
    }
  }else{
    finalReportData[tileIndexId]['kpiReportData']['actualValue'] = '';
    finalReportData[tileIndexId]['kpiReportData']['targetValue'] = kpiReportData.target_direct_value;
  }
}

function getListOfDate(tempFromDate, tempToDate, value){
  let dateList = {};
  let tempFromDateObj = new Date(tempFromDate);
  let tempToDateObj = new Date(tempToDate);
  while(tempFromDateObj <= tempToDateObj){
    dateList[formatDate(tempFromDateObj)] = value;
    tempFromDateObj.setDate(tempFromDateObj.getDate() + 1);
  }
  return dateList;
 }

function numberOfDaysBetweenTwoDates(tempFromDate, tempToDate){
  let timeDiff = (new Date(tempToDate + ' 24:00:00')) - (new Date(tempFromDate + ' 00:00:00'));
  return timeDiff / (1000 * 60 * 60 * 24);
}

function formatDate(date){
   var year = date.getFullYear().toString();
   var month = (date.getMonth() + 101).toString().substring(1);
   var day = (date.getDate() + 100).toString().substring(1);
   return year + "-" + month + "-" + day;
}

function getActualchartData(dateList, noOfDays){
  switch(parseInt(kpiReportData.actual_type)){
     case window.KPI_ACTUAL_TYPE_FIELD:
     return getActualFieldData({...dateList}, noOfDays);
   break;
     case window.KPI_ACTUAL_TYPE_QUERY:
     return getActualAndTargetDataAccordingToPeriod(dateList, fromDate, todayDate, noOfDays, kpiReportData.operation);
   break;
  }
}

function getActualFieldData(dateList, noOfDays){
  Object.keys(dateList).map(key => { dateList[key] = []; return 1;})
   kpiReportData.actual_element_value.map(key=>{
   let tempDate = new Date(key['date']);
   let plainDate = formatDate(tempDate);
      dateList[plainDate].push(key['value']);
   })
    return getActualAndTargetDataAccordingToPeriod(applyOperationOnSingleDate(dateList), fromDate, toDate, noOfDays, kpiReportData.operation);
}


const getActualAndTargetDataAccordingToPeriod = (dateList, paramFromDate, paramToDate, noOfDays, paramOperation) =>{
  switch(parseInt(kpiReportData.bundle_type)){
     case window.KPI_BUNDLE_TYPE_DAYS:
       let daysData = getIntialVarAccordingToperiod(window.KPI_BUNDLE_TYPE_DAYS, paramFromDate, paramToDate, noOfDays, dateList);
       Object.keys(dateList).map((key,index)=>{
        (daysData['Day' + (index +1)]).push(dateList[key])
        return 1;
       });
    return applyOperation(daysData, paramOperation);
    break;

    case window.KPI_BUNDLE_TYPE_WEEKS:
      let weeksData = getIntialVarAccordingToperiod(window.KPI_BUNDLE_TYPE_WEEKS, paramFromDate, paramToDate, noOfDays, dateList);
      Object.keys(dateList).map((key, index)=>{
         let tempDate = new Date(key);
         (weeksData['Week' + getWeekNumber(tempDate) + ' ('+ tempDate.getFullYear() +')']).push(dateList[key])
         return 1;
     });
    return applyOperation(weeksData, paramOperation);
    break;

    case window.KPI_BUNDLE_TYPE_MONTHS:
      let MonthsData = getIntialVarAccordingToperiod(window.KPI_BUNDLE_TYPE_MONTHS, paramFromDate, paramToDate, noOfDays, dateList);
       Object.keys(dateList).map(key=>{
       let tempDate = new Date(key);
        (MonthsData[(Months[tempDate.getMonth()]) + ' ('+ ((tempDate.getFullYear()).toString().substr(-2)) +')']).push(dateList[key])
        return 1;
       });
    return applyOperation(MonthsData, paramOperation);
    break;

    case window.KPI_BUNDLE_TYPE_QUARTER:
      let quatersData = getIntialVarAccordingToperiod(window.KPI_BUNDLE_TYPE_QUARTER, paramFromDate, paramToDate, noOfDays, dateList);
      let quaterMonthArr = Object.keys(quatersData);
      Object.keys(dateList).map(key=>{
        let tempDate = new Date(key);
        (quatersData[getQuaterMatchingKeys(quaterMonthArr, Months[tempDate.getMonth()] + ' (' + ((tempDate.getFullYear()).toString().substr(-2)) + ')')]).push(dateList[key])
        return 1;
      });
      quaterKey = Object.keys(quatersData).filter(val => val.includes(monthKey));
      quaterKey = quaterKey.length ? quaterKey[0]:'';
    return applyOperation(quatersData, paramOperation);
    break;

    default:
    break;
  }
}

function applyOperationOnSingleDate(dateList){
  Object.keys(dateList).map(key=>{
    dateList[key] = dateList[key].length > 0 ? KpiCalculationFile.commonAggregationFunc(kpiReportData.operation, dateList[key], 0)  : 0;
    return 1;
  })
  return dateList;
}

function getIntialVarAccordingToperiod(periodType, tempFromDate, tempToDate, noOfDays, dateList){
  switch(parseInt(periodType)){
    case window.KPI_BUNDLE_TYPE_DAYS:
    let daysVar = {};
    let tempVar = 1;
    while(tempVar <= noOfDays){
      daysVar['Day'+ tempVar] = [];
      tempVar++;
    }
    return daysVar;
    break;
    case window.KPI_BUNDLE_TYPE_WEEKS:
    let weeksVar = {};
    Object.keys(dateList).map(key=>{
      let tempDate = new Date(key)
      weeksVar['Week' + getWeekNumber(tempDate) + ' ('+ tempDate.getFullYear() +')'] = [];
      return 1;
    })
    return weeksVar;
    break;
   case window.KPI_BUNDLE_TYPE_MONTHS:
    let MonthArrObj = getMonthsBetweenDates(tempFromDate, tempToDate);
    let MonthsVar = {};
    Object.keys(MonthArrObj).map(key=>{
      (MonthArrObj[key]).map(monthKey=>{ MonthsVar[(Months[monthKey]) + ' ('+ key +')' ] = []  })
      return 1;
    });
    return MonthsVar;
    break;
    case window.KPI_BUNDLE_TYPE_QUARTER:
    let quaterVar = {};
    let singleMonthArrObj = getMonthsBetweenDates(tempFromDate, tempToDate);
    let tempIndex = 0;
    let temp = [];
    (Object.keys(singleMonthArrObj)).map(key=>{
       (singleMonthArrObj[key]).map(monthKey=>{
         if(tempIndex !== 0 && tempIndex % 3 === 0){
           quaterVar[temp.join('-')] = [];
           temp = [(Months[monthKey]) + ' ('+ key +')'];
         }else{
           temp.push((Months[monthKey]) + ' ('+ key +')');
         }
         tempIndex++;
       })
      return 1;
     });
     quaterVar[temp.join('-')] = [];
    return quaterVar;
    break;
    default:
    return {};
    break;
  }
}

function getWeekNumber(dt) {
  var tdt = new Date(dt.valueOf());
  var dayn = (dt.getDay() + 6) % 7;
  tdt.setDate(tdt.getDate() - dayn + 3);
  var firstThursday = tdt.valueOf();
  tdt.setMonth(0, 1);
  if (tdt.getDay() !== 4){
    tdt.setMonth(0, 1 + ((4 - tdt.getDay()) + 7) % 7);
  }
  return 1 + Math.ceil((firstThursday - tdt) / 604800000);
}

function applyOperation(data, tempOperation){
  Object.keys(data).map(key=>{
    data[key] = KpiCalculationFile.commonAggregationFunc(tempOperation, data[key], 1)
    return 1;
  });
 return data;
}

function getMonthsBetweenDates(tempFromDate, tempToDate){
  let tempDate = new Date(tempFromDate);
  let tempToDateObj = new Date(tempToDate);
  let resMonths = {};
  while(tempDate <= tempToDateObj){
  let year = (tempDate.getFullYear()).toString().substr(-2);
  if(resMonths[year] !== undefined){
    resMonths[year].push(tempDate.getMonth());
    tempDate.setMonth(tempDate.getMonth() + 1);
  }else{
    resMonths[year] = [tempDate.getMonth()];
    tempDate.setMonth(tempDate.getMonth() + 1);
  }
  }
  return resMonths;
}

function getQuaterMatchingKeys(quaterArr, singleMonth){
  return quaterArr.filter(key=>{ return key.indexOf(singleMonth) !== -1 }).join();
}


function applyCummulative(dataObj){
  let dataObjKeys = Object.keys(dataObj);
  dataObjKeys.map((key, index)=>{
    if(index !== 0){
      dataObj[dataObjKeys[index]] += dataObj[dataObjKeys[index - 1]]
    }
    return 1;
  });
  return dataObj;
}

var reA = /[^a-zA-Z]/g;
var reN = /[^0-9]/g;
function sortAlphaNum(a, b) {
  var aA = a.replace(reA, "");
  var bA = b.replace(reA, "");
  if (aA === bA) {
    var aN = parseInt(a.replace(reN, ""), 10);
    var bN = parseInt(b.replace(reN, ""), 10);
    return aN === bN ? 0 : aN > bN ? 1 : -1;
  } else {
    return aA > bA ? 1 : -1;
  }
}

function getCurrentWeek() {
  let d = new Date();
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay()||7));
  var yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
  var weekNo = Math.ceil(( ( (d - yearStart) / 86400000) + 1)/7);
  currentYear = d.getUTCFullYear();
  return 'Week' + weekNo + ' ' + '(' + currentYear + ')';
}
