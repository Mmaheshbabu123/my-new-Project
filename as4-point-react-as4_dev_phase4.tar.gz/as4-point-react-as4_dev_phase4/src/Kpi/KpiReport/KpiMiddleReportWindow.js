import React,{useState ,useEffect} from 'react'
import * as Reactbootstrap from 'react-bootstrap'
import { Button} from 'react-bootstrap';
import { datasave } from '../../_services/db_services'
import { translate } from '../../language'
import { OCAlert } from '@opuscapita/react-alerts'
import {KpiCalculationFile} from './KpiCalculationFile'
import KpiChartComponent from './KpiChartComponent'
import MultiSelect from '../../_components/MultiSelect';

const KpiMiddleReportWindow = props => {
const t = props.t;
const graphOption = [{'label': 'Line chart', 'value': window.KPI_LINE_CHART}, {'label': 'Bar chart', 'value': window.KPI_BAR_CHART}];
const aggreagateOption = [
	{label: 'Sum', value: window.KPI_OPERATION_SUM},
	{label: 'Average', value: window.KPI_OPERATION_AVERAGE},
	{label: 'Median', value: window.KPI_OPERATION_MEDIAN},
	{label: 'Min', value: window.KPI_OPERATION_MIN},
	{label: 'Max', value: window.KPI_OPERATION_MAX},
	{label: 'Count', value: window.KPI_OPERATION_COUNT},
	{label: 'Standard deviation', value: window.KPI_OPERATION_STANDARD_DEVIATION},
	{label: 'Product', value: window.KPI_OPERATION_PRODUCT}
]
  const fromiFrame = props.fromiFrame;
	const {fromDate, toDate, select_date_type, bundle_type, graph_type,
        target_type, target_direct_value, target_element_value, target_date_type, target_individual,
        actual_type, operation, actual_individual, actual_element_value, min_value, max_value,
        min_value_type, max_value_type, cummulative, kpi_name, actual_element_type, target_cummulative, actual_cummulative} = props.state;
	const {setState} = props.setState;
	const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        const Months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug',
		'Sep', 'Oct', 'Nov', 'Dec'];
	const numberOfDaysBetweenTwoDates = (tempFromDate, tempToDate) =>{
	  let timeDiff = (new Date(tempToDate + ' 24:00:00')) - (new Date(tempFromDate + ' 00:00:00'));
          return timeDiff / (1000 * 60 * 60 * 24);
	}

	const formatDate = (date) =>{
        var year = date.getFullYear().toString();
        var month = (date.getMonth() + 101).toString().substring(1);
        var day = (date.getDate() + 100).toString().substring(1);
        return year + "-" + month + "-" + day;
        }

	const getListOfDate = (tempFromDate, tempToDate, value) =>{
	let dateList = {};
	let tempFromDateObj = new Date(tempFromDate);
	let tempToDateObj = new Date(tempToDate);
	while(tempFromDateObj <= tempToDateObj){
	dateList[formatDate(tempFromDateObj)] = value;
	tempFromDateObj.setDate(tempFromDateObj.getDate() + 1);
	}
        return dateList;
	}
        const getMonthsBetweenDates = (tempFromDate, tempToDate) =>{
	let tempDate = new Date(tempFromDate);
	let tempToDateObj = new Date(tempToDate);
	let resMonths = {};
	while(tempDate <= tempToDateObj){
	let year = (tempDate.getFullYear()).toString().substr(-2);
	if(resMonths[year] !== undefined){
	resMonths[year].push(tempDate.getMonth());
	tempDate.setMonth(tempDate.getMonth() + 1);
	}else{
	resMonths[year] = [tempDate.getMonth()];
	tempDate.setMonth(tempDate.getMonth() + 1);
	}
	}
	return resMonths;
	}

	const getWeekNumber = (dt) =>{
        var tdt = new Date(dt.valueOf());
        var dayn = (dt.getDay() + 6) % 7;
        tdt.setDate(tdt.getDate() - dayn + 3);
        var firstThursday = tdt.valueOf();
        tdt.setMonth(0, 1);
        if (tdt.getDay() !== 4)
        {
        tdt.setMonth(0, 1 + ((4 - tdt.getDay()) + 7) % 7);
        }
        return 1 + Math.ceil((firstThursday - tdt) / 604800000);
        }

	const getIntialVarAccordingToperiod = (periodType, tempFromDate, tempToDate, noOfDays, dateList) =>{
	switch(parseInt(periodType)){
	case window.KPI_BUNDLE_TYPE_DAYS:
	 let daysVar = {};
	 let tempVar = 1;
	 while(tempVar <= noOfDays){
	 daysVar['Day'+ tempVar] = [];
	 tempVar++;
	 }
	 return daysVar;
	break;
	case window.KPI_BUNDLE_TYPE_WEEKS:
	 let weeksVar = {};
	 Object.keys(dateList).map(key=>{
	 let tempDate = new Date(key)
	 weeksVar['Week' + getWeekNumber(tempDate)] = [];
	 })
	 return weeksVar;
         /*let numberOfWeeks = Math.ceil(noOfDays/7);
	 let weeksVar = {};
	 let i = 1;
	 while (i <= numberOfWeeks){
  	  weeksVar['Week' + i] = [];
	  i++;
	  }
	  return weeksVar;*/
	  break;
	  case window.KPI_BUNDLE_TYPE_MONTHS:
          let MonthArrObj = getMonthsBetweenDates(tempFromDate, tempToDate);
	  let MonthsVar = {};
	  Object.keys(MonthArrObj).map(key=>{
          (MonthArrObj[key]).map(monthKey=>{ MonthsVar[(Months[monthKey]) + ' ('+ key +')' ] = []  })
	  });
	  return MonthsVar;
	  break;
	  case window.KPI_BUNDLE_TYPE_QUARTER:
	  let quaterVar = {};
	  let singleMonthArrObj = getMonthsBetweenDates(tempFromDate, tempToDate);
	  let tempIndex = 0;
	  let temp = [];
	  (Object.keys(singleMonthArrObj)).map(key=>{
          (singleMonthArrObj[key]).map(monthKey=>{
	     if(tempIndex !== 0 && tempIndex % 3 === 0){
	     quaterVar[temp.join('-')] = [];
	     temp = [(Months[monthKey]) + ' ('+ key +')'];
	     }else{
	      temp.push((Months[monthKey]) + ' ('+ key +')');
	     }
	     tempIndex++;
	  })
	  });
	  quaterVar[temp.join('-')] = [];
          return quaterVar;
	  break;
          default:
	  OCAlert.alertError("Target date type is not been saved correctly", { timeOut: window.TIMEOUTNOTIFICATION });
	  return {};
	  break;
	}
	}

	const getQuaterMatchingKeys = (quaterArr, singleMonth) =>{
	return quaterArr.filter(key=>{ return key.indexOf(singleMonth) !== -1 }).join();
	}
        const applyOperation = (data, tempOperation) =>{
	  Object.keys(data).map(key=>{
		    data[key] = KpiCalculationFile.commonAggregationFunc(tempOperation, data[key], 1)
	  });
	  return data;
	}

	const getActualAndTargetDataAccordingToPeriod = (dateList, paramFromDate, paramToDate, noOfDays, paramOperation) =>{
	  switch(parseInt(bundle_type)){
	  case window.KPI_BUNDLE_TYPE_DAYS:
	  let daysData = getIntialVarAccordingToperiod(window.KPI_BUNDLE_TYPE_DAYS, paramFromDate, paramToDate, noOfDays, dateList);
	  Object.keys(dateList).map((key,index)=>{
	  (daysData['Day' + (index +1)]).push(dateList[key])
	  });
	  return applyOperation(daysData, paramOperation);
	  break;

	  case window.KPI_BUNDLE_TYPE_WEEKS:
	  let weeksData = getIntialVarAccordingToperiod(window.KPI_BUNDLE_TYPE_WEEKS, paramFromDate, paramToDate, noOfDays, dateList);
	  Object.keys(dateList).map((key, index)=>{
		  let tempDate = new Date(key);
		  (weeksData['Week' + getWeekNumber(tempDate) ]).push(dateList[key]) });
	  return applyOperation(weeksData, paramOperation);
	  break;

	  case window.KPI_BUNDLE_TYPE_MONTHS:
          let MonthsData = getIntialVarAccordingToperiod(window.KPI_BUNDLE_TYPE_MONTHS, paramFromDate, paramToDate, noOfDays, dateList);
	  Object.keys(dateList).map(key=>{
	  let tempDate = new Date(key);
	  (MonthsData[(Months[tempDate.getMonth()]) + ' ('+ ((tempDate.getFullYear()).toString().substr(-2)) +')']).push(dateList[key])
	  });
	  return applyOperation(MonthsData, paramOperation);
	  break;

	  case window.KPI_BUNDLE_TYPE_QUARTER:
	  let quatersData = getIntialVarAccordingToperiod(window.KPI_BUNDLE_TYPE_QUARTER, paramFromDate, paramToDate, noOfDays, dateList);
	  let quaterMonthArr = Object.keys(quatersData);
	  Object.keys(dateList).map(key=>{
	  let tempDate = new Date(key);
	  (quatersData[getQuaterMatchingKeys(quaterMonthArr, Months[tempDate.getMonth()] + ' (' + ((tempDate.getFullYear()).toString().substr(-2)) + ')')]).push(dateList[key])
	  });
	  return applyOperation(quatersData, paramOperation);
	  break;
          default:
	  OCAlert.alertError("Target date type is not been saved correctly", { timeOut: window.TIMEOUTNOTIFICATION });
          break;
	}
	}

	const applyOperationOnSingleDate = (dateList) =>{
	Object.keys(dateList).map(key=>{
	dateList[key] = dateList[key].length > 0 ? KpiCalculationFile.commonAggregationFunc(operation, dateList[key], 0)  : 0;
	})
	return dateList;
	}

	const getActualFieldData = (dateList, noOfDays) =>{
	Object.keys(dateList).map(key=>{ dateList[key] = [] })
	actual_element_value.map(key=>{
	   let tempDate = new Date(key['date']);
	   let plainDate = formatDate(tempDate);
            dateList[plainDate].push(key['value']);
	   })
      return getActualAndTargetDataAccordingToPeriod(applyOperationOnSingleDate(dateList), fromDate, toDate, noOfDays, operation);
	}

	const getActualchartData = (dateList, noOfDays) =>{
		switch(parseInt(actual_type)){
		case window.KPI_ACTUAL_TYPE_FIELD:
		return getActualFieldData({...dateList}, noOfDays);
		break;
		case window.KPI_ACTUAL_TYPE_QUERY:
		return getActualAndTargetDataAccordingToPeriod(dateList, fromDate, toDate, noOfDays, operation);
		OCAlert.alertError("Actual data query functionality pending", { timeOut: window.TIMEOUTNOTIFICATION });
	        break;
		default:
		break;
	}
	}

	const getTargetSimilatLastPeriodData = () =>{
        let fromDateObj = new Date(fromDate);
	let toDateObj = new Date(toDate);
	fromDateObj.setFullYear(fromDateObj.getFullYear() - 1);
	toDateObj.setFullYear(toDateObj.getFullYear() - 1);
        let tempFromDate = formatDate(fromDateObj);
	let tempToDate = formatDate(toDateObj);
        const dateList = getListOfDate(tempFromDate, tempToDate, []);
        const noOfDays = numberOfDaysBetweenTwoDates(tempFromDate, tempToDate);
	 if(target_element_value.length > 0){
	   target_element_value.map(key=>{
	   let tempDate = new Date(key['date']);
	   let plainDate = formatDate(tempDate);
            dateList[plainDate].push(key['value']);
	   })
           return getActualAndTargetDataAccordingToPeriod(applyOperationOnSingleDate(dateList), fromDate, toDate, noOfDays, operation);
	 }else{
	   Object.keys(dateList).map(key=>{ dateList[key] = 0 })
	   return getActualAndTargetDataAccordingToPeriod(dateList, fromDate, toDate, noOfDays, operation);
	 }
	}

        const getLastPeriodAccordingToBundle = () =>{
        let tempFromDateObj = new Date(fromDate);
        let tempToDateObj = new Date(fromDate);
	switch(parseInt(bundle_type)){
	case window.KPI_BUNDLE_TYPE_DAYS:
	tempFromDateObj.setDate(tempFromDateObj.getDate() - 1);
        tempToDateObj.setDate(tempToDateObj.getDate() - 1);
        return {'from_date': formatDate(tempFromDateObj), 'to_date': formatDate(tempToDateObj)};
        break;
        case window.KPI_BUNDLE_TYPE_WEEKS:
	tempFromDateObj.setDate(tempFromDateObj.getDate() - 7);
        tempToDateObj.setDate(tempToDateObj.getDate() - 1);
        return {'from_date': formatDate(tempFromDateObj), 'to_date': formatDate(tempToDateObj)};
	break;
        case window.KPI_BUNDLE_TYPE_MONTHS:
	tempFromDateObj.setMonth(tempFromDateObj.getMonth() - 1);
        tempToDateObj.setDate(tempToDateObj.getDate() - 1);
        return {'from_date': formatDate(tempFromDateObj), 'to_date': formatDate(tempToDateObj)};
	break;
	case window.KPI_BUNDLE_TYPE_QUARTER:
	tempFromDateObj.setMonth(tempFromDateObj.getMonth() - 3);
        tempToDateObj.setDate(tempToDateObj.getDate() - 1);
        return {'from_date': formatDate(tempFromDateObj), 'to_date': formatDate(tempToDateObj)};
	break;
	default:
        OCAlert.alertError("Bundle type is not been saved correctly", { timeOut: window.TIMEOUTNOTIFICATION });
        break;
	}
     }
      const addLastTargetToActualData = (actualData, targetData) =>{
	let resultTargetData = {};
	let actualDataKeys = Object.keys(actualData);
        actualDataKeys.map((key, index)=>{
	resultTargetData[key] = index === 0 ?
	  parseInt((Object.keys(targetData).map(key1=>{ return targetData[key1] })).join()) :  actualData[actualDataKeys[index - 1]];
	});
	return resultTargetData;
	}

      const getTargetLastPeriodData = (actualData) =>{
        let fromToDateObj = getLastPeriodAccordingToBundle();
	const dateList = getListOfDate(fromToDateObj['from_date'], fromToDateObj['to_date'] , []);
        const noOfDays = numberOfDaysBetweenTwoDates(fromToDateObj['from_date'], fromToDateObj['to_date']);
           target_element_value.map(key=>{
           let tempDate = new Date(key['date']);
	   if(new Date(fromToDateObj['from_date']) >= tempDate && tempDate <= new Date(fromToDateObj['to_date'])){
           let plainDate = formatDate(tempDate);
            dateList[plainDate].push(key['value']);
	   }
	   })
        return addLastTargetToActualData(actualData, getActualAndTargetDataAccordingToPeriod(applyOperationOnSingleDate(dateList), fromToDateObj['from_date'], fromToDateObj['to_date'], noOfDays, operation));
	}

	const getTargetFieldData = (dateList, noOfDays, actualData) =>{
		switch(parseInt(target_date_type)){
		case window.KPI_TARGET_SIMILAR_DATE_LAST_YEAR:
                return getTargetSimilatLastPeriodData();
		break;
		case window.KPI_TAREGET_DATE_LAST_PERIOD:
		return getTargetLastPeriodData(actualData);
		break;
		default:
		OCAlert.alertError("Target date type is not been saved correctly", { timeOut: window.TIMEOUTNOTIFICATION });
		break;
	}
	}
        const getTargetChartData = (dateList, noOfDays, actualData) =>{
		switch(parseInt(target_type)){
		case window.KPI_TARGET_TYPE_VALUE:
		let perDayTarget = target_direct_value/noOfDays;
		Object.keys(dateList).map(key=>{ dateList[key] = perDayTarget});
                return getActualAndTargetDataAccordingToPeriod(dateList, fromDate, toDate, noOfDays, window.KPI_OPERATION_SUM);
		break;
		case window.KPI_TARGET_TYPE_FIELD:
		return getTargetFieldData(dateList, noOfDays, actualData);
		break;
		case window.KPI_TARGET_TYPE_QUERY:
		OCAlert.alertError("Target data query functionality pending", { timeOut: window.TIMEOUTNOTIFICATION });
		break;
		default:
		OCAlert.alertError("Target type is not been saved correctly", { timeOut: window.TIMEOUTNOTIFICATION });
		break;
	}
	}

	const getMinMaxChartData = (min_max_value_type, dateList, noOfDays, targetData, minOrMax) =>{
		switch(parseInt(min_max_value_type)){
		case window.KPI_TARGET_MIN_TYPE_VALUE: case window.KPI_TARGET_MAX_TYPE_VALUE:
		let perDayTarget = parseInt(minOrMax) === 1 ? min_value/noOfDays : max_value/noOfDays;
		Object.keys(dateList).map(key=>{ dateList[key] = perDayTarget});
                return getActualAndTargetDataAccordingToPeriod(dateList, fromDate, toDate, noOfDays, window.KPI_OPERATION_SUM);
		break;
		case window.KPI_TARGET_MIN_TYPE_PERCENTAGE: case window.KPI_TARGET_MAX_TYPE_PERCENTAGE:
	        let tempMinMaxValue = parseInt(minOrMax) === 1 ? min_value : max_value;
		let resultMinMaxData = {};
		Object.keys(targetData).map(key=>{
			resultMinMaxData[key] =  parseInt(targetData[key]) !== 0 ? ((tempMinMaxValue/100) * targetData[key]) : 0;
		});
		return resultMinMaxData;
	        break;
		case window.KPI_TARGET_MIN_TYPE_QUERY: case window.KPI_TARGET_MAX_TYPE_QUERY:
		return getActualAndTargetDataAccordingToPeriod(dateList, fromDate, toDate, noOfDays, window.KPI_OPERATION_SUM);
		break;
	}
	}
	const applyCummulative = (dataObj, cumulate = 'actual') =>{
	let dataObjKeys = Object.keys(dataObj);
	let sum = (cumulate !== 'actual' && cumulate === 0) ? sumFunc(Object.values(dataObj)) : 0;
	dataObjKeys.map((key, index)=>{
	if(index !== 0){
			dataObj[dataObjKeys[index]] += dataObj[dataObjKeys[index - 1]]
  }
	if (cumulate !== 'actual' && cumulate === 0) {
		dataObj[dataObjKeys[index]] = sum;
  }
	return 1;
	});
	return dataObj;
	}

	const callChartComponent = (actualData, targetData, minData, maxData, chartType, aggregateOperation) =>{
	if(Object.keys(actualData).length > 0){
	return <KpiChartComponent
		id = {"Kpi1"}
		kpiId = {props.kpiId}
		title = {kpi_name}
		xAxisValue = {Object.keys(actualData)}
		actualData = {actualData}
                targetData = {targetData}
		minData = {minData}
		maxData = {maxData}
		chartType = {chartType}
		aggregateOperation = {aggregateOperation}
		style ={{ width: '100%', height: '100%'}}
		fromiFrame={fromiFrame}
		/>
	}else{
	return <div>{'No data'}</div>
	}
	}


	const handleSingleSelect = (name, value) =>{
		props.setState({[name] : value});
	}

	const getSingleSelectDropDown = (label, name, value, optionData) =>{
		return (
	         <div>
		 <label>{label}</label>
		 <MultiSelect
                                    options={optionData}
                                    standards={value}
                                    id="graph"
                                    handleChange={(e)=>handleSingleSelect(name, e.value)}
                                    isMulti={false}
                                  /></div>
		);
	}

        const getSingleSelectValue = (data, value) =>{
        return data.filter(key=>{ return parseInt(key['value']) === parseInt(value) })[0];
	}

	const displayChart = () =>{
        if(fromDate != '' && toDate != ''){
	const dateList = getListOfDate(fromDate, toDate, 0);
	const noOfDays = numberOfDaysBetweenTwoDates(fromDate, toDate);
	const actualData = getActualchartData({...dateList}, noOfDays);
	const targetData = getTargetChartData({...dateList}, noOfDays, actualData);
	const minData = getMinMaxChartData(min_value_type, {...dateList}, noOfDays, targetData, 1);
  const maxData = getMinMaxChartData(max_value_type, {...dateList}, noOfDays, targetData, 0);
		return (<div>
		{props.filter !== undefined && <div>{getSingleSelectDropDown('Chart type: ', 'graph_type',
			getSingleSelectValue(graphOption, graph_type) , graphOption)}</div>}
		{props.filter !== undefined && (parseInt(actual_element_type) === window.NUMERICFIELD || parseInt(actual_element_type) === window.DECIMALFIELD) && <div>{getSingleSelectDropDown('Aggregate: ', 'operation',
			getSingleSelectValue(aggreagateOption, operation), aggreagateOption)}</div>}
		{callChartComponent(
	        (parseInt(actual_cummulative) === 1 && (parseInt(operation) !== 4 && parseInt(operation) !== 5)) ? applyCummulative(actualData) : actualData,
		applyCummulative(targetData, parseInt(target_cummulative)),
		applyCummulative(minData, parseInt(target_cummulative)),
		applyCummulative(maxData, parseInt(target_cummulative)), graph_type, operation)}
		</div>);
	}else{
	return (<div style={fromiFrame?{position:'absolute', left:'35%', top:'25%', marginTop:'25%'}:{}}>{'No data'}</div>);
	}
	}

	return (<div className = {fromiFrame ? 'col-md-6 p-0 m-0' :'container py-10'}>
		{displayChart()}
		</div>);
}
export default translate(KpiMiddleReportWindow)

function numOr0(n, defaultVal){ return isNaN(n) ? defaultVal : n}

function sumFunc(data){
        return data.reduce((a, b)=>{ return numOr0(a, 0) + numOr0(b, 0)});
}
