import React, {useEffect,useState,useRef} from 'react';
import * as reactbootstrap from 'react-bootstrap';
import MultiSelect from '../../_components/MultiSelect';
import { translate } from '../../../src/language';
import './KpiPopUp.css';

const KpiPopUp = (props) => {
  const[state,setState] = useState({
    t: props.t,
    selected: props.selectedItems.filter(item => { return (item.id !== props.id) }),
    excludeId: props.id,
    multiSelectItems: [],
    checkBoxId: props.checkBoxId,
  });

  useEffect(() => {
  let multiSelect = [];
  let abc = props.selectedItems.filter(val => parseInt(val.id) === parseInt(props.id));
  if(abc && abc.length) {
    abc = abc[0];
    let def = abc['checkboxes'].filter(val => parseInt(val.id) === parseInt(props.checkBoxId));
    if(def && def.length){
    let checkValues = def[0]['linkedDetail'].filter(item => {
      return state.selected.some(item1 => {
        return item.value === item1.id;
      })
    });
    multiSelect = checkValues;
  }


  }
  setState({
    ...state,
    multiSelectItems:multiSelect,
  });

  },[props]);


  const handleChangeMultiSelect= (e) => {
    let selected = [];
     e.map(item=>{
    selected.push(  {id:item.id,category_id:item.category_id,label:item.label,value:item.value})
    })
    setState({
      ...state,
      multiSelectItems: selected,
    })

  }


  const { t } = state;
  return(
    <reactbootstrap.Modal
      show={props.show}
      onHide={() => props.closePopUp()}
      dialogClassName="modal-90w"
      size = "lg"
      aria-labelledby="example-custom-modal-styling-title"
    >
      <reactbootstrap.Modal.Header closeButton>
        <reactbootstrap.Modal.Title>{props.titleName}</reactbootstrap.Modal.Title>
        </reactbootstrap.Modal.Header >
        <reactbootstrap.Container className="">
          <reactbootstrap.Modal.Body>
            <MultiSelect
              className=""
              options={state.selected}
              standards={state.multiSelectItems}
              handleChange={(e) => handleChangeMultiSelect(e)}

            />
          </reactbootstrap.Modal.Body>
          <reactbootstrap.Row className='mt-3' style={{float:'right'}}>
          <a style={{paddingTop:'15px'}} onClick={() => props.closePopUp()}>{t('Cancel')}</a>&nbsp;&nbsp;&nbsp;
          <reactbootstrap.Button className='m-2' onClick={() => props.handlePopUpSave(state.multiSelectItems, state.excludeId, state.checkBoxId)}>{t('Save')}</reactbootstrap.Button>
          </reactbootstrap.Row>
        </reactbootstrap.Container>
      </reactbootstrap.Modal>

  )
}

export default translate(KpiPopUp);
