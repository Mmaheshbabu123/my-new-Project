import React, { useState, useEffect, useRef } from 'react';
import { translate } from '../../language';
import MultiSelect from '../../_components/MultiSelect';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';

const TotalKpi =(props)=>{
  const t = props.t;
  const prevProps = usePrevious(props);
  console.log( props.allvalues);
  const [state, setState] = useState({
    kpiValueOptions : [{
      value : window.KPI_TARGET_PERCENTAGE,
      label : 'Percentage',
    },
    {
      value : window.KPI_TARGET_VALUE,
      label : 'Value',
    }],
    // targetdata_kpi     : props.allvalues['kpidata']['targetdata_kpi'],
    // actualdata_kpi     : props.allvalues['kpidata']['actualdata_kpi'],
    maximumKPI         : props.allvalues['kpidata']['maximumKPI'],
    minimumKPI         : props.allvalues['kpidata']['minimumKPI'],
    maximumKPI_option  : props.allvalues['kpidata']['maximumKPI_option'],
    minimumKPI_option  : props.allvalues['kpidata']['minimumKPI_option'],
    Submitted : props.Submitted,
    isDisable : false,
  })
  useEffect (() =>{
    setVariables ();
  },[])

  useEffect (() =>{
    // props.allvalues['kpidata']['targetdata_kpi']         = state.targetdata_kpi;
    // props.allvalues['kpidata']['actualdata_kpi']         = state.actualdata_kpi;
    props.allvalues['kpidata']['maximumKPI_option']      = state.maximumKPI_option;
    props.allvalues['kpidata']['minimumKPI_option']      = state.minimumKPI_option;
    props.allvalues['kpidata']['maximumKPI']             = state.maximumKPI;
    props.allvalues['kpidata']['minimumKPI']             = state.minimumKPI;
    props.kpidataVariables(props.allvalues);
  },[state])

  function setVariables () {
    console.log( props.allvalues['kpidata']);
   setState({...state,
    //  targetdata_kpi : props.allvalues['kpidata']['targetdata_kpi'],
    //  actualdata_kpi : props.allvalues['kpidata']['actualdata_kpi'],
     maximumKPI_option :  props.allvalues['kpidata']['maximumKPI_option'] ,
     minimumKPI_option :  props.allvalues['kpidata']['minimumKPI_option'] ,
     maximumKPI         :  props.allvalues['kpidata']['maximumKPI'],
     minimumKPI       :  props.allvalues['kpidata']['minimumKPI'],
     Submitted       :  props.Submitted,
     isDisable       :  props.action=='View'?true:false,
   })
 }
  useEffect(() => {
    if(prevProps) {
      if(prevProps.Submitted!=props.Submitted||prevProps.num!=props.num){
         setVariables ();
      }
    }
  })

  const targetMaxMinChanges = (e, name) => {
    setState({...state, [name] : e})
  }
  const handlenum=(name,value)=>{
    const re = /^[0-9\b]+$/;
      if(value === undefined || re.test(value) ){
        setState({...state,
            [name]:value
          })
        props.allvalues['kpidata'][name] = value;
      }
  }
  const getFieldBasedOnSelection = (target, obj) => {
    if (obj !== undefined) {
      switch (obj.value) {
        case 1:
          return (
            <div class="col-md-8">
              <reactbootstrap.FormControl
                placeholder="$target$*%/frequency"
                // onChange={(e) => setState({ ...state, [target]: e.target.value })}
                onChange={(e)=>handlenum(target,e.target.value)}
                value={target === 'maximumKPI' ? state.maximumKPI : state.minimumKPI}
                disabled={state.isDisable}
                className="input_sw"
              />
            </div>
          );
        case 2:
          return (
            <div class="col-md-8">
              <reactbootstrap.FormControl
                placeholder={target === 'minimumKPI' ? "$target$-value/frequncy" : "$target$+value/frequency"}
                onChange={(e)=>handlenum(target,e.target.value)}
                // onChange={(e) => setState({ ...state, [target]: e.target.value })}
                value={target === 'minimumKPI' ? state.minimumKPI : state.maximumKPI}
                disabled={state.isDisable}
                className="input_sw"
              />
            </div>
          );
        default:
          return (
            <> </>
          );
      }
    }
  }

  const formDisable = (props.action === 'Create' && props.Submitted === true && props.Valid === true) ? 'disabled' : '';

  return(
    <reactbootstrap className=" row ">
       <div className="col-md-12" >
         <reactbootstrap.Container className=" pb-4">
            <reactbootstrap.Form>
              <fieldset disabled={formDisable}>
            {/*   <reactbootstrap.FormGroup>
               <div className=" row input-overall-sec ">
                 <reactbootstrap.InputGroup>
                   <div className="col-md-4">
                     <reactbootstrap.InputGroup.Prepend>
                       <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Target data KPI:')}</p><span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                     </reactbootstrap.InputGroup.Prepend>
                   </div>
                   <div class="col-md-8 input-padd" >
                       <reactbootstrap.FormControl
                           style={{ height: '150px' }}
                           as="textarea"
                           name="targetdata_kpi"
                           disabled={state.isDisable}
                           value={state.targetdata_kpi}
                           onChange={(e) => setState({ ...state, targetdata_kpi: e.target.value })}
                           className="input_sw"
                       />

                       {state.Submitted && state.targetdata_kpi === '' && <div style={{ color: 'red' }} className="error-block">{t('Target data KPI field is required')}</div>}
                   </div>

                 </reactbootstrap.InputGroup>
               </div>
               </reactbootstrap.FormGroup>
               <reactbootstrap.FormGroup>
               <div className=" row input-overall-sec ">
                 <reactbootstrap.InputGroup>
                   <div className="col-md-4">
                     <reactbootstrap.InputGroup.Prepend>
                       <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Actual data KPI:')}</p><span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                     </reactbootstrap.InputGroup.Prepend>
                   </div>
                   <div class="col-md-8 input-padd" >
                       <reactbootstrap.FormControl
                           style={{ height: '150px' }}
                           as="textarea"
                           name="actualdata_kpi"
                           disabled={state.isDisable}
                           value={state.actualdata_kpi}
                           onChange={(e) => setState({ ...state, actualdata_kpi: e.target.value })}
                           className="input_sw"
                       />
                       {state.Submitted &&  state.actualdata_kpi === '' && <div style={{ color: 'red' }} className="error-block">{t('Actual data KPI field is required')}</div>}
                   </div>

                 </reactbootstrap.InputGroup>
               </div>
               </reactbootstrap.FormGroup>*/}

            <reactbootstrap.FormGroup>
              <div className=" row input-overall-sec ">
                <reactbootstrap.InputGroup className="  ">
                  <div className="col-md-4">
                    <reactbootstrap.InputGroup.Prepend>
                      <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Minimum KPI:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                    </reactbootstrap.InputGroup.Prepend>
                  </div>
                  <div class="col-md-8 row m-0 p-0">
                    <div className="col-md-4 p-0">
                      <MultiSelect
                        options={state.kpiValueOptions}
                        standards={state.minimumKPI_option}
                        id="kpi_option2"
                        handleChange={(e) => targetMaxMinChanges(e, 'minimumKPI_option')}
                        isMulti={false}
                        disabled={state.isDisable}
                        placeholder={'Select'}
                      />
                      {state.Submitted && state.minimumKPI === undefined && <div style={{ color: 'red' }} className="error-block">{t('Minimum KPI field is required')}</div>}
                    </div>
                    <div className="col-md-8 input-padd p-0">
                      {getFieldBasedOnSelection('minimumKPI', state.minimumKPI_option)}
                    </div>
                  </div>
                </reactbootstrap.InputGroup>
              </div>
            </reactbootstrap.FormGroup>
            <reactbootstrap.FormGroup>
              <div className=" row input-overall-sec ">
                <reactbootstrap.InputGroup className="  ">
                  <div className="col-md-4">
                    <reactbootstrap.InputGroup.Prepend>
                      <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Maximum KPI:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                    </reactbootstrap.InputGroup.Prepend>
                  </div>
                  <div class="col-md-8 row m-0 p-0">
                    <div className="col-md-4 p-0">
                      <MultiSelect
                        options={state.kpiValueOptions}
                        standards={state.maximumKPI_option}
                        id="kpi_option1"
                        handleChange={(e) => targetMaxMinChanges(e, 'maximumKPI_option')}
                        isMulti={false}
                        disabled={state.isDisable}
                        placeholder={'Select'}
                      />

                      {state.Submitted && state.maximumKPI === undefined  && <div style={{ color: 'red' }} className="error-block">{t('Maximum KPI field is required')}</div>}
                    </div>
                    <div className="col-md-8 input-padd p-0">
                      {getFieldBasedOnSelection('maximumKPI', state.maximumKPI_option)}
                    </div>
                  </div>
                </reactbootstrap.InputGroup>
              </div>
            </reactbootstrap.FormGroup>
              <div style={{border: '1px solid black'}}>
                <ul>
                  <li>$target$</li>
                  <li>$actual$</li></ul>
                <p>Ex:</p>
                <ul>
                  <li>$target$*percentage/frequency</li>
                  <li>$target$+value/frequency</li>
                  <li>$target$-value/frequency</li>
                  <li>$target$*10%/2</li>
                  <li>$target$-10/2</li>
                  <li>$target$+10/2</li>                        
                </ul>
                
              </div>
          </fieldset>
         </reactbootstrap.Form>
         </reactbootstrap.Container>
         </div>

     </reactbootstrap>

  );
}

export default translate(TotalKpi);
function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  }, [value]);
  return ref.current;
}
