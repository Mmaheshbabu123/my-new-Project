import React, { useState, useEffect, useRef } from 'react';
import MultiSelect from '../../_components/MultiSelect';
import * as reactbootstrap from "react-bootstrap";
import { translate } from '../../language';
import useFetch from '../../GroundPlan/InspectionPoint/Details/useFetch';
import { datasave } from '../../_services/db_services';

const KPIDetailsComponent = (props) => {
  const prevProps = usePrevious(props);
  // var data            =  useFetch(window.GETALLMANUALMANAGEMENTDETAILS,'GET');
  const manualOptions   = (props.allvalues['details']['manualOptions'].length > 0 || props.allvalues['details']['manualOptions'].length === undefined) ? props.allvalues['details']['manualOptions']:[];
  const folderOptions   = (props.allvalues['details']['folderOptions'].length > 0 || props.allvalues['details']['folderOptions'].length === undefined) ? props.allvalues['details']['folderOptions']:[];
  const documentOptions = (props.allvalues['details']['documentOptions'].length > 0 || props.allvalues['details']['documentOptions'].length === undefined) ? props.allvalues['details']['documentOptions']:[];
  const t = props.t;
  const [state, updateStateValues] = useState({
    kpiName            : props.allvalues['details']['name'],
    description        : props.allvalues['details']['description'],
    folderOptions      : [],  documentOptions    : [],
    selectedManuals    : props.allvalues['details']['selectedManuals'],
    selectedFolders    : props.allvalues['details']['selectedFolders'],
    selectedWebform    : props.allvalues['details']['selectedWebform'],
    isDisable      : false,
    nameWarning    : props.allvalues['details']['nameWarning'],
    targetFolderOptions   : [],  targetDocumentsOptions   : [],
    targetSelectedManuals : {},  targetSelectedFolders    : {},
    targetSelectedWebform : {},  targetSelectedWebElement : {},
    Submitted : false,
    disable  : false,
    nameError : props.nameError,
    webelementOptions:[],
 });

  const handleManualChange = async (e) => {
    // var ids = await getSelectedIDs(e);
    let folders = folderOptions.filter((menu) =>menu.manual_id==e['value']);
    updateStateValues({...state,
          selectedManuals : e,
          folderOptions   : folders,
          selectedWebform  : [],
          selectedFolders  : [],
          documentOptions  : [],
    });
  }
  useEffect (() =>{
    setVariables (props.allvalues);
  },[])
 useEffect (() =>{
    props.allvalues['details']['name']=state.kpiName;
    props.allvalues['details']['description']=state.description;
    props.allvalues['details']['selectedManuals'] = state.selectedManuals!=undefined?state.selectedManuals:[];
    props.allvalues['details']['selectedFolders'] = state.selectedFolders!=undefined?state.selectedFolders:[];
    props.allvalues['details']['selectedWebform'] = state.selectedWebform!=undefined?state.selectedWebform:[];
    props.allvalues['details']['webelementOptions'] = state.webelementOptions;
  },[state])

   useEffect (() =>{
	    if(parseInt(props.allvalues['executeDateOptionService']) === 2){
    props.allvalues['dates']['selected_date_option'] =  ['99991||'+window.START_DATE, '99992||'+window.CREATE_DATE,
    '99993||'+window.SAVE_DATE].indexOf(props.allvalues['dates']['selected_date_option']['value']) !== -1 ?
		   props.allvalues['dates']['selected_date_option'] :
		   {label: 'Start date', value: "99991||"+ window.START_DATE};
	    }else{
	    props.allvalues['executeDateOptionService'] = parseInt(props.allvalues['executeDateOptionService']) === 1 || props.allvalues['executeDateOptionService'] === undefined ? 2 : props.allvalues['executeDateOptionService'];
	    }
   },[state.selectedManuals, state.selectedFolders, state.selectedWebform]);

   function setVariables (detailvalues) {
    updateStateValues({...state,
      kpiName : props.allvalues['details']['name'],
      description : props.allvalues['details']['description']!=null?props.allvalues['details']['description']:'',
      selectedManuals :  props.allvalues['details']['selectedManuals'],
      selectedFolders :  props.allvalues['details']['selectedFolders'],
      selectedWebform :  props.allvalues['details']['selectedWebform'],
      Submitted       :  props.Submitted,
      isDisable       :  props.action=='View'?true:false,
      nameError       : props.nameError,
    })
  }

  useEffect(() => {
    if(prevProps) {
      if(prevProps.Submitted!=props.Submitted||prevProps.nameError!==props.nameError||prevProps.num!=props.num){
        setVariables (props.allvalues);
      }
    }
  })

 const handleChangeFolders = async (e) => {
    // var ids = await getSelectedIDs(e);
    let docs = documentOptions.filter((menu) =>menu.parent_id==e['value']);
    updateStateValues({...state,
         selectedFolders :  e,
         documentOptions : docs,
         selectedWebform : [],
      });
  }

  const handleChangeDocs = (e) => {
    let id = e.value;
    datasave.service(window.FETCHALLWEBELEMENTS + '/'+id ,'GET')
    .then(async response=>{
       await updateStateValues({...state,
          selectedWebform : e,
          webelementOptions : response.data,
          webformWarning : false })
        })
  }

 const getSelectedIDs = async (data) =>{
   return  data.map(obj=>{ return obj['value'] });
 }

 const handleFilter = async(selctIds,dataObj) =>{
  let data = [];
  // for(var i = 0 ; i<selctIds.length;i++){
    if(dataObj[selctIds]!== undefined){
      Array.prototype.push.apply(data, Object.values(dataObj[selctIds]))
    }
  //  }
   return data;
  }

  const targetMaxMinChanges = (e, name) => {
    updateStateValues({...state, [name] : e})
  }
  const formDisable = ((props.action === 'Create'||props.action === 'Edit') && props.Submitted === true &&(props.Valid === true && props.nameError=='')) ? 'disabled' : '';
  return (
    <reactbootstrap className=" row ">
      <div className="col-md-12" >
        <reactbootstrap.Container className=" pb-4">
          <reactbootstrap.Form>
            <fieldset disabled={formDisable}>
              <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                  <reactbootstrap.InputGroup className="  ">
                    <div className="col-md-4">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("KPI name:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div class="col-md-8 input-padd">
                      <reactbootstrap.FormControl
                        name="kpiName"
                        placeholder="KPI name"
                        onChange={(e) => updateStateValues({ ...state, kpiName: e.target.value, nameError:''  })}
                        value={state.kpiName}
                        disabled={state.isDisable}
                        className="input_sw"
                      />
                      {state.Submitted && state.kpiName=='' && <div style={{ color: 'red' }} className="error-block">{t('Name is required field')}</div>}
                      {state.nameError !=""}<div style={{ color: 'red' }} className="error-block">{state.nameError}</div>
                    </div>
                  </reactbootstrap.InputGroup>
                </div>
              </reactbootstrap.FormGroup>
              <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                  <reactbootstrap.InputGroup className="  ">
                    <div className="col-md-4">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Description:')}</reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div class="col-md-8 input-padd">
                      <reactbootstrap.FormControl as="textarea"
                        name="description"
                        placeholder="Description"
                        value={state.description}
                        onChange={(e) => updateStateValues({ ...state, description: e.target.value })}
                        disabled={state.isDisable}
                        className="input_sw"
                      />
                    </div>
                  </reactbootstrap.InputGroup>
                </div>
              </reactbootstrap.FormGroup>
              <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                  <reactbootstrap.InputGroup className="  ">
                    <div className="col-md-4">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Select webform:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div class="col-md-8 p-0">
                      <div className="col-md-12 p-0">
                        <div className="row">
                          <div style={{}} className='col-md-12 mb-2' >
                            <MultiSelect
                              options={manualOptions}
                              standards={state.selectedManuals}
                              id="manuals"
                              handleChange={(e) => handleManualChange(e)}
                              isMulti={true}
                              disabled={state.isDisable || formDisable}
                              isMulti={false}
                              placeholder={'Select manuals'}
                            />
                          </div>
                          <div style={{}} className='col-md-12 mb-2'>
                            <MultiSelect
                              options={state.folderOptions}
                              standards={state.selectedFolders}
                              disabled={state.isDisable || formDisable}
                              id="folders"
                              isMulti={true}
                              handleChange={(e) => handleChangeFolders(e)}
                              isMulti={false}
                              placeholder={'Select folders'}
                            />
                          </div>
                          <div style={{}} className='col-md-12 mb-2'>
                            <MultiSelect
                              options={state.documentOptions}
                              standards={state.selectedWebform}
                              id="webform"
                              disabled={state.isDisable || formDisable}
                              handleChange={(e) => handleChangeDocs(e)}
                              isMulti={false}
                              placeholder={'Select webform'}
                            />
                            {state.Submitted && (state.selectedWebform!==undefined?state.selectedWebform.length==0:true) && <div style={{ color: 'red' }} className="error-block">{t('Webform field is required')}</div>}
                          </div>
                        </div>
                      </div>
                    </div>
                  </reactbootstrap.InputGroup>
                </div>
              </reactbootstrap.FormGroup>
          </fieldset>
          </reactbootstrap.Form>
        </reactbootstrap.Container>
      </div>
    </reactbootstrap>
  );
}
export default translate(React.memo(KPIDetailsComponent));

function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
