import React, { useState, useEffect, useRef } from 'react';
import { Button, Form, FormGroup } from 'reactstrap';
import {translate} from '../../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import { Editor } from 'react-draft-wysiwyg';
import { EditorState, convertToRaw, ContentState, convertFromRaw } from 'draft-js';
import htmlToDraft from 'html-to-draftjs';
import draftToHtml from 'draftjs-to-html';

const CreateEmailTemplate = props => {
  const [state, setState] = useState({
    t: props.t,
    activeTab: 1,
    name: '',
    language_data: [],
    language_list: props.language_list,
    kpiId: null,
    save: false,
    templateNameError: '',
    originalName: '',
    originalLanguageData: '',

  })

  useEffect(() => {
       if ((props.templateId !== null && props.templateId !== undefined)) {
         datasave.service(window.GET_KPI_TEMPLATE_DATA + '/' + props.templateId, 'GET')
            .then(async response => {
                if (response['status'] == 200) {
                  let language_data = response['data']['json_data'];
                  convertContentToEditorObj(language_data);
                    setState({
                      ...state,
                        name: response['data']['name'],
                        language_data: language_data,
                        originalName: response['data']['name'],
                        originalLanguageData: language_data,
                        templateNameError: '',
                    })
                }
            });
        } else if ((props.templateId === null) && (props.action === 0)){
          setState({
            ...state,
            name: '',
            language_data: [],
            templateNameError: '',
          })
        }
  }, [props]);

  const convertContentToEditorObj = async (language_data) => {
     if(Object.keys(language_data).length > 0){
        await Object.keys(language_data).map(key=>{
         if(key.indexOf('body') !== -1){
           let contentBlock = htmlToDraft(language_data[key]);
           if (contentBlock) {
             const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks);
             language_data[key] = EditorState.createWithContent(contentState);
           }
         }
       })
     }
   }

  const handleText = (name, value) => {
      setState({
        ...state,
         name: value,
         templateNameError: '',
        })
  }

  const handleSubBody = (name, value) => {
    if (props.action === 1 || props.mainAction === 'View') {
        return;
    }
      const obj = { [name]: value };
      const tempObj = {
         ...state.language_data,
         ...obj ,
       }
      setState({
        ...state,
        language_data: tempObj
      });
  }

  const handleSubmit = async () => {
    const {t} = state;
    let language_data = state.language_data;
    console.log(language_data);

    if (state.name !== undefined && state.name !== '' &&  state.templateNameError === '') {
      await convertEditorObjToContent(language_data);
      let data = {
          name: state.name,
          kpiId: (props.kpiId !== undefined && props.kpiId !== 0) ? props.kpiId : props.allvalues.emailtemplate.uniqueId,
          // goal_acomplished: 1, // remove it once after modifying all
          language_data: language_data,
          // tokensData: [],
      }
      if (props.templateId !== undefined && props.templateId !== null) {
        await datasave.service(window.UPDATE_KPI_TEMPLATE_DATA + '/' + props.templateId, 'PUT', data)
         .then(async response => {
           if (response.status === 200) {
             setState({
               ...state,
               name: '',
               language_data: [],
               save: false,
             })
             props.handleNewTemplates(1);
             // OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
           } else {
             if (response.error.name) {
               let language_data = response['data']['json_data'];
               convertContentToEditorObj(language_data);
               setState({
                 ...state,
                 language_data: language_data,
                 save: false,
                 templateNameError: (response.error.name) ? response.error.name : '',
               })
             } else {
               OCAlert.alertWarning(t('Something went wrong in saving data'), { timeOut: window.TIMEOUTNOTIFICATION });
             }
           }
         })
      } else {
        await datasave.service(window.KPI_EMAILTEMPLATE_SAVE, 'POST', data)
         .then(async response => {
           if (response.status === 200) {
             setState({
               ...state,
               name: '',
               language_data: [],
               save: false,
             })
             props.handleNewTemplates(0);
           } else {
             if (response.error.name) {
               let language_data = state.language_data;
               convertContentToEditorObj(language_data);
               setState({
                 ...state,
                 language_data: language_data,
                 save: false,
                 templateNameError: (response.error.name) ? response.error.name : '',
               })
             } else {
               OCAlert.alertWarning(t('Something went wrong in saving data'), { timeOut: window.TIMEOUTNOTIFICATION });
             }
           }
         })
      }
    } else {
      setState({
        ...state,
        save: true,
      })
    }
  }

  const convertEditorObjToContent = async (language_data) => {
    if(Object.keys(language_data).length > 0){
    await Object.keys(language_data).map(key => {
        if(key.indexOf('body') !== -1){
          language_data[key] = convToEditObjSubFunc(language_data[key]);
        }
      })
    }
  }

  const convToEditObjSubFunc = (data) => {
    if (data != undefined) {
      return draftToHtml(convertToRaw(data.getCurrentContent()));
    } else {
      return {};
    }
  }

  const handleCancel = () => {
    setState({
      ...state,
      name: state.originalName,
      language_data: state.originalLanguageData,
    })
    if (props.templateId !== undefined && props.templateId !== null) {
      props.handleNewTemplates(1);
    } else {
      props.handleNewTemplates(0);
    }

  }

  const handleTab = (key) => {
      setState({
        ...state,
        activeTab: key
       });
  }

  const displayTabs = () => {
      let table = [];
      if (state.language_list.length > 0) {
          table.push(<reactbootstrap.Tabs defaultActiveKey={state.activeTab} id="uncontrolled-tab-example" onSelect={(k) => handleTab(k)}>
              {getTab()}
          </reactbootstrap.Tabs>)
      }
      return table;
  }

  const getTab = () => {
      let language_list = state.language_list;
      let table = [];
      language_list.map(key => {
          table.push(
              <reactbootstrap.Tab eventKey={key['id']} title={key['language']} >
              </reactbootstrap.Tab>
          )
      })
      return table;
  }

  const displaySubjectBody = () => {
      let table = [];
      const { t } = state;
      let subject = state.language_data['subject_' + state.activeTab];
      let body = state.language_data['body_' + state.activeTab];

      table.push(
          <div>
            <div className="col-md-12 row p-0">
              <div style={{color: '#EC661C'}} className="col-md-2">
                <reactbootstrap.Form.Label>{t('Subject:')}</reactbootstrap.Form.Label>
              </div>
              <div className="col-md-10 pr-0">
                <reactbootstrap.Form.Group>
                    <reactbootstrap.Form.Control type={'text'} placeholder={t('E-mail subject')} value={subject != undefined ? subject : ''} onChange={(e) => handleSubBody('subject_' + state.activeTab, e.target.value)}></reactbootstrap.Form.Control>
                </reactbootstrap.Form.Group>
              </div>
            </div>
            <div className="col-md-12 row p-0">
              <div style={{color: '#EC661C'}} className="col-md-2">
                <reactbootstrap.Form.Label>{t('Body:')}</reactbootstrap.Form.Label>
              </div>
              <div className="col-md-10 pr-0">
                <Editor
                  editorStyle={{ minHeight: '130px' }}
                  editorState={body != undefined ? body : EditorState.createEmpty()}
                  toolbarClassName="toolbarClassName"
                  wrapperClassName="wrapperClassName"
                  editorClassName="editorClassName"
                  onEditorStateChange={(editorState) => handleSubBody('body_' + state.activeTab, editorState)}
                  toolbar={{
                    options: ['inline', 'blockType', 'fontFamily','fontSize', 'colorPicker', 'list', 'textAlign', 'history', 'link','remove'],
                  }}
                />
              </div>
            </div>
          </div>
      )
      return table;
  }

  const {t, templateNameError} = state;
  const formDisable = (props.action === 0 || props.action === 2) ? '' : 'disabled';
  //create 0, ( view )selected tempalte 1, edit 2
  const formDisableMain = ((props.mainAction === 'Create' || props.mainAction === 'Edit') && props.Submitted === true && (props.Valid === true)) ? 'disabled' : '';

  return (
    <div className='container'>
      <div className='row ' >
        <div className='col-md-12 px-0' >
          <div className='card'>
            <div className='card-body px-0 mb-3 createSection' >
              <reactbootstrap.Container className="">
                {displayTabs()}
                <reactbootstrap.Form >
                  <fieldset disabled={formDisable || formDisableMain}>
                    <reactbootstrap.FormGroup>
                      <div className="  input-overall-sec ">
                        <reactbootstrap.InputGroup style={{ padding: '8px'}} className="  ">
                          <div className="col-md-12 row p-0">
                              <div style={{color: '#EC661C'}} className="col-md-2">
                                  <reactbootstrap.Form.Label>{t('Name:')}<span style={{color: 'red'}}>*</span></reactbootstrap.Form.Label>
                              </div>
                              <div className="col-md-10 pr-0">
                                  <reactbootstrap.Form.Group>
                                      <reactbootstrap.Form.Control type={'text'} placeholder={t('Name')} value={state.name} onChange={(e) => handleText('name', e.target.value)}></reactbootstrap.Form.Control>
                                      <span style={{ color: 'red' }}>{}</span>
                                  </reactbootstrap.Form.Group>
                              </div>
                              {((state.save === true) && (state.name === '')) &&
                                <div style={{ color: 'red' }} className="error-block">{t('Name is required')}</div>
                              }
                              <div style={{ color: 'red' }} className="error-block mt-2">{templateNameError}</div>
                          </div>
                          {displaySubjectBody()}
                        </reactbootstrap.InputGroup>
                      </div>
                    </reactbootstrap.FormGroup>
                  </fieldset>
                </reactbootstrap.Form>
              </reactbootstrap.Container>
            </div>
          </div>
        </div>
      </div>
      <FormGroup>
        <div style={{marginRight: '-14px'}} className="organisation_list mt-3 text-right">
          <a onClick={handleCancel} >{t('Cancel')}</a>
          &nbsp;&nbsp;&nbsp;
          <Button className="btn btn-primary" type="button" color="primary" onClick={() => handleSubmit()}> {t('Save template')} </Button>
        </div>
      </FormGroup>
    </div>
  )
}

export default translate(CreateEmailTemplate);
