import React, { useState, useEffect } from 'react';
import { Button, Form } from 'reactstrap';
import {translate} from '../../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import Can from '../../../_components/CanComponent/Can';

const ManageEmailTemplates = props => {
  const [state, setState] = useState({
    t: props.t,
    emailTemplates: props.allvalues.emailtemplate.templates,
    kpiId: null,
    showTrigger: false,
    deleteId: null,
  })

  useEffect(() => {
    if (props.allvalues.emailtemplate.uniqueId === null) {
      const idInstedKpiId = Math.floor(10000 + Math.random() * 90000);
      props.allvalues.emailtemplate.uniqueId = idInstedKpiId;
      window.KPI_DEFAULT_TEMPLATES.map(item => {
        let data = {
            name: item.name,
            kpiId: idInstedKpiId,
            language_data: item.languageData,
        }
        datasave.service(window.KPI_EMAILTEMPLATE_SAVE, 'POST', data)
         .then(async response => {
           if (response.status === 200) {
             // OCAlert.alertSuccess(t('Default templates created successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
           } else {
             OCAlert.alertWarning(t('Unable to create default template' . item.name), { timeOut: window.TIMEOUTNOTIFICATION });
           }
         })
      })

    }
    if (((props.kpiId !== 0 && props.kpiId !== undefined) || (props.allvalues.emailtemplate.uniqueId !== null)) && (!props.Submitted || (props.Submitted && props.Valid === false))) {
      getAllTemplates()
    }

  }, [props]);

  const getAllTemplates = async () => {
    let kpiId = (props.kpiId !== 0 && props.kpiId !== undefined) ? props.kpiId : props.allvalues.emailtemplate.uniqueId;
    await datasave.service(window.GET_KPI_EMAILTEMPLATES + '/' + kpiId, 'GET')
        .then(async response => {
            setState({
              ...state,
              emailTemplates: response.data.allData,
            })
            props.allvalues.emailtemplate.templates = response.data.allData;
        })
  }

  const handleOnClick = (Id, action) => {
    if (((props.action === 'Create' || props.action === 'Edit') && props.Submitted === true && props.Valid === true) || (props.action === 'View')) {
      return
    } else {
      props.handleEmailTemplate(Id, action);
    }
  }

  const handleDelete = async (Id) => {
    if (((props.action === 'Create' || props.action === 'Edit') && props.Submitted === true && props.Valid === true) || (props.action === 'View')) {
      return
    } else {
      let kpiId = (props.kpiId !== 0 && props.kpiId !== undefined) ? props.kpiId : props.allvalues.emailtemplate.uniqueId;
      await datasave.service(window.DELETE_KPI_TEMPLATE + '/' + kpiId + '/' + Id, 'PUT')
          .then(async response => {
            if (response.status === 200) {
              if (response.data.used) {
                setState({
                  ...state,
                  showTrigger: true,
                  deleteId: Id,
                })
              } else {
                setState({
                  ...state,
                  component: false,
                  emailTemplates: response.data.allData,
                })
                props.allvalues.emailtemplate.templates = response.data.allData;
              }
           }
          });
    }
  }

  const handleHide = () => {
  setState({ ...state, showTrigger: false });
}

const handleNo = () => {
  setState({ ...state, showTrigger: false });
}

const handleYes = async () => {
  let kpiId = (props.kpiId !== 0 && props.kpiId !== undefined) ? props.kpiId : props.allvalues.emailtemplate.uniqueId;
  if (state.deleteId !== null) {
    await datasave.service(window.DELETE_TEMPLATELINKEDDATA  + '/' + kpiId + '/' + state.deleteId, 'PUT')
        .then(async response => {
           if (response.status === 200) {
               setState({
                 ...state,
                 showTrigger: false,
                 component: false,
                 emailTemplates: response.data.allData,
               })
             props.allvalues.emailtemplate.templates = response.data.allData;
          }
        });
  }
}

  const { t, emailTemplates} = state;
  // const formDisable = ((props.action === 'Create' || props.action === 'Edit') && props.Submitted === true && (props.Valid === true)) ? true : false;

  const warningPopup = (
    <reactbootstrap.Modal
        show={state.showTrigger}
        onHide={handleHide}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
    >
        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
              Warning
          </reactbootstrap.Modal.Title>
          <reactbootstrap.Modal.Body>
              <p>{t("This template is used in kpi trigger.If you want to delete this template?")}</p>
              <div style={{ float: 'right' }} className="organisation_list mt-3">
                <Button className="btn btn-primary" type="button" color="primary" onClick={() => handleNo()}> {t('No')} </Button>
                &nbsp;&nbsp;&nbsp;
                <Button className="btn btn-primary" type="button" color="primary" onClick={() => handleYes()}> {t('Yes')} </Button>
              </div>
          </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal.Header>
    </reactbootstrap.Modal>
);

  const getTemplates = (e) => {
    let table = [];
    {
      emailTemplates.length > 0 &&
        emailTemplates.map(item => {
          let higlet_class = (item.id === props.templateId) ? 'sactive' : 'sinactive';
            table.push(
              <tr style={{borderBottom: '1px solid lightgray'}}  className={higlet_class}>
                <Can
                   perform = "Access_kpi,V_KPI_template,E_KPI_template,D_KPI_template"
                   yes = {() => (
                    <div style={{ cursor: 'default' }} title='KpiEmail'>
                       <td style={{borderTop: '0px'}}>{item.name} </td>
                    </div>
                  )}
                />
                <Can
                   perform = "Access_kpi,E_KPI_template"
                   yes = {() => (
                      <>
                        <td style={{borderTop: '0px'}}>
                          <i title="Edit" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc"
                            onClick={e => handleOnClick(item.id, 2)} >
                          </i>
                        </td>
                      </>
                  )}
                />
                <Can
                   perform = "Access_kpi,V_KPI_template"
                   yes = {() => (
                      <>
                        <td>
                          <i title="View" style={{ cursor: 'pointer' }} class="overall-sprite overall-sprite-gridopenc" onClick={(e) => handleOnClick(item.id, 1)}></i>
                        </td>
                      </>
                  )}
                />
                <Can
                   perform = "Access_kpi,D_KPI_template"
                   yes = {() => (
                      <td>
                        <i title="Delete" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec"
                          onClick={e => handleDelete(item.id)}  >
                        </i>
                        {warningPopup}
                      </td>
                  )}
                />
              </tr>
            )
        })
    }
    return table;
  }

  return (
    <reactbootstrap.Form>
      <reactbootstrap.Container className="px-0" style={{height: '400px',overflow: 'auto'}}>
        <div className='col-md-12  mt-3' style={{ height: '377px', overflow: 'auto', border: '1px solid lightgray',borderRadius: '5px',padding: '5px'}}>
          <reactbootstrap.Table className="site-table-main KPItemplate">
            <tbody>
              {getTemplates()}
            </tbody>
          </reactbootstrap.Table>
        </div>
      </reactbootstrap.Container>
    </reactbootstrap.Form>
  )
}

export default translate(ManageEmailTemplates);
