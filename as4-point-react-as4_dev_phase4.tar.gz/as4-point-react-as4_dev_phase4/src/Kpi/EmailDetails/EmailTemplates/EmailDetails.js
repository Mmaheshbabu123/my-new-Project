import React, { useState, useEffect } from 'react';
import { Form } from 'reactstrap';
import {translate} from '../../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import ManageEmailTemplates from './ManageEmailTemplates';
import '../emaildetail.css';
import CreateEmailTemplate from './CreateEmailTemplate';
import Can from '../../../_components/CanComponent/Can';
import './emailtemplate.css';

const EmailDetails = props => {
  const [state, setState] = useState({
    t: props.t,
    component: false,
    templateAction: 0,
    templateId: null,
    language_list: [],
    templateAdded: false,
    templateCreationPopup: false,
  })

  useEffect(() => {
    datasave.service(window.GET_TRANSLATION, 'GET')
      .then(response => {
          setState({
            ...state,
            language_list: response,
            component: false,
          })
      });
  }, [props]);

  const {t} = state;

  const handleAdd = () => {
    if ((((props.action === 'Create' || props.action === 'Edit') && props.Submitted === true) && (props.Valid === true)) || (props.action === 'View')) {
      return
    } else {
    setState({
        ...state,
        component: true,
        templateAction: 0,
        templateId: null,
        templateCreationPopup: true,
      });
    }
  }

  const handleEmailTemplate = (id, templateAction) => {
    setState({
        ...state,
        component: true,
        templateAction: templateAction,
        templateId: id,
        templateCreationPopup: true,
      });
  }

  const handleNewTemplates = async (latestTemplateAction) => {
      let kpiId = (props.kpiId !== 0 && props.kpiId !== undefined) ? props.kpiId : props.allvalues.emailtemplate.uniqueId;
      await datasave.service(window.GET_KPI_EMAILTEMPLATES + '/' + kpiId, 'GET')
          .then(async response => {
              setState({
                ...state,
                emailTemplates: response.data.allData,
                templateAdded: true,
                templateCreationPopup: false,
                templateAction: latestTemplateAction,
              })
              props.allvalues.emailtemplate.templates = response.data.allData;
          })
  }

  const handleHide = () => {
    setState({
      ...state,
      templateCreationPopup: false,
    })
  }

  const createTemplateContent = (
      <reactbootstrap.Modal
          size='xl'
          show={state.templateCreationPopup}
          onHide={handleHide}
          dialogClassName="modal-90w emailDetailpopup"
          aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header closeButton>
            <reactbootstrap.Modal.Body>
              <div class="col-md-12 mt-3 mb-3 ">
                  <div className="row">
                  <div class="col-md-8">
                      <div className="mb-3" style={{ borderBottom: '1px solid lightgray' }} >
                          <span><h4>{t('Create email template')}</h4></span>
                      </div>
                      <div>
                          <CreateEmailTemplate allvalues={props.allvalues} mainAction={props.action} kpiId={props.kpiId} Submitted={props.Submitted} Valid={props.Valid} action={state.templateAction} templateId={state.templateId} language_list={state.language_list} handleNewTemplates={handleNewTemplates}></CreateEmailTemplate>
                      </div>
                  </div>
                  <div class="col-md-4 pl-5">
                      <reactbootstrap.Form.Label><h4>{t('Tokens:')}</h4></reactbootstrap.Form.Label>
                      <ul style={{paddingLeft: '17px', fontSize: '14px'}}>
                          {Object.values(window.KPI_TOKENS).map(item => (
                              <li>{item}</li>
                            ))
                          }
                      </ul>
                  </div>
                  </div>
              </div>
            </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal.Header>
      </reactbootstrap.Modal>
  );

  return (
    <reactbootstrap>
        <div class="row col-md-12 mt-3 mb-3">
            <div className="col-md-12 px-0">
                <div style={{ display: 'flex', borderBottom: '1px solid lightgray' }} >
                    <span><h4>{t('Manage email templates')}</h4></span>
                    <Can
                       perform = "Access_kpi,E_KPI_template"
                       yes = {() => (
                          <>
                            <div style={{ alignSelf: 'center' }} className="ml-3">
                                <reactbootstrap style={{ cursor: 'pointer' }} title={t("Add email")} onClick={(e) => handleAdd()}><i class="webform-sprite webform-sprite-addemailc"></i></reactbootstrap>
                            </div>
                          </>
                      )}
                    />
                </div>
                <Can
                   perform = "Access_kpi,E_KPI_template,V_KPI_template,D_KPI_template"
                   yes = {() => (
                      <>
                        <ManageEmailTemplates allvalues={props.allvalues} kpiId={props.kpiId} action={props.action} Submitted={props.Submitted} Valid={props.Valid} handleEmailTemplate={handleEmailTemplate} addedTemplate={state.templateAdded} templateId={state.templateId}></ManageEmailTemplates>
                      </>
                  )}
                />
            </div>
        </div>
        {(state.component === true) &&
          <div style={{width: '150%'}}>
          {createTemplateContent}
          </div>
        }
    </reactbootstrap>
  )
}

export default translate(EmailDetails);
