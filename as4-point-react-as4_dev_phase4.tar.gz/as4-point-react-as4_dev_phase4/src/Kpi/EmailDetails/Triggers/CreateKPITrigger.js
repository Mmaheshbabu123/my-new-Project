import React, { useState, useEffect } from 'react';
import { Button, Form, FormGroup } from 'reactstrap';
import {translate} from '../../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import MultiSelect from '../../../_components/MultiSelect';
import { OCAlert } from '@opuscapita/react-alerts';

const CreateKPITrigger = (props) => {
  const [state, setState] = useState({
    t: props.t,
    triggerName: '',
    selectedOperator: window.DEFAULT_OPERATOR,
    selectedComparator: window.DEFAULT_COMPARATOR,
    templateOptions: props.emailTemplates,
    selectedTemplate: [],
    triggerNameError: '',
    save: false,
    originalTriggerName: '',
    originalSelectedOperator: window.DEFAULT_OPERATOR,
    originalSelectedComparator: window.DEFAULT_COMPARATOR,
    originalSelectedTemplate: [],
  })

  useEffect(() => {
    if (props.triggerId !== undefined && props.triggerId !== null) {
      datasave.service(window.GET_TRIGGER_DATA + '/' + props.triggerId, 'GET')
            .then(async response => {
                setState({
                  ...state,
                  triggerName: response.data.name,
                  selectedOperator: response.data.selectedOperator,
                  selectedComparator: response.data.selectedComparator,
                  selectedTemplate: response.data.selectedTemplate,
                  originalTriggerName: response.data.name,
                  originalSelectedOperator: response.data.selectedOperator,
                  originalSelectedComparator: response.data.selectedComparator,
                  originalSelectedTemplate: response.data.selectedTemplate,
                })
            })

    } else {
      setState({
        ...state,
        triggerName: '',
        selectedOperator: window.DEFAULT_OPERATOR,
        selectedComparator: window.DEFAULT_COMPARATOR,
        selectedTemplate: [],
        triggerNameError: '',
      })
    }
  }, [props])

  const selectOperator = (value) => {
    setState({
      ...state,
      selectedOperator: value,
    })
  }

  const selectComparator = (value) => {
    setState({
      ...state,
      selectedComparator: value,
    })
  }

  const handleSelectTemplate = (value) => {
    setState({
      ...state,
      selectedTemplate: value,
    })
  }

  const handleSubmit = async () => {
    let data = {
        kpiId: (props.kpiId !== undefined && props.kpiId !== 0) ? props.kpiId : props.allvalues.emailtemplate.uniqueId,
        name: triggerName,
        email_ref_id: parseInt(selectedTemplate.value),
        operator: parseInt(selectedOperator.value),
        comparator: parseInt(selectedComparator.value),
    }

    if (triggerName !== null && triggerName !== '' && (selectedTemplate.length > 0 || selectedTemplate.value)) {
      if (props.triggerId !== undefined && props.triggerId !== null) {
        await datasave.service(window.UPDATE_KPI_TRIGGERS + '/' + props.triggerId, 'PUT', data)
         .then(async response => {
           if (response.status === 200) {
              props.handleTriggers();
              // OCAlert.alertSuccess(t('Updated data successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
           } else {
             if (response.error.name) {
               setState({
                 ...state,
                save: false,
                 triggerNameError: (response.error.name) ? response.error.name : '',
               })
             } else {
               OCAlert.alertWarning(t('Something went wrong in saving data'), { timeOut: window.TIMEOUTNOTIFICATION });
             }
           }
         })
       } else {
         await datasave.service(window.CREATE_KPI_TRIGGER, 'POST', data)
          .then(async response => {
            if (response.status === 200) {
              props.handleTriggers();
            } else {
              if (response.error.name) {
                setState({
                  ...state,
                  save: false,
                  triggerNameError: (response.error.name) ? response.error.name : '',
                })
              } else {
                OCAlert.alertWarning(t('Something went wrong in saving data'), { timeOut: window.TIMEOUTNOTIFICATION });
              }
            }
          })
       }
    } else {
      setState({
        ...state,
        save: true,
      })
    }
  }

  const handleCancel = () => {
    setState({
      ...state,
      triggerName: state.originalTriggerName,
      selectedOperator: state.originalSelectedOperator,
      selectedComparator: state.originalSelectedComparator,
      selectedTemplate: state.originalSelectedTemplate,
    })
    props.handleTriggers();
  }

  const {t, triggerName, templateOptions, selectedOperator, selectedComparator, selectedTemplate, triggerNameError} = state;
  const formDisable = (props.triggerAction === 1) ? 'disabled' : '';

  return (
    <reactbootstrap.Container className="pt-5 px-0">
        <reactbootstrap.Form>
          <fieldset disabled={formDisable}>
            <div className='col-md-12 px-0'>
              <reactbootstrap.InputGroup className="  ">
                <div className="col-md-4 pl-0">
                  <reactbootstrap.InputGroup.Prepend>
                    <reactbootstrap.InputGroup style={{ color: '#EC661C', fontSize: '14px' }} id="basic-addon1">{t("KPI trigger name:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                  </reactbootstrap.InputGroup.Prepend>
                </div>
                <div class="col-md-8 input-padd">
                  <reactbootstrap.FormControl
                    name="triggerName"
                    placeholder="Trigger name"
                    onChange={(e) => setState({ ...state, triggerName: e.target.value, triggerNameError: ''})}
                    value={state.triggerName}
                    disabled={formDisable}
                    className="input_sw"
                  />
                </div>
                {((state.save === true) && (state.triggerName === '')) &&
                  <div style={{ color: 'red' }} className="error-block">{t('Name is required')}</div>
                }
                <div style={{ color: 'red' }} className="error-block mt-2">{triggerNameError}</div>
              </reactbootstrap.InputGroup>
              <reactbootstrap.InputGroup className=" my-3 ">
                <div className="col-md-4 pl-0">
                  <reactbootstrap.InputGroup.Prepend>
                    <reactbootstrap.InputGroup style={{ color: '#EC661C', fontSize: '14px' }} id="basic-addon1">{t("Actual:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                  </reactbootstrap.InputGroup.Prepend>
                </div>
                <div className="col-md-4 pl-0">
                  <MultiSelect
                    options={window.KPI_TRIGGER_OPERATOR}
                    standards={state.selectedOperator}
                    handleChange={e => selectOperator(e)}
                    disabled={formDisable}
                    isMulti={false} />
                </div>
                <div className="col-md-4 pr-0">
                  <MultiSelect
                    options={window.KPI_TRIGGER_COMPARATOR}
                    standards={state.selectedComparator}
                    handleChange={e => selectComparator(e)}
                    disabled={formDisable}
                    isMulti={false} />
                </div>
              </reactbootstrap.InputGroup>
            </div>
            <div className='col-md-12 px-0 my-3'>
              <reactbootstrap.InputGroup  className="  ">
                 <div className="col-md-4 pl-0">
                     <reactbootstrap.InputGroup.Prepend>
                         <reactbootstrap.InputGroup style={{  color: '#EC661C', fontSize: '14px' }} id="basic-addon1">
                          <span>{t('Select KPI e-mail template')} <span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></span>

                         </reactbootstrap.InputGroup>
                     </reactbootstrap.InputGroup.Prepend>
                 </div>
                 <div className="col-md-8 px-0">
                   <MultiSelect
                     options={templateOptions}
                     standards={selectedTemplate}
                     handleChange={e => handleSelectTemplate(e)}
                     disabled={formDisable}
                     isMulti={false} />
                 </div>
                 {((state.save === true) && (!selectedTemplate.value)) &&
                   <div style={{ color: 'red' }} className="error-block">{t('select email template')}</div>
                 }
             </reactbootstrap.InputGroup>
           </div>
           <FormGroup>
             <div style={{ float: 'right' }} className="organisation_list mt-3">
               <a onClick={handleCancel} >{t('Cancel')}</a>
               &nbsp;&nbsp;&nbsp;
               <Button className="btn btn-primary" type="button" color="primary" onClick={() => handleSubmit()}> {t('Save trigger')} </Button>
             </div>
           </FormGroup>
         </fieldset>
        </reactbootstrap.Form>
    </reactbootstrap.Container>
  );

}

export default translate(CreateKPITrigger);
