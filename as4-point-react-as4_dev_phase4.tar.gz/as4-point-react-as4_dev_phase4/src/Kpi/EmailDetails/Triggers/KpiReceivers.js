import React, { useState, useEffect } from 'react';
import {translate} from '../../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import PersonImg from '../../../images/personc.png';
import JobImg from '../../../images/jobc.png';
import DepartmentImg from '../../../images/departmentsc.png';
import GroupImg from '../../../images/groupc.png';
import DeleteImg from '../../../images/delete1.png';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import SearchInput, { createFilter } from 'react-search-input';
import { Button, Form, FormGroup } from 'reactstrap';
import { OCAlert } from '@opuscapita/react-alerts';


const KpiReceivers = (props) => {

  const [state, setState] = useState({
    t: props.t,
    activeKey: 0,
    items: [],
    types: [],
    tabs: [],
    selected: [],
    html: window.HTML_OBJECT,
    html_right: window.HTML_RIGHT,
    searchType: '',
    searchTerm: [],
    KEYS_TO_FILTERS: window.search_fields,
    persons: [],
    curently_hovered_item: [],
    show: false,
  })

  useEffect(() => {
      let allItems = [];
      let accessIds = [];
      if (props.triggerId !== null && props.triggerId !== undefined) {
        datasave.service(window.SHOW_TRIGGER_RECEIVERS + '/' + props.triggerId, "GET")
          .then(response => {
              accessIds = response.data.selectedIds;
              allItems = response.data.allData.filter(item => (!accessIds.includes(item.id)))
              setState({
                  ...state,
                  items: allItems,
                  types: response.data.tabs,
                  tabs: response.data.tabs,
                  selected: response.data.selectedData,
                  originalItems: allItems,
                  originalTypes: response.data.tabs,
                  originalTabs: response.data.tabs,
                  originalSelected: response.data.selectedData,
              })
          })
      }
  }, [props]);

  const getFlexStyle = ({
      display: 'flex',
  });
  const imageStyle = ({
      width: 20,
      cursor: "default",
  });
  const TextCurser = ({
      cursor: "default",
  });
  const textinline = ({
      display: '-webkit-inline-flex',
  });
  const grid = 8;
  const getListStyle = isDraggingOver => ({
      background: isDraggingOver ? 'lightblue' : '#fff',
      padding: grid,
      width: 250,
  });

  const onSelect = (e) => {
    setState({
        ...state,
        activeKey: parseInt(e),
    });
  }

  const move = (source, destination, droppableSource, droppableDestination, draggableId) => {
      const sourceClone = Array.from(source);
      const destClone = Array.from(destination);
      const [removed] = sourceClone.filter(items => items.id === draggableId);
      destClone.splice(droppableDestination.index, 0, removed);
      const result = {};
      result[droppableSource.droppableId] = sourceClone.filter(items => items.id !== draggableId);
      result[droppableDestination.droppableId] = destClone;
      result['latestDropped'] = removed;
      result['type'] = (droppableDestination.droppableId === 'droppable') ? 'remove' : 'add';
      return result;
  };

  const onDragEnd = (resultObj) => {
      const { source, destination, draggableId } = resultObj;
      if (!destination) {
          return;
      }
      if (source.droppableId === destination.droppableId) {
          return;
      } else {
          const result = move(
              getList(source.droppableId),
              getList(destination.droppableId),
              source,
              destination,
              draggableId
          );
          handleDragSelectedChange(result);
      }
  };

  const id2List = {
      droppable: 'items',
      droppable2: 'selected'
  };

  const handleDragSelectedChange = (result) => {
      setState({
          ...state,
          items: result.droppable,
          selected: result.droppable2
      });

      // props.allvalues.emailtemplate.receivers = result.droppable2;
  }

  const getList = id => state[id2List[id]];

  const handleClicktr = (resultObj) => {
    if (((props.action === 'Create' || props.action === 'Edit') && props.Submitted === true && props.Valid === true) || (props.action === 'View')) {
        return;
    } else {
      var selected = state.selected;
      var remove = selected.filter(item => (item.name !== resultObj.name && item.id !== resultObj.id));
      let allItems = [...state.items, resultObj]

      allItems.sort(function(a,b) {
        a = a.name.toLowerCase();
        b = b.name.toLowerCase();
        if( a == b) return 0;
        return a < b ? -1 : 1;
      });
      setState({
          ...state,
          items: allItems,
          // items: [...state.items, resultObj],
          selected: remove,
      });
    }
  }

  const handlePersons = (item) => {
      if (parseInt(item.category_id) !== window.PERSON_ENTITY) {
          // setState({ ...state, show: true });
          if (state.persons[item.id]) {
              setState({
                  ...state,
                  show: true,
                  curently_hovered_item: state.persons[item.id]
              })
          }
          else {
              const loaded_persons = state.persons;
              const url = window.GetAllLinkedPersons + '/' + item.id + '/' + parseInt(item.category_id)
              datasave.service(url, "GET", '')
                  .then(result => {
                      const all_persons = {
                          ...loaded_persons,
                          ...result
                      }
                      setState({
                          ...state,
                          show: true,
                          persons: all_persons,
                          curently_hovered_item: result[item.id]
                      })
                  })
                  .catch(error => {

                  })
          }
      }
  }

  const handleSubmit = async () => {
    let data = {
        templateId: props.triggerId,
        selected : state.selected,
        kpiId: (props.kpiId !== 0 && props.kpiId !== undefined) ? props.kpiId : props.allvalues.emailtemplate.uniqueId,
    }
    if ((props.triggerId !== undefined && props.triggerId !== null)) {
      await datasave.service(window.SAVE_TRIGGER_RECEIVERS, 'POST', data)
       .then(async response => {
         if (response.status === 200) {
            props.receiversAdded();
            OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
         } else {
           props.receiversAdded();
           OCAlert.alertWarning(t('Something went wrong in saving data'), { timeOut: window.TIMEOUTNOTIFICATION });
         }
       })
     }
  }

  const handleHide = () => {
      setState({ ...state, show: false });
  }

  const searchUpdated = (term, itemlist) => {
      const items = { ...state.searchTerm };
      items[itemlist] = term;
      setState({
          ...state,
          searchTerm: items,
          searchType: itemlist,
      })
  }

  const handleCancel = () => {
    setState({
      ...state,
      items: state.originalItems,
      types: state.originalTypes,
      tabs: state.originalTabs,
      selected: state.originalSelected,
    })
  }

  const {t, types, selected} = state;

  var search = '';
  const dragDisable = (((props.action === 'Create' || props.action === 'Edit') && props.Submitted === true && props.Valid === true) || props.action === 'View') ? true : false;
  const formDisable = (dragDisable === true) ? 'disabled' : '';

  const popupContent = (
      <reactbootstrap.Modal
          show={state.show}
          onHide={handleHide}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
          <reactbootstrap.Modal.Header closeButton>
              <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                  Persons
          </reactbootstrap.Modal.Title>
              <reactbootstrap.Modal.Body className="px-0">
                  <ul>
                      {state.curently_hovered_item.length != 0 &&
                          state.curently_hovered_item.map(person =>
                              <li>{person.name}</li>
                          )
                      }
                      {state.curently_hovered_item.length === 0 &&
                          t('No persons are linked')
                      }
                  </ul>
              </reactbootstrap.Modal.Body>
          </reactbootstrap.Modal.Header>
      </reactbootstrap.Modal>
  );

  var filteredNames = [];
  const dragObject =
    <reactbootstrap.Tabs activeKey={state.activeKey} onSelect={(e) => onSelect(e)} id="controlled-tab-example">
        {Object.values(types).map((itemlist, key) => {
            if (state.searchTerm && state.searchType) {
                search = state.searchTerm[itemlist];
                search = (search !== undefined) ? search : '';
            }
            filteredNames[itemlist] = state.items.filter(createFilter(search, state.KEYS_TO_FILTERS));
            return (
            <reactbootstrap.Tab className="dragndropavailable" eventKey={key} title={t(itemlist.charAt(0).toUpperCase() + itemlist.slice(1))}>
                <reactbootstrap.Table className="available-item-section" striped bordered responsive hover variant="dark">
                    <thead style={{position: 'sticky',top: '0', backgroundColor: '#fff'}}>
                      <tr>
                          <td style={{padding: '10px 0px', border: 'none'}} colSpan="3">
                              <SearchInput style={{color: '#EC661C', border: 'none'}} className="search-input" onChange={(e) => searchUpdated(e, itemlist)} />
                          </td>
                      </tr>
                      <tr>
                        {state.html_right[0][itemlist].map(rights =>
                            <th style={{backgroundColor: '#EC661C', color: '#fff',border: 'none'}} title={t(rights.name)}>{t(rights.name)}</th>
                        )}
                      </tr>
                    </thead>
                    <tbody>
                        {Object.values(filteredNames[itemlist]).map(
                            function (item, index) {
                                if (item !== undefined && item.id !== undefined && item.category === itemlist) {
                                    return (
                                      <Draggable
                                        isDragDisabled={dragDisable}
                                        key={item.id}
                                        draggableId={item.id}
                                        type={item.category}
                                        index={index}>
                                        {(provided, snapshot) => (
                                            <tr
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                            >
                                                <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6'}}>
                                                    <div className="" style={textinline}>
                                                        <div>
                                                            <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" onClick={(e) => handlePersons(item)}/>
                                                            &nbsp;
                                                        </div>
                                                        &nbsp;
                                                        <div>
                                                            {item.name}
                                                        </div>
                                                    </div>
                                                    {popupContent}
                                                </td>
                                                {item.category != 'persons' &&
                                                    <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6', textAlign:'center'}}>
                                                        {item.abbrevation}
                                                    </td>
                                                }
                                            </tr>
                                        )}
                                      </Draggable>
                                    )
                                }
                            })}
                    </tbody>
                </reactbootstrap.Table>
            </reactbootstrap.Tab>
          )
        })}
    </reactbootstrap.Tabs>

  return (
    <div className="col-md-12 my-3 pr-0">
      <div  className="row">
          <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="droppable2">
                  {(provided, snapshot) => (
                      <div className="slected-available-border dragndropavailable mb-3 col-md-6 mr-5"
                          ref={provided.innerRef}
                          style={getListStyle(snapshot.isDraggingOver)}>
                          <p>Selected items</p>
                          <reactbootstrap.Table striped bordered hover responsive variant="dark">
                              <thead style={{backgroundColor: '#EC661C', position: 'sticky',top: '0',borderColor: '1px solid #EC661C'}}>
                                  <tr>
                                    {state.html[0][props.type].map(commons =>
                                        <th style={{paddingTop: '20px', border: 'none'}}  className ={commons.class} title={t(commons.name)}></th>
                                    )}
                                  </tr>
                              </thead>
                              <tbody>
                                    {selected.map(
                                      function (item, index) {
                                        return (
                                          <tr style={{backgroundColor: '#fff', color: '#282c34', borderBottom: '1px solid lightgray'}} >
                                              <td style={{ border: 'none'}}>
                                                  <div className="borde" style={textinline} >
                                                      <div>
                                                          {item.category !== 'spaces' &&
                                                              <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" onClick={(e) => handlePersons(item)}/>
                                                          }
                                                      </div>
                                                      &nbsp;
                                                      <div style={TextCurser}>
                                                          {item.name}
                                                      </div>
                                                  </div>
                                                  {popupContent}
                                              </td>
                                              <td style={{textAlign: 'center',  border: 'none'}}>
                                                  {item.abbrevation}
                                              </td>
                                              <td  style={{textAlign: 'center', border: 'none'}} >
                                                  <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => handleClicktr(item)}></img>
                                              </td>
                                          </tr>
                                        )
                                      })}
                                  {provided.placeholder}
                              </tbody>
                          </reactbootstrap.Table>
                      </div>
                  )}
              </Droppable>
              <Droppable droppableId="droppable">
                  {(provided, snapshot) => (
                      <div
                      className="slected-available-border1 mb-3 col-md-5"
                          ref={provided.innerRef}
                          style={getListStyle(snapshot.isDraggingOver)}
                      >
                          <p>Available items</p>
                          {provided.placeholder}
                          {dragObject}
                      </div>
                  )}
              </Droppable>
          </DragDropContext>
      </div>
      <fieldset disabled={formDisable}>
        {/* {(dragDisable !== true) && */}
          <div>
            <FormGroup>
              <div style={{ float: 'right', marginRight: '-14px' }}  className="organisation_list mt-3 ">
                <a onClick={handleCancel} >{t('Cancel')}</a>
                &nbsp;&nbsp;&nbsp;
               <Button className="btn btn-primary" type="button" color="primary" onClick={handleSubmit}> {t('Save receivers')} </Button>
              </div>
            </FormGroup>
          </div>
        {/* } */}
      </fieldset>
    </div>
  )
}
export default translate(KpiReceivers)
