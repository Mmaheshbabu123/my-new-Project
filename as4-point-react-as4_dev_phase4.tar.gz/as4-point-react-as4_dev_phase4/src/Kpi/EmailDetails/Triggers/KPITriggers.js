import React, { useState, useEffect } from 'react';
import { Form } from 'reactstrap';
import {translate} from '../../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import KpiReceivers from './KpiReceivers';
import CreateKPITrigger from './CreateKPITrigger';
import Can from '../../../_components/CanComponent/Can';

const KPITriggers = (props) => {
  const [state, setState] = useState({
    t: props.t,
    addtrigger: false,
    kpiTriggersList: props.allvalues.emailtemplate.triggers,
    showReceivers: false,
    triggerId: null,
    emailTemplates: props.allvalues.emailtemplate.templates,
    triggerAction: null,
    triggerCreationPopup: false,
    triggerReceiversPopup: false,
  })

  useEffect(() => {
    if (((props.kpiId !== 0 && props.kpiId !== undefined) || (props.allvalues.emailtemplate.uniqueId !== null)) && (!props.Submitted  || (props.Submitted && props.Valid === false))) {
      getAllTriggers()
    }
  }, [props])

  const getAllTriggers = async () => {
    let kpiId = (props.kpiId !== 0 && props.kpiId !== undefined) ? props.kpiId : props.allvalues.emailtemplate.uniqueId;
    await datasave.service(window.SHOW_KPI_TRIGGERS + '/' + kpiId, 'GET')
      .then(async response => {
        setState({
          ...state,
          addtrigger: false,
          showReceivers: false,
          kpiTriggersList: response.data.triggers,
          emailTemplates: response.data.templates,
        })
        props.allvalues.emailtemplate.triggers = response.data.triggers;
        props.allvalues.emailtemplate.templates = response.data.templates;
      })
  }

  const handleTrigger = () => {
    if (((props.action === 'Create' || props.action === 'Edit') && props.Submitted === true && props.Valid === true) || (props.action === 'View')) {
      return
    } else {
      setState({
        ...state,
        addtrigger: true,
        showReceivers: false,
        triggerId: null,
        triggerCreationPopup: true,
      })
    }
  }

  const handleClick = (id) => {
    // if (((props.action === 'Create' || props.action === 'Edit') && props.Submitted === true && props.Valid === true) || (props.action === 'View')) {
    //   return
    // } else {
      setState({
        ...state,
        addtrigger: false,
        showReceivers: true,
        triggerId: id,
        triggerReceiversPopup: true,
      })
    // }
  }

  const triggerCreated = () => {
    getAllTriggers();
    setState({
      ...state,
      addtrigger: false,
      showReceivers: true,
      triggerCreationPopup: false,
    })
  }

  const receiversAdded = () => {
    setState({
      ...state,
      triggerReceiversPopup: false,
    })
  }

  const handleOnClick = (id, triggerAction) => {
    if (((props.action === 'Create' || props.action === 'Edit') && props.Submitted === true && props.Valid === true) || (props.action === 'View')) {
      return
    } else {
      setState({
        ...state,
        addtrigger: true,
        showReceivers: false,
        triggerId: id,
        triggerAction: triggerAction,
        triggerCreationPopup: true,
      })
    }
  }

  const deleteTrigger = async (Id) => {
    if (((props.action === 'Create' || props.action === 'Edit') && props.Submitted === true && props.Valid === true) || (props.action === 'View')) {
      return
    } else {
      let kpiId = (props.kpiId !== 0 && props.kpiId !== undefined) ? props.kpiId : props.allvalues.emailtemplate.uniqueId;
      await datasave.service(window.DELETE_TRIGGER + '/' + kpiId + '/' + Id, 'PUT')
          .then(async response => {
             if (response.status === 200) {
                setState({
                  ...state,
                  addtrigger: false,
                  showReceivers: false,
                  kpiTriggersList: response.data.triggers,
                })
                props.allvalues.emailtemplate.triggers = response.data.triggers;
            }
          });
    }
  }

  const handleHideTrigger = () => {
    setState({
      ...state,
      triggerCreationPopup: false,
      triggerReceiversPopup: false,
    })
  }

  const {t} = state;

  const createTrigger = (
      <reactbootstrap.Modal
          size='lg'
          show={state.triggerCreationPopup}
          onHide={handleHideTrigger}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
         >
        <reactbootstrap.Modal.Header closeButton>
            <reactbootstrap.Modal.Body>
              <div class="col-md-12 mt-3 mb-3 px-0">
                <div class="col-md-12 px-0">
                    <div style={{ borderBottom: '1px solid lightgray' }} >
                        <span><h4>{t('Create trigger')}</h4></span>
                    </div>
                    <div>
                      <CreateKPITrigger type={"common"} allvalues={props.allvalues} Submitted={props.Submitted} action={props.action} kpiId={props.kpiId} Valid={props.Valid} handleTriggers={triggerCreated} triggerId={state.triggerId} emailTemplates={state.emailTemplates} triggerAction={state.triggerAction}/>
                    </div>
                </div>
              </div>
            </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal.Header>
      </reactbootstrap.Modal>
  );

  const triggerReceivers = (
      <reactbootstrap.Modal
          size='lg'
          show={state.triggerReceiversPopup}
          onHide={handleHideTrigger}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
        <reactbootstrap.Modal.Header closeButton>
            <reactbootstrap.Modal.Body className="px-0">
              <div class="col-md-12 mt-3 mb-3 px-0">
                <div class="col-md-12 px-0">
                    <div style={{ borderBottom: '1px solid lightgray' }} >
                        <span><h4>{t('Trigger receivers')}</h4></span>
                    </div>
                    <div>
                      <KpiReceivers type={"common"} allvalues={props.allvalues} Submitted={props.Submitted} action={props.action} kpiId={props.kpiId} Valid={props.Valid} triggerId={state.triggerId} receiversAdded={receiversAdded}/>
                    </div>
                </div>
              </div>
            </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal.Header>
      </reactbootstrap.Modal>
  );

  const getTriggers = (e) => {
    var trigger = state.kpiTriggersList;

    let table = [];
    {
      trigger.length > 0 &&
        trigger.map(item => {
          let higlet_class = (item.id === state.triggerId) ? 'sactive' : 'sinactive';
            table.push(
              <tr style={{borderTop: '1px solid lightgray'}} className={higlet_class}>
                <Can
                   perform = "Access_kpi,E_KPI_Trigger,V_KPI_Trigger,D_KPI_Trigger"
                   yes = {() => (
                    <div style={{ cursor: 'default' }} title='KpiTrigger'>
                       {/* <td style={{borderTop: '0px'}}><i class="webform-sprite webform-sprite-envelopec"> </i> </td> */}
                       <td style={{borderTop: '0px'}}>
                         {item.name}
                       </td>
                    </div>
                  )}
                />
                <Can
                   perform = "Access_kpi,E_KPI_Trigger,V_KPI_Trigger,D_KPI_Trigger"
                   yes = {() => (
                     <td style={{borderTop: '0px'}}>
                       <i title="ShowReceivers" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-gridopenc"
                         onClick={e => handleClick(item.id)} >
                       </i>
                     </td>
                  )}
                />
                <Can
                   perform = "Access_kpi,E_KPI_Trigger"
                   yes = {() => (
                    <td style={{borderTop: '0px'}}>
                      <i title="Edit" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc"
                        onClick={e => handleOnClick(item.id, 2)} >
                      </i>
                    </td>
                  )}
                />
                <Can
                   perform = "Access_kpi,V_KPI_Trigger"
                   yes = {() => (
                    <td>
                      <i title="View" style={{ cursor: 'pointer' }} class="overall-sprite overall-sprite-gridopenc" onClick={(e) => handleOnClick(item.id, 1)}></i>
                    </td>
                  )}
                />
                <Can
                   perform = "Access_kpi,D_KPI_Trigger"
                   yes = {() => (
                    <td>
                      <i title="Delete" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec"
                        onClick={e => deleteTrigger(item.id)} >
                      </i>
                    </td>
                  )}
                />
                </tr>
              )
        })
    }
    return table;
  }

  return (
    <div>
      <div className='col-md-12 row p-0'>
        <div className="col-md-12 mt-3">
          <h4 className="mb-3 mt-2">KPI Trigger List</h4>
          <Can
             perform = "Access_kpi,E_KPI_Trigger"
             yes = {() => (
               <reactbootstrap.Button style={{ float: 'left', marginBottom: '15px' }} type="button" onClick={handleTrigger}> {t("Add KPI trigger")}</reactbootstrap.Button>
           )}
         />
          {/* <input type="text" className="form-control search-box-border col-md-6" placeholder='Search' style={{ borderRadius: "5px", borderColor: "#ec661c" }} onChange={searchData} /><br /> */}
          <Can
             perform = "Access_kpi,E_KPI_Trigger,V_KPI_Trigger,D_KPI_Trigger"
             yes = {() => (
              <div className='col-md-12 mt-3' style={{ height: '377px', overflow: 'auto',border: '1px solid lightgray',borderRadius: '5px',padding: '5px'}}>
                <reactbootstrap.Table className="site-table-main">
                  <tbody>
                    {getTriggers()}
                  </tbody>
                </reactbootstrap.Table>
              </div>
            )}
          />
        </div>
        {state.showReceivers &&
          <>
            {triggerReceivers}
          </>
        }
        {state.addtrigger === true &&
          <div>
            {createTrigger}
          </div>
        }
      </div>
    </div>
  )

}

export default translate(KPITriggers);
