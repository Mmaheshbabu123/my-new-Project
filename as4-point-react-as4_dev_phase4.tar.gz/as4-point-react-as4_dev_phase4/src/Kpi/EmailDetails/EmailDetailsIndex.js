import React, { Component } from 'react';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import {translate} from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import Emaildetails from './EmailTemplates/EmailDetails';
import KPITriggers from './Triggers/KPITriggers';
import Can from '../../_components/CanComponent/Can';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
import {CanPermissions} from '../../_components/CanComponent/CanPermissions';

class EmailDetailsIndex extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t:props.t,
      activeTab: 0,
    }
    this.handleSelectTab = this.handleSelectTab.bind(this);
  }

  componentDidUpdate(prevProps, prevState) {
  }

  handleSelectTab(e) {
    this.setState({
      activeTab:parseInt(e)
    });
  }

  render() {
    const {t} = this.state;
    const { activeTab } = this.state;

    return (
      <Can
         perform = "Access_kpi,E_KPI_template,V_KPI_template,D_KPI_template,E_KPI_Trigger,V_KPI_Trigger,D_KPI_Trigger"
         yes = {() => (
            <div className='container py-2' >
              <div className='row justify-content-center' >
                <div className='col-lg-12 col-md-12 float-left px-0' >
                    <reactbootstrap.Container className="p-1">
                      <reactbootstrap.Form >
                        <reactbootstrap.Tabs id="controlled-tab-example" activeKey={activeTab} onSelect={(e) => this.handleSelectTab(e)}>
                          {(CanPermissions("Access_kpi,E_KPI_template,V_KPI_template,D_KPI_template", "") === true) &&
                            <reactbootstrap.Tab eventKey={0} title={t("Email templates")}>
                              <Emaildetails allvalues={this.props.allvalues} Submitted={this.props.Submitted} action={this.props.action} kpiId={this.props.kpiId} Valid={this.props.Valid}/>
                            </reactbootstrap.Tab>
                          }
                          {(CanPermissions("Access_kpi,E_KPI_Trigger,V_KPI_Trigger,D_KPI_Trigger", "") === true) &&
                            <reactbootstrap.Tab eventKey={1} title={t('KPI triggers receivers')}>
                              <KPITriggers type={"common"} allvalues={this.props.allvalues} Submitted={this.props.Submitted} action={this.props.action} kpiId={this.props.kpiId} Valid={this.props.Valid}></KPITriggers>
                            </reactbootstrap.Tab>
                          }
                        </reactbootstrap.Tabs>
                      </reactbootstrap.Form>
                    </reactbootstrap.Container>
                </div>
              </div>
            </div>
          )}
          no={ () =>
            <AccessDeniedPage/>
          }
        />
    )
  }
}

export default translate(EmailDetailsIndex);
