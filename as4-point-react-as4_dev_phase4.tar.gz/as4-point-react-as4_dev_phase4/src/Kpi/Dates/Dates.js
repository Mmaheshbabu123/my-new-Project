import React, { useState, useEffect, useRef } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import DatePicker from "react-datepicker";
import { store } from '../../store';
import { datasave } from '../../_services/db_services';
import moment from 'moment';
import MultiSelect from '../../_components/MultiSelect';


const Dates = (props) => {
  const prevProps = usePrevious(props);
  const t = props.t;
  const Userdata = store.getState();
  let settings=Userdata['UserData']['systemsettings'];
  const [state, setState] = useState({
      startDate:props.allvalues['dates']['startDate'],
      endDate:props.allvalues['dates']['endDate'],
      frequencyValue:props.allvalues['dates']['frequencyValue'],
      select_year:props.allvalues['dates']['select_year'],
      frequencyType:props.allvalues['dates']['frequencyType'],
      Submitted : false,
      isDisable:false,
      dateisDisable:false,
      selected_date_option: props.allvalues['dates']['selected_date_option'],
      date_options: props.allvalues['dates']['date_options'],
      select_date_type : props.allvalues['dates']['select_date_type'],
      select_dates : props.allvalues['dates']['select_dates'],
      select_value : props.allvalues['dates']['select_date_type'],
      week_type   : props.allvalues['dates']['week_type'],
      select_bundle_type : props.allvalues['dates']['select_bundle_type'],
      select_graph_type : props.allvalues['dates']['select_graph_type'],
      bundles : props.allvalues['dates']['bundles'],
      graphs : props.allvalues['dates']['graphs'],

      // bundle_type  : props.allvalues['dates']
      quatervalues : [{
        id : 1,
        startmonth : 0,
        endmonth :2,
      },
      {
        id : 2,
        startmonth : 3,
        endmonth :5,
      },
      {
        id : 3,
        startmonth : 6,
        endmonth :8,
      },
      {
        id : 4,
        startmonth : 9,
        endmonth :11,
      }
    ]
    });
    useEffect (() =>{
      setVariables ();
    },[])

    useEffect(()=>{
    if(parseInt(props.allvalues['executeDateOptionService']) === 2){
      let webformId = props.allvalues['details']['selectedWebform']['value'] !== undefined ? 
		    props.allvalues['details']['selectedWebform']['value'] : 0;
     datasave.service(`${window.GET_WEBFORM_DATES}/${webformId}`, 'GET')
      .then(async response => {
      if(response['status'] == 200){
	let setObj = {date_options: response['data']['date_list'] !== undefined ? response['data']['date_list'] : []};
        if(setObj['date_options'].length > 0){
	setObj['selected_date_option'] = setObj['date_options'].filter(key=>{ 
	return key['value'] === state.selected_date_option['value'] ? 1 : 0 }).length > 0 ? state.selected_date_option : 
	      {label: 'Start date', value: "99991||"+ window.START_DATE};
	}
	setState({...state, ...setObj});
      }
      });
    }else{
       props.allvalues['executeDateOptionService'] = parseInt(props.allvalues['executeDateOptionService']) === 1 || props.allvalues['executeDateOptionService'] === undefined ? 2 : 
		    props.allvalues['executeDateOptionService'];
            }

    }, [props.allvalues['details']['selectedWebform']]);

    useEffect (() =>{
      props.allvalues['dates']['startDate']=state.startDate;
      props.allvalues['dates']['endDate']=state.endDate;
      props.allvalues['dates']['select_year'] = state.select_year;
      props.allvalues['dates']['frequencyValue'] = state.frequencyValue;
      props.allvalues['dates']['frequencyType'] = state.frequencyType;
      props.allvalues['dates']['select_date_type'] = state.select_date_type;
      props.allvalues['dates']['week_type'] = state.week_type;
      props.allvalues['dates']['select_bundle_type'] = state.select_bundle_type;
      props.allvalues['dates']['select_graph_type'] = state.select_graph_type;
      props.allvalues['dates']['select_graph_type'] = state.select_graph_type;
      props.allvalues['dates']['selected_date_option'] = state.selected_date_option;
      props.datesVariables(props.allvalues);
    },[state])
    function setVariables () {
      var selectvalue= props.allvalues['dates']['select_date_type']['value']!=undefined?props.allvalues['dates']['select_date_type']['value']:0;
     setState({...state,
       selected_date_option: props.allvalues['dates']['selected_date_option'],
       date_options: props.allvalues['dates']['date_options'],
       startDate : props.allvalues['dates']['startDate'],
       endDate : props.allvalues['dates']['endDate'],
       select_year :  props.allvalues['dates']['select_year'],
       frequencyValue :  props.allvalues['dates']['frequencyValue'],
       frequencyType :  props.allvalues['dates']['frequencyType'],
       select_date_type : props.allvalues['dates']['select_date_type'],
       Submitted       :  props.Submitted,
       isDisable       :  props.action=='View'?true:false,
       dateisDisable   :  props.action=='View'?true:(selectvalue==5?false:true),
       select_dates : props.allvalues['dates']['select_dates'],
       week_type   : props.allvalues['dates']['week_type'],
       select_value : props.allvalues['dates']['select_date_type']['value']!=undefined?props.allvalues['dates']['select_date_type']['value']:0,
       select_bundle_type : props.allvalues['dates']['select_bundle_type'],
       select_graph_type :  props.allvalues['dates']['select_graph_type'],
       bundles : props.allvalues['dates']['bundles'],
       graphs : props.allvalues['dates']['graphs'],
     })
   }

   useEffect(() => {
     if(prevProps) {
       if(prevProps.Submitted!=props.Submitted||prevProps.num!=props.num){
          setVariables ();
       }
     }

   })
    const handleChange =(event) =>{
        const {name, value} = event.target;
        const re = /^[0-9\b]+$/;
        if (name === 'frequencyValue') {
          if(value === '' || re.test(value)){
            setState({...state,
                [name]:value
              })
            props.allvalues['dates'][name] = value;
          }

        }
        else{
          setState({...state,
              [name]:value
            })
            props.allvalues['dates'][name] = value;
        }
    }

    const handleDate =async(event)=>{
      const {name, value} = event.target;
      let start_date='';
      let end_date='';
      let quality = ['6-2','7-2','8-2','9-2'];
      let fisical = ['11-2','12-2','13-2','14-2'];
      let year=new Date().getFullYear();
      if(value == 1){
        let valid = await validatedatefileds(quality);
        if (valid) {
          start_date=year+'-'+ settings["6-2"]+'-'+settings["7-2"];
          if(parseInt(settings["6-2"])<parseInt(settings["8-2"])){
            end_date=(year)+'-'+settings["8-2"]+'-'+settings["9-2"];
          }
          else {
            end_date=(year+1)+'-'+settings["8-2"]+'-'+settings["9-2"];
          }
        }else {
          OCAlert.alertWarning(t('Please select the date in system settings'), { timeOut: window.TIMEOUTNOTIFICATION });
        }

      }
      else{
        let valid = await validatedatefileds(quality);
        if (valid) {
          start_date=year+'-'+settings["11-2"]+'-'+settings["12-2"];
          if(parseInt(settings["11-2"])<parseInt(settings["13-2"])){
            end_date=(year)+'-'+settings["13-2"]+'-'+settings["14-2"];
          }
          else {
            end_date=(year+1)+'-'+settings["13-2"]+'-'+settings["14-2"];
          }
        }else {
          // start_date = new Date();
          // end_date = new Date();
          OCAlert.alertWarning(t('Please select the date in system settings'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      }
      await setState({...state,
        select_year:value,
        startDate:start_date!=''?moment(start_date).format("YYYY-MM-DD"):undefined,
        endDate:end_date!=''?moment(end_date).format("YYYY-MM-DD"):undefined,
        dateisDisable:start_date!=''&&end_date!=''?true:false,
      })
      props.allvalues['dates'][name] = value;
      props.allvalues['dates']['startDate'] = moment(start_date).format("YYYY-MM-DD");
      props.allvalues['dates']['endDate'] = moment(end_date).format("YYYY-MM-DD");
      }

      function addMonths(date, months) {
        var d = date.getDate();
        date.setMonth(date.getMonth() + +months);
        if (date.getDate() != d) {
          date.setDate(0);
        }
        return date;
    }

      const validatedatefileds = async(datevalues) => {
        let valid = 0;
        datevalues.map((item)=>{
          if(settings[item]==undefined||settings[item]==null) {
            valid++;
          }
        })
        let validationSuccess = (valid > 0) ? false : true;

        return validationSuccess;
      }


      const handleDateChange = async(event) => {
        let date_type = event.value;
        setDateChange(event);
      }
      async function handleStartandEndDate (date,type) {
        setDateChange(state.select_date_type,date,type);
      }


      async function setDateChange (date_type,selecteddate=0,type=0) {
        let start_date = undefined;
        let end_date = undefined;
        let datedisable = false;
        switch(date_type.value) {
          case 1:
            var date = selecteddate==0?new Date():selecteddate;
            var startdate = new Date(date.getFullYear(), date.getMonth(), 1);
            var enddate=new Date(date.getFullYear(), date.getMonth() + 1, 0);
            start_date = (startdate.getFullYear() + "-" + (startdate.getMonth() + 1) + "-" + startdate.getDate());
            end_date = (enddate.getFullYear() + "-" + (enddate.getMonth() + 1) + "-" + enddate.getDate());
            datedisable = true;
            break;
          case 2:
            if(state.week_type==false){
              var today =  selecteddate==0?new Date():selecteddate;
              var startdatediff = today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1);
              start_date = new Date(today.setDate(startdatediff));
              var lastdatediff = today.getDate() - (today.getDay() - 1) + 4;
              end_date =  new Date(today.setDate(lastdatediff));
              datedisable = true;
            }
            break;
          case 3:
            var date = selecteddate==0?new Date():selecteddate;
            var quater = Math.ceil((date.getMonth() + 1) / 3);
            var quaterendmonth = state.quatervalues.filter((menu) =>menu.id==quater);
            var enddate=new Date(date.getFullYear(), quaterendmonth[0]['endmonth'] + 1, 0);
            var startdate = new Date(date.getFullYear(), quaterendmonth[0]['startmonth'], 1);
            start_date = (startdate.getFullYear() + "-" + (startdate.getMonth() + 1) + "-" + startdate.getDate());
            end_date = (enddate.getFullYear() + "-" + (enddate.getMonth() + 1) + "-" + enddate.getDate());
            datedisable = true;
            break;
          case 4:
            start_date = undefined;
            end_date = undefined;
            datedisable = false;
            break;
          case 5:
            if (type==1) {
              await setState({...state,
                startDate:(selecteddate.getFullYear() + "-" + (selecteddate.getMonth() + 1) + "-" + selecteddate.getDate())
              })
              start_date = (selecteddate.getFullYear() + "-" + (selecteddate.getMonth() + 1) + "-" + selecteddate.getDate());
              end_date= state.endDate;
            }else if (type==2){
              await setState({...state,
                endDate:(selecteddate.getFullYear() + "-" + (selecteddate.getMonth() + 1) + "-" + selecteddate.getDate())
              })
              start_date = state.startDate;
              end_date = (selecteddate.getFullYear() + "-" + (selecteddate.getMonth() + 1) + "-" + selecteddate.getDate());
            }
            datedisable = false;
            break;
          default:
            return false;
        }
        await setState({...state,
          startDate : start_date,
          endDate   : end_date,
          select_date_type : date_type,
          select_value : date_type.value,
          week_type : false,
          dateisDisable : datedisable,
        })
      }

      async function setWeekDate(e) {
        if (!state.week_type==true) {
          var today = new Date();
          var calculatedays = today.getDay()!=0 ? 7-today.getDay():7-7;
          calculateWeekdays(today,calculatedays);
        }
        else {
          var today = new Date();
          var calculatedays = (today.getDay()!=6&&today.getDay()!==0) ? 5-today.getDay():5-5;
          calculateWeekdays(today,calculatedays);
        }
      }
      async function calculateWeekdays (today,calculatedays) {
        var diff = today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1);
        await setState({...state,
          week_type : !state.week_type,
          startDate :  new Date(new Date().setDate(diff)),
          endDate : (moment(today.setDate(today.getDate() + +parseInt(calculatedays))).format("YYYY-MM-DD")),
          dateisDisable:true,
        })
      }
   
	 const handleDateOptionChange = (name, value) =>{
	  setState({...state, ...{[name]: value}});
	 }
    const formDisable = ((props.action === 'Create'||props.action === 'Edit') && props.Submitted === true && props.Valid === true) ? 'disabled' : '';
      return(
        <reactbootstrap className=" row ">
          <div className="col-md-12" >
            <reactbootstrap.Container className=" pb-4">
               <reactbootstrap.Form>
                  <fieldset disabled={formDisable}>
                  <reactbootstrap.FormGroup>
                     <div className=" row input-overall-sec ">
                          <reactbootstrap.InputGroup className="  ">
                              <div className="col-md-4">
                                   <reactbootstrap.InputGroup.Prepend>
                                       <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Select date option:')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></p></reactbootstrap.InputGroup>
                                   </reactbootstrap.InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd" >
                                <div style={{}} className='col-md-12 mb-2 px-0' >
                                  <MultiSelect
                                    options={state.date_options}
                                    standards={state.selected_date_option}
                                    id="dates"
                                    handleChange={(e)=>handleDateOptionChange('selected_date_option', e)}
                                    disabled={state.isDisable || formDisable}
                                    isMulti={false}
                                    placeholder={t('Select date option')}
                                  />
                                </div>

                              </div>
                          </reactbootstrap.InputGroup>
                          {state.Submitted && state.select_date_type.length == 0 && <div style={{ color: 'red' }} className="error-block">{t('Please select the option')}</div>}
                      </div>
                  </reactbootstrap.FormGroup>
                  <reactbootstrap.FormGroup>
                     <div className=" row input-overall-sec ">
                          <reactbootstrap.InputGroup className="  ">
                              <div className="col-md-4">
                                   <reactbootstrap.InputGroup.Prepend>
                                       <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Select type:')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></p></reactbootstrap.InputGroup>
                                   </reactbootstrap.InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd" >
                                <div style={{}} className='col-md-12 mb-2 px-0' >
                                  <MultiSelect
                                    options={state.select_dates}
                                    standards={state.select_date_type}
                                    id="dates"
                                    handleChange={handleDateChange}
                                    disabled={state.isDisable || formDisable}
                                    isMulti={false}
                                    placeholder={t('Select date type')}
                                  />
                                </div>

                              </div>
                          </reactbootstrap.InputGroup>
                          {state.Submitted && state.select_date_type.length == 0 && <div style={{ color: 'red' }} className="error-block">{t('Please select the option')}</div>}
                      </div>
                  </reactbootstrap.FormGroup>
                  {state.select_value ==4 &&
                  <reactbootstrap.FormGroup>
                     <div className=" row input-overall-sec ">
                          <reactbootstrap.InputGroup className="  ">
                              <div className="col-md-4">
                                   <reactbootstrap.InputGroup.Prepend>
                                       <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Select the year:')}</p></reactbootstrap.InputGroup>
                                   </reactbootstrap.InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd" >
                                   <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="quality_year" value ="1" disabled={state.isDisable} checked={state.select_year ==1} onChange={handleDate} name="select_year"/>
                                        <label class="custom-control-label" for="quality_year">Quality year</label>
                                   </div>
                                   <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="fiscal_year" value ="2" disabled={state.isDisable} checked={state.select_year ==2} onChange={handleDate}  name="select_year"/>
                                        <label class="custom-control-label" for="fiscal_year">Fiscal year</label>
                                   </div>
                              </div>
                          </reactbootstrap.InputGroup>
                      </div>
                  </reactbootstrap.FormGroup>}
                  {state.select_value ==2 &&
                  <reactbootstrap.FormGroup>
                     <div className=" row input-overall-sec ">
                          <reactbootstrap.InputGroup className="  ">
                              <div class="col-md-8 px-4 input-padd" >
                              <reactbootstrap.Form.Check
                                  onChange={e => setWeekDate(e)}
                                  checked={state.week_type}
                                  name="week_type"
                                  className="col-md-12"
                                  disabled={state.isDisable}
                                  label={t("Include week ends")}
                                />
                              </div>

                          </reactbootstrap.InputGroup>
                      </div>
                  </reactbootstrap.FormGroup>}

                  {window.DATE_STATUS.includes(state.select_value.toString())&&
                  <reactbootstrap.FormGroup>
                    <div className=" row input-overall-sec ">
                      <reactbootstrap.InputGroup >
                        <div className="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Start date KPI:')}</p><span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                        </div>
                      <div class="col-md-8 input-padd " >
                        <DatePicker
                              className="form-control input_sw"
                              name="startDate"
                              selected={ state.startDate !== undefined&&state.startDate!=''&&state.startDate!=null ? new Date(state.startDate):undefined}
                              onChange={(date) => handleStartandEndDate(date,1)}
                              disabled={state.isDisable || state.dateisDisable}
                              dateFormat="dd-MM-yyyy"
                              placeholderText="dd/mm/yyyy"
                              isOutsideRange={() => false}
                        />
                        {state.Submitted && state.startDate === undefined && <div style={{ color: 'red' }} className="error-block">{t('Start date KPI field is required')}</div>}
                      </div>
                    </reactbootstrap.InputGroup>
                  </div>
                </reactbootstrap.FormGroup>}
                {window.DATE_STATUS.includes(state.select_value.toString()) &&

                  <reactbootstrap.FormGroup>
                     <div className=" row input-overall-sec ">
                        <reactbootstrap.InputGroup >
                           <div className="col-md-4">
                             <reactbootstrap.InputGroup.Prepend>
                                <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('End date KPI:')}</p><span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                                                                                                                                                                                                                                                                                                                                                       </reactbootstrap.InputGroup.Prepend>
                          </div>
                          <div class="col-md-8 input-padd">
                             <DatePicker
                                className="input_sw form-control"
                                name="endDate"
                                disabled={state.isDisable || state.dateisDisable}
                                selected={ state.endDate !== undefined&&state.endDate!=''&&state.endDate!=null ? new Date(state.endDate):undefined}
                                onChange={(date) => handleStartandEndDate(date,2)}
                                placeholderText="dd/mm/yyyy"
                                dateFormat="dd-MM-yyyy"
                                isOutsideRange={() => false}
                             />
                             {state.Submitted && state.endDate === undefined && <div style={{ color: 'red' }} className="error-block">{t('End date KPI field is required')}</div>}
                         </div>
                       </reactbootstrap.InputGroup>
                    </div>
                  </reactbootstrap.FormGroup>}
                  {window.DATE_STATUS.includes(state.select_value.toString()) &&
                  <reactbootstrap.FormGroup>
                     <div className=" row input-overall-sec ">
                          <reactbootstrap.InputGroup className="  ">
                             <div className="col-md-4">
                                  <reactbootstrap.InputGroup.Prepend>
                                      <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Frequency to check:')}</p></reactbootstrap.InputGroup>
                                  </reactbootstrap.InputGroup.Prepend>
                             </div>
                             <div class="col-md-5 input-group input-padd">
                                  <reactbootstrap.FormControl
                                      name="frequencyValue"
                                      placeholder="Frequency to check"
                                      disabled={state.isDisable}
                                      value={state.frequencyValue}
                                      onChange={handleChange}
                                      className="input_sw"
                                  />
                            </div>
                            <div className="col-md-3 input-group input-padd">
                                <reactbootstrap.FormControl
                                    name="frequencyType"
                                    disabled={state.isDisable}
                                    as="select"
                                    value={state.frequencyType}
                                    onChange={handleChange}
                                    className="input_sw">
                                    <option value="days">{t('Days')}</option>
                                    <option value="weeks">{t('Weeks')}</option>
                                    <option value="months">{t('Months')}</option>
                                    <option value="years">{t('Years')}</option>
                                </reactbootstrap.FormControl>
                           </div>
                      </reactbootstrap.InputGroup>
                   </div>
                   <reactbootstrap.FormGroup>
                     <div className=" row input-overall-sec ">
                          <reactbootstrap.InputGroup className="  ">
                              <div className="col-md-4">
                                   <reactbootstrap.InputGroup.Prepend>
                                       <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Bundle type:')}</p></reactbootstrap.InputGroup>
                                   </reactbootstrap.InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd " >
                                <div style={{}} className='col-md-12 mb-2 px-0' >
                                  <MultiSelect
                                    options={state.bundles}
                                    standards={state.select_bundle_type}
                                    id="bundles"
                                    handleChange={(e)=>setState({...state,select_bundle_type:e})}
                                    disabled={state.isDisable || formDisable}
                                    isMulti={false}
                                    placeholder={t('Select time periood')}
                                  />
                                </div>
                              </div>
                          </reactbootstrap.InputGroup>
                      </div>
                  </reactbootstrap.FormGroup>
                  <reactbootstrap.FormGroup>
                     <div className=" row input-overall-sec ">
                          <reactbootstrap.InputGroup className="  ">
                              <div className="col-md-4">
                                   <reactbootstrap.InputGroup.Prepend>
                                       <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1"><p>{t('Graph type:')}</p></reactbootstrap.InputGroup>
                                   </reactbootstrap.InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd" >
                                <div style={{}} className='col-md-12 mb-2 px-0' >
                                  <MultiSelect
                                    options={state.graphs}
                                    standards={state.select_graph_type}
                                    id="graph"
                                    handleChange={(e)=>setState({...state,select_graph_type:e})}
                                    disabled={state.isDisable || formDisable}
                                    isMulti={false}
                                    placeholder={t('Select graph type')}
                                  />
                                </div>

                              </div>
                          </reactbootstrap.InputGroup>
                      </div>
                  </reactbootstrap.FormGroup>
                </reactbootstrap.FormGroup>}
               </fieldset>
              </reactbootstrap.Form>
            </reactbootstrap.Container>
          </div>
        </reactbootstrap>
      );

}
export default translate(Dates)
function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
