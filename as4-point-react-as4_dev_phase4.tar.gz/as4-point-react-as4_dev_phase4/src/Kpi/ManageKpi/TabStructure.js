import React, { Component } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import Details from '../Details/Details';
import Emaildetails from '../EmailDetails/EmailDetailsIndex';
import Dates from '../Dates/Dates';
import Access from '../Access/Access';
import { datasave } from '../../_services/db_services';
// import TargetData from '../TargetData/TargetData';
import KpiData from '../KpiData/KpiData';
import { OCAlert } from '@opuscapita/react-alerts';
let TargetData='targetdata';
let allRequireFileds = {
  details : ['name', 'selectedWebform'],
  access : [],
  dates :['startDate','endDate','select_date_type']
}
let allkpidataRequireFileds ={
  targetdata:['target_type'],
  actualdata:['actual_type'],
}
class Tabstructure extends Component {
  constructor(props) {
    super(props)
    this.state = {
      active_tab : 1,
      t:props.t,
      Submitted: false,
      details : this.props.kpi_details != undefined?this.props.kpi_details:[],
      action : '',
      id : 0,
      nameError : '',
      Valid: true,
    }

    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.detailsVariables = this.detailsVariables.bind(this);
    this.datesVariables = this.datesVariables.bind(this);
    this.emaildetailsVariables = this.emaildetailsVariables.bind(this);
    this.accessVariables = this.accessVariables.bind(this);
    this.targetdataVariables = this.targetdataVariables.bind(this);
    this.kpidataVariables = this.kpidataVariables.bind(this);
  }

  componentDidMount() {
    // this.setActions();
  }
  async componentDidUpdate(prevProps, prevState) {
    if(prevProps.num!=this.props.num) {
      await this.setState({
        action : this.props.action,
        id : this.props.id,
        Submitted : this.props.Submitted,
        nameError : '',
      })
    }
  }

  detailsVariables (details) {
  //   this.setState({
  //     allvalues : details,
  //   })
  }
  datesVariables (dates) {
      // allvalues = dates;
  }
  emaildetailsVariables () {

  }
  targetdataVariables (targetdata) {
      // allvalues = targetdata;
  }
  kpidataVariables (kpidata){
    if(kpidata['type']=='targetdata'){
        this.props.allvalues['kpidata']['targetdata']['targetquery']=kpidata['query']
    }
    else if (kpidata['type']=='actualdata') {
        this.props.allvalues['kpidata']['actualdata']['actualquery']=kpidata['query']
    }
    else if (kpidata['type']=='minimumKPI_query') {
        this.props.allvalues['kpidata']['targetdata']['minimumKPI_query']=kpidata['query']
    }
    else if(kpidata['type']=='maximumKPI_query'){
        this.props.allvalues['kpidata']['targetdata']['maximumKPI_query']=kpidata['query']
    }

      // allvalues = kpidata;
  }
  accessVariables () {

  }
  async handlePageClick (key) {
    await this.setState({
      active_tab: Number(key),
    });
  }
  async handleSubmit () {
    let valid = await this.validateFields();
    await this.setState({
      Submitted: false,
      Valid: valid,
    })
    const data = {
      kpi : this.props.allvalues,
      kpi_id : this.props.id,
    }
    if (valid) {
      if (this.props.id == 0) {
        datasave.service(window.SAVE_KPI_DETAILS, 'POST',data)
        .then(async response => {
          if(response.status==200) {
            await this.props.updateManageKpi('',response.data);
            OCAlert.alertSuccess(this.state.t('Saved data successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
            await this.setState ({
              nameError : '',
            })
          }
          else if(response.status==201){
            await this.setState ({
              nameError : response.error.name[0],

            })
          }
          else {
            OCAlert.alertWarning(this.state.t('KPI data is not created'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
        });
      }
      else {
        datasave.service(window.UPDATE_KPI_DETAILS, 'POST',data)
        .then(async response => {
          if(response.data=='success') {
           await this.props.updateManageKpi();
           OCAlert.alertSuccess(this.state.t('Updated data successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
           await this.setState ({
            nameError : ''
          })
          }
          else if(response.status==201){
            await this.setState ({
              nameError : response.error.name[0]
            })
          }
          else {
            OCAlert.alertWarning(this.state.t('KPI data is not updated'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
        });
      }
    }else {
      OCAlert.alertWarning(this.state.t('Please fill all required fields'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
  }
  handleCancel() {
    this.props.handleCancel(this.props.action);
  }
  async validateFields () {
    let data = this.props.allvalues;
    let kpidata = this.props.allvalues['kpidata'];
    let targetdata = kpidata['targetdata'];
    let actualdata = kpidata['actualdata'];
    var warning = 0;
    Object.keys(allRequireFileds).map(key => {
      allRequireFileds[key].map((item) => {
        if (Array.isArray(data[key][item])) {
          if (data[key][item].length === 0) {
            warning++
          }
        } else {
          if (data[key][item] === null || data[key][item] === undefined || data[key][item] === '') {
            warning++
          }
        }
      })
    })
    Object.keys(allkpidataRequireFileds).map(key => {
      allkpidataRequireFileds[key].map((item) => {
          if (kpidata[key][item].length === 0 || kpidata[key][item] == 0) {
            warning++
          }
         else {
          if (kpidata[key][item] === null || kpidata[key][item] === undefined || kpidata[key][item] === '') {
            warning++
          }
        }
      })
    })

    if(targetdata['target_type'] == 1){
      if(targetdata['target_value'].length === 0 || targetdata['target_value'] == 0){
        warning++;
      }
    }
    else if (targetdata['target_type'] == 2) {
      if (targetdata['selectedOperation'].length === 0 ) {
        warning++;
      }

    }
    else if (targetdata['target_type'] == 3) {
      if (targetdata['targetquery'] === undefined || targetdata['targetquery'] === '' ) {
        warning++;
      }
    }
    if(targetdata['minimumKPI_option'].length === 0){
      warning++;
    }
    else {
      if(targetdata['minimumKPI_option']['value'] !== 3 && (targetdata['minimumKPI'].length ===0 || targetdata['minimumKPI'] == 0 ) ){
        warning++;
      }
      else if (targetdata['minimumKPI_option']['value'] == 3 && (targetdata['minimumKPI_query'] == null || targetdata['minimumKPI_query'] === '')) {
        warning++;
      }

    }
    if(targetdata['maximumKPI_option'].length === 0){
      warning++;
    }
    else {
      if(targetdata['maximumKPI_option']['value'] !== 3 && (targetdata['maximumKPI'].length ===0 || targetdata['maximumKPI'] == 0 ) ){
        warning++;
      }
      else if (targetdata['maximumKPI_option']['value'] == 3 && (targetdata['maximumKPI_query'] == null || targetdata['maximumKPI_query'] === '')) {
        warning++;
      }
    }

    if (actualdata['actual_type'] == 1) {
      if (actualdata['selectedOperation'].length === 0) {
        warning++
      }
    } else if(actualdata['actual_type'] == 2){
      if (actualdata['actualquery'] === undefined || actualdata['actualquery'] === '' ) {
        warning++;
      }
    }

    let validationSuccess = (warning > 0) ? false : true;
    return validationSuccess;
  }


  render = () => {
    const { t, active_tab, action, id, allvalues, createdata } = this.state;
    const formDisable = ((this.props.action === 'Create' || this.props.action === 'Edit') && this.state.Submitted === true && (this.state.Valid === true && this.state.nameError=='')) ? 'disabled' : '';

      return(
        <div className="p-0 m-0">
          <reactbootstrap.Container>
            <reactbootstrap.Tabs activeKey={active_tab} onSelect={this.handlePageClick.bind(this)} id="controlled-tab-example">
              <reactbootstrap.Tab eventKey={1} title={t("Details")}>
                <Details allvalues={this.props.allvalues} detailsVariables={this.detailsVariables} Submitted={this.state.Submitted} action= {this.props.action} kpiId={this.props.id} num={this.props} nameError={this.state.nameError} Valid={this.state.Valid}></Details>
              </reactbootstrap.Tab>
              <reactbootstrap.Tab  eventKey={2} title={t("Dates")}>
                <Dates allvalues={this.props.allvalues} datesVariables={this.datesVariables} Submitted={this.state.Submitted} action= {this.props.action} kpiId={this.props.id} num={this.props} Valid={this.state.Valid}></Dates>
              </reactbootstrap.Tab>
              <reactbootstrap.Tab  eventKey={3} title={t("Email details")}>
                <Emaildetails allvalues={this.props.allvalues} emaildetailsVariables={this.emaildetailsVariables} Submitted={this.state.Submitted} action= {this.props.action} kpiId={this.props.id} Valid={this.state.Valid}></Emaildetails>
              </reactbootstrap.Tab>
              <reactbootstrap.Tab  eventKey={4} title={t("KPI data")}>
                <KpiData allvalues={this.props.allvalues} kpidataVariables={this.kpidataVariables} Submitted={this.state.Submitted} action= {this.props.action} kpiId={this.props.id} num={this.props} nameError={this.state.nameError} Valid={this.state.Valid}></KpiData>
              </reactbootstrap.Tab>
              <reactbootstrap.Tab  eventKey={7} title={t("Access")}>
                {active_tab == 7 &&
                  <Access allvalues={this.props.allvalues} type={"kpi_access"} accessVariables={this.accessVariables} Submitted={this.state.Submitted} action= {this.props.action} kpiId={this.props.id} Valid={this.state.Valid}></Access>
                }
              </reactbootstrap.Tab>
            </reactbootstrap.Tabs>
            <fieldset disabled={formDisable}>
              <reactbootstrap.FormGroup>
                <div style={{ float: 'right', marginBottom:'50px'}} className="organisation_list mt-4">
                  <a  type="submit" onClick={this.handleCancel} name="cancel" > {t('Cancel')} </a>
                  &nbsp;&nbsp;&nbsp;
                  <reactbootstrap.Button type="submit"
                    name="save"
                    className="btn btn-primary"
                    onClick={this.handleSubmit}
                  >
                    {t('Save')}
                      </reactbootstrap.Button>
                  </div>
                </reactbootstrap.FormGroup>
                </fieldset>
              </reactbootstrap.Container>
        </div>
    );
  }
}
export default translate(Tabstructure)
