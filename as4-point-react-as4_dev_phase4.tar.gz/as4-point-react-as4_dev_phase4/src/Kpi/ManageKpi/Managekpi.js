import React, { useState, useEffect,useRef } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../../language';
import { SearchFilter } from '../../SearchFilter';
import CommonPopUp from '../../GroundPlan/Layers/CommonPopUp';
import Pagination from 'react-bootstrap/Pagination';
import { confirmAlert } from 'react-confirm-alert';
import Can from '../../_components/CanComponent/Can';
import {CanPermissions} from '../../_components/CanComponent/CanPermissions';
import '../images/images.css';

function Managekpi(props) {
  const prevProps = usePrevious(props);
  const t = props.t;
  const [filterTableData, setFilterTableData] = useState([]);
  const [state, setState] = useState({
    details : props.manage_details!=undefined?props.manage_details:[],
    dummy_details: props.manage_details!=undefined?props.manage_details:[],
    page: 5,
    count :0,
    active :1,
    activePage: 1,
    searchTerm: '',
    filterFullList : [],
    kpi_id : props.kpi_id,
  });

  useEffect(() => {
    setState({...state,details:props.manage_details!=undefined?props.manage_details:[],
      dummy_details : props.manage_details!=undefined?props.manage_details:[],
      kpi_id : props.kpi_id,
    })
  }, []);
  useEffect(() => {
    let items = props.manage_details!=undefined?props.manage_details:[];
    let previousSearch = state.searchTerm;
    let res = '';
    let res1 = '';
    var list= items.filter(function (item) {
        if (item.name !== null) {
          res = item.name.toLowerCase().search(
            previousSearch.toLowerCase()) !== -1;
        }
        if(res) {
            return res;
        }
        else if (item.description !==null) {
            res1 =  item.description.toLowerCase().search(
                previousSearch.toLowerCase()) !== -1;
        }
        if(res1) {
            return res1;
        }
    });
    const page_data = state.searchTerm != ''?getPageData( state.active, list):getPageData( state.active, items);
    const count = state.searchTerm != ''? getCountPage(list) : getCountPage(items);
    setState({...state,
      dummy_details : props.manage_details!=undefined?props.manage_details:[],
      details : page_data,
      count :count,
      active : state.active,
      kpi_id : props.kpi_id
    })

  },[props])
  const editKpi= async(id,action) => {
    await setState({...state,
      kpi_id : id,
      active  : state.active
    })
    props.handleActions(id,action);
  }
  const deleteKpi = async(id,action) => {
    confirmAlert({
      title: t('Confirm to submit'),
      message: t('Do you want to delete the KPI?'),
      buttons: [
          {
              label: t('Yes'),
              onClick: () => handleDelete(id,action)
          },
          {
              label: t('No'),
              onClick: () => handlcancel()
          }
      ]
    });
  }

  async function handleDelete (id,action) {
    await setState({...state,
      kpi_id : id,
    })
    datasave.service(window.DELETE_KPI+'/'+id, 'POST')
      .then(response => {
          if (response.status == 200) {
            OCAlert.alertSuccess(t('Delete KPI successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
            props.updateManageKpi(action);
          }
          else{
            OCAlert.alertWarning(this.state.t('KPI data is not deleted'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
      });
  }
  const fetchKpidetails = (id,action) => {
    if (CanPermissions("Access_kpi,V_KPI,E_KPI", "") === true) {
      setState({...state,
        kpi_id : id,
      })
      props.handleActions(id,action);
    } else {
      return
    }
  }
  async function searchFilter(e) {
    var list = [...state.dummy_details];
    let res = '';
    let res1 = '';
    list= list.filter(function (item) {
        if (item.name !== null) {
          res = item.name.toLowerCase().search(
            e.target.value.toLowerCase()) !== -1;
        }
        if(res) {
            return res;
        }
        else if (item.description !==null) {
            res1 =  item.description.toLowerCase().search(
                e.target.value.toLowerCase()) !== -1;
        }
        if(res1) {
            return res1;
        }
    });
    const page_data = getPageData(1, list);
    const count = getCountPage(list);
    await setState({
      ...state,
      details: page_data,
      count  : count,
      active: 1,
      searchTerm: e.target.value,
      filterFullList: list,
    });
  }
  const getCountPage = (items) => {
    const itemLength = items.length;
    return (itemLength > state.page) ? Math.ceil(itemLength / state.page) : 0;
  }
  const getPageData = (id, list = '') => {
    const page = state.page;
    const allItems = state.dummy_details;
    const items = (list !== '') ? list : allItems;
    const page_data = items.slice(page * (id - 1), page * id);
    return page_data;
  }
  const changePage = (e, id) => {
    const list = (state.searchTerm !== '') ? state.filterFullList : '';
    const page_data = getPageData(id, list);
    setState({
      ...state,
      details: page_data,
      active: id,
      activePage : id
    });
  }

  const archiveKpi= async(id,action) => {
    confirmAlert({
      title: t('Confirm to submit'),
      message: t('Do you want to archive the KPI?'),
      buttons: [
          {
              label: t('Yes'),
              onClick: () => handleArchivedandHistorical(id,action,1)
          },
          {
              label: t('No'),
              onClick: () => handlcancel()
          }
      ]
    });
  }
  async function handleArchivedandHistorical (id,action,type) {
    await setState({...state,
      kpi_id : id,
    })
    const data = {
      id : id,
      type :type,
      status : 1,
    }
    datasave.service(window.ARCHIVE_AND_HISTORICAL_KPI, 'POST',data)
      .then(response => {
          if (response.status == 200) {
            props.handleActions(id,action);
            props.updateManageKpi(action);
          }
      });
  }
  function handlcancel () {

  }
  const cloneKpi = async(id,action) => {
    confirmAlert({
      title: t('Confirm to submit'),
      message: t('Do you want to clone the KPI?'),
      buttons: [
          {
              label: t('Yes'),
              onClick: () => handleClone(id,action)
          },
          {
              label: t('No'),
              onClick: () => handlcancel()
          }
      ]
    });

  }

    const kpiReportOverview = (kpiId) =>{
      let url = 'kpi_report_overview/' + kpiId;
      window.open(url, '_blank');
    }

  function handleClone (id,action) {
    datasave.service(window.CLONE_KPI_DATA+'/'+id, 'POST')
    .then(response => {
      if (response.status == 200) {
          setState({...state,kpi_id:response.data})
          props.handleActions(response.data,action);
          props.updateManageKpi(action,response.data);
        }
    });
  }

  async function historicalKpi (id,action) {
    confirmAlert({
      title: t('Confirm to submit'),
      message: t('Do you want to historical the KPI?'),
      buttons: [
          {
              label: t('Yes'),
              onClick: () => handleArchivedandHistorical(id,action,2)
          },
          {
              label: t('No'),
              onClick: () => handlcancel()
          }
      ]
    });
  }
  let pages = [];
  if (state.count > 0) {
      for (let number = 1; number <= state.count; number++) {
          pages.push(
              <Pagination.Item key={number} active={number === state.active} id={number} onClick={(e) => changePage(e, number)}>
                  {number}
              </Pagination.Item>,
          );
      }
  }



  return (
    <reactbootstrap.Container>
      <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C", width: "108%", marginLeft:'-14px' }} placeholder={t("Search...")} autoFocus onChange={(e) => searchFilter(e)} /><br />
      <reactbootstrap.Row style={{ scrollBarWidth: 'thin' }} >
        <reactbootstrap.Table striped bordered hover variant="" className="managelayerTables actionlayertables">
          <thead style={{ backgroundColor: '#EC661C', color: '#fff', position: 'sticky', top: '0', textAlign: 'center' }}>
            <tr style={{ textAlign: 'center' }}>
              <th>{t('Name')}</th>
              <th>{t('Description')}</th>
              <th>{t('Actions')}</th>
            </tr>
            {/* <tr>
              <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder='Search' style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='code' value={searchCode} onChange={(e) => searchFilter(e)} onKeyUp={(e) => onKeyUp(e)} /></th>
              <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder='Search' style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='name' value={searchName} onChange={(e) => searchFilter(e)} onKeyUp={(e) => onKeyUp(e)} /></th>
              <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder='Search' style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='description' value={searchDescription} onChange={(e) => searchFilter(e)} onKeyUp={(e) => onKeyUp(e)} /></th>
              <th></th>
            </tr> */}
          </thead>
          <tbody>
            {state.details != undefined && state.details.map(item => {
              let css = (parseInt(item.id) === parseInt(state.kpi_id))  ? '#feb389' : '#fafafa';
              return <tr style={{backgroundColor: css }}>
                <Can
                  perform = "Access_kpi,V_KPI,E_KPI,D_KPI,Archive_KPI,Clone_KPI,Historical_KPI"
                  yes = {() => (
                    <>
                      <td onClick={(e) => fetchKpidetails(item['id'], 'View')}>{item['name']}</td>
                      <td onClick={(e) => fetchKpidetails(item['id'], 'View')}>{item['description']}</td>
                    </>
                  )}
                />
                <td >
                  <div style={{ display: 'flex', textAlign: 'center', justifyContent:'center' }} >
                    <Can
                      perform = "Access_kpi,E_KPI"
                      yes = {() => (
                        <>
                          {item['kpi_historical'] == 0 &&
                            <i title="Edit" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc"  onClick={(e) => editKpi(item['id'], 'Edit')}/>
                          }
                        </>
                      )}
                    />
                    &nbsp;
                    <Can
                      perform = "Access_kpi,Overview_KPI"
                      yes = {() => (
                        <i title="Overview" style={{ 'cursor': 'pointer' }} class="webform-sprite webform-sprite-smallviewc" onClick={(e) => kpiReportOverview(item['id'])}></i>
                      )}
                    />
                    &nbsp;
                    {/* <Can
                      perform = "Access_kpi,D_KPI"
                      yes = {() => (
                        <i title="Delete" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={(e) => deleteKpi(item['id'], 'Delete')}/>
                      )}
                    /> */}
                    &nbsp;
                    <Can
                      perform = "Access_kpi,Archive_KPI"
                      yes = {() => (
                        <i title="Archive" style={{ 'cursor': 'pointer' }} class="archive archive-archive" onClick={(e) => archiveKpi(item['id'], 'View')}/>
                      )}
                    />
                    &nbsp;
                    <Can
                      perform = "Access_kpi,Clone_KPI"
                      yes = {() => (
                        <i style={{ 'cursor': 'pointer' }} class="clone clone-clone" alt="private memo" title='Clone' onClick={(e) => cloneKpi(item['id'], 'View')}></i>
                      )}
                    />
                    &nbsp;
                    <Can
                      perform = "Access_kpi,Historical_KPI"
                      yes = {() => (
                        <>
                          {item['select_date_type'] == 5 &&
                            <i style={{ 'cursor': 'pointer' }} class="historical historical-hisrorical" alt="private memo" title='Historical' onClick={(e) => historicalKpi(item['id'], 'View')}></i>}
                      </>
                    )}
                  />
                </div>
              </td>
            </tr>
          })}

          </tbody>
        </reactbootstrap.Table>
        <div className="page-nation-sec col-md-12 pl-0 mb-5">
            <Pagination style={{ width: '500px', overflow: 'auto',scrollbarWidth: 'thin' }} size="md">{pages}</Pagination>
        </div>
      </reactbootstrap.Row>
    </reactbootstrap.Container>
  )
}
export default translate(Managekpi);
function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
