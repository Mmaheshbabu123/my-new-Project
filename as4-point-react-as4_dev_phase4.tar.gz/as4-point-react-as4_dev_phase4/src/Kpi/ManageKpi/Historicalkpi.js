import React, { useState, useEffect,useRef } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../../language';
import { SearchFilter } from '../../SearchFilter';
import Pagination from 'react-bootstrap/Pagination';
import { confirmAlert } from 'react-confirm-alert'; // Import
import Can from '../../_components/CanComponent/Can';
import {CanPermissions} from '../../_components/CanComponent/CanPermissions';

function Historicalkpi(props) {
  const prevProps = usePrevious(props);
  const t = props.t;
  const [state, setState] = useState({
    details : props.manage_details!=undefined?props.manage_details:[],
    dummy_details: props.manage_details!=undefined?props.manage_details:[],
    page: 5,
    count :0,
    active :1,
    activePage: 1,
    searchTerm: '',
    filterFullList : [],
    kpi_id : 0,
  });

  useEffect(() => {
    setState({...state,details:props.manage_details!=undefined?props.manage_details:[],
      dummy_details : props.manage_details!=undefined?props.manage_details:[],
    })
  }, []);
  useEffect(() => {
    let items = props.manage_details!=undefined?props.manage_details:[];
    let previousSearch = state.searchTerm;
    let res = '';
    let res1 = '';
    var list= items.filter(function (item) {
        if (item.name !== null) {
          res = item.name.toLowerCase().search(
            previousSearch.toLowerCase()) !== -1;
        }
        if(res) {
            return res;
        }
        else if (item.description !==null) {
            res1 =  item.description.toLowerCase().search(
                previousSearch.toLowerCase()) !== -1;
        }
        if(res1) {
            return res1;
        }
    });
    const page_data = state.searchTerm != ''?getPageData( state.active, list):getPageData( state.active, items);
    const count = state.searchTerm != ''? getCountPage(list) : getCountPage(items);
    setState({...state,
      dummy_details : props.manage_details!=undefined?props.manage_details:[],
      details : page_data,
      count :count,
      active : state.active,
      kpi_id : props.kpi_id
    })

  },[props])

  const fetchKpidetails = (id,action) => {
    setState({...state,
      kpi_id : id,
    })
    props.handleActions(id,action);
  }
  async function searchFilter(e) {
    var list = [...state.dummy_details];
    let res = '';
    let res1 = '';
    list= list.filter(function (item) {
        if (item.name !== null) {
          res = item.name.toLowerCase().search(
            e.target.value.toLowerCase()) !== -1;
        }
        if(res) {
            return res;
        }
        else if (item.description !==null) {
            res1 =  item.description.toLowerCase().search(
                e.target.value.toLowerCase()) !== -1;
        }
        if(res1) {
            return res1;
        }
    });

    const page_data = getPageData(1, list);
    const count = getCountPage(list);
    await setState({
      ...state,
      details: page_data,
      count  : count,
      active: 1,
      searchTerm: e.target.value,
      filterFullList: list,
    });
  }
  const getCountPage = (items) => {
    const itemLength = items.length;
    return (itemLength > state.page) ? Math.ceil(itemLength / state.page) : 0;
  }
  const getPageData = (id, list = '') => {
    const page = state.page;
    const allItems = state.dummy_details;
    const items = (list !== '') ? list : allItems;
    const page_data = items.slice(page * (id - 1), page * id);
    return page_data;
  }
  const changePage = (e, id) => {
    const list = (state.searchTerm !== '') ? state.filterFullList : '';
    const page_data = getPageData(id, list);
    setState({
      ...state,
      details: page_data,
      active: id,
      activePage : id
    });
  }

  const deleteKpi = async(id,action) => {
    confirmAlert({
      title: t('Confirm to submit'),
      message: t('Do you want to delete the KPI?'),
      buttons: [
          {
              label: t('Yes'),
              onClick: () => handleDelete(id,action)
          },
          {
              label: t('No'),
              onClick: () => handlcancel()
          }
      ]
    });
  }

  async function handleDelete (id,action) {
    await setState({...state,
      kpi_id : id,
    })
    datasave.service(window.DELETE_KPI+'/'+id, 'POST')
      .then(response => {
          if (response.status == 200) {
            OCAlert.alertSuccess(t('Delete KPI successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
            props.updateManageKpi(action);
          }
          else{
            OCAlert.alertWarning(this.state.t('KPI data is not deleted'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
      });
  }
  const archiveKpi= async(id,action) => {
    confirmAlert({
      title: t('Confirm to submit'),
      message: t('Do you want to activate the KPI?'),
      buttons: [
          {
              label: t('Yes'),
              onClick: () => handleArchivedandHistorical(id,action,1)
          },
          {
              label: t('No'),
              onClick: () => handlcancel()
          }
      ]
    });
  }
  async function handleArchivedandHistorical (id,action,type) {
    await setState({...state,
      kpi_id : id,
    })
    const data = {
      id : id,
      type :type,
      status : 0,
    }
    datasave.service(window.ARCHIVE_AND_HISTORICAL_KPI, 'POST',data)
      .then(response => {
          if (response.status == 200) {
            props.handleActions(id,action);
            props.updateManageKpi(action);
          }
      });
  }

  function handlcancel () {

  }

  let pages = [];
  if (state.count > 0) {
      for (let number = 1; number <= state.count; number++) {
          pages.push(
              <Pagination.Item key={number} active={number === state.active} id={number} onClick={(e) => changePage(e, number)}>
                  {number}
              </Pagination.Item>,
          );
      }
  }

  return (
    <reactbootstrap.Container>
      <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C", width: "100%", marginLeft: '-14px', marginTop: '10px' }} placeholder={t("Search")} autoFocus onChange={(e) => searchFilter(e)} /><br />
      <reactbootstrap.Row style={{ scrollBarWidth: 'thin' }} >
        <reactbootstrap.Table striped bordered hover variant="" className="managelayerTables archiveTables">
          <thead style={{ backgroundColor: '#EC661C', color: '#fff', position: 'sticky', top: '0', textAlign: 'center' }}>
            <tr style={{ textAlign: 'center' }}>
              <th>{t('Name')}</th>
              <th>{t('Description')}</th>
              <th>{t('Actions')}</th>
            </tr>
          </thead>
          <tbody>
            <Can
               perform = "Access_kpi,V_KPI,D_KPI"
               yes = {() => (
                 <>
                    {state.details!=undefined&&state.details.map(item => {
                      let css = (parseInt(item.id) === parseInt(state.kpi_id))  ? '#feb389' : '#fafafa';
                      return <tr style={{backgroundColor: css }}>
                        <td onClick={(e) => fetchKpidetails(item['id'], 'View')}>{item['name']}</td>
                        <td onClick={(e) => fetchKpidetails(item['id'], 'View')}>{item['description']}</td>
                        <Can
                           perform = "Access_kpi,D_KPI"
                           yes = {() => (
                             <>
                                <td >
                                  <div style={{ display: 'flex', textAlign: 'center', justifyContent: 'center' }} >
                                    <i title="Delete" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={(e) => deleteKpi(item['id'], 'Delete')}/> &nbsp;
                                    {/* <i title="Add to activate" style={{ 'cursor': 'pointer' }} class="archive archive-archive" onClick={(e) => archiveKpi(item['id'], 'View')}/> */}

                                  </div>
                                </td>
                            </>
                          )}
                        />

                      </tr>
                    })}
                  </>
              )}
            />
          </tbody>
        </reactbootstrap.Table>
        <div className="page-nation-sec col-md-12 pl-0">
            <Pagination style={{ width: '500px', overflow: 'auto',scrollbarWidth: 'thin' }} size="md">{pages}</Pagination>
        </div>
      </reactbootstrap.Row>
    </reactbootstrap.Container>
  )
}
export default translate(Historicalkpi);
function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
