import React, { Component } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import Managekpi from './Managekpi';
import Archivekpi from './Archivekpi';
import Historicalkpi from './Historicalkpi';
import TabStructure from './TabStructure';
import { datasave } from '../../_services/db_services';
import Can from '../../_components/CanComponent/Can';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
import {CanPermissions} from '../../_components/CanComponent/CanPermissions';

var duplicatedata = [];
var duplicatecanceldata =[];
var duplicatecreatedata = [];
class KpiIndex extends Component {
    constructor(props) {
        super(props)
        this.state = {
          active_tab : 1,
          dummy :[],
          t:props.t,
          num : 0,
          manage_details : [],
          archive_details :[],
          historical_details : [],
          action : '',
          Submitted : false,
          id : 0,
          MFW :[],
          kpi_id : 0,
          canceldata : [],
          cancelcreatedata : [],
          operations:[{
            value : 1,
            label : 'Sum',
          },
          {
            value : 2,
            label : 'Average',
          },
          {
            value : 3,
            label : 'Median',
          },
          {
            value : 4,
            label : 'Min',
          },
          {
            value : 5,
            label : 'Max',
          },
          {
            value : 6,
            label : 'Count',
          },
          {
            value : 7,
            label : 'Standard deviation',
          },
          {
            value : 8,
            label : 'Product',
          }
        ],
          kpidatavalues : [{
            value : 1,
            label : 'Percentage',
          },
          {
            value : 2,
            label : 'Value',
          },
          {
            value : 3,
            label : 'Query',
          }],
          allvalues : {
            details : {
              name            : '',
              description        : '',
              selectedManuals    : [],
              selectedFolders    : [],
              selectedWebform    : [],
              manualOptions      : [],
              folderOptions      : [],
              documentOptions    : [],
              webelementOptions  : [],
              namError : ''
            },
            dates : {
	      executeDateOptionService: 0,
	      selected_date_option: {label: 'Start date', value: "99991||"+ window.START_DATE},
              date_options: [],
              startDate   : undefined,
              endDate     : undefined,
              select_year : undefined,
              frequencyValue    : 1,
              frequencyType     : 'days',
              select_date_type : [],
              week_type   : false,
              select_value :0,
              select_bundle_type : [],
              select_graph_type : [],
              select_dates : [{
                value : 2,
                label : 'Week',
              },
              {
                value : 1,
                label : 'Month',
              },
              {
                value : 3,
                label : 'Quarter',
              },
              {
                value : 4,
                label : 'Year',
              },
              {
                value : 5,
                label : 'Start and end date',
              }],
              bundles     : [{
                label : props.t('Days'),
                value  :1
              },
              {
                label : props.t('Weeks'),
                value  :2
              },
              {
                label : props.t('Month'),
                value  :3
              },
              {
                label : props.t('Quarter'),
                value  :4
              }
              ],
              graphs     : [{
                label : props.t('Line chart'),
                value  :1
              },
              {
                label : props.t('Bar chart'),
                value  :2
              }
              ]
            },
            emailtemplate : {
              templates: [],
              triggers: [],
              // selectedTemplate: [],
              // receivers: [],
              // receiverIds: [],
              uniqueId: null,
            },
            kpidata:{
              webelementOptions : [],
              targetdata:{
                kpiValueOptions : [{
                  value : 1,
                  label : 'Percentage',
                },
                {
                  value : 2,
                  label : 'Value',
                },
                {
                  value : 3,
                  label : 'Query',
                }],
                date_type_options : [{
                  value : 1,
                  label : 'Same period last year',
                },
                {
                  value : 2,
                  label : 'Last period',
                }],
                target_type        :0,
                target_value       :0,
                selectedManuals    :[],
                selectedFolders    : [],
                selectedWebform    : [],
                selectedWebelement :[],
                manualOptions      : [],
                folderOptions      : [],
                documentOptions    : [],
                webelementOptions  : [],
                targetquery        : '',
                maximumKPI         : 0,
                minimumKPI         : 0,
                maximumKPI_option  : [],
                minimumKPI_option  : [],
                cumulative         : 0,
                individual_targets : 0,
                date_type          : [],
                minimumKPI_query   : '',
                maximumKPI_query   : '',
                select_sublist : [],
                // text_field_value : '',
                // textbox_value : '',
                date : undefined,
                sublist_type : 0,
                operater : [],
                selectedOperation : [],
              },
            actualdata:{
              actual_type        :0,
              selectedManuals    :[],
              selectedFolders    : [],
              selectedWebform    : [],
              selectedWebelement :[],
              selectedOperation  :[],
              manualOptions      : [],
              folderOptions      : [],
              documentOptions    : [],
              webelementOptions  : [],
              actualquery     : '',
              individual_data : 0,
              cumulative      : 0,
              select_sublist : [],
              // text_field_value : '',
              // textbox_value : '',
              date : undefined,
              sublist_type :  0,
              operater : [],
            },

            },
            access : {
              accessItems: [],
              accessIds: [],
            },
          },
          createdata : {
            details : {
              name            : '',
              description        : '',
              selectedManuals    : [],
              selectedFolders    : [],
              selectedWebform    : [],
              selectedWebelement :[],
              manualOptions      : [],
              folderOptions      : [],
              documentOptions    : [],
              namError : ''
            },
            dates : {
	     executeDateOptionService: 2,
	      selected_date_option: {label: 'Start date', value: "99991||"+ window.START_DATE},
	      date_options: [],
              startDate   : undefined,
              endDate     : undefined,
              select_year : undefined,
              frequencyValue    : 1,
              frequencyType     : 'days',
              select_date_type : [],
              week_type   : false,
              select_value : 0,
              select_bundle_type : [],
              select_graph_type  : [],
              select_dates : [{
                value : 2,
                label : 'Week',
              },
              {
                value : 1,
                label : 'Month',
              },
              {
                value : 3,
                label : 'Quarter',
              },
              {
                value : 4,
                label : 'Year',
              },
              {
                value : 5,
                label : 'Start and end date',
              }],
              bundles     : [{
                label : props.t('Days'),
                value  :1
              },
              {
                label : props.t('Weeks'),
                value  :2
              },
              {
                label : props.t('Month'),
                value  :3
              },
              {
                label : props.t('Quarter'),
                value  :4
              }
              ],
              graphs     : [{
                label : props.t('Line chart'),
                value  :1
              },
              {
                label : props.t('Bar chart'),
                value  :2
              }
              ]

            },
            emailtemplate : {
              templates: [],
              triggers: [],
              // selectedTemplate: [],
              // receivers: [],
              // receiverIds: [],
              uniqueId: null,
            },
            kpidata:{
              webelementOptions : [],
              targetdata:{
                kpiValueOptions : [{
                  value : 1,
                  label : 'Percentage',
                },
                {
                  value : 2,
                  label : 'Value',
                },{
                  value : 3,
                  label : 'Query',
                }],
                date_type_options : [{
                  value : 1,
                  label : 'Same period last year',
                },
                {
                  value : 2,
                  label : 'Last period',
                }],
                target_type        :0,
                target_value       :0,
                selectedManuals    :[],
                selectedFolders    : [],
                selectedWebform    : [],
                selectedWebelement :[],
                manualOptions      : [],
                folderOptions      : [],
                documentOptions    : [],
                webelementOptions  : [],
                targetquery     : '',
                maximumKPI         : 0,
                minimumKPI         : 0,
                maximumKPI_option  : [],
                minimumKPI_option  : [],
                cumulative         :0,
                individual_targets : 0,
                date_type          :[],
                minimumKPI_query   : '',
                maximumKPI_query   : '',
                select_sublist : [],
                text_field_value : '',
                textbox_value : '',
                date : undefined,
                operater : [],
                sublist_type : 0,
                selectedOperation :[],

              },
            actualdata:{
              actual_type        :0,
              selectedManuals    :[],
              selectedFolders    : [],
              selectedWebform    : [],
              selectedWebelement :[],
              selectedOperation  :[],
              manualOptions      : [],
              folderOptions      : [],
              documentOptions    : [],
              webelementOptions  : [],
              actualquery     : '',
              individual_data : 0,
              cumulative      : 0,
              select_sublist : [],
              // text_field_value : '',
              // textbox_value : '',
              date : undefined,
              sublist_type :0,
              operater : undefined,
              webelement_type : undefined,
            },
            },
            access : {
              accessItems: [],
              accessIds: [],
            },
          },
        }
        this.createKpi = this.createKpi.bind(this);
    }

    async createKpi () {
        let dummydata  = this.state.createdata;
        dummydata['details']['manualOptions'] = this.state.MFW.manuals!=undefined?this.state.MFW.manuals:[];
        dummydata['details']['folderOptions'] = this.state.MFW.folders!=undefined?this.state.MFW.folders:[];
        dummydata['details']['documentOptions'] = this.state.MFW.webforms!=undefined?this.state.MFW.webforms:[];
       // dummydata['dates']['date_options'] = this.state.MFW.webforms!=undefined ? this.state.MFW.webforms:[];
        duplicatedata = JSON.parse(JSON.stringify(this.state.createdata));
      await this.setState ({
        allvalues : duplicatedata,
        Submitted  :false,
        action : 'Create',
        id     : 0,
        // allvalues : this.state.createdata,
        num : Math.floor(Math.random() * 10000) + 1,
      })
      // await this.assginValues([])
    }
    async componentDidMount() {
      await this.fetchMFW();
      await this.fetchManageKpiDetails();
      await this.fetchWebformDate();
    }

    async fetchWebformDate(){
    const { createdata } = this.state;
    datasave.service(`${window.GET_WEBFORM_DATES}/0`, 'GET')
      .then(async response => {
      if(response['status'] == 200){
       let tempCreateData = Object.assign({}, createdata);
       tempCreateData['dates']['date_options'] = response['data']['date_list'] !== undefined ? response['data']['date_list'] : [];
       this.setState({ createdata: tempCreateData });
      }
      });
    }


    async fetchMFW () {
      datasave.service(window.FETCHMFW, 'GET')
      .then(async response => {
        await this.setState({
          MFW : response.data,
        })
      });
    }

    async fetchManageKpiDetails (action = '',kpi_id=0) {
      datasave.service(window.FETCH_MANAGE_DETAILS, 'GET')
      .then(async response => {
        await this.setState({
          manage_details : response.filter((menu) =>menu.kpi_archive==0&&menu.kpi_historical==0),
          archive_details : response.filter((menu) =>menu.kpi_archive==1),
          historical_details : response.filter((menu)=>menu.kpi_historical ==1),
          kpi_id : kpi_id,
        })
        if(action == 'Delete') {
          await this.fetchKpiDetails(response[0]['id']);
        }
      });
    }

    async handleActions (id,action) {
      await this.setState({
        action : action,
        id : id,
        kpi_id : id,
        num : Math.floor(Math.random() * 10000) + 1,
      })
      await this.fetchKpiDetails (id);
    }

    async handleCancel(action){
      duplicatecanceldata = JSON.parse(JSON.stringify(this.state.canceldata));
      duplicatecreatedata = JSON.parse(JSON.stringify(this.state.createdata));
      if(action=='Edit') {
        await this.setState({
          canceldata :duplicatecanceldata,
          allvalues : this.state.canceldata
        })
      }else {
        await this.setState({
          cancelcreatedata : duplicatecreatedata,
          allvalues : duplicatecreatedata
        })
      }
    }

   async fetchKpiDetails (id) {
      const data = {
        kpi_id : id,

      }
      datasave.service(window.FETCH_KPI_DETAILS, 'POST',data)
      .then(async response => {
        await this.assginValues(response.data)
      });
    }
    async assginValues (filterdata) {
      let data =this.state.allvalues;
      if(filterdata.length!==0) {
        var selectedmanual = this.state.MFW.manuals.filter((menu) =>menu.value==filterdata[0]['details']['manual_id']);
        var selectedfolder = this.state.MFW.folders.filter((menu) =>menu.value==filterdata[0]['details']['folder_id']);
        var selectedWebform = this.state.MFW.webforms.filter((menu) =>menu.value==filterdata[0]['details']['webform_id']);
        var selectdatetype = this.state.allvalues['dates']['select_dates'].filter((menu) =>menu.value==filterdata[0]['dates']['select_date_type']);
        var bundletype = this.state.allvalues.dates.bundles.filter((menu) =>menu.value==filterdata[0]['dates']['bundle_type']);
        var graphtype = this.state.allvalues.dates.graphs.filter((menu) =>menu.value==filterdata[0]['dates']['graph_type']);
        let date_options = filterdata[0]['dates']['date_options'];
	let selected_date_options = date_options.filter(keyObj=>{
	 return keyObj['value'] === filterdata[0]['dates']['selected_date_option'] ? 1 : 0});
	selected_date_options = selected_date_options.length > 0 ? selected_date_options[0] : {};
        var actual_manual_id = this.state.MFW.manuals.filter((menu) =>menu.value==filterdata[0]['actualdata']['selectedManuals']);
        var actual_folder_id = this.state.MFW.folders.filter((menu) =>menu.value==filterdata[0]['actualdata']['selectedFolders']);
        var actual_webform_id = this.state.MFW.webforms.filter((menu) =>menu.value==filterdata[0]['actualdata']['selectedWebform']);
        var actual_webformelements = filterdata.length !== 0 ? filterdata[0]['actualdata']['webelementOptions'] :[];
        var actual_web_element = (actual_webformelements !== undefined && actual_webformelements !== null )?actual_webformelements.filter((menu) =>menu.value==filterdata[0]['actualdata']['selectedWebelement']) :[];
        var actual_operation   = this.state.operations.filter((menu)=>menu.value == filterdata[0]['actualdata']['selectedOperation']);
        var actual_folders = filterdata[0]['actualdata']['selectedManuals'] !== null ? this.state.MFW.folders.filter((menu) =>menu.manual_id == filterdata[0]['actualdata']['selectedManuals']): [];
        var actual_webforms = filterdata[0]['actualdata']['selectedFolders'] !== null ? this.state.MFW.webforms.filter((menu) =>menu.parent_id== filterdata[0]['actualdata']['selectedFolders']) : [];
        var target_operation   = this.state.operations.filter((menu)=>menu.value == filterdata[0]['targetdata']['selectedOperation']);

        var target_folders = filterdata[0]['targetdata']['selectedManuals'] !== null ? this.state.MFW.folders.filter((menu) =>menu.manual_id == filterdata[0]['targetdata']['selectedManuals']): [];
        var target_webforms = filterdata[0]['targetdata']['selectedFolders'] !== null ? this.state.MFW.webforms.filter((menu) =>menu.parent_id== filterdata[0]['targetdata']['selectedFolders']) : [];
        var target_manual_id = this.state.MFW.manuals.filter((menu) =>menu.value==filterdata[0]['targetdata']['selectedManuals']);
        var target_folder_id = this.state.MFW.folders.filter((menu) =>menu.value==filterdata[0]['targetdata']['selectedFolders']);
        var target_webform_id = this.state.MFW.webforms.filter((menu) =>menu.value==filterdata[0]['targetdata']['selectedWebform']);
        var target_webformelements = filterdata.length !== 0 ? filterdata[0]['targetdata']['webelementOptions'] :[];
        var target_web_element = (target_webformelements !== undefined && target_webformelements !== null) ? target_webformelements.filter((menu) =>menu.value==filterdata[0]['targetdata']['selectedWebelement']) :[];
        var target_min_option  = this.state.kpidatavalues.filter((menu)=>menu.value == filterdata[0]['targetdata']['min_option']);
        var target_max_option  = this.state.kpidatavalues.filter((menu)=>menu.value == filterdata[0]['targetdata']['max_option']);
        var target_date_type   = this.state.allvalues['kpidata']['targetdata']['date_type_options'].filter((menu)=>menu.value == filterdata[0]['targetdata']['date_type']);
        var actual_operater = actual_web_element.length!=0?window.KPI_TEXT_OPERATOR_ACTIONS.includes(actual_web_element[0].type.toString())?window.KPI_TEXT_OPERATOR.filter((menu) =>menu.value==filterdata[0]['actualdata']['operator']):window.KPI_TRIGGER_OPERATOR.filter((menu) =>menu.value==filterdata[0]['actualdata']['operator']):[];
        var target_operater = target_web_element.length!=0?window.KPI_TEXT_OPERATOR_ACTIONS.includes(target_web_element[0].type.toString())?window.KPI_TEXT_OPERATOR.filter((menu) =>menu.value==filterdata[0]['targetdata']['operator']):window.KPI_TRIGGER_OPERATOR.filter((menu) =>menu.value==filterdata[0]['targetdata']['operator']):[];
      data['kpidata']['targetdata']['select_sublist']= filterdata[0]['targetdata']['webelement_type']!=window.DATEFIELD?filterdata[0]['targetdata']['value']:'';
      data['kpidata']['targetdata']['webelement_type']=filterdata[0]['targetdata']['webelement_type'];
      data['kpidata']['targetdata']['date']=filterdata[0]['targetdata']['webelement_type']==window.DATEFIELD?filterdata[0]['targetdata']['value']:undefined;
      data['details']['name'] = filterdata.length!==0?filterdata[0]['details']['name']:'';
      data['details']['description'] = filterdata.length!==0?filterdata[0]['details']['description']:'';
      data['details']['selectedManuals'] = filterdata.length!==0?selectedmanual[0]:[];
      data['details']['selectedFolders'] = filterdata.length!==0?selectedfolder[0]:[];
      data['details']['selectedWebform'] = filterdata.length!==0?selectedWebform[0]:[];
      data['details']['manualOptions'] = this.state.MFW.manuals!=undefined?this.state.MFW.manuals:[];
      data['details']['folderOptions'] = this.state.MFW.folders!=undefined?this.state.MFW.folders:[];
      data['details']['documentOptions'] = this.state.MFW.webforms!=undefined?this.state.MFW.webforms:[];
      data['dates']['startDate']      = filterdata.length!==0 ? filterdata[0]['dates']['start_date_kpi']:undefined;
      data['dates']['endDate']        = filterdata.length!==0 ? filterdata[0]['dates']['end_date_kpi']:undefined;
      data['dates']['select_year']    = filterdata.length!==0 ? filterdata[0]['dates']['year_type']:undefined;
      data['dates']['frequencyValue'] = filterdata.length!==0 ? filterdata[0]['dates']['frequency_value']:undefined;
      data['dates']['select_date_type'] = filterdata.length!==0 ? selectdatetype[0]:undefined;
      data['dates']['select_value'] = filterdata.length!==0 ? selectdatetype[0]['value']:undefined;
      data['dates']['frequencyType']  = filterdata.length!==0 ? filterdata[0]['dates']['frequency_type']:'days';
      data['dates']['select_graph_type']  = filterdata.length!==0 ? graphtype[0]:[];
      data['dates']['select_bundle_type']  = filterdata.length!==0 ? bundletype[0]:[];
      data['dates']['date_options'] = date_options;
      data['dates']['selected_date_option'] = selected_date_options;
      data['access']['accessItems'] = filterdata.length !== 0 ? filterdata[0]['access']['accessItems'] : [];
      data['access']['accessIds'] = filterdata.length !== 0 ? filterdata[0]['access']['accessIds'] : [];
      data['kpidata']['actualdata']['actual_type']=filterdata.length !== 0 ? filterdata[0]['actualdata']['actual_type']:undefined;
      data['kpidata']['actualdata']['actualquery']=filterdata.length !== 0 ? filterdata[0]['actualdata']['actual_query']:'';
      data['kpidata']['actualdata']['selectedManuals']=filterdata.length !== 0 ? actual_manual_id[0]:[];
      data['kpidata']['actualdata']['selectedFolders']=filterdata.length !== 0 ? actual_folder_id[0]:[];
      data['kpidata']['actualdata']['selectedWebform']=filterdata.length !== 0 ? actual_webform_id[0]:[];
      data['kpidata']['actualdata']['selectedWebelement']=filterdata.length !== 0 ? actual_web_element[0]:[];
      data['kpidata']['actualdata']['webelementOptions']=filterdata.length !== 0 ? actual_webformelements :[];
      data['kpidata']['actualdata']['folderOptions']=filterdata.length !== 0 ? actual_folders :[];
      data['kpidata']['actualdata']['documentOptions']=filterdata.length !== 0 ? actual_webforms :[];
      data['kpidata']['actualdata']['selectedOperation']=filterdata.length !== 0 ? actual_operation[0]:[];
      data['kpidata']['actualdata']['individual_data']=filterdata.length !== 0 ? filterdata[0]['actualdata']['individual_data']:0;
      data['kpidata']['actualdata']['cumulative']=filterdata.length !== 0 ? filterdata[0]['actualdata']['cumulative']:0;
      data['kpidata']['actualdata']['select_sublist']= filterdata[0]['actualdata']['webelement_type']!=window.DATEFIELD?filterdata[0]['actualdata']['value']:'';
      data['kpidata']['actualdata']['webelement_type']=filterdata[0]['actualdata']['webelement_type'];
      data['kpidata']['actualdata']['date']=filterdata[0]['actualdata']['webelement_type']==window.DATEFIELD?filterdata[0]['actualdata']['value']:undefined;
      data['kpidata']['actualdata']['webelement_type']=filterdata.length !== 0 ? filterdata[0]['actualdata']['webelement_type']:0;
      data['kpidata']['targetdata']['target_type']=filterdata.length !== 0 ? filterdata[0]['targetdata']['target_type']:0;
      data['kpidata']['targetdata']['target_value']=filterdata.length !== 0 ? filterdata[0]['targetdata']['target_value']:0;
      data['kpidata']['targetdata']['targetquery']=filterdata.length !== 0 ? filterdata[0]['targetdata']['target_query']:'';
      data['kpidata']['targetdata']['cumulative']=filterdata.length !== 0 ? filterdata[0]['targetdata']['cummulative']:0;
      data['kpidata']['targetdata']['minimumKPI']=filterdata.length !== 0 ? filterdata[0]['targetdata']['min_kpi']:0;
      data['kpidata']['targetdata']['maximumKPI']=filterdata.length !== 0 ? filterdata[0]['targetdata']['max_kpi']:0;
      data['kpidata']['targetdata']['minimumKPI_query']=filterdata.length !== 0 ? filterdata[0]['targetdata']['minimumKPI_query']:"";
      data['kpidata']['targetdata']['maximumKPI_query']=filterdata.length !== 0 ? filterdata[0]['targetdata']['maximumKPI_query']:"";
      data['kpidata']['targetdata']['individual_targets']=filterdata.length !== 0 ? filterdata[0]['targetdata']['individual_targets']:0;
      data['kpidata']['targetdata']['date_type'] =filterdata.length !== 0 ? target_date_type[0]:[];
      data['kpidata']['targetdata']['selectedManuals']=filterdata.length !== 0 ? target_manual_id[0]:[];
      data['kpidata']['targetdata']['selectedFolders']=filterdata.length !== 0 ? target_folder_id[0]:[];
      data['kpidata']['targetdata']['selectedWebform']=filterdata.length !== 0 ? target_webform_id[0]:[];
      data['kpidata']['targetdata']['webelementOptions']=filterdata.length !== 0 ? target_webformelements :[];
      data['kpidata']['targetdata']['selectedWebelement']=filterdata.length !== 0 ? target_web_element[0]:[];
      data['kpidata']['targetdata']['maximumKPI_option']=filterdata.length !== 0 ? target_max_option[0]:[];
      data['kpidata']['targetdata']['minimumKPI_option']=filterdata.length !== 0 ? target_min_option[0]:[];
      data['kpidata']['targetdata']['operater']=filterdata.length !== 0 ? target_operater[0]:0;
      data['kpidata']['actualdata']['operater']=filterdata.length !== 0 ? actual_operater[0]:0;
      data['kpidata']['targetdata']['folderOptions']=filterdata.length !== 0 ? target_folders :[];
      data['kpidata']['targetdata']['documentOptions']=filterdata.length !== 0 ? target_webforms :[];
      data['kpidata']['targetdata']['selectedOperation']=filterdata.length !== 0 ? target_operation[0]:[];
	      data['executeDateOptionService'] = 1;
      duplicatecanceldata = JSON.parse(JSON.stringify(data));
      duplicatecreatedata = JSON.parse(JSON.stringify(this.state.createdata));
      await this.setState({
        allvalues : data,
        Submitted  :false,
        canceldata : duplicatecanceldata,
        cancelcreatedata : duplicatecreatedata,
      })
      }
    }

    updateManageKpi (action,kpi_id=0) {
      this.fetchManageKpiDetails(action,kpi_id);
    }

    async handlePageClick (key) {
      await this.setState({
        active_tab: Number(key),
      });
    }
    render = () => {
        const {t} = this.state;
        return(
          <Can
            perform = "Access_kpi,E_KPI,V_KPI,D_KPI,Archive_KPI,Clone_KPI,Historical_KPI"
            yes = {() => (
              <div className="mt-4 col-md-12 col-lg-12">
                <reactbootstrap.Row>
                  <reactbootstrap.Col className='col-md-4'>
                    <reactbootstrap.Tabs activeKey={this.state.active_tab} onSelect={this.handlePageClick.bind(this)} id="controlled-tab-example">
                      {(CanPermissions("Access_kpi,E_KPI,V_KPI,D_KPI,Archive_KPI,Clone_KPI,Historical_KPI", "") === true) &&
                        <reactbootstrap.Tab eventKey={1} title={t("Activate KPI")}>
                          <Can
                            perform = "Access_kpi,E_KPI"
                            yes = {() => (
                              <>
                                {this.state.MFW.manuals!=undefined &&
                                  <reactbootstrap.Button className="mb-2 mt-2" onClick={this.createKpi}>{t('Add KPI')}</reactbootstrap.Button>
                                }
                              </>
                            )}
                          />
                          <Can
                            perform = "Access_kpi,E_KPI,V_KPI,D_KPI,Archive_KPI,Clone_KPI,Historical_KPI"
                            yes = {() => (
                              <>
                                <Managekpi num = {this.state.num} manage_details = {this.state.manage_details} handleActions={this.handleActions.bind(this)} updateManageKpi={this.updateManageKpi.bind(this)} kpi_id={this.state.kpi_id}></Managekpi>
                              </>
                            )}
                          />
                        </reactbootstrap.Tab>
                      }
                      {(CanPermissions("Access_kpi,V_KPI,D_KPI", "") === true) &&
                        <reactbootstrap.Tab eventKey={2} title={t("Archive KPI")}>
                          <Can
                            perform = "Access_kpi,V_KPI,D_KPI"
                            yes = {() => (
                              <>
                                <Archivekpi num = {this.state.num} manage_details = {this.state.archive_details} handleActions={this.handleActions.bind(this)} updateManageKpi={this.updateManageKpi.bind(this)}></Archivekpi>
                              </>
                            )}
                          />
                        </reactbootstrap.Tab>
                      }
                      <reactbootstrap.Tab eventKey={3} title={t("Historical KPI")}>
                        <Historicalkpi num = {this.state.num} manage_details = {this.state.historical_details} handleActions={this.handleActions.bind(this)} updateManageKpi={this.updateManageKpi.bind(this)}></Historicalkpi>
                      </reactbootstrap.Tab>
                    </reactbootstrap.Tabs>
                  </reactbootstrap.Col>
                  <reactbootstrap.Col className='p-0 m-0'>
                    {this.state.num!==0 &&<TabStructure num = {this.state.num}  action={this.state.action} id={this.state.id} allvalues={this.state.allvalues} updateManageKpi={this.updateManageKpi.bind(this)} Submitted={this.state.Submitted} handleCancel={this.handleCancel.bind(this)}></TabStructure>}
                    </reactbootstrap.Col>
                  </reactbootstrap.Row>
                </div>
              )}
              no={ () =>
                <AccessDeniedPage/>
              }
            />
        );
    }
}
export default translate(KpiIndex)
