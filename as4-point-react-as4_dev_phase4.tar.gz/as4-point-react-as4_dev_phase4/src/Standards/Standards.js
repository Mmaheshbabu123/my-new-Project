import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Pagination from 'react-bootstrap/Pagination'
import FileUpload from '../_components/FileUpload/FileUpload';
import {translate} from '../language';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import { persistor, store } from '../store';
import Can from '../_components/CanComponent/Can'
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import CheckBox  from '../CheckBox';

class Standards extends Component {
  constructor(props) {
    super(props)
    this.state = {
      name: '',
      available_field_screen: true,
      active_standard: true,
      logo: '',
      file_id: '',
      checked: true,
      description: '',
      submitted: false,
      loading: false,
      name_error: '',
      code: '',
      status: 1,
      edit_img: '',
      url: '',
      file_name: 'Choose File',
      standards_docs: [],
      currentPage: 1,
      todosPerPage: 4,
      alert: '',
      malert: '',
      falert: '',
      folder_data: [],
      manual_data: [],
      fcurrentPage: 1,
      mcurrentPage: 1,
      t:props.t,
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCheck = this.handleCheck.bind(this);
    this.handleCancel = this.handleCancel.bind(this);

  }

  handleChange(event) {
    const { name,description,value } = event.target;
    this.setState({ [name]: value,[description]:value, error: '' });

  }
  handleCheck(e) {
    this.setState({ checked: !this.state.checked });
    if (this.state.checked) {
      this.state.status = 0
    } else {
      this.state.status = 1
    }
  }

  handleCancel(event) {
    const { history } = this.props
    if (this.props.id) {
      this.props.updateComponent(1);
    } else {

      this.props.updateComponent(1);
    }
  }

  handleExport() {
    var details = {
      name:this.state.name,
      clone:this.state.clone,
      description:this.state.description,
      olddescription:this.state.clonedescription

    }

   var url = window.GET_EXPORT + this.props.id
   datasave.service(url ,'PUT',details)
   .then(response =>{
    window.open(response)
    window.close()
   })
  }

  updateImageUpload(response) {
    this.setState({
      sucess: window.FILE_UPLOAD_SUCCESS,
      edit_img: '',
      file_id: response.data.file_id[0],
      logo: response.data.filepath
    });

  }
  componentDidMount() {
    if (this.props.id) {
      const id = this.props.id;
      const url = window.SHOW_STANDARD + this.props.id;
      datasave.service(url, 'GET', '')
        .then(response => {
          this.setState({
            link_details: response,
            name: response[0]['name'],
            clone: response[0]['name'],
            description: response[0]['description'],
            clonedescription: response[0]['description'],
            active_standard: response[0]['status'],
            file_name: response[0]['logo'] ? response[0]['logo'] : this.state.file_name,
            clone_filename: response[0]['logo'] ? response[0]['logo'] : this.state.file_name,
            logo: response[0]['logo'],
            clonelogo: response[0]['logo'],
            available_field_screen: response[0]['available_field_screen'],
            clone_available_field: response[0]['available_field_screen'],
            edit_img: response[0]['logo'] ? 'Click here for preview' : '',
            name_error: '',
            error: '',

          })
        });
    }
  }
  componentWillReceiveProps() {
    this.setState({
      name_error: '',
      error: '',
    })
  }
  componentDidUpdate(prevProps, prevState) {
    let tid = this.props.id;
    if (tid !== undefined && prevProps.id !== this.props.id) {
      const id = this.props.id;
      const url = window.SHOW_STANDARD + this.props.id;
      datasave.service(url, 'GET', '')
        .then(response => {

          if (response[0]['description'] !== null) {
            this.setState({
              link_details: response,
              name: response[0]['name'],
              clone: response[0]['name'],
              clonename:response[0]['name'],
              clonedescription: response[0]['description'],
              description: response[0]['description'],
              active_standard: response[0]['status'],
              file_name: response[0]['logo'] ? response[0]['logo'] : this.state.file_name,
              clone_filename: response[0]['logo'] ? response[0]['logo'] : this.state.file_name,
              logo: response[0]['logo'],
              available_field_screen: response[0]['available_field_screen'],
              clone_available_field: response[0]['available_field_screen'],
              edit_img: response[0]['logo'] ? 'Click here for preview' : '',
              name_error: '',
              error: ''
            });
          }
          else {
            this.setState({
              description: '',
              name: response[0]['name'],
              clone: response[0]['name'],
              clonedescription: response[0]['description'],
              file_name: response[0]['logo'] ? response[0]['logo'] : this.state.file_name,
              clone_filename: response[0]['logo'] ? response[0]['logo'] : this.state.file_name,
              logo: response[0]['logo'],
              available_field_screen: response[0]['available_field_screen'],
              clone_available_field: response[0]['available_field_screen'],
              edit_img: response[0]['logo'] ? 'Click here for preview' : '',
              name_error: '',
              error: '',
            });
          }
        });
    }
    if (tid === undefined && prevProps.id !== this.props.id) {

      this.setState({
        name: '',
        description: '',
        name_error: '',
        error: '',
        edit_img: '',
        logo: '',
        file_name: '',
        clone: '',
      });
    }

  }
  handleSubmit(event) {
    event.preventDefault();
    let Userdata = store.getState();
      let person_id = Userdata.UserData.user_details.person_id;
      const {t} = this.state;
    this.setState({ submitted: true });
    const details = {
      id:this.props.id,
      name: this.state.name,
      description: this.state.description,
      logo: this.state.logo,
      logo_id: this.state.file_id,
      status: this.state.active_standard,
      available_field_screen: this.state.available_field_screen,
        clone: this.state.clone,
        modifyname : (this.state.name === this.state.clone) ? false:true,
        modifydescription :(this.state.clonedescription === this.state.description) ? false:true,
        pid : person_id,
        clonedescription:this.state.clonedescription,
        clonename     : this.state.clone
    }

    if (this.validate()) {
      const { name, clone, clonedescription, description, clone_available_field, clone_filename, clonelogo } = this.state
      if (this.props.id) {
        datasave.service(window.CHECK_STANDARD, 'POST', details).then(
          response => {

            if (response == 1) {
              this.setState({
                error: t('Standard name had already been taken!')
              })
            } else {
              { (clone === name && this.state.description === this.state.clonedescription && clone_available_field === this.state.available_field_screen && clone_filename === this.state.file_name && clonelogo === this.state.logo) && this.props.updateComponent(1) }
              const id = this.props.id;

               const durl = window.GET_MASTER_DATA + id;
              datasave.service(durl, 'GET', id).then(
                response => {
                  let standards_docs_r = response;
                  if (standards_docs_r.length === 0) {

                    const id = this.props.id;
                    const url = window.SHOW_STANDARD + id;
                    datasave.service(url, 'PUT', details)
                      .then(response => {
                        if (response.name) {
                          this.setState({
                            name_error: response.name
                          })
                        }
                        else {
                          if (response != 1) {
                            this.props.created(this.state.name)
                            this.props.updateComponent(1);
                          } else {
                            this.setState({
                              error: t('Standard name had already been taken!')
                            })
                          }
                        }
                      })

                  }
                  else {
                    this.setState({ show : true, standards_docs: response, id: id, alert: '' });
                  }
                }
              )

            }
          })

      }
      else {
        datasave.service(window.INSERT_STANDARD, 'POST', details)
          .then(response => {
            if (response.name) {
              this.setState({
                name_error: response.name
              })
            }
            else {
              if (response !== 1) {
                this.props.created(this.state.name)
                this.props.updateComponent(1);
              } else {
                this.setState({
                  error: t('Standard name had already been taken!')
                })
              }
            }
          })
      }
    }
  }
  validate() {
    var name = this.state.name.replace(/\s+/g, ' ').trim();
    let formIsValid = true;
    const {t} = this.state;
    if (!name === true) {
      formIsValid = false;
      this.setState(
        {
          error: t('Standard name field is required!')
        }
      )
    }
    return formIsValid;
  }
  handlePageClick(event) {
    this.setState({
      currentPage: Number(event.target.id)
    });
  }

 /* handleFolderPageClick(event) {
    this.setState({
      fcurrentPage: Number(event.target.id)
    });
  }*/
 /* handleManualPageClick(event) {
    this.setState({
      mcurrentPage: Number(event.target.id)
    });
  }*/

  handlehide = () => {
    this.setState(
      { show: false }
    )
  }
  handlePopCancel() {
    this.setState(
      { show: false }
    )
  }
  handleOk() {
    // this.setState(
    //   { show: false }
    // )
    const {t} = this.state;
    if (this.props.id) {
      this.setState({ submitted: true });
      const { history } = this.props
      let Userdata = store.getState();
      let person_id = Userdata.UserData.user_details.person_id;
      const details = {
        name: this.state.name,
        description: this.state.description,
        logo: this.state.logo,
        logo_id: this.state.file_id,
        status: this.state.active_standard,
        available_field_screen: this.state.available_field_screen,
        clone: this.state.clone,
        modifyname : (this.state.name === this.state.clone) ? false:true,
        modifydescription :(this.state.clonedescription === this.state.description) ? false:true,
        pid : person_id,
        clonedescription:this.state.clonedescription,
        clonename     : this.state.clone
      }
      const id = this.props.id;
      const url = window.SHOW_STANDARD + id;
      datasave.service(url, 'PUT', details)
        .then(response => {
          if (response.name) {
            this.setState({
              name_error: response.name
            })
          }
          else {
            if (response !== 1) {
              this.props.created(this.state.name)
              this.props.updateComponent(1);
            } else {
              this.setState({
                error: t('Standard name had already been taken!')
              })
            }
          }
        })
    }

  }
  render() {

    const { clone,t, error, id, standards_docs, alert, todosPerPage, currentPage, folder_data, manual_data, mcurrentPage, fcurrentPage, malert, falert, name, description, submitted, loading, active_standard, available_field_screen, name_error, clonedescription } = this.state;
    const indexOfLastTodo = currentPage * todosPerPage;
    const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
 /*   //folder
    const indexOfLastFolder = fcurrentPage * todosPerPage;
    const indexOfFirstFolder = indexOfLastFolder - todosPerPage;
    //manual
    const indexOfLastManual = mcurrentPage * todosPerPage;
    const indexOfFirstManual = indexOfLastManual - todosPerPage; */

    const currentTodos = standards_docs.slice(indexOfFirstTodo, indexOfLastTodo);
    const pagerender = currentTodos.map(doc => {
      return <tr>
        <td>{doc.code}</td>
        <td>{doc.name}</td>
        <td>{doc.folder}</td>
        <td>{doc.manual}</td>
      </tr>
    });
   /* const folderdata = folder_data.slice(indexOfFirstFolder, indexOfLastFolder);
    const folders = folderdata.map(folder => {
      return <tr><td>{folder.code}</td>
        <td>{folder.name}</td>
      </tr>
    });
    const manualsdata = manual_data.slice(indexOfFirstManual, indexOfLastManual);
    const manuals = manualsdata.map(manual => {
      return <tr><td>{manual.code}</td>
        <td>{manual.name}</td>
      </tr>
    }); */
    const pageNumbers = [];
    for (let i = 1; i <= Math.ceil(standards_docs.length / todosPerPage); i++) {
      pageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handlePageClick(e, this)} key={i} active={i === currentPage}>
        {i}
      </Pagination.Item>);
    }
   /* const folderPageNumbers = [];
    for (let i = 1; i <= Math.ceil(folder_data.length / todosPerPage); i++) {
      folderPageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handleFolderPageClick(e, this)} key={i} active={i === fcurrentPage}>
        {i}
      </Pagination.Item>);
    }
    const manualPageNumbers = [];
    for (let i = 1; i <= Math.ceil(manual_data.length / todosPerPage); i++) {
      manualPageNumbers.push(<Pagination.Item id={i} onClick={(e) => this.handleManualPageClick(e, this)} key={i} active={i === mcurrentPage}>
        {i}
      </Pagination.Item>);
    }  */

    const popup = (
      <reactbootstrap.Modal
        size="lg"
        show={this.state.show}
        onHide={this.handlehide}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title">
        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
          </reactbootstrap.Modal.Title>
          <reactbootstrap.Modal.Body>
            {/* <reactbootstrap.Tabs id="controlled-tab-example"> */}
              {/* <reactbootstrap.Tab eventKey={1} title="Documents"> */}
                <reactbootstrap.Table responsive striped bordered hover size="sm">
                  <thead>
                    <tr>
                      <td>{t('Document code')}</td>
                      <td>{t('Document name')}</td>
                      <td>{t('Folder name')}</td>
                      <td>{t('Manual name')}</td>
                    </tr>
                  </thead>
                  <tbody>
                    {pagerender}
                  </tbody>
                  {alert && <span className=" alert text-center">{t('No  Record found !')}</span>}
                </reactbootstrap.Table>
                <Pagination style={{width: '530px', overflow: 'auto'}} size="sm">{pageNumbers}</Pagination>
              {/* </reactbootstrap.Tab> */}
              {/* <reactbootstrap.Tab eventKey={2} title="Folder">
                <reactbootstrap.Table striped bordered hover variant="dark">
                  <thead>
                    <tr>
                      <td>{t('Code')}</td>
                      <td>{t('Folder name')}</td>
                    </tr>
                  </thead>
                  <tbody>
                    {folders}
                  </tbody>
                  {falert && <span className=" alert text-center">{t('No  Record found !')}</span>}
                </reactbootstrap.Table>
                <Pagination size="sm">{folderPageNumbers}</Pagination>
              </reactbootstrap.Tab> */}
              {/* <reactbootstrap.Tab eventKey={3} title="Manuals">
                <reactbootstrap.Table striped bordered hover variant="dark">
                  <thead>
                    <tr>
                      <td>{t('Code')}</td>
                      <td>{t('Manual name')}</td>
                    </tr>
                  </thead>
                  <tbody>
                    {manuals}
                  </tbody>
                  {malert && <span className=" alert text-center">{t('No  Record found !')}</span>}
                </reactbootstrap.Table>
                <Pagination size="sm">{manualPageNumbers}</Pagination>
              </reactbootstrap.Tab> */}
            {/* </reactbootstrap.Tabs> */}
            <reactbootstrap.Table responsive striped bordered hover size="sm">
              <thead>
                {clone !== name &&
                  <tr>
                    <th className="taghead" style={{ width: '35%' }}>{t('Previous standard name')}</th>
                    <td>{clone}</td>
                  </tr>
                }
                {clone !== name &&
                  <tr>
                    <th className="taghead">{t('Updated standard name')}</th>
                    <td>{name}</td>
                  </tr>
                }
                {clonedescription !== description &&
                  <tr>
                    <th className="taghead" style={{ width: '35%' }}>{t('Previous description')}</th>
                    <td>{clonedescription}</td>
                  </tr>
                }
                {clonedescription !== description &&
                  <tr>
                    <th className="taghead" style={{ width: '35%' }}>{t('Updated description')}</th>
                    <td>{description}</td>
                  </tr>
                }
              </thead>
              <tbody>
              </tbody>
            </reactbootstrap.Table>
          </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button onClick={() => this.handlePopCancel()}>{t('Cancel')}</reactbootstrap.Button>
          &nbsp;&nbsp; &nbsp;&nbsp;
          <reactbootstrap.Button onClick={() => this.handleOk()}>{t('Edit')}</reactbootstrap.Button>
          <reactbootstrap.Button  onClick={() => this.handleExport()} >{t('Export')}</reactbootstrap.Button>
        </reactbootstrap.Modal.Footer>
      </reactbootstrap.Modal>
    );
    return (
      <Can
        perform = "E_standards"
        yes = {() => (
          <div className='container' >
            <div className='row justify-content-center' >
              <div className='col-md-12' >
                <div className='card' >
                  <div className='card-header' > {t('Create standard')} </div>
                  <div className='card-body' >
                    <reactbootstrap.Container className="p-1">
                      <reactbootstrap.Form onSubmit={this.handleSubmit}>
                        <reactbootstrap.FormGroup>
                          <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
                          <div className=" input-overall-sec ">
                            <reactbootstrap.InputGroup className="">
                            <div className="col-md-4">
                              <reactbootstrap.InputGroup.Prepend>
                                <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Name')} : <span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                              </reactbootstrap.InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 input-padd">
                              <reactbootstrap.FormControl
                                name="name"
                                autoFocus
                                placeholder={t("Standard")}
                                aria-label="Standard"
                                aria-describedby="basic-addon1"
                                value={name}
                                onChange={this.handleChange}
                                className="input_sw "
                              />
                                 <div style={{ color: 'red' }} className="error-block mt-2">{name_error}</div>
                            <div style={{ color: 'red'  }} className="error-block mt-2">{error}</div>
                              </div>
                            </reactbootstrap.InputGroup>


                          </div>
                          </div>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                        <div className=" input-overall-sec ">
                        <reactbootstrap.InputGroup className="">
                        <div className="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Description')} :</reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                          </div>
                          <div class="col-md-8 input-padd">
                          <reactbootstrap.FormControl
                            style={{ height: '200px' }}
                            as="textarea" rows="3"
                            name="description"
                            placeholder={this.props.placeholder}
                            value={description}
                            id="description"
                            onChange={this.handleChange}
                            className="input_sw "
                          />
                          </div>
                          </reactbootstrap.InputGroup>
                          </div>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                          <reactbootstrap.FormGroup md="4" controlId="validationCustom02">
                            <div className="input-group">
                              <FileUpload updateImageUpload={this.updateImageUpload.bind(this)} file_name={this.state.file_name} {...this} />
                            </div>
                            {/* <div className="ml-4 mt-3"> */}
                              {/* <a href={this.state.file_name}>{this.state.edit_img}</a> */}
                              {/* <div className="col-md-12" style={{ color: "green", textAlign: 'center', marginLeft: '2rem' }}>{this.state.sucess}</div> */}

                              <div style={{}} className="row col-md-12 mt-2">
                              <div style={{ visibility: 'hidden' }} className="col-md-4">
                                <h3>{t('Upload')}</h3>
                              </div>
                              <div className="col-md-8">
                                <a href={this.state.file_name}>{this.state.edit_img}</a>
                                <span style={{ color: "green" }}>{this.state.sucess}</span>
                              </div>
                            </div>

                            {/* </div> */}
                          </reactbootstrap.FormGroup>
                          <div className="ml-4 mt-2">
                          <reactbootstrap.Form.Group>
                            <CheckBox
                              name={t("Available in master data")}
                              tick={available_field_screen}
                              style={{ paddingLeft: '0px' }}
                              onCheck={e => this.setState({ available_field_screen: !available_field_screen })}
                              value={'Available in master data'}
                            />
                          </reactbootstrap.Form.Group>
                          </div>
                          <FormGroup>
                          <div style={{float: 'right'}} className="organisation_list mt-3">
                          <a   onClick={this.handleCancel} >{t('Cancel')}</a>

                          &nbsp;&nbsp;&nbsp;
                            <reactbootstrap.Button style={{fontSize: '14px'}} type="submit" className="btn btn-primary" disabled={loading}>{t('Save')}</reactbootstrap.Button>
                          </div>
                          {popup}
                          </FormGroup>
                        </reactbootstrap.FormGroup>
                      </reactbootstrap.Form>
                    </reactbootstrap.Container>
                  </div>
                </div>
              </div>
            </div>
          </div>
          )}
          no = {() =>
            <AccessDeniedPage />
          }
      />
    );
  }
}
export default translate(Standards);
