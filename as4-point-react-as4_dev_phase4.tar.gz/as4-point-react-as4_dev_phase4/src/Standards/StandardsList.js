import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import {translate} from '../language';

class StandardsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            tabs: {
                Active: props.t('Active standards'),
                Archived: props.t('Archived standards')
            },
            standards: {
                Active: [],
                Archived: [],
            },
            gettagsUrl: window.GET_Active_nd_Archive,
            changeTagStatusUrl: window.CHANGE_STATUS,
            t:props.t,
        }
        this.handle_activities = this.handle_activities.bind(this);
    }

    componentDidMount() {

        var url = this.state.gettagsUrl + window.standards_table;
        datasave.service(url, 'GET', '')
            .then(response => {
                this.setState({
                    standards: response,
                })
            });

    }

    handle_activities(id, status, e) {
        var url = this.state.changeTagStatusUrl + id;
        const details = {
            table: window.standards_table,
            status: status ? 1 : 0
        }
        datasave.service(url, 'PUT', details)
            .then(response => {
                if (response === 1) {

                }
            })
            .catch(error => {
                this.setState({
                    errors: error.response.data.errors
                })
            })

    }

    render() {

        const { tabs,t, standards } = this.state
        var tabData = Object.keys(tabs).map(
            function (tab, value) {
                return (
                    <reactbootstrap.Tab eventKey={tab} title={tabs[tab]}>
                        <div className="card-body">
                            <form method='POST'>
                                <reactbootstrap.Table responsive striped bordered hover size="sm">
                                    <thead>
                                        <tr>
                                            <th>{t('Standard')}</th>
                                            <th></th>
                                            <th>{t('Actions')}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {standards[tab].map(
                                            function (standard) {
                                                return (
                                                    <tr>
                                                        <td>{standard.name}</td>
                                                        <td></td>
                                                        <td>
                                                            <Link
                                                                to={`/standards/${standard.id}`}
                                                                key={standard.id}
                                                            >
                                                                {t('Edit')}
                                                            </Link>
                                                            <br></br>
                                                            <a href='#'
                                                                onClick={this.handle_activities.bind(this, standard.id, !standard.status)}
                                                            >
                                                                {standard.status ? t('Make archive') : t('Make active')}
                                                            </a>
                                                        </td>
                                                    </tr>
                                                )
                                            }, this)
                                        }
                                    </tbody>
                                </reactbootstrap.Table>
                            </form>
                        </div>
                    </reactbootstrap.Tab>)
            }, this
        )

        return (
            <div className='container py-4'>
                <div className='row justify-content-center'>
                    <div className='col-md-8'>
                        <div className='card'>
                            <div className='card-header'>{t('All standards')}</div>
                            <div className='card-body'></div>
                            <reactbootstrap.Tabs activeKey={this.state.key} onSelect={this.handleSelect} id="controlled-tab-example">
                                {tabData}
                            </reactbootstrap.Tabs>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

}

export default translate(StandardsList);
