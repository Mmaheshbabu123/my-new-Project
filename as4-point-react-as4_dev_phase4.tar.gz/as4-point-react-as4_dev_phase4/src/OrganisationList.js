import axios from 'axios'
import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from './_services/db_services';
import './Organisations.css';
import Can from './_components/CanComponent/Can';
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import { PagePermissions } from './_components/CanComponent/PagePermissions';
import Pagination from 'react-bootstrap/Pagination';
import Organisationswitching from './Organisationswitching';

import { translate } from './language';
// import mkactive from './images/mkactive.png';
// import mkinactive from './images/mkinactive.png';
// import createsite from './images/create_site.png';
// import clickhere from './images/click-here.png';
// import editicon from './images/manage-edit.png';
import './OrganisationList.css'
import { OCAlert } from '@opuscapita/react-alerts';
import Sitepopup from './Sitepopup';
import SearchInput, { createFilter } from 'react-search-input';
import Organisation from './Organisation';

const KEYS_TO_FILTERS = ['name', 'package_name', 'site'];





class OrganisationList extends Component {
  constructor(props) {
    super(props)
    this.handleEdit = this.handleEdit.bind(this)
    this.handleTabSelect = this.handleTabSelect.bind(this);
    this.handleMakeactive = this.handleMakeactive.bind(this)
    this.handleMakeinactive = this.handleMakeinactive.bind(this)
    this.activeOrganisation = this.activeOrganisation.bind(this)
    this.inactiveOrganisation = this.inactiveOrganisation.bind(this)
    this.handleSubmit = this.handleSubmit.bind(this)
    this.handleChange = this.handleChange.bind(this)
    this.searchUpdated = this.searchUpdated.bind(this);
    this.searchData = this.searchData.bind(this);
    // this.searchDataInactive = this.searchDataInactive.bind(this);


    this.state = {
      search_active: 'active',
      serach_inactive: 'inactive',
      //active_tab: 'Active_organisation',
      active_tab: (this.props.match && this.props.match.params && this.props.match.params.id) ? 3 : 1,
      organisations: [],
      inactiveorganisations: [],
      activeorganisationsdata1: [],
      activeorganisationsdata: [],
      inactiveorganisationsdata: [],
      name: '',
      site: '',
      package_id: '',
      search: '',
      status: '',
      packages_data: [],
      hostname: process.env.REACT_APP_baseURL,
      protocol: window.location.protocol,
      todosPerPage: 5,
      items: [],
      searchTerm: '',
      id: '',
      page: 5,
      active: 1,
      currentPage: 1,
      // count:0,
      filterFullList: [],
      t: props.t,
      searchTerm : '',
      inactivestate : 0,
      activestate: 0,
      show_sitepopup : false,
      show_inactive_popup : false,
      switching_status : false,
      switching_id:0,
    }
  }
  handleTabSelect(key) {
    key = parseInt(key);
    if (key === 1 || key === 2) {
      this.props.history.push('/managemyorganisation/manageorganisation')
    }
    this.setState({
        active_tab: key,
      });
  }
  searchUpdated(term) {
    console.log(term)
    this.setState({
        searchTerm: term,
    })
}

  activeOrganisation(event) {
    this.setState({
      active_tab: 'Active_organisation',
    })

  }
  inactiveOrganisation(event) {
    this.setState({
      active_tab: 'inActive_organisation',
    })
  }
  handleChange(event) {
    event.preventDefault()
    event.stopPropagation()
    const { history } = this.props
    const details = {
      search: 'inactive',
      name: this.state.name,
      package_id: this.state.package_id
    }
    if (details.name === "" && ((details.package_id === "") || (details.package_id === '0'))) {
      window.location.reload()
    }
    else {
      var url = window.ORGANISATIONS_SEARCH;
      datasave.service(url, "GET")
        .then(response => {
          //axios.post(process.env.REACT_APP_serverURL + '/api/organisations/search', details).then(response => {
          this.setState({
            inactiveorganisationsdata: [],
          })
          this.setState({
            inactiveorganisationsdata: response,
          }).then(response => {
            if (response) {
              history.push('/managemyorganisation/manageorganisation')
            }
          })
        })
    }
  }
  handleSubmit(event) {
    event.preventDefault()
    event.stopPropagation()
    this.state.search = 'active'
    const details = {
      search: 'active',
      name: this.state.name,
      site: this.state.site,
      package_id: this.state.package_id
    }
    if (details.name === "" && details.site === "" && ((details.package_id === "") || (details.package_id === '0'))) {
      window.location.reload()
    }
    else {
      var url = window.ORGANISATIONS_SEARCH;
      datasave.service(url, 'POST', details)
        .then(response => {
          // axios.post(process.env.REACT_APP_serverURL + '/api/organisations/search', details).then(response => {
          this.setState({
            activeorganisationsdata: [],

          })
          this.setState({
            activeorganisationsdata: response,

          })
        })
    }
  }

  componentDidMount() {
    var packages = window.packages;
    datasave.service(packages, "GET")
      .then(response => {
        //axios.get(process.env.REACT_APP_serverURL + '/api/packages').then(response => {
        this.setState({
          packages_data: response
        })
      })

    var org = window.ORGANISATIONS;
    datasave.service(org, 'GET')
      .then(response => {
        const pageData = this.getPageData(1, response);
        const count = this.getCountPage(response);
        this.setState({
          activeorganisationsdata: response,
          count: count,
          items: pageData,
          activestate : 1
        })
      })

    var inactive = window.ORGANISATIONS_INACTIVE;
    datasave.service(inactive, 'GET')
      .then(response => {
        const pageData = this.getPageData(1, response);
        const count = this.getCountPage(response);
        this.setState({
          inactiveorganisationsdata: response,
          // count1: count,
          // items1: pageData,
          inactivestate : 2
        })
      })
  }
  // need to check for active and inactive
  getCountPage(items) {
    const itemLength = items.length;
    return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }
  // searchDataInactive(e) {
  //   var list = [...this.state.inactiveorganisationsdata];
  //   let res =''
  //   let res1 =''
  //   let res2 =''
  //   list = list.filter(function (item) {
  //       if (item.name !== null) {
  //         // console.log(item.name)
  //           res = item.name.toLowerCase().search(
  //               e.target.value.toLowerCase()) !== -1;
  //         }
  //         if (res) {
  //           return res
  //         }
  //       else if (item.package_name !== null) {
  //           res1 = item.package_name.toLowerCase().search(
  //               e.target.value.toLowerCase()) !== -1;

  //         }
  //         if (res1) {
  //           return res1
  //         }
  //       else {
  //         // console.log(item.site);
  //         if (item.site !== undefined) {
  //           item.site.filter(function (item){
  //             if (item!== null) {
  //               // console.log(e.target.vale)
  //               res2 = item.toLowerCase().search(
  //                   e.target.value.toLowerCase()) !== -1;
  //               console.log(res2);
  //             }
  //           })

  //         }
  //         if(res2) {
  //           return res2
  //         }
  //       }
  //     });
  //   const page_data = this.getPageData(1, list);
  //   const count = this.getCountPage(list);
  //   this.setState({
  //       items1: page_data,
  //       coun1: count,
  //       active: 1,
  //       searchTerm: e.target.value,
  //       filterFullList: list,
  //   });

  // }
  searchData(e) {
    var list = [...this.state.activeorganisationsdata];
    let res =''
    let res1 =''
    let res2 =''
    list = list.filter(function (item) {
        if (item.name !== null) {
          // console.log(item.name)
            res = item.name.toLowerCase().search(
                e.target.value.toLowerCase()) !== -1;
          }
          if (res) {
            return res
          }
        else if (item.package_name !== null) {
            res1 = item.package_name.toLowerCase().search(
                e.target.value.toLowerCase()) !== -1;

          }
          if (res1) {
            return res1
          }
        else {
          // console.log(item.site);
          if (item.site !== undefined) {
            item.site.filter(function (item){
              if (item!== null) {
                // console.log(e.target.vale)
                res2 = item.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
                console.log(res2);
              }
            })

          }
          if(res2) {
            return res2
          }
        }
      });
    const page_data = this.getPageData(1, list);
    const count = this.getCountPage(list);
    this.setState({
        items: page_data,
        count: count,
        active: 1,
        searchTerm: e.target.value,
        filterFullList: list,
    });

  }
  changePage(e, id = 1) {
    const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
    const page_data = this.getPageData(id, list);
    this.setState({
        items: page_data,
        active: id,
      });
  }
  getPageData(id, list = '') {
      const page = this.state.page;
      const items = (list !== '') ? list : this.state.activeorganisationsdata;
      const page_data = items.slice(page * (id - 1), page * id);
      return page_data;
  }


  handleEdit(id, e) {

  }
  handleMakeactive(id, e) {
    this.setState({
      show_inactive_popup:true,
      site_id : id,
    })
    // const details = {
    //   status: 1,
    //   hostname: this.state.hostname,
    //   protocol: window.location.protocol,
    // }
    // const organisationId = id;
    // var url = window.ORGANISATION_ACTIVITIES + '/' + organisationId;
    // datasave.service(url, 'PUT', details)
    //   //axios.put(process.env.REACT_APP_serverURL + `/api/organisations/manageactivites/${organisationId}`, details)
    //   .then(response => {
    //     if (response === 'Sucess') {
    //       window.location.reload()
    //     }

    //   })
    //   .catch(error => {
    //     this.setState({
    //       error: error.response.errors
    //     })
    //   })

  }

  handleMakeinactive(id, e) {
    this.setState({
      show_sitepopup:true,
      id : id,
    })
    // const details = {
    //   status: 0,
    //   hostname: this.state.hostname,
    //   protocol: window.location.protocol,
    // }
    // const organisationId = id;
    // var url = window.ORGANISATION_ACTIVITIES + '/' + organisationId;
    // datasave.service(url, 'PUT', details)
    //   // axios.put(process.env.REACT_APP_serverURL + `/api/organisations/manageactivites/${organisationId}`, details)
    //   .then(response => {
    //     if (response === 'Sucess') {
    //       window.location.reload()
    //     }

    //   })
    //   .catch(error => {
    //     this.setState({
    //       error: error.response.errors
    //     })
    //   })
  }

  handleCancel(name) {
    if(name==0){
      this.setState({
        show_sitepopup:false
      })
    }
    else {
      console.log("came")
      this.setState({
        show_inactive_popup:false
      })
    }

  }


  handleClick(id, e) {
    const {t} = this.state;
    this.state.activeorganisationsdata.map((lang) => {
      if (lang.id == id) {
        if (lang.no_of_sites == lang.site.length) {
          OCAlert.alertWarning(t('Number of sites are exceeded under this organisation!'), { timeOut: window.TIMEOUTNOTIFICATION1});
          // alert("Number of sites are exceeded under this organisation")
          e.preventDefault()
          this.props.history.push('/manageorganisations')
        }
      }
    })
  }

  handleSwitching (id,e) {
    this.setState({
      switching_status : true,
      switching_id : id,
    })
  }
  changeStatus (status) {
    this.setState({
      switching_status:status
    })
  }



  render() {
    console.log(this.state.active_tab);
    const { t } = this.state;
    const as4_or_site = PagePermissions()
    const { activeorganisationsdata } = this.state
    const { inactiveorganisationsdata } = this.state
    const organisationId = (this.props.match && this.props.match.params && this.props.match.params.id) ? this.props.match.params.id:undefined;
    // const page_data = Object.values(inactiveorganisationsdata).slice(this.state.page - 5, this.state.page);
    // const filtered = page_data.filter(createFilter(this.state.searchTerm, KEYS_TO_FILTERS));
    let active = this.state.active;
    const filtered = this.state.items;
    let pages = [];
    if (this.state.count > 0) {
        for (let number = 1; number <= this.state.count; number++) {
            pages.push(
                <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                    {number}
                </Pagination.Item>,
            );
        }
    }

     if (as4_or_site) {
      return (
        <Can
          perform="E_organisation,R_organisation,active_organisation,inactive_organisation"
          yes={() => (
            <div className="col-md-12 row">
              <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
              <div style={{  }} className='col-md-11' >
                <div className= "" >
                  <div className='col-md-12 mb-5 border-radius' >
                    <div class='organisation_list'>
                      <div className='header'>
                        <reactbootstrap.Tabs activeKey={this.state.active_tab} onSelect={this.handleTabSelect} id="controlled-tab-example">
                          <reactbootstrap.Tab eventKey={1} title={t("Active organisation")}>
                            <div className=" row input-overall-sec">
                              {/* <div className="col-md-4 input-group  input-padd-name  ">
                                <label style={{ alignSelf: 'center' }} className='input-box'>{t('Name')}</label>
                                <input class="form-control search-box-border"
                                  placeholder={t("Search by organisation name")}
                                  value={this.state.name}no_of_sites
                                  onChange={e => this.setState({ name: e.target.value })}
                                />
                              </div>
                              <div className="col-md-3 input-group input-padd">
                                <label style={{ alignSelf: 'center' }} className='input-box'>{t('Sites')}</label>
                                <input class="form-control search-box-border"
                                  placeholder="Search by site"
                                  value={this.state.site}
                                  onChange={e => this.setState({ site: e.target.value })}
                                />
                              </div>
                              <div className="col-md-3 input-group input-padd">
                                <label style={{ alignSelf: 'center' }} className='input-box'>{t('Package')}</label>
                                <select class="form-control search-box-border"
                                  name="package_id"
                                  value={this.state.package_id}
                                  onChange={e => this.setState({ package_id: e.target.value })} >
                                  <option value='0'>{t('Search by package')}</option>
                                  {this.state.packages_data.map(packages =>
                                    <option value={packages.id}>{packages.name}</option>)}
                                </select>
                              </div>
                              <div className="col-md-1  input-padd-search">
                                <button class="btn btn-primary  search-btn" onClick={this.handleSubmit}>{t('Search')}</button>
                                  </div>*/}
                            </div>
                            <input className="form-control search-box-border col-md-4 mb-2" placeholder={t("Search")} onChange={this.searchData} /><br />
                            <div className='card-body'>
                              <form method='POST'>
                                <div style={{}}>
                                  {/* <reactbootstrap.Table responsive> */}
                                  <reactbootstrap.Table className="site-table-main" >
                                    <thead>
                                      <tr>
                                        <th>{t('Name of organisation')}</th>
                                        <th>{t('No.of Sites')}</th>
                                        <th>{t('Sites')}</th>
                                        <th>{t('Package')}</th>
                                        <th>{t('URL')}</th>
                                        <th style={{ textAlign: 'center', }}>{t('Actions')}</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {filtered.map(organisation => (
                                        <tr style={{ borderBottom: '1px solid #dee2e6' }}>
                                          <td> {organisation.name}</td>
                                          <td>{organisation.no_of_sites}</td>
                                          <td>
                                            {(organisation.site == undefined) ? '' : organisation.site.map(site => (
                                              <li style={{listStyleType:'none'}}>{site}</li>
                                            ))}
                                          </td>
                                          <td>{organisation.package_name}</td>
                                          <td>
                                            <a href={this.state.protocol + '//' + organisation.website + '.' + this.state.hostname} target="_blank">
                                              {/* <img style={{height: '20px'}} title='Click here' src={clickhere}></img> */}
                                              <i title={t("Click here")} class="overall-sprite overall-sprite-myclickherec"></i>
                                            </a>
                                          </td>
                                          <td>
                                          <div style={{ display: 'flex', float: 'right', border: '0px' }}>
                                            <Can
                                              perform="E_organisation"
                                              yes={() => (
                                                <Link style={{ float: 'right', padding: '10px' }}
                                                  to={`/managemyorganisation/manageorganisation/${organisation.id}`}
                                                  key={organisation.id}
                                                >
                                                  {/* {t('Edit')} */}
                                                  {/* <img style={{paddingRight: '15px'}} title='Edit' src={editicon}></img> */}
                                                  {/* <i class="overall-sprite overall-sprite-myeditc"></i> */}
                                                  <i title={t("Edit")} class="overall-sprite overall-sprite-myeditc"></i>
                                                </Link>
                                              )}
                                            />
                                            <br></br>
                                            <Can
                                              perform="inactive_organisation"
                                              yes={() => (
                                                <a style={{ float: 'right', padding: '10px' }} href='#'
                                                  onClick={this.handleMakeinactive.bind(this, organisation.id)}
                                                >

                                                  {/* {t('Make inactive')} */}
                                                  {/* <img style={{height: '20px' ,paddingRight: '15px'}} title='Make inactive' src={mkinactive}></img> */}
                                                  <i title={t("Make Inactive")} class="overall-sprite overall-sprite-myinactivec"></i>
                                                </a>
                                              )}
                                            />
                                            <br></br>
                                            {this.state.show_sitepopup &&
                                              <Sitepopup id={this.state.id} show_sitepopup={this.state.show_sitepopup} handleCancel={this.handleCancel.bind(this)} status={0} name={'organisation'}/>
                                            }
                                            <Link style={{ float: 'right', padding: '10px' }} onClick={this.handleClick.bind(this, organisation.id)} to={`/site/${organisation.id}`}
                                              key={organisation.id}>
                                              {/* {t('Create Site')} */}
                                              {/* <img style={{height: '20px'}} title='create site' src={createsite}></img> */}
                                              <i title={t("Create Site")} class="overall-sprite overall-sprite-mycreatesitec"></i>
                                            </Link>
                                            <br></br>

                                              <a style={{ float: 'right', padding: '10px' }}><i style={{ float: 'right', padding: '10px' }} onClick = {this.handleSwitching.bind(this,organisation.id)} title={t("Organisation switching")} class="overall-sprite overall-sprite-mycreatesitec"></i></a>
                                              </div>
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </reactbootstrap.Table>
                                  {this.state.switching_status &&
                                    <Organisationswitching status = {this.state.switching_status} id={this.state.switching_id} changeStatus={this.changeStatus.bind(this)} activedata = {this.state.activeorganisationsdata} sitestatus={1}/>
                                  }
                                </div>
                                <div className="col-md-12">
                                  <Pagination className="page-nation-org" size="md">{pages}</Pagination>
                                </div>
                              </form>
                            </div>
                          </reactbootstrap.Tab>
                          <reactbootstrap.Tab eventKey={2} title={t("Inactive organisation")}>
                            <div className=" row input-overall-sec">
                              {/* <div className="col-md-4 input-group input-padd-name ">
                                <label style={{ alignSelf: 'center' }} className='input-box' >{t('Name')}</label>
                                <input class="form-control search-box-border "
                                  placeholder={t("Search by organisation name")}
                                  value={this.state.name}
                                  onChange={e => this.setState({ name: e.target.value })}
                                />
                              </div>
                              <div className="col-md-3 input-group input-padd ">
                                <label style={{ alignSelf: 'center' }} className='input-box'>{t('Sites')}</label>
                                <input class="form-control search-box-border"
                                  placeholder={t("Search by site")}
                                  value={this.state.site}
                                  onChange={e => this.setState({ name: e.target.value })}
                                />
                              </div>
                              <div className="col-md-3 input-group input-padd ">
                                <label style={{ alignSelf: 'center' }} className='input-box'>{t('Package')}</label>
                                <select class="form-control search-box-border"
                                  name="package_id"
                                  value={this.state.package_id}
                                  onChange={e => this.setState({ package_id: e.target.value })} >
                                  <option value='0'>{t('Search by package')}</option>
                                  {this.state.packages_data.map(packages => <option value={packages.id}>{packages.name}</option>)}
                                </select>
                              </div>
                              <div className="col-md-1 input-padd-search ">
                                <button class="btn btn-primary search-btn" onClick={this.handleChange} >{t('Search')}</button>
                              </div> */}
                            </div>
                            <input className="form-control search-box-border col-md-4 mb-2" placeholder={t("Search")} onChange={this.searchDataInactive} /><br />
                            <div className='card-body'>
                              <div style={{}}>
                                <reactbootstrap.Table className="site-table-main" >
                                  <thead>
                                    <tr>
                                      <th>{t('Name of organisation')}</th>
                                      <th>{t('No.of Sites')}</th>
                                      <th>{t('Sites')}</th>
                                      <th>{t('Package')}</th>
                                      <th>{t('URL')}</th>
                                      <th style={{ textAlign: 'center' }}>{t('Actions')}</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {this.state.inactiveorganisationsdata.map(organisations => (
                                      <tr>
                                        <td> {organisations.name}</td>
                                        <td>{organisations.no_of_sites}</td>
                                        <td>
                                          {(organisations.site == undefined) ? '' : organisations.site.map(site => (
                                            <li style={{listStyleType: 'none'}}>{site}</li>
                                          ))}
                                        </td>
                                        <td>{organisations.package_name}</td>
                                        <td>
                                          <a href={this.state.protocol + '//' + organisations.website + '.' + this.state.hostname} target="_blank">
                                            {/* {t('Click here')} */}
                                            {/* <img style={{height: '20px'}} title='Click here' src={clickhere}></img> */}
                                            <i title={t("Click here")} class="overall-sprite overall-sprite-myclickherec"></i>
                                          </a>
                                        </td>
                                        <td>
                                          <Can
                                            perform="active_organisation"
                                            yes={() => (
                                              <a style={{ float: 'right', padding: '10px' }}
                                                onClick={this.handleMakeactive.bind(this, organisations.id)}
                                              >
                                                {/* {t('Make active')} */}
                                                {/* <img title="Make active" style={{height: '20px'}} src={mkactive}></img> */}
                                                <i title={t("Make Active")} class="overall-sprite overall-sprite-myactivec"></i>
                                              </a>
                                            )}
                                          />

                                          <br></br>
                                          {this.state.show_inactive_popup &&
                                            <Sitepopup id={this.state.site_id} show_sitepopup={this.state.show_inactive_popup} handleCancel={this.handleCancel.bind(this)} status={1} name={'organisation'}/>
                                          }
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </reactbootstrap.Table>
                              </div>
                              <div className="page-nation-sec col-md-12">
                                  <Pagination style={{ width: '500px', overflow: 'auto',scrollbarWidth: 'thin' }} size="md">{pages}</Pagination>
                              </div>
                            </div>
                          </reactbootstrap.Tab>
                          <reactbootstrap.Tab eventKey={3} title={t("Create organisation")}>
                              <Organisation history={this.props.history} id={this.props.match.params.id} handleSelect={this.handleTabSelect} />
                          </reactbootstrap.Tab>
                        </reactbootstrap.Tabs>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          no={() =>
            <AccessDeniedPage />
          }
        />
      );
    }
    else {
      return (
        <AccessDeniedPage />
      )
    }
  }
}

export default translate(OrganisationList)
{/* <i class="overall-sprite overall-sprite-myactivec"></i>
<i class="overall-sprite overall-sprite-myactivecc"></i>
<i class="overall-sprite overall-sprite-myclickherec"></i>
<i class="overall-sprite overall-sprite-myclickherecc"></i>
<i class="overall-sprite overall-sprite-mycreatesitec"></i>
<i class="overall-sprite overall-sprite-mycreatesitecc"></i>
<i class="overall-sprite overall-sprite-myeditc"></i>
<i class="overall-sprite overall-sprite-myeditcc"></i>
<i class="overall-sprite overall-sprite-myinactivec"></i>
<i class="overall-sprite overall-sprite-myinactivecc"></i> */}



{/* <i class="overall-sprite overall-sprite-myactivec"></i>
<i class="overall-sprite overall-sprite-myactivecc"></i>
<i class="overall-sprite overall-sprite-myclickherec"></i>
<i class="overall-sprite overall-sprite-myclickherecc"></i>
<i class="overall-sprite overall-sprite-mycreatesitec"></i>
<i class="overall-sprite overall-sprite-mycreatesitecc"></i>
<i class="overall-sprite overall-sprite-myeditc"></i>
<i class="overall-sprite overall-sprite-myeditcc"></i>
<i class="overall-sprite overall-sprite-myinactivec"></i>
<i class="overall-sprite overall-sprite-myinactivecc"></i> */}
