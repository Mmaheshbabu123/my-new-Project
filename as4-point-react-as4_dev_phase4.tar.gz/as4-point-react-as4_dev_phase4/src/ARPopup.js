import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../src/_services/db_services';
import { connect } from "react-redux";
import { translate } from "../src/language";
import { store } from './store'
import { OCAlert } from '@opuscapita/react-alerts';
import BlockBoxTagBuild from '../src/BlockBox/BlockBoxTagBuild';

class ARPopup extends Component {
    constructor(props) {
      let storage = store.getState()
      let personLinkedOrg = storage.UserData.LinkedOrgUnits;
      let loggedPerson = storage.UserData.user_details.person_id;
      let loggedPersonName = storage.UserData.user_details.user_name;
        super(props)
        this.state = {
            save: props.t('Save'),
            switch_case: true,
            credentials: this.props.credentials,
            use_existing_file_name: props.t('Choose file'),
            savevalue: 'true',
            loading: false,
            error: '',
            description: '',
            batch_code:'',
            status: 1,
            submitted: false,
            showpopup: true,
            sucess: '',
            loggedPerson:loggedPerson,
            loggedPersonName:loggedPersonName,
            t: props.t,
                errors: {},
            blocked_element_data :[],
            OrgUnits:[],
            showRelease:false,
            release_actor_name:'',
            linked_elements :['25548','25540'],


        }
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleRelease = this.handleRelease.bind(this);
        this.cancelPopup = this.cancelPopup.bind(this);
        this.showPopup = this.showPopup.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.Goback = this.Goback.bind(this);
        this.showRelease = this.showRelease.bind(this);
        //alert('no');

    }
    showRelease() {
this.setState({showRelease:!this.state.showRelease})
}

Goback() {
  this.props.history.push(localStorage.getItem('prevLocation'));
}
    handleSubmit(event) {
        const { history } = this.props;
        const {t} = this.state;
        event.preventDefault()
        this.setState({ submitted: true });
        this.setState({
            savevalue: '',
            save: t('Please wait')
        })



        let description = this.state.description.toString().replace(/\s+/g, ' ').trim();
        const details4 = {
            task_id: this.props.task_id,
            person_id: this.props.UserData.user_details.person_id,
            comment: description,
        }
      //this.handleService(window.COMMENT_STORE, "POST", details4);
        if (description) {

            OCAlert.alertSuccess(t('Saved successfully!'), { timeOut: window.TIMEOUTNOTIFICATION });
            // alert('Submited successfully');
            //this.props.history.push(localStorage.getItem('prevLocation'));


        } else {
            this.setState({
                error: t('Comment is required'),
            })

        }



    }
    handleChange(event) {
        const { name, value } = event.target;
        this.state.errors[name] = '';
        this.setState({
            [name]: value,
        })
      }
    componentDidMount() {


    }
    // updateCycles(doc_id, doc_status, person_id) {
    //     const { history } = this.props;
    //     var url = window.GET_CYCLE + '/' + doc_id + '/' + doc_status + '/' + person_id;
    //     datasave.service(url, "POST")
    //         .then(result => {
    //             if (result) {

    //                 //  history.push('/workarea');

    //             }

    //         });
    // }
    handleCancel(event) {
        this.cancelPopup();

    }
    formValidate() {
          let errors = {};
          let formIsValid = true;
          let description = this.state.description.toString().replace(/\s+/g, ' ').trim();
          if (!description) {
            formIsValid = false;
            errors["description"] = "*comment is required";
          }
          if (!this.state.batch_code) {
           formIsValid = false;
           errors["batch_code"] = "*Batch code is required";
         }
         this.setState({
            errors: errors
          });
          return formIsValid;

      }
    cancelPopup() {
        this.setState({ showpopup: false });
        this.props.handleClicktrTask(this.props.result_obj,0,false);
        //   {this.state.switch_case &&
        //   <FourthCycleComponent status_id = {this.props.status_id} doc_id = {this.props.doc_id} status_name = {this.props.status_name}/>}
        // }
    }
    handleRelease(e,type) {

            this.props.handleBlockBoxsubmit(e,this.props.current_zone_step_id);

    }
    showPopup() {
        this.setState({ showpopup: true });
    }

    handleService(url, request_type, data) {
        datasave.service(url, request_type, data)
            .then(response => {
            });
    }

    render() {

      //Object.entries(this.props.blocked_element_data[this.props.step_id]['zones'][this.props.current_zone_step_id]['linked_elements']).forEach(([key, value]) =>{
        let blocked_details =   this.props.linked_elements.map(item => {
              console.log(item)
             return Object.keys(this.props.webform_content_obj).map(function (item1, key) {
               console.log(item1.toString())
               if(item1.toString() === (item).toString()){
                 console.log(item1)
             return(
     <BlockBoxTagBuild
     handleDateChange = {this.props.handleDateChange}
     form_content={this.props.webform_content_obj[item1]}
      datavalue = {this.props.simulation_state[this.props.webform_content_obj[item1]['id']]}
      validateNumberFields = {['']}
      handleChange = {this.props.handleChange}
      PJDG = {this.props.PJDG}
      JDG_personlist = {this.props.JDG_personlist}
      handleSelectChange={this.props.handleSelectChange}
      />
             /*  <tr>
               <td style={{'backgroundColor':item.colour,textAlign:'center'}}>{window.ELEMENT_ACTIONS[item.action_type.toString()]}</td>
               <td style={{'backgroundColor':item.colour,textAlign:'center'}}>{item.label}</td>
               <td style={{'backgroundColor':item.colour,textAlign:'center'}}>{item.resullt_value}</td>
               <td style={{'backgroundColor':item.colour,textAlign:'center'}} >{item.block_box_name}</td>
               </tr>*/
             )}

           },this)
         } )
   console.log(this.props)

        return (
          <div>
            <reactbootstrap.Modal   backdrop="static"
                   keyboard={false} show={this.state.showpopup} onHide={this.cancelPopup}
                   size='lg'
                   dialogClassName="modal-90w"
                   aria-labelledby="example-custom-modal-styling-title"
                   >
                      <reactbootstrap.Modal.Header >
                          <reactbootstrap.Modal.Title style={{ color : '#EC661C'}}><a onClick = {this.showRelease} >{'AR zone Linked web elements'}</a></reactbootstrap.Modal.Title>
                          <a onClick= {this.Goback} href= ''>{'Go back'} </a>
                      </reactbootstrap.Modal.Header>
          <div className='container py-2' >
            <div className='justify-content-center' style={{width: '100%', float: 'left'}} >
              <div className='col-lg-12 col-md-12 float-left px-0'>
                  <reactbootstrap.Container className="p-1">
                      <reactbootstrap.Form >
                          <reactbootstrap.Modal.Body>

                        <reactbootstrap.FormGroup>
                         <reactbootstrap.InputGroup className="">
                          </reactbootstrap.InputGroup>
                        </reactbootstrap.FormGroup>
                        {'zone'}
                        <div className = "col-md-12">
                          {blocked_details}
                          </div>

                        </reactbootstrap.Modal.Body>
                        <reactbootstrap.Modal.Footer style={{ borderTop: '0px' }}>
                            <reactbootstrap.Modal.Footer style={{ borderTop: '0px' }}></reactbootstrap.Modal.Footer>
                          <reactbootstrap.Button    className="btn btn-primary" type="button" color="primary" onClick={e => this.handleRelease(e,1)} icon={{
    name: "arrow-right",
    size: 15,
    color: "white"
  }} >{('Next zone')}</reactbootstrap.Button>


                          {/*(this.props.resolve  === 1) && <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={e => this.handleRelease(e,2)} >{t('Not possible to resolve')}</reactbootstrap.Button>*/}
                                              {(this.props.blocked_element_data[this.props.next_step_id] !== undefined) && <reactbootstrap.Button type="button" onClick={e => this.handleRelease(e,3)} color="primary">{('SEND')}</reactbootstrap.Button>}

                        </reactbootstrap.Modal.Footer>
                    </reactbootstrap.Form>
                </reactbootstrap.Container>
              </div>
            </div>
          </div>
            </reactbootstrap.Modal >
            </div>
        );
    }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(ARPopup));
