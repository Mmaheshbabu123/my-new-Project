import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap'
import { datasave } from '../_services/db_services';
import {translate} from '../language';

class Memo extends Component {
  constructor(props) {
    super(props)
    this.state = {
      save: 'Save',
      credentials: this.props.credentials,
      savevalue: 'true',
      loading: false,
      error: '',
      description: '',
      status: 1,
      submitted: false,
      memo_data: [],
      id: '',
      showpopup: true,
      uid: '',
      t:props.t,
    }
    this.getUid = this.getUid.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.getMemos = this.getMemos.bind(this);
    this.cancelPopup = this.cancelPopup.bind(this);
    this.showPopup = this.showPopup.bind(this);

  }
  componentDidMount() {
    //this.getUid();
    this.getMemos();
  }
  componentDidUpdate(prevProps) {
    if (this.props.credentials !== prevProps.credentials) {
      this.getMemos();
      this.showPopup();
    }
  }
  handleSubmit(event) {
    event.preventDefault()
    const {t} = this.state;
    this.setState({ submitted: true });
    this.setState({
      savevalue: '',
      save: t('Please wait')
    })
    if (this.state.id) {
      const details = {
        description: this.state.description,
        typeId: this.props.credentials.type_id,
        documentId: this.props.credentials.ref_id,
      }
      const url = window.GETMEMOS + this.props.credentials.type_id + '/' + this.props.credentials.ref_id + '/' + this.state.id;
      datasave.service(url, 'PUT', details)
        .then(response => {
          console.log(response);
            if (response.description) {
              this.setState({
                error: response.description
              })
            }
            else {
              this.cancelPopup();
              this.props.memoSaved()
            }
        })
        .catch(error => {
          this.setState({
            errors: error.response.errors
          })
        })
    }
    else {
      const details = {
        description: this.state.description,
        typeId: this.props.credentials.type_id,
        documentId: this.props.credentials.ref_id,
        uid: this.state.uid,
      }
      const url = window.GETMEMOS + this.props.credentials.type_id + '/' + this.props.credentials.ref_id;
      datasave.service(url, 'POST', details)
        .then(response => {
          console.log(response);
            if (response.description) {
              this.setState({
                error: response.description
              })
            }
            else {
              this.cancelPopup();
              this.props.memoSaved()
            }
        })
        .catch(error => {
          this.setState({
            errors: error.response.data.errors
          })
        })
    }
  }
  handleCancel(event) {
    const url = window.GETMEMOS + this.state.id
    datasave.service(url, 'PUT', this.state.id)
      .then(response => {
        if (response.description) {
          this.setState({
            error: response.description
          })
        }
        else {
          this.cancelPopup();
        }
      })
      .catch(error => {
        this.setState({
          errors: error.response.errors
        })
      })
  }
  cancelPopup() {
    this.setState({ showpopup: false });
  }
  showPopup() {
    this.setState({ showpopup: true });
  }
  getUid() {
    var obj = JSON.parse(localStorage.getItem('user'));
    var result = window.atob(obj.authdata);
    result = result.substring(0, result.indexOf(":"));
    const userId = window.GET_UID + '/' + result;
    datasave.service(userId, "GET")
      .then(response => {
        this.setState({
          uid: response,
        })
      })
  }
  getMemos() {
    /*this.getUid();
    var obj = JSON.parse(localStorage.getItem('user'));
    var result = window.atob(obj.authdata);
    result = result.substring(0, result.indexOf(":"));
    const email = result;
    const userId = window.GET_UID + '/' + result;
    datasave.service(userId, "GET")
      .then(response => {
        this.setState({
          uid: response,
        })
      })*/
    const url = window.GETMEMOS + this.props.credentials.type_id + '/' + this.props.credentials.ref_id  ;
    datasave.service(url, "GET")
      .then(response => {
        if (response.length > 0) {
          this.setState({
            memo_data: response,
            description: response['0']['content'],
            id: response['0']['id'],
            uid: response['0']['uid'],
          })
        }
        else {
          this.setState({
            memo_data: '',
            description: '',
            id: '',
            uid: '',
          })
        }
      })
  }
  render() {
    const { description,t, loading, memo_data, error, id } = this.state;
    return (
      <reactbootstrap.Modal show={this.state.showpopup} onHide={this.cancelPopup}>
        <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title>{t('Memo')}</reactbootstrap.Modal.Title>
        </reactbootstrap.Modal.Header>
        <reactbootstrap.Container className="p-5">
          <reactbootstrap.Form onSubmit={this.handleSubmit}>
            <reactbootstrap.Modal.Body>
              <reactbootstrap.FormGroup>
                <reactbootstrap.FormControl
                  style={{ height: '200px' }}
                  as="textarea" rows="3"
                  placeholder={this.props.placeholder}
                  value={this.state.description}
                  onChange={e => this.setState({ description: e.target.value })}
                />
              </reactbootstrap.FormGroup>
            </reactbootstrap.Modal.Body>
            <div style={{ color: 'red' }} className="error-block">{error}</div>
            <reactbootstrap.Modal.Footer>
              <reactbootstrap.Modal.Footer></reactbootstrap.Modal.Footer>
              <reactbootstrap.Button type="submit" disabled={loading} color="primary">{t('Save')}</reactbootstrap.Button>
              {loading &&
                <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
              }
              &nbsp;&nbsp;&nbsp;
                    <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.handleCancel} >{t('Remove')}</reactbootstrap.Button>
            </reactbootstrap.Modal.Footer>
          </reactbootstrap.Form>
        </reactbootstrap.Container>
      </reactbootstrap.Modal>
    );
  }
}
export default translate(Memo);
