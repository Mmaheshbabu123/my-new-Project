import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { userService } from './_services/user.services';
import * as reactbootstrap from 'react-bootstrap';
import { translate} from './language';
import { datasave } from './_components/Constants';
import { datasave } from './_services/db_services';


class Login extends Component {

    constructor(props) {
        super(props)
        userService.logout();
        this.state = {
            t: props.t,
            email: '',
            password: '',
            showerror: false,
            submitted: false,
            loading: false,
            error: ''
            // selectedlanguage:this.props.selectedlanguage
        }

        this.hasErrorFor = this.hasErrorFor.bind(this)
        this.renderErrorFor = this.renderErrorFor.bind(this)
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    /*componentDidUpdate(prevProps){
        if(prevProps.selectedlanguage !== this.props.selectedlanguage){
            this.setState({selectedlanguage:this.props.selectedlanguage});
            // setLanguage(this.props.selectedlanguage);
        }
        else{
        }
    }*/

    handleChange(e) {
        const { name, value } = e.target;
        this.setState({ [name]: value });
    }

    handleSubmit(e) {

        e.preventDefault();

        this.setState({ submitted: true });
        const { email, password } = this.state;

        // stop here if form is invalid
        if (!(email && password)) {
            return;
        }
        this.setState({ loading: true });
        userService.login(email, password)
            .then(user => {
                    /*window.user_data = user.user_data;
                    return
                    localStorage.setItem('uuser_data', user.user_data);

                    return*/
                    const { from } = { from: { pathname: "/" } };
                    this.props.history.push(from);
                },
                error => this.setState({ error, loading: false })
            );

    }

    hasErrorFor (field) {
        return !!this.state.errors[field]
    }

    renderErrorFor (field) {
        if (this.hasErrorFor(field)) {
            return (
            <span className='invalid-feedback'>
                <strong>{this.state.errors[field][0]}</strong>
            </span>
            )
        }
    }

    render() {
        const {t} = this.state;
        const { email, password, submitted, loading, error } = this.state;
        return (
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-md-8">
                        <div className="card">
                            <div className="card-header">{t('Login')}</div>
                            <reactbootstrap.Container className="p-5">
                                <reactbootstrap.Form onSubmit = { this.handleSubmit } >
                                    <reactbootstrap.FormGroup>
                                    <div className={'form-group' + (submitted && !email ? ' has-error' : '')}>
                                        <label>{t('Email')}  <span style={{ color: 'red' }}>  *</span></label>
                                        <input type="text"
                                            className="form-control"
                                            name="email"
                                            value={email}
                                            onChange={this.handleChange}
                                            id="email"
                                            placeholder="email@email"
                                        />
                                        {submitted && !email &&
                                            <div style={{ color: 'red' }} className="help-block">{t('The Email field is required')}</div>
                                        }
                                    </div>
                                    </reactbootstrap.FormGroup>
                                    <reactbootstrap.FormGroup>
                                    <div className={'form-group' + (submitted && !password ? ' has-error' : '')}>
                                        <label>{t('Password')} <span style={{ color: 'red' }}>  *</span></label>
                                        <input type="password"
                                            className="form-control"
                                            name="password"
                                            value={password}
                                            onChange={this.handleChange}
                                            id="password"
                                            placeholder="Password"
                                        />
                                        {submitted && !password &&
                                            <div style={{ color: 'red' }} className="help-block">{t('The Password field is required')}</div>
                                        }
                                    </div>
                                    </reactbootstrap.FormGroup>
                                    <reactbootstrap.FormGroup>
                                        <div>
                                            <Link className='btn btn-primary btn-sm mb-3' to='/forgotpassword'>
                                                {t('Forgot password')}
                                            </Link>
                                        </div>
                                    </reactbootstrap.FormGroup>
                                    <reactbootstrap.FormGroup>
                                    <div className="form-group">
                                        <button type="submit" className="btn btn-primary" disabled={loading}>{t('Login')}</button>
                                        {loading &&
                                            <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                                        }
                                    </div>
                                    {error &&
                                        <div className={'alert alert-danger'}>{error}</div>
                                    }
                                    </reactbootstrap.FormGroup>
                                </reactbootstrap.Form>
                            </reactbootstrap.Container>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default translate(Login)
