import React, { Component } from 'react';
import Pagination from 'react-bootstrap/Pagination'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import CheckBox from '../CheckBox';
import './system.css';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';


import { OCAlert } from '@opuscapita/react-alerts';

const KEYS_TO_FILTERS = ['name', 'id']

class System extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t: props.t,
      documents: [],
      delete: false,
      selectedItems :[],
      selectAll: 0,
      deletestatus : false,
      expiredstatus :true,
      active_tab: 1,
      webforms : [],
      alldocuments : [],

    }
    this.exportFiles = this.exportFiles.bind(this);
    this.deleteFiles = this.deleteFiles.bind(this);
    this.selectAll = this.selectAll.bind(this);
  }

  componentDidMount() {
    this.getDocuments();
  }

  getDocuments () {
    var url = window.GET_EXPIRED_DOCS;
      datasave.service(url, 'GET', '')
        .then(response => {
          this.setState({
            documents: response.filter((doc) =>parseInt(doc.webform)===0),
            webforms : response.filter((web) =>parseInt(web.webform)===1),
            alldocuments : response
          })
      })
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.delete !== this.state.delete) {
      this.getDocuments();
    }

  }

  async exportFiles() {
    const data ={
      selecteddata : this.state.selectedItems,
    }

    var URL = window.GET_EXPIRED_DOCS_ZIP;
    await datasave.service(URL, "POST", data)
      .then(async response => {
        var a = document.createElement("a");
        a.setAttribute("type", "file");
        a.href = response.file;
        a.download = response.name;
        document.body.appendChild(a);
        a.click();
        a.remove();
      });
    await this.setState({
      deletestatus : true,
      expiredstatus :false,
    })
  }
  deleteFiles() {
    const data ={
      selecteddata : this.state.selectedItems,
    }
    var URL = window.DELETE_EXPIRED_DOCS;
    datasave.service(URL, "POST", data)
      .then(response => {
        this.setState({
          delete: true,
          deletestatus : false,
          expiredstatus :true,
        })
      });
  }
  selectedItemsList (e,status,name) {
    const allItems = status===1?this.state.documents:this.state.webforms;
    allItems.map((each_item, key) => {
      if (each_item.id == e.target.name) {
        allItems[key]['checked'] = !allItems[key]['checked']
        if (allItems[key]['checked']) {
          this.state.selectedItems.push(each_item);
        } else {
          this.state.selectedItems.map((item, key1) => {
            if (item.id === e.target.name) {
              this.state.selectedItems.splice(key1, 1);
              this.setState({
                selectAll: 0
              })
            }
          })
        }
      }
    })

    this.setState({
      [name]: allItems,
    })
  }
  selectAll(e,status,name) {
    const allItems = this.state.alldocuments;
    //Imediatly after setstaet we cont check that value so here added reverse condition
    if (this.state.selectAll) {
      allItems.map((each_item, key) => {
          allItems[key]['checked'] = 0
      })
      this.setState({
        selectedItems: [],
      })
    } else {
      allItems.map((each_item1, key1) => {
          if (!allItems[key1]['checked']) {
            allItems[key1]['checked'] = 1
            this.state.selectedItems.push(each_item1)
          }
      })
    }
    this.setState({
      documents: allItems.filter((doc) =>parseInt(doc.webform)===0),
      webforms : allItems.filter((doc) =>parseInt(doc.webform)===1),
      selectAll: !this.state.selectAll,
    })
  }

  tableStructure(data,status,name) {
    const { t,selectAll } = this.state;
    let documents = data;
    return (
      <div >
        <div className='row '>
          <div id="systemcleanup" className='col-md-12 pl-0' >
            <div className='col-md-12 pr-0' >
              <div className="text-center">
                <div className='pt-2 pb-2 mb-1'><h3>{t('System cleanup')}</h3> </div>
              </div>
              <div className="">
                <reactbootstrap.Table  style={{position: 'relative'}} striped bordered responsive hover className="m-0" >
                  <thead style={{color: '#fff'}}>
                    <tr>
                      <th style={{position: 'sticky',top: '0',backgroundColor: '#EC661C' }}>{t('Document name')}</th>
                      <th style={{position: 'sticky',top: '0',backgroundColor: '#EC661C' }}>{t('Document code')}</th>
                      <th style={{position: 'sticky',top: '0',backgroundColor: '#EC661C' }}>{t('Document version')}</th>
                      <th style={{position: 'sticky',top: '0',backgroundColor: '#EC661C' }}>{t('Manual name')}</th>
                      <th style={{position: 'sticky',top: '0',backgroundColor: '#EC661C',zIndex:'99' }}>
                      {status ==1&& <CheckBox
                          name={t("Select all")}
                          tick={selectAll}
                          onCheck={e => this.selectAll(e,status,name)}
                          value={selectAll}
                          disabled={this.state.deletestatus}
                      />}
                      {status ==2&& <CheckBox
                          name={t("Select all")}
                          tick={selectAll}
                          onCheck={e => this.selectAll(e,status,name)}
                          value={selectAll}
                          disabled={this.state.deletestatus}
                      />}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {documents.map(doc => {
                      return (
                        <tr disabled ={this.state.deletestatus}>
                          <td>{doc.name}</td>
                          <td>{doc.code}</td>
                          <td>{doc.version}</td>
                          <td>{doc.manual_name}</td>
                          <td>
                            <reactbootstrap.Form.Check
                              onChange={e => this.selectedItemsList(e,status,name)}
                              checked={doc.checked}
                              name={doc.id}
                              className="col-md-12"
                              disabled={this.state.deletestatus}
                            />
                          </td>
                        </tr>
                      )
                    })}
                    {
                      documents.length === 0 &&
                      <tr style={{textAlign: 'center'}}>
                        <td colspan='3' >{t('No records found')}</td>
                      </tr>
                    }
                  </tbody>
                </reactbootstrap.Table>
              </div>
            </div>
            {documents.length !== 0 &&
              < div className="mt-3 mb-5 float-right">
              {this.state.selectedItems.length!=0 && this.state.expiredstatus &&
                <Can
                  perform = "Export_system_clean"
                  yes = {() => (
                    <reactbootstrap.Button className="mr-2" onClick={() => this.exportFiles()}>{t('Export')}</reactbootstrap.Button>
                  )}
                />}

                {this.state.deletestatus &&
                <Can
                  perform = "D_system_clean"
                  yes = {() => (
                    <reactbootstrap.Button onClick={() => this.deleteFiles()}>{t('Delete')}</reactbootstrap.Button>
                  )}
                />}
              </ div                                                                                                                              >
            }

          </div>
        </div>
      </div>
    )
  }
  handlePageClick(key){
    this.setState({
      active_tab: Number(key),
    });
  }



  render() {
    const { t,active_tab } = this.state;
    let documents = this.state.documents;
    let webforms = this.state.webforms;
    return (
      <Can
        perform = "R_system_clean,Export_system_clean,D_system_clean"
        yes = {() => (
      <div className="row mb-3 col-md-12">
        <div style={{ visibility: 'hidden' }} className="col-md-1">
          <p>welcome</p>
        </div>
        <div className='col md-12'>
        <reactbootstrap.Tabs activeKey={active_tab} onSelect={this.handlePageClick.bind(this)} style={{border: 'none'}} id="controlled-tab-example" >
          <reactbootstrap.Tab eventKey={1} title={t("Documents")} className="card mt-5">
            {this.tableStructure(documents,1,'documents')}
          </reactbootstrap.Tab>
          {(CanPermissions("Webforms_in_system_cleanup", "") === true) &&
            <reactbootstrap.Tab  eventKey={2} title={t("Webforms")} className="card mt-5">
              {this.tableStructure(webforms,2,'webforms')}
            </reactbootstrap.Tab>
          }
        </reactbootstrap.Tabs>
        </div>
      </div>
    )}
    no = {() =>
      <AccessDeniedPage />
    }
  />
    )
  }
}

export default translate(System);
