import React from 'react';
import Camera, { FACING_MODES, IMAGE_TYPES } from 'react-html5-camera-photo';
import * as allDevices from "react-device-detect";
import 'react-html5-camera-photo/build/css/index.css';
function WebCamera(props) {
  async function handleTakePhoto(dataUri) {
    var randomFileName = new Date().getTime();
    let file = dataURLtoFile(dataUri, randomFileName);
    return props.handleTakePhoto(dataUri, file, randomFileName);
  }
  window.navigator.mediaDevices.getUserMedia && window.navigator.mediaDevices.getUserMedia({ audio: true, video: true }, function (stream) {
    if (stream.getVideoTracks().length > 0 && stream.getAudioTracks().length > 0) {
      console.log('1');
    } else {
      console.log('2');
    }
  });
  function dataURLtoFile(dataurl, filename) {
    var arr = dataurl.split(","),
      mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]),
      n = bstr.length,
      u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }

  function handleTakePhotoAnimationDone(dataUri) {
    console.log('takePhoto');
  }
  function handleCameraStart(stream) {
    console.log('handleCameraStart');
  }

  function handleCameraStop() {
    console.log('handleCameraStop');
  }
  function handleCameraError(error) {
    console.log(error);
  }
  return (<Camera
    onTakePhoto={(dataUri) => { handleTakePhoto(dataUri); }}
    onTakePhotoAnimationDone={(dataUri) => { handleTakePhotoAnimationDone(dataUri); }}
    onCameraError={(error) => { handleCameraError(error); }}
    idealFacingMode={FACING_MODES.ENVIRONMENT}
    idealResolution={{ width: 640, height: 480 }}
    imageType={IMAGE_TYPES.JPG}
    imageCompression={0.97}
    isMaxResolution={false}
    isImageMirror={(allDevices.isMobile || allDevices.isTablet || allDevices.isIPhone13 || allDevices.isIPad13 || allDevices.isIPod13) ? false : true}
    isSilentMode={false}
    isDisplayStartCameraError={true}
    isFullscreen={false}
    sizeFactor={1}
    onCameraStart={(stream) => { handleCameraStart(stream); }}
    onCameraStop={() => { handleCameraStop(); }}
  />
  )
}
export default WebCamera;
