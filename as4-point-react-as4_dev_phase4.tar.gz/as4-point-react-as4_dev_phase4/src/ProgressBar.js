import React from "react";
import * as reactbootstrap from 'react-bootstrap';
import PropTypes from "prop-types";
import Styled from "styled-components";
const Container = Styled.div`
  progress {
    margin-right: 8px;
  }

  progress[value] {
    width: ${props => props.width};

    -webkit-appearance: none;
    appearance: none;
  }

  progress[value]::-webkit-progress-bar {
    height: 10px;
    border-radius: 20px;
    background-color: #eee;
  }

  progress[value]::-webkit-progress-value {
    height: 10px;
    border-radius: 20px;
    background-color: ${props => props.color};
  }
`;
const ProgressBar = ({ value, max,color, width}) => {
  return (
    <reactbootstrap.Modal
        size="lg"
        show={true}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title">
        <reactbootstrap.Modal.Header closeButton>
            <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
             {'Uploading data please wait'}
            </reactbootstrap.Modal.Title>
            <reactbootstrap.Modal.Body>
             <Container color={color} width={width}>
      <progress value={value} max={max} />
       <span>{Math.ceil((value / max) * 100)}%</span>
        </Container>
      </reactbootstrap.Modal.Body>
  </reactbootstrap.Modal.Header>
</reactbootstrap.Modal>

  );
};


ProgressBar.defaultProps = {
  max: 100,
  color: "lightBlue",
  width: "250px"
};

export default ProgressBar;
