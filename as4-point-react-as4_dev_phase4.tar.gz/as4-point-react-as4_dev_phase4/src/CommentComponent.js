import React, { Component } from 'react';
import CheckBoxList from './CheckBoxList';
import { datasave } from './_services/db_services'
import { TabbedLayout } from 'ag-grid-community';
import { translate } from './language';

class CommentComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            url: this.props.url,
            comment: '',
            doc_status: '',
            notify_status: '',
            commented_at: '',
            option_type : '',
            logPerson: '',
            comPerson: '',
            file_path: '',
            notifyId: 0,
            t: props.t,
        }
    }
    displayComment() {
        var table = [];
        const { t } = this.state;
        switch (this.state.notifyId) {
            case 1:
                table.push(this.verify_authorise('verification by'));
                break;
            case 2:
                table.push(this.verify_authorise('authorisation by'));
                break;
            case 3:
                table.push(
                    <div>{t('Hi')}&nbsp;{this.state.logPerson},&nbsp;
                        {t('this is warning message that the to review date of this document is about to be passed')}

                    </div>);
                break;
            case 4:
                table.push(<div>
                    {t('Hi')}&nbsp;{this.state.logPerson},&nbsp;{t('the to review date of this document is passed.')}

                </div>)
                break;
            case 5:
                table.push(
                    <div>
                        {this.state.comment && <div>{t('Hi')}&nbsp;{this.state.logPerson},&nbsp;
                    {t('this document was rejected during the reviewing by')}&nbsp;"{this.state.comPerson}"
                    {t(' with this comment:')}&nbsp;"{this.state.comment}"</div>}
                    </div>);
                break;
            case 6:
                table.push(
                    <div>
                        {this.state.comment && <div>{t("Hi")}&nbsp;{this.state.logPerson},&nbsp;
                        {t('this document was rejected during the expiration cycle by')}&nbsp;"{this.state.comPerson}"
                        {t(' with this comment:')}&nbsp;"{this.state.comment}"</div>}
                    </div>);

                break;
            case 7:
                table.push(
                    <div>
                        {t('Hi')}&nbsp;{this.state.logPerson}&nbsp;{t(',this document is expired.')}

                    </div>
                )
                break;
            case 8:
                table.push(
                    <div>
                        {
                            this.state.comment && <div>{t("Hi")}&nbsp;{this.state.logPerson},&nbsp;{t('this document was not read and understand by')}&nbsp;"{this.state.comPerson}"&nbsp;
                {t(' with this comment:')}&nbsp;"{this.state.comment}"</div>}
                        {this.state.file_path && <div><a href={this.state.file_path}>{t('Link')}</a></div>}
                    </div>
                )
                break;
            case 9:
                table.push(
                    <div>
                        {t('Hi')}&nbsp;{this.state.logPerson},&nbsp;{t('this document needs to be reviewed because the main document of the bundle is revised.')}
                    </div>
                )
                break;
            case 10:
                table.push(<div>
                    {
                        this.state.comment && <div>{t('Hi')}&nbsp;{this.state.logPerson},&nbsp;
            {t('for this document there was a webcomment sent by')}&nbsp;"{this.state.comPerson}"&nbsp;
            {t(' with this comment:')}&nbsp;"{this.state.comment}"</div>}
                </div>);
                break;
            case 11:
                break;
        }
        return table;
    }
    verify_authorise(statusName) {
        const { t } = this.state;
        return (
            <div>
                {
                    this.state.comment && <div>{t('Hello')}&nbsp;{this.state.logPerson},&nbsp;{t('below document was rejected during the'+' '+statusName)}&nbsp;"{this.state.comPerson}"&nbsp;{t('because of errors in ')} {this.state.option_type}{t('The user gave following comment:')}&nbsp;"{this.state.comment}"&nbsp;{t('and reject time:')}&nbsp;{this.state.commented_at}</div>
                  }
                  {<div>{t('Please make the requested changes to the document via the editor, and initiate the document afterwards.')}</div>}
                  {this.state.file_path !=='' && <div>{t('The')}&nbsp;{t(this.state.comPerson)}&nbsp;{t('has attached an additional document with comments:')}<a href={this.state.file_path}>{t('Link')}</a></div>}
            </div>
        );
    }
    render() {
      console.log(this.state);
        return (
            <div>
                {this.displayComment()}
                {/* <div>
                    {
                        this.state.comment && <div>Hi {this.state.logPerson},
                    the below document is rejected during the {this.state.doc_status}
                            with the following comment: "{this.state.comment}"
                    from "{this.state.comPerson}" on "{this.state.commented_at}".
                    Please process the feedback in the manual management section and initiate the document again afterwards.</div>
                    }
                    {this.state.file_path && <div><a href={this.state.file_path}>Link</a></div>}
                </div> */}
                {/* <h5>
                    <p>Notification status: {this.state.notify_status}</p>
                    <p>Document status: {this.state.doc_status}</p>

                </h5>
                <h4>
                    <p>Comment: {this.state.comment}</p>

                </h4> */}
            </div>
        )
    }
    componentDidMount() {
        datasave.service(this.state.url, "GET")
            .then(result => {
                this.setState({
                    comment: result['Comment'],
                    doc_status: result['Doc_status'],
                    notify_status: result['Notify_status'],
                    commented_at: result['Commented_at'],
                    option_type : result['Option_type'] === 1 ? 'layout/spelling.' :(result['Option_type'] === 2 ? 'content.' :'layout and content.'),
                    logPerson: result['LogPerson'],
                    comPerson: result['ComPerson'],
                    file_path: result['File_path'],
                    notifyId: parseInt(result['Notify_ID'])

                })
            });
    }
}

export default translate(CommentComponent);
