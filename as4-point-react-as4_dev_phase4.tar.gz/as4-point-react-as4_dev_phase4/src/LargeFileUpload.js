import React, { useState, useEffect, useRef } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from './language';
import axios from 'axios';
import {store } from './store';
import $ from 'jquery';
import { datasave } from './_services/db_services';
import ProgressBar from './ProgressBar';
const path = require('path')

const LargeFileUpload=(props)=>{
  const t = props.t;
  const [importData,setImportData] = useState({
    file:'',
    fileName:'',
    chunkSize:0,
    chunkFile:'',
    progressValue:0,
    progressPopup:false,
    action:'',
    filepath:'',
    uploadAllow : 0,
  });

  const {file,file_details,show,popUpData,table_name}=importData;

  const handleChange = async(e)=>{
    const { t } = importData;
    let Userdata = store.getState();
    let systemsettings = Userdata.UserData.systemsettings;
     let Allow = 0;
    let kilobytes = (e.target.files[0]['size'] / 1000).toFixed(1);
    let megabytes = kilobytes / 1024;
    let sizeType = systemsettings['20-1'] == undefined ? 4 : parseInt(systemsettings['20-1']);
    let specifiedSize = systemsettings['19-1'] == undefined ? 1024 : parseInt(systemsettings['19-1']);
    if(props.type === undefined ) {
        if (sizeType == 4 && kilobytes > specifiedSize || sizeType == 5 && megabytes > specifiedSize) {
            OCAlert.alertError(t('Size of a document is more than specified size in settings'), { timeOut: window.TIMEOUTNOTIFICATION });
        } else {
            Allow =1;
        }
    } else {
        if(props.type === e.target.files[0]['name'].slice(-3) || props.type === 5) {
          Allow =1  ;
        } else {
            props.updateImageUpload("notMP4");
            setImportData({
              ...importData,
              fileName: "Choose file",
            })
        }
    }

let data = createChunks(e.target.files[0]);
setImportData({
  ...importData,
  file:e.target.files[0],
  fileName:e.target.files[0]['name'],
  chunkSize:data.ChunkSlice,
  chunkFile:data.ChunkFile,
  uploadAllow:Allow,
})



  }
  useEffect(()=>{
    if(importData.uploadAllow === 1){
    uploadFile();
  }
  },[importData.uploadAllow])
const  createChunks = (file) =>{
    let data = {
      ChunkSlice:0,
      ChunkFile:[],
    }
      let size = 1000000, chunks = Math.ceil(file.size / size);
      data.ChunkSlice = chunks;
      for (let i = 0; i < chunks; i++) {
          data.ChunkFile.push(file.slice(
              i * size, Math.min(i * size + size, file.size), file.type
          ));
      }

   return data;
  }

  const uploadFile =async (e)=>{
    console.log(importData);
    console.log(importData);
let Result = [];
   for (let i = 0; i < importData.chunkSize; i++){
     let formData = new FormData();

     formData.set('is_last', importData.chunkFile.length === 1);
     formData.set('file', importData.chunkFile[0], `${importData.fileName}.part`);
     document.getElementById("loding-icon").setAttribute("style", "display:block;");
     await axios.post(window.backendURL + window.IMPORT_LARGE_FILE, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
     .then(async response => {
             console.log(response);
             Result = response;
             let data = response.data;
             document.getElementById("loding-icon").setAttribute("style", "display:none;");
             if(data.status===200 ){
             let per =   Math.floor(((i+1)/importData.chunkSize) * 100);
             console.log(per)
             console.log(i+1);

               setImportData({...importData,
               progressPopup : true,
               progressValue : per,
             })
       }
     })
     importData.chunkFile.shift();
   }
   setImportData({...importData,
    progressPopup : false,
    uploadAllow:0,
 })
 OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
  props.updateImageUpload(Result);
}

  const openClosePopup=()=>{
    setImportData({
      ...importData,
      show:false,
      popUpData:[]
    });
  }
  const exampleDownLoad = ()=>{
    let userAgentString = navigator.userAgent;
    let chromeAgent = userAgentString.indexOf("Chrome") > -1;// Detect Chrome
    if(chromeAgent){
      window.open('https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5fd349a159ee83.730118801607682465.csv', '_blank');
    }else {
      var a = document.createElement('a');
      a.title = t("Download");
      a.href = 'https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5fd349a159ee83.730118801607682465.csv';
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
  }
  const handleChangeName = (event) =>{
    const { name, value } = event.target;
    setImportData({
      ...importData,
      [name]: value,
     });
   }

  const clearForm =()=>{
    const {file_details,file,table_name,action}=importData;
    if(file_details==='' && file === '' && table_name === '' || action === 'edit'){
          props.updateManageImportFiles(importData,'close_component');
          setImportData({
            ...importData,
            show:false,
            popUpData:[],
            file:'',
            file_details: '',
            filePath:'',
            table_name:'' ,
            fileId:0,
            action:'create',
            row_id:0,
            import_type:1,
          });
     }else {
      setImportData({
        ...importData,
        show:false,
        popUpData:[],
        file:'',
        file_details: '',
        filePath:'',
        table_name:'' ,
        fileId:0,
        action:'create',
        row_id:0,
        import_type:1,
      });
    }

  //  props.openCloseUploadPopup();
  }
  const popUp = ()=>{
    let data = popUpData &&Object.values(popUpData).map(item=>{
      return(
        <tr style={{ textAlign: 'center' }}>
        <td>{item.name}</td>
        <td>{item.email}</td>
        <td>{item.barcode}</td>
        </tr>
      );
    })
    return(
      <reactbootstrap.Modal
      show={show}
      onHide={(e) => openClosePopup()}
      dialogClassName="modal-90w"
      aria-labelledby="example-custom-modal-styling-title"
      >
      <reactbootstrap.Modal.Header closeButton>
      <reactbootstrap.Modal.Title>{t('Please verify this users and import again')}</reactbootstrap.Modal.Title>
      </reactbootstrap.Modal.Header>
      <reactbootstrap.Modal.Body>
      <reactbootstrap.Table responsive striped bordered hover size="sm">
      <thead style={{ backgroundColor: '#EC661C', color: '#fff', position: 'sticky', top: '0', textAlign: 'center' }}>
      <tr style={{ textAlign: 'center' }}>
      <th>{t('Name')}</th>
      <th>{t('Email')}</th>
      <th>{t('Barcode')}</th>
      </tr>
      </thead>
      <tbody>
      {data}
      </tbody>
      </reactbootstrap.Table>
      </reactbootstrap.Modal.Body>
      </reactbootstrap.Modal>)
    }

    const formDisable =  false;
    let accept = ((props.type !== undefined && props.type !== '' )|| (props.related !==undefined && props.related!=='')) ? window.DOC_TYPES[props.type] : window.DOC_TYPES['default'];
    let label  =  (props.label === undefined ? t('Upload') : t(props.label))
   console.log(props);
   console.log(accept);
   console.log(label);
    return(
<>
  <div className="input-group-prepend col-md-4">
      <span style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} className=" " id="inputGroupFileAddon01">
        {label}
      </span>
  </div>
  <div className="col-md-8 custom-file input_sw">
      <input
          type="file"
          className="custom-file-input"
          id="image"
          aria-describedby="inputGroupFileAddon01"
          disabled={props.disabled_cycle || props.disabled_view}
          name='image'
          accept={"mp4"}
          onChange={(e) => handleChange(e)}
      />
      <label className="custom-file-label" htmlFor="inputGroupFile01">

          {props.file_name !== null && importData.fileName === '' &&
              props.file_name.substr(props.file_name.lastIndexOf('/') + 1)
          }
          {importData.fileName !== '' && importData.fileName}
      </label>
  </div>
{importData.progressPopup && <ProgressBar value= {importData.progressValue} color={"#ff7979"} width={"150px"} max={importData.progressMax}/>}
      </>
    )

  }
  export default translate(LargeFileUpload);
