import React from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { BrowserRouter as Router } from 'react-router-dom'
import { datasave } from '../_services/db_services';
import './Master.css';
import { Draggable } from 'react-drag-and-drop';
import {translate} from '../language';
import FMDWebformEditor from './FMDWebformEditor';
import { persistor, store } from '../store';

class FrameDocumentTemplate extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      key: 'jobs',
      openEditor: true,
      docData: [],
      docName: '',
      t:props.t,
      insertmasterdata: true,
      lang: 'Dutch',
      language: [],
      langs: [],
      show:false,
      langId: 3,
      docReportId:'',
      report_name:'',
      reportName:'',
    }
   this.handleChanges = this.handleChanges.bind(this);
   this.getData = this.getData.bind(this);
  }
  async componentDidMount() {
   let languageId;
     datasave.service(window.DOC_TEMP_REPORT_NAME + '/' + this.props.match.params.docReportId, 'GET')
                .then(response => {
                      this.setState({
                         reportName : response.name,
                      });
                 });
      await datasave.service(window.GET_ALL_LANGUAGES, 'GET')
          .then(async response => {
              languageId = response[0].id;
             this.setState({
               language: response,
               langId : languageId,
               show:true,
             });
           });
      datasave.service(window.STORE_DOC_TEMP_REPORT_PATH + '/' + this.props.match.params.docReportId + '/' + languageId, 'GET')
                 .then(response => {
                        this.setState({
                          report_name:response.data['docTempReport_path'],
                        });
                     });

}

  handleChanges(e){
    const { value } = e.target;
    this.getData(value);
  }

  getData(value){
    datasave.service(window.STORE_DOC_TEMP_REPORT_PATH + '/' + this.props.match.params.docReportId + '/' + value, 'GET')
    .then(response =>{
      this.setState({
        report_name:response.data['docTempReport_path'],
        langId : value,
      });
    });
  }

  closeDocEditor(e) {
    this.setState({
      openEditor: false,
    });
    this.props.history.push("/reports");
  }
  addmasterdata(e) {
    document.getElementById('editor-frame-wrapper').setAttribute("class", "col-md-10 col-lg-10 px-0 editor");
    document.getElementById('fmd-wrapper').setAttribute("style", "display:block;");
    document.getElementById('office_frame').setAttribute("style", "margin-left:-181px");
    this.setState({ insertmasterdata: false });
  }

  closemasterdata(e) {
    document.getElementById('editor-frame-wrapper').setAttribute("class", "col-md-12 col-lg-12 px-0 editor");
    document.getElementById('fmd-wrapper').setAttribute("style", "display:none;");
    document.getElementById('office_frame').setAttribute("style", "margin-left:-224px");
    this.setState({ insertmasterdata: true });
  }


  render() {
    const {t} = this.state;
    const webform_id = -1;
    const docReportId = this.props.match.params.docReportId;
    return (
      <div id="fmd-wrapper-layout-web" className="row ml-5 py-3 pl-1 smart-editor">
        <div className= "options col-md-5">
         <div className="col-md-2 lang-label"><reactbootstrap.Form.Label>{t('Language:')}</reactbootstrap.Form.Label></div>
          {this.state.show &&
            <reactbootstrap.FormControl className="col-md-7" as="select"
                              name="displayvalue"
                              onChange={this.handleChanges}> >
                              <option style={{ display: "none" }}>{t('Select')}</option>
                              {this.state.language.map(ele => <option key={ele.id} selected = {ele.id == this.state.langId} value={ele.id}>{ele.language}</option>)}
            </reactbootstrap.FormControl>

          }
         </div>
         <div className = "template-name-fm"><reactbootstrap.Form.Label>{t('Document Report Name')}: {this.state.reportName}</reactbootstrap.Form.Label></div>
          <div className="preview-button" style = {{ margin: '0px 100px 20px 0' }}>
            <reactbootstrap.Button className="btn" onClick={(e) => this.closeDocEditor(e)}>{t('Close')}</reactbootstrap.Button>
            {this.state.insertmasterdata && <reactbootstrap.Button className="btn" onClick={(e) => this.addmasterdata(e)}>{t('Insert masterdata')}</reactbootstrap.Button>}
            {!this.state.insertmasterdata && <reactbootstrap.Button className="btn" onClick={(e) => this.closemasterdata(e)}>{t('Minimize masterdata')}</reactbootstrap.Button>}
            </div>

       <div id="editor-frame-wrapper" className="col-md-12 col-lg-12 editor px-0">
        <div className="card">
         <div className="card-body pr-0">
         {this.state.report_name !== '' && <DocEditor langid = {this.state.langId} report_name = {this.state.report_name} docReportId = {this.props.match.params.docReportId} did={webform_id} />}
          </div>
        </div>
      </div>
      <FMDWebformEditor
              postmessage={process.env.REACT_APP_baseURL_office}
              did={webform_id}
              docReportId = {this.props.match.params.docReportId}
              flow="webformelements"
              stateObj = {this.state} />
      </div>
    );
  }

}
class DocEditor extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    const name = this.props.report_name;
    const docReportId = this.props.docReportId;
    const langid = this.props.langid;
    const hashcode = process.env.REACT_APP_baseURL_office_hashcode;
    const loleaflet_src = process.env.REACT_APP_baseURL_office  + "/loleaflet/" + hashcode + "/loleaflet.html";
    //const loleaflet_src = "http://office-frontend.local:9980/loleaflet/305832f/loleaflet.html";
    const access_token = "aFPBvqgQZ6g0dnDUKHcSRn5HZhCHJugm";
    const title = name;
    let Userdata = store.getState();
    let person_id = Userdata.UserData.user_details.person_id;
    let person_name = Userdata.UserData.user_details.user_name;
    let WOPISrc = '';
    let WOPI_src_url = window.backendURL;
    WOPISrc = WOPI_src_url + "/api/template/wopi/files/" + docReportId + '/' + langid + '/' + title +  '/' + person_id + '/' + person_name;
    const iframeSource = loleaflet_src + "?access_token=" + access_token + "&WOPISrc=" + WOPISrc + "?title=" + title + "&lang=en&closebutton=1&revisionhistory=1&doc_type=1";
    return (
      <iframe id="office_frame" width="100%" height="800px" name="office_form" src={iframeSource}></iframe>
    );
  }
}
export default translate(FrameDocumentTemplate);
