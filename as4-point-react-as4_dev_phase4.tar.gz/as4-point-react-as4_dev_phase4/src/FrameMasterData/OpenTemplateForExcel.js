import React, { Component } from 'react';
import CKEditor from '@ckeditor/ckeditor5-react';
import ClassicEditor from 'ckeditor5-build-classic-plus';
import {translate} from '../language';
import { reducers } from '../GroundPlan/Building/Reducers/reducers';
import $ from 'jquery';
var CURSOR_POSITION = 0;
var EDITOR_INSTANCE = {};

class OpenTemplateForExcel extends Component{
  constructor(props) {
      super(props);
      this.state = {
        t: props.t,
        formatWarning : false,
        sizeWarning   : false,
      }
  }

  handleFileChanges = async (e) => {
    let response = await reducers.uploadImage(e);
    if(response.status === 200){
      this.setState({
        formatWarning : false,
        sizeWarning : false,
        uploadMessage : true,
      }, ()=>this.props.handleLeftArea(response.data.file_id[0], response.data.originalfname))
    } else{
      this.setState({
        formatWarning : response.formatWarning,
        sizeWarning   : response.sizeWarning,
        uploadMessage:false,
      })
    }
  }

  handleEditorChange(editor, key) {
      EDITOR_INSTANCE = editor;
      let value = editor.getData();
      this.props.handleEditorChange(key, value);
  }

  handleInsertTokens(el, newText) {
    let token = localStorage.getItem('framemasterdataTemplate_Token');
    EDITOR_INSTANCE.model.change( writer => {
    const position = EDITOR_INSTANCE.model.document.selection.getFirstPosition();
		writer.insertText( token, position, 'after' );
    EDITOR_INSTANCE.editing.view.focus();
	});
}

  editorForAddingTokens(key, stateData){
    return(
      <div className='col-md-12 input-padd input_sw'>
      <CKEditor
        type = "textarea"
        config={{ toolbar: [ 'Heading', '|', 'Bold', 'Italic', 'Undo', 'Redo' ]}}
        editor={ClassicEditor}
        data={stateData || ''}
        onChange={(e, editor) => {this.handleEditorChange(editor, key)}}
        onFocus={ ( event, editor ) => {
                      EDITOR_INSTANCE = editor;
                	    EDITOR_INSTANCE.model.change( writer => {
                	  	CURSOR_POSITION = EDITOR_INSTANCE.model.document.selection.getFirstPosition();
                	});
                } }
      />
    </div>
    );
  }

  render(){
    const { t } = this.state;
    return(
      <div className='col-md-12 row p-0 m-0'>
        <div className='col-md-4 p-1'>
          <div>
          <span style={{ color: '#EC661C', padding: '8px' }}> {t('Left area')}</span>
            <div className='col-md-12 input-padd' style={{height:'5%', border:'2px solid #f5c3a8'}}>
             <div class="image-upload" style = {{padding:'10px'}}>
                <label for="file-input" style= {{cursor:'pointer'}}>
                  <img src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5f47f7b117ba25.333358961598551985.jpg"
                       width='50px' height='50px' title='upload logo'/>
                </label>
                <input style = {{display : 'none'}}id="file-input" type="file" accept={window.DOC_TYPES['default']} onChange={(e) =>{this.handleFileChanges(e)}}/>
                {this.state.formatWarning && <small style={{color:'red'}}> {window.FILE_FORMAT_ERROR_MSG}</small>}
                {this.state.sizeWarning && <small style={{color:'red'}}>{t('Size should be < 1MB')}</small>}
                <p>{this.props.file_name}</p>
              </div>
            </div>
          </div>
        </div>
        <div className='col-md-4 p-1'>
          <span style={{ color: '#EC661C', padding: '8px' }}> {t('Center area')}</span>
          <span style={{ color: '#EC661C', cursor:'pointer', float:'right' }} onClick = {(e) => this.handleInsertTokens(e, 'centerArea')}> {t('Insert tokens')}</span>
          {this.editorForAddingTokens('centerArea', this.props.centerArea)}
        </div>
        <div className='col-md-4 p-1'>
          <span style={{ color: '#EC661C', padding: '8px' }}> {t('Right area')}</span>
          <span style={{ color: '#EC661C', cursor:'pointer', float:'right'}} onClick = {(e) => this.handleInsertTokens(e, 'rightArea')} > {t('Insert tokens')}</span>
           {this.editorForAddingTokens('rightArea', this.props.rightArea)}
        </div>
    </div>
    );
  }
}
export default translate(OpenTemplateForExcel);
