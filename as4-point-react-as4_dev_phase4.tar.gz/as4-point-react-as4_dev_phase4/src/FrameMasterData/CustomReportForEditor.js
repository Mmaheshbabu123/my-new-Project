import React from 'react';
import * as Reactbootstrap from 'react-bootstrap';
import TreeMenu from 'react-simple-tree-menu'
import { Form, Input, ListGroup, ListGroupItem } from 'reactstrap';
import { translate } from '../language';
import { datasave } from '../_services/db_services';
import StaticDynamicPopup from '../DocumentReport/StaticDynamicPopup';

class CustomReportForEditor extends React.Component{
  constructor(props){
    super(props)
    this.state ={
        t:props.t,
        reports         :[],
        searchTerm      :'',
        show            : false,
        tokens          : [],
        selectedToken   : 0,
        showReportPopup : false,
        token_name      : '',
        tuid            : '',
        doc_id          : this.props.id,
        M_F_D_data      : {},
    }
    this.closePopUp = this.closePopUp.bind(this);
    this.storeTokensData = this.storeTokensData.bind(this);
  }

  componentDidMount() {
    datasave.service(`${window.GET_Folders}?customReport=1`, "GET", '')
      .then(data => {
        this.constructTreeData(data);
      });
  }

  constructTreeData(data) {
    let finalData = {};
    let folderData = data;
    var touched_ids = [];
    Object.keys(folderData).map(key => {
        folderData[key].childrens.forEach(id => {
        folderData[key].nodes[id] = folderData[id];
        touched_ids.push(id);
      });
      return finalData[key] = folderData[key];
    });
    touched_ids.forEach(function (id) {
      delete finalData[id];
    });
    this.setState({ M_F_D_data : finalData, })
  }

    handleClick = (id, key_type, current_type) => {
      if (current_type === 'document') {
        this.getCustomCharts(key_type);
      }
    }

  enablePopUp = () => {
      this.setState({ showReportPopup : true, });
  }
  closePopUp = () => {
    this.setState({ showReportPopup : false, });
  }
  getDataToSave = () => {
    let data = {
      token_name  : this.state.token_name,
      template_id : this.state.template_id,
      tuid        : this.state.tuid,
      doc_id      : this.state.doc_id,
    }
    return data;
  }
  storeTokensData = async (popUpData) => {
    let data = await this.getDataToSave();
    let tokenData = {...popUpData, ...data};
    let token_name = ' ' + data.token_name + ' ';
    datasave.service(window.SAVE_REPORT_TOKENS,'POST',tokenData)
    .then(res => {
    });
    document.getElementById('office_frame').contentWindow.postMessage('{"MessageId":"InsertTokens","Body": "' + token_name + '"}', this.props.postmessage);
  }

  Insertinto = (e, name, id) => {
    if(e.target.checked) {
       this.setState({
         name : name,
         template_id : id,
         selectedToken: id,
       })
    }
    if (!e.target.checked) { this.setState({ selectedToken : 0 }); }
  }

  copySelectedTokens = async (e) => {
    let name = this.state.name;
    let id = this.state.template_id;
    const uuidv1 = require('uuid/v1');
    const z = uuidv1();
    let a = z.substring(0, 8);
    let token_name = '$' + name + '_' + id + '_' + a + '$';
    let tuid = '$' + a + '$';
    await this.setState({ token_name : token_name, tuid: tuid, doc_id: this.props.id })
    this.enablePopUp();
  }

  searchData = (e)=>{
    const {target} = e;
    const {cloned} = this.state
    var list = [...cloned];
    list = list.filter(item =>{ return item.label.toLowerCase().search(
      target.value.toLowerCase()) !== -1;
    });
    this.setState({
      reports:list
    })
  }


  render(){
    return(
      <>
      {this.getRenderContent()}
      {this.reportPopup()}
      </>
    )
  }
  getRenderContent =()=>{
    const {t} =this.state;
    const DEFAULT_PADDING = 5;
    const ICON_SIZE = 8;
    const LEVEL_SPACE = 16;
    const DISPLAY = 'inline-flex';
    const WIDTH_DYNAMIC = 15;
    const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }}>{on ? '-' : '+'}</span>;
    const ListItem = ({
      level = 0,
      key,
      doc_type,
      status,
      hasNodes,
      isOpen,
      type_id,
      current_type,
      manual_id,
      label,
      searchTerm,
      version,
      ...props
    }) => (
        <div className="folder-manual-section">
          <ListGroupItem
            {...props}
            style={{ paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE, cursor: 'pointer' }}
            key={key} >
            <div className="list-items-structure" style={{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
              {hasNodes && <ToggleIcon on={isOpen} />}
              {!hasNodes && <span style={{ marginRight: 8 }}> &nbsp;</span>}
              {current_type === 'manual' &&
                <i class="folder-icons folder-icons-accounts" title={t("Manual")} style={{ marginRight: '5px' }}> </i>
              }
              {current_type === 'folder' &&
                <i class="folder-icons folder-icons-folder" title={t("Folder")} style={{ marginRight: '5px' }}> </i>
              }
              {current_type === 'document' &&
                <i class={'folder-icons folder-icons-' + doc_type} title={doc_type} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} />
              }
              {current_type === 'document' &&
                <i class={'sprite-document2 sprite-document2-' + status} title={status} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} />
              }
              <span title={label} className='folderstructure-label'> {label} </span>
              {current_type === 'document' &&
                <span className="version-wrapper"> V-{version} </span>
              }
            </div>
          </ListGroupItem>
        </div >
      );
    const {reports, selectedToken} =  this.state
    const html = (
      <>
        <div className="container-fluid">
          <div className="row scroll-div-table" style = {{ height : '25vh' }}>
            <div className="col-lg-12 fix-overflow-docs">
              <TreeMenu
                data={this.state.M_F_D_data}
                hasSearch='false'
                onClickItem={({ key, label, manual_id, key_type, current_type }) => {
                  this.handleClick(manual_id, key_type, current_type)
                }}
                debounceTime={125}>
                {({ search, items }) => (
                  <>
                    <Input onChange={e => search(e.target.value)} placeholder={t("Search")} />
                    <ListGroup>
                      {items.map((props, key) => (
                        <div key={key}>
                          <ListItem {...props} />
                        </div>
                      ))}
                    </ListGroup>
                  </>
                )}
              </TreeMenu>
            </div>
          </div>
          {this.state.show &&
          <div>
            <div className="copytofile" style = {{ height : '15vh' }}>
              {/*<input style={{ position: 'sticky', top: '0px', zindex: '999', backgroundColor: '#fff' }} className="form-control search-box-border  col-md-12" placeholder={t('Search reports')} onChange={this.searchData} />*/}
              <Reactbootstrap.Table striped bordered hover size="sm" style={{ textAlign: 'left',}}>
                <tbody>
                  {reports.map(report => {
                    return <tr>
                      <td><input
                        type="checkbox"
                        name='name'
                        checked={selectedToken === report.value ? true : false}
                        value={report.value}
                        onChange={(e) => this.Insertinto(e, report.label, report.value)} />
                      </td>
                      <td style={{ cursor: "pointer" }} id={'reportId_' + report.value}  >{report.label} </td>
                    </tr>
                  })}
                </tbody>
              </Reactbootstrap.Table >
            </div>
            <div className="copy-button">
              <Reactbootstrap.Button className="btn btn-primary" onClick={(e) => this.copySelectedTokens(e)}>{t('Copy Tokens')}</Reactbootstrap.Button>
            </div>
          </div>}
        </div>
      </>
    )
    return html
  }
  getCustomCharts(webform_id){
    const  url =  window.GET_CUSTOM_REPORTSFOR_TILE + '/' + webform_id;
      datasave.service(url, 'GET').then(response =>{
        this.setState({
          show : response.length > 0 ? true : false,
          reports:response,
          cloned:JSON.parse(JSON.stringify(response)),
        })
      })
  }

  reportPopup = () => {
    const { t } = this.state;
    return(
      <Reactbootstrap.Modal
          show={this.state.showReportPopup}
          onHide={this.closePopUp}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
      <Reactbootstrap.Modal.Header closeButton>
          <Reactbootstrap.Modal.Title style={{ textAlign:'center' }}>{t('Report type')}</Reactbootstrap.Modal.Title>
      </Reactbootstrap.Modal.Header >
          <Reactbootstrap.Container className="">
              <Reactbootstrap.Modal.Body>
                  <StaticDynamicPopup
                     tokensData      = {this.state}
                     closePopUp      = {this.closePopUp}
                     storeTokensData = {this.storeTokensData}
                   />
              </Reactbootstrap.Modal.Body>
          </Reactbootstrap.Container>
      </Reactbootstrap.Modal>

    );
  }

}
export default translate(CustomReportForEditor);
