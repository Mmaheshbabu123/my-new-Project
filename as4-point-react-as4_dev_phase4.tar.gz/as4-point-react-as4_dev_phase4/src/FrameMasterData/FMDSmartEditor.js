import React,{Suspense} from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { Tabs, Tab } from 'react-bootstrap';
import Pagination from "react-js-pagination";
import { Link, BrowserRouter as Router, Route, Switch, } from 'react-router-dom'
import { datasave } from '../_services/db_services';
import './Master.css';
import FMDJobs from '../FrameMasterData/FMDJobs';
import FMDPersons from '../FrameMasterData/FMDPersons';
import FMDDefinitions from '../FrameMasterData/FMDDefinitions';
import FMDExternallinks from '../FrameMasterData/FMDExternallinks';
import FMDStandards from '../FrameMasterData/FMDStandards';
import FMDDepartments from '../FrameMasterData/FMDDepartments';
import FMDDocuments from '../FrameMasterData/FMDDocuments';
import FMDCurrentDocuments from '../FrameMasterData/FMDCurrentDocuments';
import { Draggable, Droppable } from 'react-drag-and-drop';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import Can from '../_components/CanComponent/Can';
import axios from 'axios';
import {translate} from '../language';
const CustomReportForEditor = React.lazy(() => import('./CustomReportForEditor'));

class FMDSmartEditor extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      key: 'Documents',
      openEditor: true,
      docData: [],
      docName: '',
      t:props.t
    }

  }

  render() {
const {t} =this.state;
    const Frame = [
      { 'title': 'Documents', 'eventkey': 'Documents', 'component': <FMDDocuments postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
      { 'title': 'Current Document', 'eventkey': 'CurrentDocuments', 'component': <FMDCurrentDocuments postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
      {'title' : 'Custom reports', 'eventkey' : 'webformreportelements', 'component' : <CustomReportForEditor id = {this.props.did} postmessage = {this.props.postmessage} stateObj = {this.props.stateObj}/>},
      { 'title': 'Definitions', 'eventkey': 'Definitions', 'component': <FMDDefinitions postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
      { 'title': 'Standards', 'eventkey': 'Standards', 'component': <FMDStandards postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
      { 'title': 'External link', 'eventkey': 'externallink', 'component': <FMDExternallinks postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
      { 'title': 'Persons', 'eventkey': 'Persons', 'component': <FMDPersons postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
      { 'title': 'Jobs', 'eventkey': 'Jobs', 'component': <FMDJobs postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
      { 'title': 'Departments', 'eventkey': 'Departments', 'component': <FMDDepartments postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
      ];

    return (
      <div id="fmd-wrapper" className="col-md-4 col-lg-4 px-0 py-0 cursor-pointer-event">
        <div className="">
          <div className="card">
            <div className="card-body px-0">
              <Suspense fallback={<div>Loading....</div>}>
              <Tabs id="controlled-tab-example" className="header_tabs"
                activeKey={this.state.key}
                onSelect={key => this.setState({ key })}
              >
                {Frame.map(function (item) {
                  const componentName = item.component;
                  return (
                    <Tab eventKey={item.eventkey} title={t(item.title)}  id="nameoftab" >
                      {componentName}
                    </Tab>
                  );
                })
                }
                </Tabs>
              </Suspense>
            </div>
          </div>
        </div>
      </div>
    );
  }

}
export default translate(FMDSmartEditor);
