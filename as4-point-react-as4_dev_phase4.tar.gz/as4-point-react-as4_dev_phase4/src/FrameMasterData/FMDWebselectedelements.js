import React from 'react';
import ReactDOM from 'react-dom';
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from '../store';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { translate, setLanguage, setDefaultTranslations, setDefaultLanguage, setTranslations, Language } from '../language';
import SearchInput, { createFilter } from 'react-search-input';
import './FMDWebselectedelements.css';

const KEYS_TO_FILTERS = ['name']


class FMDWebselectedelements extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      searchresult: [],
      webformid: this.props.id,
      t:props.t,
      show:false,
      namechecked:false,
      tokens: [],
      select: '',
      data: []
    }

   this.searchData = this.searchData.bind(this);
   this.Insertinto = this.Insertinto.bind(this);
  }


  componentDidMount() {
     datasave.service(window.FETCH_ALL_WEBELEMENTS + '?webform_id=' + this.props.id, 'POST').then(
              response => {
                 this.setState ({
                    searchresult : response['data'],
                    show : true,
                    data : response['data'],
                 });
              });
  }
  searchData(e) {
    var list = [...this.state.searchresult];
    list = list.filter(function (item) {
      if (item.name !== null) {
        return item.name.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
    });
    this.setState({
      data: list,
    })
  }


  Insertinto(e, name, entity_id, created_date, updated_date, elementtype ) {
        let Userdata = store.getState();
        let user_id = Userdata.UserData.user_details.user_id;
        const uuidv1 = require('uuid/v1');
        const b = uuidv1();
        const a = b.substring(0, 6);
        name = (name === null || name === undefined || name === '') ? e.target.name : name;
        const id = "$" + name + "_" + a + "$ ";
        let create_date = Math.floor(Date.now() / 1000);
        let update_date = Math.floor(Date.now() / 1000);
        let lang_id = (this.props.stateObj !== undefined && this.props.stateObj.langId !== undefined) ? this.props.stateObj.langId : window.DefaultLangId;
        let stand_id = (this.props.stateObj !== undefined && this.props.stateObj.standId !== undefined) ? this.props.stateObj.standId : window.DefaultStandId;

        // let create_date = Math.floor(new Date(created_date).getTime()/1000);
        // let update_date = Math.floor(new Date(updated_date).getTime()/1000);
        let tokens = '';
    if(e.target.checked) {
    let array = {
                  'token_name': id,
                  'entity_type_ref': 'webform',
                  'entity_type': elementtype,
                  'entity_id': entity_id,
                  'ref_id' : this.props.id,
                  'ref_type': '99',
                  'ref_token_id': '99',
                  'tuid': '$'+ a + '$',
                  'added_by': user_id,
                  'created_at': create_date,
                  'updated_at': update_date,
                  'temp_id' : this.props.tempid,
                  'lang_id': lang_id,
                  'stand_id': stand_id,
                }
       this.state.tokens.push(array);

    }
    if (!e.target.checked) {
        let index = this.state.tokens.findIndex(token => token.entity_id === entity_id);
            this.state.tokens.splice(index, 1);
    }
    this.state.tokens.map(function (t) {
          tokens += t.token + ' ';
    }, this);
    this.setState({
            final_tokens: tokens,
    });

  }

  copySelectedTokens(e) {
    var data = {
                tokenData: this.state.tokens,
               }
    let tokens = '';
    this.state.tokens.filter(function(token) {
        tokens += token.token_name ;
    });
    document.getElementById('office_frame').contentWindow.postMessage('{"MessageId":"InsertTokens","Body": "' + tokens + '"}', this.props.postmessage);
    datasave.service(window.INSERT_DOCMASTERTOKEN, 'POST', data)
        .then((response) => {
            if (response['status'] == 200) {
            } else {
            }
        })
  }

  render() {
       const { t } = this.state;
       const add = {
          textAlign: 'left'
          };
    return(
        <div>
        {this.state.show &&
        <div className='scroll-div-table-webform '>
        <div className = 'web-template'>
        <input  className="form-control search-box-border col-md-12 " placeholder={t("Search")}  onChange={this.searchData} />
          <reactbootstrap.Table striped bordered hover size="sm" style={add} >
            <tbody>
              {this.state.data.map(ele => {
                   return <tr>
                    <td><input type="checkbox" name='name' value={ele.name} onChange={(e) => this.Insertinto(e, ele.name, ele.id, ele.created_at,ele.updated_at,ele.type)} /></td>
                   <td style={{ cursor: "pointer" }} id ={'webelement'+ele.id}  >{ele.alias} ({t(ele.typename)}) </td>
                    </tr>

              })}
            </tbody>
          </reactbootstrap.Table>
         </div>
        </div>
       }
      {this.state.show &&
       <div className="copy-button">
        <reactbootstrap.Button className="btn btn-primary" onClick={(e) => this.copySelectedTokens(e)}>{t('Copy Tokens')}</reactbootstrap.Button>
     </div>
     }
    </div>
    );
  }
}
export default translate(FMDWebselectedelements);
