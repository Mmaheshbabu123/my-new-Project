import React from 'react';
import ReactDOM from 'react-dom';
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from '../store';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';

class FMDWebelements extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      t:props.t,
      data :store.getState().UserData.webform_controls,
      searchresult: store.getState().UserData.webform_controls,
    }
    this.userId = 0;
    let userData = JSON.parse(localStorage.getItem('user'));
    if(userData.user_data !== undefined) {
      this.userId = userData.user_data.user_details.person_id;
    }
   this.searchData = this.searchData.bind(this);
  }

  onDragStart = (ev, name, id) => {
    localStorage.setItem('webform-type-id', id);
    localStorage.setItem('drop_type',window.Webelement_type);
    ev.dataTransfer.setData("text", '<span></span>');
  }
  onDragEnd = (ev, name) => {
  }

  searchData(e) {
    var list = [...this.state.data];
    list = list.filter(function (item) {
      if (item.name !== null) {
        return item.name.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
    });
    this.setState({
      searchresult: list,
      // searchTerm:e.target.value,
    })
  }


  render(){
    const myData = this.state.searchresult.sort((a, b) => a.name.localeCompare(b.name)).map((item, i) => <tr>{item}</tr>);
    // let userData = store.getState();
    // const webcontrols = userData.UserData.webform_controls;
    const result = this.state.searchresult;
    var Webelements = [];
    result.forEach ((t) => {
      if (t.enable && (t.typeid !== window.ROWGENERATOR || (t.typeid === window.ROWGENERATOR && (this.userId === -999 || CanPermissions('row_generator_access_key'))))) {
        Webelements.push(
        <tr
          key = {t.typeid}
          data-id={t.typeid}
          onDragStart={(e)=>this.onDragStart(e, t.name, t.typeid)}
          onDragEnd={(e)=>this.onDragEnd(e, t.name, t.typeid)}
          draggable
          className="draggable">
          <td>
          {this.props.t(t.name)}
          </td>
        </tr>);
      }
    });
    const add = {
      textAlign: 'left'
    };
    return(
        <div className='scroll-div-table-webform'>
        <input style={{position: 'sticky',top: '0px',zindex: '999', backgroundColor: '#fff'}}  className="form-control search-box-border  col-md-12" placeholder={this.props.t("Search")}  onChange={this.searchData} />
          <reactbootstrap.Table striped bordered hover size="sm" style={add}>
            <tbody>
              {Webelements}
            </tbody>
          </reactbootstrap.Table>
        </div>
    );
  }
}
export default translate(FMDWebelements);
