import React from 'react';
import FrameMasterData from '../FrameMasterData/FrameMasterData';
import * as reactbootstrap from 'react-bootstrap';
import { Tabs, Tab } from 'react-bootstrap';
import Pagination from "react-js-pagination";
import TreeMenu from 'react-simple-tree-menu'
import renderhtml from 'react-render-html';
import FolderStructure from '../Folder/Folder';
import DocumentStructure from '../Document/Document';
import Select from 'react-select';
import { Button, Container, Form, FormGroup, Input, Label, ListGroup, ListGroupItem } from 'reactstrap';
import folderlogo from '../Blanco/folder-icon.png';
import { datasave } from '../_services/db_services';
import './Master.css';
import SearchInput, { createFilter } from 'react-search-input';
import { connect } from "react-redux";
import { persistor, store } from '../store';
import { translate, setLanguage, setDefaultTranslations, setDefaultLanguage, setTranslations, Language } from '../language';

const KEYS_TO_FILTERS = ['name']




class FMDDocuments extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchTerm: '',
      blanco_data: {},
      fields: [],
      rules: [],
      count: '',
      show: false,
      f: false,
      tokens: [],
      final_tokens: '',
      entity_id: '',
      entity_type: '',
      t:props.t,
      select:'',
    }
    this.handleClick = this.handleClick.bind(this);
    this.Insertinto = this.Insertinto.bind(this);
  }
  componentDidMount() {
    datasave.service(window.GET_Folders, "GET", '')
      .then(result => {
        this.displayFolder(result);
      });
  }

  /*
  *@param data takes the folder object which is to be created.
  * Creates an object with the childrens which is specified in data param and sets to the blanco state.
  */

  displayFolder(data) {
    let finalData = {};
    let folderData = data;
    var touched_ids = [];
    Object.keys(folderData).map(function (key) {
      folderData[key].childrens.forEach(function (id) {
        folderData[key].nodes[id] = folderData[id];
        touched_ids.push(id);
      });
      finalData[key] = folderData[key];
    });
    touched_ids.forEach(function (id) {
      delete finalData[id];
    });
    this.setState({
      blanco_data: finalData,
    })
  }

  handleClick(id, key_type, current_type) {
    if (current_type === 'manual') {
      datasave.service(window.GET_MANUAL_DETAILS + '/' + id, 'GET')
        .then((response) => {
          this.setState({
            fields: [response[0]],
            count: 1,
            show: true,
            namechecked: false,
            codechecked: false,
            entity_id: id,
            entity_type: 1,
            select:key_type,
          });
        });
    }
    else if (current_type === 'folder') {
      datasave.service(window.GET_FOLDER_DETAILS_LIST + '/' + key_type, 'GET')
        .then((response) => {
          this.setState({
            fields: [response[0]],
            count: 1,
            show: true,
            namechecked: false,
            codechecked: false,
            entity_id: key_type,
            entity_type: 2,
            select:key_type,
          });
        });
    }
    else {
      datasave.service(window.GET_DOCUMENTS_DETAILS + '/' + key_type, 'GET')
        .then((response) => {
          this.setState({
            fields: [response[0]],
            count: 2,
            show: true,
            entity_id: key_type,
            entity_type: 3,
            select:key_type,
            final_tokens:'',
            tokens:[],
          },()=>{this.setTokens()});
        });
    }
  }
  setTokens = ()=>{
    const {codechecked,namechecked,versionchecked,revision_datechecked,fields,entity_id,select,entity_type} =  this.state
    if(fields.length === 0){
      return ;
    }
    let items = {};
    fields.map(item=>  items = item);
    let eobj ={
      target:{
        value:undefined,
        checked:undefined,
        name:undefined,
      }}
      if(codechecked){
        eobj.target.name = 'code'
        eobj.target.checked = true
        eobj.target.value  = items.code
        this.Insertinto(eobj,items.code,entity_id,3,entity_type);
      }
      if(namechecked){
        eobj.target.name = 'name'
        eobj.target.checked = true
        eobj.target.value  = items.name
        this.Insertinto(eobj,items.name,entity_id,5,entity_type);
      }
      if(versionchecked){
        eobj.target.name = 'version'
        eobj.target.checked = true
        eobj.target.value  = items.version
        this.Insertinto(eobj,items.version,entity_id,4,entity_type);
      }
      if(revision_datechecked){
        eobj.target.name = 'revision_date'
        eobj.target.checked = true
        eobj.target.value  = items.revision_date
        this.Insertinto(eobj,items.revision_date,entity_id,6,entity_type);
      }
  }

  Insertinto(e, name, entity_id, token_id, entity_type, code, version, revision_date, ) {

    let Userdata = store.getState();
    let person_id = Userdata.UserData.user_details.person_id;
    const uuidv1 = require('uuid/v1');
    const z = uuidv1();
    let a = z.substring(0, 8);
    name = (name === null || name === undefined || name === '') ? e.target.name : name;
    const id = "$" + name + "_" + a + "$";
    let flag = this.state.tokens.filter((items) => (items.entity_id === entity_id && items.ref_token_id === token_id));
    let data = '';
    let final = '';
    let tokens = '';
    let create_date = Math.floor(Date.now() / 1000);
    let update_date = Math.floor(Date.now() / 1000);
    let lang_id = (this.props.stateObj !== undefined && this.props.stateObj.langId !== undefined) ? this.props.stateObj.langId : window.DefaultLangId;
    let stand_id = (this.props.stateObj !== undefined && this.props.stateObj.standId !== undefined) ? this.props.stateObj.standId : window.DefaultStandId;

    if (e.target.checked) {

      data = {
        'token_name': id,
        'entity_type_ref': 'documents',
        'entity_type': entity_type,
        'entity_id': entity_id,
        'ref_id': this.props.id,
        'ref_type': 3,
        'ref_token_id': token_id,
        'added_by': person_id,
        'token_value': e.target.value,
        'token': id,
        'tuid': '$' + a + '$ ',
        'updated_at': update_date,
        'created_at': create_date,
        'temp_id': '',
        'lang_id': lang_id,
        'stand_id': stand_id,
      }
      this.state.tokens.push(data);
    }

    if (e.target.name === 'name') {
      this.setState({ namechecked: e.target.checked });
    }
    else if (e.target.name === 'code') {
      this.setState({ codechecked: e.target.checked });
    }
    if(e.target.name === 'version'){
      this.setState({versionchecked:e.target.checked})
    }
    if(e.target.name === 'revision_date'){
      this.setState({revision_datechecked:e.target.checked})
    }
    if (!e.target.checked) {
      let index = this.state.tokens.findIndex(token => token.entity_id === entity_id && token.ref_token_id === token_id);
      this.state.tokens.splice(index, 1);
    }
    this.state.tokens.map(function (t) {
      tokens += ' '+t.token + ' ';
    }, this);
    this.setState({
      final_tokens: tokens,
    });
  }
  copySelectedTokens(e) {
    let filtered = this.state.tokens.filter(token => token.entity_id === this.state.select);
    var data = {
      tokenData: filtered,
    }
    let tokens = '';
    filtered.map(function (t) {
      tokens += ' '+t.token+' ';
    }, this);
    localStorage.setItem('framemasterdataTemplate_Token', tokens);
  if(!this.props.isExcel){
    document.getElementById('office_frame').contentWindow.postMessage('{"MessageId":"InsertTokens","Body": "' + tokens + '"}', this.props.postmessage);
  }

  datasave.service(window.INSERT_DOCMASTERTOKEN, 'POST', data)
      .then((response) => {
          if (response['status'] == 200) {
          } else {
          }
      })
  }
  render() {

    var i = -1;
    const { count, t } = this.state;
    const add = {
      textAlign: 'left'
    };
    let mfcode = 2;
    let mfname = 1;
    const DEFAULT_PADDING = 5;
    const ICON_SIZE = 8;
    const LEVEL_SPACE = 16;
    const WIDTH = '25px';
    const HEIGHT = '25px';
    const STYLE = { color: 'blue' };
    const DISPLAY = 'inline-flex';
    const WIDTH_DYNAMIC = 15;
    const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }}>{on ? '-' : '+'}</span>;
    const logo = renderhtml('<img  src=' + folderlogo + ' alt="Logo" style="width:5%" />');
    const ListItem = ({
      level = 0,
      key,
      doc_type,
      status,
      rights,
      owner,
      hasNodes,
      isOpen,
      type_id,
      current_type,
      manual_id,
      label,
      searchTerm,
      openNodes,
      version,
      ...props
    }) => (
        < div className="folder-manual-section">
          <ListGroupItem
            {...props}
            style={{
              paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
              cursor: 'pointer',
            }}
            key={key}
          >
          <div className="list-items-structure" style = {{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
            {hasNodes && <ToggleIcon on={isOpen} />}
            {!hasNodes && <span style={{ marginRight: 8 }}> &nbsp;</span>}
            {current_type === 'manual' &&
                <i class="folder-icons folder-icons-accounts" title={t("Manual")}  style={{ marginRight: '5px' }}> </i>
            }
            {current_type === 'folder' &&
                <i class="folder-icons folder-icons-folder" title={t("Folder")}  style={{ marginRight: '5px' }}> </i>
            }
            {current_type === 'document' &&
                <i class={'folder-icons folder-icons-' + doc_type} title={doc_type} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id)} />
            }
            {current_type === 'document' &&
                <i class={'sprite-document2 sprite-document2-' + status} title={status} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} onClick={() => this.actionEdit(props.key_type, current_type, "view", type_id, manual_id)} />
            }
            <span title={label} className='folderstructure-label'>
                {label}
            </span>
            {current_type === 'document' &&
             <span className="version-wrapper">
                V-{version}
              </span>
            }
          </div>
          </ListGroupItem>
        </div >
      );
    return (
      <div className="container-fluid">
        <div className="row scroll-div-table">
          <div className="col-lg-12 fix-overflow-docs">
            <TreeMenu
              data={this.state.blanco_data}
              hasSearch='false'
              onClickItem={({ key, label, manual_id, key_type, current_type }) => {
                this.handleClick(manual_id, key_type, current_type)
              }}
              debounceTime={125}>
              {({ search, items }) => (
                <>
                  <Input onChange={e => search(e.target.value)} placeholder={t("Search")} />
                  <ListGroup>
                    {items.map((props, key) => (
                      <div key={key}>
                        <ListItem {...props} />
                      </div>
                    ))}
                  </ListGroup>
                </>
              )}
            </TreeMenu>
          </div>
        </div>
<div className="copytofile">
        {this.state.show &&
          <div>
            {this.state.fields.map((field) => {
              if (count === 1) {
                if (this.state.entity_type === 1) {
                  mfcode = 48;
                  mfname = 47;
                }
                else if (this.state.entity_type === 2) {
                  mfcode = 2;
                  mfname = 1;
                }
                return (
                  <reactbootstrap.Table striped bordered hover size="sm" style={add}>
                    <tbody>
                      <tr>
                        <td><input type="checkbox" name='code' value={field.code} onChange={(e) => this.Insertinto(e, field.code, this.state.entity_id, mfcode, this.state.entity_type)} checked={this.state.codechecked} /></td>
                        <th>{t('Code')}</th>
                        <td >{field.code}</td>
                      </tr>
                      <tr>
                        <td><input type="checkbox" name='name' value={field.name} onChange={(e) => this.Insertinto(e, field.name, this.state.entity_id, mfname, this.state.entity_type)} checked={this.state.namechecked} /></td>
                        <th>{t('Name')}</th>
                        <td>{field.name}</td>
                      </tr>
                    </tbody>
                  </reactbootstrap.Table>
                );
              }
              else {
                return (
                  <reactbootstrap.Table striped bordered hover size="sm" style={add}>
                    <tbody>
                      <tr>
                        <td><input type="checkbox" name='code' value={field.code} onChange={(e) => this.Insertinto(e, field.code, this.state.entity_id, 3, this.state.entity_type)} /></td>
                        <th>{t('Code')}</th>
                        <td >{field.code}</td>
                      </tr>
                      <tr>
                        <td><input type="checkbox" name='name' value={field.name} onChange={(e) => this.Insertinto(e, field.name, this.state.entity_id, 5, this.state.entity_type)} /></td>
                        <th>{t('Name')}</th>
                        <td >{field.name}</td>
                      </tr>
                      <tr>
                        <td><input type="checkbox" name='version' value={field.version} onChange={(e) => this.Insertinto(e, field.version, this.state.entity_id, 4, this.state.entity_type)} /></td>
                        <th>{t('Version')}</th>
                        <td >{field.version}</td>
                      </tr>
                      <tr>
                        <td><input type="checkbox" name='revision_date' value={field.revision_date} onChange={(e) => this.Insertinto(e, field.revision_date, this.state.entity_id, 6, this.state.entity_type)} /></td>
                        <th>{t('Revision date')}</th>
                        <td >{field.revision_date}</td>
                      </tr>
                    </tbody>
                  </reactbootstrap.Table>
                );
              }
            })
            }
          </div>
        }
        </div>
        {this.state.show &&
        <div className="copy-button">
          <reactbootstrap.Button className="btn btn-primary button-wrap" onClick={(e) => this.copySelectedTokens(e)}>{t('Copy Tokens')}</reactbootstrap.Button>
        </div>
      }

      </div >
    );
  }

}
export default translate(FMDDocuments);
