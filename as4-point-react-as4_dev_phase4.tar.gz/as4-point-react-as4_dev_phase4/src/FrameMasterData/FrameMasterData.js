import React, {Suspense} from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { Tabs, Tab } from 'react-bootstrap';
import Pagination from "react-js-pagination";
import { Link, BrowserRouter as Router, Route, Switch, } from 'react-router-dom'
import { datasave } from '../_services/db_services';
import './Master.css';
import FMDJobs from '../FrameMasterData/FMDJobs';
import FMDPersons from '../FrameMasterData/FMDPersons';
import FMDDefinitions from '../FrameMasterData/FMDDefinitions';
import FMDExternallinks from '../FrameMasterData/FMDExternallinks';
import FMDStandards from '../FrameMasterData/FMDStandards';
import FMDDepartments from '../FrameMasterData/FMDDepartments';
import FMDDocuments from '../FrameMasterData/FMDDocuments';
import FMDCurrentDocumentsLayout from '../FrameMasterData/FMDCurrentDocumentsLayout';
import { Draggable, Droppable } from 'react-drag-and-drop';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import Can from '../_components/CanComponent/Can';
import axios from 'axios';
import {translate} from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from '../store';
import OpenTemplateForExcel from './OpenTemplateForExcel'
const CustomReportForEditor = React.lazy(() => import('./CustomReportForEditor'));

class FrameMasterData extends React.Component {
  constructor(props) {
    const urlParams = new URLSearchParams(window.location.search);
    super(props)
    this.state = {
      key: 'Documents',
      openEditor: true,
      docData: [],
      docName: '',
      t:props.t,
      insertmasterdata: true,
      leftArea    : '',
      centerArea  : '',
      rightArea   : '',
      logo        : '',
      doc_type    : 2, //open template for excel
      template_id :  urlParams.get('tid'),
    }
  }
  componentDidMount() {
    const urlParams = new URLSearchParams(window.location.search);
    const tid = urlParams.get('tid');
    let isExcel = urlParams.get('openfor') === 'excel' ? 1 : 0;
    if(isExcel){
      this.getTemplateTokenData(tid);
    }
  }
  closeDocEditor(e) {
    this.setState({
      openEditor: false,
    });

    this.props.history.push("/manuals/layouts?q=template");
  }
  HTMLPreview(e) {
    const urlParams = new URLSearchParams(window.location.search);
    const myParam = atob(urlParams.get('id'));
    const tid = urlParams.get('tid');
    document.getElementById("loding-icon").setAttribute("style", "display:block;");
    //axios.get('http://as4.ruby.local:3000/api/v1/doc_converters?tid='+tid+'&backend=' + process.env.REACT_APP_serverURL + '&contentdoc=' + btoa(myParam))
    axios.get(process.env.REACT_APP_RUBY_URL+'/api/v1/doc_converters?tid='+tid+'&backend=' + process.env.REACT_APP_serverURL + '&contentdoc=' + btoa(myParam))
      .then(function (response) {
        document.getElementById("loding-icon").setAttribute("style", "display:none;");
        if(response.data.status !== "500") {
          window.open(window.location.origin + '/previewrevision/' + tid + '?content=' + response.data.message, '_blank');
        }
        else {
          OCAlert.alertError(response.data.message, { timeOut: window.TIMEOUTNOTIFICATION1});

          // alert(response.data.message);
        }
      })
  }
  addmasterdata(e) {
    document.getElementById('editor-frame-wrapper').setAttribute("class", "col-md-8 col-lg-8 px-0 editor");
    document.getElementById('fmd-wrapper').setAttribute("style", "display:block;");
    document.getElementById('office_frame').setAttribute("style", "margin-left:-181px");
    this.setState({ insertmasterdata: false });
  }

  closemasterdata(e) {
    document.getElementById('editor-frame-wrapper').setAttribute("class", "col-md-12 col-lg-12 px-0 editor");
    document.getElementById('fmd-wrapper').setAttribute("style", "display:none;");
    document.getElementById('office_frame').setAttribute("style", "margin-left:-224px");
    this.setState({ insertmasterdata: true });
  }
 min_max(e){
 }
  render() {
    const urlParams = new URLSearchParams(window.location.search);
    const myParam = urlParams.get('tid');
    let isExcel = urlParams.get('openfor') === 'excel' ? 1 : 0;
    const {t} = this.state;
    const Frame = [
      { 'title': 'Documents', 'eventkey': 'Documents', 'component': <FMDDocuments postmessage = {process.env.REACT_APP_baseURL_office} id={myParam} stateObj = {this.props.stateObj} isExcel={isExcel} /> },
      { 'title': 'Current document', 'eventkey': 'CurrentDocuments', 'component': <FMDCurrentDocumentsLayout postmessage = {process.env.REACT_APP_baseURL_office} id={myParam} stateObj = {this.props.stateObj} isExcel={isExcel} /> },
      { 'title': 'Definitions', 'eventkey': 'Definitions', 'component': <FMDDefinitions postmessage = {process.env.REACT_APP_baseURL_office} id={myParam} stateObj = {this.props.stateObj} isExcel={isExcel}/> },
      { 'title': 'Standards', 'eventkey': 'Standards', 'component': <FMDStandards postmessage = {process.env.REACT_APP_baseURL_office} id={myParam} stateObj = {this.props.stateObj} isExcel={isExcel}/> },
      { 'title': 'External link', 'eventkey': 'externallink', 'component': <FMDExternallinks postmessage = {process.env.REACT_APP_baseURL_office} id={myParam} stateObj = {this.props.stateObj} isExcel={isExcel}/> },
      { 'title': 'Persons', 'eventkey': 'Persons', 'component': <FMDPersons postmessage = {process.env.REACT_APP_baseURL_office} id={myParam} stateObj = {this.props.stateObj} isExcel={isExcel}/> },
      { 'title': 'Jobs', 'eventkey': 'Jobs', 'component': <FMDJobs postmessage = {process.env.REACT_APP_baseURL_office} id={myParam} stateObj = {this.props.stateObj} /> },
      { 'title': 'Departments', 'eventkey': 'Departments', 'component': <FMDDepartments postmessage = {process.env.REACT_APP_baseURL_office} id={myParam} stateObj = {this.props.stateObj} isExcel={isExcel} /> },
      ];

    return (
      <div className='container-fluid'>
        <div id="fmd-wrapper-layout" style={{ position: 'initial !important' }} className="row ml-5 py-3 pl-1 smart-editor">
          <div className="preview-button">
            <reactbootstrap.Button className="btn" onClick={(e) => this.closeDocEditor(e)}>{t('Close')}</reactbootstrap.Button>
            {isExcel !== 0 && <reactbootstrap.Button className="btn" onClick={() => this.saveTemplatesData()}>{t('Save')}</reactbootstrap.Button>}
            <reactbootstrap.Button className="btn" onClick={(e) => this.HTMLPreview(e)}>{t('HTML Preview')}</reactbootstrap.Button>
            {this.state.insertmasterdata && <reactbootstrap.Button className="btn" onClick={(e) => this.addmasterdata(e)}>{t('Insert masterdata')}</reactbootstrap.Button>}
            {!this.state.insertmasterdata && <reactbootstrap.Button className="btn" onClick={(e) => this.closemasterdata(e)}>{t('Minimize masterdata')}</reactbootstrap.Button>}
          </div>
          <div className='col-md-12 d-flex'>
            <div id="editor-frame-wrapper" className="col-md-12 col-lg-12 editor px-0">
              <div className="card">
                {isExcel !== 1 ? <div className="card-body pr-0">
                  {this.state.openEditor && <DocEditor />}
                </div> :
                <div className="card-body pr-0">
                    <div id='office_frame'>
                        <OpenTemplateForExcel leftArea = {this.state.leftArea}
                           centerArea = {this.state.centerArea} file_name = {this.state.file_name}
                           rightArea = {this.state.rightArea} handleLeftArea = {this.handleLeftArea.bind(this)}
                           handleEditorChange={this.handleEditorChange.bind(this)}/>
                    </div>
                </div>}
              </div>
            </div>
            <div id="fmd-wrapper" className="col-md-4 col-lg-4 px-0 py-0 cursor-pointer-event" style={{ overflowX: 'auto', overflowY: 'auto', height: "800px", scrollBarWidth: 'thin' }}>
              <div className="card">
                <div className="card-body px-0">
                  <Suspense fallback={<div>{t("Loading....")}</div>}>
                    <Tabs id="controlled-tab-example" className="header_tabs" style={{ width: '100%' }}
                      activeKey={this.state.key}
                      onSelect={key => this.setState({ key })}
                    >
                      {Frame.map(function (item) {
                        const componentName = item.component;
                        return (
                          <Tab eventKey={item.eventkey} title={t(item.title)} id="nameoftab" >
                            {componentName}
                          </Tab>
                        );
                      })
                      }
                    </Tabs>
                  </Suspense>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  getTemplateTokenData(template_id){
    datasave.service(window.GET_TEMPLATES_TOKEN_DATA + '/' + template_id, 'GET')
    .then(result =>{
      if(result.status === 200){
        let response = result.data;
        let fileData = response.file_details
        this.setState({
          leftArea   : response.left_area   !== undefined ? response.left_area   : '',
          centerArea : response.center_area !== undefined ? response.center_area : '',
          rightArea  : response.right_area  !== undefined ? response.right_area  : '',
          file_name  : fileData.file_name   !== undefined ? fileData.file_name   : '',
        })
      }
    })
  }

  saveTemplatesData(){
    datasave.service(window.SAVE_TEMPLATES_TOKEN_DATA, 'POST', this.state).
      then(response =>{
        console.log(response);
      })
  }
  handleEditorChange = (key, value) => {
      this.setState({ [key] : value });
  }
  handleLeftArea = (file_id, name) => {
    this.setState({ leftArea : file_id, file_name : name })
  }
}
class DocEditor extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    const urlParams = new URLSearchParams(window.location.search);
    const myParam = atob(urlParams.get('id'));
    const hashcode = process.env.REACT_APP_baseURL_office_hashcode;
    const loleaflet_src = process.env.REACT_APP_baseURL_office  + "/loleaflet/" + hashcode + "/loleaflet.html";
    //const loleaflet_src = "http://office-frontend.local:9980/loleaflet/305832f/loleaflet.html";
    let WOPI_src_url = window.backendURL;
    const access_token = "aFPBvqgQZ6g0dnDUKHcSRn5HZhCHJugm";
    const type = urlParams.get('type')
    const title = myParam + '$' + type + '^Dutch';
    let Userdata = store.getState();
    let person_id = Userdata.UserData.user_details.person_id;
    let person_name = Userdata.UserData.user_details.user_name;
    const WOPISrc = WOPI_src_url+"/api/wopi/files/" + title + '/Dutch/general/0/' + person_id + '/' + person_name;
    const iframeSource = loleaflet_src + "?access_token=" + access_token + "&WOPISrc=" + WOPISrc + "&title=" + title + "&lang=en&closebutton=1&revisionhistory=1&doc_type=1";
    return (
      <iframe id="office_frame" width="100%" height="800px" name="office_form" src={iframeSource}></iframe>
    );
  }
}
export default translate(FrameMasterData);
