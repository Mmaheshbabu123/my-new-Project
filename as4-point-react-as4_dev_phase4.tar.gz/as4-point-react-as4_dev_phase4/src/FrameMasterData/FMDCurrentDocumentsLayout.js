import React from 'react';
import FrameMasterData from '../FrameMasterData/FrameMasterData';
import * as reactbootstrap from 'react-bootstrap';
import { Tabs, Tab } from 'react-bootstrap';
import {Input} from 'reactstrap';
import Pagination from 'react-bootstrap/Pagination';
import { datasave } from '../_services/db_services';
import './Master.css';
import { connect } from "react-redux";
import { persistor, store } from '../store';
import { translate, setLanguage, setDefaultTranslations, setDefaultLanguage, setTranslations, Language } from '../language';
const TableData=[
  {name:'code',title:'Code',token_id:3,entity_type:3},
  {name:'name',title:'Name',token_id:5,entity_type:3},
  {name:'version',title:'Version',token_id:4,entity_type:3},
  {name:'revision_date',title:'Revision date',token_id:6,entity_type:3},
  {name:'f_code',title:'Folder code',token_id:2,entity_type:2},
  {name:'f_name',title:'Folder name',token_id:1,entity_type:2},
  {name:'review_date',title:'Review date',token_id:14,entity_type:3},
  {name:'reason_of_change',title:'Reason of change',token_id:15,entity_type:3},
  {name:'pre_version',title:'Previous version',token_id:16,entity_type:3},
  {name:'l_name',title:'Layout name',token_id:9,entity_type:3},
  {name:'verified_by',title:'Verified by',token_id:39,entity_type:3},
  {name:'verification_date',title:'Verification date',token_id:41,entity_type:3},
  {name:'authorised_by',title:'Authorised by',token_id:40,entity_type:3},
  {name:'activation_date',title:'Activation date',token_id:43,entity_type:3},
  {name:'revised_by',title:'Revised by',token_id:44,entity_type:3},
  {name:'document_owners',title:'Document owners',token_id:50,entity_type:3},
  {name:'status',title:'Status',token_id:17,entity_type:3},
  {name:'DOS',title:'Ondocument standards',token_id:10,entity_type:3},
  {name:'DOJ',title:'Document owners job',token_id:46,entity_type:3},
  {name:'DOP',title:'Document owners person',token_id:45,entity_type:3},
];

class FMDCurrentDocuments extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: [],
            name: '',
            abbrevation: '',
            rules: [],
            pnames: [],
            jnames: [],
            snames: [],
            searchTerm: '',
            keys: [],
            show: false,
            active: 1,
            page: 5,
            selected_class: 'inactive',
            tokens: [],
            final_tokens: '',
            entity_id: '',
            t:props.t,
            select:'',
            currentDocumentsData:[],
        }
        this.Insertinto = this.Insertinto.bind(this);
    }

    componentDidMount() {
        if (this.props.id) {
          const pageData = this.getPageData(1, TableData);
          const count = this.getCountPage(TableData);
            this.setState({ entity_id: this.props.id ,currentDocumentsData:pageData,count:count,items:TableData});
        }
    }
    Insertinto(e, name, entity_id, token_id, entity_type = 3) {
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        const uuidv1 = require('uuid/v1');
        const b = uuidv1();
        const a = b.substring(0, 8)
        const id = "$" + e.target.name + "_" + a + "$";
        let flag = this.state.tokens.filter((items) => (items.token_value === e.target.value));
        let data = '';
        let final = '';
        let tokens = '';
        let create_date = Math.floor(Date.now() / 1000);
        let update_date = Math.floor(Date.now() / 1000);
        let lang_id = (this.props.stateObj !== undefined && this.props.stateObj.langId !== undefined) ? this.props.stateObj.langId : window.DefaultLangId;
        let stand_id = (this.props.stateObj !== undefined && this.props.stateObj.standId !== undefined) ? this.props.stateObj.standId : window.DefaultStandId;

        if (flag.length < 1 && e.target.checked) {
            // data = {
            //     'token_value': e.target.value,
            //     'token': id,
            //     'doc_id': this.props.id
            // }
            data = {
                'token_name': id,
                'entity_type_ref': 'documents-layout',
                'entity_type': entity_type,
                'entity_id': entity_id,
                'ref_id': this.props.id,
                'ref_type': 3,
                'ref_token_id': token_id,
                'added_by': person_id,
                'token_value': e.target.value,
                'token': id,
                'tuid': '$' + a + '$ ',
                'updated_at': update_date,
                'created_at': create_date,
                'temp_id': '',
                'lang_id': lang_id,
                'stand_id': stand_id,
            }
            this.state.tokens.push(data);
        }
        if (!e.target.checked) {
            let index = this.state.tokens.findIndex(token => token.token_value === e.target.value);
            this.state.tokens.splice(index, 1);
        }
        this.state.tokens.map(function (t) {
            tokens += ' '+t.token + ' ';
        }, this);
        this.setState({
            final_tokens: tokens,
        });
    }
    copySelectedTokens(e) {
    var data = {
      tokenData: this.state.tokens
    }
    localStorage.setItem('framemasterdataTemplate_Token', this.state.final_tokens);
    if(!this.props.isExcel){
      document.getElementById('office_frame').contentWindow.postMessage('{"MessageId":"InsertTokens","Body": "' + this.state.final_tokens + '"}', this.props.postmessage);
    }
    datasave.service(window.INSERT_DOCMASTERTOKEN, 'POST', data)
        .then((response) => {
            if (response['status'] == 200) {
            } else {
            }
        })
    }

    searchData=(e)=>{
      let list = TableData.filter(function (item) {
        if (item.title !== null) {
          return item.title.toLowerCase().search(
            e.target.value.toLowerCase()) !== -1;
        }
      });
      const page_data = this.getPageData(1, list);
      const count = this.getCountPage(list);
      this.setState({
        currentDocumentsData: page_data,
        count: count,
        active: 1,
        searchTerm: e.target.value,
      });
    }
    changePage(e, id = 1) {
      const page_data = this.getPageData(id, TableData);
      this.setState({
        currentDocumentsData: page_data,
        active: id,
      });
    }
    getPageData(id, list = '') {
      const page = this.state.page;
      const items = (list !== '') ? list : this.state.fields;
      return items.slice(page * (id - 1), page * id);
    }
    getCountPage(items) {
      const itemLength = items.length;
      return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }
    render() {
        const {t,searchTerm,active,count,currentDocumentsData} = this.state;
        let pages = [];
        if (count > 0) {
          for (let number = 1; number <= count; number++) {
            pages.push(
              <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                {number}
              </Pagination.Item>,
            );
          }
        }
        return (
            <div className='scroll-div-table1'>
                     <Input value={searchTerm}  onChange={(e) => this.searchData(e)} placeholder={t("Search")} />
                        <reactbootstrap.Table striped bordered hover size="sm" style={{textAlign: 'left'}} >
                            <tbody>
                            {currentDocumentsData.map(item=>{
                                return  (<tr>
                                  <td className="checkbox-td"><input type="checkbox" name={item.name} value={item.name} onChange={(e) => this.Insertinto(e, '', this.state.entity_id,item.token_id,item.entity_type)}/></td>
                                  <th>{item.title}</th>
                                  <td>?</td>
                                  </tr>)
                            })}
                            </tbody>
                        </reactbootstrap.Table>
                    <div className="copy-button">
                    <reactbootstrap.Button className="btn btn-primary" onClick={(e) => this.copySelectedTokens(e)}>{t('Copy Tokens')}</reactbootstrap.Button>
                    </div>
                    <Pagination  size="md">{pages}</Pagination>
            </div>
        );
    }
}
export default translate(FMDCurrentDocuments);
