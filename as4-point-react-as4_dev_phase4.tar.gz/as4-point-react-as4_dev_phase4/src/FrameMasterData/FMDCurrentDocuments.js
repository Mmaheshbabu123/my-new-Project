import React from 'react';
import FrameMasterData from '../FrameMasterData/FrameMasterData';
import * as reactbootstrap from 'react-bootstrap';
import { Tabs, Tab } from 'react-bootstrap';
import Pagination from 'react-bootstrap/Pagination';
import { datasave } from '../_services/db_services';
import {Input} from 'reactstrap';
import {SearchFilter }from '../SearchFilter';
import './Master.css';
import { connect } from "react-redux";
import { persistor, store } from '../store';
import { translate, setLanguage, setDefaultTranslations, setDefaultLanguage, setTranslations, Language } from '../language';

class FMDCurrentDocuments extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: [],
            name: '',
            abbrevation: '',
            rules: [],
            pnames: [],
            jnames: [],
            snames: [],
            searchTerm: '',
            keys: [],
            show: false,
            active: 1,
            page: 5,
            selected_class: 'inactive',
            tokens: [],
            final_tokens: '',
            entity_id: '',
            t:props.t,
            select:'',
            currentRules:[],
            filtedRule:[],
        }
        this.Insertinto = this.Insertinto.bind(this);
    }

    async componentDidMount() {
        if (this.props.id) {
            await this.didMountState(this.props.id);
        }

    }

    async didMountState(id){
        datasave.service(window.GET_CD_DETAILS + '/' + id, "GET")
            .then(async result => {
              let tableData = await this.setTableData(result);
              let pageData = await SearchFilter.getPageData(1,this.state.page,tableData,tableData);
              this.setState({
                  rules: tableData,
                  currentRules:pageData,
                  filtedRule:tableData,
                  count:await SearchFilter.getCountPage(tableData,this.state.page),
                  show: true,
                  entity_id: id,
                  select:id,
                  searchTerm:''
              });
        });
    }
setTableData=(data)=>{
  return[
      {name:'code',title:'Code',token_id:3,entity_type:3,details:data[0].code},
      {name:'name',title:'Name',token_id:5,entity_type:3,details:data[0].name},
      {name:'version',title:'Version',token_id:4,entity_type:3,details:data[0].version},
      {name:'revision_date',title:'Revision date',token_id:6,entity_type:3,details:data[0].revision_date},
      {name:'f_code',title:'Folder code',token_id:2,entity_type:2,details:data[0].f_code},
      {name:'f_name',title:'Folder name',token_id:1,entity_type:2,details:data[0].f_name},
      {name:'review_date',title:'Review date',token_id:14,entity_type:3,details:data[0].review_date},
      {name:'reason_of_change',title:'Reason of change',token_id:15,entity_type:3,details:data[0].reason_of_change},
      {name:'pre_version',title:'Previous version',token_id:16,entity_type:3,details:data[0].pre_version},
      {name:'l_name',title:'Layout name',token_id:9,entity_type:3,details:data[0].l_name},
      {name:'verified_by',title:'Verified by',token_id:39,entity_type:3,details:data[0].verified_by},
      {name:'verification_date',title:'Verification date',token_id:41,entity_type:3,details:data[0].verification_date},
      {name:'authorised_by',title:'Authorised by',token_id:40,entity_type:3,details:data[0].authorised_by},
      {name:'activation_date',title:'Activation date',token_id:43,entity_type:3,details:data[0].activation_date},
      {name:'revised_by',title:'Revised by',token_id:44,entity_type:3,details:data[0].revised_by},
      {name:'document_owners',title:'Document owners',token_id:50,entity_type:3,details:data[0].document_owners},
      {name:'status',title:'Status',token_id:17,entity_type:3,details:'New'},
      {name:'DOS',title:'Ondocument standards',token_id:10,entity_type:3,details:data.snames?data.snames.join():' '},
      {name:'DOJ',title:'Document owners job',token_id:46,entity_type:3,details:data.jnames?data.jnames.join():' '},
      {name:'DOP',title:'Document owners person',token_id:45,entity_type:3,details:data.pnames?data.pnames.join():' '},
    ];
}
    Insertinto(e, name, entity_id, token_id, entity_type = 3) {
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id;
        const uuidv1 = require('uuid/v1');
        const b = uuidv1();
        const a = b.substring(0, 8);
        name = (name === null || name === undefined || name === '') ? e.target.name : name;
        const id = "$" + name + "_" + a + "$ ";
        let flag = this.state.tokens.filter((items) => (items.entity_id === entity_id && items.ref_token_id === token_id));
        let data = '';
        let final = '';
        let tokens = '';
        let create_date = Math.floor(Date.now() / 1000);
        let update_date = Math.floor(Date.now() / 1000);
        let lang_id = (this.props.stateObj !== undefined && this.props.stateObj.langId !== undefined) ? this.props.stateObj.langId : window.DefaultLangId;
        let stand_id = (this.props.stateObj !== undefined && this.props.stateObj.standId !== undefined) ? this.props.stateObj.standId : window.DefaultStandId;
        if (e.target.checked) {
            // data = {
            //     'token_value': e.target.value,
            //     'token': id,
            //     'doc_id': this.props.id
            // }
            data = {
                'token_name': id,
                'entity_type_ref': 'documents',
                'entity_type': entity_type,
                'entity_id': entity_id,
                'ref_id': this.props.id,
                'ref_type': 3,
                'ref_token_id': token_id,
                'added_by': person_id,
                'token_value': e.target.value,
                'token': id,
                'tuid': '$' + a + '$',
                'updated_at': update_date,
                'created_at': create_date,
                'temp_id': '',
                'lang_id': lang_id,
                'stand_id': stand_id,
            }
            this.state.tokens.push(data);
        }
        if (!e.target.checked) {
            let index = this.state.tokens.findIndex(token => token.entity_id === entity_id && token.ref_token_id === token_id);
            this.state.tokens.splice(index, 1);
        }
        this.state.tokens.map(function (t) {
            tokens += ' '+t.token + ' ';
        }, this);
        this.setState({
            final_tokens: tokens,
        });
    }
    copySelectedTokens(e) {
      let filtered = this.state.tokens.filter(token => token.entity_id === this.state.select);
      var data = {
        tokenData: filtered,
      }
      let tokens = '';
      filtered.map(function (t) {
        tokens += t.token;
      }, this);
    document.getElementById('office_frame').contentWindow.postMessage('{"MessageId":"InsertTokens","Body": "' + tokens + '"}', this.props.postmessage);
    datasave.service(window.INSERT_DOCMASTERTOKEN, 'POST', data)
        .then((response) => {
            if (response['status'] == 200) {
            } else {
            }
        })
    }
    changePage(e, id = 1) {
      this.setState({
        currentRules: SearchFilter.getPageData(id,this.state.page,(this.state.searchTerm !== '') ? this.state.filtedRule : '',this.state.rules),
        active: id,
      });
    }
    searchData=(e)=>{
      let res ='';
    let  list = this.state.rules.filter((item)=> {
        if (item.title) {
          res = item.title.toLowerCase().search(
            e.target.value.toLowerCase()) !== -1;
          }
          if(res){
            return res;
          }
          else{
            if (item.details) {
              res = item.details.toLowerCase().search(
                e.target.value.toLowerCase()) !== -1;
              }
              if(res){
                return res;
              }
            }
          }
        );
        let pageData =  SearchFilter.getPageData(1,this.state.page,list,this.state.rules);
      this.setState({
        currentRules: pageData,
        count:  SearchFilter.getCountPage(list,this.state.page),
        active: 1,
        searchTerm: e.target.value,
        filtedRule:list,
      });
    }
    render() {
        const {t,currentRules,searchTerm,count,active} = this.state;
        let pages = [];
        if (count > 0) {
          for (let number = 1; number <= count; number++) {
            pages.push(
              <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                {number}
              </Pagination.Item>,
            );
          }
        }
        return (
        <div className='fix-overflow-docs'>
                     <Input value={searchTerm}  className="search-input" onChange={(e) => this.searchData(e)} placeholder={t("Search")} />
                        <reactbootstrap.Table striped bordered hover size="sm" style={{textAlign: 'left'}} >
                            <tbody>
                            {currentRules.length>0 && currentRules.map(item=>{
                                return  (<tr>
                                  <td className="checkbox-td"><input type="checkbox" name={item.name} value={item.name} onChange={(e) => this.Insertinto(e, item.name, this.state.entity_id,item.token_id,item.entity_type)}/></td>
                                  <th>{item.title}</th>
                                  <td>{item.details}</td>
                                  </tr>)
                            })}
                            </tbody>
                        </reactbootstrap.Table>
                    <div className="copy-button">
                    <reactbootstrap.Button className="btn btn-primary" onClick={(e) => this.copySelectedTokens(e)}>{t('Copy Tokens')}</reactbootstrap.Button>
                    </div>
                    <Pagination  size="md">{pages}</Pagination>
            </div>
          );
    }
  }
export default translate(FMDCurrentDocuments);
