import React ,{Suspense} from 'react';
import { Tabs, Tab } from 'react-bootstrap';
import { BrowserRouter as Router } from 'react-router-dom'
import './Master.css';
import FMDWebelements from '../FrameMasterData/FMDWebelements';
import FMDWebselectedelements from '../FrameMasterData/FMDWebselectedelements';
import { Draggable } from 'react-drag-and-drop';
import { translate } from '../language';
const CustomReportForEditor = React.lazy(() => import('./CustomReportForEditor'));



class FMDWebformEditor extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      key: 'webformcontrols',
      openEditor: true,
      docData: [],
      docName: '',
      t:props.t
    }

  }
componentDidMount(){
  if(this.props.flow!==undefined && this.props.flow==='webformelements'){
    this.setState({key:'webformcontrolelements'})
  }
}

  render() {
    const Frame = [
      ...(this.props.did !== -1 ? [
      /*  { 'title': 'Jobs', 'eventkey': 'jobs', 'component': <FMDJobs postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
        { 'title': 'Persons', 'eventkey': 'persons', 'component': <FMDPersons postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
        { 'title': 'External link', 'eventkey': 'externallink', 'component': <FMDExternallinks postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
        { 'title': 'Documents', 'eventkey': 'Documents', 'component': <FMDDocuments postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
        { 'title': 'Departments', 'eventkey': 'Departments', 'component': <FMDDepartments postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
        { 'title': 'Standards', 'eventkey': 'Standards', 'component': <FMDStandards postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
        { 'title': 'Definitions', 'eventkey': 'Definitions', 'component': <FMDDefinitions postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },
        { 'title': 'Current Document', 'eventkey': 'CurrentDocuments', 'component': <FMDCurrentDocuments postmessage = {this.props.postmessage} id = {this.props.did} stateObj = {this.props.stateObj} /> },  */
        {'title' : 'Webform controls', 'eventkey' : 'webformcontrols', 'component' : <FMDWebelements id = {this.props.did} postmessage = {this.props.postmessage} stateObj = {this.props.stateObj} />},
        {'title' : 'Webform saved elements', 'eventkey' : 'webformcontrolelements', 'component' : <FMDWebselectedelements id = {this.props.did} tempid = {this.props.tempid} postmessage = {this.props.postmessage} stateObj = {this.props.stateObj}/>}
      ] : [{'title' : 'Webform reports', 'eventkey' : 'webformreportelements', 'component' : <CustomReportForEditor id = {this.props.did} postmessage = {this.props.postmessage} stateObj = {this.props.stateObj}/>}]
     )
    ];
    const {t}=this.state;
    return (
      <div id="fmd-wrapper" className="webform-sticky col-md-2 col-lg-2 px-0 py-0 cursor-pointer-event">
        <div className="">
          <div className="card">
            <div className="card-body px-0 sticky-div">
            <Suspense fallback={<div>{t("Loading....")}</div>}>
              <Tabs id="controlled-tab-example" className="header_tabs"
                activeKey={this.props.did !==-1 ? this.state.key : 'webformreportelements'}
                onSelect={key => this.setState({ key })}
              >
                {Frame.map(function (item) {
                  const componentName = item.component;
                 if ((this.props.flow === 'webformelements' && item.eventkey === 'webformcontrolelements')||(this.props.flow === "webform" && item.eventkey === 'webformcontrols')) {
                      return (
                        <Tab key={item.eventkey} eventKey={item.eventkey} title={t(item.title)} id="nameoftab"
                         >
                          {componentName}
                        </Tab>
                      );
                    }
                 else if (item.eventkey !== 'webformcontrols' && item.eventkey !== 'webformcontrolelements') {
                    return (
                      <Tab style={{width: '100% !important'}} key={item.eventkey} eventKey={item.eventkey} title={t(item.title)} id="nameoftab" >
                        {componentName}
                      </Tab>
                    );
                  }
                }, this)
                }
              </Tabs >
              </Suspense >
            </div>
          </div>
        </div>
      </div>
    );
  }

}
export default translate(FMDWebformEditor);
