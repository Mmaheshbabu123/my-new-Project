import React from 'react';
import FrameMasterData from '../FrameMasterData/FrameMasterData';
import * as reactbootstrap from 'react-bootstrap';
import { Tabs, Tab } from 'react-bootstrap';
import Pagination from 'react-bootstrap/Pagination';
import { Draggable, Droppable } from 'react-drag-and-drop'
import { datasave } from '../_services/db_services';
import './Master.css';
import SearchInput, { createFilter } from 'react-search-input';
import { connect } from "react-redux";
import { persistor, store } from '../store';
import { translate, setLanguage, setDefaultTranslations, setDefaultLanguage, setTranslations, Language } from '../language';

const KEYS_TO_FILTERS = ['name']



class FMDStandards extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fields: [],
      name: '',
      rules: [],
      description: '',
      searchTerm: '',
      show: false,
      active: 1,
      page: 5,
      selected_class: 'inactive',
      t:props.t,
      checked: false,
      items: [],
      searchItems: [],
      id: '',
      currentPage: 1,
      count: 0,
      filterFullList: [],
      tokens: [],
      final_tokens: '',
      entity_id: '',
      select:'',
    }

    this.searchData = this.searchData.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.Insertinto = this.Insertinto.bind(this);
  }

  handleClick(e, id) {
    var url = window.GET_STD_DETAILS + '/' + id;
    datasave.service(url, "GET")
      .then(response => {
        this.setState
          ({
            rules: [response[0]],
            show: true,
            namechecked: false,
            descchecked: false,
            entity_id: id,
            select:id,
          });
      })
  }

  componentDidMount() {
    datasave.service(window.GET_STD_LIST, 'GET', '')
      .then((response) => {
        const pageData = this.getPageData(1, response);
        const count = this.getCountPage(response);
        this.setState({
          fields: response,
          count: count,
          items: pageData
        });
      });
  }

  getCountPage(items) {
    const itemLength = items.length;
    return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }

  getPageData(id, list = '') {
    const page = this.state.page;
    const items = (list !== '') ? list : this.state.fields;
    const page_data = items.slice(page * (id - 1), page * id);
    return page_data;
  }

  searchData(e) {
    var list = [...this.state.fields];
    list = list.filter(function (item) {
      if (item.name !== null) {
        return item.name.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
    });
    const page_data = this.getPageData(1, list);
    const count = this.getCountPage(list);
    this.setState({
      items: page_data,
      count: count,
      active: 1,
      searchTerm: e.target.value,
      filterFullList: list,
      show: false
    });

  }

  changePage(e, id = 1) {
    const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
    const page_data = this.getPageData(id, list);
    this.setState({
      items: page_data,
      active: id,
    });
  }

  Insertinto(e, name, entity_id, token_id, description) {
    let Userdata = store.getState();
    let person_id = Userdata.UserData.user_details.person_id;
    const uuidv1 = require('uuid/v1');
    const z = uuidv1();
    let a = z.substring(0, 8);
    name = (name === null) ? e.target.name : name;
    const id = "$" + name + "_" + a + "$";
    let flag = this.state.tokens.filter((items) => (items.entity_id === entity_id && items.ref_token_id === token_id));
    let data = '';
    let final = '';
    let tokens = '';
    let create_date = Math.floor(Date.now() / 1000);
    let update_date = Math.floor(Date.now() / 1000);
    let lang_id = (this.props.stateObj !== undefined && this.props.stateObj.langId !== undefined) ? this.props.stateObj.langId : window.DefaultLangId;
    let stand_id = (this.props.stateObj !== undefined && this.props.stateObj.standId !== undefined) ? this.props.stateObj.standId : window.DefaultStandId;

    if (flag.length < 1 && e.target.checked) {
      // data = {
      //   'token_value': e.target.value,
      //   'token': id,
      //   'doc_id': this.props.id
      // }
      data = {
        'token_name': id,
        'entity_type_ref': 'documents',
        'entity_type': 4,
        'entity_id': entity_id,
        'ref_id': this.props.id,
        'ref_type': 3,
        'ref_token_id': token_id,
        'added_by': person_id,
        'token_value': e.target.value,
        'token': id,
        'tuid': '$' + a + '$ ',
        'temp_id': '',
        'updated_at': update_date,
        'created_at': create_date,
        'lang_id': lang_id,
        'stand_id': stand_id,
      }
      this.state.tokens.push(data);
    }
    if (e.target.name === 'name') {
      this.setState({ namechecked: e.target.checked });
    }
    else if (e.target.name === 'desc') {
      this.setState({ descchecked: e.target.checked });
    }
    if (!e.target.checked) {
      let index = this.state.tokens.findIndex(token => token.entity_id === entity_id && token.ref_token_id === token_id);
      this.state.tokens.splice(index, 1);
    }
  }
  copySelectedTokens(e) {
    let filtered = this.state.tokens.filter(token => token.entity_id === this.state.select);
    var data = {
      tokenData: filtered,
    }
    let tokens = '';
    filtered.map(function (t) {
      tokens += ' '+t.token + ' ';
    }, this);
    localStorage.setItem('framemasterdataTemplate_Token', tokens);
    if(!this.props.isExcel){
      document.getElementById('office_frame').contentWindow.postMessage('{"MessageId":"InsertTokens","Body": "' + tokens + '"}', this.props.postmessage);
    }
  datasave.service(window.INSERT_DOCMASTERTOKEN, 'POST', data)
      .then((response) => {
          if (response['status'] == 200) {
          } else {
          }
      })
  }
  render() {
    const { id,t, currentPage } = this.state;
    const page_data = this.state.fields.slice(this.state.page - 5, this.state.page);
    const filtered = this.state.items;
    let active = this.state.active;
    let pages = [];
    if (this.state.count > 0) {
      for (let number = 1; number <= this.state.count; number++) {
        pages.push(
          <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
            {number}
          </Pagination.Item>,
        );
      }
    }
    const add = {
      textAlign: 'left'
    };

    return (<div>
      <div className="scroll-div-table fix-overflow-docs">
      <input type="text" placeholder={t("Search")} className="search-input" onChange={this.searchData} /><br />
      <reactbootstrap.Table striped bordered hover size="sm" style={add}>
        <tbody>
          {filtered.map(field => {
            return (
              <tr key={field.id}>
                <td className = {(this.state.entity_id === field.id) ? 'active' : 'inactive'} onClick={(e) => this.handleClick(e, field.id)} >{field.name}</td>
              </tr>
            );
          })
          }
        </tbody>
      </reactbootstrap.Table>
      </div>
      <Pagination size="md">{pages}</Pagination>
      <div className="copytofile">
      {this.state.show &&
        <div>
          {this.state.rules.map((rule) => {

            return (
              <div>
                <reactbootstrap.Table striped bordered hover size="sm" style={add}>
                  <tbody>
                    <tr>
                      <td><input type="checkbox" name="name" value={rule.name} onChange={(e) => this.Insertinto(e, rule.name, this.state.entity_id, 10)} checked={this.state.namechecked} /></td>
                      <th >{t('Name')}</th>
                      <td >{rule.name}</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" name="desc" value={rule.description} onChange={(e) => this.Insertinto(e, rule.description, this.state.entity_id, 29)} checked={this.state.descchecked} /></td>
                      <th>{t('Description')}</th>
                      <td>{rule.description}</td>
                    </tr>
                  </tbody>
                </reactbootstrap.Table>
              </div>
            );
          })
          }
        </div>
      }
          </div>
      {this.state.show &&
      <div className="copy-button">
      <reactbootstrap.Button className="btn btn-primary" onClick={(e) => this.copySelectedTokens(e)}>{t('Copy Tokens')}</reactbootstrap.Button>
      </div>
    }

    </div>
    );
  }
}


export default translate(FMDStandards);
