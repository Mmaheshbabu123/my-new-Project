import React from 'react';
import FrameMasterData from '../FrameMasterData/FrameMasterData';
import * as reactbootstrap from 'react-bootstrap';
import { Tabs, Tab } from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import './Master.css';
import Pagination from 'react-bootstrap/Pagination';
import SearchInput, { createFilter } from 'react-search-input';
import { connect } from "react-redux";
import { persistor, store } from '../store';
import { translate, setLanguage, setDefaultTranslations, setDefaultLanguage, setTranslations, Language } from '../language';
const KEYS_TO_FILTERS = ['name']


class FMDJobs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fields: [],
      name: '',
      abbrevation: '',
      rules: [],
      searchTerm: '',
      show: false,
      active: 1,
      page: 5,
      selected_class: 'inactive',
      t:props.t,
      checked: false,
      items: [],
      searchItems: [],
      id: '',
      currentPage: 1,
      count: 0,
      filterFullList: [],
      tokens: [],
      final_tokens: '',
      entity_id: '',
      select:'',
    }

    this.searchData = this.searchData.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.Insertinto = this.Insertinto.bind(this);
    this.copyTo = this.Insertinto.bind(this);
  }

  handleClick(e, id) {
    var url = window.GET_JOB_DETAILS + '/' + id;
    datasave.service(url, "GET")
      .then(response => {
        this.setState
          ({
            rules: [response[0]],
            show: true,
            namechecked: false,
            abbchecked: false,
            entity_id: id,
            select: id,
          });
      })
  }

  componentDidMount() {
    datasave.service(window.GET_JOB_LIST, 'GET', '')
      .then((response) => {
        const pageData = this.getPageData(1, response);
        const count = this.getCountPage(response);
        this.setState({
          fields: response,
          count: count,
          items: pageData
        });
      });
  }

  searchData(e) {
    var list = [...this.state.fields];
    list = list.filter(function (item) {
      if (item.name !== null) {
        return item.name.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
    });
    const page_data = this.getPageData(1, list);
    const count = this.getCountPage(list);
    this.setState({
      items: page_data,
      count: count,
      active: 1,
      searchTerm: e.target.value,
      filterFullList: list,
      show: false
    });

  }


  changePage(e, id = 1) {
    const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
    const page_data = this.getPageData(id, list);
    this.setState({
      items: page_data,
      active: id,
    });
  }

  getCountPage(items) {
    const itemLength = items.length;
    return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
  }

  getPageData(id, list = '') {
    const page = this.state.page;
    const items = (list !== '') ? list : this.state.fields;
    const page_data = items.slice(page * (id - 1), page * id);
    return page_data;
  }


  Insertinto(e, name, entity_id, token_id) {
    let Userdata = store.getState();
    let person_id = Userdata.UserData.user_details.person_id;
    const uuidv1 = require('uuid/v1');
    const z = uuidv1();
    let a = z.substring(0, 8);
    name = (name === null) ? e.target.name : name;
    const id = "$" + name + "_" + a + "$";
    let flag = this.state.tokens.filter((items) => (items.entity_id === entity_id && items.ref_token_id === token_id));
    let create_date = Math.floor(Date.now() / 1000);
    let update_date = Math.floor(Date.now() / 1000);
    let data = '';
    let final = '';
    let tokens = '';
    let lang_id = (this.props.stateObj !== undefined && this.props.stateObj.langId !== undefined) ? this.props.stateObj.langId : window.DefaultLangId;
    let stand_id = (this.props.stateObj !== undefined && this.props.stateObj.standId !== undefined) ? this.props.stateObj.standId : window.DefaultStandId;
    if (flag.length < 1) {
      data = {
        'token_name': id,
        'entity_type_ref': 'org',
        'entity_type': 2,
        'entity_id': entity_id,
        'ref_id': this.props.id,
        'ref_type': 3,
        'ref_token_id': token_id,
        'added_by': person_id,
        'token_value': e.target.value,
        'token': id,
        'tuid': '$' + a + '$ ',
        'created_at': create_date,
        'updated_at': update_date,
        'temp_id': '',
        'lang_id': lang_id,
        'stand_id': stand_id,
      }
      this.state.tokens.push(data);
    }

    if (e.target.name === 'name') {
      this.setState({ namechecked: e.target.checked });
    }
    else if (e.target.name === 'abb') {
      this.setState({ abbchecked: e.target.checked });
    }
    if (!e.target.checked) {
      let index = this.state.tokens.findIndex(token => token.entity_id === entity_id && token.ref_token_id === token_id);
      this.state.tokens.splice(index, 1);
    }
    this.state.tokens.map(function (t) {
      tokens += ' '+t.token+' ';
    }, this);
    this.setState({
      final_tokens: tokens,
    });
  }
  copySelectedTokens(e) {
    let filtered = this.state.tokens.filter(token => token.entity_id === this.state.select);
    var data = {
      tokenData: filtered,
    }
    let tokens = '';
    filtered.map(function (t) {
      tokens += t.token + ' ';
    }, this);
    localStorage.setItem('framemasterdataTemplate_Token', tokens);
    if(!this.props.isExcel){
      document.getElementById('office_frame').contentWindow.postMessage('{"MessageId":"InsertTokens","Body": "' + tokens + '"}', this.props.postmessage);
    }
      datasave.service(window.INSERT_DOCMASTERTOKEN, 'POST', data)
      .then((response) => {
          if (response['status'] == 200) {
          } else {
          }
      })
  }
  render() {
    const { id,t, currentPage } = this.state;
    const page_data = this.state.fields.slice(this.state.page - 5, this.state.page);
    const filtered = this.state.items;
    let active = this.state.active;
    console.log(this.props);
    let pages = [];
    if (this.state.count > 0) {
      for (let number = 1; number <= this.state.count; number++) {
        pages.push(
          <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
            {number}
          </Pagination.Item>,
        );
      }
    }


    return (

      <div >
        <div className="fix-overflow-docs scroll-div-table">
        <input type="text" placeholder={t("Search")} className="search-input" onChange={this.searchData} /><br />

        <reactbootstrap.Table striped bordered hover size="sm">
          <tbody>
            {filtered.map(field => {
              return (
                <tr key={field.id} >
                  <td className = {(this.state.entity_id === field.id) ? 'active' : 'inactive'} onClick={(e) => this.handleClick(e, field.id)} >{field.name}</td>
                </tr>
              );
            })
            }
          </tbody>
        </reactbootstrap.Table>
        </div>
        <Pagination size="md">{pages}</Pagination>
        {this.state.show &&
          <div>
            {this.state.rules.map((rule) => {
              return (
                <reactbootstrap.Table striped bordered hover size="sm">
                  <tbody>
                    <tr>
                      <td><input type="checkbox" name='name' value={rule.name} onChange={(e) => this.Insertinto(e, rule.name, this.state.entity_id, 18)} checked={this.state.namechecked} /></td>
                      <th>{t('Name')}</th>
                      <td>{rule.name}</td>
                    </tr>
                    <tr>
                      <td><input type="checkbox" name='abb' value={rule.abbrevation} onChange={(e) => this.Insertinto(e, rule.abbrevation, this.state.entity_id, 19)} checked={this.state.abbchecked} /></td>
                      <th>{t('Abbreviation')}</th>
                      <td>{rule.abbrevation}</td>
                    </tr>
                  </tbody>
                </reactbootstrap.Table >
              );
            })
            }
          </div>
        }
        {this.state.show &&
          <div className="copy-button">
        <reactbootstrap.Button className="btn btn-primary" onClick={(e) => this.copySelectedTokens(e)}>{t('Copy Tokens')}</reactbootstrap.Button>
      </div>}
      </div>

    );

  }
}
const mapStateToProps = state => ({ ...state });
export default translate(connect(mapStateToProps)(FMDJobs));
