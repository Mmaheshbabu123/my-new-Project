import React, { Component } from 'react';
import { translate } from '../language';
import { datasave } from '../_services/db_services';
import { Input, ListGroup, ListGroupItem} from 'reactstrap';
import CheckBox from '../CheckBox';
import * as Reactbootstrap from 'react-bootstrap';
import { Button, Form, FormGroup, FormControl } from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import './hierarchy.css';

import TreeMenu, { defaultChildren, ItemComponent } from 'react-simple-tree-menu';

var dummydata = [];
class Hierarchy extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t:props.t,
      treedata : [],
      data : [],
      replica_data : [],
    }
    this.openNodes = [];
    this.handleCheckBox = this.handleCheckBox.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  componentDidMount() {
    const details = {
      doc_id :this.props.doc_id,
    }
    datasave.service(window.ORG_SITES, "POST",details)
        .then(result => {
          dummydata = JSON.parse(JSON.stringify(result));
          this.displayTreestructure(result)
              this.setState({
                data : result,
                replica_data : dummydata,
            })
        });
  }
  componentDidUpdate(prevProps, prevState) {
    if(prevProps.doc_id!=this.props.doc_id){
      const details = {
        doc_id :this.props.doc_id,
      }
      datasave.service(window.ORG_SITES, "POST",details)
          .then(result => {
            dummydata = JSON.parse(JSON.stringify(result));
            this.displayTreestructure(result)
                this.setState({
                  data : result,
                  replica_data : dummydata,
                })
          });
    }
  }


  handleCancel() {
    this.setState({
      data : this.state.duplicatedata
    })
  }

  displayTreestructure (data) {
    let finalData = {};
    let folderData = data;
    var touched_ids = [];
    Object.keys(folderData).map(function (key) {
        if(folderData[key].childrens!== undefined){
            Array.from(Object.values(folderData[key].childrens)).forEach(function (id) {
                folderData[key].nodes[id] = folderData[id];
                touched_ids.push(id);
            });
        finalData[key] = folderData[key];
      }
    });
    touched_ids.forEach(function (id) {
        delete finalData[id];
    });
    this.openNodes = Object.keys(finalData);
    this.setState({
      treedata : finalData,
    })
  }
  handleCheckBox(id,value) {
    this.handleUpdateState(id,value)

  }
  handleUpdateState(id, value) {
    let data = this.state.data;
    for (var key in this.state.data) {
      let item = this.state.data[key];
      if (item.id === id) {
        item.value = value;
      }
    }
    this.setState({
      data: data,
    });
  }

  handleSubmit() {
    const details = {
      doc_id : this.props.doc_id,
      doc_status : this.props.document_status,
      data : this.state.data,
    }
    datasave.service(window.HIERARCHY_SITE, "POST",details)
        .then(result => {
            if(result === 'Success'){
              for (var x in this.state.data){
                  if (this.state.data[x].value!=this.state.replica_data[x].value) {
                    var message = this.state.data[x].value ==true ? this.state.t('Document successfully copied to '+this.state.data[x].label+'site'):
                                                                    this.state.t('Document successfully deleted from '+this.state.data[x].label+'site')
                    OCAlert.alertSuccess(message, { timeOut: window.TIMEOUTNOTIFICATION });
                  }
              }
            }
        });
    }
  onClickNode(key, label, props) {
    if(props.parent_type !== 'organisation') {
      this.handleUpdateState(props.id, !props.value)
      return;
    }
    if(this.openNodes.includes(key))
        this.openNodes.splice(this.openNodes.indexOf(key), 1)
    else
        this.openNodes.push(key)
    this.setState({updateTree: 1})
  }

  render () {
    const DEFAULT_PADDING = 5;
    const ICON_SIZE = 8;
    const LEVEL_SPACE = 16;
    const WIDTH = '25px';
    const HEIGHT = '25px';
    const DISPLAY = 'inline-flex';
    const WIDTH_DYNAMIC = '20' ;
    const {t} = this.state;
    const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }}>{on ? '-' : '+'}</span>;
    const ListItem = ({
        level = 0,
        key,
        hasNodes,
        isOpen,
        type_id,
        label,
        searchTerm,
        openNodes,
        value,
        id,
        parent_type,
        ...props
    })=> (
          <div className="hierarchy-wrap">
              <ListGroupItem
                  className="left-border"
                  {...props}
                  style={{
                      paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
                      cursor: 'pointer',
                  }}
                  key={key}
                >
                <div className='rosw'>
                  <div className="list-items-structure" style = {{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
                      {hasNodes && <ToggleIcon on={isOpen} />}
                      <p className="result-label" style={{fontWeight: parent_type !== 'organisation' ? null: 'bold'}}>{label}</p>
                      {!hasNodes && <span style={{ marginRight: 8 }}> &nbsp;</span>}
                  </div>
                  {parent_type !== 'organisation' &&
                   <div className="col-m2d-3">
                       <Reactbootstrap.Form.Group >
                           <CheckBox
                             className="col-md-2"
                             key={id}
                             value={value}
                             tick={value}
                             // name = {label}
                             classification={label}
                             onCheck={e => this.handleCheckBox(id, e.target.checked)}
                             keyvalue={id}

                           />

                       </Reactbootstrap.Form.Group>
                   </div>
                 }
                 </div>

              </ListGroupItem>
          </div>
    );
    return (
      <div className='container-fluid'>
        <div className='row'>
          <div className='col-md-12 offset-md-12'>
            <TreeMenu
              data={this.state.treedata}
              onClickItem={({ key, label, ...props }) => {
                this.onClickNode(key, label, props);
              }}
              openNodes={this.openNodes}
              debounceTime={125}>
                {({ search, items }) => (
                    <>
                      <Input onChange={e => search(e.target.value)} placeholder="Type and search" />
                      <ListGroup>
                        {items.map(props => (
                            <ListItem {...props} />
                        ))}
                      </ListGroup>
                    </>
                )}
            </TreeMenu>


          </div>
        </div>
        <FormGroup>
           <div style={{ float: 'right' }} className="organisation_list">
              <Button type="submit" name="save" className="btn btn-primary" onClick={this.handleSubmit.bind(this)}>{t('Save')}</Button>
           </div>
         </FormGroup>
      </div>
    )
  }
}
export default translate(Hierarchy)
