import React, { Component } from 'react';
import language, { translate } from './language';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import * as reactbootstrap from 'react-bootstrap';
import withDragAndDrop from 'react-big-calendar/lib/addons/dragAndDrop'
const DragAndDropCalendar = withDragAndDrop(Calendar)
// moment.locale('en-GB');
// BigCalendar.momentLocalizer(moment);
class BigCalendarPractice extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showPopUp: false,
            start: {},
            end: {},
            title: '',
            events: [
                {
                    id: 0,
                    title: 'All Day Event very long title',
                    // allDay: true,
                    start: new Date(2019, 10, 16, 10, 0, 0),
                    end: new Date(2019, 10, 16, 12, 0, 0),
                    resource: 'todo1'
                },
                {
                    id: 1,
                    title: 'Long Event',
                    start: new Date(2019, 10, 7),
                    end: new Date(2019, 10, 10),
                    resource: 'todo2'
                },
            ]
        }
    }
    render() {
        return (<div className='container py-5'>
            {this.displayCalendar()}
            {this.displayPopUp()}
        </div>)
    }

    displayCalendar() {

        const localizer = momentLocalizer(moment);
        return (

            <div style={{ height: '500pt' }}>
                <DragAndDropCalendar
                    selectable
                    events={this.state.events}
                    startAccessor="start"
                    endAccessor="end"
                    // defaultDate={new Date(2019, 10, 16)}
                    defaultView='month'
                    views={['week', 'day', 'work_week', 'agenda', 'month']}
                    localizer={localizer}
                    onSelectEvent={(event) => this.handleEvenSelect(event)}
                    onSelectSlot={this.handleSelect}
                    onDragStart={console.log}
                    onEventDrop={this.moveEvent.bind(this)}
                    eventPropGetter={this.eventStyleGetter}
                />
            </div>
        );


    }
    eventStyleGetter = (event, start, end, isSelected) => {
        console.log(event);
        // var backgroundColor = '#' + event.hexColor;
        var backgroundColor = 'red';
        if (event.id == 1) {
            backgroundColor = 'blue';
        }

        var style = {
            backgroundColor: backgroundColor,
            // borderRadius: '0px',
            opacity: 0.8,
            color: 'black',
            // border: '0px',
            // display: 'block'
        };
        return {
            style: style
        };
    }

    moveEvent(e) {
        console.log(e);
        let events = this.state.events;
        events.map((key, index) => {
            if (key.id == e.event.id) {
                events[index].start = e.start;
                events[index].end = e.end;
            }
        })
        this.setState({ events: events });
        console.log('move');
        console.log(e);
    }
    handleSelect = (e) => {
        let start = e.start;
        let end = e.end;
        // let startObj = {
        //     'date': start.getDate(),
        //     'month': start.getMonth() + 1,
        //     'year': start.getFullYear(),
        //     'hours': start.getHours()
        // };
        // let endObj = {
        //     'date': end.getDate(),
        //     'month': end.getMonth() + 1,
        //     'year': end.getFullYear(),
        //     'hours': end.getHours()
        // }
        this.setState({ start: start, end: end, showPopUp: true });

        // this.setState({ start: startObj, end: endObj, showPopUp: true });
    }

    handlePopUP() {

    }
    handleEvenSelect(event) {
        alert(event.title);
    }
    handleSave() {
        let start = this.state.start;
        let end = this.state.end;
        let title = this.state.title;
        let events = this.state.events;

        let newObj = {
            'title': title,
            'start': start,
            'end': end
        }
        events.push(newObj);
        this.setState({ events: events, showPopUp: false });

    }

    handleOnChange() {

    }
    displayPopUp() {
        const { t } = this.state;
        return (
            <reactbootstrap.Modal show={this.state.showPopUp} onHide={(e) => this.setState({ showPopUp: false })}>
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title>{'Title'}</reactbootstrap.Modal.Title>
                </reactbootstrap.Modal.Header>
                <input type={'text'} onChange={(e) => this.setState({ title: e.target.value })} />
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button variant="primary" onClick={this.handleSave.bind(this)}>
                        Ok
                    </reactbootstrap.Button>
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        )
    }
}
export default translate(BigCalendarPractice);

