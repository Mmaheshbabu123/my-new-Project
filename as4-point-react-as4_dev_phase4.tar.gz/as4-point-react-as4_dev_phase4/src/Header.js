import React from 'react'
import * as reactbootstrap from 'react-bootstrap';
import { FormGroup, InputGroup, Button } from 'react-bootstrap';
import { translate } from './language';
import axios from 'axios';
import './header.css';

import OptionsTab from './settings/OptionsTab';

class Header extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: '',
      t: props.t,
      isAuthenticated: false,
      selected: "",
      language: [],
      sitedata: this.props.sitedata
    }
    this.changelang1 = this.changelang1.bind(this)

  }
  changelang1(event) {

    var x = event.target.value;
    this.setState({ t: this.props.t });
    this.setState({ selected: event.target.value })
    localStorage.setItem('Applang', event.target.value);

    this.props.triggerSelectedLanguage(
      event.target.value
    )
    //window.location.reload();
  }
  componentWillReceiveProps(nextProps) {
    //setting the latest props to the state
    this.setState({ sitedata: nextProps.sitedata });
  }
  update() {
    if ((localStorage.getItem('user')) && localStorage.getItem('user').token !== '') {
      this.setState({ isAuthenticated: true });
    }
  }

  componentDidMount() {
    if (localStorage.getItem('Applang')) {
      this.setState({
        selected: localStorage.getItem('Applang')
      })
    }
    else {
      this.setState({
        selected: 'en'
      })
    }
    // this.setState({
    //     selected : 'english',
    // })
    this.getTheLanguage();
  }
  componentDidUpdate() {
    //window.backendURL = this.state.sitedata.backend;
  }
  getTheLanguage() {
    axios.get(process.env.REACT_APP_serverURL + '/api/get_all_languages')
      .then(response => {
        this.setState({
          language: response.data
        });
      });
  }

  getOptionItems() {
    let temp = [];
    if (this.state.language.length > 1) {
      if (this.state.language) {
        temp = this.state.language.map((lang) => {
          return (<option id={lang.code_name} value={lang.code_name} >{lang.language}</option>)
        }
        );
        return temp;
      }
    }
  }

  render() {
    const { t } = this.state;
    return (
      <reactbootstrap.Navbar className="header-nav" bg="primary" variant="dark">
        <reactbootstrap.Navbar.Brand href="/">
          <img
            src={window.backendURL + "" + this.state.sitedata.icon}
            width="100"
            height="60"
            className="d-inline-block align-top"
            alt="As4 point"
          />
        </reactbootstrap.Navbar.Brand>
        <reactbootstrap.Nav className="ml-auto">

          <FormGroup>
            <InputGroup className="mb-3">
              <InputGroup.Prepend>
                <InputGroup id="basic-addon1">{t('Language')}</InputGroup>
              </InputGroup.Prepend>
              <select name="language" id="language" value={this.state.selected} onChange={this.changelang1}>
                {
                  //this.getOptionItems()
                }
              </select>
            </InputGroup>
          </FormGroup>
          {localStorage.getItem('user') ? <reactbootstrap.Nav.Link href="/loginscreen" onClick={this.update}>{t('Logout')}</reactbootstrap.Nav.Link>
            : <reactbootstrap.Nav.Link href="/loginscreen">{t('Login')}</reactbootstrap.Nav.Link>}
        </reactbootstrap.Nav>
      </reactbootstrap.Navbar>
    );
  }
}

export default translate(Header)
