import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Can from '../_components/CanComponent/Can';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import {PagePermissions} from '../_components/CanComponent/PagePermissions';
import {translate} from '../language';
import { Button, Container, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';

class Templates extends Component {
  constructor(props) {
    super(props)
    this.handleSubmit = this.handleSubmit.bind(this);
    this.state = {
      name: '',
      //description: '',
      submitted: false,
      loading: false,
      error: '',
      type_id: '',
      types: [],
      type_disabled: false,
      name_error: '',
      require_error: '',
      type_error:'',
      new: '',
      template_store_url: window.GET_INSERT_TEMPLATE_DETAILS,
      t: props.t,
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleChangeSelect = this.handleChangeSelect.bind(this);
  }

  componentDidMount() {
    const templateId = this.props.id;
    var get_types_url = window.SHOW_TEMPLATECATEGORY;
     if(this.props.type === 'clone'){
       this.setState({
         type_disabled:true,
         require_error:'',
         name_error:''
       })
     }
    datasave.service(get_types_url, 'GET', '').then(result => {
      this.setState({
        types: result
      })
    })
    if (templateId) {
      const get_templates_url = window.SHOW_TEMPLATES + templateId;
      datasave.service(get_templates_url, 'GET', '')
      .then(response => {
        this.setState({
          name: response[0]['name'],
          type_id: response[0]['type_id'],
          require_error: '',
          errors:'',
          name_error: ''
          //type_disabled: false,
        })
      })
    }
  }
  componentDidUpdate(prevProp,prevState){
    const templateId = this.props.id;
    if((this.props.id !==''&& prevProp.id!==this.props.id) || prevProp.type!==this.props.type){
      if(this.props.type === 'clone'){
        this.setState({
          type_disabled:true,
          require_error: '',
          name_error:''
        })
      }else{
        this.setState({
          type_disabled:false,
          require_error: '',
           name_error: '',
        })
      }
      if(this.props.id!== undefined){
        const get_templates_url = window.SHOW_TEMPLATES + templateId;
        datasave.service(get_templates_url, 'GET', '')
        .then(response => {
          this.setState({
            name: response[0]['name'],
            type_id: response[0]['type_id'],
            type_error:''
      })
    })
    }else{
      this.setState({name:'',
      type_id: [],
      // require_error: '',
      // name_error: ''
     })
    }
  }
  }

  handleChangeSelect(event)
  {
    const { name, value } = event.target;
    const {t} = this.state;
    this.setState({
      [name]: value,
      name_error: '',
      type_error: '',
      loading: '',
    });
    if(event.target.value === 'Select' ){
      this.setState({type_error: t('Type is required field')})
    }
    else{
      this.setState({ type_error: '' })
    }
  }


  handleChange(event) {
     const { name, value } = event.target;
     const {t} = this.state;
    this.setState({
      [name]: value,
      name_error: '',
      type_error: '',
      loading: '',
    });
    if(event.target.value === '' ){
      this.setState({require_error: t('Name is required field')})
    }
    else{
      this.setState({ require_error: '' })
    }
  }
  //WARNING! To be deprecated in React v17. Use componentDidMount instead.


  handleCancel(event) {
       event.preventDefault()
      this.props.updateComponentCancel(1);
  }
  componentWillReceiveProps(){
    if(this.props.id === undefined){
    this.setState({
      require_error:'',
      type_error:'',
      name_error: '',
    })}
  }

  handleSubmit(event) {
    const {t} = this.state;
    event.preventDefault()
    // const { history } = this.props
    const data = {
      name: this.state.name.replace(/\s+/g,' ').trim(),
      type_id: this.state.type_id,
    }

    if (this.props.id) {
      if (this.validate()) {
        const details = {
          name: this.state.name.replace(/\s+/g,' ').trim(),
          id: this.props.id,
          type_id: this.state.type_id,
        }
        const editurl = window.UPDATE_TEMPLATE + this.props.id + '/'+this.props.type;
        datasave.service(editurl, 'PUT', details)
        .then(response => {
            if (response.name) {
              this.setState({
                  name_error: t('The name has already been taken!'),
              })
            } else {
              if (response === "Success") {
                this.props.updateComponent(1);
              }
            }
          }
        )

      }
    } else {

      if (this.validate()) {

        datasave.service(window.GET_INSERT_TEMPLATE_DETAILS, 'POST', data)
          .then(response => {
            if (response.name) {
              this.setState({
                name_error: t('The name has already been taken !'),
              })
            } else {
              if (response === 'Success') {
                this.props.updateComponent(1);
              }
              if (response.name || response.type_id) {
                          this.setState({
                            name_error: response.name,
                            type_error: response.type_id,
                          })
                        }
            }
          })
      }
    }
  }
  validate() {
    const {t} = this.state;
    var name_valid = this.state.name.replace(/\s+/g,' ').trim();
     let  formIsValid;
     if (name_valid === ''&& this.state.type_id === '') {
       formIsValid = false;
         this.setState(
           {
             require_error: t('Name is required field'),
             type_error:t('Type is required field')
           }
         )
       }else if(name_valid === ''){
         formIsValid = false;
        this.setState(
          {
            require_error: t('Name is required field'),
          }
        )
       }
       else if(this.state.type_id === 'Select'){
        formIsValid = false;
        this.setState(
          {
            //require_error: 'Template name is required field',
            type_error:t('Type is required field')
          }
        )
       }
         else{
       formIsValid = true;
       }

     return formIsValid;
   }

  render() {
    const as4_or_site = 1;//PagePermissions()
    const { types, name, type_id, submitted, loading, type_error,t } = this.state;

    if (as4_or_site) {
      return (
        <div className=" row">
          <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
          <div style={{ marginLeft: '-1.5rem' }} className='col-md-11' >
          <Can
            perform="E_template"
            yes={() => (
            <div className='row justify-content-center' >
              <div className='col-md-12  mb-5' >
              <div className='card' >
                <div className='card-header' >{('Create template')}</div>
                <div className='card-body' >
                  <reactbootstrap.Container className="p-2">
                    <reactbootstrap.Form onSubmit={this.handleSubmit}>
                      <reactbootstrap.FormGroup>
                        <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
                        <div className=" row input-overall-sec ">
                          <reactbootstrap.InputGroup className="">
                          <div className="col-md-4">
                            <reactbootstrap.InputGroup.Prepend>
                              <reactbootstrap.InputGroup  style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{('Name:')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                            </reactbootstrap.InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                            <reactbootstrap.FormControl
                              name="name"
                              placeholder={t("Template")}
                              aria-label="Template"
                              aria-describedby="basic-addon1"
                              value={name}
                              onChange={this.handleChange}
                              className="input_sw "
                            />
                             <div style={{ color: 'red' }} className="error-block mt-2">{this.state.require_error}</div>
                          {/* <div style={{ color: 'red' }} className="error-block">{this.state.errors}</div> */}
                          <div style={{ color: 'red' }} className="error-block mt-2">{this.state.name_error}</div>
                            </div>
                          </reactbootstrap.InputGroup>

                        </div>
                        </div>
                      </reactbootstrap.FormGroup>
                      <reactbootstrap.FormGroup>
                      <div className={'form-group' + (submitted && !type_id ? ' has-error' : '')}>
                      <div className=" row input-overall-sec ">
                        <reactbootstrap.InputGroup className="">
                        <div className="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }}  id="basic-addon1">{t('Select type:')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                          </div>
                          <div class="col-md-8 input-padd">
                          <div className="input_sw ">
                          <reactbootstrap.FormControl as="select" name="type_id"
                            required
                            value={type_id}
                             disabled={this.state.type_disabled}
                            onChange={this.handleChangeSelect}
                             >
                            <option>{('Select')}</option>
                            {types.map(type => <option value={type.id}>{type.name}</option>)}
                          </reactbootstrap.FormControl>
                       </div> <div style={{ color: 'red' }} className="error-block mt-2">{this.state.type_error}</div>
                       </div>
                        </reactbootstrap.InputGroup>

                        </div>
                        </div>
                      </reactbootstrap.FormGroup>
                      <FormGroup>
                      <div style={{ float: 'right' }} className="organisation_list mt-3">
                        <a onClick={this.handleCancel} >{t('Cancel')}</a>
                        &nbsp;&nbsp;&nbsp;
                          <reactbootstrap.Button type="submit" className="btn btn-primary" onClick={this.handleSubmit} disabled={loading}>{t('Save')}</reactbootstrap.Button>
                          {/* {loading &&
                            <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                          } */}
                          &nbsp;&nbsp;&nbsp;

                        </div>
                        </FormGroup>
                    </reactbootstrap.Form>
                  </reactbootstrap.Container>
                </div>
              </div>
            </div>
          </div>
           )}
          no={ () =>
            <AccessDeniedPage/>
          }
        />
        </div>
        </div>
      );
    }
    else {
      return(
          <AccessDeniedPage />
      )
    }
  }
}
export default translate(Templates)
