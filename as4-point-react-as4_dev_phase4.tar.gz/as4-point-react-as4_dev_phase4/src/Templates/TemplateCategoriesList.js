//import axios from 'axios';
import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import {translate} from '../language';

class TemplateCategoriesList extends Component {
  constructor(props) {
    super(props)
    this.state = {
      categories: [],
      t:props.t,
    }
  }
  componentDidMount() {
    var data = '';
    var url = window.SHOW_TEMPLATECATEGORY;
    datasave.service(url, 'GET', data).then(response => {
      this.setState({
        categories: response
      })
    })
  }

  render() {
    const { categories,t } = this.state
    return (
      <div className='container py-4'>
        <div className='row justify-content-center'>
          <div className='col-md-8'>
            <div className='card'>
              <div className='card-header'>{t('Template categories')}</div>
              <div className='card-body'>
                <reactbootstrap.Table responsive striped bordered hover size="sm">
                  <thead>
                    <tr>
                      <th>{t('Category name')}</th>
                      <th colspan="2">{t('Actions')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {categories.map(CategoryItem => (
                      <tr>
                        <td>
                          {CategoryItem.name}
                        </td>
                        <td>
                          <Link
                            to={`/templatecategory/${CategoryItem.id}`}
                            key={CategoryItem.id}
                          >
                            {t('Edit')}
                        </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </reactbootstrap.Table>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default translate(TemplateCategoriesList);
