import axios from 'axios';
import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import {translate} from '../language';

class TemplateCategory extends Component {
  constructor(props) {
    super(props)
    this.handleSubmit = this.handleSubmit.bind(this);
    this.state = {
      name: '',
      //checked: false,
      description: '',
      submitted: false,
      loading: false,
      error: '',
      classification_id: 1,
      classifications: [],
      t:props.t,
    }
    this.handleChange = this.handleChange.bind(this);

  }
  componentDidMount() {
    const templatecatId = this.props.match.params.id;
    var data = '';
    var method = 'GET';
    var tempclassification = window.SHOW_TEMPCLASSIFICATIONS;
    var tempcategories = window.SHOW_TEMPLATECATEGORY + '/' + templatecatId;
    datasave.service(tempclassification, method, data).then(result => {
      this.setState({
        classifications: result
      })
    })
    if (this.props.match.params.id) {
      datasave.service(tempcategories, method, data).then(response => {
        this.setState({
          name: response[0]['name'],
          package_details: response,
          description: response[0]['description'],
          classification_id: response[0]['classification_id']
        })
      })
    }
  }
  handleChange(event) {
    const { name, value } = event.target;
    this.setState({ [name]: value });
  }
  handleSubmit(event) {
    event.preventDefault();
    this.setState({ submitted: true });
    const { history } = this.props
    const details = {
      name: this.state.name,
      description: this.state.description,
      classification_id: this.state.classification_id,
    }
    if (this.props.match.params.id) {
      const templatecatId = this.props.match.params.id;
      var url = window.SHOW_TEMPLATECATEGORY + '/' + templatecatId;
      datasave.service(url, 'PUT', details)
        .then(response => {
          if (response.name) {
            console.log('test');
            this.setState({
              error: response.name
            })
          }
          else {
            history.push('/managetemplatecategories');
          }
        })
    }
    else {
      console.log('else');
      datasave.service(window.INSERT_TEMPLATECATEGORY, 'POST', details)
        .then(response => {
          if (response.name) {
            console.log('test');
            this.setState({
              error: response.name
            })
          }
          else {
            history.push('/managetemplatecategories');
          }
        })
    }
  }
  render() {
    const { name,t, description, submitted, loading, error, classification_id } = this.state;
    return (
      <div className='container py-4' >
        <div className='row justify-content-center' >
          <div className='col-md-6' >
            <div className='card' >
              <div className='card-header' > {t('Create template category')} </div>
              <div className='card-body' >
                <reactbootstrap.Container className="p-2">
                  <reactbootstrap.Form onSubmit={this.handleSubmit}>
                    <reactbootstrap.FormGroup>
                      <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
                        <reactbootstrap.InputGroup className="mb-3">
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup  id="basic-addon1">{t('Name')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                          <reactbootstrap.FormControl
                            name="name"
                            placeholder={t("Template category")}
                            aria-label="Template category"
                            aria-describedby="basic-addon1"
                            value={name}
                            onChange={this.handleChange}
                          />
                        </reactbootstrap.InputGroup>
                        <div style={{ color: 'red' }} className="error-block">{error}

                        </div>

                      </div>
                    </reactbootstrap.FormGroup>
                    <reactbootstrap.FormGroup>
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup  id="basic-addon1">{t('Description')}</reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                      <reactbootstrap.FormControl
                        style={{ height: '200px' }}
                        as="textarea" rows="3"
                        name="description"
                        placeholder={this.props.placeholder}
                        value={description}
                        id="description"
                        onChange={this.handleChange}
                      />
                    </reactbootstrap.FormGroup>
                    <reactbootstrap.FormGroup>
                      <reactbootstrap.InputGroup className="mb-3">
                        <reactbootstrap.InputGroup.Prepend>
                          <reactbootstrap.InputGroup  id="basic-addon1">{t('Select classification')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                        </reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.FormControl as="select" name="tid"
                          required
                          value={this.state.classification_id}
                          onChange={e => this.setState({ classification_id: e.target.value })} >

                          {this.state.classifications.map(classification => <option value={classification.id}>{classification.classification}</option>)}
                        </reactbootstrap.FormControl>
                      </reactbootstrap.InputGroup>
                    </reactbootstrap.FormGroup>
                    <reactbootstrap.FormGroup>
                      <div className="form-group">
                        <reactbootstrap.Button type="submit" className="btn btn-primary" disabled={loading}>{t('Save')}</reactbootstrap.Button>
                        {loading &&
                          <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                        }
                      </div>
                    </reactbootstrap.FormGroup>
                  </reactbootstrap.Form>
                </reactbootstrap.Container>
              </div>
            </div>
          </div>
        </div>
      </div>

    );
  }
}
export default translate(TemplateCategory);
