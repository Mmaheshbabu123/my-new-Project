import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import Pagination from 'react-bootstrap/Pagination'
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import Templates from '../Templates/Templates'
import Can from '../_components/CanComponent/Can';
import { translate } from '../language';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import { PagePermissions } from '../_components/CanComponent/PagePermissions';
import SearchInput, { createFilter } from 'react-search-input';
import './TemplateList.css';
import { OCAlert } from '@opuscapita/react-alerts';


const KEYS_TO_FILTERS = ['name', 'id']
class TemplateList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            templates: [],
            page: 5,
            _1stTemplate: '',
            templateId: '',
            currentPage: 1,
            searchTerm: '',
            items: [],
            doc_data: [],
            tabId: '',
            active: 1,
            todosPerPage: 4,
            popperpage:5,
            count: 0,
            show:false,
            alert:false,
            delete:false,
            component:false,
            t: props.t,
            layoutExist:false,
            delete1:false,
            linkedManuals : [],
            manualDocs    : [],
            manualtabkey  : 0,
        }
        this.handleDelete = this.handleDelete.bind(this);
        this.changeComponent = this.changeComponent.bind(this);
        this.searchData = this.searchData.bind(this);
    }

    getPageData(id, list = '') {
        const page = this.state.page;
        const items = (list !== '') ? list : this.state.templates;
        const page_data = items.slice(page * (id - 1), page * id);
        return page_data;

    }

    componentDidMount() {
        const url = window.GET_INSERT_TEMPLATES;
        datasave.service(url, 'GET', '')
            .then(response => {
                const pageData = this.getPageData(this.state.active, response);
                const count = this.getCountPage(response);
                this.setState({
                    templates: response,
                    _1stTemplate: response[0].id,
                    items: pageData,
                    count: count,
                    editbtnstatus: 'true',
                    active:1,
                })
            });
    }

    getCountPage(items) {
        const itemLength = items.length;
        return (itemLength > this.state.page) ? Math.ceil(itemLength / this.state.page) : 0;
    }

    searchData(e) {
        var list = [...this.state.templates];
        list = list.filter(function (item) {
            if (item.name !== null) {
                return item.name.toLowerCase().search(
                    e.target.value.toLowerCase()) !== -1;
            }
        });
        const page_data = this.getPageData(1, list);
        const count = this.getCountPage(list);
        this.setState({
            items: page_data,
            count: count,
            active: 1,
            searchTerm: e.target.value,
            filterFullList: list,
        });

    }
    handleDelete(id, e) {
        var url = window.DELETE_ITEM + id;
        const details = {
            table: window.templates_table,
        }
        datasave.service(url, 'PUT', details)
            .then(response => {
                if (response === 1) {
                    this.setState({
                        component: 'false'
                    })
                    this.updateComponentCancel.component = 'false'
                    this.componentDidMount()
                }
            })
            .catch(error => {
                this.setState({
                    errors: error.response.data.errors
                })
            })
    }
    changeComponent(e, id, type) {

        this.setState({
            component: 'true',
            formId: (id !== '') ? id : '',
            type: type,
            editbtnstatus: 'false'
        });
        this.props.tab(true);
    }

    updateComponent(e) {
        if (e) {
            this.componentDidMount();
            this.setState({
                component: 'false',
                saveComponent: 1,
            })
        }
        this.props.tab(false);
    }

    updateComponentCancel(e) {
        if (e) {
            this.setState({
                component: 'false',
                saveComponent: 1,
                editbtnstatus: 'true'
            })
        }
        this.props.tab(false);
    }
    update(e) {
        if (e !== this.state.tabId) {
            this.setState({
                tabId: e,
            });
        }
    }
    changePage(e, id = 1) {
        const list = (this.state.searchTerm !== '') ? this.state.filterFullList : '';
        const page_data = this.getPageData(id, list);
        this.setState({
            items: page_data,
            active: id,
        });

    }
    searchUpdated(term) {
        this.setState({ searchTerm: term })
    }
    openEditor(e, name, tid, type, openFor = '') {
      if(type === 2){
        type = 4;
      }
      let route = `/FrameMasterData?type=${type}&tid=${tid}&id=${btoa(name)}&openfor=${openFor}`
      window.open(route, '_top');
    }
    handleDeleteTemplate(id){
      const {t} = this.state;
        let url = window.Delete_Template+id;
        datasave.service(url,'put').then(
            response=>{
              if(response){
                OCAlert.alertWarning(t('Documents attached, cannot be deleted!'), { timeOut: window.TIMEOUTNOTIFICATION1});

                //   alert("Doc attached can't be deleted")
              }else{
                  this.componentDidMount();
                  this.setState({
                      show:false
                  })
                  this.state.items.length = this.state.items.length-1;
            if(this.state.items.length === 0)
            {
                this.state.active = this.state.active - 1
            }
              }
            }
        )
    }
    handleDeletePopup = (id)=>{
       let url = window.get_usedDocsDelete+id;
         datasave.service(url,'GET').then(
             response=>{
                 this.checkLayoutForTemplate(id,response)
             }
         )
    }
    checkLayoutForTemplate(id,responsed)
    {
      let url = window.checkLayoutExist+id;
      datasave.service(url,'GET').then(
        response=>{
            if(response.length !== 0 && responsed.length !== 0){
                this.setState({
                    manualDocs:responsed.manualDocs ? responsed.manualDocs : [],
                    linkedManuals : responsed.manuals ? responsed.manuals : [],
                    manualtabkey : responsed.manuals ? responsed.manuals[0].value : 0,
                    show:true,
                    delete:false,
                    linkid : id,
                    layoutExist:false,
                    delete1:false,
           })
            }else if(response.length === 0 && responsed.length === 0){
                this.setState({
                    manualDocs:responsed.manualDocs ? responsed.manualDocs : [],
                    linkedManuals : responsed.manuals ? responsed.manuals : [],
                    manualtabkey : responsed.manuals ? responsed.manuals[0].value : 0,
                    show:true,
                    delete:true,
                    linkid : id,
                    layoutExist:true,
                    delete1:false
                })
            }
            else if(response.length !== 0 && responsed.length === 0){
                this.setState({
                    manualDocs:responsed.manualDocs ? responsed.manualDocs : [],
                    linkedManuals : responsed.manuals ? responsed.manuals : [],
                    manualtabkey : responsed.manuals ? responsed.manuals[0].value : 0,
                    show:true,
                    delete:true,
                    linkid : id,
                    layoutExist:false,
                    delete1:true
                })
            }
        })
    }
    handlehide = () => {
        this.setState(
            { show: false }
        )
    }
    handleOk() {
        const {t} = this.state;
        if(this.state.delete === true){
            this.handleDeleteTemplate(this.state.linkid);
        }else{
            OCAlert.alertWarning(t('Documents attached, cannot be deleted!'), { timeOut: window.TIMEOUTNOTIFICATION1});
        }

    }
    handlePopCancel(){
        this.setState(
            { show: false }
        )

    }
    handlePageClick(event) {
        this.setState({
            popcurrentpage: Number(event.target.id)
        });
    }

    render() {
        const as4_or_site = 1;//PagePermissions()
        const { templates, t } = this.state
        const filtered = this.state.items;
        const templatesdata = filtered.map(templates => {
            return <tr>
                <td>
                    <span style={{ cursor: 'pointer', hover: 'color:#007bf8' }}>
                        {templates.name}
                    </span>
                </td>
                <td>{templates.tc_name}</td>

                <td >
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                        <Can
                            perform="E_template"
                            yes={() => (
                                <p style={{ color: "#007bf8", cursor: "pointer", margin: '0px', padding: '5px' }} onClick={(e) => this.changeComponent(e, templates.id, 'edit')} disabled={this.state.editBtnState}  >
                                    {/* {t('Edit')} */}
                                    <i title={t("Edit")} class="E-C-T E-C-T-edit"></i>
                                </p>
                            )}
                        />
                        {/* {  this.state.editbtnstatus === 'true' &&
                    <Can
                        perform="D_space"
                        yes={() => (
                            <p style={{ color: "#007bf8", cursor: "pointer", "margin-top": "15px" }} onClick={() => this.handleDelete(templates.id)}>
                                {t('Delete')}
                            </p>
                         )}
                     />
                    } */}
                        <Can
                            perform="Clone_template"
                            yes={() => (
                                <p style={{ color: "#007bf8", cursor: "pointer", margin: '0px', padding: '5px' }} onClick={(e) => this.changeComponent(e, templates.id, 'clone')}>
                                    {/* {t('Clone')} */}
                                    <i title={t("Clone")} class="E-C-T E-C-T-clone"></i>
                                </p>
                            )}
                        />

                        {this.state.editbtnstatus === 'true' &&
                            <Can
                                perform="D_template"
                                yes={() => (
                                    <p style={{ color: "#007bf8", cursor: "pointer", margin: '0px', padding: '5px' }} onClick={(e) => this.handleDeletePopup(templates.id)}>
                                        <i title={t("Delete")} class="overall-sprite overall-sprite-mtdeletec"></i>
                                    </p>
                                )}
                            />
                        }

                        {this.state.editbtnstatus === 'true' &&
                            <Can
                                perform="R_template"
                                yes={() => (
                                    <p style={{ color: "#007bf8", cursor: "pointer", margin: '0px', padding: '5px' }} onClick={(e) => this.openEditor(e, templates.template_alias, templates.id, templates.type_id, 'word')}>
                                        {/* {t('Open Template')} */}
                                        <i title={t("Open template for word")} class="E-C-T E-C-T-template"></i>
                                    </p>
                                )}
                            />
                        }
                        {this.state.editbtnstatus === 'true' &&
                            <Can
                                perform="R_template"
                                yes={() => (
                                    <p style={{ color: "#007bf8", cursor: "pointer", margin: '0px', padding: '5px' }} onClick={(e) => this.openEditor(e, templates.template_alias, templates.id, templates.type_id, 'excel')}>
                                        {/* {t('Open Template')} */}
                                        <i title={t("Open template for excel")} class="E-C-T E-C-T-template"></i>
                                    </p>
                                )}
                            />
                        }
                    </div>
                </td>

            </tr>
        })

        const data = this.state.manualDocs[this.state.manualtabkey] !== undefined ?
            Object.values(this.state.manualDocs[this.state.manualtabkey]).map(data => {
                return (
                    <tr id={data.id}>
                        <td>{data.d_code}</td>
                        <td>{data.d_name}</td>
                        <td>{data.d_version}</td>
                        <td>{data.f_code}-{data.f_name}</td>
                    </tr>
                )
            }) : [];

        const popUp = (
            <reactbootstrap.Modal
                size="xl"
                show={this.state.show}
                onHide={this.handlehide}
                dialogClassName="delete_popup_modal"
                aria-labelledby="example-custom-modal-styling-title">
                <reactbootstrap.Modal.Header closeButton style={{ borderBottom: 'none', height: '0px' }} />
                <reactbootstrap.Container className="">
                    <reactbootstrap.Modal.Body>
                        <div className="col-lg-12 p-0">
                            <reactbootstrap.Tabs
                                id="controlled-tab-example"
                                activeKey={this.state.manualtabkey}
                                onSelect={key => this.setState({ manualtabkey: key })}>
                                {
                                    this.state.linkedManuals.map(function (values, key) {
                                        return (
                                            <reactbootstrap.Tab eventKey={values.value} title={values.label}>
                                            <br />
                                                <div style={{ 'height': '275px', 'overflowY': 'auto', 'scrollbar-width': 'thin' }}>
                                                    <reactbootstrap.Table striped bordered hover>
                                                        <thead style={{ backgroundColor: '#EC661C', color: '#fff', textAlign: 'center', position: 'sticky', top: '0'}}>
                                                            <tr>
                                                                <th style={{ width: '28%' }}>{t('Document code')}</th>
                                                                <th style={{ width: '28%' }}>{t('Document name')}</th>
                                                                <th style={{ width: '20%' }}>{t('Version')}</th>
                                                                <th style={{ width: '24%' }}>{t('Folder')}</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody >
                                                            {data}
                                                        </tbody>
                                                    </reactbootstrap.Table>
                                                </div>
                                            </reactbootstrap.Tab>
                                        )
                                    }, this)
                                }
                            </reactbootstrap.Tabs>
                            {this.state.delete === true && <tr className=" alert text-center">{t('No records found')}</tr>}
                            {this.state.delete1 === true && <tr className=" alert text-center">{t('But this template is attached to a layout')}</tr>}
                        </div>
                    </reactbootstrap.Modal.Body>
                </reactbootstrap.Container>
                <reactbootstrap.Modal.Footer>
                    <reactbootstrap.Button onClick={() => this.handlePopCancel()}>{t('Cancel')}</reactbootstrap.Button>
                        &nbsp;&nbsp; &nbsp;&nbsp;
                       {this.state.delete === true && <reactbootstrap.Button onClick={() => this.handleOk()}>{t('Delete')}</reactbootstrap.Button>} {/* change it to this.state.layoutExist to hide delete button if layout linked to template */}
                </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );

        let active = this.state.active;
        let pages = [];
        if (this.state.count > 0)
            for (let number = 1; number <= this.state.count; number++) {
                pages.push(
                    <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
                        {number}
                    </Pagination.Item>,
                );
            }
        if (as4_or_site) {
            return (
                <Can
                    perform="E_template,D_template,Clone_template,R_template"
                    yes={() => (
                        <div className='container py-4'>
                            <div className="row">

                                <reactbootstrap.Col lg={6} className="pl-0">
                                    {/* <div className="justify-content-center"> */}
                                    {/* <div className="text-center"> */}
                                    <div style={{ display: 'flex' }} >
                                        <input className="form-control search-box-border  mb-2" placeholder={t("What are you looking for ?")} onChange={this.searchData} /><br />
                                        <reactbootstrap.Button variant="link">
                                            <Can
                                                perform="E_template"
                                                yes={() => (
                                                    <i title={t("Add Template ")} onClick={(e) => this.changeComponent(e)} class="layout-template layout-template-template"></i>
                                                )}
                                            />
                                        </reactbootstrap.Button><br />
                                    </div>

                                    <div className='card'>
                                        <reactbootstrap.Table style={{ marginBottom: '0px' }} responsive striped bordered hover size="sm" className="main-data-table">
                                            <thead>
                                                <tr>
                                                    <th>{t('Template')}</th>
                                                    <th>{t('Template category')}</th>
                                                    <th>{t('Actions')}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {templates.length == 0 && <div>{t('No records found')}</div>}
                                                {templatesdata}
                                            </tbody>

                                        </reactbootstrap.Table>
                                    </div>
                                    <div className='text-center mt-3' style={{}}>
                                        {pages.length > 1 && <Pagination size="md">{pages}</Pagination>}
                                    </div>
                                    {/* </div> */}
                                    {/* </div> */}
                                </reactbootstrap.Col>
                                {popUp}
                                {this.state.component === 'true' && <reactbootstrap.Col lg={6}> {/*<h5>{t('Create Template')} </h5>*/}<Templates updateComponent={this.updateComponent.bind(this)} updateComponentCancel={this.updateComponentCancel.bind(this)} id={this.state.formId} type={this.state.type} tabId={this.state.tabId} /></reactbootstrap.Col>}

                            </div>
                        </div>
                    )}
                    no={() =>
                        <AccessDeniedPage />
                    }
                />
            );
        }
        else {
            return (
                <AccessDeniedPage />
            )
        }
    }
}
export default translate(TemplateList);


{/* <i class="E-C-T E-C-T-clone"></i>
<i class="E-C-T E-C-T-clonec"></i>
<i class="E-C-T E-C-T-edit"></i>
<i class="E-C-T E-C-T-editc"></i>
<i class="E-C-T E-C-T-template"></i>
<i class="E-C-T E-C-T-templatec"></i> */}
