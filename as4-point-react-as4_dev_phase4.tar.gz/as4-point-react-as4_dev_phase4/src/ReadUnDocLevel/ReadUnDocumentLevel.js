import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap'
import { datasave } from '../_services/db_services';
import { translate } from '../language';




class ReadUnDocumentLevel extends Component {
    constructor(props) {
        super(props)
        this.state = {
            allDetails: [],
            convDetails: [],
            didStatus: false,
            statusText: 'Loading',
            t:props.t
        }
    }

    displayConversation(id) {
        var data = [];
        var convData = this.state.convDetails["'" + id + "'"];
        const {t} = this.state;
        convData.map(key => {
            data.push(
                <div>
                    <p> {t("Person name:")}{key.person_name}</p>
                    {key.comment_type == 2 ? <p>{t("comment:")} {key.comment}</p> : <p>{t("feedback:")}{key.comment} </p>}
                </div>)
        })
        return data;
    }
    displayDetails() {
        var data = [];

        this.state.allDetails.map(key => {

            if (key.conversation) {
                data.push(
                    <tr>
                        <td>{key.person_name}</td>
                        <td>{key.read_at}</td>
                        <td><div>{this.displayConversation(key.id)}</div></td>
                        <td>OK</td>
                    </tr >
                )


            } else {
                data.push(
                    <tr>
                        <td>{key.person_name}</td>
                        <td>{key.read_at}</td>
                        <td>----</td>
                        <td>OK</td>
                    </tr>
                )
            }

        })
        return data;
    }
    render() {
      const {t} =this.state;
        if (this.state.didStatus) {
            return <div>
                <reactbootstrap.Table>
                    <thead>
                        <tr>
                            <th>{("Person name")}</th>
                            <th>{t("Read at")}</th>
                            <th>{t("Comment")}</th>
                            <th>{t("Understood")}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.displayDetails()}
                    </tbody>
                </reactbootstrap.Table>
            </div>
        } else {
            return (
                <div>
                    {this.state.statusText}
                </div>
            );
        }

    }
    componentDidMount() {
        datasave.service(window.GET_READUN_BYDOCID + '/' + this.props.match.params.docId, 'GET')
            .then(response => {
                console.log(response);
                if (response['status'] == 200) {
                    this.setState({
                        allDetails: response['AllDetails'],
                        convDetails: response['ConvDetails'],
                        didStatus: true,
                    })
                } else {
                    this.setState({
                        statusText: 'No data'
                    })
                }

            })
    }
}
export default translate(ReadUnDocumentLevel);
