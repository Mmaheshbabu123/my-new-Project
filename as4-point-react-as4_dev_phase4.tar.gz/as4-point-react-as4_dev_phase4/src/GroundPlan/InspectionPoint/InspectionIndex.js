import React, { Component } from 'react';
import {translate} from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import Inpectionpoint from './Details/CreateInspectionPoint';

class InspectionIndex extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t:props.t,
      activeTab: 0,
      InpectionId: this.props.buildingId,
    }
    this.handleSelectTab = this.handleSelectTab.bind(this);
  }

  handleSelectTab(e) {
    this.setState({
      activeTab:parseInt(e)
    });
  }

  render() {
    const {t} = this.state;
    const {activeTab, buildingId } = this.state;

    return (
      <div className='container py-2' >
        <div className='row justify-content-center' >
          <div className='col-lg-12 col-md-12 float-left px-0' >
            <div className='card-header' style = {{textAlign: "center"}} > <p>{t('Inspectionpoint details')}</p> </div>
              <reactbootstrap.Container className="p-1">
                <reactbootstrap.Form >
                  <reactbootstrap.Tabs id="controlled-tab-example" activeKey={activeTab} onSelect={(e) => this.handleSelectTab(e)}>
                    <reactbootstrap.Tab eventKey={0} title={t("Details")}>
                      <Inpectionpoint parentId={buildingId}/>
                    </reactbootstrap.Tab>
                  </reactbootstrap.Tabs>
                </reactbootstrap.Form>
              </reactbootstrap.Container>
          </div>
        </div>
      </div>
    )
  }
}

export default translate(InspectionIndex);
