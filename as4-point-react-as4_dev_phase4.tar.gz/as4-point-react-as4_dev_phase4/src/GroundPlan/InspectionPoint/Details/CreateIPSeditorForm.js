import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import { translate } from '../../../language';
import { Button, Form, FormGroup } from 'react-bootstrap';
import MultiSelect from '../../../_components/MultiSelect';
import { reducers } from '../../Building/Reducers/reducers';
import React, { useState, useEffect } from 'react';
import { OCAlert } from '@opuscapita/react-alerts';
import useFetch from "./useFetch";
import TodoLinkingComponent from './TodoLinkingComponent';
import './inspection.css';
var prevCodeName = '';

const CreateIPSeditorForm = props => {
  const MFD_DATA = useFetch(window.GET_MANUAL_FOLDER_WEBFORMS, 'GET');
  const report_data = useFetch(window.GET_ALL_WEBFORM_REPORTS_DETAILS, 'GET');
  const templateReportsOPtions = (report_data.length > 0 || report_data.length === undefined) ? Object.values(report_data.webform_template) : [];
  const customReportOptions = (report_data.length > 0 || report_data.length === undefined) ? Object.values(report_data.custom_report) : [];
  const webformReportOptions = (report_data.length > 0 || report_data.length === undefined) ? Object.values(report_data.webform_report) : [];
  const kpiReports = (report_data.length > 0 || report_data.length === undefined) ? Object.values(report_data.kpi_reports) : [];

  const manualOptions = MFD_DATA.manuals !== undefined ? MFD_DATA.manuals : [];
  const folderOptions = MFD_DATA.folders !== undefined ? MFD_DATA.folders : [];
  const webformOptions = MFD_DATA.webforms !== undefined ? MFD_DATA.webforms : [];
  const subFolderIds = MFD_DATA.subFolderIds !== undefined ? MFD_DATA.subFolderIds : [];
  const allWebforms = MFD_DATA.allWebforms !== undefined ? MFD_DATA.allWebforms : [];
  const docOptionsresponse = MFD_DATA.documents !== undefined ? MFD_DATA.documents : [];
  const allDocuments = MFD_DATA.allDocuments !== undefined ? MFD_DATA.allDocuments : [];

  const t = props.t;
  // const [dbResponse, setResponse] = useState([]);
  const [state, setData] = useState({
    layerData: {
      selectedManuals: [],
      selectedManuals1: [],
      selectedfolders: [],
      selectedfolders1: [],
      selectedDocs: [],
      selectedWebform: [],
      selectedtemplateReports: [],
      selectedcustomReports: [],
      selectedwebformReports: [],
      selectedKpiReports : [],
      description: '',
      uploadMessage: false,
      formatWarning: false,
      sizeWarning: false,
      file_id: [],
      todoData : {},
    },
    selectedEntity : 'general',
    selectedLayer: props.layers[0].value,
    name: '',
    code: '',
    name_error: '',
    code_erroe: '',
    subTabKey : 'general',

    use_existing_file: '',
    url: window.backendURL,
    use_existing_file_name: props.t('Choose image'),
    file_name: props.t('Click here to add images'),
    use_existing_file_edit_img: '',
    file_id: [],
    file_path: '',
    isDisable: false,
    data: {},
    parent_id: (props.buildingId !== undefined) ? props.buildingId : '',
    parent_type: '',
    errors: {},
    submitted: false,
    loading: false,
    sucess: '',
    floorDisabled: 'disable',
    dataLoading  : true,
  })

  const updateTodoData = (obj) => {
    let data = {...state.layerData};
    const { selectedLayer } = state;
    data = {...data,
      [selectedLayer] : {...data[selectedLayer],
        todoData : obj,
      }
    }
    setData({...state, layerData : data })
  }

  useEffect(() => {
    let url = '';
    let data = [];
    if (props.flow === 1 || props.flow === 0) {
       data = { ip_id: props.flow ? props.ipid : 0, parent_id : props.floorObj.value };
       url = window.FETCH_INSPECTION_POINT;
   }else {
      data = props.layerObj; url = window.GET_IPL_DATA
    }
    datasave.service(url, 'POST', data)
      .then(response => {
        if (response.status === 200) {
          console.log(response);
          props.flow === 2 ? constructLayerDataObj(response.data)
            : constructLayerObj(response.data, props.flow)
        } else {
          constructLayerObj()
        }
      })
  }, []);

  const constructLayerDataObj = (response) => {
    let name, code;
    let layerData = {};
    props.layers.map(layer => {
      let data = response[layer.value] !== undefined ? response[layer.value] : [];
      name = data.inspection_details !== undefined ? data.inspection_details.name : '';
      code = data.inspection_details !== undefined ? data.inspection_details.code : '';
      let mdfData = data.mfd_data !== undefined ? data.mfd_data : [];
      let report_data = data.report_data !== undefined ? data.report_data : [];
      const selected_data = data.selected_data;
      const man_ids = mapfilter(Object.values(mdfData.manuals));
      const fol_ids = mapfilter(Object.values(mdfData.folders));
      const fol_selected = handleFilter(man_ids, selected_data.folders);
      const doc_selected = handleFilter(fol_ids, selected_data.document);
      let todoData = data.todoData !== undefined ? data.todoData : [];
      todoData = constructTodoResponse(todoData);
      let obj = {
        [layer.value]: {
          ...state.layerData,
          selectedManuals: mdfData.manuals !== undefined ? Object.values(mdfData.manuals) : [],
          selectedfolders: mdfData.folders !== undefined ? Object.values(mdfData.folders) : [],
          selectedDocs: mdfData.documents !== undefined ? Object.values(mdfData.documents) : [],
          selectedfolders1: [],
          selectedManuals1: [],
          selectedWebform: [],
          selectedtemplateReports: Object.values(report_data.template_details),
          selectedwebformReports: Object.values(report_data.report_details),
          selectedcustomReports: Object.values(report_data.custom_details),
          selectedKpiReports : report_data.kpi_details ? Object.values(report_data.kpi_details) : [],
          description: data.des_details.length > 0 ? (data.des_details[0].description !== undefined ? data.des_details[0].description : '') : '',
          uploadMessage: false,
          formatWarning: false,
          sizeWarning: false,
          file_id: data.file_details !== undefined ? data.file_details : [],
          folderOptions: fol_selected,
          docOptions: doc_selected,
          todoData  : todoData,
        }
      };
      layerData = { ...layerData, ...obj }
    })
    prevCodeName = `${code}-${name}`;
    setData({
      ...state,
      layerData: layerData,
      code: code, name: name,
      dataLoading : false,
    })
  }

  const constructTodoResponse = (data) => {
    let response = {};
    Object.keys(data).map(obj => {
      var temp = {
        subActionData   : data[obj].subActionData ? data[obj].subActionData : [],
        elementOptios   : data[obj].elementOptios ? data[obj].elementOptios : [],
        selectedWebform : data[obj].selectedWebform ? data[obj].selectedWebform : {value:'',label:''},
        selectedManuals : [],
        selectedfolders : [],
        selectedElements: data[obj].selectedElements ? data[obj].selectedElements : [],
        color           : data[obj].color ? data[obj].color : '',
        colorRule       : data[obj].colorRule ? data[obj].colorRule : [],
        webform_id      : data[obj].webform_id ? data[obj].webform_id : 1,
        treeData        : data[obj].treeData ? data[obj].treeData : [],
        openNodes       : [],
        deleteclick     : false,
        index           : undefined,
        activeKey       : undefined,
        showworkflow    : 1,
        disableButtons  : true,
        disableButtons_c: true,
        orgArrayIds     : window.WEBFORM_ORG_ID,
        showRuleButtons : false,
        showRuleButtons_c : false,
      }
      return response[obj] = temp;
    });
    return response;
  }

  const constructLayerObj = (data = '', flow = 0 ) => {
    let code = data.code ? data.code : `${props.buildingObj.code}.${props.floorObj.code}.${data}`;
    let name = data.name ? data.name : '';
    let obj = {};
    props.layers.map(layer => {
      obj = { ...obj, [layer.value]: state.layerData }
    })
    prevCodeName = `${code}-${name}`;
    setData({ ...state, layerData: obj,
      name: name,
      code: code,
      dataLoading:false,
    })
  }

  const handleCancel = () => {
    props.closePopup();
  }

  const handleFilter = (selctIds, dataObj) => {
    let data = [];
    for (var i = 0; i < selctIds.length; i++) {
      if (dataObj[selctIds[i]] !== undefined) {
        Array.prototype.push.apply(data, Object.values(dataObj[selctIds[i]]))
      }
    }
    return data;
  }

  const handleChange = (event) => {
    const { name, value } = event.target;
    state.errors[name] = '';
    setData({
      ...state,
      [name]: value,
      name_error: '',
      code_error: '',
    });

  }

  const handleChangeOptions = async (e) => {
    const { selectedLayer } = state;
    let data = { ...state.layerData };
    var ids = mapfilter(e);
    let folders = handleFilter(ids, folderOptions);
    let subFolders = getSubFoloderIds(folders);
    let docOptions = handleFilter(subFolders, docOptionsresponse);
    data = {
      ...data,
      [selectedLayer]: {
        ...(data[selectedLayer] !== undefined ? data[selectedLayer] : {}),
        selectedManuals: e,
        folderOptions: folders,
        docOptions: docOptions,
      }
    }
    setData({
      ...state,
      layerData: data
    });
  }

  const handleChangeFolders = async (e) => {
    const { selectedLayer } = state;
    let data = { ...state.layerData };
    let subFolders = getSubFoloderIds(e);
    let docs = handleFilter(subFolders, docOptionsresponse);
    data = {
      ...data,
      [selectedLayer]: {
        ...(data[selectedLayer] !== undefined ? data[selectedLayer] : {}),
        selectedfolders: e,
        docOptions: subFolders.length > 0 ? docs : allDocuments,
      }
    }
    setData({
      ...state,
      layerData: data
    });
  }

  const handleChangeDocs = async (e) => {
    const { selectedLayer } = state;
    let data = { ...state.layerData };
    data = {
      ...data,
      [selectedLayer]: {
        ...(data[selectedLayer] !== undefined ? data[selectedLayer] : {}),
        selectedDocs: e,
      }
    }
    setData({
      ...state,
      layerData: data
    });
  }

  const handleDocumentReportChangeOptions = (e, type) => {
    const { selectedLayer } = state;
    let data = { ...state.layerData };
    data = {
      ...data,
      [selectedLayer]: {
        ...(data[selectedLayer] !== undefined ? data[selectedLayer] : {}),
        [type]: e,
      }
    }
    setData({
      ...state,
      layerData: data
    });
  }

  const getSubFoloderIds = (data) => {
    let temp = [];
    data.map(val => {
      if (subFolderIds[val.value]) {
        temp = temp.concat(val.value);
        temp = temp.concat(subFolderIds[val.value]);
      } else {
        temp = temp.concat(val.value);
      }
    })
    return temp;
  }

  const mapfilter = (d) => {
    return d.map(obj => { return obj['value'] });
  }

  const getSubmitData = () => {
    var parent_id = props.floorObj.value;
    var parent_type = window.FLOOR_ENTITY_TYPE_ID;
    let data = {
      name: state.name,
      description: state.description,
      code: state.code,
      file_id: [],
      file_path: [],
      selectedtemplateReports: [],
      selectedwebformReports: [],
      selectedKpiReports : [],
      selectedcustomReports: [],
      selectedManuals: [],
      selectedfolders: [],
      selectedDocs: [],
      parent_id: parent_id,
      parent_type: parent_type,
      linked_data: state.layerData,
      UniqueKey: props.drop_id,
      building_id : props.buildingObj.value,
      floor_id : props.floorObj.value,
      parentCode : `${props.buildingObj.code}.${props.floorObj.code}`
    }

    return data;
  }

  const handleSubmit = () => {
    if (validateForm()) {
      const details = getSubmitData();
      let url = props.flow === 0 ? window.INSERT_IPL_DATA : `${window.UPDATE_IPL_DATA}/${props.ipid}/${props.drop_id}`;
      datasave.service(url, 'POST', details)
        .then(resultObj => {
          if (resultObj.status === 200) {
            OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
            if (props.flow === 0) {
              props.updateInspectionsData(resultObj.data);
            } else if (props.flow === 1) {
              props.updateDroppedElementData(resultObj, 1);
            } else {
              let label = `${resultObj.data.code}-${resultObj.data.name}`;
              let result = {
                id: resultObj.data.id,
                value: resultObj.data.id,
                label: label,
              };
              props.closePopup(result, props.layerObj);
            }
          } else {
            if (resultObj.error.name || resultObj.error.number || resultObj.error.code) {
              setData({
                ...state,
                errors: resultObj.error,
              })
            } else {
              OCAlert.alertWarning(t('Something went wrong in saving data'), { timeOut: window.TIMEOUTNOTIFICATION });
            }
          }
        }
        );
    }
  }


  const validateForm = () => {
    let errors = {};
    let formIsValid = true;
    if (!state.name) {
      formIsValid = false;
      errors["name"] = "Please enter inspection point name";
    }
    if (!state.code) {
      formIsValid = false;
      errors["code"] = "Please enter  inspection point code.";
    }
    setData({
      ...state,
      errors: errors
    });
    return formIsValid;
  }

  const handleGeneralTab = (e, name) => {
    const { selectedLayer } = state;
    let data = { ...state.layerData };
    data = {
      ...data,
      [selectedLayer]: { ...data[selectedLayer], [name]: e.target.value }
    }
    setData({
      ...state,
      layerData: data
    });
  }

  const handleFileChanges = async (e, type) => {
    let data = { ...state.layerData };
    const { selectedLayer } = state;
    if (type === 'upload') {
      let response = await reducers.uploadImage(e);
      if (response.status === 200) {
        var obj = {};
        obj['file_id'] = response.data.file_id[0];
        obj['file_name'] = response.data.originalfname;
        obj['file_path'] = response.data.filepath;
        obj['formatWarning'] = false;
        obj['sizeWarning'] = false;
        obj['uploadMessage'] = true;
        data = {
          ...data,
          [selectedLayer]: {
            ...(data[selectedLayer] !== undefined ? data[selectedLayer] : {}),
            file_id: [...data[selectedLayer].file_id, obj],
            formatWarning: false,
            sizeWarning: false,
          }
        }
      } else {
        data = {
          ...data,
          [selectedLayer]: {
            ...(data[selectedLayer] !== undefined ? data[selectedLayer] : {}),
            formatWarning: response.formatWarning,
            sizeWarning: response.sizeWarning,
            uploadMessage: false,
          }
        }
      }
    } else if (e !== 0) {
      // await reducers.removeImage(e);
      var filterArrayObj = data[selectedLayer].file_id.filter(selected => (selected.file_id !== e));
      data = {
        ...data,
        [selectedLayer]: {
          ...(data[selectedLayer] !== undefined ? data[selectedLayer] : {}),
          file_name: t('Choose image'),
          file_path: '',
          file_id: filterArrayObj,
        }
      }
    }
    setData({
      ...state,
      layerData: data
    });
  }

  const layerDetailTabs = () => {
    return (
      <reactbootstrap.Tabs
        onSelect={(key) => setData({ ...state, selectedEntity: key, subTabKey : key })}
        defaultActiveKey={'general'}
        disabled = {state.dataLoading}
      >
        <reactbootstrap.Tab eventKey={'general'} title={t('General settings')}>
          {generalTab()}
        </reactbootstrap.Tab>
        <reactbootstrap.Tab eventKey={'doc_link'} title={t('Linking documents')}>
          {linkingDocument()}
        </reactbootstrap.Tab>
        <reactbootstrap.Tab eventKey={'todo_link'} title={t("Linking to do's")}>
          {linkingTodos()}
        </reactbootstrap.Tab>
        <reactbootstrap.Tab eventKey={'reports_link'} title={t('Linking reports')}>
          {linkingReports()}
        </reactbootstrap.Tab>
      </reactbootstrap.Tabs>
    );
  }

  const { name, code, submitted, loading } = state;
  const generalTab = () => {
    let data = { ...state.layerData };
    let { selectedLayer } = state;
    return (
      <div>
        <reactbootstrap.FormGroup>
          <div className=" input-overall-sec ">
            <reactbootstrap.InputGroup className="">
              <div className="col-md-4 mob-popup-label" >
                <reactbootstrap.InputGroup.Prepend>
                  <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Inspectionpoint code')}:<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                </reactbootstrap.InputGroup.Prepend>
              </div>
              <div class="col-md-8 input-padd">
                <reactbootstrap.FormControl
                  placeholder={t("code")}
                  name="code"
                  aria-label="externalcode"
                  aria-describedby="basic-addon1"
                  value={code}
                  onChange={(e) => handleChange(e)}
                  className="input_sw "
                />
                <div style={{ color: 'red' }} className="error-block mt-2">{state.errors.code}</div>
              </div>
            </reactbootstrap.InputGroup>
          </div>
        </reactbootstrap.FormGroup>
        <reactbootstrap.FormGroup>
          <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
            <div className=" input-overall-sec ">
              <reactbootstrap.InputGroup className="">
                <div className="col-md-4 mob-popup-label" >
                  <reactbootstrap.InputGroup.Prepend>
                    <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Inspectionpoint name')}:<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                  </reactbootstrap.InputGroup.Prepend>
                </div>
                <div class="col-md-8 input-padd">
                  <reactbootstrap.FormControl
                    name="name"
                    autoFocus
                    placeholder={t("Inspectionpoint name")}
                    aria-label="Inspectionpoint name"
                    aria-describedby="basic-addon1"
                    value={name}
                    onChange={(e) => handleChange(e)}
                    className="input_sw "
                  />
                  <div style={{ color: 'red' }} className="error-block mt-2">{state.errors.name}</div>
                </div>
              </reactbootstrap.InputGroup>
            </div>
          </div>
        </reactbootstrap.FormGroup>
        <reactbootstrap.FormGroup>
          <div className=" input-overall-sec ">
            <reactbootstrap.InputGroup className="">
              <div className="col-md-4 mob-popup-label" >
                <reactbootstrap.InputGroup.Prepend>
                  <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Description')}:</reactbootstrap.InputGroup>
                </reactbootstrap.InputGroup.Prepend>
              </div>
              <div class="col-md-8 input-padd">
                <reactbootstrap.FormControl
                  as="textarea" rows="3"
                  name="description"
                  placeholder={"Inspectionpoint description"}
                  value={data[selectedLayer] ? data[selectedLayer].description : ''}
                  id="description"
                  onChange={(e) => handleGeneralTab(e, 'description')}
                  className="input_sw "
                />
              </div>
            </reactbootstrap.InputGroup>
          </div>
        </reactbootstrap.FormGroup>
        <reactbootstrap.FormGroup>
          <div className=" input-overall-sec ">
            <reactbootstrap.InputGroup className="">
              <div className="col-md-4 mob-popup-label" >
                <reactbootstrap.InputGroup.Prepend>
                  <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Building name')}:</reactbootstrap.InputGroup>
                </reactbootstrap.InputGroup.Prepend>
              </div>
              <div class="col-md-8 input-padd">
                <reactbootstrap.FormControl
                  aria-label="externalcode"
                  aria-describedby="basic-addon1"
                  value={props.buildingObj.label}
                  className="input_sw "
                  disabled={true}
                />
              </div>
            </reactbootstrap.InputGroup>
          </div>
        </reactbootstrap.FormGroup>
        <reactbootstrap.FormGroup>
          <div className=" input-overall-sec ">
            <reactbootstrap.InputGroup className="">
              <div className="col-md-4 mob-popup-label" >
                <reactbootstrap.InputGroup.Prepend>
                  <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Floor name')}:</reactbootstrap.InputGroup>
                </reactbootstrap.InputGroup.Prepend>
              </div>
              <div class="col-md-8 input-padd">
                <reactbootstrap.FormControl
                  aria-label="externalcode"
                  aria-describedby="basic-addon1"
                  value={props.floorObj.label}
                  className="input_sw "
                  disabled={true}
                />
              </div>
            </reactbootstrap.InputGroup>
          </div>
        </reactbootstrap.FormGroup>
        <reactbootstrap.FormGroup>
          <div className=" input-overall-sec ">
            <reactbootstrap.InputGroup className="">
              <div className="col-md-4 mob-popup-label" >
                <reactbootstrap.InputGroup.Prepend>
                  <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Upload image')}:</reactbootstrap.InputGroup>
                </reactbootstrap.InputGroup.Prepend>
              </div>
              <div className="col-md-8 custom-file input_sw">
                <input
                  type="file"
                  className="custom-file-input"
                  id="image"
                  name='image'
                  disabled={state.isDisable}
                  accept={window.DOC_TYPES['default']}
                  onChange={(e) => handleFileChanges(e, 'upload')}
                  onClick={(event) => event.target.value = null}
                  multiple="true"
                />
                <label className="custom-file-label input_sw" htmlFor="inputGroupFile01">
                  {state.file_name !== null && state.file_name}
                </label>
              </div>
            </reactbootstrap.InputGroup>
          </div>
        </reactbootstrap.FormGroup>
        <div style={{}} className="row col-md-12 mt-2">
          <div style={{ visibility: 'hidden' }} className="col-md-4">
            <h3>{t('Upload')}</h3>
          </div>
          {<div className="col-md-8">
            {data[selectedLayer] ? (data[selectedLayer].file_id.length > 0 &&
              file_handling) : null}
            {data[selectedLayer] ? (data[selectedLayer].formatWarning && data[selectedLayer].sizeWarning && <span style={{ color: "red" }}>{window.FILE_FORMAT_ERROR_MSG}{t('and size should be < 1MB')} </span>) : null}
            {data[selectedLayer] ? (data[selectedLayer].formatWarning && !data[selectedLayer].sizeWarning && <span style={{ color: "red" }}> {window.FILE_FORMAT_ERROR_MSG} </span>) : null}
            {data[selectedLayer] ? (!data[selectedLayer].formatWarning && data[selectedLayer].sizeWarning && <span style={{ color: "red" }}> {t('Size should be < 1MB')} </span>) : null}
          </div>}
        </div>
      </div>
    );
  }

  const file_handling = state.layerData[state.selectedLayer] ? state.layerData[state.selectedLayer].file_id.map(item => {
    return (
      <div>
        <div>  <span style={{ color: "black", display: 'inline-block', marginRight: '10px' }}>{item.file_name}</span>
        </div>
        <span style={{ color: "green", display: 'inline-block', marginRight: '10px' }}>{window.FILE_UPLOAD_SUCCESS}</span>
        <span style={{ display: 'inline-block', marginRight: '10px' }}>
          <i title="preview" style={{ 'cursor': 'pointer' }} class="webform-sprite webform-sprite-smallviewc" onClick={(e) => window.open(item.file_path, "_blank")}></i>
        </span>
        <span style={{ display: 'inline-block', marginRight: '10px' }}>
          <i title="Remove" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={(e) => { handleFileChanges(item.file_id, 'remove') }} />
        </span>
      </div>
    )
  }) : null;

  const linkingDocument = () => {
    let docs = state.layerData[state.selectedLayer] ? state.layerData[state.selectedLayer] : [];
    if(state.selectedEntity === 'doc_link' || state.selectedEntity === ''){
      return (
        <div style={{ marginTop: '20px' }}>
          <reactbootstrap.FormGroup>
            <reactbootstrap.InputGroup className="">
              <div className="col-md-2" style={{ padding: 0, margin: 0 }}>
                <reactbootstrap.InputGroup.Prepend>
                  <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Document')}:</reactbootstrap.InputGroup>
                </reactbootstrap.InputGroup.Prepend>
              </div>
              <div className="col-md-8">
                <div className="row">
                  <div style={{}} className='col-md-12 mb-3' >
                    <MultiSelect
                      options={manualOptions}
                      standards={docs.selectedManuals ? docs.selectedManuals : []}
                      id="Manuals"
                      value={[]}
                      handleChange={(e) => handleChangeOptions(e)}
                      isMulti={true}
                      placeholder={'Select manuals'}
                    />
                  </div>
                  <div style={{}} className='col-md-12 mb-3'>
                    <MultiSelect
                      options={docs.folderOptions ? docs.folderOptions : []}
                      standards={docs.selectedfolders ? docs.selectedfolders : []}
                      id="folders"
                      value={[]}
                      handleChange={(e) => handleChangeFolders(e)}
                      placeholder={'Select folders'}
                    />
                  </div>
                  <div style={{}} className='col-md-12 mb-3'>
                    <MultiSelect
                      options={docs.selectedManuals ? (docs.selectedManuals.length > 0 ? docs.docOptions : allDocuments) : allDocuments}
                      standards={docs.selectedDocs ? docs.selectedDocs : []}
                      id="docs"
                      value={[]}
                      handleChange={(e) => handleChangeDocs(e)}
                      placeholder={'Select documents'}
                    />
                  </div>
                </div>
              </div>
            </reactbootstrap.InputGroup>
          </reactbootstrap.FormGroup>
        </div>
      );
    }
  }

  const linkingTodos = () => {
    let data = { ...state.layerData };
    let { selectedLayer, selectedEntity } = state;
    if(selectedEntity === 'todo_link' || selectedEntity === ''){
      return(
        <TodoLinkingComponent
        manuals={manualOptions}
        folders={folderOptions}
        webforms={webformOptions}
        subFolderIds={subFolderIds}
        allWebforms={allWebforms}
        getSubFoloderIds={getSubFoloderIds.bind()}
        updateTodoData = {updateTodoData.bind()}
        data ={data[selectedLayer] ? data[selectedLayer].todoData : []}
        webelement_id = {-1}
        // handleDocumentReportChangeOptions={handleDocumentReportChangeOptions.bind()}
        />
      );
    }
  }

  const linkingReports = () => {
    let reports = state.layerData[state.selectedLayer] ? state.layerData[state.selectedLayer] : [];
    if(state.selectedEntity === 'reports_link' || state.selectedEntity ===  ''){
      return (
        <div style={{ marginTop: '20px' }}>
          <reactbootstrap.FormGroup>
            <reactbootstrap.InputGroup className="">
              <div className="col-md-2" style={{ padding: 0, margin: 0 }}>
                <reactbootstrap.InputGroup.Prepend>
                  <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Reports')}:</reactbootstrap.InputGroup>
                </reactbootstrap.InputGroup.Prepend>
              </div>
              <div className="col-md-8">
                <div className="row">
                  <div style={{}} className='col-md-12 mb-3' >
                    <MultiSelect
                      options={templateReportsOPtions}
                      standards={reports.selectedtemplateReports ? reports.selectedtemplateReports : []}
                      id="template"
                      value={[]}
                      handleChange={(e) => handleDocumentReportChangeOptions(e, 'selectedtemplateReports')}
                      isMulti={true}
                      placeholder={'Template'}
                    />
                  </div>
                  <div style={{}} className='col-md-12 mb-3'>
                    <MultiSelect
                      options={customReportOptions}
                      standards={reports.selectedcustomReports ? reports.selectedcustomReports : []}
                      id="custom"
                      value={[]}
                      handleChange={(e) => handleDocumentReportChangeOptions(e, 'selectedcustomReports')}
                      placeholder={'Custom report'}
                    />
                  </div>
                  <div style={{}} className='col-md-12 mb-3'>
                    <MultiSelect
                      options={webformReportOptions}
                      standards={reports.selectedwebformReports ? reports.selectedwebformReports : []}
                      id="webform"
                      value={[]}
                      handleChange={(e) => handleDocumentReportChangeOptions(e, 'selectedwebformReports')}
                      placeholder={'Webform report'}
                    />
                  </div>
                  <div style={{}} className='col-md-12 mb-3'>
                    <MultiSelect
                      options={kpiReports}
                      standards={reports.selectedKpiReports ? reports.selectedKpiReports : []}
                      id="kpi"
                      value={[]}
                      handleChange={(e) => handleDocumentReportChangeOptions(e, 'selectedKpiReports')}
                      placeholder={'KPI reports'}
                    />
                  </div>
                </div>
              </div>
            </reactbootstrap.InputGroup>
          </reactbootstrap.FormGroup>
        </div>
      );
    }
  }

  return (
    <div className='com-md-12 py-2' >
      <div className='justify-content-center' style={{ width: '100%', float: 'left' }} >
        <div className='col-lg-12 col-md-12 float-left px-0' >

          {state.dataLoading !== true ? <reactbootstrap.Container className="p-1">
            <reactbootstrap.Tabs
              onSelect={(key) => setData({ ...state, selectedLayer: parseInt(key), selectedEntity: '' })}
              defaultActiveKey={state.selectedLayer}
            >
              {props.layers.map(layer => <reactbootstrap.Tab
                eventKey={layer.value} title={layer.label} disabled = {state.dataLoading}>
                {layerDetailTabs()}
              </reactbootstrap.Tab>)}
            </reactbootstrap.Tabs>
            <FormGroup style={{ marginTop : state.subTabKey !== 'general' ? state.subTabKey !== 'todo_link' ? '230px' :0:0}}>
              <div style={{ float: 'right' }} className="organisation_list  mb-4">
                <a onClick={handleCancel} >{t('Cancel')}</a>
                  &nbsp;&nbsp;&nbsp;
              <Button style={{ fontSize: '14px' }} type="button" onClick={() => handleSubmit()} className="btn btn-primary" disabled={loading}>{t('Save')}</Button>
              </div>
            </FormGroup>
          </reactbootstrap.Container> :
          <div style={{textAlign:'center'}}>
            <reactbootstrap.Spinner animation="grow" variant="success" />
            <p>{t('Loading')}...</p>
          </div>
        }
        </div>
      </div>
    </div>
  )
}
export default translate(CreateIPSeditorForm);
