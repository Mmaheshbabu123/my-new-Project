import { useState, useEffect } from "react";
import { datasave } from '../../../_services/db_services';

export default function useFetch(url,type) {
  const [data, setData] = useState([]);

  useEffect(() => {
      async function dataLoad(){
    await datasave.service(url, type, '')
     .then(async response => response.data)
   .then(async data => setData(data));
 }
 dataLoad();
  }, []);

  return data;
}
