import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import {translate} from '../../../language';
import { Button, Form, FormGroup } from 'react-bootstrap';
import MultiSelect from '../../../_components/MultiSelect';
import { reducers } from '../../Building/Reducers/reducers';
import React, { useState, useEffect ,useRef} from 'react';
import { OCAlert } from '@opuscapita/react-alerts';
import useFetch from "./useFetch";
import './inspection.css';
const BasicDetailsForm = props => {
  const document_data1 =  useFetch(window.GETALLMANUALMANAGEMENTDETAILS,'GET');
  const report_data = useFetch(window.GET_ALL_WEBFORM_REPORTS_DETAILS,'GET');
  const manualOPtions = (document_data1.length > 0 || document_data1.length === undefined)?Object.values(document_data1.manual):[];
  const folderOptionsresonse = (document_data1.length > 0 || document_data1.length === undefined)?document_data1.folders:[];
  const   docOptionsresponse = (document_data1.length > 0 || document_data1.length === undefined)?document_data1.document:[];
  const templateReportsOPtions = (report_data.length > 0 || report_data.length === undefined)?Object.values(report_data.webform_template):[];
  const  customReportOptions =(report_data.length > 0 || report_data.length === undefined)?Object.values(report_data.custom_report):[];
  const webformReportOptions =(report_data.length > 0 || report_data.length === undefined)?Object.values(report_data.webform_report):[];

    const [state, setData] = useState({
    t:props.t,
    use_existing_file: '',
    url : window.backendURL,
    use_existing_file_name: props.t('Choose image'),
    file_name :props.t('Click here to add images'),
    use_existing_file_edit_img: '',
    file_id: [],
    file_path: '',
    isDisable:false,
    selectedManuals:[],
    selectedDocs:[],
    selectedfolders:[],
    selectedtemplateReports:[],
    selectedcustomReports:[],
    parent_id: (props.buildingId !== undefined) ? props.buildingId : '',
    parent_type:'',
    errors: {},
    name: '',
    code: '',
    name_error: '',
    code_erroe:'',
    description: '',
    submitted: false,
    loading: false,
    sucess: '',
    formatWarning   : false,
    sizeWarning     : false,
    floorDisabled:'disable',
    uploadMessage : false,
    selected_files:[],
  })

const file_handling = state.selected_files.map(item => {
return(
<div>
    <div>  <span style={{ color: "black", display:'inline-block', marginRight: '10px'  }}>{item.file_name}</span>
      </div>
    <span style={{ color: "green", display:'inline-block', marginRight: '10px'  }}>{window.FILE_UPLOAD_SUCCESS}</span>
    <span style={{display:'inline-block',  marginRight: '10px'}}>
        <i disabled = {disableFields} title="preview" style={{ 'cursor': 'pointer' }} class="webform-sprite webform-sprite-smallviewc" onClick={(e) => window.open(item.file_path, "_blank")}></i>
    </span>
    <span style={{display:'inline-block',  marginRight: '10px'}}>
        <i disabled = {disableFields} title="Remove" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec"  onClick={(e) => {handleFileChanges(item.file_id, 'remove')}}/>
    </span>
</div>
)
})
const handleFileChanges = async (e, type) => {
  if(type === 'upload'){
    let response = await reducers.uploadImage(e);
    if (response.status === 200){
      let data2 = [];
        var obj = {};
        obj['file_id'] = response.data.file_id[0];
        obj['file_name'] = response.data.originalfname;
        obj['file_path'] = response.data.filepath;
        obj['formatWarning'] = false;
        obj['sizeWarning'] = false;
        obj['uploadMessage'] = true;
      setData({...state,
            ['selected_files']: [...state['selected_files'], obj]
      })
      // console.log([...state['selected_files'], obj])
        if(props.fromEditor){
   props.handleChangeOptions(state,[...state['selected_files'], obj],9);}
    } else{
      setData({...state,
        formatWarning : response.formatWarning,
        sizeWarning   : response.sizeWarning,
        uploadMessage : false,
      })
    }
  } else if (e !== 0) {
    await reducers.removeImage(e);
    var filterArrayObj = state.selected_files.filter(selected => (selected.file_id !== e));
    setData({
      ...state,
      file_id   : 0,
      file_name : t('Choose image'),
      file_path : '',
      ['selected_files']: filterArrayObj,
    })
  }
}
const handleChangeOptions = async (e) =>{
var ids = await mapfilter(e);
let folders = await handleFilter(ids,folderOptionsresonse);
if(props.fromEditor){
props.handleChangeOptions(state,e,1);
}
setData({
...state,
selectedManuals:e,
folderOptions:folders,
});
}
const mapfilter = async (d) =>{
return  d.map(obj=>{return obj['value']});
}
const handleChangeFolders = async (e) =>{
 var ids = await mapfilter(e);
let docs = await handleFilter(ids,docOptionsresponse);
if(props.fromEditor ){
props.handleChangeOptions(state,e,2);
}
setData({
...state,
selectedfolders:e,
docOptions:docs,
});
}
const handleChangeReportOptions = async (e,selecttype) =>{

if(selecttype === 1) {

setData({

...state,
selectedtemplateReports:e,
});
}else if(selecttype === 2) {

setData({
...state,
selectedcustomReports:e,
});
}
else{

setData({

...state,
selectedwebformReports:e,
});
}
if(props.fromEditor){
props.handleChangeOptions(state,e,window.HANDLE_REOPRT_OPTIONS[selecttype]);
}
}
const handleChangeDocs = async (e) =>{

setData({
...state,
selectedDocs:e,
})
if(props.fromEditor){
props.handleChangeOptions(state,e,2);
}
}
 const handleFilter = async(selctIds,dataObj) =>{
    let data = [];
  for(var i = 0 ; i<selctIds.length;i++){
    if(dataObj[selctIds[i]]!== undefined){
    Array.prototype.push.apply(data, Object.values(dataObj[selctIds[i]]))
  }
};
return data;
  }
  const getParentDetails = () => {
    let data = {};
    if(props.current_type === 'buildingid'){
      data['parent_id'] = props.buildingid;
      data['parent_type'] = window.BUILDING_ENTITY_TYPE_ID;
    }
    else if(props.current_type === 'floor'){
      data['parent_id'] = props.id;
        data['parent_type'] = window.FLOOR_ENTITY_TYPE_ID;
    }
    else if(props.current_type === 'inspectionpoint'){
      data['parent_id'] = state.parent_id;
        data['parent_type'] = state.parent_type;
    }
    return data;
  }
  const handleChange = (event) =>{
    const { name, value } = event.target;
          state.errors[name] = '';

    setData({
      ...state,
      [name]: value,
      name_error: '',
      code_error: '',
     });
     if(props.fromEditor){
     props.handleChangeOptions(state,value,7);
     }
  }


  // console.log(state)

      const { description, t } = state;
     const formDisabled = (props.action == 1) ? 'disabled' : '';
     const disableFields = (props.action == 1) ? true : false;
  return (
      <div className='col-md-12 py-2 px-0' >
        <div className='justify-content-center' style={{width: '100%', float: 'left'}} >
          <div className='col-lg-12 col-md-12 float-left px-0' >
              <div className='card-header component-header'style = {{textAlign: "center", marginLeft: '0px'}} > <p>{t('Inspection point details')}</p> </div>
                <reactbootstrap.Container className="p-1">
                    <reactbootstrap.Form  className="inspectionFrom">
                       <fieldset disabled={formDisabled}>
                       <reactbootstrap.FormGroup>

                       <div className=" input-overall-sec ">
                       <reactbootstrap.InputGroup className="">
                       <div className="col-md-4" >
                         <reactbootstrap.InputGroup.Prepend>
                           <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Description')}:</reactbootstrap.InputGroup>
                         </reactbootstrap.InputGroup.Prepend>
                         </div>
                         <div class="col-md-8 ">
                         <reactbootstrap.FormControl
                           as="textarea" rows="3"
                           name="description"
                           placeholder={"Inspectionpoint description"}
                           value={description}
                           disabled = {disableFields}
                           id="description"
                           onChange={(e) => handleChange(e)}
                           className="input_sw "
                         />
                         </div>
                         </reactbootstrap.InputGroup>
                         </div>
                       </reactbootstrap.FormGroup>
                    <reactbootstrap.FormGroup>
                    <reactbootstrap.InputGroup className="">
                    <div className="col-md-4">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Document')}:</reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                      </div>
                    <div className = "col-md-8">
                         <div className= "row">
                              <div style={{  }} className='col-md-12 mb-3' >
                                     <MultiSelect
                                         options={manualOPtions}
                                         standards={state.selectedManuals}
                                         id="Manuals"
                                         value={[]}
                                         handleChange={(e) => handleChangeOptions(e)}
                                         isMulti={true}
                                         disabled = {disableFields}
                                         placeholder = {'Select manuals'}
                                       />
                              </div>

                               <div style={{  }} className='col-md-12 mb-3'>
                               <MultiSelect
                                 options={state.folderOptions}
                                 standards={state.selectedfolders}
                                   disabled = {disableFields}
                                 id="folders"
                                  value={[]}
                                 handleChange={(e) => handleChangeFolders(e)}
                                  placeholder = {'Select folders'}
                               />
                               </div>
                               <div style={{  }} className='col-md-12 mb-3'>
                               <MultiSelect
                                 options={state.docOptions}
                                 standards={state.selectedDocs}
                                 id="docs"
                                  value={[]}
                                  disabled = {disableFields}
                                 handleChange={(e) => handleChangeDocs(e)}
                                 placeholder = {'Select documents'}
                               />
                               </div>
                         </div>
                    </div>
                  </reactbootstrap.InputGroup>
                </reactbootstrap.FormGroup>
                <reactbootstrap.FormGroup>
                <reactbootstrap.InputGroup className="">
                <div className="col-md-4">
                  <reactbootstrap.InputGroup.Prepend>
                    <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Reports')}:</reactbootstrap.InputGroup>
                  </reactbootstrap.InputGroup.Prepend>
                  </div>
                <div className = "col-md-8">
                     <div className= "row">
                          <div style={{  }} className='col-md-12 mb-3' >
                                 <MultiSelect
                                     options={templateReportsOPtions}
                                     standards={state.selectedtemplateReports}
                                     id="template"
                                     value={[]}
                                     disabled = {disableFields}
                                     handleChange={(e) => handleChangeReportOptions(e,1)}
                                     isMulti={true}
                                     placeholder = {'Template'}
                                   />
                          </div>

                           <div style={{  }} className='col-md-12 mb-3'>
                           <MultiSelect
                             options={customReportOptions}
                             standards={state.selectedcustomReports}
                             id="custom"
                              value={[]}
                             handleChange={(e) => handleChangeReportOptions(e,2)}
                              placeholder = {'Custom report'}
                              disabled = {disableFields}
                           />
                           </div>
                           <div style={{  }} className='col-md-12 mb-3'>
                           <MultiSelect
                             options={webformReportOptions}
                             standards={state.selectedwebformReports}
                             id="webform"
                              value={[]}
                              disabled = {disableFields}
                             handleChange={(e) => handleChangeReportOptions(e,3)}
                             placeholder = {'Webform report'}
                           />
                           </div>
                     </div>
                </div>
              </reactbootstrap.InputGroup>
            </reactbootstrap.FormGroup>
            <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                    <reactbootstrap.InputGroup className="  ">
                        <div className="col-md-4" style={{paddingLeft: '26px'}}>
                            <reactbootstrap.InputGroup.Prepend>
                                <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Upload image:')}</reactbootstrap.InputGroup>
                            </reactbootstrap.InputGroup.Prepend>
                        </div>
                        <div className="col-md-8 custom-file " style={{marginLeft: "-30px"}}>
                            <input
                                type="file"
                                className="custom-file-input"
                                id="image"
                                name='image'
                                disabled = {state.isDisable}
                                accept={window.DOC_TYPES['default']}
                                onChange={(e) =>handleFileChanges(e, 'upload')}
                                onClick={(event)=> event.target.value = null}
                                multiple="true"
                            />
                            <label className="custom-file-label input_sw" htmlFor="inputGroupFile01">
                                {state.file_name !== null && state.file_name }
                            </label>
                        </div>
                    </reactbootstrap.InputGroup>
                </div>
            </reactbootstrap.FormGroup>
            <div style={{}} className="row col-md-12 mt-2">
                <div style={{ visibility: 'hidden' }} className="col-md-4">
                    <h3>{t("Upload")}</h3>
                </div>
                {!disableFields &&
                  <div className="col-md-8">
                    {state.selected_files.length > 0&&
                  file_handling
                  }
                    {state.formatWarning && state.sizeWarning && <span style={{ color: "red" }}>{window.FILE_FORMAT_ERROR_MSG}{t( 'and size should be < 1MB')} </span>}
                    {state.formatWarning && !state.sizeWarning && <span style={{ color: "red" }}> {window.FILE_FORMAT_ERROR_MSG} </span>}
                    {!state.formatWarning && state.sizeWarning && <span style={{ color: "red" }}> {t('Size should be < 1MB')} </span>}
                </div>}
            </div>
                       </fieldset>
                        </reactbootstrap.Form >
                </reactbootstrap.Container>
              </div>
            </div>
      </div>


  )
}
export default translate(BasicDetailsForm);
function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
