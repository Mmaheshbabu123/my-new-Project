import { datasave } from '../../../_services/db_services';
import { translate } from '../../../language';
import { Form } from 'react-bootstrap';
import MultiSelect from '../../../_components/MultiSelect';
import React, { useState, useRef, useEffect } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { create } from '../../../Webforms/Actions/CreateRule';
import DisplayRules from '../../../Webforms/WebElements/DisplayRules';
import SubActions from '../../../Webforms/Actions/SubActions';
import './inspection.css';
var SUBACTIONSDATA = '';
var WEBFORM_ID = 0;
var ACTION_OR_COLOR  = '';

const TodoLinkingComponent = (props) => {
  const t = props.t;
  const CONDITIONS = { action: 1, orgunit: 0, workflow: 0, control: 1 }
  const [state, setState] = useState({
    showAddWebform: false,
    selectedManuals: [],
    folderOptions: [],
    selectedfolders: [],
    webformOptions: [],
    color         : '#00FF00', //default green color
    selectedWebform: [],
    webformEdit  : 0,
    popUpShow: false,
    disableButtons: true,
    disableButtons_c: true,
    webform_id: 0,
    editclick: false,
    addOr : false,
    addAnd:false,
    oldKey : 0,
  });

  const prevPopUpShow = usePrevious(state.editclick);

  const handleChangeOptions = async (e) => {
    var ids = await mapfilter(e);
    let folders = await handleFilter(ids, props.folders);
    let subFolderIds = props.getSubFoloderIds(folders);
    let webformOptions = await handleFilter(subFolderIds, props.webforms);
    // props.handleDocumentReportChangeOptions(e, 'selectedManuals1');
    setState({
      ...state,
      selectedManuals: e,
      folderOptions: folders,
      webformOptions: webformOptions,
    });
  }

  const mapfilter = async (d) => {
    if(d){
      return d.map(obj => { return obj['value'] });
    }else{
      return [];
    }
  }
  const handleChangeFolders = async (e) => {
    let subFolderIds = props.getSubFoloderIds(e); //mapfilter(e) //
    let docs = await handleFilter(subFolderIds, props.webforms);
    // props.handleDocumentReportChangeOptions(e, 'selectedfolders1');
    setState({
      ...state,
      selectedfolders: e,
      webformOptions: subFolderIds.length > 0 ? docs : props.allWebforms,
    });
  }

  const handleFilter = async (selctIds, dataObj) => {
    let data = [];
    for (var i = 0; i < selctIds.length; i++) {
      if (dataObj[selctIds[i]] !== undefined) {
        Array.prototype.push.apply(data, Object.values(dataObj[selctIds[i]]))
      }
    }
    return data;
  }

  const handleChangeDocs = async (e) => {
    setState({
      ...state,
      selectedWebform: e,
    })
  }

  const createWebformRow = async () => {
    const { selectedWebform, selectedManuals, selectedfolders } = state;
    let webform_id = selectedWebform.value;
    if (state.oldKey !== webform_id) {
      await datasave.service(window.GET_ORGUNITS_AND_ELEMENTS + '/' + webform_id, 'GET')
        .then(res => {
          let data = {
            [webform_id]: {
              subActionData   : res.status === 200 ? res.data.orgUnits : [],
              elementOptios   : res.status === 200 ? res.data.elements : [],
              selectedElements: [],
              selectedManuals : selectedManuals,
              selectedfolders : selectedfolders,
              selectedWebform : selectedWebform,
              color           : '#00FF00',
              colorRule       : [],
              webform_id      : webform_id,
              editclick       : false,
              treeData        : [],
              openNodes       : [],
              deleteclick     : false,
              index           : undefined,
              activeKey       : undefined,
              showworkflow    : 1,
              disableButtons  : true,
              disableButtons_c: true,
              orgArrayIds     : window.WEBFORM_ORG_ID,
              showRuleButtons : false,
              showRuleButtons_c : false,
            }
          }
          let todoData = JSON.parse(JSON.stringify({...props.data}));
          delete todoData[state.oldKey];
          props.updateTodoData({ ...todoData, ...data });
          setState({
            ...state,
            selectedManuals : [],
            selectedfolders : [],
            selectedWebform : [],
            showAddWebform  : false,
            webformEdit     : false,
            oldKey          : 0,
          })
        })
    }
  }

  const handleColorChage = (e, webform_id) => {
    setState({...state, color : e.target.value });
    let data = { ...props.data };
    data = {...data, [webform_id]: {
        ...data[webform_id],
        color : e.target.value,
      }}
      props.updateTodoData(data);
  }

  const handleIdFieldChanges = (e, webform_id) => {
    let data = { ...props.data };
    updateActionData(data, webform_id, 'selectedElements', e);
  }

  const updateActionData = (data, webform_id, key, value) => {
    data = {...data, [webform_id]: {
        ...data[webform_id],
        [key]: value,
        disableButtons: true,
        showRuleButtons:false,
        showRuleButtons_c:false,
      }
    }
    props.updateTodoData(data);
  }

  const handleRule = (e, type, webform_id, from = '') => {
    ACTION_OR_COLOR = from !== '' ? 0 : 1;
    WEBFORM_ID = webform_id;
    setState({
      ...state,
      webform_id: webform_id,
      ruleclick: true,
      type: type,
      color : '#00FF00',
      popUpShow : true,
      addOr     : true,
      addAnd    : false,
    })
  }

  const handleEditDeleRule = async (e, type, webform_id, from = '') => {
    ACTION_OR_COLOR = from !== '' ? 0 : 1;
    let treeKey = ACTION_OR_COLOR ? 'treeData' : 'colorRule';
    WEBFORM_ID = webform_id;
    if (type) {
      setState({
        ...state,
        editclick: true, popUpShow: true, type: 0,
      })
    } else {
      let tree = await createTreeStructure('', '', true);
      let data = { ...props.data };
      updateActionData(data, webform_id, treeKey, tree);
    }
  }
  const handleTreeClick = (e, activekey = undefined, webform_id = 0, from = '') => {
    ACTION_OR_COLOR = from !== '' ? 0 : 1;
    WEBFORM_ID = webform_id;
    let data = { ...props.data };
    const { index, key, action, control, operator, orgid, value,
      workflow, orgname, type, name, controlType, valueId,
      workflowid, controlid, operatorId, showworkflow, valueType, isDateType, count, periodtype, category, color } = e;
    let openNodes = data[webform_id].openNodes;
    let node = activekey === undefined ? key : activekey
    if (openNodes.includes(node)) {
      var i = openNodes.indexOf(node);
      if (i !== -1) openNodes.splice(i, 1);
    } else {
      openNodes.push(node)
    }
    data = {
      ...data,
      [webform_id]: {
        ...data[webform_id],
        index: index, editaction: action,
        editcontrol: control, editoperator: operator, editorgname: orgname,
        editorgid: orgid, editvalue: value, editworkflow: workflow,
        editworkflowid: workflowid,
        edittype: parseInt(type), editauthor: name, editcontroltype: controlType,
        editcontrolid: parseInt(controlid),
        editoperatorid: parseInt(operatorId),
        activeKey: activekey !== undefined ? activekey : key,
        openNodes: openNodes,
        showworkflow: showworkflow,
        editvalueType: valueType,
        editisDateType: isDateType,
        conditions: CONDITIONS,
        category: category,
        count: count,
        periodtype: periodtype,
        disableButtons: from === 'color' ? true : false,
        showRuleButtons: from === 'color' ? false : true,
        disableButtons_c  : from === 'color' ? false : true,
        showRuleButtons_c : from === 'color' ? true : false,
        valueId : valueId,
        color   : color,
      }
    }
    props.updateTodoData(data);
  }

  const onHidePopup = () =>{
    setState({...state, popUpShow : false, addOr : false });
  }

  const changeComponent = async (saved, obj = {}) => {
    obj = {...obj, color : state.color};
    let treeKey = ACTION_OR_COLOR ? 'treeData' : 'colorRule';
    let data = { ...props.data };
    if (saved) {
      let ruleOrColorData = ACTION_OR_COLOR ? data[WEBFORM_ID].treeData : data[WEBFORM_ID].colorRule;
      const treeData = create.createRule(obj, ruleOrColorData, data[WEBFORM_ID]);
      if (ruleOrColorData.length == 0) {
        updateActionData(data, WEBFORM_ID, treeKey, treeData.tree);
      } else {
        let updatedData = await createTreeStructure(treeData.createdobj, data[WEBFORM_ID].index);
        data = {...data, [WEBFORM_ID]: {...data[WEBFORM_ID],
            [treeKey]: updatedData,
            showRuleButtons: false,
            showRuleButtons_c : false, }
          }
        props.updateTodoData(data);
      }
    }
    setState({...state, popUpShow: false, editclick: false, addOr : false })
  }

  const createTreeStructure = (obj = '', index = '', ruleRemove = false) => {
    let data = { ...props.data };
    let ruleOrColorData = ACTION_OR_COLOR ? data[WEBFORM_ID].treeData : data[WEBFORM_ID].colorRule;
    let treeData = ruleOrColorData;
    let onClickTreeData = data[WEBFORM_ID];
    let ruleEdit = state.editclick ? 1 : 0;
    Object.values(treeData).map((item, at) => {
      if (item.index == onClickTreeData.index) {
        if (ruleRemove) {
          treeData.splice(at, 1);
          return;
        } else {
          let index = ruleEdit ? at : treeData.length;
          obj.nodes = ruleEdit ? item.nodes : [];
          return treeData[index] = obj;
        }
      }
    })
    return treeData;
  }

  const sendEditData = () => {
    if (props.data[WEBFORM_ID]) {
      const {
        editaction, editauthor, editorgname, editorgid,
        editcontrol, editoperator, editvalue, editworkflow, editcontroltype,
        editworkflowid, editcontrolid, editoperatorid, editenter, editleave, editvalueType, editisDateType,
        count, periodtype, category, valueId } = props.data[WEBFORM_ID];
      if (state.editclick) {
        return {
          action: editaction,
          author: editauthor,
          orgid: editorgid,
          orgunit: editorgname,
          workflow: editworkflow,
          workflowid: editworkflowid,
          controlid: editcontrolid,
          control: editcontrol,
          controlType: editcontroltype,
          valueId: valueId,
          value: editvalue,
          operatorId: editoperatorid,
          operator: editoperator,
          onleave: editleave,
          onenter: editenter,
          valueType: editvalueType,
          isDateType: editisDateType,
          count: count,
          periodtype: periodtype,
          category: category
        }
      }
    }
    return {};
  }

  const colorDropDown = (addOr, color) => {
    return(
      <reactbootstrap.Form.Group controlId="formBasicEmail">
        <div className='row col-md-12' style={{ padding: 0, margin: 0 }}>
          <reactbootstrap.Form.Label className="col-md-3 p-0 m-0" style={{ color: 'rgb(236, 102, 28)', textAlign : 'center'}} >Color:</reactbootstrap.Form.Label>
          <div className="col-md-8 input-group input-padd" style={{ paddingLeft: '7%', margin: 0 }}>
            <reactbootstrap.FormControl
              name="color"
              as="select"
              value={addOr !== true ? (props.data[WEBFORM_ID] ? props.data[WEBFORM_ID].color : '') : color}
              onChange={(e) => handleColorChage(e, WEBFORM_ID)}
              className="input_sw">
              <option value='' > {'Select'}</option>
              <option value="#00FF00">{'Green'}</option>
              <option value="#FFA500">{'Orange'}</option>
              <option value="#FF0000">{'Red'}</option>
            </reactbootstrap.FormControl>
          </div>
        </div>
      </reactbootstrap.Form.Group>
    );
  }
  const displayPopUpForRuleAdd = () => {
    const { editclick, popUpShow, addOr, color } = state;
      let data = {...props.data};
      if(popUpShow !== prevPopUpShow){
        return (<reactbootstrap.Modal show={popUpShow} onHide={onHidePopup}>
          <reactbootstrap.Modal.Body>
          {
            <>
            {ACTION_OR_COLOR !== 1 ? colorDropDown(addOr, color) : null}
            <SubActions
              action={window.WEBFORM_CALCULATION}
              changeComponent={changeComponent}
              type={CONDITIONS}
              edit={editclick}
              data={sendEditData()}
              webelement_id={props.webelement_id}
              webform_id={data[WEBFORM_ID] ? data[WEBFORM_ID].webform_id : 1}
              apidata={data[WEBFORM_ID] ? data[WEBFORM_ID].subActionData : []}
              groundplan={1}
            />
            </>
          }
          </reactbootstrap.Modal.Body>
          </reactbootstrap.Modal>
        );
      }
  }

  const handleRemoveEditWebform = async (type, webform_id) => {
    let data = JSON.parse(JSON.stringify({...props.data }));
    if(type !== 'edit'){
      delete data[webform_id];
      setState({...state,
        selectedManuals : [],
        selectedfolders : [],
        selectedWebform : [],
      })
      props.updateTodoData(data);
      return;
    }else{
      let selectedManuals = data[webform_id].selectedManuals;
      let selectedfolders = data[webform_id].selectedfolders;
      let selectedWebform = data[webform_id].selectedWebform;
      var ids = await mapfilter(selectedManuals);
      let folders = await handleFilter(ids, props.folders);
      let subFolderIds = props.getSubFoloderIds(folders);
      let webformOptions = await handleFilter(subFolderIds, props.webforms);
      setState({...state,
        selectedManuals : selectedManuals,
        selectedfolders : selectedfolders,
        selectedWebform : selectedWebform,
        webformOptions  : webformOptions,
        folderOptions   : folders,
        showAddWebform  : true,
        webformEdit     : 1,
        oldKey          : webform_id,
      })
    }
  }

  return (
    <>
      <div className='col-md-12 m-0 p-0'>
        <div style={{ width: '100%', padding: '0' }}>
          <button type="button" class="btn btn-link">
            <i title="Add webform"
              className="col-md-4 "
              class="webform-sprite webform-sprite-createlistc"
              onClick={() => setState({ ...state, showAddWebform: !state.showAddWebform })}
            >
            </i>
          </button>

          {state.showAddWebform !== false && <div>
            <reactbootstrap.FormGroup>
              <reactbootstrap.InputGroup className="">
                <div className="col-md-2" style={{ padding: 0, margin: 0 }}>
                  <reactbootstrap.InputGroup.Prepend>
                    <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Webform')}:</reactbootstrap.InputGroup>
                  </reactbootstrap.InputGroup.Prepend>
                </div>
                <div className="col-md-8">
                  <div className="row">
                    <div style={{}} className='col-md-12 mb-3 px-0' >
                      <MultiSelect
                        options={props.manuals}
                        standards={state.selectedManuals}
                        id="Manuals"
                        value={[]}
                        handleChange={(e) => handleChangeOptions(e)}
                        isMulti={true}
                        placeholder={'Select manuals'}
                      />
                    </div>

                    <div style={{}} className='col-md-12 mb-3 px-0'>
                      <MultiSelect
                        options={state.folderOptions}
                        standards={state.selectedfolders}
                        id="folders"
                        value={[]}
                        handleChange={(e) => handleChangeFolders(e)}
                        placeholder={'Select folders'}
                      />
                    </div>
                    <div style={{}} className='col-md-12 mb-3 px-0'>
                      <MultiSelect
                        options={state.selectedManuals.length > 0 ? state.webformOptions : props.allWebforms}
                        standards={state.selectedWebform}
                        id="docs"
                        value={[]}
                        isMulti={false}
                        handleChange={(e) => handleChangeDocs(e)}
                        placeholder={'Select webform'}
                      />
                    </div>
                  </div>
                </div>
              </reactbootstrap.InputGroup>
            </reactbootstrap.FormGroup>
            <reactbootstrap.FormGroup style={{ marginTop: '10px 0 25px 0', width: '85%' }}>
              <div style={{ float: 'right' }} className="organisation_list">
                <reactbootstrap.Button
                  onClick={() => setState({ ...state, showAddWebform: false })}
                  variant="outline-warning">
                  {t('Close')}
                </reactbootstrap.Button>
                <span style={{ paddingLeft: '15px' }}></span>
                {state.webformEdit !== 1 ?
                <reactbootstrap.Button
                  onClick={createWebformRow}
                  variant="outline-success">
                  {t('Add')}
                </reactbootstrap.Button> :
                <reactbootstrap.Button
                  onClick={createWebformRow}
                  variant="outline-success">
                  {t('Update')}
                </reactbootstrap.Button>}
              </div>
            </reactbootstrap.FormGroup>
          </div>}
          <reactbootstrap.Table bordered responsive hover variant="" className = "groundPlanActionTable">
            <thead style={{backgroundColor: '#EC661C', color: '#fff', textAlign: 'center' }}>
              <tr>
                <th style={{ width: '22%' }} >{t('Webforms')}</th>
                <th style={{ width: '27%' }} >{t('Conditions')}</th>
                <th style={{ width: '27%' }} >{t('Color code')}</th>
                <th style={{ width: '25%' }} >{t('Identification')}</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(props.data).length > 0 ?
                <>
                  {Object.values(props.data).map(val => {
                    return (
                      <tr webform_id={val.webform_id} id={'id_' + val.webform_id}>
                        <td>
                          {val.selectedWebform.label}
                           <i title="Edit" style={{ 'cursor': 'pointer', display:'inline-block', margin: '0 8px 0 8px' }} class="overall-sprite overall-sprite-myeditc" onClick = {() => handleRemoveEditWebform('edit', val.selectedWebform.value)}></i>
                           <i title="Delete" style={{ 'cursor': 'pointer', display:'inline-block', }} class="overall-sprite overall-sprite-mtdeletec" onClick = {() => handleRemoveEditWebform('delete', val.selectedWebform.value)}> </i>
                        </td>
                        <td style = {{ padding : 0 }}>
                          {<reactbootstrap.Row className="row  mt-1 ">
                            {(val.showRuleButtons || val.treeData.length < 1) && <td className="mt-2 ml-3">
                                     <reactbootstrap.Button className="mb-2 mr-2" variant="outline-primary" onClick={(e) => handleRule(e, 0, val.webform_id)} disabled={val.treeData.length === 0 ? false    : val.disableButtons}> {t("Add OR")} </reactbootstrap.Button>
                              &nbsp;{<reactbootstrap.Button className="mb-2 " variant="outline-warning" onClick={(e) => handleEditDeleRule(e, 1, val.webform_id)} disabled={val.treeData.length === 0 ? true : val.disableButtons}> {t("Edit")}   </reactbootstrap.Button>}
                              &nbsp;{<reactbootstrap.Button className="mb-2" variant="outline-danger" onClick={(e) => handleEditDeleRule(e, 0, val.webform_id)} disabled={val.treeData.length === 0 ? true   : val.disableButtons}> {t("Remove")} </reactbootstrap.Button>}
                            </td>}
                            {val.treeData.length > 0 && <DisplayRules data={val.treeData} handleTreeClick={(e) => handleTreeClick(e, val.activekey, val.webform_id)} active={val.activeKey} openNodes={val.openNodes} groundplan={1} />}
                            {displayPopUpForRuleAdd()}
                          </reactbootstrap.Row>}
                        </td>
                        <td style = {{ padding : 0 }}>
                          {<reactbootstrap.Row className="row  mt-1 ">
                            {(val.showRuleButtons_c || val.colorRule.length < 1) && <td className="mt-2 ml-3">
                                      <reactbootstrap.Button className="mb-2 mr-2" variant="outline-primary" onClick={(e) => handleRule(e, 0, val.webform_id, 'color')} disabled={val.colorRule.length === 0 ? false    : val.disableButtons_c}> {t("Add OR")} </reactbootstrap.Button>
                               &nbsp;{<reactbootstrap.Button className="mb-2 " variant="outline-warning" onClick={(e) => handleEditDeleRule(e, 1, val.webform_id, 'color')} disabled={val.colorRule.length === 0 ? true : val.disableButtons_c}> {t("Edit")}   </reactbootstrap.Button>}
                               &nbsp;{<reactbootstrap.Button className="mb-2" variant="outline-danger" onClick={(e) => handleEditDeleRule(e, 0, val.webform_id, 'color')} disabled={val.colorRule.length === 0 ? true   : val.disableButtons_c}> {t("Remove")} </reactbootstrap.Button>}
                            </td>}
                            {val.colorRule.length > 0 && <DisplayRules data={val.colorRule} handleTreeClick={(e) => handleTreeClick(e, val.activekey, val.webform_id, 'color')} active={val.activeKey} openNodes={val.openNodes} groundplan={1} />}
                            {displayPopUpForRuleAdd()}
                          </reactbootstrap.Row>}
                        </td>
                        <td style = {{ padding : '5px' }}>
                          <reactbootstrap.Form.Group>
                            <reactbootstrap.Form.Label className="col-md-8 common-color ">
                              {t('Elements:')}
                            </reactbootstrap.Form.Label>
                            <div className="col-md-12 p-0 m-0">
                              <reactbootstrap.Form.Group>
                                <MultiSelect
                                  standards={val.selectedElements}
                                  options={val.elementOptios}
                                  isMulti={true}
                                  disabled={false}
                                  handleChange={(e) => handleIdFieldChanges(e, val.webform_id)}
                                />
                              </reactbootstrap.Form.Group>
                            </div>
                          </reactbootstrap.Form.Group>

                        </td>
                      </tr>
                    );
                  })}
                </> : null}
            </tbody>
          </reactbootstrap.Table>
        </div>

      </div>
    </>
  );
}
export default translate(React.memo(TodoLinkingComponent))
function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
