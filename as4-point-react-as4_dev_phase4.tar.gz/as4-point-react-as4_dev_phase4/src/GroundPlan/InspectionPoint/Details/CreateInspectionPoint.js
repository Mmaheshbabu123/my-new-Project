
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import {translate} from '../../../language';
import { Button, Form, FormGroup } from 'react-bootstrap';
import MultiSelect from '../../../_components/MultiSelect';
import { reducers } from '../../Building/Reducers/reducers';
import React, { useState, useEffect ,useRef} from 'react';
import { OCAlert } from '@opuscapita/react-alerts';
import useFetch from "./useFetch";
import './inspection.css';
const CreateInspectionPoint = props => {
  const document_data1 =  useFetch(window.GETALLMANUALMANAGEMENTDETAILS,'GET');
  const report_data = useFetch(window.GET_ALL_WEBFORM_REPORTS_DETAILS,'GET');
  const manualOPtions = (document_data1.length > 0 || document_data1.length === undefined)?Object.values(document_data1.manual):[];
  const folderOptionsresonse = (document_data1.length > 0 || document_data1.length === undefined)?document_data1.folders:[];
  const   docOptionsresponse = (document_data1.length > 0 || document_data1.length === undefined)?document_data1.document:[];
  const templateReportsOPtions = (report_data.length > 0 || report_data.length === undefined)?Object.values(report_data.webform_template):[];
  const  customReportOptions =(report_data.length > 0 || report_data.length === undefined)?Object.values(report_data.custom_report):[];
  const webformReportOptions =(report_data.length > 0 || report_data.length === undefined)?Object.values(report_data.webform_report):[];

  const prevProps = usePrevious(props);
  const [dbResponse, setResponse] = useState([]);
    const [state, setData] = useState({
        t:props.t,

    use_existing_file: '',
    url : window.backendURL,
    use_existing_file_name: props.t('Choose image'),
    file_name :props.t('Click here to add images'),
    use_existing_file_edit_img: '',
    file_id: '',
    file_path: '',
    isDisable:false,
    selectedManuals:[],
    selectedDocs:[],
    selectedfolders:[],
    selectedtemplateReports:[],
    selectedcustomReports:[],
    parent_id: (props.buildingId !== undefined) ? props.buildingId : '',
    parent_type:'',
    errors: {},
    name: '',
    code: '',
    name_error: '',
    code_erroe:'',
    description: '',
    submitted: false,
    loading: false,
    sucess: '',
    formatWarning   : false,
    sizeWarning     : false,
    floorDisabled:'disable',
    uploadMessage : false,
    selected_files:[],
  })

const setToInitialState = () => {
    setData({...state,
      use_existing_file: '',
      url : window.backendURL,
      use_existing_file_name: props.t('Choose image'),
      file_name :props.t('Choose image'),
      use_existing_file_edit_img: '',
      file_id: '',
      file_path: '',
      isDisable:false,
      selectedManuals:[],
      selectedDocs:[],
      selectedfolders:[],
      selectedtemplateReports:[],
      selectedcustomReports:[],
      parent_id: (props.buildingId !== undefined) ? props.buildingId : '',
      parent_type:'',
      errors: {},
      name: '',
      code: '',
      name_error: '',
      code_erroe:'',
      description: '',
      submitted: false,
      loading: false,
      sucess: '',
      formatWarning   : false,
      sizeWarning     : false,
      floorDisabled:'disable',
      selected_files:[],
      file_id:[],
    })
}
const handleFileChanges = async (e, type) => {
  if(type === 'upload'){
    let response = await reducers.uploadImage(e);
    if (response.status === 200){
      let data2 = [];
        var obj = {};
        obj['file_id'] = response.data.file_id[0];
        obj['file_name'] = response.data.originalfname;
        obj['file_path'] = response.data.filepath;
        obj['formatWarning'] = false;
        obj['sizeWarning'] = false;
        obj['uploadMessage'] = true;
      setData({...state,
               formatWarning:false,
               sizeWarning:false,
            ['selected_files']: [...state['selected_files'], obj]
      })
        if(props.fromEditor){
   props.handleChangeOptions(state,[...state['selected_files'], obj],9);}
    } else{
      setData({...state,
        formatWarning : response.formatWarning,
        sizeWarning   : response.sizeWarning,
        uploadMessage : false,
      })
    }
  } else if (e !== 0) {
    // await reducers.removeImage(e);
    var filterArrayObj = state.selected_files.filter(selected => (selected.file_id !== e));
    setData({
      ...state,
      file_id   : 0,
      file_name : t('Choose image'),
      file_path : '',
      ['selected_files']: filterArrayObj,
    });
    props.handleChangeOptions(state,filterArrayObj,9);
  }
}
  useEffect(() => {
     const {t} = state;
     async function dataLoad(){
                 if((props.ipid !== undefined && props.ipid !== null && props.ipid !== 1) && (props.action !== 2) && (props.current_type === 'inspectionpoint')){//props.parentId
                   let url;
                  if(props.fromEditor && props.flow){
                    url  = window.GET_IPL_DATA + '/' +  props.ipid + '/' + props.layer_id + '/' + props.drop_id;
                  }
                  else{
                    url = window.GET_INSPECTION_POINT_DATA + '/' + props.ipid;
                  }
                   await datasave.service(url, 'GET', )
                   .then(async response1 => {
                       if(response1.status === 200) {

                          setResponse(response1);
                          if(props.resultObj[props.layer_id] != undefined) {
                            setPrefilledValues(props.resultObj[props.layer_id] ,response1);
                          }
                          else {
                         setStateValues(response1);
                       }
                       } else {
                         OCAlert.alertWarning(t('Unable to fetch data'), { timeOut: window.TIMEOUTNOTIFICATION });
                       }
                     })
                   }
                   else{
                     setData({
                       ...state,
                       name: '',
                       code: '',
                       description: '',
                       use_existing_file_name: props.t('Choose file'),
                       file_name :props.t('Choose icon'),
                       use_existing_file_edit_img: '',
                       file_id: '',
                       file_path: '',
                       folderOptions:[],
                       docOptions:[],
                       selectedDocs:[],
                       selectedfolders:[],
                       selectedManuals:[],
                       selectedwebformReports:[],
                       selectedcustomReports:[],
                       selectedtemplateReports:[],

                     })
              }


       }
        dataLoad();
     }, [props.ipid,props.layer_id]);
      const setStateValues = async(response1) => {
        setToInitialState();
       const inspection_form_data = response1.data.inspection_details;
       const document_data = response1.data.mfd_data;
       const report_data = response1.data.report_data;
       const selected_data = response1.data.selected_data;
       const man_ids = await mapfilter(Object.values(document_data.manuals));
       const fol_ids = await mapfilter(Object.values(document_data.folders));
       const fol_selected = await handleFilter(man_ids,selected_data.folders);
       const doc_selected = await handleFilter(fol_ids,selected_data.document);
       setData({
         ...state,
         name: inspection_form_data.name,
          description:props.fromEditor ?
                       (response1.data.des_details.length > 0 ?(response1.data.des_details[0].description !== undefined ? response1.data.des_details[0].description : ''):'') : inspection_form_data.description,
         code: inspection_form_data.code,
        ['selected_files'] : response1.data.file_details,
         ['file_id']:response1.data.file_details,
        //  file_name: (response1.data.file_details.file_name !== undefined) ? response1.data.file_details.file_name : 'Choose icon',
          //file_path: (response1.data.file_details.file_path !== undefined) ? response1.data.file_details.file_path : '',
          //file_id : (response1.data.file_details.id !== undefined) ? response1.data.file_details.id : null,
          parent_id :inspection_form_data.parent_id,
         parent_type:inspection_form_data.parent_type,
         folderOptions:fol_selected,
         docOptions:doc_selected,
         selectedtemplateReports:Object.values(report_data.template_details),
         selectedwebformReports:Object.values(report_data.report_details),
         selectedcustomReports:Object.values(report_data.custom_details),
         selectedManuals:Object.values(document_data.manuals),
         selectedfolders:Object.values(document_data.folders),
         selectedDocs:Object.values(document_data.documents),
       })

     }
     const setPrefilledValues = async(data ,response1) => {
       setToInitialState();
      const inspection_form_data = response1.data.inspection_details;
      const document_data = response1.data.mfd_data;
      const report_data = response1.data.report_data;
      const selected_data = response1.data.selected_data;
      const man_ids = await mapfilter(Object.values(document_data.manuals));
      const fol_ids = await mapfilter(Object.values(document_data.folders));
      const fol_selected = await handleFilter(man_ids,selected_data.folders);
      const doc_selected = await handleFilter(fol_ids,selected_data.document);
      setData({
        ...state,
        name: inspection_form_data.name,
         description:props.fromEditor ?
                      (response1.data.des_details.length > 0 ?(response1.data.des_details[0].description !== undefined ? response1.data.des_details[0].description : ''):'') : inspection_form_data.description,
        code: inspection_form_data.code,
       ['selected_files'] : data.file_id,
        ['file_id']:data.file_id,
       //  file_name: (response1.data.file_details.file_name !== undefined) ? response1.data.file_details.file_name : 'Choose icon',
         //file_path: (response1.data.file_details.file_path !== undefined) ? response1.data.file_details.file_path : '',
         //file_id : (response1.data.file_details.id !== undefined) ? response1.data.file_details.id : null,
         parent_id :inspection_form_data.parent_id,
        parent_type:inspection_form_data.parent_type,
        folderOptions:fol_selected,
        docOptions:doc_selected,
        selectedtemplateReports:data.selectedtemplateReports,
        selectedwebformReports:data.selectedwebformReports,
        selectedcustomReports:data.selectedcustomReports,
        selectedManuals:data.selectedManuals,
        selectedfolders:data.selectedfolders,
        selectedDocs:data.selectedDocs,
      })

    }
      const selectedOptions = async() => {
       const man_ids = await mapfilter(state.selectedManuals);
       const fol_ids = await mapfilter(state.selectedfolders);
       const fol_selected = await handleFilter(man_ids,folderOptionsresonse);
       const doc_selected = await handleFilter(fol_ids,folderOptionsresonse);
     }
    const handleCancel = () => {
      if(props.fromEditor && props.flow){
        props.closePopup();
        return;
      }
      if(props.action!==2){
        setStateValues(dbResponse);
      }
      else if(props.action === 2){
        setToInitialState();
      }
    }

     const handleChangeOptions = async (e) =>{
    var ids = await mapfilter(e);
  let folders = await handleFilter(ids,folderOptionsresonse);
  if(props.fromEditor && props.flow){
  props.handleChangeOptions(state,e,1);
}
  setData({
    ...state,
    selectedManuals:e,
    folderOptions:folders,
  });
  }
  const mapfilter = async (d) =>{
    return  d.map(obj=>{return obj['value']});
  }
const handleChangeFolders = async (e) =>{
      var ids = await mapfilter(e);
    let docs = await handleFilter(ids,docOptionsresponse);
    if(props.fromEditor && props.flow){
    props.handleChangeOptions(state,e,2);
  }
    setData({
    ...state,
    selectedfolders:e,
    docOptions:docs,
    });
}
const handleChangeReportOptions = async (e,selecttype) =>{

  if(selecttype === 1) {

  setData({

    ...state,
  selectedtemplateReports:e,
  });
}else if(selecttype === 2) {

  setData({
    ...state,
  selectedcustomReports:e,
  });
}
else{

  setData({

  ...state,
  selectedwebformReports:e,
  });
}
if(props.fromEditor && props.flow){
props.handleChangeOptions(state,e,window.HANDLE_REOPRT_OPTIONS[selecttype]);
}
}
const handleChangeDocs = async (e) =>{

  setData({
    ...state,
    selectedDocs:e,
  })
  if(props.fromEditor && props.flow){
  props.handleChangeOptions(state,e,3);
}
}

 const handleFilter = async(selctIds,dataObj) =>{
    let data = [];
  for(var i = 0 ; i<selctIds.length;i++){
    if(dataObj[selctIds[i]]!== undefined){
    Array.prototype.push.apply(data, Object.values(dataObj[selctIds[i]]))
  }
};
return data;
  }
  const getParentDetails = () => {
    let data = {};
    if(props.current_type === 'buildingid'){
      data['parent_id'] = props.buildingid;
      data['parent_type'] = window.BUILDING_ENTITY_TYPE_ID;
    }
    else if(props.current_type === 'floor'){
      data['parent_id'] = props.id;
        data['parent_type'] = window.FLOOR_ENTITY_TYPE_ID;
    }
    else if(props.current_type === 'inspectionpoint' && props.fromEditor   === 1) {
      data['parent_id'] = props.floorObj.value;
        data['parent_type'] = window.FLOOR_ENTITY_TYPE_ID;
    }
    else if(props.current_type === 'inspectionpoint'){
      data['parent_id'] = state.parent_id;
        data['parent_type'] = state.parent_type;
    }
    return data;
  }
  const handleChange = (event) =>{
    const { name, value } = event.target;
          state.errors[name] = '';

    setData({
      ...state,
      [name]: value,
      name_error: '',
      code_error: '',
     });
     if(props.fromEditor && props.flow){
 props.onChange(state, name, value);
 }
  }
  const getSubmitData = () => {
    let parent_data = getParentDetails();
  var  parent_id = parent_data.parent_id;
  var parent_type = parent_data.parent_type;
  var unique_id = null;
  if(props.fromEditor) {
    unique_id = props.drop_id;
  }
    let data = {
      name: state.name,
      description:state.description,
      code: state.code,
      file_id: state.selected_files,
      file_path: state.file_path,
      selectedtemplateReports:state.selectedtemplateReports,
      selectedwebformReports:state.selectedwebformReports,
      selectedcustomReports:state.selectedcustomReports,
      selectedManuals:state.selectedManuals,
      selectedfolders:state.selectedfolders,
      selectedDocs:state.selectedDocs,
      parent_id :parent_id,
      parent_type:parent_type,
      unique_key : unique_id,

    }

    return data;
  }
  const file_handling = state.selected_files.map(item => {
  return(
  <div>
      <div>  <span style={{ color: "black", display:'inline-block', marginRight: '10px'  }}>{item.file_name}</span>
        </div>
    {props.action === 2  &&   <span style={{ color: "green", display:'inline-block', marginRight: '10px'  }}>{window.FILE_UPLOAD_SUCCESS}</span>}
    { item.file_path !== undefined && item.file_path !== null && <span style={{display:'inline-block',  marginRight: '10px'}}>
          <i disabled = {disableFields} title="preview" style={{ 'cursor': 'pointer' }} class="webform-sprite webform-sprite-smallviewc" onClick={(e) => window.open(item.file_path, "_blank")}></i>
      </span>}
    { item.file_id !== undefined && item.file_id !== null && <span style={{display:'inline-block',  marginRight: '10px'}}>
          <i disabled = {disableFields} title="Remove" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec"  onClick={(e) => {handleFileChanges(item.file_id, 'remove')}}/>
      </span> }
  </div>
  )
  })
  const handleSubmit = () => {
    if(props.fromEditor && props.flow){
      props.submit(props.ipid,props.drop_id);
      return;
    }

    const {t} = state;
      if (validateForm()) {
          const details = getSubmitData();
          if ((props.ipid !== undefined && props.ipid !== null && props.ipid !== 1) && (props.action !== 2) && (props.current_type === 'inspectionpoint')) {
            datasave.service(window.UPDATE_INSPECTION_POINT_DATA + '/' + props.id, 'PUT', details)
              .then(resultObj => {
                  if (resultObj.status === 200) {
                    props.updateStructure('','',resultObj.data.id,'inspectionpoint');
                    setData({...state, uploadMessage : false})
               OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
            }
              });
           }
         else {
           let url;
             // if(props.fromEditor && props.flow === 0 ){
             //   url = window.INSERT_INSPECTION_POINT
             // }
             // else {
               url = window.INSERT_INSPECTION_POINT;
             // }
            datasave.service(url, 'POST', details)
              .then(resultObj => {
                if (resultObj.status === 200) {
                   if(props.fromEditor && props.flow == 0 ){
                  OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
                  props.updateInspectionsData(resultObj.data);return;
                }
                else {
                  props.updateStructure('','',resultObj.data.id,'inspectionpoint');
                  setData({...state, uploadMessage : false})
                  OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
                }

                }
                else {
                  if (resultObj.error.name || resultObj.error.number || resultObj.error.code) {
                    setData({
                      ...state,
                     errors: resultObj.error,

                    })

                  } else {
                    OCAlert.alertWarning(t('Something went wrong in saving data'), { timeOut: window.TIMEOUTNOTIFICATION });
                  }
                }
              }
              );
          }

      }
  }
  const validateForm = ()=> {
      let errors = {};
      let formIsValid = true;
      if (!state.name) {
        formIsValid = false;
        errors["name"] = "*Please enter inspection point name";
      }
      if (!state.code) {
       formIsValid = false;
       errors["code"] = "*Please enter  inspection point code.";
     }
     setData({
         ...state,
        errors: errors
      });
      return formIsValid;

  }
      const { name, code,description, submitted, loading,
                } = state;
     const {t} = state;
     const formDisabled = (props.action == 1) ? 'disabled' : '';
     const disableFields = (props.action == 1) ? true : false;
  return (

      <div className='col-md-12 px-0  py-2' >
        <div className='justify-content-center' style={{width: '100%', float: 'left'}} >
          <div className='col-lg-12 col-md-12 float-left px-0' >
              <div className='card-header component-header'style = {{textAlign: "center", marginLeft: '0px'}} > <p style={{marginBottom: '0'}}>{t('Inspection point details')}</p> </div>
                <reactbootstrap.Container className="p-1">
                    <reactbootstrap.Form  className="inspectionFrom">
                       <fieldset disabled={formDisabled}>
                    <reactbootstrap.FormGroup>
                    <div className=" input-overall-sec ">
                      <reactbootstrap.InputGroup className="">
                      <div className="col-md-4" >
                        <reactbootstrap.InputGroup.Prepend>
                          <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Inspectionpoint code')}:<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                        </reactbootstrap.InputGroup.Prepend>
                        </div>
                        <div class="col-md-8 input-padd">
                        <reactbootstrap.FormControl
                          placeholder={t("code")}
                          name="code"
                          aria-label="externalcode"
                          aria-describedby="basic-addon1"
                          value={code}
                          disabled = {disableFields}
                          onChange={(e) => handleChange(e)}
                          className="input_sw "
                        />
                        <div style={{ color: 'red'  }} className="error-block mt-2">{state.errors.code}</div>
                        </div>
                      </reactbootstrap.InputGroup>

                   </div>
                    </reactbootstrap.FormGroup>
                    <reactbootstrap.FormGroup>
                      <div className={'form-group' + (submitted && !name ? ' has-error' : '')}>
                      <div className=" input-overall-sec ">
                        <reactbootstrap.InputGroup className="">
                        <div className="col-md-4" >
                          <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Inspectionpoint name')}:<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                          </div>
                          <div class="col-md-8 input-padd">
                          <reactbootstrap.FormControl
                            name="name"
                            autoFocus
                            placeholder={t("Inspection point name")}
                            aria-label="Inspectionpoint name"
                            aria-describedby="basic-addon1"
                            value={name}
                            disabled = {disableFields}
                            onChange={(e) => handleChange(e)}
                            className="input_sw "
                          />
                           <div style={{ color: 'red' }} className="error-block mt-2">{state.errors.name}</div>
                          </div>
                        </reactbootstrap.InputGroup>

                      </div>
                      </div>
                    </reactbootstrap.FormGroup>
                    <reactbootstrap.FormGroup>
                    <div className=" input-overall-sec ">
                      <reactbootstrap.InputGroup className="">
                      </reactbootstrap.InputGroup>
                      </div>
                    </reactbootstrap.FormGroup>
                    <reactbootstrap.FormGroup>
                    <div className=" input-overall-sec ">
                    <reactbootstrap.InputGroup className="">
                    <div className="col-md-4" >
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Description')}:</reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                      </div>
                      <div class="col-md-8 input-padd">
                      <reactbootstrap.FormControl
                        style={{ height: '200px' }}
                        as="textarea" rows="3"
                        name="description"
                        placeholder={"Inspection point description"}
                        value={description}
                        disabled = {disableFields}
                        id="description"
                        onChange={(e) => handleChange(e)}
                        className="input_sw "
                      />
                      </div>
                      </reactbootstrap.InputGroup>
                      </div>
                    </reactbootstrap.FormGroup>
                    {props.fromEditor === 1 && <reactbootstrap.FormGroup>
                      <div className="input-overall-sec ">
                        <reactbootstrap.InputGroup className="  ">
                            <div className="col-md-4">
                                <reactbootstrap.InputGroup.Prepend>
                                    <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Building name')}</reactbootstrap.InputGroup>
                                </reactbootstrap.InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 px-0">
                                <reactbootstrap.FormControl
                                    name="buildingName"
                                    placeholder={t("Building name")}
                                    aria-label="code"
                                    aria-describedby="basic-addon1"
                                    value={props.buildingObj.label}
                                    className="input_sw"
                                    disabled = {1}
                                />
                            </div>
                        </reactbootstrap.InputGroup>
                      </div>
                      </reactbootstrap.FormGroup>}
                      {props.fromEditor === 1 &&  <reactbootstrap.FormGroup>
                      <div className="  input-overall-sec ">
                          <reactbootstrap.InputGroup className="  ">
                              <div className="col-md-4">
                                  <reactbootstrap.InputGroup.Prepend>
                                      <reactbootstrap.InputGroup style={{ padding: '10px', color: '#EC661C' }} id="basic-addon1">{t('Floor name')}</reactbootstrap.InputGroup>
                                  </reactbootstrap.InputGroup.Prepend>
                              </div>
                              <div class="col-md-8 px-0">
                                  <reactbootstrap.FormControl
                                      name="floorName"
                                      placeholder={t("Floor name")}
                                      aria-label="code"
                                      aria-describedby="basic-addon1"
                                      value={props.floorObj.label}
                                      className="input_sw"
                                      disabled = {1}
                                  />
                              </div>
                          </reactbootstrap.InputGroup>
                        </div>
                          </reactbootstrap.FormGroup>}
                    <reactbootstrap.FormGroup>
                    <reactbootstrap.InputGroup className="">
                    <div className="col-md-4">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Document')}:</reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                      </div>
                    <div className = "col-md-8">
                         <div className= "row">
                              <div style={{  }} className='col-md-12 mb-3 px-0' >
                                     <MultiSelect
                                         options={manualOPtions}
                                         standards={state.selectedManuals}
                                         id="Manuals"
                                         value={[]}
                                         handleChange={(e) => handleChangeOptions(e)}
                                         isMulti={true}
                                         disabled = {disableFields}
                                         placeholder = {'Select manuals'}
                                       />
                              </div>

                               <div style={{  }} className='col-md-12 mb-3 px-0'>
                               <MultiSelect
                                 options={state.folderOptions}
                                 standards={state.selectedfolders}
                                   disabled = {disableFields}
                                 id="folders"
                                  value={[]}
                                 handleChange={(e) => handleChangeFolders(e)}
                                  placeholder = {'Select folders'}
                               />
                               </div>
                               <div style={{  }} className='col-md-12 mb-3 px-0'>
                               <MultiSelect
                                 options={state.docOptions}
                                 standards={state.selectedDocs}
                                 id="docs"
                                  value={[]}
                                  disabled = {disableFields}
                                 handleChange={(e) => handleChangeDocs(e)}
                                 placeholder = {'Select documents'}
                               />
                               </div>
                         </div>
                    </div>
                  </reactbootstrap.InputGroup>
                </reactbootstrap.FormGroup>
                <reactbootstrap.FormGroup>
                <reactbootstrap.InputGroup className="">
                <div className="col-md-4">
                  <reactbootstrap.InputGroup.Prepend>
                    <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Reports')}:</reactbootstrap.InputGroup>
                  </reactbootstrap.InputGroup.Prepend>
                  </div>
                <div className = "col-md-8">
                     <div className= "row">
                          <div style={{  }} className='col-md-12 mb-3 px-0' >
                                 <MultiSelect
                                     options={templateReportsOPtions}
                                     standards={state.selectedtemplateReports}
                                     id="template"
                                     value={[]}
                                     disabled = {disableFields}
                                     handleChange={(e) => handleChangeReportOptions(e,1)}
                                     isMulti={true}
                                     placeholder = {'Template'}
                                   />
                          </div>

                           <div style={{  }} className='col-md-12 mb-3 px-0'>
                           <MultiSelect
                             options={customReportOptions}
                             standards={state.selectedcustomReports}
                             id="custom"
                              value={[]}
                             handleChange={(e) => handleChangeReportOptions(e,2)}
                              placeholder = {'Custom report'}
                              disabled = {disableFields}
                           />
                           </div>
                           <div style={{  }} className='col-md-12 mb-3 px-0'>
                           <MultiSelect
                             options={webformReportOptions}
                             standards={state.selectedwebformReports}
                             id="webform"
                              value={[]}
                              disabled = {disableFields}
                             handleChange={(e) => handleChangeReportOptions(e,3)}
                             placeholder = {'Webform report'}
                           />
                           </div>
                     </div>
                </div>
              </reactbootstrap.InputGroup>
            </reactbootstrap.FormGroup>
            <reactbootstrap.FormGroup>
                <div className=" row input-overall-sec ">
                    <reactbootstrap.InputGroup className="  ">
                        <div className="col-md-4" style={{paddingLeft: '26px'}}>
                            <reactbootstrap.InputGroup.Prepend>
                                <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Upload image:')}</reactbootstrap.InputGroup>
                            </reactbootstrap.InputGroup.Prepend>
                        </div>
                        <div className="col-md-8 custom-file customSection " style={{marginLeft: "-30px"}}>
                            <input
                                type="file"
                                className="custom-file-input"
                                id="image"
                                name='image'
                                disabled = {state.isDisable}
                                accept={window.DOC_TYPES['default']}
                                onClick={(event)=> event.target.value = null}
                                onChange={(e) =>handleFileChanges(e, 'upload')}
                            />
                            <label className="custom-file-label input_sw" htmlFor="inputGroupFile01">
                                {state.file_name !== null && state.file_name }
                            </label>
                        </div>
                    </reactbootstrap.InputGroup>
                </div>
            </reactbootstrap.FormGroup>
            <div style={{}} className="row col-md-12 mt-2">
                <div style={{ visibility: 'hidden' }} className="col-md-4">
                    <h3>{t('Upload')}</h3>
                </div>
                {!disableFields &&
                  <div className="col-md-8">
                  {state.selected_files.length > 0&&
                file_handling
                }
                    {state.formatWarning && state.sizeWarning && <span style={{ color: "red" }}>{window.FILE_FORMAT_ERROR_MSG}{t( 'and size should be < 1MB')} </span>}
                    {state.formatWarning && !state.sizeWarning && <span style={{ color: "red" }}> {window.FILE_FORMAT_ERROR_MSG} </span>}
                    {!state.formatWarning && state.sizeWarning && <span style={{ color: "red" }}> {t('Size should be < 1MB')} </span>}
                </div>}
            </div>
                    <FormGroup>
                    <div style={{float: 'right'}} className="organisation_list  mb-4">
                      <a disabled = {disableFields}  onClick={handleCancel} >{t('Cancel')}</a>
                      &nbsp;&nbsp;&nbsp;
                        <Button disabled = {disableFields} style={{fontSize: '14px'}} type="button" onClick = {() => handleSubmit()}className="btn btn-primary" disabled={loading}>{t('Save')}</Button>
                      </div>
                      </FormGroup>
                       </fieldset>
                        </reactbootstrap.Form >
                </reactbootstrap.Container>
              </div>
            </div>
      </div>


  )
}
export default translate(CreateInspectionPoint);
function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
