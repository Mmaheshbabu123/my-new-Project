import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import {translate} from '../../../language';
import { Form } from 'react-bootstrap';
import MultiSelect from '../../../_components/MultiSelect';
import { SearchFilter } from '../../../SearchFilter';
import React, { useState, useEffect ,useRef} from 'react';
import { OCAlert } from '@opuscapita/react-alerts';
import './inspection.css';
import { store } from '../../../store';
import GroundplanForm from '../../../Views/GroundplanManagementView';
const InspectionElementOverview = props => {
const TodoStatus = [
  {
    'label': 'All',
    'value': '-1',
  },
  {
    'label': 'Open',
    'value': '0',
  },
  {
    'label':'Past due date',
    'value':'1'
  }
];
const [tableData,setTableData] = useState({
  selectedTodoStatus:{
      'label': 'All',
      'value': '-1',
    },
  searchCode:'',
  searchName:'',
  searchDueDate:'',
  searchStatus:'',
})
const [tableResultData,setTableResultData] = useState({
  searchWebform:'',
  searchTaskName:'',
  searchIdentificationValue:'',
  searchResultValue:'',
  searchTodoScount:'',
})
const t = props.t;
    const [state, setData] = useState({
    use_existing_file: '',
    url : window.backendURL,
    use_existing_file_name: props.t('Choose image'),
    file_name :props.t('Click here to add images'),
    use_existing_file_edit_img: '',
    file_id: '',
    file_path: '',
    isDisable:false,
    selectedManuals:[],
    selectedDocs:[],
    selectedfolders:[],
    selectedtemplateReports:[],
    selectedcustomReports:[],
    selectedwebformReports:[],
    selectedKpiReports : [],
    parent_id: (props.buildingId !== undefined) ? props.buildingId : '',
    parent_type:'',
    errors: {},
    name: '',
    code: '',
    name_error: '',
    code_erroe:'',
    description: '',
    submitted: false,
    loading: false,
    sucess: '',
    formatWarning   : false,
    sizeWarning     : false,
    floorDisabled:'disable',
    uploadMessage : false,
    selected_files:[],
    webform_todos:[],
    result_todos:[],
    originalWebformTodos:[],
    originalWebformTodosResult:[],
    webforms : [],
    document_enable:false,
  })

const setToInitialState = () => {
    setData({...state,
      use_existing_file: '',
      url : window.backendURL,
      use_existing_file_name: props.t('Choose image'),
      file_name :props.t('Choose image'),
      use_existing_file_edit_img: '',
      file_id: '',
      file_path: '',
      isDisable:false,
      selectedManuals:[],
      selectedDocs:[],
      selectedfolders:[],
      selectedtemplateReports:[],
      selectedcustomReports:[],
      selectedwebformReports:[],
      selectedKpiReports : [],
      parent_id: (props.buildingId !== undefined) ? props.buildingId : '',
      parent_type:'',
      errors: {},
      name: '',
      code: '',
      name_error: '',
      code_erroe:'',
      description: '',
      submitted: false,
      loading: false,
      sucess: '',
      formatWarning   : false,
      sizeWarning     : false,
      floorDisabled:'disable',
      selected_files:[],
      webform_todos:[],
      originalWebformTodos:[],
      selectedTodo : [],
      originalWebformTodosResult:[],
      webforms : [],
    })
}

  useEffect(() => {
     async function dataLoad(){
                 if((props.ipid !== undefined && props.ipid !== null && props.ipid !== 1) && (props.action !== 2) && (props.current_type === 'inspectionpoint')){//props.parentId
                   let url;
                  if(props.fromEditor && props.flow){
                    url  = window.GET_IPL_OVERVIEW + '/' +  props.ipid + '/' + props.layer_id + '/' + props.drop_id + '/' + props.task_ids + '/' + props.webform_ids;
                  }
                  else{
                    url = window.GET_INSPECTION_POINT_DATA + '/' + props.ipid;
                  }
                   await datasave.service(url, 'GET', )
                   .then(async response1 => {
                       if(response1.status === 200) {
                         setStateValues(response1);
                       } else {
                         OCAlert.alertWarning(t('Unable to fetch data'), { timeOut: window.TIMEOUTNOTIFICATION });
                       }
                     })
                   }
                   else{
                     setData({
                       ...state,
                       name: '',
                       code: '',
                       description: '',
                       use_existing_file_name: props.t('Choose file'),
                       file_name :props.t('Choose icon'),
                       use_existing_file_edit_img: '',
                       file_id: '',
                       file_path: '',
                       folderOptions:[],
                       docOptions:[],
                       selectedDocs:[],
                       selectedfolders:[],
                       selectedManuals:[],
                       selectedwebformReports:[],
                       selectedcustomReports:[],
                       selectedtemplateReports:[],
                       selectedKpiReports : [],
                       webforms : [],
                       document_enable:false,
                     })
              }


       }
      if(window.SHOWSLICERESULT[props.slice] !== window.GP_DOCS_ROW )  {

        dataLoad();
      }
     }, [props.ipid,props.layer_id]);
      const setStateValues = async(response1) => {
        setToInitialState();
        const inspection_form_data = response1.data.inspection_details;
        const document_data = response1.data.mfd_data;
        const report_data = response1.data.report_data;
        let constructedData = await reconstructData(response1.data.webform_todos);
        let constructedResultData = await reconstructTodosData(response1.data.result_details);
       setData({
         ...state,
         name: inspection_form_data.name,
          code: inspection_form_data.code,
          selected_files:response1.data.file_details.file_details,
         selectedtemplateReports:Object.values(report_data.template_details),
         selectedwebformReports:Object.values(report_data.report_details),
         selectedcustomReports:Object.values(report_data.custom_details),
         selectedKpiReports : Object.values(report_data.kpi_details),
         selectedManuals:Object.values(document_data.manuals),
         selectedfolders:Object.values(document_data.folders),
         selectedDocs:Object.values(document_data.documents),
         originalWebformTodos:constructedData,
         webform_todos:constructedData,
         originalWebformTodosResult:constructedResultData,
         result_todos:constructedResultData,
         document_enable:true,
         webforms    : report_data.webforms ? report_data.webforms : [],
       })

     }
const reconstructData = (data)=>{
  if (data.length > 0) {
    return data.map(value => {
        let css_status  =  props.blockboxRefIds[value.webform_id].includes(value.ref_id)?3:'0';
         if(css_status === 3) {
           value.css_status = css_status;
         }
      return {
        'id':value.id?value.id:0,
        'document_code': value.document_code ? value.document_code.toString() : ' ',
        'document_name': value.document_name ? value.document_name.toString() : ' ',
        'finished': value.finished?value.finished.toString() : '0',
        'due_date_passed':value.due_date_passed?value.due_date_passed.toString():'0',
        'css_status':(value.css_status )?value.css_status.toString():'0',

        'due_date': value.due_date ? value.due_date.toString() : ' ',
        'webform_id': value.webform_id ? value.webform_id.toString() : '0',
         'ref_id': value.ref_id ? value.ref_id.toString() :'0',
         'step_id':value.step_id?value.step_id.toString():'0',
      }
    })
  } else {
    return [];
  }
}
const reconstructTodosData = (data)=> {
  if (data.length > 0) {
    return data.map(value => {
      return {
        'result_value':value.result_value?value.result_value.toString():'',
        'todo_status_color':value.todo_status_color?value.todo_status_color.toString():'',
        'todos_count':value.todos_count?value.todos_count.toString():'',
        'result_color':value.result_color?value.result_color.toString():'',
        'webform':value.webform?value.webform.toString():'',
        'task_name':value.task_name?value.task_name.toString():'',
        'identification_value':value.identification_value?value.identification_value.toString():'',
      }
    })
  } else {
    return [];
  }
}

    // const selected_docs = state.selectedDocs.map(item => {
    // return(
    // <div>
    //   <a style={{ color: "green"}} target="_blank" href={'/previewrevisionentities/' + item.value}>{item.label}</a>
    // </div>
    // )
    // })
  // const selected_webform_reports  = state.selectedwebformReports.map(item => {
  //   let storage = store.getState()
  //   let loggedPerson = storage.UserData.user_details.person_id
  // return(
  // <div>
  //   <a style={{ color: "green"}} href={'/report_view/' + item.value + '/' + item.webform_id + '/' + loggedPerson + '/' + item.label} target="_blank">{item.label}</a>
  // </div>
  // )
  // })
  // const selected_custom_reports = state.selectedcustomReports.map(item => {
  // return(
  // <div>
  //   <a style={{ color: "green"}} target="_blank" href={'/main_custom/' + item.value + '/' + item.webform_id} >{item.label}</a>
  // </div>
  // )
  // })
  // const handleClick = (documentId, submitId, currentStepId, webTodoId) =>{
  //      window.location = '/webformaction/' + documentId + '/' + webTodoId + '/' + submitId + '/' + currentStepId + '/0' + '/0' + '/0' + '/0' + '/0' +'?q=' + window.location.pathname;
  // }
  // const handleWebformReport = (id, name, web_id) => {
  //      let storage = store.getState()
  //      let loggedPerson = storage.UserData.user_details.person_id
  //   window.location = '/report_view/' + id + '/' + web_id + '/' + loggedPerson + '/' + name ;
  // }
  const webform_todos_details = state.webform_todos.map(item => {
    return(
      <tr style={{'cursor':'pointer'}}
          onClick = {() => window.open('/webformaction/' + item.webform_id + '/' + item.id + '/' + item.ref_id + '/' + item.step_id + '/0' + '/0' + '/0' + '/0' + '/0' + '/0' + '?q=' + window.location.pathname, '_blank')}>
        <td style = {{'backgroundColor': window.TODO_CSS_STATUS[item.css_status],textAlign:'center'}}>{item.document_code}</td>
        <td style = {{'backgroundColor': window.TODO_CSS_STATUS[item.css_status],textAlign:'center'}} >{item.document_name}</td>
        <td style = {{'backgroundColor': window.TODO_CSS_STATUS[item.css_status],textAlign:'center'}}>{item.due_date}</td>
        <td style = {{'backgroundColor': window.TODO_CSS_STATUS[item.css_status],textAlign:'center'}} >{window.TODO_STAUS[item.finished]}</td>
      </tr>
    )
  })
  const webform_todos_result_details = state.result_todos.map(item => {
    return(
      <tr>
      <td className="tr1 td-break">{item.webform}</td>
      <td className="tr2 td-break">{item.task_name}</td>
       <td className="tr5" style = {{'backgroundColor':item.identification_value ? '#00FF00' : '', textAlign:'center'}} >{item.identification_value}</td>
      <td className="tr3 td-break" style={{'backgroundColor':item.result_color,textAlign:'center'}}>{item.result_value}</td>
      </tr>
    )
  })

// const show_images = state.selected_files.map(item => {
//   return (
//     <div style={{ height :'150px' }} className='col-md-4' >
//      <img src = {item.file_path} height = {'100%'} width = {'100%'}/>
//     </div>
//   )
// })
const handleChangeStatusOptions =async (event) =>{
  tableData.selectedTodoStatus=event;
  let filledStates = await getStates('', '', '','' ,'finished',tableData.selectedTodoStatus.value==='-1'?'':tableData.selectedTodoStatus.value);
  let result = await SearchFilter.getData(filledStates, state.originalWebformTodos);
      let comp = tableData.selectedTodoStatus.value==='-1'?['1','0']:[tableData.selectedTodoStatus.value];
    //let column = tableData.selectedTodoStatus.value === 1?'due_date_passed':'finished';
  await setData({
    ...state,
    webform_todos:tableData.selectedTodoStatus.value === '1'?result.filter(item=>{return comp.includes(item.due_date_passed)}):result.filter(item=>{return comp.includes(item.finished)})
  })
}
const searchFilter=async  (e)=>{
  const name = e.target.name;
  const value = e.target.value;
  if (e.key !== "Delete" || e.key !== "Backspace") {
    let filledStates = await getStates('', '', '','' ,name,value);
    switch (name) {
      case 'document_code':
    await setTableData({
      ...tableData,
      searchCode:value
    });
    break;
    case 'document_name':
    await setTableData({
      ...tableData,
      searchName:value
    });
    break;
    case 'due_date_passed':
    await setTableData({
      ...tableData,
      searchStatus:value
    });
    break;
    case 'due_date':
    await setTableData({
      ...tableData,
      searchDueDate:value
    });
    break;
  }

let result = await SearchFilter.getData(filledStates, state.originalWebformTodos);
   let comp = tableData.selectedTodoStatus.value==='-1'?['1','0']:[tableData.selectedTodoStatus.value];
   await setData({
     ...state,
     webform_todos:result.filter(item=>{return comp.includes(item.finished)})
   })
}
}
  const searchResultFilter=async  (e)=>{
    if (e.key !== "Delete" || e.key !== "Backspace") {
        const name = e.target.name;
        const value = e.target.value;
      switch (name) {
        case 'webform':
      await setTableResultData({
        ...tableData,
        searchWebform:value
      });
      break;
      case 'task_name':
      await setTableResultData({
        ...tableData,
        searchTaskName:value
      });
      break;
      case 'result_value':
      await setTableResultData({
        ...tableData,
        searchResultValue:value
      });
      break;
      case 'identification_value':
      await setTableResultData({
        ...tableData,
        searchIdentificationValue:value
      });
      break;
      case 'todos_count':
      await setTableResultData({
        ...tableData,
        searchTodoScount:value
      });
        break;
    }
    let filledStates = await getResultStates('', '', '','' ,name,value);
    let result = await SearchFilter.getData(filledStates, state.originalWebformTodosResult);
       await setData({
         ...state,
         result_todos:result,
       })
    }
}

const getResultStates = (col1,col2,col3,col4,name,value)=>{
  if(name!==''){
    col1 = name==='webform'?col1+value:(name === 'task_name' || name === 'result_value' || name === 'todos_count')?searchWebform:'';
    col2 = name==='task_name'?col2+value:(name === 'webform' || name === 'result_value' || name === 'todos_count')?searchTaskName:'';
    col3= name==='result_value'?col3+value:(name === 'webform' || name === 'task_name' || name === 'todos_count')?searchResultValue:'';
    col4 = name==='identification_value'?col4+value:(name === 'webform' || name === 'task_name' || name === 'result_value')?searchIdentificationValue:'';
  }
  var arr = []
    if (col1 != '') {
      arr.push({ name: 'webform', value: col1 });
    }
    if (col2 != '') {
      arr.push({ name: 'task_name', value: col2 });
    }
    if (col3 != '') {
      arr.push({ name: 'result_value', value: col3 });
    }
    if (col4 != '') {
      arr.push({ name: 'identification_value', value: col4 });
    }
    return arr;
  }
  const getStates = (col1,col2,col3,col4,name,value)=>{
    if(name!==''){
      col1 = name==='document_code'?col1+value:(name === 'document_name' || name === 'due_date_passed' || name === 'due_date')?searchCode:'';
      col2 = name==='document_name'?col2+value:(name === 'document_code' || name === 'due_date_passed' || name === 'due_date')?searchName:'';
      col3= name==='due_date_passed'?col3+value:(name === 'document_name' || name === 'document_code' || name === 'due_date')?searchStatus:'';
      col4 = name==='due_date'?col4+value:(name === 'document_name' || name === 'document_code' || name === 'due_date_passed')?searchDueDate:'';
    }
    var arr = []
      if (col1 != '') {
        arr.push({ name: 'document_code', value: col1 });
      }
      if (col2 != '') {
        arr.push({ name: 'document_name', value: col2 });
      }
      if (col3 != '') {
        arr.push({ name: 'due_date_passed', value: col3 });
      }
      if (col4 != '') {
        arr.push({ name: 'due_date', value: col4 });
      }
      return arr;
    }
  async function onKeyUp(e) {
    var result = [];
    if (e.key === "Delete" || e.key === "Backspace") {
      var filledStates = await getStates(searchCode, searchName, searchStatus,searchDueDate ,'','');
       result = await SearchFilter.getData(filledStates, state.originalWebformTodos);
       let comp = tableData.selectedTodoStatus.value==='-1'?['1','0']:[tableData.selectedTodoStatus.value];
      await setData({
        ...state,
        webform_todos:result.filter(item=>{return comp.includes(item.finished)})
      })
    }
}
async function onResultKeyUp(e) {
  var result = [];
  if (e.key === "Delete" || e.key === "Backspace") {
    var filledStates = await getResultStates(searchWebform, searchTaskName, searchResultValue,searchTodoScount,searchIdentificationValue ,'','');
     result = await SearchFilter.getData(filledStates, state.originalWebformTodosResult);
    await setData({
      ...state,
      result_todos:result,
    })
  }
}
const {selectedTodoStatus,searchCode,searchName,searchDueDate,searchStatus}=tableData;
const webform_todo =(
<div style={{ 'height':(state.originalWebformTodos.length>0)?"350px":'', 'overflowY': 'auto', 'scrollbar-width': 'thin' }}>
  <reactbootstrap.Table striped bordered  hover>
      <thead style={{backgroundColor: '#EC661C', color: '#fff',position: 'sticky',top: '0',textAlign:'center'}}>
          <tr>
              <th style={{ width: '23%' }}>{t('Document code')}</th>
              <th style={{ width: '25%' }}>{t('Document name')}</th>
              <th style={{ width: '20%' }}>{t('Deadline')}</th>
              <th style={{ width: '20%' }}>{t('Status')}</th>
          </tr>
    {state.originalWebformTodos.length>0 &&  <tr>
            <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='document_code' value={searchCode} onChange={(e) => searchFilter(e)} onKeyUp={(e) => onKeyUp(e)} /></th>
            <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='document_name' value={searchName} onChange={(e) => searchFilter(e)} onKeyUp={(e) => onKeyUp(e)} /></th>
            <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='due_date' value={searchDueDate} onChange={(e) => searchFilter(e)} onKeyUp={(e) => onKeyUp(e)} /></th>
            <th><>
            <MultiSelect
            options={TodoStatus}
            standards={selectedTodoStatus}
            disabled={false}
            handleChange={e=>handleChangeStatusOptions(e)}
            isMulti={false}
            name = {'selectedTodoStatus'}
            />
            </></th>
          </tr>}
          </thead>
          <tbody>
           {state.webform_todos.length > 0 &&  webform_todos_details}
      </tbody>

  </reactbootstrap.Table>
  </div>
);
const {searchWebform,searchTaskName,searchResultValue,searchTodoScount,searchIdentificationValue} = tableResultData;
const webform_todo_result =(
<div style={{ 'height':(state.originalWebformTodosResult.length>0)?"400px":'', 'overflowY': 'auto', 'scrollbar-width': 'thin' }}>
  <reactbootstrap.Table striped bordered  hover variant="" className="resultTable">
      <thead style={{backgroundColor: '#EC661C', color: '#fff',textAlign:'center'}}>
          <tr>
              <th  style={{ width: '28%' }}>{t('Webform name')}</th>
              <th  style={{ width: '28%' }}>{t('Task name')}</th>
              <th  style = {{width: '25%'}}>{t('identification value')}</th>
              <th  style={{ width: '25%' }}>{t('Result value')}</th>
              {/*<th className="tr5">{'Result colour'}</th>*/}

          </tr>
    {state.originalWebformTodosResult.length>0 &&  <tr>
            <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='webform' value={searchWebform} onChange={(e) => searchResultFilter(e)} onKeyUp={(e) => onResultKeyUp(e)} /></th>
            <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='task_name' value={searchTaskName} onChange={(e) => searchResultFilter(e)} onKeyUp={(e) => onResultKeyUp(e)} /></th>
            <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='identification_value' value={searchIdentificationValue} onChange={(e) => searchResultFilter(e)} onKeyUp={(e) => onResultKeyUp(e)} /></th>
            <th></th>
            {/* <th className="tr5"></th> */}
          </tr>}
          </thead>
          <tbody>
           {state.result_todos.length > 0 &&  webform_todos_result_details}
      </tbody>

  </reactbootstrap.Table>
  </div>
);
const gpDocsDetails = ()=>{
  return <GroundplanForm
     ip_id = {props.ipid}
     layer_id= {props.layer_id}
     unique_id = {props.drop_id}
     personid = {'871'}
     gridItemId = {props.gridItemId}

     />
//  props.ipid + '/' + props.layer_id + '/' + props.drop_id
  window.open('/GroundplanForm/18/84/'+props.ipid + '/' + props.layer_id + '/' + props.drop_id+'/'+'871','_parent');
}
      // const { name, code,description, submitted, loading,
      //           } = state;
     // const formDisabled = (props.action == 1) ? 'disabled' : '';
     // const disableFields = (props.action == 1) ? true : false;
  return (

      <div className='py-2' >
        <div className='justify-content-center' style={{width: '100%', float: 'left', marginBottom:'5%'}} >
          <div className='col-lg-12 col-md-12 float-left px-0' >
                <reactbootstrap.Container className="pl-0">
                    <reactbootstrap.Form  className="inspectionFrom">
                  {/*  <reactbootstrap.FormGroup>
                       <reactbootstrap.InputGroup className="">
                    <div className = "col-md-12">
                         <div className= "row">
                              <div style={{  }} className='col-md-4' >
                                    <reactbootstrap.FormGroup>
                                      <div className="input-overall-sec ">
                                      <div style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Inspectionpoint Details')}:</div>
                                      </div>
                                      </reactbootstrap.FormGroup>
                              </div>

                               <div style={{  }} className='col-md-4'>
                                   <reactbootstrap.FormGroup>
                                     <div className="input-overall-sec ">
                                       <reactbootstrap.InputGroup className="  ">
                                               <reactbootstrap.InputGroup.Prepend>
                                                   <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Inspection name')}</reactbootstrap.InputGroup>
                                               </reactbootstrap.InputGroup.Prepend>
                                               <reactbootstrap.FormControl
                                                   name="buildingName"
                                                   placeholder={t("Building name")}
                                                   aria-label="code"
                                                   aria-describedby="basic-addon1"
                                                   value={props.buildingObj.label}
                                                   className="input_sw"
                                                   disabled = {1}
                                               />
                                       </reactbootstrap.InputGroup>
                                     </div>
                                     </reactbootstrap.FormGroup>
                               </div>
                   </div>
                 </div>
                       </reactbootstrap.InputGroup>
                    </reactbootstrap.FormGroup>*/}

                   {/* <reactbootstrap.FormGroup>
                    <reactbootstrap.InputGroup className="">
                    <div className = "col-md-12">
                         <div className= "row">
                             <div style={{  }} className='col-md-4'>
                             <reactbootstrap.FormGroup>
                               <div className="input-overall-sec ">
                                 <reactbootstrap.InputGroup className="  ">
                                             <div style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Inspection name')}</div>
                                           <div>
                                         <reactbootstrap.FormControl
                                             name="buildingName"
                                             placeholder={t("Building name")}
                                             aria-label="code"
                                             aria-describedby="basic-addon1"
                                             value={state.code+'-'+state.name}
                                             className="input_sw"
                                             disabled = {1}
                                         />
                                         </div>
                                 </reactbootstrap.InputGroup>
                               </div>
                               </reactbootstrap.FormGroup>

                            {/* <reactbootstrap.FormGroup>

                               <div className="input-overall-sec ">
                               <div style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Ground plan details')}:</div>
                               </div>
                               </reactbootstrap.FormGroup>
                         </div>
                          {/*    <div style={{  }} className='col-md-4' >
                                    <reactbootstrap.FormGroup>
                                      <div className="input-overall-sec ">
                                        <reactbootstrap.InputGroup className="  ">
                                                    <div style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Building name')}</div>
                                                      <div>
                                                        <reactbootstrap.FormControl
                                                            name="buildingName"
                                                            placeholder={t("Building name")}
                                                            aria-label="code"
                                                            aria-describedby="basic-addon1"
                                                            value={props.buildingObj.label}
                                                            className="input_sw"
                                                            disabled = {1}
                                                        />
                                                        </div>
                                        </reactbootstrap.InputGroup>
                                      </div>
                                      </reactbootstrap.FormGroup>
                              </div>


                               <div style={{  }} className='col-md-4'>
                                     <reactbootstrap.FormGroup>
                                    <div className="  input-overall-sec ">
                                        <reactbootstrap.InputGroup className="  ">
                                                    <div style={{ padding: '10px', color: '#EC661C' }} id="basic-addon1">{t('Floor name')}</div>
                                                       <div>
                                                          <reactbootstrap.FormControl
                                                              name="floorName"
                                                              placeholder={t("Floor name")}
                                                              aria-label="code"
                                                              aria-describedby="basic-addon1"
                                                              value={props.floorObj.label}
                                                              className="input_sw"
                                                              disabled = {1}
                                                          />
                                                        </div>
                                        </reactbootstrap.InputGroup>
                                      </div>
                                        </reactbootstrap.FormGroup>
                               </div>

                         </div>
                    </div>
                  </reactbootstrap.InputGroup>
                </reactbootstrap.FormGroup>*/}

                    <reactbootstrap.FormGroup>
                    <reactbootstrap.InputGroup className="">
                    <div className = "col-md-12 p-0">
                    {window.SHOWSLICERESULT[props.slice] === window.GP_REPORTS_ROW &&
                      <>
                      <div style={{ 'height': state.webforms.length ? '375px' : '0px', 'overflowY': 'auto', 'scrollbar-width': 'thin' }}>
                        <reactbootstrap.Table bordered hover>
                            <thead style={{ backgroundColor: '#EC661C', color: '#fff', textAlign: 'center', position: 'sticky', top: '0'}}>
                                <tr>
                                    <th style={{ width: '25%' }}>{t('Webform')}</th>
                                    <th style={{ width: '25%' }}>{t('Report')}</th>
                                    <th style={{ width: '25%' }}>{t('Custom report')}</th>
                                    <th style={{ width: '25%' }}>{t('KPI report')}</th>
                                </tr>
                            </thead>
                            <tbody >
                            {state.webforms.map(webform => {
                              return(
                                <tr id={webform.id}>
                                    <td>{webform.code + '-' + webform.name + '-' + webform.version}</td>
                                    <td>{state.selectedwebformReports.map(item => {
                                        let storage = store.getState()
                                        let loggedPerson = storage.UserData.user_details.person_id
                                      return webform.id === item.webform_id ?
                                         <div>
                                           <a style={{ cursor: "pointer", color : 'black'}} href={'/report_view/' + item.value + '/' + item.webform_id + '/' + loggedPerson + '/' + item.label} target="_blank">{item.label}</a>
                                         </div> : null
                                      })}
                                    </td>
                                    <td>{state.selectedcustomReports.map(item => {
                                       return webform.id === item.webform_id ?
                                          <div>
                                            <a style={{ cursor: "pointer", color : 'black'}} target="_blank" href={'/main_customv1/' + item.value + '/' + item.webform_id + '?q=groundplan=1'} >{item.label}</a>
                                          </div> : null
                                       })}
                                    </td>
                                    <td>{state.selectedKpiReports.map(item => {
                                       return webform.id === item.webform_id ?
                                          <div>
                                            <a style={{ cursor: "pointer", color : 'black'}} target="_blank" href={'/kpi_report_overview/' + item.value} >{item.label}</a>
                                          </div> : null
                                       })}
                                    </td>
                                </tr>
                              );
                            })}
                            </tbody>
                        </reactbootstrap.Table>
                    </div>
                  </>}
                  {window.SHOWSLICERESULT[props.slice] === window.GP_DOCS_ROW && <div style={{  }} className='col-md-12' >
                   <div >
                    {gpDocsDetails()}
                    {/* <reactbootstrap.Table bordered hover>
                        <thead style={{ backgroundColor: '#EC661C', color: '#fff', textAlign: 'center', position: 'sticky', top: '0'}}>
                            <tr>
                                <th style={{ width: '33%' }}>{t('Code')}</th>
                                <th style={{ width: '33%' }}>{t('Name')}</th>
                                <th style={{ width: '34%' }}>{t('Version')}</th>
                            </tr>
                        </thead>
                        <tbody >
                        {state.selectedDocs.map(doc =>
                            <tr style={{cursor:'pointer'}} id={doc.value}
                                onClick = {() => window.open('/previewrevisionentities/' + doc.value, '_blank')}>
                                    <td>{doc.code}</td>
                                    <td>{doc.name}</td>
                                    <td>{doc.version}</td>
                            </tr>
                          )}
                        </tbody>
                       </reactbootstrap.Table> */}
                      </div>
                    </div>}
                  </div>
                  </reactbootstrap.InputGroup>
                </reactbootstrap.FormGroup>
              {window.SHOWSLICERESULT[props.slice] === window.GP_STATUS_ROW  &&  <reactbootstrap.FormGroup>
                <reactbootstrap.InputGroup className="">
                {state.originalWebformTodos.length < 1 && <div className="col-md-4">
                  <reactbootstrap.InputGroup.Prepend>
                    <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('No to do\'s linked')}:</reactbootstrap.InputGroup>
                  </reactbootstrap.InputGroup.Prepend>
                  </div>}
                <div className = "col-md-12">
              {  webform_todo}
                    {/*  <div className= "row">
                          <div style={{  }} className='col-md-4' >

                          </div>

                           <div style={{  }} className='col-md-4'>

                           </div>
                           <div style={{  }} className='col-md-4'>

                           </div>
                     </div>*/}
                </div>
              </reactbootstrap.InputGroup>
            </reactbootstrap.FormGroup>}
          {window.SHOWSLICERESULT[props.slice] === window.GP_STATUS_ROW  &&  <reactbootstrap.FormGroup>
            {/*<reactbootstrap.InputGroup className="">
            <div className="col-md-4">
              <reactbootstrap.InputGroup.Prepend>
                <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Images')}:</reactbootstrap.InputGroup>
              </reactbootstrap.InputGroup.Prepend>
              </div>
            <div className = "col-md-12">
                <div className= "row">
                    {state.selected_files.length>0 && show_images}
                 </div>
            </div>
          </reactbootstrap.InputGroup>*/}
        </reactbootstrap.FormGroup>}
      {window.SHOWSLICERESULT[props.slice] === window.GP_RESULT_ROW &&  <reactbootstrap.FormGroup>
        <reactbootstrap.InputGroup className="">
        {state.originalWebformTodosResult.length<1 && <div className="col-md-4">
          <reactbootstrap.InputGroup.Prepend>
            <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('No results found')}:</reactbootstrap.InputGroup>
          </reactbootstrap.InputGroup.Prepend>
          </div>}
        <div className = "col-md-12">
                {state.originalWebformTodosResult.length>0 && webform_todo_result}
        </div>
      </reactbootstrap.InputGroup>
    </reactbootstrap.FormGroup>}

                        </reactbootstrap.Form >
                </reactbootstrap.Container>
              </div>
            </div>
      </div>


  )
}
export default translate(InspectionElementOverview);
function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
