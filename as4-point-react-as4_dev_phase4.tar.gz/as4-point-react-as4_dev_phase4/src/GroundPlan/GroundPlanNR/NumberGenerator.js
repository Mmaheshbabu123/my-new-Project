import React, { useState, useEffect } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';

const NumberGenerator = (props) =>{
  const t = props.t;
  const [tab, setTab] = useState(1);
  const [dbResponse, setResponse] = useState({});
  const [state, setState] = useState({
    data : {
      position : 1,
      template: '<NR>',
      sample  : 1,
      error   : false,
    },
  })

  useEffect(()=>{
    dataLoad();
  },[])

  async function dataLoad(data = '') {
    if(!data){
    await datasave.service(window.GET_GROUNDPLAN_NR_DATA, 'GET')
    .then(async response => {
      await setResponse(response.data);
      await setState({...state, data : response.data });
    })
  }else{
    setState({...state, data : data})
   }
 }

  const handleTemplateChange = (e) => {
    var data = {...state.data};
    var combine = '';
    if (e.target.value.includes('<NR>')) {
        combine = getTemplate(e.target.value);
        data = ({...data,
          [tab] : {...data[tab],
            template : e.target.value,
            sample   : combine,
          }
        })
        setState({...state, data : data});
    }else {
        combine = getTemplate('<NR>')
        data = ({...data,
          [tab] : {...data[tab],
            template: '<NR>',
            sample   : combine
          }
        })
        setState({...state, data : data});
    }
  }

  const handlePositionChange = (e) => {
    var data = {...state.data};
    if(parseInt(e.target.value) < 11 || e.target.value === ''){
      if (e.target.value === '') {
          data = ({...data,
            [tab] : {...data[tab], position : e.target.value, sample : 1, error : false}
          })
          setState({...state, data : data, warning : false});
      } else {
          var s = getTemplate(data[tab].template, e.target.value);
          data = ({...data,
            [tab] : {...data[tab], position : e.target.value, sample : s, error : false}
          })
          setState({...state, data : data, warning : false});
      }
    }else{
      data = ({...data,
        [tab] : {...data[tab], position : e.target.value, error : true}
      })
       setState({...state, data : data, warning : true })
    }
  }

  const getTemplate = (template, position = '') => {
      var s = getposition(position);
      var combine = template.replace('<NR>', s);
      return combine;
  }
  const getposition = (position = '', sample = 1) => {
      var seq = (position) ? position : state.data[tab].position;
      var s = sample + "";
      while (s.length < seq) {
          s = "0" + s;
      }
      return s;
  }

  const handleCancel = () => {
      dataLoad(dbResponse);
  }

  const handleSave = () => {
    if(!state.warning){
      datasave.service(window.STORE_GROUNDPLAN_NR_DATA, 'POST', {data : state.data})
      .then(response => {
        OCAlert.alertSuccess(t('Saved successfully.!'), { timeOut: window.TIMEOUTNOTIFICATION });
      })
    }
  }

  const numberGenerator = () => {
    const data = state.data[tab] ? state.data[tab] : state.data;
    const { template, sample, position, error } = data;
    return (
      <div className='mt-4'>
          <reactbootstrap.FormGroup>
              <div class=" row input-overall-sec mb-4 ">
                  <reactbootstrap.InputGroup className="">
                      <div class="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                              <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C', backgroundColor: 'none', border: '0px' }} id="basic-addon1">{t('Template:')}</reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                      </div>
                      <div class="col-md-8 input-padd ">
                          <reactbootstrap.FormControl
                              name="template"
                              placeholder="<NR>"
                              aria-label="Manual"
                              aria-describedby="basic-addon1"
                              value={template}
                              onChange={handleTemplateChange}
                              className="input_sw"
                          />
                      </div>
                  </reactbootstrap.InputGroup>
              </div>
          </reactbootstrap.FormGroup>

          <reactbootstrap.FormGroup>
              <div class=" row input-overall-sec mb-4 ">
                  <reactbootstrap.InputGroup className="">
                      <div class="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                              <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C', backgroundColor: 'none', border: '0px' }} id="basic-addon1">{t('Positions:')} </reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                      </div>
                      <div class="col-md-8 input-padd ">
                          <reactbootstrap.FormControl
                              name="position"
                              placeholder={t("Positions")}
                              aria-label="Manual"
                              aria-describedby="basic-addon1"
                              value={position}
                              onChange={handlePositionChange}
                              className="input_sw"
                          />
                          {error && <reactbootstrap.Form.Text style={{ color: "red" }} >
                              {t('Maximum allowed upto range 10')}</reactbootstrap.Form.Text>}
                      </div>
                  </reactbootstrap.InputGroup>
              </div>
          </reactbootstrap.FormGroup>
          <reactbootstrap.FormGroup>
              <div class=" row input-overall-sec mb-4 ">
                  <reactbootstrap.InputGroup className="">
                      <div class="col-md-4">
                          <reactbootstrap.InputGroup.Prepend>
                              <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C', backgroundColor: 'none', border: '0px' }} id="basic-addon1">{t('Sample:')}</reactbootstrap.InputGroup>
                          </reactbootstrap.InputGroup.Prepend>
                      </div>
                      <div class="col-md-8 input-padd ">
                          <reactbootstrap.FormControl
                              name="sample"
                              placeholder=""
                              disabled={1}
                              aria-label="Manual"
                              aria-describedby="basic-addon1"
                              value={sample}
                              className="input_sw"
                          />
                      </div>
                  </reactbootstrap.InputGroup>
              </div>
          </reactbootstrap.FormGroup>
      </div>
    );
  }



  return (
    <reactbootstrap className=" row ">
          <div className='col-md-12'>
              <reactbootstrap.Tabs defaultActiveKey={tab} id = "uncontrolled-tab-example" onSelect = {(key) => setTab(key)}>
                <reactbootstrap.Tab eventKey={1} title={t("Building")}>
                    {numberGenerator()}
                </reactbootstrap.Tab>
                <reactbootstrap.Tab eventKey={2} title={t("Floor")}>
                    {numberGenerator()}
                </reactbootstrap.Tab>
                <reactbootstrap.Tab eventKey={3} title={t("Inspection element")}>
                    {numberGenerator()}
                </reactbootstrap.Tab>
              </reactbootstrap.Tabs>
              <reactbootstrap.FormGroup>
                <div style={{ float: 'right' }} className="organisation_list">
                  <a type="submit" onClick = {handleCancel} name="cancel" > {t('Cancel')} </a>
                           &nbsp;&nbsp;&nbsp;
                  <reactbootstrap.Button type="submit"
                     name="save"
                     className="btn btn-primary"
                     onClick  = {handleSave}
                     >{t('Save')}
                  </reactbootstrap.Button>
                </div>
              </reactbootstrap.FormGroup>
      </div>
    </reactbootstrap>
  );
}
export default translate(NumberGenerator);
