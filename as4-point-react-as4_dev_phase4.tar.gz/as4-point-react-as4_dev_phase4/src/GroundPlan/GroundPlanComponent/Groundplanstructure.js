import React, { Component } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import TreeMenu, { defaultChildren, ItemComponent } from 'react-simple-tree-menu';
import { Input, ListGroup, ListGroupItem} from 'reactstrap';
import { Button, Form, FormGroup, FormControl } from 'react-bootstrap';
import _ from "lodash";
import './groundplanComp.css';
import { OCAlert } from '@opuscapita/react-alerts';
import Can from '../../_components/CanComponent/Can';
import {CanPermissions} from '../../_components/CanComponent/CanPermissions';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';

let clickEventPrevent = false;

class Groundplanstructure extends Component {
    constructor(props) {
        super(props);
        this.state = {
          treedata:[],
          activeOpenNode: '',
          openNode: [],
          buildingid : '',
          buildings :[],
          selectedbuilding : '',
          t:props.t
        }
        this.onClickNode = this.onClickNode.bind(this);
        this.actionChange = this.actionChange.bind(this);
        this.handledelete = this.handledelete.bind(this);
        this.onViewmode = this.onViewmode.bind(this);
    }
    componentDidMount() {
      this.setState({
        openNodeManual: JSON.parse(localStorage.getItem('openNodeBuilding')),
        activeOpenNode: localStorage.getItem('activeOpenbuildingNode'),
      })
      const data = {
        id : this.props.buildingid.value,
      }
      console.log("didmount");
      
      this.fetchBuildingStructure(data);
    }

   componentDidUpdate (prevProps, prevState) {
      // console.log(prevProps.buildingid.value);
      // console.log(this.props.buildingid.value);
      // console.log( prevProps.status);
      // console.log(this.props.status);
      if(prevProps.buildingid.value!=this.props.buildingid.value || prevProps.status!= this.props.status) {
        this.setState({
          openNodeManual: JSON.parse(localStorage.getItem('openNodeBuilding')),
          activeOpenNode: localStorage.getItem('activeOpenbuildingNode'),
        })
        const data = {
          id : this.props.buildingid.value,
        }
        console.log("didupdate");
        
        this.fetchBuildingStructure(data);
      }
    }

    fetchBuildingStructure (data) {
      console.log(data);
      
      datasave.service(window.BUILDINGSTRUCTURE, "POST", data)
      .then(result => {
        this.displayTreestructure(result.data);
      })
    }

    displayTreestructure (data) {
      let finalData = {};
      let folderData = data;
      var touched_ids = [];
      Object.keys(folderData).map(function (key) {
          if(folderData[key].childrens!== undefined){
              Array.from(Object.values(folderData[key].childrens)).forEach(function (id) {
                  folderData[key].nodes[id] = folderData[id];
                  touched_ids.push(id);
              });
          finalData[key] = folderData[key];
        }
      });
      touched_ids.forEach(function (id) {
          delete finalData[id];
      });
      this.setState({
        treedata : finalData,
        buildingid : this.props.buildingid,
      })
    }
    onClickNode(key, label, props) {

      this.setState({
          activeOpenNode: key,
      });
      console.log(clickEventPrevent);
      if (clickEventPrevent) {
        // this.actionChange(props,props.id,label,props.current_type,props.parent_type,"view");
          clickEventPrevent = false;
          return false;
      }

      if (localStorage.getItem('openNodeBuilding') !== null) {
          var opennodes = JSON.parse(localStorage.getItem('openNodeBuilding'));
      }
      else {
          var opennodes = [];
      }
      if (opennodes !== null && opennodes.includes(key)) {
          var index = opennodes.indexOf(key);
          if (index !== -1) opennodes.splice(index, 1);
      } else {
          opennodes.push(key);
      }
      localStorage.setItem('openNodeBuilding', JSON.stringify(opennodes));
      localStorage.setItem('activeOpenbuildingNode', key);
      this.setState({
          openNodeManual: opennodes,
          activeOpenNode: key,
      });
      // return false;
      this.debouncedClickEvents = this.debouncedClickEvents || [];
      //
      // // Each click we store a debounce (a future execution scheduled in 250 milliseconds)
      const callback = _.debounce(_ => {
      //     // YOUR ON CLICKED CODE
      //
          this.debouncedClickEvents = [];
      }, 500);
      this.debouncedClickEvents.push(callback);

      // We call the callback, which has been debounced (delayed)
      // this.actionChange(props,props.id,label,props.current_type,props.parent_type,"view");
      callback();
    }
    onViewmode(props,key,label,current_type,parent_type) {
        this.actionChange(props,key,label,current_type,props.parent_type,"view");
    }

    actionChange (props,key,label,current_type,parent_type,action_type) {
      clickEventPrevent = true;
      const details = {
        key           : key,
        label         : label,
        current_type  : current_type,
        parent_type   : parent_type,
        props         : props,
        action_type   : action_type,
      }
        this.props.handleredirect(details);
    }
    handledelete (props,current_type,id) {
      const data={
        current_type:current_type,
        id:id,
        parent_id : current_type === 'floor' ? props.parent_id : -1,
      }
      datasave.service(window.DELETE_GROUNDPLAN_DETAILS, "POST", data)
      .then(result => {
        console.log(result);
        if(result.status===201){
          OCAlert.alertWarning(result.Msg, { timeOut: window.TIMEOUTNOTIFICATION });
        }else if(result.status===200) {
          OCAlert.alertSuccess('Deleted successfully ', { timeOut: window.TIMEOUTNOTIFICATION });
        }
        datasave.service(window.FETCHBUILDINGS, "GET")
        .then(async response => {
          let result = response.buildings;
          localStorage.setItem('building_id', JSON.stringify(result[0]));
          if (current_type === 'building'){
            await this.props.buildingDetails(result[0],true);
          }
          const data = {
            id : current_type === 'floor'?props.parent_id:result[0]['value'],
          }
          console.log("delete");
          
          this.fetchBuildingStructure(data);
        })
      })
    }



    render () {
      const DEFAULT_PADDING = 5;
      const ICON_SIZE = 8;
      const LEVEL_SPACE = 16;
      const WIDTH = '25px';
      const HEIGHT = '25px';
      const DISPLAY = 'inline-flex';
      const WIDTH_DYNAMIC = '20' ;
      const {t} = this.state;
      const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }}>{on ? '-' : '+'}</span>;
      const ListItem = ({
          level = 0,
          key,
          hasNodes,
          isOpen,
          type_id,
          label,
          searchTerm,
          openNodes,
          value,
          id,
          parent_type,
          current_type,
          code,
          childrens,
          ...props
      })=> (
            <div className="folder-manual-section">
                <ListGroupItem
                    className="left-border"
                    {...props}
                    style={{
                        paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE,
                        cursor: 'pointer',
                    }}
                    key={key}
                  >
                    <div className="list-items-structure" style = {{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
                        {hasNodes && <ToggleIcon on={isOpen} />}
                        {current_type ==='building' &&
                          <i class="folder-icons folder-icons-folder" title="Building"  style={{ marginRight: '5px' }} > </i>
                        }

                        <p style={{width: '80%'}} className="result-label" onClick={() => this.onViewmode(props,id,label,current_type,parent_type)}>{code}-{label}</p>
                        <Can
                           perform = "Access_groundplan,E_floor"
                           yes = {() => (
                              <>
                                {current_type ==='building' &&
                                   <i class="overall-sprite overall-sprite-msfolderc" alt="Logo" title="Add floor" style={{ marginTop: '5px' }} onClick={() => this.actionChange(props,id,label,current_type,parent_type,"add floor")}></i>
                                }
                              </>
                          )}
                        />
                        {/* {current_type === 'floor' &&
                            <i class="overall-sprite overall-sprite-msdocumentc" alt="Logo" title="Add inspection" style={{ marginTop: '5px' }} onClick={() => this.actionChange(props,id,label,current_type,parent_type,"add inspection")}></i>
                        } */}
                        {childrens.length == 0 &&
                          <>
                            {((current_type === 'building' && CanPermissions("Access_groundplan,D_building", "") === true) || (current_type === 'floor' && CanPermissions("Access_groundplan,D_floor", "") === true)) &&
                               <div style={{ alignSelf: 'center', margin: '1px 0px 0px 1px' }}> <i class="overall-sprite overall-sprite-msdeletec" alt={'Delete'+current_type} title={'Delete'+' '+current_type} onClick={() => this.handledelete(props,current_type,id)}></i> </div>
                            }
                          </>
                        }
                        {((current_type === 'building' && CanPermissions("Access_groundplan,E_building", "") === true) || (current_type === 'floor' && CanPermissions("Access_groundplan,E_floor", "") === true)) &&
                            <i style={{marginLeft: '6px', marginTop: '1px'}} class="overall-sprite overall-sprite-mseditc" alt="Logo" title="Edit" onClick={() => this.actionChange(props,id,label,current_type,parent_type,"Edit")}></i>
                        }
                        {!hasNodes && <span> &nbsp;</span>}

                    </div>

                </ListGroupItem>
            </div>
      );
      return (
        <div className='container-fluid' style={{paddingLeft: '0'}}>
          <div className='row'>
            <div className='col-md-12 offset-md-12'>
              <TreeMenu
                data={this.state.treedata}
                onClickItem={({ key, label, ...props }) => {
                  this.onClickNode(key, label, props);
                }}
                debounceTime={125}
                activeKey={this.state.activeOpenNode}
                openNodes={this.state.openNodeManual}
                >
                  {({ search, items }) => (
                      <>
                        <Input className="input_sw " onChange={e => search(e.target.value)} placeholder={t("Type and search")} />
                        <ListGroup className="folder-left-list-group">
                            {items.map(props => (
                                <ListItem {...props} />
                            ))}
                        </ListGroup>
                      </>
                  )}
              </TreeMenu>
            </div>
          </div>
        </div>
      )
    }

}
export default translate(Groundplanstructure)
