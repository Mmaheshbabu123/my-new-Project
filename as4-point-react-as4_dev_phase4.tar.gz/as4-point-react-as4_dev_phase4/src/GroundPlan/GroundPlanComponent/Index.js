import React, { Component } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import _ from "lodash";
import { datasave } from '../../_services/db_services';
import Groundplanheader from './Groundplanheader';
import Groundplanstructure from './Groundplanstructure';
import Building  from '../Building/Building';
import Floor from '../Floors/FloorIndex';
import Inspectionpoint from '../InspectionPoint/Details/CreateInspectionPoint';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import {
  BrowserRouter as Router,
  Route,
  Link,
} from 'react-router-dom'


class Index extends Component {
    constructor(props) {
        super(props);
        this.state = {
          buildingid : 0,
          status : false,
          action_change : [],
        }
        this.createBuilding = this.createBuilding.bind(this);
        this.handleChangeBuilding = this.handleChangeBuilding.bind(this);
        this.handleRedirection = this.handleRedirection.bind(this);
        this.updateStructure = this.updateStructure.bind(this);
    }
    async componentDidMount (){
      let groundplandata = JSON.parse(localStorage.getItem('groundplandata'));
      await this.setState({
        current_type: groundplandata!=null?groundplandata.current_type:'',
        action_type: groundplandata!=null?(groundplandata.action_type==='create'?'create':'view'):'view',
        id : groundplandata!=null?groundplandata.id:'',
        createbuilding : groundplandata!=null?groundplandata.createbuilding:false,
        ipid : groundplandata!=null?groundplandata.ipid:0,
      })
    }

   async createBuilding() {
      await this.setState({
        createbuilding :true,
        action_type : "create",
        current_type : 'building',
      })
      const groundplandata ={
        current_type : 'building',
        action_type: 'create',
        id : 0,
        createbuilding :true,
        ipid :0,
      }
      localStorage.setItem('groundplandata', JSON.stringify(groundplandata));
      this.props.history.push('/managemyorganisation/groundplan/building/create/0')
    }
    async handleChangeBuilding (buildingid) {
      await this.setState({
        buildingid : buildingid,
        status : false,
        current_type : 'building',
        action_type: 'view',
        createbuilding : false,
      })
    }

    handleRedirection (actionchange) {
      this.setState({
          action_type : actionchange.action_type,
          action_change : actionchange,
          current_type :actionchange.current_type,
          id : actionchange.key,
          createbuilding :false,
          ipid :actionchange.current_type=='inspectionpoint' ?actionchange.key:0,
      })
      const groundplandata ={
        current_type : actionchange.current_type,
        action_type: actionchange.action_type,
        id : actionchange.key,
        createbuilding : false,
        ipid :actionchange.current_type=='inspectionpoint' ?actionchange.key:0,
      }
      // this.props.currentDetails(actionchange.action_type);
      this.props.history.push('/managemyorganisation/groundplan/'+actionchange.current_type+'/'+actionchange.action_type+'/'+actionchange.key);
      localStorage.setItem('groundplandata', JSON.stringify(groundplandata));


    }
    updateBuildingStructure () {

    }
    updateStructure (id,floorid,ipid,current_type) {
      this.setState({
        buildingid : id!=''?id:this.state.buildingid,
        status : true,
        id:floorid,
        ipid : ipid,
        action_type :"view",
        current_type : current_type,
        createbuilding : false,
      })
      if(id=='') {
        localStorage.setItem('activeOpenbuildingNode',this.state.buildingid.value+'/'+floorid)
      }
    }
    async buildingDetails(buildingid,status) {
      await this.setState({
        buildingid : buildingid,
        status : status,

      })
    }

    handleCancel = (current_type) => {
      this.setState({
        action_type  :"view",
        current_type : current_type,
        createbuilding : false
      });
    }


    render () {
      const {t,createbuilding,buildingid,status,action_type,action_change,id,current_type,ipid} = this.state;
      let building_props = {
        id     : (current_type==='building'&&action_type==="create")? 0 : ((buildingid!==undefined) ? buildingid.value : 0),
        action : action_type === 'Edit' ? 0 : (action_type=== 'view' ? 1 : 0),
        action_type : (current_type==='building'&&action_type==="create") ? 2 : 0,
      };

          return(
            <div className='sectionHeader mt-2' >
                <div className='row justify-content-center' >
                    <div className='col-md-4' >
                       <Groundplanheader buildingid={buildingid} status = {status} createbuilding={this.createBuilding} handleChangeBuilding={this.handleChangeBuilding} buildingDetails = {this.buildingDetails.bind(this)}></Groundplanheader>
                        {(buildingid!==0&&buildingid!==undefined) && <Groundplanstructure buildingid={buildingid} status={status} handleredirect={this.handleRedirection} buildingDetails = {this.buildingDetails.bind(this)}></Groundplanstructure>}
                    </div>
                    <div id="fde-wrapper" style={{ backgroundColor: '#f4f4f4' }} className="col-lg-8 col-md-8 float-left px-0 pt-0">
                        {(createbuilding ==true || createbuilding=='true' ||(current_type =='building' && (action_type == 'Edit'||action_type == "view")))&&
                        <Building buildingid = {building_props} handleCancel = {this.handleCancel.bind(this)} updateStructure={this.updateStructure}></Building>
                        }
                        {((action_type == "add floor"&&buildingid!=0) || (current_type =='floor'&&buildingid!=0 &&(action_type == 'Edit'||action_type == "view"))) &&
                          <Floor buildingid = {buildingid} current_type={current_type} action = {action_type==='Edit'?0:(action_type==='view'?1:2)} floorid = {current_type=='building'?null:id} handleCancel = {this.handleCancel.bind(this)} updateStructure={this.updateStructure} ></Floor>
                        }
                        {((action_type == "add inspection" &&buildingid!=0)|| (current_type =='inspectionpoint' &&buildingid!=0 && (action_type == 'Edit'||action_type == "view"))) &&
                           <Inspectionpoint buildingid = {buildingid} current_type={current_type} id={id} action = {action_type==='Edit'?0:(action_type==='view'?1:2)} updateStructure={this.updateStructure} ipid={ipid} fromEditor = {0}></Inspectionpoint>
                        }

                    </div>
                </div>
            </div>
        )
    }
}
export default translate(Index)
