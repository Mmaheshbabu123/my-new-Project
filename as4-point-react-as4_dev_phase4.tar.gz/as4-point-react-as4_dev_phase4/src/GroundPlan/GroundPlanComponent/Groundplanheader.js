import React, { Component } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import _ from "lodash";
import { datasave } from '../../_services/db_services';
import MultiSelect from '../../_components/MultiSelect';
import './groundplanComp.css';
import Can from '../../_components/CanComponent/Can';
import {CanPermissions} from '../../_components/CanComponent/CanPermissions';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';


class Groundplanheader extends Component {
    constructor(props) {
        super(props);
        this.state = {
          buildings :[],
          selectedbuilding : '',
          t : props.t

        }
        this.handleChangebuilding = this.handleChangebuilding.bind(this);
    }
    async componentDidMount() {
      datasave.service(window.FETCHBUILDINGS, "GET")
      .then(async response => {
        let result = response.buildings;
        let building_id = JSON.parse(localStorage.getItem('building_id'))!=undefined?JSON.parse(localStorage.getItem('building_id')):result[0];
         await this.setState({
           buildings:result,
           selectedbuilding : building_id,
         })
         await this.props.buildingDetails(building_id,false);
      })
    }
    componentDidUpdate (prevProps) {
      if(prevProps.status != this.props.status) {
        datasave.service(window.FETCHBUILDINGS, "GET")
        .then(response => {
          let result = response.buildings;
          let building_id = this.props.buildingid;
           this.setState({
             buildings:result,
             selectedbuilding : building_id,
           })
           localStorage.setItem('building_id', JSON.stringify(building_id));
           this.props.buildingDetails(building_id,false);
         })
      }
    }
    handleChangebuilding(event){
      this.setState({
        selectedbuilding:event,
      })
      localStorage.setItem('building_id', JSON.stringify(event));
      this.props.handleChangeBuilding(event);
    }


    render () {
      const {t,buildings,selectedbuilding} = this.state;
        return(
            <div className='container' style={{paddingBottom: '7px'}} >
                <div className='row justify-content-center' >
                    <div className='col-md-12' style={{paddingLeft: '0'}}>
                      <Can
                         perform = "E_building"
                         yes = {() => (
                           <reactbootstrap.Button className=" mb-2" onClick={this.props.createbuilding}>{t('Add building')}</reactbootstrap.Button>
                         )}
                       />
                      <div className="input_sw ">
                        <MultiSelect
                        options= {buildings}
                        standards={selectedbuilding}
                        handleChange={this.handleChangebuilding}
                        isMulti = {false}
                       />
                      </div>
                    </div>
                </div>
            </div>
        )
    }
}
export default translate(Groundplanheader)
