import React, { Component } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import Building from './Index';
import Layers from '../Layers/ManageLayers';
import Access from '../Access/AccessPage';
import GroundPlanEditor from '../GroundPlanEditor/GroundPlanEditor';
import NumberGenerator from '../GroundPlanNR/NumberGenerator';
import {CanPermissions} from '../../_components/CanComponent/CanPermissions';
import { confirmAlert } from 'react-confirm-alert';
var CURRENT_TAB = 0;
var NEXT_TAB = 0;
class GroundPlanTab extends Component {
    constructor(props) {
        super(props)
        this.state = {
          t:props.t,
          current_type:'',
          action_type:'view',
          createbuilding : false,
          id :0,
          ipid :0,
          active_tab: localStorage.getItem('active_tab')!=null?localStorage.getItem('active_tab'):1,
        }
        this.currentDetails = this.currentDetails.bind(this);
    }
    componentDidMount(){
      CURRENT_TAB = parseInt(localStorage.getItem('active_tab')!=null?localStorage.getItem('active_tab'):1);
      window.history.pushState('', '', '/managemyorganisation/groundplan'+ '/' + window.GROUND_PLAN_TABS[CURRENT_TAB]);
      // this.setState({
      //   action_type:this.props.match.param!==undefined?this.props.match.params.action_type:'view',
      // })
    }

    componentDidUpdate(prevProps, prevState) {
    }

    shouldComponentUpdate(nextProps, nextState) {
      CURRENT_TAB = parseInt(nextState.active_tab);
      NEXT_TAB = parseInt(this.state.active_tab);
      return true;
    }

    checkGroundPlanDataModifedOrNot(key){
      const { t } = this.state;
      let oldData = sessionStorage.getItem("groundplanOldData");
      let currentData = sessionStorage.getItem("groundplanCurrentData");
      if(oldData !== currentData){
        confirmAlert({
         message: t('You have unsaved changes, do you want to leave without saving'),
          buttons: [
              { label: t('No') },
              { label: t('Yes'),
                onClick: () => this.handlePageClick(key)
              }
          ]});
      }else{ this.handlePageClick(key) }
    }

    currentDetails (action_type) {
      this.setState({
        action_type :action_type,
      })
    }

    handlePageChange(key){
      if((NEXT_TAB !== CURRENT_TAB) && CURRENT_TAB === 4){
        return this.checkGroundPlanDataModifedOrNot(key);
      }
      this.handlePageClick(key);
    }

    handlePageClick(key){
      this.setState({
        active_tab: Number(key),
      });
      window.history.pushState('', '', '/managemyorganisation/groundplan'+ '/' + window.GROUND_PLAN_TABS[key]);
      localStorage.setItem('active_tab', key);
    }

    render = () => {
        const {t,active_tab,current_type,action_type,id,ipid,createbuilding} = this.state;
          return(
              <div class="row col-md-12">
              <div class="col-md-1" style={{visibility: 'hidden'}}> </div>
              <div className="col-md-11 mt-1">
              <reactbootstrap.Tabs activeKey={active_tab} onSelect={this.handlePageChange.bind(this)} id="controlled-tab-example">
                  {(CanPermissions("Access_groundplan,E_building,V_building,D_building,E_inspectionpoint,V_inspectionpoint,D_inspectionpoint", "") === true) &&
                    <reactbootstrap.Tab eventKey={1} title={t("Manage building")}>
                      {active_tab ==1 && <Building {...this.props} current_type={current_type} action_type={action_type} id={id} ipid={ipid} createbuilding={createbuilding} currentDetails={this.currentDetails}></Building>}
                    </reactbootstrap.Tab>
                  }
                  {(CanPermissions("Access_groundplan,E_layer,V_layer,Clone_layer,D_layer", "") === true) &&
                    <reactbootstrap.Tab  eventKey={2} title={t("Manage layers")}>
                      {active_tab ==2 && <Layers/>}
                    </reactbootstrap.Tab>
                  }
                  {(CanPermissions("Access_groundplan,E_groundplan_access,V_groundplan_access", "") === true) &&
                    <reactbootstrap.Tab  eventKey={3} title={t("Manage access")}>
                        {active_tab ==3 &&<Access/>}
                    </reactbootstrap.Tab>
                  }
                  {(CanPermissions("Access_groundplan,E_groundplan_editor,V_groundplan_editor", "") === true) &&
                    <reactbootstrap.Tab  eventKey={4} title={t("Ground plan editor")}>
                        {active_tab ==4 &&<GroundPlanEditor/>}
                    </reactbootstrap.Tab>
                  }
                  {(CanPermissions("Access_groundplan,E_groundplan_editor,V_groundplan_editor", "") === true) &&
                    <reactbootstrap.Tab  eventKey={5} title={t("Number generator")}>
                        {active_tab == 5 && <NumberGenerator/>}
                    </reactbootstrap.Tab>
                  }
              </reactbootstrap.Tabs>
              </div>
              </div>
        );
    }
}
export default translate(GroundPlanTab)
