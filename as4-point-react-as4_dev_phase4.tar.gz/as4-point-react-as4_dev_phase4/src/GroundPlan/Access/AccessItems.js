import React, { useState, useEffect, useRef } from 'react';
import { Button, Form, FormGroup} from 'reactstrap';
import * as reactbootstrap from "react-bootstrap";
import { translate } from '../../language';
import CheckBox from '../../CheckBox';
import './Access.css';

const AccessItems = (props) => {
  const prevProps = usePrevious(props);
  const [state, setState] = useState({
    t: props.t,
    buildings: props.buildings,
    floors: props.floors,
    layers: props.layers,
    selectedBuildingIds: props.allData[props.parent_id]['buildings'],
    selectedFloorIds: props.allData[props.parent_id]['floors'],
    selectedLayerIds: props.allData[props.parent_id]['layers'],
    parentId: props.parent_id,
    allData: props.allData,
  })

  useEffect(() => {
   if(prevProps){
     if (((prevProps.parent_id !== undefined) && (prevProps.parent_id !== props.parent_id)) || (prevProps.activeTab !== props.activeTab)) {
       setState({
         ...state,
         selectedBuildingIds: props.allData[props.parent_id]['buildings'],
         selectedFloorIds: props.allData[props.parent_id]['floors'],
         selectedLayerIds: props.allData[props.parent_id]['layers'],
         parentId: props.parent_id,
         allData: props.allData,
       })
      return;
     }
   }
 })

 const handleCancel = () => {
   props.handleCancel();
   setState({
     ...state,
     selectedBuildingIds: props.originalAccessdata[props.parent_id]['buildings'],
     selectedFloorIds: props.originalAccessdata[props.parent_id]['floors'],
     selectedLayerIds: props.originalAccessdata[props.parent_id]['layers'],
     parentId: props.parent_id,
     allData: props.originalAccessdata,
   })
 }

  const selectedBuildings = (e) => {
    let Id = parseInt(e.target.value);
    if ((props.allData[props.parent_id]['buildings']).includes(Id)) {
        const mainIndex = props.allData[props.parent_id]['buildings'].indexOf(Id);
        props.allData[props.parent_id]['buildings'].splice(mainIndex, 1);
        if (parseInt(props.parent_id) !== window.EVERYONEID) {
          props.allData[window.EVERYONEID_STRING_INDEX]['buildings'].splice(mainIndex, 1)
        }
        if (floors[Id] !== undefined) {
          Object.values(floors[Id]).map(floorIds => {
            if (props.allData[props.parent_id]['floors'].includes(floorIds.id)) {
              let floorIndex = props.allData[props.parent_id]['floors'].indexOf(floorIds.id)
              props.allData[props.parent_id]['floors'].splice(floorIndex, 1);
              if (parseInt(props.parent_id) !== window.EVERYONEID) {
                props.allData[window.EVERYONEID_STRING_INDEX]['floors'].splice(floorIndex, 1)
              }
            }
          })
        }
        if (parseInt(props.parent_id) === window.EVERYONEID) {
          Object.keys(props.allData).map(itemIndex => {
              if (!props.selectedExcludedIds.includes(parseInt(itemIndex))) {
                let BuildingIndex = props.allData[itemIndex].buildings.indexOf(Id)
                if (BuildingIndex !== -1) {
                  props.allData[itemIndex].buildings.splice(BuildingIndex, 1);
                  if (floors[Id] !== undefined) {
                    Object.values(floors[Id]).map(floorIds1 => {
                      if (props.allData[itemIndex].floors.includes(floorIds1.id)) {
                        let floorIndex1 = props.allData[itemIndex].floors.indexOf(floorIds1.id)
                        props.allData[itemIndex].floors.splice(floorIndex1, 1);
                        if (props.allData[itemIndex].floors.length === 0) {
                          props.allData[itemIndex].layers = [];
                        }
                      }
                    })
                  }
                }
              }
          })
        }
        if (props.allData[props.parent_id]['buildings'].length === 0) {
          props.allData[props.parent_id]['floors'] = [];
          props.allData[props.parent_id]['layers'] = [];
        }
    } else {
      props.allData[props.parent_id]['buildings'].push(Id)
      if (parseInt(props.parent_id) === window.EVERYONEID) {
        Object.keys(props.allData).map(key => {
          if (!props.selectedExcludedIds.includes(parseInt(key))) {
            // if ((parseInt(key) !== window.EVERYONEID) && (!props.allData[key]['buildings'].includes(Id))) {
            if (parseInt(key) !== window.EVERYONEID) {
              props.allData[key]['buildings'].push(Id);
            }
          }
        })
      }
    }
    setState({
      ...state,
      selectedFloorIds: props.allData[props.parent_id]['floors'],
      selectedBuildingIds: props.allData[props.parent_id]['buildings'],
    })
  }

  const selectedFloors = (e) => {
    let Id = parseInt(e.target.value);
    if ((props.allData[props.parent_id]['floors']).includes(Id)) {
      const mainIndex = props.allData[props.parent_id]['floors'].indexOf(Id);
      props.allData[props.parent_id]['floors'].splice(mainIndex, 1);
      if (parseInt(props.parent_id) !== window.EVERYONEID) {
        props.allData[window.EVERYONEID_STRING_INDEX]['floors'].splice(mainIndex, 1)
      }
      if (parseInt(props.parent_id) === window.EVERYONEID) {
        Object.keys(props.allData).map(itemIndex => {
          if (!props.selectedExcludedIds.includes(parseInt(itemIndex))) {
            let floorIndex = props.allData[itemIndex].floors.indexOf(Id);
            if (floorIndex !== -1) {
              props.allData[itemIndex].floors.splice(floorIndex, 1);
            }
          }
        })
      }

      if (props.allData[props.parent_id]['floors'].length === 0) {
        props.allData[props.parent_id]['layers'] = [];
      }
    } else {
      props.allData[props.parent_id]['floors'].push(Id)
      if (parseInt(props.parent_id) === window.EVERYONEID) {
        Object.keys(props.allData).map(key => {
          if (!props.selectedExcludedIds.includes(parseInt(key))) {
            if (parseInt(key) !== window.EVERYONEID) {
              props.allData[key]['floors'].push(Id);
            }
          }
        })
      }
    }
    setState({
      ...state,
      selectedFloorIds: props.allData[props.parent_id]['floors'],
      selectedLayerIds: props.allData[props.parent_id]['layers'],
    })
  }

  const selectedLayers = (e) => {
    let Id = parseInt(e.target.value);
    if ((props.allData[props.parent_id]['layers']).includes(Id)) {
      const mainIndex = props.allData[props.parent_id]['layers'].indexOf(Id);
      props.allData[props.parent_id]['layers'].splice(mainIndex, 1);
      if (parseInt(props.parent_id) !== window.EVERYONEID) {
        props.allData[window.EVERYONEID_STRING_INDEX]['layers'].splice(mainIndex, 1)
      }
      if (parseInt(props.parent_id) === window.EVERYONEID) {
        Object.keys(props.allData).map(itemIndex => {
          if (!props.selectedExcludedIds.includes(parseInt(itemIndex))) {
            let layerIndex = props.allData[itemIndex].layers.indexOf(Id);
            if (layerIndex !== -1) {
              props.allData[itemIndex].layers.splice(layerIndex, 1);
            }
          }
        })
      }
    } else {
      props.allData[props.parent_id]['layers'].push(Id)
      if (parseInt(props.parent_id) === window.EVERYONEID) {
        Object.keys(props.allData).map(key => {
          if (!props.selectedExcludedIds.includes(parseInt(key))) {
            if (parseInt(key) !== window.EVERYONEID) {
              props.allData[key]['layers'].push(Id);
            }
          }
        })
      }
    }
    setState({
      ...state,
      selectedLayerIds: props.allData[props.parent_id]['layers'],
    })
  }

  const {t} = props;
  const { buildings, floors, layers, selectedBuildingIds, selectedFloorIds, selectedLayerIds } = state;
  const formDisable = (props.type === 'view') ? 'disabled' : '';

  return (
    <div className='container pl-0' >
      <div className='row justify-content-center' >
        <div className='col-lg-12 col-md-12 float-left px-0' >
            <reactbootstrap className="">
              <reactbootstrap.Form >
                <fieldset disabled={formDisable}>
                  <div className='row'>
                    {(props.hideBuildings === false) &&
                      <div className='col-md-4 pr-0' style={{ }}>
                        <Button className="btn btn-primary custombutton" type="button" color="primary" style={{width: '100%'}}> {t('Buildings')} </Button>
                        <div style={{border: '2px solid lightgray', height: '48.3vh', overflow: 'auto'}}>
                          {buildings.map(building =>
                            <>
                              {((props.itemId === building.id) || (props.itemId === undefined)) &&
                                <div class="">
                                  <CheckBox
                                      name={building.code + '-' + building.name}
                                      tick={(selectedBuildingIds.includes(building.id)) ? true : false}
                                      onCheck={e => selectedBuildings(e)}
                                      value={building.id}
                                  />
                                </div>
                              }
                            </>
                          )}
                        </div>
                      </div>
                    }
                    {(props.hideFloors === false) &&
                      <div className='col-md-4 mob-space' style={{ }}>
                        {(selectedBuildingIds.length > 0) &&
                          <>
                            <Button className="btn btn-primary custombutton" type="button" color="primary" style={{width: '100%'}}> {t('Floors')} </Button>
                            <div style={{border: '2px solid lightgray', height: '48.3vh', overflow: 'auto'}}>
                              {selectedBuildingIds.map(buildingId => (
                                <>
                                  {(floors[buildingId] !== undefined) &&
                                    <>
                                    {Object.values(floors[buildingId]).map(floor => (
                                      <>
                                        {((props.itemId === floor.id) || (props.itemId === undefined)) &&
                                          <div class="">
                                            <CheckBox
                                              name={floor.code + '-' + floor.name}
                                              tick={(selectedFloorIds.includes(floor.id)) ? true : false}
                                              onCheck={e => selectedFloors(e)}
                                              value={floor.id}
                                            />
                                          </div>
                                        }
                                      </>
                                    ))}
                                    </>
                                  }
                                </>
                              ))}
                            </div>
                          </>
                        }
                      </div>
                    }
                    {(props.hideLayers === false) &&
                      <div className='col-md-4 pl-0 mob-layer' style={{ }}>
                        {(selectedFloorIds.length > 0) &&
                          <>
                          <Button className="btn btn-primary custombutton" type="button" color="primary" style={{width: '100%'}}> {t('Layers')} </Button>
                          <div style={{border: '2px solid lightgray', height: '48.3vh', overflow: 'auto'}}>
                            {layers.map(layer => (
                              <div class="">
                                <CheckBox
                                  name={layer.code + '-' + layer.name}
                                  tick={(selectedLayerIds.includes(layer.id)) ? true : false}
                                  onCheck={e => selectedLayers(e)}
                                  value={layer.id}
                                />
                              </div>
                            ))}
                          </div>
                          </>
                        }
                      </div>
                    }
                  </div>
                  <FormGroup>
                    <div style={{ float: 'right' }} className="organisation_list mt-3">
                      {(props.type !== 'view') &&
                        <a onClick={handleCancel} >{t('Cancel')}</a>
                      }
                      &nbsp;&nbsp;&nbsp;
                      <Button className="btn btn-primary" type="button" color="primary" onClick={() => props.handleSubmit(props.allData)}> {t('Save')} </Button>
                    </div>
                  </FormGroup>
                </fieldset>
              </reactbootstrap.Form>
            </reactbootstrap>
        </div>
      </div>
    </div>
  );
}
export default translate(AccessItems);

function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
