import React, { useState, useEffect, useRef } from 'react';
import { Form, Button } from 'reactstrap';
import {translate} from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import Pagination from 'react-bootstrap/Pagination';
import PersonImg from '../../images/personc.png';
import JobImg from '../../images/jobc.png';
import AccessItems from './AccessItems';
import Can from '../../_components/CanComponent/Can';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
import MultiSelect from '../../_components/MultiSelect';

const AccessPage = props => {
  const [state, setState] = useState({
    t: props.t,
    activeTab: 0,
    personsJobs: [],
    currentTab : 'persons',
    page: 5,
    active: 1,
    component: 'false',
    type: 'view',
    buildings: [],
    floors: [],
    layers: [],
    allData: [],
    searchTerm: '',
    personsPagesCount: 0,
    jobsPagesCount: 0,
    items: [],
    hideBuildings: (props.itemType === 2) ? true : false,
    hideFloors: (props.itemType === 1) ? true : false,
    hideLayers: (props.itemType === 1 || props.itemType === 2) ? true : false,
    showJobPopup: false,
    curentlyHoveredJob: [],
    showExcludePersons: false,
    selectedExcludedPersons: [],
    persons: [],
    jobs: [],
    excludePersons: [],
    currentJobData: [],
    originalAccessdata: [],
    mergeUpdate: false,
    previousId: null,
  })

  useEffect(() => {
    fetchData();
  }, []);

  const accessData = window.FETCH_ACCESS_DATA;
  async function fetchData(mergeCancel = 0) {
    await datasave.service(accessData, 'GET')
      .then(response => {
        if (response.status === 200) {
          const categories = ['persons', 'jobs', 'default'];
          const PJDG = response.data.personJobs;
          const peronsJobs = PJDG.filter(item => (categories.includes(item.category)));

          const buildings = response.data.buildings.original.data;
          const floors = response.data.floors.original.data;
          const layers = response.data.layers.original.data;
          const accessData = response.data.accessData;
          const persons = peronsJobs.filter(item => (item.category === 'persons' && parseInt(item.activeornot) === 1));
          const jobs = peronsJobs.filter(item => (item.category === 'jobs'));
          const defaultTabData = peronsJobs.filter(item => (item.category === 'default'));
          const excludeOptions = response.data.excludeOptions;
          var fist_list = persons[0];

          const personsPageData = getPageData(state.active, persons);
          const personsPagesCount = getCountPage(persons);
          const jobsPageData = getPageData(state.active, jobs);
          const jobsPagesCount = getCountPage(jobs);

          setState({
            ...state,
            personsJobs: peronsJobs,
            personsItems: personsPageData,
            jobsPageItems: jobsPageData,
            defaultPageItems: defaultTabData,
            buildings: buildings,
            floors: floors,
            layers: layers,
            allData: accessData,
            parent_id: (mergeCancel === 0) ? (fist_list ? fist_list['id'] : undefined) : state.parent_id,
            persons: persons,
            jobs: jobs,
            component: (peronsJobs.length > 0) ? 'true' : 'false',
            type: 'view',
            personsPagesCount: personsPagesCount,
            jobsPagesCount: jobsPagesCount,
            items: (state.currentTab === 'persons' || state.currentTab === 'jobs') ? ((state.currentTab === 'persons') ? personsPageData : jobsPageData) : defaultTabData,
            excludePersons: excludeOptions,
            selectedExcludedPersons: response.data.excludedPersons,
            selectedExcludedIds: response.data.selectedExcludePersonsIds,
            originalAccessdata: response.data.originalAccessData,
            mergeUpdate: false,
          })
        }
      })
  }

  const handleSelectTab = (e) => {
    setState({
      ...state,
      active: 1,
      activeTab: parseInt(e),
      currentTab : (parseInt(e) === 0 || parseInt(e) === 1) ? ((parseInt(e) === 0) ? 'persons' : 'jobs') : 'default',
      type: 'view',
      parent_id: (parseInt(e) === 0 || parseInt(e) === 1) ? ((parseInt(e) === 0) ? state.persons[0]['id'] : state.jobs[0]['id']) : state.defaultPageItems[0]['id'],
      items: (parseInt(e) === 0 || parseInt(e) === 1) ? ((parseInt(e) === 0) ? state.personsItems : state.jobsPageItems) : state.defaultPageItems,
    });
  }

  const getCountPage = (items) => {
    const itemLength = items.length;
    return (itemLength > state.page) ? Math.ceil(itemLength / state.page) : 0;
  }


  const getPageData = (id, list = '') => {
    const page = state.page;
    const allItems = (state.currentTab === 'persons') ? state.persons : state.jobs;
    const items = (list !== '') ? list : allItems;
    const page_data = items.slice(page * (id - 1), page * id);

    return page_data;
  }

  const searchData = (e) => {
    var list = (state.currentTab === 'persons') ? [...state.persons] : [...state.jobs];
    let res = '';
    list = list.filter(function (item) {
      if (item.category === state.currentTab) {
          res = item.name.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
      return res;

    });

    const page_data = getPageData(1, list);
    const count = getCountPage(list);

    setState({
      ...state,
      items: page_data,
      personsPagesCount: (state.currentTab === 'persons') ? count : state.personsPagesCount,
      jobsPagesCount: (state.currentTab === 'jobs') ? count : state.jobsPagesCount,
      active: 1,
      searchTerm: e.target.value,
      filterFullList: list,
    });
  }

  const changePage = (e, id, tabType) => {
    const list = (state.searchTerm !== '') ? state.filterFullList : '';
    const page_data = getPageData(id, list);
    setState({
      ...state,
      items: page_data,
      active: id,
    });
  }

  const changeComponent = (e, type, id = undefined, previousId = null) => {
    setState({
      ...state,
      component: 'true',
      type: type,
      parent_id: id,
    });
    if (state.currentTab === 'jobs' && previousId !== null) {
      mergeUpdateData(previousId, id);
    }
  }

  const mergeUpdateData = (previousId, jobId) => {
    if (previousId !== jobId) {
      const originalData = state.originalAccessdata[previousId];
      const modifiedData = state.allData[previousId];
      let buildings = [];
      let floors = [];
      let layers = [];

      if (modifiedData['buildings'].length > originalData['buildings'].length) {
        buildings = modifiedData['buildings'].filter(building => (!originalData['buildings'].includes(building)));
      } else if (originalData['buildings'].length > modifiedData['buildings'].length) {
        buildings = originalData['buildings'].filter(building => (!modifiedData['buildings'].includes(building)));
      } else {
        let buildings1 = originalData['buildings'].filter(building => (!modifiedData['buildings'].includes(building)));
        let buildings2 = modifiedData['buildings'].filter(building => (!originalData['buildings'].includes(building)));
        buildings = buildings1.concat(buildings2);
      }

      if (modifiedData['floors'].length > originalData['floors'].length) {
        floors = modifiedData['floors'].filter(building => (!originalData['floors'].includes(building)));
      } else if (originalData['floors'].length > modifiedData['floors'].length) {
        floors = originalData['floors'].filter(building => (!modifiedData['floors'].includes(building)));
      } else {
        let floors1 = originalData['floors'].filter(building => (!modifiedData['floors'].includes(building)));
        let floors2 = modifiedData['floors'].filter(building => (!originalData['floors'].includes(building)));
        floors = floors1.concat(floors2);
      }

      if (modifiedData['layers'].length > originalData['layers'].length) {
        layers = modifiedData['layers'].filter(building => (!originalData['layers'].includes(building)));
      } else if (originalData['layers'].length > modifiedData['layers'].length) {
        layers = originalData['layers'].filter(building => (!modifiedData['layers'].includes(building)));
      } else {
        let layers1 = originalData['layers'].filter(building => (!modifiedData['layers'].includes(building)));
        let layers2 = modifiedData['layers'].filter(building => (!originalData['layers'].includes(building)));
        layers = layers1.concat(layers2);
      }
      if ((buildings.length > 0) || (floors.length > 0) || (layers.length > 0)) {
        setState({
          ...state,
          mergeUpdate: true,
          previousId: previousId,
          parent_id: jobId,
        });
      }
    }
  }

  const handleSubmit = (allData, handleOk = 0) => {
    const accessUrl = window.SAVE_ACCESS_DATA;
    const submitData = {
      data : allData,
      excludedPersons : state.selectedExcludedPersons,
    }
    setState({
      ...state,
      type: 'view',
      mergeUpdate: false,
    })

    datasave.service(accessUrl, 'POST', submitData)
    .then(response => {
      if (response.status === 200) {
        OCAlert.alertSuccess(t('Updated successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
        fetchData(1);
      } else {
        OCAlert.alertWarning(t('Something went wrong in saving data'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    })
  }

  const handleCancel = () => {
    const originalData = state.originalAccessdata;
    setState({
      ...state,
      activeTab: 0,
      component: 'true',
      type: 'view',
      allData: originalData,
    });
    fetchData(1);
  }

  const excludePersons = (e) => {
      setState({
          ...state,
          showExcludePersons: true,
      })
  }

  const handleHide = () => {
    setState({
        ...state,
        showExcludePersons: false,
        active: state.active,
        showJobPopup: false,
        mergeUpdate: false,
    });
  }


  const handlePersons = (item) => {
    if(state.currentTab === 'jobs') {
      const url = window.GetAllLinkedPersons + '/' + item.id + '/' + window.JOB_ENTITY;
      datasave.service(url, "GET", '')
        .then(result => {
            setState({
                ...state,
                showJobPopup: true,
                curentlyHoveredJob: result[item.id]
            })
        })
        .catch(error => {

        })
    }
  }

  const selectExcludePersons = (event) => {
    let newIds = [];
    event.map(item => (
      newIds.push(item.value)
    ));
    setState({
      ...state,
      selectedExcludedPersons: event,
      selectedExcludedIds: newIds,
    });
  }

  const cancelMergeUpdate = () => {
    // let originalJobData = state.originalAccessdata;
    // let modifiedJobData = state.allData;
    // modifiedJobData[state.previousId] = originalJobData[state.previousId];
    // setState({
    //   ...state,
    //   mergeUpdate: false,
    //   allData: modifiedJobData,
    // });
    fetchData(1);
  }

  const handleOk = () => {
    let newAllData = state.allData;
    let newDataOfJob = state.allData[state.previousId]
    const url = window.GetAllLinkedPersons + '/' + state.previousId + '/' + window.JOB_ENTITY;
    datasave.service(url, "GET", '')
      .then(result => {
        result[state.previousId].map((item) => {
          newAllData[item.id] = newDataOfJob;
        })
        setState({
          ...state,
          mergeUpdate: false,
          allData: newAllData,
        });
        handleSubmit(newAllData, 1);
      })
      .catch(error => {

      })
  }

  const { t, activeTab, active, currentTab, parent_id, personsPagesCount, jobsPagesCount} = state;

  const excludePersonsContent = (
      <reactbootstrap.Modal
          show={state.showExcludePersons}
          onHide={handleHide}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
          <reactbootstrap.Modal.Header closeButton>
              <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                  Exclude persons
          </reactbootstrap.Modal.Title>
              <reactbootstrap.Modal.Body>
                <div class="col-md-12 input-padd">
                  <div className="input_sw">
                    <MultiSelect
                      options={state.excludePersons}
                      standards={state.selectedExcludedPersons}
                      handleChange={e => selectExcludePersons(e)}
                    />
                  </div>
                </div>
              </reactbootstrap.Modal.Body>
          </reactbootstrap.Modal.Header>
      </reactbootstrap.Modal>
  );

  const jobPopupContent = (
      <reactbootstrap.Modal
          show={state.showJobPopup}
          onHide={handleHide}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
          <reactbootstrap.Modal.Header closeButton>
              <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                  Persons
              </reactbootstrap.Modal.Title>
              <reactbootstrap.Modal.Body>
                  <ul>
                      {state.curentlyHoveredJob.length != 0 &&
                          state.curentlyHoveredJob.map(person =>
                              <li>{person.name}</li>
                          )
                      }
                      {state.curentlyHoveredJob.length === 0 &&
                          'No persons are linked'
                      }
                  </ul>
              </reactbootstrap.Modal.Body>
          </reactbootstrap.Modal.Header>
      </reactbootstrap.Modal>
  );

  const mergeUpdatePopup = (
      <reactbootstrap.Modal
          show={state.mergeUpdate}
          onHide={handleHide}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
          <reactbootstrap.Modal.Header closeButton>
              <reactbootstrap.Modal.Title id="contained-modal-title-vcenter">
                  Persons
              </reactbootstrap.Modal.Title>
              <reactbootstrap.Modal.Body>
                  <p>{t("Items linked to this job and for persons of this job are Different, do want us to merge and update?")}</p>
                  <div style={{ float: 'right' }} className="organisation_list mt-3">
                    <a onClick={cancelMergeUpdate} >{t('Cancel')}</a>
                    &nbsp;&nbsp;&nbsp;
                    <Button className="btn btn-primary" type="button" color="primary" onClick={() => handleOk()}> {t('OK')} </Button>
                  </div>
              </reactbootstrap.Modal.Body>
          </reactbootstrap.Modal.Header>
      </reactbootstrap.Modal>
  );

  let personsPages = [];
  if (personsPagesCount > 0)
    for (let number = 1; number <= personsPagesCount; number++) {
      personsPages.push(
        <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => changePage(e, number, 'persons')}>
          {number}
        </Pagination.Item>,
      );
  }
  let jobsPages = [];
  if (jobsPagesCount > 0)
    for (let number = 1; number <= jobsPagesCount; number++) {
      jobsPages.push(
        <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => changePage(e, number , 'jobs')}>
          {number}
        </Pagination.Item>,
      );
  }

  const pageItems =
    state.items.map((parent, key) => {
      let higlet_class = (parent.id == parent_id) ? 'sactive' : 'sinactive';
      return (
        <>
          {parent.category === currentTab &&
            <tr style={{ borderBottom: "1px solid #dee2e6" }} className={higlet_class}>
              <td style={{ cursor: 'pointer', hover: 'color:#007bf8' }} onClick={(e) => changeComponent(e, 'view', parent.id)}>
                  <img style={{ float: 'left' }}  src={(currentTab === 'persons' || currentTab === 'default') ? PersonImg : JobImg} alt={currentTab} onClick={(e) => handlePersons(parent)}/>
                  <span>{parent.name}</span>
              </td>
              <td style={{ display: "flex", justifyContent: 'center', borderTop: '0px', borderBottom: '0px', borderLeft: '0px' }}>
                <div style={{ paddingLeft: '10px' }}>
                  <Can
                     perform = "Access_groundplan,E_groundplan_access"
                     yes = {() => (
                       <div style={{ display: 'flex', textAlign: 'center' }} >
                         <span className="" variant="link">
                           <i title="Edit" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc" onClick={(e) => changeComponent(e, 'edit', parent.id, state.parent_id)}></i>
                           {mergeUpdatePopup}
                         </span>
                         {currentTab === 'default' &&
                           <span className="" variant="link">
                             <img style={{ 'cursor': 'pointer', paddingLeft: '10px', paddingRight: '10px' }} src={PersonImg} alt={"exclude"} onClick={(e) => excludePersons(e)}/>
                             {excludePersonsContent}
                           </span>
                         }
                       </div>
                      )}
                  />
                </div>
              </td>
            </tr>
          }
        </>
      )
  })


  return (
    <Can
       perform = "Access_groundplan,E_groundplan_access,V_groundplan_access"
       yes = {() => (
          <div className='col-md-12 pl-0'>
            <div className="card-body mb-3 px-0">
              <div className='row'>
                <div className='col-md-12  mb-3 pr-0'>
                  <div className='card'>
                    <div className="text-left">
                    </div>
                    <div className="container" style={{paddingBottom: '20px'}}>
                    <div className="row">
                      <reactbootstrap.Col lg={4}>
                        <div className="text-center">
                          <reactbootstrap.Form >
                            <reactbootstrap.Tabs id="controlled-tab-example" activeKey={activeTab} onSelect={(e) => handleSelectTab(e)}>
                              <reactbootstrap.Tab eventKey={0} title={t("Persons")}>
                                <reactbootstrap.Table responsive bordered hover>
                                  <thead>
                                    <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
                                      <th>{t('Name')}</th>
                                      <th>{t('Actions')}</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C", width: "138%" }} placeholder={t("What are you looking for ?")} autoFocus onChange={(e) => searchData(e)} /><br />
                                    {pageItems}
                                  </tbody>
                                </reactbootstrap.Table>
                                <div className="pg col-md-12">
                                  {personsPages.length > 1 && <Pagination style={{ width: '295px', overflow: 'auto', marginBottom: '0px' }} size="md">{personsPages}</Pagination>}
                                </div>
                              </reactbootstrap.Tab>
                              <reactbootstrap.Tab eventKey={1} title={t('Jobs')}>
                                <reactbootstrap.Table responsive bordered hover>
                                  <thead>
                                    <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
                                      <th>{t('Name')}</th>
                                      <th>{t('Actions')}</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C", width: "138%" }} placeholder={t("What are you looking for ?")} autoFocus onChange={(e) => searchData(e)} /><br />
                                    {pageItems}
                                    {jobPopupContent}
                                  </tbody>
                                </reactbootstrap.Table>
                                <div className="pg col-md-12">
                                  {jobsPages.length > 1 && <Pagination style={{ width: '200px', overflow: 'auto' }} size="md">{jobsPages}</Pagination>}
                                </div>
                              </reactbootstrap.Tab>
                              <reactbootstrap.Tab eventKey={2} title={t('Default')}>
                                <reactbootstrap.Table responsive bordered hover>
                                  <thead>
                                    <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
                                      <th>{t('Name')}</th>
                                      <th>{t('Actions')}</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {/* <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C", width: "148%" }} placeholder={t("What are you looking for ?")} autoFocus onChange={(e) => searchData(e)} /><br /> */}
                                    {pageItems}
                                  </tbody>
                                </reactbootstrap.Table>
                              </reactbootstrap.Tab>
                            </reactbootstrap.Tabs>
                          </reactbootstrap.Form>
                        </div>
                      </reactbootstrap.Col>
                      {state.component === 'true' &&
                        <reactbootstrap.Col lg={8}>
                          <h3 className=""></h3>
                          <AccessItems type={state.type} parent_id={state.parent_id} type={state.type} buildings={state.buildings} floors={state.floors} allData={state.allData}
                            layers={state.layers} activeTab={state.currentTab} handleCancel={handleCancel.bind()} handleSubmit={handleSubmit.bind()} hideBuildings={state.hideBuildings}
                            hideFloors={state.hideFloors} hideLayers={state.hideLayers} itemId={props.itemId} originalAccessdata={state.originalAccessdata} selectedExcludedIds={state.selectedExcludedIds}/>
                        </reactbootstrap.Col>
                      }
                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        no={() =>
            <AccessDeniedPage />
        }
      />
  );
}

export default translate(AccessPage);

function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
