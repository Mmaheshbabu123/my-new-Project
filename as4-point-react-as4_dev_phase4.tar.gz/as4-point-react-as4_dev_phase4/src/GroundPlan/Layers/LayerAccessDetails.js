import React, { useState, useEffect } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../../language';
import PersonImg from '../../images/personc.png';
import JobImg from '../../images/jobc.png';
// import Pagination from 'react-bootstrap/Pagination';
import Paginator from '../../Paginator';
import { datasave } from '../../_services/db_services';
import * as reactbootstarp from 'react-bootstrap';

const LayerAccessDetails = (props) => {
  const t = props.t;
  const [accessData, manageAccessData] = useState({
    person: props.accessPersons,
    job: props.accessJobs,
    tab: 1,
    currentData: props.accessPersons,
    image: PersonImg,
    page: 5,
    active: 1,
    accessPagesCount: 0,
    searchTerm: '',
    show: false,
    curently_hovered_item: [],
  });
  var { person, job, tab, currentData, image, active, page, accessPagesCount, filterFullList, searchTerm } = accessData;

  useEffect(() => {
    const fetchLayerData = async () => {
      await setAccessData();
    }
    fetchLayerData();
  }, []);

  useEffect(() => {
    const fetchLayerData = async () => {
      await setAccessData();
    }
    fetchLayerData();
  }, [props]);

  const setAccessData = async () => {
    await manageAccessData({
      ...accessData,
      person: props.accessPersons,
      job: props.accessJobs,
      currentData: await getPageData(active, tab == 1 ? props.accessPersons : props.accessJobs),
      accessPagesCount: await getCountPage(tab == 1 ? props.accessPersons : props.accessJobs),
      tab:1,
    })
  }

  const getPageData = async (id, list) => {
    const allItems = tab == 1 ? person : job;
    const items = (list.length > 0) ? list : allItems;
    return items.slice(page * (id - 1), page * id);
  }

  const getCountPage = (items) => {
    return (items.length > page) ? Math.ceil(items.length / page) : 0;
  }

  // const PageData = (
  //   currentTabDetails.length > 0 && Object.values(currentTabDetails).map((item, key) => {
  //     return (
  //       <tr>
  //         <td>
  //           <span style={{ paddingRight: '5px' }}><img src={image} onClick={(e) => handlePersons(item)}/></span>
  //           <span>{parseInt(tab) === 1 ? item.person_name : item.job_name}</span>
  //         </td>
  //       </tr>
  //     )
  //   })
  // );
  //
  // let currentTabDetails = (parseInt(tab) === 1) ? person : job ;

  const PageData = (
    currentData.length > 0 && Object.values(currentData).map((item, key) => {
      let status = parseInt(tab) === 1 ? item.status : 1;
      let name = parseInt(tab) === 1 ? item.person_name : item.job_name;
      if(name && status){
      return (
        <>
        {(parseInt(tab) === 1) && (item.person_name !== null) &&
          <tr>
            <td>
              <span style={{ paddingRight: '5px' }}><img src={image} onClick={(e) => handlePersons(item)}/></span>
                <span style={{display:'inline-block', width:'80%', textAlign:'center'}}>
                  {item.person_name}
                </span>

            </td>
          </tr>
        }
        {(parseInt(tab) === 2) && (item.job_name !== null) &&
          <tr>
            <td>
              <span style={{ paddingRight: '5px' }}><img src={image} onClick={(e) => handlePersons(item)}/></span>
                <span style={{display:'inline-block', width:'80%', textAlign:'center'}}>
                  {item.job_name}
                </span>

            </td>
          </tr>
        }
        </>
      )
    }})
  );
  const searchData = async (value) => {
    var name ='';
    var list1 = Object.values(tab == 1 ? person : job).filter(function (item, key) {
      if(tab == 1 && item.person_name!==null){
        name = item.person_name;
      }
      if(tab == 2 && item.job_name!==null){
        name = item.job_name;
      }
      return name && name.toLowerCase().search(
        value.toLowerCase()) !== -1;
    });

    await manageAccessData({
      ...accessData,
      currentData: await getPageData(1, list1),
      accessPagesCount: await getCountPage(list1),
      active: 1,
      filterFullList: list1,
      searchTerm: value,
    });
  }

  // let accessPages = [];
  // if (accessPagesCount > 0)
  //   for (let number = 1; number <= accessPagesCount; number++) {
  //     accessPages.push(
  //       <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => changePage(e, number)}>
  //         {number}
  //       </Pagination.Item>,
  //     );
  //   }

  const changePage = async (id) => {
    const list = (searchTerm !== '') ? filterFullList : '';
    let djd = await getPageData(id, list)
    await manageAccessData({
      ...accessData,
      currentData: djd,
      active: id,
    });
  }
const css = {
   width: '295px', overflow: 'auto', marginBottom: '0px'
};
  const TableForAccess = (
    <>
      <reactbootstrap.Table responsive bordered hove>
        <thead>
          <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
            <td>{t('Name')}</td>
          </tr>
        </thead>
        <tbody>
          <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C" }} placeholder={t("What are you looking for ?")} autoFocus onChange={(e) => searchData(e.target.value)} /><br />
          {PageData}
        </tbody>
      </reactbootstrap.Table>
      <Paginator count={accessPagesCount} active={active} changePage={changePage} css={css} size="md"/>
      {/**<Pagination style={{ width: '295px', overflow: 'auto', marginBottom: '0px' }} size="md">{accessPages}</Pagination>*/}
    </>
  );

  const changeTab = async (key) => {
    await manageAccessData({
      ...accessData,
      tab: parseInt(key),
      currentData: await getPageData(1, (parseInt(key) == 1 ? props.accessPersons : props.accessJobs)),
      accessPagesCount: await getCountPage(parseInt(key) == 1 ? props.accessPersons : props.accessJobs),
      image: parseInt(key) === 1 ? PersonImg : JobImg,
      searchTerm: '',
      active: 1,
      page: 5,
    })
  }
  const handleHide = () => {
    manageAccessData({
        ...accessData,
        show: false,
    });
  }

  const handlePersons = (item) => {
    if (tab === 2) {
      const url = window.GetAllLinkedPersons + '/' + item.j_id + '/' + window.JOB_ENTITY;
      datasave.service(url, "GET", '')
        .then(result => {
            manageAccessData({
                ...accessData,
                show: true,
                curently_hovered_item: result[item.j_id]
            })
        })
        .catch(error => {

        })
    }
  }

  const popupContent = (
      <reactbootstarp.Modal
          show={accessData.show}
          onHide={handleHide}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
          <reactbootstarp.Modal.Header closeButton>
              <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
                  {t("Persons")}
          </reactbootstarp.Modal.Title>
              <reactbootstarp.Modal.Body>
                  <ul>
                      {accessData.curently_hovered_item.length != 0 &&
                          accessData.curently_hovered_item.map(person =>
                              <li>{person.name}</li>
                          )
                      }
                      {accessData.curently_hovered_item.length === 0 &&
                          t('No persons are linked')
                      }
                  </ul>
              </reactbootstarp.Modal.Body>
          </reactbootstarp.Modal.Header>
      </reactbootstarp.Modal>
  );

  return (
      <reactbootstrap.Container className="px-0 mt-1">
        {(person.length > 0 || job.length > 0) &&
          <reactbootstrap.Tabs activeKey={tab} onSelect={(key) => changeTab(key)}>
              <reactbootstrap.Tab eventKey={1} title={t("Persons")}>
                {TableForAccess}
              </reactbootstrap.Tab>
              <reactbootstrap.Tab eventKey={2} title={t("Jobs")}>
                {TableForAccess}
                {popupContent}
              </reactbootstrap.Tab>
          </reactbootstrap.Tabs>
        }
      </reactbootstrap.Container>
  );
}
export default translate(LayerAccessDetails);
