import React, { useState, useEffect } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../../language';
import TreeMenu from 'react-simple-tree-menu';
import { ListGroup, ListGroupItem, Input } from 'reactstrap';
import MultiSelect from '../../_components/MultiSelect';
import manageunlink from '../../Space/manage-unlink.png';
import managelink from '../../Space/manage-link.png';
const BuildingLayerFolderStracture = (props) => {
  const t = props.t;
  const [buildingData, manageBuildingData] = useState({
    buildingOptions: props.inspectionPointData.buildings,
    allBuildingData: props.inspectionPointData.buildingStracture,
    openNodes: props.inspectionPointData.openNodes,
    selectedbuilding: [],
    activeOpenNode: '',
  });
  useEffect(() => {
    const fetchLayerData = async () => {
      await setDbData();
    }
    fetchLayerData();
  }, []);
  useEffect(() => {
    const fetchLayerData = async () => {
      await setDbData();
    }
    fetchLayerData();
  }, [props]);
  const setDbData = async () => {
    await manageBuildingData({
      ...buildingData,
      buildingOptions: props.inspectionPointData.buildings,
      allBuildingData: props.inspectionPointData.buildingStracture,
      openNodes: props.inspectionPointData.openNodes,
      selectedbuilding: [],
      activeOpenNode: '',
    })
  }
  const handleChangebuilding = async (e) => {
    await manageBuildingData({
      ...buildingData,
      selectedbuilding: e,
    })
  }
  const onClickNode = async (key, label, props) => {
    var openNodeArray = buildingData.openNodes;
    if (openNodeArray && openNodeArray.includes(key)) {
      var index = openNodeArray.indexOf(key);
      if (index !== -1) openNodeArray.splice(index, 1);
    } else {
      openNodeArray.push(key);
    }
    await manageBuildingData({
      ...buildingData,
      activeOpenNode: key,
      openNodes: openNodeArray
    });
  }
  const DEFAULT_PADDING = 5;
  const ICON_SIZE = 8;
  const LEVEL_SPACE = 16;
  const DISPLAY = 'inline-flex';
  const WIDTH_DYNAMIC = 33;
  const ToggleIcon = ({ on }) => <span style={{ marginRight: 8 }}>{on ? '-' : '+'}</span>;
  const ListItem = ({
    level = 0,
    hasNodes,
    isOpen,
    label,
    searchTerm,
    openNodes,
    value,
    buildingId,
    parent,
    current_type,
    childrens,
    key_type,
    layer,
    ...props
  }) => (
      <reactbootstrap.Col className="folder-manual-section">
        <ListGroupItem
          {...props}
          style={{ paddingLeft: DEFAULT_PADDING + ICON_SIZE + level * LEVEL_SPACE, cursor: 'pointer' }}
          key={key_type}
        >
          <reactbootstrap.Col className="list-items-structure" style={{ width: WIDTH_DYNAMIC - (level - 1) + 'rem' }}>
            {hasNodes && <ToggleIcon on={isOpen} />}
            {!hasNodes && <span style={{ marginRight: 8 }}> &nbsp;</span>}
            {current_type === 'flore' &&
              <i class="folder-icons folder-icons-folder" title={t("Flore")} style={{ marginRight: '5px' }}> </i>
            }
            {current_type === 'inspectionPoint' &&
              <i class='overall-sprite overall-sprite-msdocumentc' title={t('Inspection point')} style={{ display: DISPLAY, marginLeft: '3px', marginRight: '3px' }} />
            }
            <p className="result-label">{label}</p>
            {current_type === 'inspectionPoint' && layer > 0 &&
              <reactbootstrap.Col>
                <img src={manageunlink} style={{ width: '20px', height: '20px', marginLeft: '10px', float: 'right' }}></img>
              </reactbootstrap.Col>
            }
            {current_type === 'inspectionPoint' && layer < 1 &&
              <reactbootstrap.Col>
                <img src={managelink} style={{ width: '20px', height: '20px', marginLeft: '10px', float: 'right' }}></img>
              </reactbootstrap.Col>
            }
          </reactbootstrap.Col>
        </ListGroupItem>
      </reactbootstrap.Col>
    );
  var { buildingOptions, selectedbuilding, activeOpenNode, openNodes, allBuildingData } = buildingData;
  return (
    allBuildingData ?
      <reactbootstrap.Container>
        {Object.keys(allBuildingData).length > 0 && <reactbootstrap.Row>
          <reactbootstrap.Col className='col-md-2 pt-2'>
          <img src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5efb0f0882f5b7.528854791593511688.png" title={t("Buildings")} style={{width:'42px'}}/>
          </reactbootstrap.Col>
          <reactbootstrap.Col className='col-md-10 pt-2' style={{ zIndex: 999 }}>
            <MultiSelect
              options={buildingOptions}
              standards={selectedbuilding}
              handleChange={handleChangebuilding}
              isMulti={false} />
          </reactbootstrap.Col>
        </reactbootstrap.Row>}
        {Object.keys(allBuildingData).length > 0 && <reactbootstrap.Row>
          <reactbootstrap.Col className='col-md-12 pt-2'>
            <TreeMenu
              data={allBuildingData[selectedbuilding.id] ? allBuildingData[selectedbuilding.id] : []}
              hasSearch='false'
              onClickItem={({ key, label, ...props }) => { onClickNode(key, label, props); }}
              debounceTime={125}
              activeKey={activeOpenNode}
              openNodes={openNodes}
            >
              {({ search, items }) => (
                <>
                {Object.keys(selectedbuilding).length>0 &&  <Input onChange={e => search(e.target.value)} placeholder={t("Type and search")} />}
                  <ListGroup className="folder-left-list-group">
                    {items.map(props => (<ListItem {...props} />))}
                  </ListGroup>
                </>
              )}
            </TreeMenu>
          </reactbootstrap.Col>
        </reactbootstrap.Row>}
      </reactbootstrap.Container>
      :
      <></>
  )
}
export default translate(BuildingLayerFolderStracture);
