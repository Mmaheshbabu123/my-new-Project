import React, { useState, useEffect, } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../../language';
import { reducers } from '../Building/Reducers/reducers';
import { SearchFilter } from '../../SearchFilter';
import Paginator from '../../Paginator';
import CommonPopUp from './CommonPopUp';
import BuildingLayerFolderStracture from './BuildingLayerFolderStracture';
import LayerAccessDetails from './LayerAccessDetails';
// import Pagination from 'react-bootstrap/Pagination';
import './managelayers.css';
import Can from '../../_components/CanComponent/Can';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';

function ManageLayers(props) {
  const t = props.t;
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [layerId, setLayerId] = useState(0);
  const [description, setDescription] = useState('');
  const [filePath, setFilePath] = useState('');
  const [action, setAction] = useState('Create');
  const [file_id, setFileId] = useState('');
  const [file_name, setFileName] = useState('Choose image');
  const [tableData, setTableData] = useState('');
  const [filterTableData, setFilterTableData] = useState('');
  const [formatWarning, setFormatWarning] = useState(false);
  const [sizeWarning, setSizeWarning] = useState(false);
  const [searchCode, setSearchCode] = useState('');
  const [searchName, setSearchName] = useState('');
  const [error, setError] = useState(false);
  const [searchDescription, setSearchDescription] = useState('');
  const [show, setShow] = useState('none');
  const [flag, setFlag] = useState(false);
  const [fileData, setFilesData] = useState([]);
  const [fileSuccess, setFileSuccess] = useState('');
  const [previousLayerId, setPreviousLayerId] = useState(0);
  const [tab, setTab] = useState(1);
  const [inspectionPointData, setInspectionPointData] = useState([]);
  const [accessPersons, setAccessPersons] = useState([]);
  const [accessJobs, setAccessJobs] = useState([]);
  const [page] = useState(5);
  const [active, setActive] = useState(1);
  const [tablePagesCount, setTablePagesCount] = useState(0);
  const [filterFullList, setFilterFullList] = useState([]);
  useEffect(() => {
    const fetchData = async () => {
      await getTableLayouts(layerId);
    }
    fetchData();
  }, []);

  async function getTableLayouts(id) {
    await datasave.service(window.FETCH_ALL_LAYERS, 'GET').then(async response => {
      if (await response['status'] === 200) {
        let resonstrictedData = await reconstructData(response['data']['layersData']);
        if (props.id) {
          let filterResultById = await resonstrictedData.filter(item => { return item.ref_id === parseInt(props.id) });
          if (filterResultById.length > 0) {
            await editLayer(filterResultById[0], 'Edit');
          }
          else {
            window.history.pushState('', '', '/managemyorganisation/groundplan/' + 'managelayers');
            await setShow('none');
          }
        }
        await setTableData(resonstrictedData);
        // await setFilterTableData(resonstrictedData);
        await setFilesData(response['data']['file_data']);
        let pageData = [];
        if (id > 1) {
          let result =await SearchFilter.verifyPageNumber(1,parseInt(id),resonstrictedData,page);
          pageData = result[0];
          await setActive(result[1]);
          let filterResultById = await resonstrictedData.filter(item => { return item.id === parseInt(id) });
          await getBuildingbyLayer(filterResultById[0], 'View');
        } else {
          pageData = await SearchFilter.getPageData(active,page,resonstrictedData,resonstrictedData);
          if(pageData.length<1 && active!==1){
            pageData = await SearchFilter.getPageData(active-1,page,resonstrictedData,resonstrictedData);
                await setActive(active-1);
          }
        }
        let pageCount = await SearchFilter.getCountPage(resonstrictedData,page);
        await setFilterTableData(pageData);
        await setTablePagesCount(pageCount);
        await setFilterFullList(resonstrictedData);
      }
    })
  }
  function reconstructData(data) {
    if (data.length > 0) {
      return data.map(value => {
        return {
          'id': value.ref_id ? value.ref_id : 0,
          'name': value.name ? value.name.toString() : ' ',
          'code': value.code ? value.code.toString() : ' ',
          'description': value.description ? value.description.toString() : ' ',
          'file_id': !value.file_id ? 0 : value.file_id, 'file_path': value.file_path
        }
      })
    } else {
      return [];
    }
  }
  async function saveLayouts(e) {
    let actionperming = window.location.pathname === '/' + 'managelayers' ? 'Create' : 'Edit';
    if (name.length < 1 || code.length < 1 || file_name === 'Choose image') {
      OCAlert.alertWarning(t('Please enter mandatory fields '), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if ((tableData.length > 0 && actionperming === 'Create' && checkDuplicateCodesCreateMode(tableData)) || (tableData.length > 0 && actionperming === 'Edit' && checkDuplicateCodesEditMode())) {
      OCAlert.alertWarning(t('Code should be unique for each layer '), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }
    else {
      await savingData(action === 'Create' ? window.SAVE_LAYER : window.EDIT_LAYER);
      window.history.pushState('', '', '/managemyorganisation/groundplan/' + 'managelayers');
    }
  }
  const checkDuplicateCodesCreateMode = (data) => {
    let presentCodes = data.map(item => { return item.code });
    return presentCodes.includes(code);
  }
  const checkDuplicateCodesEditMode = () => {
    let data = tableData.filter(item => { return item.id !== layerId });
    return checkDuplicateCodesCreateMode(data);
  }
  const savingData = async (url) => {
    let data = await getDataToStore();
    await datasave.service(url, 'POST', data).then(async response => {
      if (response['status'] === 200) {
        await setLayerId(response['data'][0] === 1 ? layerId : response['data'][0]);
        // await cancelLayouts('save');
        await getTableLayouts(response['data'][0] === 1 ? layerId : response['data'][0]);
        await setPreviousLayerId(0);
        // await setShow('none');
        OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
      } else {
        OCAlert.alertError(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
    })
  }
  const getDataToStore = () => {
    return {
      formData: {
        'id': layerId, 'name': name,
        'code': code, 'description': description,
        'file_name': file_name !== 'Choose image' ? file_name : '',
        'file_path': filePath, 'file_id': file_id, 'previousId': previousLayerId,
      }
    }
  }
  async function handleImage(e, url = '') {
    if(url !== ''){
      return reducers.downloadImage(url, file_name);
    }
    let result = await reducers.uploadImage(e);
    if (result['status'] === 200) {
      let resultFileId = result['data']['file_id'][0];
      let filePath = result['data']['filepath'];
      let fileName = result['data']['originalfname'];
      await commonFileSetStates(resultFileId, fileName, filePath);
      await setError(false);
      await setFileSuccess('File uploaded successfully');
    } else {
      await setFormatWarning(result.formatWarning);
      await setSizeWarning(result.sizeWarning);
      await setError(true);
      await setFileSuccess('');
    }
  }
  async function cancelLayouts(operation) {
    if (action === 'View' && operation === 'close') {
      await setShow('none');
      await commonFileSetStates(0, 'Choose image', '');
      await codeNameDescStates('', '', '', 0, 'Create');
      await commonWarning();
      await setInspectionPointData([]);
      await setPreviousLayerId(0);
      return;
    }
    else if (action !== 'Edit' && operation === 'cancel' && (name.length > 0 || code.length > 0 || description.length > 0)) {
      await setShow('block');
      await commonFileSetStates(0, 'Choose image', '');
      await codeNameDescStates('', '', '', layerId, action);
      await commonWarning();
    } else {
      // let id = layerId > 0 ? layerId : 0;
      // let l_action = layerId > 0 ? 'Edit' : 'Create';
      await codeNameDescStates('', '', '', 0, 'Create');
      await commonFileSetStates(0, 'Choose image', '');
      await commonWarning();
      await setShow('none');
      await setPreviousLayerId(0);
    }

  }

  const editLayer = async (value, currentAction) => {
    window.history.pushState('', '', '/managemyorganisation/groundplan/' + 'managelayers' + '/' + currentAction + '/' + value.id);
    if (fileData.length > 0) {
      var currentFiledata = [];
      currentFiledata = await fileData.filter(item => { return item.id === value.file_id });
      if (currentFiledata[0]) {
        await getBuildingbyLayer(value, currentAction);
        await getAccessdetails(value.id);
        if (currentAction !== 'View') {
          await commonFileSetStates(value.file_id, currentFiledata[0].file_name ? currentFiledata[0].file_name : 'Choose image', currentFiledata[0].file_path ? currentFiledata[0].file_path : '');
        }
        else {
          await commonFileSetStates(value.file_id, value.file_name, value.file_path);
        }
      }
      else {
        await commonFileSetStates(0, 'Choose image', '');
      }
    } else {
      await commonFileSetStates(0, 'Choose image', '');
    }
    await commonWarning();
    await setShow('block');
    await codeNameDescStates(value.code, value.name, value.description, value.id, currentAction);
    await setFileSuccess('');
  }
  const getAccessdetails = async (id) => {
    await datasave.service(window.GET_ACCESS_DATA_BY_LAYER + '/' + id, 'GET').then(async response => {
      if (response['status'] === 200) {
        await setAccessJobs(response['data']['jobs']);
        await setAccessPersons(response['data']['persons']);
      } else {
        await setAccessJobs([]);
        await setAccessPersons([]);
      }
    })
  }
  const commonWarning = async () => {
    await setError(false);
    await setFormatWarning(false);
    await setSizeWarning(false);
  }
  const codeNameDescStates = async (l_code, l_name, l_description, l_leyerId, l_action) => {
    await setName(l_name);
    await setCode(l_code);
    await setDescription(l_description);
    await setLayerId(l_leyerId);
    await setAction(l_action);
  }
  const commonFileSetStates = async (l_fileid, l_filename, l_filepath) => {
    await setFileName(l_filename)
    await setFilePath(l_filepath);
    await setFileId(l_fileid);
  }
  const deleteLayer = async () => {
    await datasave.service(window.DELETE_LAYER + '/' + layerId, 'POST').then(async response => {
      if (response['status'] === 200) {
        await getTableLayouts(1);
        OCAlert.alertSuccess(t('Delete successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
      } else {
        OCAlert.alertError(t('Something went wrong please try again'), { timeOut: window.TIMEOUTNOTIFICATION });
      }
      await openClosePopup();
      await setAction('Create');
      await setShow('none');
      window.history.pushState('', '', '/managemyorganisation/groundplan/' + 'managelayers');
    })
  }
  const openClosePopup =async () => {
    if(flag){
      await setPreviousLayerId(0);
      await setLayerId(0);
    }
    await setFlag(!flag);
  }
  const deletePopUP = async (id) => {
    window.history.pushState('', '', '/managemyorganisation/groundplan/' + 'managelayers' + '/' + 'Delete' + '/' + id);
    await setFlag(true);
    await setLayerId(id);
    await setAction('delete');
    await setShow('none');

  }
  const clonePopUP = async (id) => {
    window.history.pushState('', '', '/managemyorganisation/groundplan/' + 'managelayers' + '/' + 'Clone' + '/' + id);
    await setFlag(true);
    await setAction('clone');
    await setShow('none');
    await setLayerId(id);

  }
  async function searchFilter(e) {
    const name = e.target.name;
    const value = e.target.value;
    if (e.key !== "Delete" || e.key !== "Backspace") {
      var filledStates = await getStates('', '', '', name, value);
      var result = await SearchFilter.getData(filledStates, tableData);
      switch (name) {
        case 'name':
          setSearchName(value);
          break;
        case 'code':
          setSearchCode(value);
          break;
        case 'description':
          setSearchDescription(value);
          break;
      }
      let pageData1 = await SearchFilter.getPageData(1,page,result,result);
      let pagecount = await SearchFilter.getCountPage(result,page);
      await setFilterTableData(pageData1);
      await setTablePagesCount(pagecount);
      await setActive(1);
      await setFilterFullList(result);
    }
  }
  async function onKeyUp(e) {
    var result = [];
    if (e.key === "Delete" || e.key === "Backspace") {
      var filledStates = await getStates(searchName, searchCode, searchDescription, '', '');
      result = await SearchFilter.getData(filledStates, tableData);
      let pageData1 = await SearchFilter.getPageData(1,page,result,result);
      let pagecount = await SearchFilter.getCountPage(result,page);
      await setFilterTableData(pageData1);
      await setTablePagesCount(pagecount);
      await setActive(1);
    }
  }
  const getStates = (col1, col2, col3, names, cols) => {
    if (names !== '') {
      col1 = names === 'name'?col1 + cols:searchName;
      col2 = names === 'code'?col2 + cols:searchCode;
      col3 = names === 'description'?col3 + cols:searchDescription;
    }
    var arr = []
    if (col1 != '') {
      arr.push({ name: 'name', value: col1 });
    }
    if (col2 != '') {
      arr.push({ name: 'code', value: col2 });
    }
    if (col3 != '') {
      arr.push({ name: 'description', value: col3 });
    }
    return arr;
  }
  const addLayer = async (e) => {
    window.history.pushState('', '', '/managemyorganisation/groundplan/' + 'managelayers' + '/' + 'Create' + '/' + 0);
    await codeNameDescStates('', '', '', 0, 'Create');
    await commonFileSetStates(0, 'Choose image', '');
    await setInspectionPointData([]);
    await commonWarning();
    await setShow('block');
    await setFileSuccess('');
    await setTab(1);
    await setAccessPersons([]);
    await setAccessJobs([]);
  }
  const popUpQuitMethod = async (e) => {
    window.history.pushState('', '', '/managemyorganisation/groundplan/' + 'managelayers');
    await setAction('Create');
    await setFlag(false);
    await setLayerId(0);
    await setPreviousLayerId(0);

  }
  const cloneLayer = async (e) => {
    let currentLayerdata = tableData.filter(item => { return item.id === layerId });
    if (fileData.length > 0) {
      var currentFiledata = [];
      currentFiledata = await fileData.filter(item => { return item.id === currentLayerdata[0].file_id });
      if (currentFiledata[0]) {
        await commonFileSetStates(currentFiledata[0].id, currentFiledata[0].file_name ? currentFiledata[0].file_name : 'Choose image', currentFiledata[0].file_path ? currentFiledata[0].file_path : '');
      } else {
        await commonFileSetStates(0, 'Choose image', '');
      }
    } else {
      await commonFileSetStates(0, 'Choose image', '');
    }
    await commonWarning();
    await setShow('block');
    await codeNameDescStates('', currentLayerdata[0]['name'], currentLayerdata[0]['description'], 0, 'clone');
    await openClosePopup();
    await setFileSuccess('');
    await setPreviousLayerId(layerId);
    await getBuildingbyLayer(currentLayerdata ? currentLayerdata[0] : currentLayerdata, 'clone')
  }
  const clonesaveLayouts = async (e) => {
    if (name.length < 1 || code.length < 1 || file_name === 'Choose image') {
      OCAlert.alertWarning(t('Please enter mandatory fields'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (tableData.length > 0 && checkDuplicateCodesCreateMode(tableData)) {
      OCAlert.alertWarning(t('Code should be unique for each layer '), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }
    else {
      await savingData(window.CLONE_LAYER);
      window.history.pushState('', '', '/managemyorganisation/groundplan/' + 'managelayers');
    }
  }

  const getBuildingbyLayer = async (value, currentAction) => {
    await datasave.service(window.GET_LAYER_INSPECTION_POINTS + '/' + value.id, 'GET').then(async response => {
      if (response['status'] === 200) {
        let buildingData = response['data'];
        await setInspectionPointData(buildingData);
        await setTab(1);
        var currentFiledata = [];
        currentFiledata = await fileData.filter(item => { return item.id === value.file_id });
        if (currentFiledata[0]) {
          await commonFileSetStates(value.file_id, currentFiledata[0].file_name ? currentFiledata[0].file_name : 'Choose image', currentFiledata[0].file_path ? currentFiledata[0].file_path : '');
        }
        await commonWarning();
        await setShow('block');
        if (currentAction !== 'clone') {
          await getAccessdetails(value.id);
          await codeNameDescStates(value.code, value.name, value.description, value.id, currentAction);
        }else{
          await getAccessdetails(value.id);
        }
        await setFileSuccess('');
      }
    });
  }
  var paginationData = [];
  // if (tablePagesCount > 0)
  //   for (let number = 1; number <= tablePagesCount; number++) {
  //     paginationData.push(
  //       <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => changePage(e, number)}>
  //         {number}
  //       </Pagination.Item>,
  //     );
  //   }
  const changePage = async (id) => {
    const list = (searchCode !== '' || searchName !== '' || searchDescription !== '') ? filterFullList : '';
    let pageData = await SearchFilter.getPageData(id,page,list,tableData);
    await setFilterTableData(pageData);
    await setActive(id);
  }
  const css = {
    width: '295px', overflow: 'auto', marginBottom: '0px',
  }
  var highlightLayerId = (action==='clone' && parseInt(previousLayerId)>0)?parseInt(previousLayerId):parseInt(layerId);

  return (
    <Can
       perform = "Access_groundplan,E_layer,V_layer,D_layer,Clone_layer"
       yes = {() => (
          <div className='fluid pl-2'>
            <Can
               perform = "Access_groundplan,E_layer"
               yes = {() => (
                  <reactbootstrap.Row className='p-2'>
                    <reactbootstrap.Button onClick={(e) => addLayer(e)}>{t('Add layer')}</reactbootstrap.Button>
                  </reactbootstrap.Row>
               )}
            />
            <reactbootstrap.Row className='p-1'>
              <reactbootstrap.Col className='col-md-6'>
                {tableData.length > 0 &&
                  <reactbootstrap.Row >
                  <div  style={{ 'scrollbar-width': 'thin', height:'400px', overflow:'auto' }}>
                  <reactbootstrap.Table striped bordered hover variant="" style={{ 'table-layout': 'fixed'}}>
                    <thead style={{ backgroundColor: '#EC661C', color: '#fff', position: 'sticky', top: '0', textAlign: 'center' }}>
                      <tr style={{ textAlign: 'center' }}>
                        <th>{t('Code')}</th>
                        <th>{t('Name')}</th>
                        <th>{t('Description')}</th>
                        <th>{t('Actions')}</th>
                      </tr>
                      <tr>
                        <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='code' value={searchCode} onChange={(e) => searchFilter(e)} onKeyUp={(e) => onKeyUp(e)} /></th>
                        <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='name' value={searchName} onChange={(e) => searchFilter(e)} onKeyUp={(e) => onKeyUp(e)} /></th>
                        <th><reactbootstrap.FormControl type="text" className="search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='description' value={searchDescription} onChange={(e) => searchFilter(e)} onKeyUp={(e) => onKeyUp(e)} /></th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {filterTableData && filterTableData.map(item => {
                        let css = (parseInt(item.id) === parseInt(highlightLayerId)) ? '#feb389' : '#fafafa';
                        return <tr style={{backgroundColor: css }} >
                          <td onClick={(e) => getBuildingbyLayer(item, 'View')} style={{ textAlign: 'left' }}>{item.file_path ? <span style={{ paddingRight: '5px' }}><img src={item.file_path} style={{ width: '25px' }} /></span> : <span style={{ paddingRight: '30px' }}></span>}<span>{item.code}</span></td>
                          <td onClick={(e) => getBuildingbyLayer(item, 'View')}>{item.name}</td>
                          <td style = {{ 'text-overflow': 'ellipsis', overflow: 'hidden'}} onClick={(e) => getBuildingbyLayer(item, 'View')}>{item.description}</td>
                          <td >
                            <div style={{ display: 'flex', textAlign: 'center', justifyContent: 'center' }} >
                              <Can
                                 perform = "Access_groundplan,E_layer"
                                 yes = {() => (
                                    <i title={t("Edit")} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-myeditc" onClick={(e) => editLayer(item, 'Edit')} />
                                 )}
                               />
                               <Can
                                  perform = "Access_groundplan,Clone_layer"
                                  yes = {() => (
                                    <span style={{ paddingLeft: '10px', paddingRight: '10px' }}><i title={t("Clone")} class="dashboard-tiles  dashboard-tiles-clone" onClick={(e) => clonePopUP(item.id)}></i></span>
                                  )}
                                />
                                <Can
                                   perform = "Access_groundplan,D_layer"
                                   yes = {() => (
                                      <i title={t("Delete")} style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec" onClick={(e) => deletePopUP(item.id)} />
                                   )}
                                />
                            </div>
                          </td>
                        </tr>
                      })}
                    </tbody>
                  </reactbootstrap.Table>
                  </div>
                    <Paginator count={tablePagesCount} active={active} changePage={changePage} css={css} size="md"/>
                    { /**<Pagination style={{ width: '295px', overflow: 'auto', marginBottom: '0px' }} size="md">{paginationData}</Pagination>*/}
                  </reactbootstrap.Row>}
                {action === 'delete' && <CommonPopUp
                  quit={t('Cancel')}
                  quitMethod={(e) => popUpQuitMethod(e)}
                  proceed={t('Confirm')}
                  preoceedMetod={(e) => deleteLayer()}
                  message={t('Are you sure you want to delete this layer ?')}
                  show={flag}
                  showMethod={(e) => openClosePopup()}
                />}
                {action === 'clone' && <CommonPopUp
                  quit={t('No')}
                  quitMethod={(e) => popUpQuitMethod(e)}
                  proceed={t('Yes')}
                  preoceedMetod={(e) => cloneLayer(e)}
                  message={t('Are you sure you want to clone this layer ?')}
                  show={flag}
                  showMethod={(e) => openClosePopup()}
                />}
              </reactbootstrap.Col>
              <reactbootstrap.Col className='col-md-6' style={{ display: show }}>
                <reactbootstrap.Tabs activeKey={tab} onSelect={(key) => setTab(key)}>
                  <reactbootstrap.Tab eventKey={1} title={t("Layers details")}>
                    <reactbootstrap.Row className='p-1 mob-margin'>
                      <reactbootstrap.FormLabel className='col-md-3'>{t('Layer code')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
                      <reactbootstrap.FormControl
                        className="col-md-9 input_sw"
                        type='text'
                        onChange={(e) => setCode(e.target.value)}
                        value={code}
                        disabled={action === 'View' ? true : false} />
                    </reactbootstrap.Row>
                    <reactbootstrap.Row className='p-1 mob-margin'>
                      <reactbootstrap.FormLabel className='col-md-3'>{t('Layer name')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
                      <reactbootstrap.FormControl
                        className="col-md-9 input_sw"
                        type='text'
                        onChange={(e) => setName(e.target.value)}
                        value={name}
                        disabled={action === 'View' ? true : false} />
                    </reactbootstrap.Row>
                    <reactbootstrap.Row className='p-1 mob-margin'>
                      <reactbootstrap.FormLabel className='col-md-3'>{t('Description')}</reactbootstrap.FormLabel>
                      <reactbootstrap.FormControl
                        as='textarea'
                        value={description}
                        onChange={e => setDescription(e.target.value)}
                        className='col-md-9 input_sw'
                        disabled={action === 'View' ? true : false} />
                    </reactbootstrap.Row>
                    <reactbootstrap.Row className='p-1 mob-margin mt-1'>
                      <reactbootstrap.FormLabel className='col-md-3'>{t('Upload icon')}<span style={{ color: 'red' }}>{'*'}</span></reactbootstrap.FormLabel>
                      <reactbootstrap.InputGroup className="col-md-9 custom-file input_sw">
                        <reactbootstrap.FormControl
                          type="file"
                          className="custom-file-input"
                          id="inputGroupFile01"
                          name='image'
                          accept={window.DOC_TYPES['default']}
                          onChange={(e) => handleImage(e)}
                          onClick={(event)=> event.target.value = null}
                          disabled={action === 'View' ? true : false}
                        />
                        <reactbootstrap.FormLabel className="custom-file-label" htmlFor="inputGroupFile01">
                          {file_name !== null && file_name}
                        </reactbootstrap.FormLabel>
                      </reactbootstrap.InputGroup>
                    </reactbootstrap.Row>
                    <reactbootstrap.Row>
                      <reactbootstrap.Col style={{ marginLeft: '121px' }}>
                        {error === false ? <div style={{ display: file_name !== 'Choose image' ? 'block' : 'none' }}>
                          <span style={{ color: "green", marginLeft: '1px' }}>{fileSuccess}</span>
                          <span style={{ display: 'inline-block', margin: '5px' }}>
                            <i title={t("preview")} style={{ 'cursor': 'pointer', marginLeft: '1px' }} class="webform-sprite webform-sprite-smallviewc" onClick={(e) => window.open(filePath, "_blank")}></i>
                          </span>
                          <span style={{display:'inline-block', margin: '5px'}}>
                              <img src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/61726d5042ee88.300490011634889040.png" alt="Logo" title="Download" style={{cursor: 'pointer', marginTop: '-15px'}} onClick = {(e) => handleImage(e, filePath)}></img>
                          </span>
                          {action !== 'View' && <span style={{ display: 'inline-block', margin: '5px' }}>
                            <i title={t("Remove")} style={{ 'cursor': 'pointer', marginLeft: '1px' }} class="overall-sprite overall-sprite-mtdeletec" onClick={(e) => commonFileSetStates(0, 'Choose image', '')} />
                          </span>}
                        </div>
                          :
                          <>
                            {formatWarning === false && sizeWarning === false && <span style={{ color: "red" }}> {window.FILE_FORMAT_ERROR_MSG}{t('and size should be < 1MB')} </span>}
                            {formatWarning === true && sizeWarning === false && <span style={{ color: "red" }}> {window.FILE_FORMAT_ERROR_MSG} </span>}
                            {formatWarning === false && sizeWarning === true && <span style={{ color: "red" }}> {t('File size should be < 1MB')} </span>}
                          </>}
                      </reactbootstrap.Col>
                    </reactbootstrap.Row>
                    <reactbootstrap.Row className='pt-2 organisation_list float-right'>
                      {action === 'View' && <a id="cancel" className='mt-2 mr-3' active='true' onClick={(e) => cancelLayouts('close')}>{t('Cancel')}</a>}
                      {action !== 'View' && <a id="cancel" className='mt-2 mr-3' active='true' onClick={(e) => cancelLayouts('cancel')}>{t('Cancel')}</a>}
                      {action !== 'View' && action !== 'clone' && <reactbootstrap.Button onClick={(e) => saveLayouts(e)}>{t('Save')}</reactbootstrap.Button>}
                      {action !== 'View' && action === 'clone' && <reactbootstrap.Button onClick={(e) => clonesaveLayouts(e)}>{t('Save')}</reactbootstrap.Button>}
                    </reactbootstrap.Row>
                  </reactbootstrap.Tab>
                  <reactbootstrap.Tab eventKey={2} title={t("Linked inspection points")}>
                    {inspectionPointData && <BuildingLayerFolderStracture inspectionPointData={inspectionPointData} />}
                  </reactbootstrap.Tab>
                  <reactbootstrap.Tab eventKey={3} title={t("Access")}>
                    {/* {((accessPersons.length > 0) || (accessJobs.lenght > 0)) && */}
                      <LayerAccessDetails accessPersons={accessPersons} accessJobs={accessJobs} />
                    {/* } */}
                  </reactbootstrap.Tab>
                </reactbootstrap.Tabs>
              </reactbootstrap.Col>
            </reactbootstrap.Row>
        </div>
      )}
      no={() =>
          <AccessDeniedPage />
      }
    />
  )
}
export default translate(ManageLayers);
