import React from 'react';
import * as reactbootstrap from 'react-bootstrap';
export default function CommonPopUp({ quit, quitMethod, proceed, preoceedMetod, message, show, showMethod }) {
  return (
    <reactbootstrap.Modal
      show={show}
      onHide={showMethod}
      dialogClassName="modal-90w"
      aria-labelledby="example-custom-modal-styling-title"
    >
      <reactbootstrap.Modal.Header style={{ fontSize: '18px' }} closeButton>
        {message}
      </reactbootstrap.Modal.Header>
      <reactbootstrap.Modal.Footer>
        <reactbootstrap.Button onClick={quitMethod}>{quit}</reactbootstrap.Button>
        <reactbootstrap.Button onClick={preoceedMetod}>{proceed}</reactbootstrap.Button>
      </reactbootstrap.Modal.Footer>
    </reactbootstrap.Modal>
  );
}
