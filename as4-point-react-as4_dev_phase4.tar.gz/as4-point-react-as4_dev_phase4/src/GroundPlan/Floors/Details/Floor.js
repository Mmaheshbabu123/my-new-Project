import React, { useState, useEffect, useRef } from 'react';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import {translate} from '../../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import { reducers } from '../../Building/Reducers/reducers';

const Floor = props => {
  const prevProps = usePrevious(props);
  const [state, setState] = useState({
    t:props.t,
    floorName: '',
    floorCode: '',
    floorNumber: '',
    floorDescription: '',
    file_name       : 'Choose image',
    file_id         : null,
    file_path       : '',
    formatWarning   : false,
    sizeWarning     : false,
    parent_id: '',
    buildingName: (props.buildingName !== undefined) ? props.buildingName : '',
    floorNameError: '',
    floorCodeError: '',
    floorNumberError: '',
    isDisable: '',
    buildingDisable: 'disable',
    currentFloorDetails: [],
    formDisbale: '',
    uploadMessage   : false,
    parentCode : props.buildingCode ? props.buildingCode : '',
  })

  useEffect(() => {
    const {t} = state;
    if ((props.floorId !== undefined && props.floorId !== null && props.floorId !== 1) && (props.action !== 2)) {
      const getFloor = window.GET_FLOOR_DETAILS + '/' + props.floorId;
      datasave.service(getFloor, 'GET', )
      .then(response => {
        if(response.status === 200) {
          const floorDetails = response.data;
          setState({
            ...state,
            floorCode: floorDetails.code,
            floorName: floorDetails.name,
            floorNumber: floorDetails.number,
            buildingName: state.buildingName,
            floorDescription: floorDetails.description,
            file_name: (floorDetails.file_details.file_name !== undefined) ? floorDetails.file_details.file_name : 'Choose image',
            file_path: (floorDetails.file_details.file_path !== undefined) ? floorDetails.file_details.file_path : '',
            file_id : (floorDetails.file_details.id !== undefined) ? floorDetails.file_details.id : null,
            currentFloorDetails: floorDetails,
            uploadMessage   : false
          })
        } else {
          OCAlert.alertWarning(t('Unable to fetch data'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
      })
    }else if (props.action && props.parentId && props.action === 2) {
      datasave.service(`${window.GET_GROUNDPLAN_NR}/2/${props.parentId}`, 'GET')
     .then(result => {
       setToInitialState(props.buildingCode + '.' + result.data.code)
     })
    }
  }, [props.floorId]);

  useEffect(() => {
   if(prevProps){
     if ((props.floorId !== undefined && props.floorId !== null) && (prevProps.floorId !== undefined && prevProps.floorId !== null)){
       if ((prevProps.floorId !== props.floorId)) {
         setState({
           ...state,
           floorId: props.floorId,
         })
       }
     }
     if (prevProps.action !== undefined && prevProps.action !== props.action) {
       if (props.action === 2) {
         setState({
           ...state,
           // floorCode: props.nextCode ? props.nextCode : '',
           floorName: '',
           floorNumber: '',
           floorDescription: '',
           file_name: 'Choose image',
           file_path: '',
           file_id : null,
           uploadMessage : false,
         })
        return;
      }
     }
   }
 })

  const handleChange = (e) => {
    const {name, value} = e.target;
    setState({
      ...state,
      [name] : value,
      floorNameError: '',
      floorCodeError: '',
      floorNumberError: '',
    })
  }

  const handleFileChanges = async (e, type, url = '') => {
    console.log(type, url);
    if(type === 'upload'){
      let response = await reducers.uploadImage(e);
      if (response.status === 200){
        setState({...state,
          file_id: response.data.file_id[0],
          file_name : response.data.originalfname,
          file_path : response.data.filepath,
          formatWarning : false,
          sizeWarning : false,
          uploadMessage : true,
        })
      } else{
        setState({...state,
          formatWarning : response.formatWarning,
          sizeWarning   : response.sizeWarning,
          uploadMessage : false,
        })
      }
    } else if (type === 'download') {
        reducers.downloadImage(url, state.file_name);
    } else if (state.file_id !== 0) {
      // await reducers.removeImage(state.file_id);
      setState({
        ...state,
        file_id   : 0,
        file_name : t('Choose image'),
        file_path : '',
      })
    }
  }

  const handleSubmit = () => {
    const {t} = state;
    const details = getSubmitData();
    const floorCreationUrl = window.CRETAE_FLOOR;
    const floorUpdateUrl = window.UPDATE_FLOOR + '/' + props.floorId;

    if (props.floorId !== undefined && props.floorId !== null && props.floorId !== 1) {
      datasave.service(floorUpdateUrl, 'PUT', details)
      .then(response => {
        if (response.status === 200) {
          props.updateStructure('',props.floorId,'','floor');
          setState({...state, uploadMessage : false })
          OCAlert.alertSuccess(t('Updated successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
        } else {
          if (response.error.name || response.error.number || response.error.code) {
            setState({
              ...state,
              floorNameError: (response.error.name) ? response.error.name : '',
              floorCodeError: (response.error.code) ? response.error.code : '',
              floorNumberError: (response.error.number) ? response.error.number : '',
            })

          } else {
            OCAlert.alertWarning(t('Something went wrong in saving data'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
        }
      })
    } else {
      datasave.service(floorCreationUrl, 'POST', details)
      .then(response => {
        if (response.status === 200) {
          OCAlert.alertSuccess(t('Saved successfully'), { timeOut: window.TIMEOUTNOTIFICATION });
          props.updateStructure('',response.data.id,'','floor')
        } else {
          if (response.error.name || response.error.number || response.error.code) {
            setState({
              ...state,
              floorNameError: (response.error.name) ? response.error.name : '',
              floorCodeError: (response.error.code) ? response.error.code : '',
              floorNumberError: (response.error.number) ? response.error.number : '',
            })
          } else {
            OCAlert.alertWarning(t('Something went wrong in saving data'), { timeOut: window.TIMEOUTNOTIFICATION });
          }
        }
      })
    }
  }
  const setToInitialState = (code = '') => {
    setState({
      ...state,
      floorCode: code,
      floorName: '',
      floorNumber: '',
      floorDescription: '',
      file_name: 'Choose image',
      file_path: '',
      file_id : null,
      uploadMessage   : false,
    })
  }
  const handleCancel = () => {
    if (props.action === 2) {
      setToInitialState();
    } else {
      setState({
        ...state,
        floorCode: state.currentFloorDetails.code !== null ? state.currentFloorDetails.code : '',
        floorName: state.currentFloorDetails.name !== null ? state.currentFloorDetails.name : '',
        floorNumber: state.currentFloorDetails.number !== null ? state.currentFloorDetails.number : '',
        buildingName: state.buildingName,
        floorDescription: state.currentFloorDetails.description !== null ? state.currentFloorDetails.description : '',
        file_name: (state.currentFloorDetails.file_details.file_name !== undefined) ? state.currentFloorDetails.file_details.file_name : 'Choose image',
        file_path: (state.currentFloorDetails.file_details.file_path !== undefined) ? state.currentFloorDetails.file_details.file_path : '',
        file_id : (state.currentFloorDetails.file_details.id !== undefined) ? state.currentFloorDetails.file_details.id : null,
        currentFloorDetails: state.currentFloorDetails,
        // formDisbale: 'disabled',
        uploadMessage   : false,
      })
    }
    props.handleCancel('floor');
  }

  const getSubmitData = () => {
    let data = {
      name: state.floorName,
      code: state.floorCode,
      parent_id: ((props.parentId !== undefined) || ( props.parentId !== null)) ? props.parentId : null,
      parent_type : window.BUILDING_ENTITY_TYPE_ID,
      number: state.floorNumber,
      description: state.floorDescription,
      img_name: state.file_name !== 'Choose image' ? state.file_name : '',
      img_id: state.file_id,
      img_path: state.file_path,
      parentCode : state.parentCode,
    }

    return data;
  }

    const {t} = state;
    const {floorName, floorCode, floorCodeError, floorNameError, floorNumber, floorNumberError, floorDescription, buildingDisable} = state
    const formDisabled = ((props.action == 1) || (state.formDisbale != '')) ? 'disabled' : '';

    return (
        <div className='container py-2' >
          <div className='row justify-content-center' >
            <div className='col-lg-12 col-md-12 float-left px-0' >
                <reactbootstrap.Container className="p-1">
                  <reactbootstrap.Form >
                    <fieldset disabled={formDisabled}>
                      <reactbootstrap.FormGroup>
                          <div className="  input-overall-sec ">
                            <reactbootstrap.InputGroup className="  ">
                                <div className="col-md-4">
                                    <reactbootstrap.InputGroup.Prepend>
                                        <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Floor code')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                    </reactbootstrap.InputGroup.Prepend>
                                </div>
                                <div class="col-md-8">
                                    <reactbootstrap.FormControl
                                        name="floorCode"
                                        placeholder={t("Floor code")}
                                        aria-label="code"
                                        aria-describedby="basic-addon1"
                                        value={floorCode}
                                        onChange={(e) => handleChange(e)}
                                        className="input_sw"
                                    />
                                    <div style={{ color: 'red' }} className="error-block mt-2">{floorCodeError}</div>
                                </div>
                            </reactbootstrap.InputGroup>
                          </div>
                          <div className="  input-overall-sec ">
                              <reactbootstrap.InputGroup className="  ">
                                  <div className="col-md-4">
                                      <reactbootstrap.InputGroup.Prepend>
                                          <reactbootstrap.InputGroup style={{ padding: '10px', color: '#EC661C' }} id="basic-addon1">{t('Floor name')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                      </reactbootstrap.InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8">
                                      <reactbootstrap.FormControl
                                          name="floorName"
                                          placeholder={t("Floor name")}
                                          aria-label="code"
                                          aria-describedby="basic-addon1"
                                          value={floorName}
                                          onChange={(e) => handleChange(e)}
                                          className="input_sw"
                                      />
                                      <div style={{ color: 'red' }} className="error-block mt-2">{floorNameError}</div>
                                  </div>
                              </reactbootstrap.InputGroup>
                            </div>
                            <div className="input-overall-sec ">
                              <reactbootstrap.InputGroup className="  ">
                                  <div className="col-md-4">
                                      <reactbootstrap.InputGroup.Prepend>
                                          <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Building name')}</reactbootstrap.InputGroup>
                                      </reactbootstrap.InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8">
                                      <reactbootstrap.FormControl
                                          name="buildingName"
                                          placeholder={t("Building name")}
                                          aria-label="code"
                                          aria-describedby="basic-addon1"
                                          value={props.buildingCode + '-' + props.buildingName}
                                          className="input_sw"
                                          disabled = {buildingDisable}
                                      />
                                  </div>
                              </reactbootstrap.InputGroup>
                            </div>
                            <div className="input-overall-sec ">
                              <reactbootstrap.InputGroup className="  ">
                                  <div className="col-md-4">
                                      <reactbootstrap.InputGroup.Prepend>
                                          <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Floor number')}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                      </reactbootstrap.InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8">
                                      <reactbootstrap.FormControl
                                          name="floorNumber"
                                          placeholder={t("Floor number")}
                                          aria-label="code"
                                          aria-describedby="basic-addon1"
                                          value={floorNumber}
                                          onChange={(e) => handleChange(e)}
                                          className="input_sw"
                                      />
                                      <div style={{ color: 'red' }} className="error-block mt-2">{floorNumberError}</div>
                                  </div>
                              </reactbootstrap.InputGroup>
                            </div>
                            <div className="  input-overall-sec ">
                              <reactbootstrap.InputGroup className="  ">
                                  <div className="col-md-4">
                                      <reactbootstrap.InputGroup.Prepend>
                                          <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Description')}</reactbootstrap.InputGroup>
                                      </reactbootstrap.InputGroup.Prepend>
                                  </div>
                                  <div class="col-md-8 ">
                                      <reactbootstrap.FormControl
                                          name="floorDescription"
                                          as="textarea" rows="5"
                                          placeholder={t("Description")}
                                          aria-label="code"
                                          aria-describedby="basic-addon1"
                                          value={floorDescription}
                                          onChange={(e) => handleChange(e)}
                                          className="input_sw"
                                      />
                                  </div>
                              </reactbootstrap.InputGroup>
                          </div>
                          {/* visio,pdf,.dwg,dxt*/}
                          <reactbootstrap.FormGroup>
                              <div className="  input-overall-sec ">
                                  <reactbootstrap.InputGroup className="  ">
                                      <div className="col-md-4">
                                          <reactbootstrap.InputGroup.Prepend>
                                              <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Upload groundplan:')}</reactbootstrap.InputGroup>
                                          </reactbootstrap.InputGroup.Prepend>
                                      </div>
                                      <div className="col-md-7 custom-file input_sw" style={{marginLeft: '2%', maxWidth: '62%'}}>
                                          <input
                                              type="file"
                                              className="custom-file-input"
                                              id="image"
                                              name='image'
                                              disabled = {state.isDisable}
                                              accept={window.DOC_TYPES['default']}
                                              onChange={(e) => handleFileChanges(e, 'upload')}
                                              onClick={(event)=> event.target.value = null}
                                          />
                                          <label className="custom-file-label" htmlFor="inputGroupFile01">
                                              {state.file_name !== null && state.file_name }
                                          </label>
                                      </div>
                                  </reactbootstrap.InputGroup>
                              </div>
                              </reactbootstrap.FormGroup>
                          </reactbootstrap.FormGroup>
                          </fieldset>
                          <div style={{}} className="row col-md-12 mt-2">
                              <div style={{ visibility: 'hidden' }} className="col-md-4">
                                  <h3>{t("Upload")}</h3>
                              </div>
                                <div className="col-md-8">
                                  {!state.formatWarning && !state.sizeWarning && state.file_name !== 'Choose image' &&
                                    <div>
                                      {
                                        <>
                                        {((state.uploadMessage) && (props.action === 2 || props.action === 0)) &&
                                          <span style={{ color: "green", display:'inline-block', marginRight: '10px' }}>{window.FILE_UPLOAD_SUCCESS}</span>
                                        }
                                        <span style={{display:'inline-block', marginRight: '10px'}}>
                                            <i title="preview" style={{ 'cursor': 'pointer' }} class="webform-sprite webform-sprite-smallviewc" onClick={(e) => window.open(state.file_path, "_blank")}></i>
                                        </span>
                                        <span style={{display:'inline-block', marginRight: '10px'}}>
                                            <img src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/61726d5042ee88.300490011634889040.png" alt="Logo" title="Download" style={{cursor: 'pointer', marginTop: '-10px' }} onClick = {(e) => handleFileChanges(e, 'download', state.file_path)}></img>
                                        </span>
                                        {formDisabled === '' && <span style={{display:'inline-block', marginRight: '10px'}}>
                                            <i title="Remove" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec"  onClick={(e) => {handleFileChanges(e, 'remove')}}/>
                                        </span>}
                                        </>
                                      }
                                    </div>
                                }
                                  {state.formatWarning && state.sizeWarning && <span style={{ color: "red" }}>{window.FILE_FORMAT_ERROR_MSG}{t( 'and size should be < 1MB')} </span>}
                                  {state.formatWarning && !state.sizeWarning && <span style={{ color: "red" }}> {window.FILE_FORMAT_ERROR_MSG} </span>}
                                  {!state.formatWarning && state.sizeWarning && <span style={{ color: "red" }}> {t('Size sgould be < 1MB')} </span>}
                              </div>
                          </div>
                      <FormGroup>
                        <div style={{ float: 'right' }} className="organisation_list mt-3 mr-3">
                          <a onClick={handleCancel} >{t('Cancel')}</a>
                          &nbsp;&nbsp;&nbsp;
                          <Button className="btn btn-primary" type="button" color="primary" onClick={() => handleSubmit()}> {t('Save')} </Button>
                        </div>
                      </FormGroup>
                    </reactbootstrap.Form>
                </reactbootstrap.Container>
            </div>
          </div>
        </div>
    )
}

export default translate(Floor);

function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
