import React, { useState, useEffect } from 'react';
import * as reactbootstrap from "react-bootstrap";
import { translate } from '../../../language';
import { datasave } from '../../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import AccessPage from '../../Access/AccessPage';
import PersonImg from '../../../images/personc.png';
import JobImg from '../../../images/jobc.png';
import * as reactbootstarp from 'react-bootstrap';
import Pagination from 'react-bootstrap/Pagination';

const FloorAccess = (props) => {
  const [state, setState] = useState({
    t: props.t,
    activeTab: 0,
    personsList: [],
    jobsList: [],
    showJobPopup: false,
    curentlyHoveredJob: [],
    activePopupTab: 0,
    showPersonPopup: false,
    curentlyHoveredPerson: [],
    searchTerm: '',
    personsPagesCount: 0,
    jobsPagesCount: 0,
    page: 5,
    active: 1,
    items: [],
  })

   useEffect(() => {
     const {t} = state;
     if ((props.floorId !== undefined && props.floorId !== null && props.floorId !== 1)) {
       const getAccessData = window.GET_BUILDINGNFLOOR_LINKEDADTA + '/' + props.buildingId + '/' + window.BUILDING_ENTITY_TYPE_ID + '/' + props.floorId + '/' + window.FLOOR_ENTITY_TYPE_ID;
       datasave.service(getAccessData, 'GET')
       .then(response => {
         if (response.status === 200) {
           const floorAccess = response.data;
           const personsPageData = getPageData(state.active, floorAccess.persons);
           const personsPagesCount = getCountPage(floorAccess.persons);
           const jobsPageData = getPageData(state.active, floorAccess.jobs);
           const jobsPagesCount = getCountPage(floorAccess.jobs);
           setState({
             ...state,
             personsList: floorAccess.persons,
             jobsList: floorAccess.jobs,
             personsItems: personsPageData,
             jobsPageItems: jobsPageData,
             personsPagesCount: personsPagesCount,
             jobsPagesCount: jobsPagesCount,
             items: (state.activeTab === 0) ? personsPageData : jobsPageData,
           })
         } else {
           OCAlert.alertSuccess(t('Unable to fetch Floor access data'), { timeOut: window.TIMEOUTNOTIFICATION });
         }
       })
     }
   }, [props.floorId]);

   const searchData = (e) => {
     var list = (state.activeTab === 0) ? [...state.personsList] : [...state.jobsList];
     let res = '';
     list = list.filter(function (item) {
       if (state.activeTab === 0) {
           res = item.person_name.toLowerCase().search(
           e.target.value.toLowerCase()) !== -1;
       } else {
         res = item.job_name.toLowerCase().search(
         e.target.value.toLowerCase()) !== -1;
       }
       return res;

     });

     const page_data = getPageData(1, list);
     const count = getCountPage(list);

     setState({
       ...state,
       items: page_data,
       personsPagesCount: (state.activeTab === 0) ? count : state.personsPagesCount,
       jobsPagesCount: (state.activeTab === 1) ? count : state.jobsPagesCount,
       active: 1,
       searchTerm: e.target.value,
       filterFullList: list,
     });
   }

   const getCountPage = (items) => {
     const itemLength = items.length;
     return (itemLength > state.page) ? Math.ceil(itemLength / state.page) : 0;
   }

   const getPageData = (id, list = '') => {
     const page = state.page;
     const allItems = (state.activeTab === 0) ? state.personsList : state.jobsList;
     const items = (list !== '') ? list : allItems;
     const page_data = items.slice(page * (id - 1), page * id);

     return page_data;
   }

   const changePage = (e, id, tabType) => {
     const list = (state.searchTerm !== '') ? state.filterFullList : '';
     const page_data = getPageData(id, list);
     setState({
       ...state,
       items: page_data,
       active: id,
     });
   }

   const handleSelectTab = (e) => {
    setState({
      ...state,
      activeTab: parseInt(e),
      searchTerm: '',
      items: (parseInt(e) === 0) ?((state.personsItems !== undefined && state.personsItems !== null) ? state.personsItems : []) : ((state.jobsPageItems !== undefined && state.jobsPageItems !== null) ? state.jobsPageItems : []),
    });
   }

  const handleSelectPopupTab = (e) => {
    setState({
      ...state,
      activePopupTab: parseInt(e),
    });
  }

  const handleHide = () => {
    setState({
        ...state,
        showJobPopup: false,
        showPersonPopup: false,
    });
  }

  const handleBuildingsnFloors = (item) => {
    const url = window.GET_PERSON_LINKED_BUILDINGSNFLOORS + '/' + item.p_id + '/' + window.GROUNDPLAN_PERSON_ENTITYID;
    datasave.service(url, "GET", '')
      .then(result => {
          setState({
              ...state,
              showPersonPopup: true,
              curentlyHoveredPerson: result.data
          })
      })
      .catch(error => {

      })
  }

  const handlePersons = (item) => {
    const url = window.GetAllLinkedPersons + '/' + item.j_id + '/' + window.JOB_ENTITY;
    datasave.service(url, "GET", '')
      .then(result => {
          setState({
              ...state,
              showJobPopup: true,
              curentlyHoveredJob: result[item.j_id]
          })
      })
      .catch(error => {

      })
  }

  const { t, activeTab, personsList, jobsList, activePopupTab, active, items } = state;

  const jobPopupContent = (
      <reactbootstarp.Modal
          show={state.showJobPopup}
          onHide={handleHide}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
          <reactbootstarp.Modal.Header closeButton>
              <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
                  Persons
          </reactbootstarp.Modal.Title>
              <reactbootstarp.Modal.Body>
                  <ul>
                      {state.curentlyHoveredJob.length != 0 &&
                          state.curentlyHoveredJob.map(person =>
                              <li>{person.name}</li>
                          )
                      }
                      {state.curentlyHoveredJob.length === 0 &&
                          'No persons are linked'
                      }
                  </ul>
              </reactbootstarp.Modal.Body>
          </reactbootstarp.Modal.Header>
      </reactbootstarp.Modal>
  );

  const personPopupContent = (
      <reactbootstarp.Modal
          show={state.showPersonPopup}
          onHide={handleHide}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
      >
          <reactbootstarp.Modal.Header closeButton>
              <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">

          </reactbootstarp.Modal.Title>
              <reactbootstarp.Modal.Body>
                <reactbootstrap.Tabs id="controlled-tab-example" activeKey={activePopupTab} onSelect={(e) => handleSelectPopupTab(e)}>
                  <reactbootstrap.Tab eventKey={0} title={t("Buildings")}>
                    <ul>
                        {state.curentlyHoveredPerson.length != 0 &&
                            state.curentlyHoveredPerson.map(item =>
                              <>
                              {item.b_name !== null &&
                                <li>{item.b_name}</li>
                              }
                              </>
                            )
                        }
                        {state.curentlyHoveredPerson.length === 0 &&
                            'No persons are linked'
                        }
                    </ul>
                  </reactbootstrap.Tab>
                  <reactbootstrap.Tab eventKey={1} title={t("Floors")}>
                    <ul>
                        {state.curentlyHoveredPerson.length != 0 &&
                            state.curentlyHoveredPerson.map(item =>
                              <>
                              {item.f_name !== null &&
                                <li>{item.f_name}</li>
                              }
                              </>
                            )
                        }
                        {state.curentlyHoveredPerson.length === 0 &&
                            'No persons are linked'
                        }
                    </ul>
                  </reactbootstrap.Tab>
                </reactbootstrap.Tabs>
              </reactbootstarp.Modal.Body>
          </reactbootstarp.Modal.Header>
      </reactbootstarp.Modal>
  );

  {/* <AccessPage itemId={props.floorId} itemType={2}/> */}
  let personsPages = [];
  if (state.personsPagesCount > 0)
    for (let number = 1; number <= state.personsPagesCount; number++) {
      personsPages.push(
        <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => changePage(e, number, 'persons')}>
          {number}
        </Pagination.Item>,
      );
  }
  let jobsPages = [];
  if (state.jobsPagesCount > 0)
    for (let number = 1; number <= state.jobsPagesCount; number++) {
      jobsPages.push(
        <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => changePage(e, number , 'jobs')}>
          {number}
        </Pagination.Item>,
      );
  }

  return (
      <div className='container py-2' >
        <div className='row justify-content-center' >
          <div className='col-lg-12 col-md-12 float-left px-0' >
              <reactbootstrap.Container className="p-1">
                <div className="text-center">
                  <reactbootstrap.Form >
                    <reactbootstrap.Tabs id="controlled-tab-example" activeKey={activeTab} onSelect={(e) => handleSelectTab(e)}>
                      <reactbootstrap.Tab eventKey={0} title={t("Persons")}>
                        <reactbootstrap.Table responsive bordered hover>
                          <thead>
                            <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
                              <th>{t('Name')}</th>
                            </tr>
                          </thead>
                          <tbody>
                              <>
                              <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C" }} placeholder={t("What are you looking for ?")} autoFocus onChange={(e) => searchData(e)} /><br />
                              {Object.values(items).map((person, index) => {
                               if(person.status && person.person_name){
                                 return (
                                   <tr style={{ borderBottom: "1px solid #dee2e6" }}>
                                    <td style={{ cursor: 'pointer', hover: 'color:#007bf8' }}>
                                      <span>{person.person_name}</span>
                                      <img style={{ float: 'left' }}  src={PersonImg} alt={'Persons'} onClick={(e) => handleBuildingsnFloors(person)}/>
                                    </td>
                                  {personPopupContent}
                                </tr>
                              )}})}
                              </>
                          </tbody>
                        </reactbootstrap.Table>
                        <div className="pg col-md-12">
                          {personsPages.length > 1 && <Pagination style={{ width: '295px', overflow: 'auto', marginBottom: '0px' }} size="md">{personsPages}</Pagination>}
                        </div>
                      </reactbootstrap.Tab>
                      <reactbootstrap.Tab eventKey={1} title={t('Jobs')}>
                        <reactbootstrap.Table responsive bordered hover>
                          <thead>
                            <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
                              <th>{t('Name')}</th>
                            </tr>
                          </thead>
                          <tbody>
                              <>
                              <input type="text" className="search-input form-control" style={{ borderRadius: "5px", borderColor: "#EC661C" }} placeholder={t("What are you looking for ?")} autoFocus onChange={(e) => searchData(e)} /><br />
                              {Object.values(items).map((job, index) => {
                                if(job.job_name){
                                return (
                                <tr>
                                  <td>
                                      <span >{job.job_name}</span>
                                      <img style={{ float: 'left' }}  src={JobImg} alt={'Jobs'} onClick={(e) => handlePersons(job)}/>
                                  </td>
                                  {jobPopupContent}
                                </tr>
                              )}})}
                              </>
                          </tbody>
                        </reactbootstrap.Table>
                        <div className="pg col-md-12">
                          {jobsPages.length > 1 && <Pagination style={{ width: '200px', overflow: 'auto' }} size="md">{jobsPages}</Pagination>}
                        </div>
                      </reactbootstrap.Tab>
                    </reactbootstrap.Tabs>
                  </reactbootstrap.Form>
                </div>
              </reactbootstrap.Container>
          </div>
        </div>
      </div>
  );
}
export default translate(FloorAccess);
