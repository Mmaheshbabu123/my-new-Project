import React, { Component } from 'react';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import {translate} from '../../language';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import Floor from './Details/Floor';
import FloorAccess from './Access/FloorAccess';

class FloorIndex extends Component {
  constructor(props) {
    super(props)
    this.state = {
      t:props.t,
      activeTab: 0,
      buildingId: (this.props.buildingid !== undefined &&  this.props.buildingid !== null && this.props.buildingid !== 0) ? this.props.buildingid.value : null,
      buildingName: (this.props.buildingid !== undefined &&  this.props.buildingid !== null  && this.props.buildingid !== 0) ? this.props.buildingid.label : '',
      buildingCode: (this.props.buildingid !== undefined &&  this.props.buildingid !== null  && this.props.buildingid !== 0) ? this.props.buildingid.code : '',
      floorId: this.props.floorid,
      action: this.props.action,
    }
    this.handleSelectTab = this.handleSelectTab.bind(this);
  }

  componentDidUpdate(prevProps, prevState) {
    if ((prevProps.floorid !== this.props.floorid) || (prevProps.action !== this.props.action)) {
      this.setState({
        buildingId: (this.props.buildingid !== undefined &&  this.props.buildingid !== null && this.props.buildingid !== 0) ? this.props.buildingid.value : null,
        buildingName: (this.props.buildingid !== undefined &&  this.props.buildingid !== null  && this.props.buildingid !== 0) ? this.props.buildingid.label : '',
        buildingCode: (this.props.buildingid !== undefined &&  this.props.buildingid !== null  && this.props.buildingid !== 0) ? this.props.buildingid.code : '',
        floorId: this.props.floorid,
        action: this.props.action,
      })
    }
  }

  handleSelectTab(e) {
    this.setState({
      activeTab:parseInt(e)
    });
  }

  render() {
    const {t} = this.state;
    const {activeTab, buildingId, buildingName, floorId, action, buildingCode} = this.state;

    return (
      <div className='container py-2' >
        <div className='row justify-content-center' >
          <div className='col-lg-12 col-md-12 float-left px-0' >
              <reactbootstrap.Container className="p-1">
                <reactbootstrap.Form >
                  <reactbootstrap.Tabs id="controlled-tab-example" activeKey={activeTab} onSelect={(e) => this.handleSelectTab(e)}>
                    <reactbootstrap.Tab eventKey={0} title={t("Details")}>
                      <Floor parentId={buildingId}
                             buildingName={buildingName}
                             buildingCode = {buildingCode}
                             floorId={floorId}
                             action={action}
                             handleCancel = {this.props.handleCancel}
                             updateStructure={this.props.updateStructure}
                          />
                    </reactbootstrap.Tab>
                    <reactbootstrap.Tab eventKey={1} title={t('Access')}>
                      <FloorAccess floorId={floorId} buildingId={buildingId}/>
                    </reactbootstrap.Tab>
                  </reactbootstrap.Tabs>
                </reactbootstrap.Form>
              </reactbootstrap.Container>
          </div>
        </div>
      </div>
    )
  }
}

export default translate(FloorIndex);
