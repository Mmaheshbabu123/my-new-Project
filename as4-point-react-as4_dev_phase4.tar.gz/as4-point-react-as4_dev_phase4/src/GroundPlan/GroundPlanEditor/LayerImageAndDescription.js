import React, { useState, useEffect } from 'react';
import { translate } from '../../language';
import { datasave } from '../../_services/db_services';
import * as reactbootstrap from "react-bootstrap";

const LayerImageAndDescription = (props) => {
  const t = props.t;
  const [state, setState] = useState({
    showModal : false,
    description: '',
    imageArray: [],
  })
  useEffect(() => {
    datasave.service(`${window.GETlAYER_DESC_IMAGES}/${props.ip_id}/${props.layer_id}/${props.uniqueId}`, 'GET')
      .then(response => {
        if (response.status === 200) {
          setState({
            ...state,
            description: response.data[0] ? response.data[0].description : '',
            imageArray: response.data,
          })
        }
      })
  }, [])
  return (
    <>
      <strong>{t('Description')}:</strong>
      <p>{state.description}</p>
      <strong>{t('Images')}:</strong>
      {state.imageArray.length > 0 ? <div className="col-md-12 row">
        {state.imageArray.map(image => {
          return (
            <div style={{ marginRight: '5%', cursor: 'pointer' }} className='col-md-5' >
              <img
                id={image.file_id}
                src={image.file_path}
                width={'100%'}
                height={'100%'}
                onClick={() => {
                  setState({...state, file_path : image.file_path, showModal : true })
                }}
              />
            </div>
          );
        })}
      </div>
        : <p>{t('no images to show')}</p>}
        <reactbootstrap.Modal
          show={state.showModal}
          onHide={() => setState({...state, showModal : false })}>
        <reactbootstrap.Modal.Body>
          <img src = {state.file_path}
               width={'100%'}
               height={'100%'}/>
        </reactbootstrap.Modal.Body>
        </reactbootstrap.Modal>
    </>
  );
}
export default translate(React.memo(LayerImageAndDescription));
