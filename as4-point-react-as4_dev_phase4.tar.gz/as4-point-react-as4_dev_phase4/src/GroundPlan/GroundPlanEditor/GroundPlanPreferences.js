import React, { useState, useEffect } from 'react';
import { translate } from '../../language';
import { store } from '../../store';
import { datasave } from '../../_services/db_services';
import * as reactbootstrap from "react-bootstrap";
import MultiSelect from '../../_components/MultiSelect';
import { OCAlert } from '@opuscapita/react-alerts';
import Can from '../../_components/CanComponent/Can';
import {CanPermissions} from '../../_components/CanComponent/CanPermissions';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';

const GroundPlanPreferences = React.memo((props) => {
  const t = props.t;
  const userData = store.getState();
  const person_id = userData.UserData.user_details.person_id;
  const user_name = userData.UserData.user_details.user_name;
  const [state, setState] = useState({
    floorOptions     : [],
    selectedBuildings: props.selectedBuildings !== undefined ? props.selectedBuildings : [],
    selectedFloors   : props.selectedFloors !== undefined  ? props.selectedFloors : [],
    selectedLayers   : props.selectedLayers !== undefined ? props.selectedLayers : [],
    person_id        : person_id,
    personDetails    : [{
      value : person_id,
      label : user_name,
    }],
  });

  useEffect(()=>{
    constructAndSetStateValues();
  },[])

  const constructAndSetStateValues = () =>{
    let selectedBuildings = handleData(props.buildings, props.selectedBuildings);
    let floors = handleFilter(props.selectedBuildings, props.floors);
    let selectedFloors = handleData(floors, props.selectedFloors);
    let selectedLayers = handleData(props.layers, props.selectedLayers);
    setState({...state,
      selectedBuildings : selectedBuildings,
      selectedLayers : selectedLayers,
      selectedFloors : selectedFloors,
      floorOptions : floors,
    })
  }

  const handleData = (data, ids) => {
    let result = [];
    data.map(val => {
      if(ids.includes(val.value)){ result.push(val) }});
    return result;
  }

  const handleDefaultBuildingChange = async (e) => {
    let ids = e.map(obj => { return obj['value'] });
    let floors = await handleFilter(ids, props.floors);
    let selectedFloors = modifySelectedFloors(ids);
    setState({...state,
      selectedBuildings: e,
      floorOptions     : floors,
      selectedFloors   : selectedFloors,
    });
  }

  const modifySelectedFloors = (buildingIds) => {
    let selectedFloors = [];
    state.selectedFloors.map((floor) => {
      if(buildingIds.includes(floor.parent_id)){
        selectedFloors.push(floor);
      }
    })
    return selectedFloors;
  }

  const handleDefaultFloorsLayersChange = (e, name) => {
    setState({...state, [name] : e })
  }

  const handleFilter = (selctIds,dataObj) =>{
       let data = [];
       for(var i = 0 ; i<selctIds.length;i++){
       if(dataObj[selctIds[i]]!== undefined){
       Array.prototype.push.apply(data, Object.values(dataObj[selctIds[i]]))
    }}
    return data;
 }

 const handleSave = async () => {
    datasave.service(window.SAVE_GROUNDPLAN_DEFAULT_PREFERENCES, 'POST', state).
    then(response => {
      response.status === 200 ?
        OCAlert.alertSuccess(t('Saved successfully.!'), { timeOut: window.TIMEOUTNOTIFICATION })
      : OCAlert.alertError(t('Unable to save default preferences.'), { timeOut: window.TIMEOUTNOTIFICATION });
      props.reloadTheComponent(response.data);
    });
 }

 // const handleCancel = () => {
 //   constructAndSetStateValues();
 // }

 const formDisabled = (CanPermissions("Access_groundplan,E_groundplan_editor", "") === true) ? false : true;

 return(
  <Can
     perform = "Access_groundplan,E_groundplan_editor,V_groundplan_editor"
     yes = {() => (
      <reactbootstrap className="container row ">
          <reactbootstrap.Container>
             <reactbootstrap.InputGroup className="">
                 <div className="col-md-4" >
                     <reactbootstrap.InputGroup.Prepend>
                         <reactbootstrap.InputGroup style={{ color: '#EC661C' }} id="basic-addon1">{t('Person:')}</reactbootstrap.InputGroup>
                     </reactbootstrap.InputGroup.Prepend>
                 </div>
                 <div class="col-md-8 input-padd">
                   <reactbootstrap.Form.Control className="col-md-12" as="input"
                       type="text"
                       name='name'
                       id = {person_id}
                       value={user_name}
                       disabled={true}
                   />
                 </div>
             </reactbootstrap.InputGroup>
             <reactbootstrap.InputGroup className="" style = {{marginTop:'15px'}}>
                <div className="col-md-4" >
                    <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ color: '#EC661C' }} id="basic-addon1">{t('Buildings:')}</reactbootstrap.InputGroup>
                    </reactbootstrap.InputGroup.Prepend>
                </div>
                <div class="col-md-8 input-padd">
                    <MultiSelect
                    options={props.buildings}
                    standards={state.selectedBuildings}
                    disabled={formDisabled}
                    handleChange={(e) => handleDefaultBuildingChange(e)}
                    isMulti={true}
                    />
                </div>
            </reactbootstrap.InputGroup>
            <reactbootstrap.InputGroup className="" style = {{marginTop:'15px'}}>
              <div className="col-md-4">
                  <reactbootstrap.InputGroup.Prepend>
                      <reactbootstrap.InputGroup style={{ color: '#EC661C' }} id="basic-addon1">{t('Floors:')}</reactbootstrap.InputGroup>
                  </reactbootstrap.InputGroup.Prepend>
              </div>
              <div class="col-md-8 input-padd">
                  <MultiSelect
                  options={state.floorOptions}
                  standards={state.selectedFloors}
                  disabled={formDisabled}
                  handleChange={(e) => handleDefaultFloorsLayersChange(e, 'selectedFloors')}
                  isMulti={true}
                  />
              </div>
           </reactbootstrap.InputGroup>
           <reactbootstrap.InputGroup className="" style = {{marginTop:'15px'}}>
              <div className="col-md-4">
                  <reactbootstrap.InputGroup.Prepend>
                      <reactbootstrap.InputGroup style={{ color: '#EC661C' }} id="basic-addon1">{t('Layers:')}</reactbootstrap.InputGroup>
                  </reactbootstrap.InputGroup.Prepend>
              </div>
              <div class="col-md-8 input-padd">
                  <MultiSelect
                  options={props.layers}
                  standards={state.selectedLayers}
                  disabled={formDisabled}
                  handleChange={(e) => handleDefaultFloorsLayersChange(e, 'selectedLayers')}
                  isMulti={true}
                  />
              </div>
           </reactbootstrap.InputGroup>
           {formDisabled === false &&
             <reactbootstrap.FormGroup style = {{marginTop :'20px'}}>
                <div style={{ float: 'right' }} className="organisation_list">
                  <a type="submit" onClick={() => props.closePreferenceModal()} name="cancel" > {t('Close')} </a>
                  &nbsp;&nbsp;&nbsp;
                  <reactbootstrap.Button type="submit"
                  name="save"
                  className="btn btn-primary"
                  onClick={handleSave}>{t('Save')}
                </reactbootstrap.Button>
                </div>
             </reactbootstrap.FormGroup>
           }
         </reactbootstrap.Container>
      </reactbootstrap>
    )}
    no={ () =>
      <AccessDeniedPage/>
    }
  />
 );
})

export default translate(GroundPlanPreferences);
