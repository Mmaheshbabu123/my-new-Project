import React, { useState, useEffect, useRef, useMemo } from 'react';
// import { Prompt } from 'react-router';
import L from 'leaflet';
import InspectionPopup from './InspectionPopup';
import DefaultPreferences from './GroundPlanPreferences';
import InspectionLinkingDetails from './InspectionLinkingDetails';
import RemoveInspectionPoint from './RemoveInspectionPoint';
import LayerImageAndDescription from './LayerImageAndDescription';
import Can from '../../_components/CanComponent/Can';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
import { Map, Marker, Popup, ImageOverlay } from "react-leaflet";
import { CanPermissions } from '../../_components/CanComponent/CanPermissions';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../../language';
import { datasave } from '../../_services/db_services';
import { store } from '../../store';
import * as reactbootstrap from "react-bootstrap";
import './GroundPlanEditor.css';
import map_marker from '../../images/map_marker-512.png';
import blocked from './blocked.png';
import CheckBox from '../../CheckBox';
var MAP_DEFAULT_BOUNDS = [];
var SLICE_HOVER     = false;
var SLICE_ROW = null;
var PDCA = 0;
var TODO_SLICE   = '';
var STATUS_SLICE = '';
var REPORT_SLICE = '';
var DOCS_SLICE   = '';
var HOVER_MARKER = {};
var CLICK_EVENT  = false;
var returnIPdata = {};
var editorBounds = {x: 110, y: 190};

const GroundPlanEditor = (props) => {
  const t = props.t;
  const [dbResponse, setResponse] = useState([]);
  const userData  = store.getState();
  const person_id = userData.UserData.user_details.person_id;
  const inputRef  = useRef({});
  const urlArray  = window.location.href;
  const overview  = urlArray.includes('groundplan_overview') ? 1 : 0;
  var screenWidth = overview && window.screen && window.screen.width ? window.screen.width : 0;

  const [state, setState] = useState({
    buildings            : [],     floors            : [],
    layers               : [],     inspectionPoints  : [],
    floorIcons           : [],     selectedBuildings : [],
    selectedLayers       : [],     linkedFloors      : [],
    selectedFloors       : [],     floorIps          : [],
    searchList           : [],     saveDetails       : [],
    inspectionIcons      : [],     layerIcons        : [],
    tab                  : 1,      selBuildingFloors : [],
    showInspectionPoints : false,  showPopup         : false,
    selectAllBuildings   : false,  selectAllLayers   : false,
    selectAllFloors      : false,  sel_noneBuildings : false,
    sel_noneFloors       : false,  sel_noneLayers    : false,
    defaultBuildings     : [],     defaultFloors     : [],
    ipLinkedLayers       : [],     ipLinkedFloors    : [],
    selectedInspection   : '',     searchAllIps      : [],
    defaultLayers        : [],     ipLinkedBuildings : [],
    timeInterval         : 0,      slice             : 0,
    taskPlanner          : [],     task_ids          : [],
    webform_ids          : [],     showPreferences   : false,
    showRemoveIP         : false,  showDndMsg        : false,
    updateInspections    : 0,      viewInspection    : 0,
    mode                 : '',     showLinkedDetails : false,
    BlockBoxRefIds       : {},
    report_color         : window.DEFAULT_REPORT_COLOR,
    doc_color            : window.DEFAULT_DOC_COLOR,
    status_color         : window.DEFAULT_STATUS_COLOR,
    result_color         : window.DEFAULT_RESULT_COLOR,
    defaultBounds        : {x: 140, y: 275},
    searchTerm           : {buildings: '', floors: '', layers: '' },
    showTableView        : overview !== 1 ? 'open' : 'close',
    gridItemId           : 0,
  });

  useEffect(() => {
    dataLoad();
  }, [])

  const fetchInpsectionPoints = async (data) => {
    await datasave.service(window.FETCH_GROUND_PLAN_DATA_IP, 'GET')
      .then(async response => response.data)
      .then(async preFillData => {
        setState({...state,
          showPopup         : false,
          showLinkedDetails : false,
          updateInspections : !(state.updateInspections),
          inspectionPoints  : preFillData.inspection_points !== undefined ? preFillData.inspection_points : [],
          inspectionIcons   : preFillData.inspection_icons  !== undefined ? preFillData.inspection_icons  : [],
          showDndMsg        : false,
       })
    });
  }

  async function dataLoad(data = '') {
    if(data === ''){
      await datasave.service(`${window.FETCH_GROUND_PLAN_DATA}/${person_id}?screenwidth=${screenWidth}`, 'GET')
      .then(async response => response.data)
      .then(async preFillData => {
        await setStateResponseValues(preFillData);
        await setResponse(preFillData);
      });
    }else{
      await setStateResponseValues(data);
      await setResponse(data);
    }
  }

  const updateInspectionsData = async(data, flow = '') => {
    if(flow !== 'delete'){
      returnIPdata = { id : data.id, value : data.id, label : `${data.code}-${data.name}`};
    }else if (flow === 'delete') {
      localStorage.gp_editorDroppedElementData = '0';
    }
    await fetchInpsectionPoints();
  }

  const sortBuildingLayerFloorIpByLabel = (dataoptions, key = '')=> {
    const sortable = Object.keys(dataoptions).map(i => dataoptions[i])
    sortable.sort(function(a, b) {
      if(Object.keys(a).length && Object.keys(b).length){
        return a.label.localeCompare(b.label, undefined, {
          numeric: true,
          sensitivity: 'base'
        });
      }
    });
    return key === '' ? sortable : getFilteredData(sortable, key);
  }

  const getFilteredData = (sortable, key) => {
    let value = state['searchTerm'][key];
    return sortable.filter(item => { return item.label.toLowerCase().search(value.toLowerCase()) !== -1  })
  }

  const searchHandler = (key, value) => {
    setState({...state, searchTerm: {...state['searchTerm'], [key]: value }});
  }

  const setStateResponseValues = (preFillData) => {
    let data = preFillData.data !== undefined ? preFillData.data : [];
    setState({
      ...state,
      buildings          : (overview === 1 ? (data.linkedBuildings !== undefined ? data.linkedBuildings : [])
                         : (data.buildings !== undefined ? data.buildings : [])),
      floors             : (overview === 1 ? (data.linkedFloors !== undefined ? data.linkedFloors : [])
                         : (data.floors !== undefined ? data.floors : [])),
      layers             : (overview === 1 ? (data.linkedLayers !== undefined ? data.linkedLayers : [])
                         : (data.layers !== undefined ? data.layers : [])),
      inspectionPoints   : data.inspection_points !== undefined ? data.inspection_points : [],
      floorIcons         : data.floor_icons       !== undefined ? data.floor_icons       : [],
      inspectionIcons    : data.inspection_icons  !== undefined ? data.inspection_icons  : [],
      layerIcons         : data.layer_icons       !== undefined ? data.layer_icons       : [],
      selectedBuildings  : (overview === 1 && preFillData.selected_building  !== undefined) ? preFillData.selected_building  : [],
      selectedFloors     : (overview === 1 && preFillData.selected_floors    !== undefined) ? preFillData.selected_floors    : [],
      selectedLayers     : (overview === 1 && preFillData.selected_layers    !== undefined) ? preFillData.selected_layers    : [],
      defaultBuildings   : (overview === 1 && preFillData.selected_building  !== undefined) ? preFillData.selected_building  : [],
      defaultFloors      : (overview === 1 && preFillData.selected_floors    !== undefined) ? preFillData.selected_floors    : [],
      defaultLayers      : (overview === 1 && preFillData.selected_layers    !== undefined) ? preFillData.selected_layers    : [],
      selectAllBuildings : (overview === 1 && preFillData.selectAllBuildings !== undefined) ? preFillData.selectAllBuildings : false,
      selectAllFloors    : (overview === 1 && preFillData.selectAllFloors    !== undefined) ? preFillData.selectAllFloors    : false,
      selectAllLayers    : (overview === 1 && preFillData.selectAllLayers    !== undefined) ? preFillData.selectAllLayers    : false,
      saveDetails        : preFillData.tree_data          !== undefined ? preFillData.tree_data          : [],
      taskPlanner        : preFillData.taskPlanner        !== undefined ? preFillData.taskPlanner        : [],
      timeInterval       : preFillData.timeInterval       !== undefined ? preFillData.timeInterval       : 0,
      selBuildingFloors  : (overview === 1 && data.linkedFloors !== undefined) ? getSortedFloors(preFillData.selected_building, data.linkedFloors) : [],
      sel_noneBuildings  : false,
      sel_noneLayers     : false,
      sel_noneFloors     : false,
      showPopup          : false,
      viewInspection     : 0,
      showInspectionPoints : false,
      showLinkedDetails    : false,
      showPreferences      : false,
      showDndMsg           : false,
      defaultBounds        : preFillData.defaultBounds !== undefined ? preFillData.defaultBounds : state.defaultBounds,
      gridItemId           : preFillData.gridItemId !== undefined ? preFillData.gridItemId : 0,
      BlockBoxRefIds       : preFillData.BlockBoxRefIds !== undefined ? preFillData.BlockBoxRefIds : {},
    });
  }

  useEffect(()=>{
    if(state.mode === 'drop'){
      updateDroppedElementData(returnIPdata, 0);
    }
  },[state.inspectionPoints])

  const getDataToPost = () => {
    if (dbResponse.tree_data !== undefined) {
      let equal = JSON.stringify(dbResponse.tree_data) === JSON.stringify(state.saveDetails);
      if (!equal) {
        let data = { data: state.saveDetails, }
        redirectToSave(data);
      }else{
        OCAlert.alertSuccess(t('Saved successfully.!'), { timeOut: window.TIMEOUTNOTIFICATION });
      }}
  }

  const redirectToSave = (data) => {
    datasave.service(window.SAVE_GROUND_PLAN_DATA, 'POST', data)
      .then(response => {
        setResponse({...dbResponse, tree_data : data.data });
       response.status === 200 ? OCAlert.alertSuccess(t('Saved successfully.!'), { timeOut: window.TIMEOUTNOTIFICATION })
       : OCAlert.alertError(t('Unable to save the ground plan data.'), { timeOut: window.TIMEOUTNOTIFICATION });
      })
  }
  const resetValues = () => {
    setStateResponseValues(dbResponse);
  }

  const onDragStart = (e, ip_data) => {
    e.dataTransfer.setData('from', '1');
    e.dataTransfer.setData("inspection_data", JSON.stringify(ip_data));
  }

  const onDragOver = (event) => {
    if (overview) { return false }
    event.preventDefault();
  }

  const onDrop = (event, floorObj, buildingId) => {
    event.preventDefault();
    let createOrLink = parseInt(event.dataTransfer.getData('from'));
    if(createOrLink !== 1 && createOrLink !== 0){
      return;
    }
    let uniqueId = Math.random().toString(36).substr(2, 9);
    var inspection_data = [];
    var inspectionId = 0, floorId = floorObj.value;
    if(createOrLink === 1){
      inspection_data = JSON.parse(event.dataTransfer.getData("inspection_data"));
      inspectionId =  inspection_data.value !== undefined ? inspection_data.value : 0;
    }
    var index = `${floorId}_${uniqueId}` + '';
    let mapRef = inputRef.current[floorId];
    if (mapRef !== null) {
    const map = mapRef.leafletElement;
    var point = L.point(event.clientX, event.clientY);
    var markerCoords = map.containerPointToLatLng(point);
    var coordsX = (markerCoords.lat) > -30 ? (Math.random() * (95 - 0) + 0) : (Math.random() * (0 - (-95)) + (-95));
    var coordsY = markerCoords.lng - 55;
    var data = { ...state.saveDetails };
    let marker = {
        building_id   : buildingId,
        floor_id      : floorId,
        inspection_id : inspectionId,
        coordinate_x  : coordsX,
        coordinate_y  : coordsY,
      }
      let dropData = {
         data : data, floorId : floorId, index : index, marker : marker, inspection_data : inspection_data,
         inspection_id : inspectionId,
       }
      localStorage.setItem('gp_editorDroppedElementData', JSON.stringify(dropData));
      setState({
        ...state,
        showPopup         : true,
        flow              : parseInt(createOrLink),
        mode              : 'drop',
        dropedBuilding    : state.buildings[buildingId] !== undefined ? state.buildings[buildingId] : {},
        droppedFloor      : floorObj,
        droppedInspection : inspection_data ,
        droppedId         : index,
      });
    }
  }

  const updateDroppedElementData = (returnObj = {}, flow = 0) => {
    let dropData = JSON.parse(localStorage.getItem('gp_editorDroppedElementData'));
    let inspection_id   = flow === 0 ? returnObj.id : dropData.inspection_id;
    let inspection_data = flow === 0 ? returnObj    : dropData.inspection_data;
    let data = dropData ? updateDataObject(dropData.data, dropData.floorId, dropData.index,
       dropData.marker, inspection_data, inspection_id) : state.saveDetails;
    let linkedIps = getLinkedInspectionPointsDetails(state.selectedFloors, state.selectedLayers, data);
    setState({
      ...state,
      saveDetails    : data,
      showPopup      : false,
      viewInspection : 0,
      floorIps       : linkedIps,
      searchList     : linkedIps,
    })
  }

  const updateDataObject = (data, floorId, index, marker, inspection_data, inspection_id) => {
    if(state.selectedLayers.length > 0){
      state.selectedLayers.forEach((item) => {
        let layersData = state.layers[item] !== undefined ? state.layers[item] : [];
        data = {
          ...data,
          [floorId]: {...(data[floorId] !== undefined ? data[floorId] : {}),
            [item]: {...(data[floorId] !== undefined ? data[floorId][item] : {}),
              [index]: {...marker,
                layer_id       : item,
                drop_id        : index,
                inspection_id  : inspection_id,
                inspectionData : inspection_data,
                layersData     : layersData  }
            }}
           }
      });
    }
    return data;
  }

  const updateCoordinates = (target, marker) => {
    let latlng     = target._latlng;
    let data       = { ...state.saveDetails };
    let floor      = marker.floor_id;
    let ip_id      = marker.inspection_id;
    let newCoordsX = latlng.lat;
    let newCoordsY = latlng.lng;
    marker = { ...marker, coordinate_x: newCoordsX, coordinate_y: newCoordsY }
    Object.values(data[floor]).map( outerObj => {
      return Object.values(outerObj).map(innerObj => {
        if(innerObj.inspection_id === ip_id){
          let layer_id = innerObj.layer_id;
          let index = innerObj.drop_id;
          data = {...data,
            [floor]:{...data[floor],
              [layer_id]:{...data[floor][layer_id],
                [index]:{...data[floor][layer_id][index],
                  coordinate_x: newCoordsX, coordinate_y: newCoordsY }}
                }}
              }
          return true;
        })
      })
    setState({ ...state, saveDetails: data });
  }

  const removeInspectionPoint = (marker, floorId, layerIds = []) => {
    let mapRef = inputRef.current[floorId];
    if (mapRef !== null) {
    const map = mapRef.leafletElement;
    map.closePopup();
    let data = JSON.parse(JSON.stringify({ ...state.saveDetails }));
    layerIds.forEach((item) => {
      if (data[marker.floor_id][item] !== undefined) {
        Object.values(data[marker.floor_id][item]).map(innerObj => {
          if(innerObj.inspection_id === marker.inspection_id){
            let index = innerObj.drop_id;
            return delete data[marker.floor_id][item][index];
          }})
        }
    });
    if(marker.layer_id !== undefined && marker.layer_id === 0){
      delete data[marker.floor_id][0][marker.drop_id];
    }
    let linkedIps = getLinkedInspectionPointsDetails(state.selectedFloors, state.selectedLayers, data);
    setState({ ...state,
      floorIps: linkedIps, searchList: linkedIps,saveDetails: data, showRemoveIP : false })
   }
  }

  const getAllIds = (data, from = '') => {
    let floorIds = [], floorsLength = 0, ids = [];
    if (from === 'floors') {
      data.forEach((item) => {
        if (state.floors[item] !== undefined) {
          let temp = [];
          temp = Object.keys(state.floors[item]);
          floorIds = [...floorIds, ...temp]; }
        });
      floorsLength = floorIds.length;
      return [floorIds.map(Number), floorsLength];
    }
    if (from === 'layers') {
      Object.values(data).map((item) => { return ids.push(item.value) });
      return ids;
    }
    ids = Object.keys(data).length > 0 ? Object.keys(data) : [];
    var arrayOfIds = ids.map(Number);
    return arrayOfIds;
  }

  const handleBuildingChange = (e, name, id) => {
    if (!state.sel_noneBuildings) {
      let ids, floorsLength;
      let temp = [...state.selectedBuildings];
      let buildingsLength = Object.keys(state.buildings).length;
      let selectedFloors = [...state.selectedFloors];
      if (!e.target.checked) {
        if (parseInt(id) === 0) {
          temp = [];
        } else {
          const index = temp.indexOf(id);
          if (index > -1) { temp.splice(index, 1); }
          if (state.floors[id] !== undefined) {
            Object.keys(state.floors[id]).forEach((item) => {
              const key = selectedFloors.indexOf(parseInt(item));
              if (key > -1) {
                selectedFloors.splice(key, 1)
              }}
            )}
          [ids, floorsLength] = getAllIds(temp, 'floors');
        }
      } else {
        if (parseInt(id) === 0) {
          temp = getAllIds(state.buildings);
          [ids, floorsLength] = getAllIds(temp, 'floors');
        } else {
          temp.push(id);
          [ids, floorsLength] = getAllIds(temp, 'floors');
        }
      }
      let selectedBuildingFloors = getSortedFloors(temp, state.floors);
      closeRadialMarkers(PDCA);
      setState({
        ...state,
        selectedBuildings  : temp,
        selBuildingFloors  : selectedBuildingFloors,
        selectAllFloors    : (floorsLength > 0 ? (floorsLength === selectedFloors.length ? true : false) : false) ,
        selectedFloors     : temp.length > 0 ? selectedFloors : [],
        selectAllBuildings : (temp.length === buildingsLength) ? true : false,
      });
    }
  }

  const getSortedFloors = (selectedBuilding, floors, array = 1) => {
    let selBuildingFloors = !array ? selectedBuilding : [];
    if(array){
    if(selectedBuilding.length){
     selectedBuilding.forEach((item) => {
       if(floors[item] !== undefined){
         Object.values(floors[item]).map(val => {
           return( selBuildingFloors.push(val) );
         })}
     });
   }}
   selBuildingFloors.sort(function(a, b) {
     return a.label.localeCompare(b.label, undefined, {
       numeric: true,
       sensitivity: 'base'
     });
   });
   return array ? selBuildingFloors : getFilteredData(selBuildingFloors, 'floors');
  }

  const handleFloorChange = (e, name, id) => {
    if (!state.sel_noneFloors) {
      let floorsLength = 0;
      let ids = [];
      if (state.selectedBuildings.length) {
        let temp = [...state.selectedFloors];
        if (!e.target.checked) {
          if (parseInt(id) === 0) {
            temp = [];
          } else {
            const index = temp.indexOf(id);
            if (index > -1) { temp.splice(index, 1); }
          }
        } else {
          if (parseInt(id) === 0) {
            [temp, floorsLength] = getAllIds(state.selectedBuildings, 'floors');
          } else {
            [ids, floorsLength] = getAllIds(state.selectedBuildings, 'floors');
            temp.push(id);
          }
        }
        let linkedIps = getLinkedInspectionPointsDetails(temp, state.selectedLayers, state.saveDetails);
        closeRadialMarkers(PDCA);
        setState({
          ...state,
          selectedFloors: temp,
          floorIps: linkedIps,
          searchList: linkedIps,
          mode : '',
          selectAllFloors: (floorsLength > 0 ? (temp.length === floorsLength ? true : false) : false) ,
        })
      } else {
        setState({ ...state, selectAllFloors : false, selectedFloors: [] })
      }
    }
  }

  const handleLayerChange = (e, name, id) => {
      let layerLength = Object.keys(state.layers).length;
      let temp = [...state.selectedLayers];
      if (!e.target.checked) {
        if (parseInt(id) === 0) {
          temp = [];
        } else {
          const index = temp.indexOf(id);
          if (index > -1) { temp.splice(index, 1); }
        }
      } else {
        if (parseInt(id) === 0) {
          temp = getAllIds(state.layers, 'layers')
        } else {
          temp.push(id);
        }
      }
      let linkedIps = getLinkedInspectionPointsDetails(state.selectedFloors, temp, state.saveDetails);
      closeRadialMarkers(PDCA);
      setState({
        ...state,
        floorIps : linkedIps,  searchList  : linkedIps,
        selectedLayers       : temp,
        showInspectionPoints : temp.length > 0 ? true : false,
        selectAllLayers      : (temp.length === layerLength) ? true : false,
      })
  }

  const getLinkedInspectionPointsDetails = (floors, layerIds, data) => {
    let ipData = [];
    if(floors.length){
      floors.forEach((item) => {
        layerIds.forEach((item2) => {
          if(data[item]!== undefined && data[item][item2] !== undefined){
            Object.values(data[item][item2]).map(val => ipData.push(val.inspectionData))
          }});
      });
    }
    let jsonObject = ipData.map(JSON.stringify);
    let uniqueSet = new Set(jsonObject);
    return Array.from(uniqueSet).map(JSON.parse);
  }

  const searchData = (e) => {
    var list = parseInt(state.tab) === 1 ? [...state.floorIps] : [...state.allIps];
      list = list.filter(function (item) {
      let inspection = item.label;
      if (inspection !== '') {
        return inspection.toLowerCase().search(
          e.target.value.toLowerCase()) !== -1;
      }
    });
    parseInt(state.tab) === 1 ? setState({ ...state, searchList: list }) :
    setState({ ...state, searchAllIps : list })
  }

  const constructTableView = () => {
    return (
      <div style = {editorStyle.tableView} className='col-md-12 row'>
        <div className='col-md-4 pl-0 mb-3 mob-plan-editor' style={{}}>
          <p className="textStyle">
            {t('Buildings')}
          </p>
          {state.showTableView === 'open' && <div className="tableStyle">
          <input type="text" className="search-input form-control mb-2" style={{ borderRadius: "5px", borderColor: "#EC661C", position:'sticky', top:'0', zIndex:1}} value={state['searchTerm']['buildings']}  placeholder={t("What are you looking for ?")} autoFocus onChange={(e) => searchHandler('buildings', e.target.value) } />
            <div class="">
              <CheckBox
                  name={t('Select all')}
                  tick={state.selectAllBuildings}
                  onCheck={(e) => handleBuildingChange(e, 'all', 0)}
                  disabled = {(CanPermissions("Access_groundplan,E_groundplan_editor", "") === true) ? '' : 'disabled'}
                  value={0}
              />
            </div>
            {Object.values(sortBuildingLayerFloorIpByLabel(state.buildings, 'buildings')).map(val => {
              return (
                <div class="">
                  <CheckBox
                      name={val.label}
                      tick={state.selectedBuildings.indexOf(val.value) !== -1 ? true : false}
                      onCheck={(e) => handleBuildingChange(e, val.label, val.value)}
                      disabled = {(CanPermissions("Access_groundplan,E_groundplan_editor", "") === true) ? '' : 'disabled'}
                      value={val.value}
                  />
                </div>
              );
            })}
          </div>}
        </div>
        <div className='col-md-4 pl-0 mb-3 mob-plan-editor' style={{}}>
          <p className="textStyle">
            {t('Floors')} </p>
          {state.showTableView === 'open' &&  <div className="tableStyle">
            <input type="text" className="search-input form-control mb-2" style={{ borderRadius: "5px", borderColor: "#EC661C", position:'sticky', top:'0', zIndex:1}} value={state['searchTerm']['floors']}  placeholder={t("What are you looking for ?")} onChange={(e) => searchHandler('floors', e.target.value) } />
            {state.selectedBuildings.length > 0 &&
              <>
                <div class="">
                  <CheckBox
                      name={t('Select all')}
                      tick={state.selectAllFloors}
                      onCheck= {(e) => handleFloorChange(e, 'all', 0)}
                      disabled = {(CanPermissions("Access_groundplan,E_groundplan_editor", "") === true) ? '' : 'disabled'}
                      value={0}
                  />
                </div>
              </>
            }
            {getSortedFloors(state.selBuildingFloors, [], 0).map(val => {
                return (
                  <div class="">
                    <CheckBox
                        name={val.label}
                        tick={state.selectedFloors.indexOf(val.value) !== -1 ? true : false}
                        onCheck={(e) => handleFloorChange(e, val.label, val.value)}
                        disabled = {(CanPermissions("Access_groundplan,E_groundplan_editor", "") === true) ? '' : 'disabled'}
                        value={val.value}
                    />
                  </div>
                );
              })
            }
          </div>}
        </div>
        <div className='col-md-4 pr-0 pl-0 mb-3 mob-plan-editor' style={{}}>
          <p className="textStyle">
            {t('Layers')} </p>
          {state.showTableView === 'open' && <div className="tableStyle">
          <input type="text" className="search-input form-control mb-2" style={{ borderRadius: "5px", borderColor: "#EC661C", position:'sticky', top:'0', zIndex:1}} value={state['searchTerm']['layers']}  placeholder={t("What are you looking for ?")} onChange={(e) => searchHandler('layers', e.target.value) } />
          <div class="">
            <CheckBox
                name={t('Select all')}
                tick={state.selectAllLayers}
                onCheck= {(e) => handleLayerChange(e, 'all', 0)}
                disabled = {(CanPermissions("Access_groundplan,E_groundplan_editor", "") === true) ? '' : 'disabled'}
                value={0}
            />
          </div>
          {Object.values(sortBuildingLayerFloorIpByLabel(state.layers, 'layers')).map(val => {
              return (
                <div class="">
                  <CheckBox
                      name={val.label}
                      tick={state.selectedLayers.indexOf(val.value) !== -1 ? true : false}
                      onCheck={(e) => handleLayerChange(e, val.label, val.value)}
                      disabled = {(CanPermissions("Access_groundplan,E_groundplan_editor", "") === true) ? '' : 'disabled'}
                      value={val.value}
                  />
                </div>
              );
            })}
          </div>}
        </div>
      </div>
    );
  }

  const constructDndView = () => {
    let result = parseInt(state.tab) ===1 ? [...state.searchList] : [...state.searchAllIps];
    result = Object.keys(result).length > 0 ? sortBuildingLayerFloorIpByLabel(result) : result;
    var IPs = [];
    result.forEach((ip) => {
      IPs.push(
        <tr
           id          = {'ipId_' + ip.value}
           draggable   = {true}
           className   = "draggable"
           onDragStart = {(e) => onDragStart(e, ip)}
           onClick     = {(e) => showIPLinkedDetails(e, ip)}
           style       = {{ cursor: "pointer", 'text-align': 'left' }} >
           <td id={ip.value}>{ip.label} </td>
         </tr>
      );
    });
    return (
      <div>
        <div className='scroll-div-table-webform' style = {{height:'40vh'}}>
          <input style={{ position: 'sticky', top: '0px', zindex: '999', backgroundColor: '#fff' }} className="form-control search-box-border  col-md-12" placeholder={t("Search")} onChange={searchData} />
          <reactbootstrap.Table striped bordered hover size="sm" style={{}}>
            <tbody>
              {IPs}
            </tbody>
          </reactbootstrap.Table>
        </div>
      </div>
    );
  }

  /*------ADDING FLOORS IMAGES ONTO REACT-LEAFLET MAP CONATINER----*/

  const showSelectedFloors = () => {
    let selected = [];
    var southWest = overview !== 1 ? L.latLng(-editorBounds['x'], -editorBounds['y']) : L.latLng(-state.defaultBounds['x'], -state.defaultBounds['y']);
    var northEast = overview !== 1 ? L.latLng(editorBounds['x'], editorBounds['y'])   : L.latLng(state.defaultBounds['x'], state.defaultBounds['y']);
    MAP_DEFAULT_BOUNDS = L.latLngBounds(southWest, northEast);
    state.selectedBuildings.forEach((item) => {
      if (state.floors[item] !== undefined) {
        Object.values(state.floors[item]).map(val => {
          let source = state.floorIcons[val.value] !== undefined ? state.floorIcons[val.value].file_path : '';
          let marker = state.saveDetails[val.value] !== undefined ? 1 : 0;
          let buildingId = state.buildings[item].value;
          if (state.selectedFloors.indexOf(val.value) !== -1) {
            return (
              selected.push(
                <div>
                  <label> <strong>{t('Building')}</strong> : {state.buildings[item].label}, <strong>{t('Floor')}</strong> : {val.label}</label>
                  <div
                    onDragOver={(event) => onDragOver(event)}
                    onDrop={(event) => onDrop(event, val, buildingId)}
                    className={overview !== 1? 'groundPlan_editror' : 'groundPlan_overview'} id={'floorId_' + val.value} parent_id={item} >
                    <Map ref = {map => inputRef.current[val.value] = map}
                      center = {[0, 0]}
                      zoom   = {1}
                      minZoom  = {1}
                      maxZoom  = {4}
                      dragging = {true}
                      onClick  = {() => closeRadialMarkers(val.value)}
                      maxBoundsViscosity = {1.0}
                      maxBounds  = {MAP_DEFAULT_BOUNDS}
                      attributionControl = {false}
                      crs             = {L.CRS.Simple}
                      zoomControl     = {true}
                      touchZoom       = {true}
                      doubleClickZoom = {true}
                      scrollWheelZoom = {true}
                      onZoom = {() => closeRadialMarkers(val.value)}
                      >
                      <ImageOverlay
                        minZoom = {1}
                        maxZoom = {4}
                        bounds  = {MAP_DEFAULT_BOUNDS}
                        url     = {source}
                      />
                      {marker === 1 && markerJsx(val, buildingId)}
                    </Map>
                  </div>
                </div>
              ));
          }
        })}
    });
    return selected;
  }
  // const handleMapZoom = (floorId, zoom) => {
  //   closeRadialMarkers(floorId);
  // }
 /*------CREATING CUSTOM MARKERS USING LEAFLET ICON OBJECT----*/
  const markerJsx = (val, buildingId) => {
    const { taskPlanner } = state;
    let markerObj = [];
    Object.values(state.saveDetails).map(floor => {
      state.selectedLayers.forEach((layer) => {
        if (floor[layer] !== undefined) {
          Object.values(floor[layer]).map(obj => { return markerObj.push(obj) });
        }
      }
      );
      return 1;
    })
    const customMarkers = (
      markerObj.map((marker, index) => {
        let taskIndex = `${marker.building_id}_${marker.floor_id}_${marker.layer_id}_${marker.inspection_id}_${marker.drop_id}`;
        var task = taskPlanner[taskIndex] !== undefined ? taskPlanner[taskIndex] : {};
        let blockBoxExists = checkBlockBoxlinking(task.webform_id);
        console.log(blockBoxExists);
        var status_color = task.todo_status_color ? task.todo_status_color : window.DEFAULT_STATUS_COLOR;
        var result_color = task.result_color ? task.result_color : window.DEFAULT_RESULT_COLOR;
        var doc_color = state.doc_color, report_color = state.report_color;
        let url = state.layerIcons[marker.layer_id] !== undefined ? state.layerIcons[marker.layer_id].file_path : map_marker;
        let html = {
          code: `<figure>
                <div class="figure-content">
                  <svg width="100%" height="100%" viewBox="0 0 42 42" class="donut" aria-labelledby="beers-title beers-desc" role="img">
                    <desc id="beers-desc">Donut chart showing 10 total beers. Two beers are Imperial India Pale Ales, four beers are Belgian Quadrupels, and three are Russian Imperial Stouts. The last remaining beer is unlabeled.</desc>
                    <circle class="donut-hole" cx="21" cy="21" r="15.91549430918954" fill="#fff" role="presentation"></circle>
                    <circle class="donut-ring" cx="21" cy="21" r="15.91549430918954" fill="transparent"  stroke=${doc_color} stroke-width="4" role="presentation">
                      <title id="donut-segment-Status"></title>
                    </circle>
                    <circle class="donut-segment" cx="21" cy="21" r="15.91549430918954" fill="transparent" stroke=${result_color} stroke-width="4" stroke-dasharray="25 50" stroke-dashoffset="100">
                      <title id="donut-segment-Documents"></title>
                    </circle>
                    <circle class="donut-segment" cx="21" cy="21" r="15.91549430918954" fill="transparent" stroke=${status_color} stroke-width="4" stroke-dasharray="25 75" stroke-dashoffset="100">
                      <title id="donut-segment-Reports"></title>
                    </circle>
                    <circle class="donut-segment" cx="21" cy="21" r="15.91549430918954" fill="transparent" stroke=${report_color} stroke-width="4" stroke-dasharray="25 100" stroke-dashoffset="100">
                      <title id="donut-segment-Results"></title>
                    </circle>
                    <g class="chart-text">
                    <image href=${url} x='27%' y='13%' width='20' height='25' />
                    </g>
                  </svg>
                </div>
              </figure>`
        }
        var customIcon =
          // overview === 1 ? (
          L.divIcon({
            className: '',
            html: L.Util.template(html.code, html),
            iconSize: [66, 74],
            iconAnchor: [33, 74],
            popupAnchor: [-2, -50]
          })
        // ) : (
        let editor = L.icon({
          iconUrl: url,
          iconSize: [34, 45],
          iconAnchor: [17, 45],
          popupAnchor: [-2, -30]
        })
        let blockbox = L.icon({
          className:'blockbox_groundplan_marker blinking',
          iconUrl: blocked,
          iconSize: [6, 26],
          iconAnchor: [3, 26],
        })
        // );
        if (marker.floor_id == val.value) {
          let nonHoverMarker = JSON.stringify(marker) !== HOVER_MARKER;
          let inspectionLabel = marker.inspectionData.label !== undefined ? `${marker.inspectionData.label}` : 'code-name';
          // rate of change of langitude value from overview to editor (OverviewBounds/EditorBounds)*100
          let coordsY = overview !== 0 ? marker.coordinate_y * state.defaultBounds['y'] / editorBounds['y'] : marker.coordinate_y;
          let coordsX = overview !== 0 ? nonHoverMarker ? marker.coordinate_x * 1.272728 - 1 : marker.coordinate_x * 1.272728 : marker.coordinate_x;
          // let mapRef = inputRef.current[val.value];
          return (
            <>
            {blockBoxExists && <Marker icon={blockbox} position={[coordsX + (nonHoverMarker ? 12 : 5), coordsY + 9]} />}
            <Marker
              icon={overview !== 1 ? editor : (nonHoverMarker ? customIcon : editor)}
              draggable={overview === 1 ? false : true}
              onDragend={e => updateCoordinates(e.target, marker)}
              key = {`marker-${index}`}
              onClick = {overview === 1 ? (PDCA === 0 ? (e) => showRadialMarkers(e, val, marker, taskIndex) : () => showLayerDescription(marker)) : null}
              onPopupOpen={overview !== 1 ? (e => handleOpenPopup(e.target, val.value)) : null}
              onMouseOver={overview !== 1 ? null : (e => showRadialMarkers(e, val, marker, taskIndex))}
              onPopupClose={e => handleClosePopup(val.value)}
              position={[coordsX, coordsY]} >
              {overview !== 1 &&
                <Popup
                  autoPan={true} >
                   <div style={{ width: 'auto', height: 'auto', textAlign: 'center' }}>
                      <h5> {inspectionLabel} </h5> <br />
                      <reactbootstrap.Button onClick={() => viewInspectionDetails(marker, val)} variant="outline-dark" size="sm">{t('Edit')}</reactbootstrap.Button>
                      <reactbootstrap.Button onClick={() => setState({ ...state, showRemoveIP: true, selectedMarker: marker })} variant="outline-dark" style={{ marginLeft: '10px' }} size="sm">{t('Remove')}</reactbootstrap.Button>
                   </div>
                </Popup>}
            </Marker>
            </>
          );
        }
      })
    );
    return customMarkers;
  }

  const showRadialMarkers = (e, val, marker, taskIndex) => {
    const { taskPlanner } = state;
    let floorId = val.value;
    var task = taskPlanner[taskIndex] !== undefined ? taskPlanner[taskIndex] : [];
    var todo_color = task.todo_status_color ? task.todo_status_color : window.DEFAULT_STATUS_COLOR;
    var status_color = task.result_color ? task.result_color : window.DEFAULT_RESULT_COLOR;
    closeRadialMarkers(floorId, marker);
    if (HOVER_MARKER !== JSON.stringify(marker)) {
      HOVER_MARKER = JSON.stringify(marker);
    }
    let latlng = e.target._latlng;
    let X = latlng.lat;
    let Y = latlng.lng;
    let mapRef = inputRef.current[floorId];
    if (mapRef !== null) {
      const map = mapRef.leafletElement;
      let zoom = map.getZoom();
      if (!PDCA) {
        let docIcon    = getDivIconHtml(window.DEFAULT_DOC_COLOR, 'Documents');
        let statusIcon = getDivIconHtml(status_color, t('Status'));
        let todoIcon   = getDivIconHtml(todo_color, t("To do's"));
        let reportIcon = getDivIconHtml(window.DEFAULT_REPORT_COLOR, t('Reports'));
        DOCS_SLICE = L.marker(pointsBasedOnZoomLevel(X, Y, zoom, 'd'), { icon: docIcon }).addTo(map)
          .on('click', function (e) {
             CLICK_EVENT = true;
             viewInspectionDetails(marker, val, window.GP_DOCS_ROW, taskIndex);
          }).on('mouseout', function (e) {
              closeRadialMarkers(val.value);
          });
        STATUS_SLICE = L.marker(pointsBasedOnZoomLevel(X, Y, zoom, 's'), { icon: statusIcon }).addTo(map)
          .on('click', function (e) {
            CLICK_EVENT = true;
            viewInspectionDetails(marker, val, window.GP_RESULT_ROW, taskIndex);
         }).on('mouseout', function (e) {
             closeRadialMarkers(val.value);
          });
        TODO_SLICE = L.marker(pointsBasedOnZoomLevel(X, Y, zoom, 't'), { icon: todoIcon }).addTo(map)
          .on('click', function (e) {
            CLICK_EVENT = true;
            viewInspectionDetails(marker, val, window.GP_STATUS_ROW, taskIndex);
         }).on('mouseout', function (e) {
             closeRadialMarkers(val.value);
          });
        REPORT_SLICE = L.marker(pointsBasedOnZoomLevel(X, Y, zoom, 'r'), { icon: reportIcon }).addTo(map)
          .on('click', function (e) {
            CLICK_EVENT = true;
            viewInspectionDetails(marker, val, window.GP_REPORTS_ROW, taskIndex);
         }).on('mouseout', function (e) {
             closeRadialMarkers(val.value);
          });
        PDCA = val.value;
        setState({ ...state, changeShape: 1 });
      }
    }
  }

  const pointsBasedOnZoomLevel = (coordsX, coordsY, zoomLevel, slice) => {
    if(zoomLevel === 1){
      return slice === 'd' ? [coordsX + 18, coordsY + 9] : slice === 's' ? [coordsX + 20, coordsY - 12] :
             slice === 't' ? [coordsX - 2,  coordsY + 10]  : slice === 'r' ? [coordsX - 4, coordsY - 12]  : [];
    }
    if(zoomLevel === 2){
      return slice === 'd' ? [coordsX + 9,   coordsY + 6.5] : slice === 's' ? [coordsX + 9.5, coordsY - 8] :
             slice === 't' ? [coordsX - 1.5, coordsY + 6.5]   : slice === 'r' ? [coordsX-2, coordsY - 8]   : [];
      }
    if(zoomLevel === 3){
      return slice === 'd' ? [coordsX + 5, coordsY + 3] : slice === 's' ? [coordsX + 5.5, coordsY - 4] :
             slice === 't' ? [coordsX - 0.5,  coordsY + 3.5]    : slice === 'r' ? [coordsX -0.5, coordsY - 4]     : [];
      }
    if(zoomLevel === 4){
      return slice === 'd' ? [coordsX + 2.75, coordsY + 1.5] : slice === 's' ? [coordsX + 3, coordsY - 2] :
             slice === 't' ? [coordsX + 0.25, coordsY + 1.5]     : slice === 'r' ? [coordsX, coordsY - 1.75]     : [];
      }
  }

  const getDivIconHtml = (color, title, degree = 0) => {
    let icon = L.divIcon({
      iconSize   : [42, 32],
      iconAnchor : [18, 30],
      className  : 'divIconStyle',
      html: title === 'Documents' ?  `<svg viewBox="-1.06 -2.45 2.5 2.5"><path d="M 1 0 A 1 1 0 0 0 -1 -2" stroke="transparent" stroke-width="1" fill=${color}><title>${title}</title></svg>` //doc
          : title === 'Reports'   ?  `<svg viewBox="-0.5 -0.01 2.5 2.5"> <path d="M 0 0 A 1 1 0 0 0 2 2" stroke="transparent" stroke-width="0" fill=${color}><title>${title}</title></svg>` // repo
          : title === 'Status'    ?  `<svg viewBox="-2.49 -0.7 2.5 2.75"><path d="M 0 0 A 1 1 0 0 0 -2 2" stroke="transparent" stroke-width="1" fill=${color}><title>${title}</title></svg>` //status
          :                          `<svg viewBox="0 -2.2 2.5 2.65"><path d="M 0 0 A 1 1 0 0 0 2 -2" stroke="transparent" stroke-width="1" fill=${color}><title>${title}</title></svg>` // todo
    });
    return icon;
  }

  const closeRadialMarkers = (floorId, marker = '') => {
    let mapRef = inputRef.current[floorId];
    if (mapRef && !CLICK_EVENT) {
      const map = mapRef.leafletElement;
      if (PDCA && HOVER_MARKER !== JSON.stringify(marker)) {
        map.removeLayer(DOCS_SLICE);
        map.removeLayer(REPORT_SLICE);
        map.removeLayer(STATUS_SLICE);
        map.removeLayer(TODO_SLICE);
        PDCA = 0;
        HOVER_MARKER = {};
        CLICK_EVENT = false;
        setState({ ...state, changeShape: 0 });
      }
    }
  }

  const showLayerDescription = (marker) => {
    setState({...state,
      clickedLayerId    : marker.layer_id,
      clickedIP_id    : marker.inspection_id,
      droppedId       : marker.drop_id,
      showDescription : true,
    })
  }

  const closeDescriptionModal = () => {
    setState({...state,
      clickedLayerId    : 0,
      clickedIP_id    : 0,
      droppedId       : '',
      showDescription : false,
    })
  }

  /*------ADJUSTING MAP MAX BOUNDS TO IMAGE RESOLUTIONS----*/
  // function imageOverlay(val, source){
  //   var myImage    = new Image();
  //   myImage.onload = getWidthAndHeight
  //   myImage.src   = source;
  //   var imgHeight = myImage.height;
  //   var imgWidth  = myImage.width;
  //   let mapRef    = inputRef.current[val.value];
  //   if (inputRef.current.length && mapRef !== undefined) {
  //     const map     = mapRef.leafletElement;
  //     var southWest = map.unproject([0, imgHeight], map.getMaxZoom() - 1);
  //     var northEast = map.unproject([imgWidth, 0], map.getMaxZoom() - 1);
  //     var bounds    = new L.LatLngBounds(southWest, northEast);
  //     L.imageOverlay(source, bounds).addTo(map);
  //     map.setMaxBounds(bounds);
  //   }
  // }
  // const getWidthAndHeight = (e) => {
  //   e.preventDefault();
  // }

  const handleClosePopup = async (floorId) => {
    let mapRef = inputRef.current[floorId];
    if (mapRef !== null) {
      const map = mapRef.leafletElement;
      if(!MAP_DEFAULT_BOUNDS.contains(map.getBounds())){
        map.fitBounds(MAP_DEFAULT_BOUNDS);
      }
      map.setMaxBounds(MAP_DEFAULT_BOUNDS);
    }
    SLICE_HOVER = false;
    setState({...state, renderChart : 1})
    return;
  }

  const handleOpenPopup = (target, floorId) => {
    let mapRef = inputRef.current[floorId];
    if (mapRef !== null) {
      const map = mapRef.leafletElement;
      map.setMaxBounds(null);
      target.openPopup();
    }
  }

  // const handleMouseOut = (floorId) => {
  //   let mapRef = inputRef.current[floorId];
  //   if (mapRef !== null) {
  //     //-----------//
  //   }
  // }

  useEffect(() => {
    const interval = setInterval(() => {
      autoUpdateTaskPlannerData();
   }, state.timeInterval);
      return () => clearInterval(interval);
  }, [state]);

  const autoUpdateTaskPlannerData = async () => {
    if(state.timeInterval !== 0 && overview !== 0 && !state.showPopup && !state.showPreferences && !SLICE_HOVER){
      await datasave.service(window.GET_GP_TASK_PLANNER_DATA + '/' + person_id, 'GET')
        .then(async response => response.data)
        .then(async preFillData => {
          setState({...state,
            taskPlanner : (preFillData !== undefined && preFillData !== '') ? preFillData : [],
          })
        });
    }
  }
  const viewInspectionDetails = (ip_point, floorObj, slice = null, taskIndex = '') => {
    let data            = { ...state.saveDetails };
    let buildingId      = ip_point.building_id;
    let floor           = floorObj.value;
    let drop_id         = ip_point.drop_id;
    let linked_layerIds = [];
    let layerObj        = {};
    let inspection_id   = ip_point.inspection_id;
    let task = state.taskPlanner[taskIndex] !==undefined ? state.taskPlanner[taskIndex] : [];
    let task_ids = task.task_id ? task.task_id : [];
    let webform_ids = task.webform_id ? task.webform_id : [];
    // if(!overview){
      Object.values(data[floor]).map( outerObj => {
        return Object.values(outerObj).map(innerObj => {
          if(innerObj.inspection_id === inspection_id){
            let taskIndex = `${innerObj.building_id}_${innerObj.floor_id}_${innerObj.layer_id}_${innerObj.inspection_id}_${innerObj.drop_id}`;
            let task = state.taskPlanner[taskIndex] !==undefined ? state.taskPlanner[taskIndex] : [];
            let task_ids = task.task_id ? task.task_id : [];
            let webform_ids = task.webform_id ? task.webform_id : [];
            let obj = {[innerObj.layer_id] : { layer_id : innerObj.layer_id, drop_id : innerObj.drop_id, ip_id : innerObj.inspection_id, task_ids : task_ids, webform_ids : webform_ids }}
            layerObj = {...layerObj,...obj};
            return linked_layerIds.push(innerObj.layer_id);
          }})})
    // }else{
    //   linked_layerIds.push(ip_point.layer_id);
    // }
    setState({...state,
      showPopup         : true,
      flow              : 2,
      viewInspection    : 1,
      mode              : 'view',
      linked_layerIds   : linked_layerIds,
      dropedBuilding    : state.buildings[buildingId] !== undefined ? state.buildings[buildingId] : {},
      droppedFloor      : floorObj,
      droppedInspection : ip_point.inspectionData,
      droppedId         : drop_id,
      slice             : slice,
      task_ids          : task_ids,
      webform_ids       : webform_ids,
      layerObj          : layerObj,
      showDndMsg        : false,
    })
  }

  const onDragStartAddInspection = (e, name) => {
    e.dataTransfer.setData("from", '0');
  }

  const closeInspectionPopup = (returnObj = '', layerObj = '') => {
    if(layerObj !== ''){
      let data = JSON.parse(JSON.stringify({ ...state.saveDetails }));
      let inspectionPoints = JSON.parse(JSON.stringify({ ...state.inspectionPoints }));
      let floorId = state.droppedFloor.value;
      state.linked_layerIds.forEach((item) => {
        let index = layerObj[item].drop_id;
        data[floorId][item][index].inspection_id = returnObj.id;
        data[floorId][item][index].inspectionData = returnObj;
      });
      let linkedIps = getLinkedInspectionPointsDetails(state.selectedFloors, state.selectedLayers, data);
      inspectionPoints[floorId][returnObj.id] = returnObj;
      setState({ ...state,
        showPopup      : false,
        saveDetails    : data,
        viewInspection : 0,
        floorIps       : linkedIps,
        searchList     : linkedIps,
        inspectionPoints : inspectionPoints,
        showDndMsg       : false,
      });
    }else{
      setState({...state,
        showPopup : false,viewInspection : 0, showDndMsg : false,});
    }
  }

  const closeLinkedDetailsModal = () => {
    setState({ ...state, showLinkedDetails : false });
  }

  const showIPLinkedDetails = (e, ip) => {
    let ipLinkedBuildings = [];
    let ipLinkedFloors    = [];
    let ipLinkedLayers    = [];
    let data = { ...state.saveDetails };
    Object.values(data).map(obj => {
      return Object.values(obj).map(obj2 => {
       return Object.values(obj2).map(val => {
        if(ip.value === val.inspection_id){
          ipLinkedBuildings.push(val.building_id)
          ipLinkedFloors.push(val.floor_id)
          ipLinkedLayers.push(val.layer_id) }
          return true; })
        })
      }
   )
   setState({...state,
     showLinkedDetails  : true,
     selectedInspection : ip,
     ipLinkedBuildings  : Array.from(new Set(ipLinkedBuildings)),
     ipLinkedFloors     : Array.from(new Set(ipLinkedFloors)),
     ipLinkedLayers     : Array.from(new Set(ipLinkedLayers)),
   })
  }

  const defaultPreferences = useMemo(() => {
    const { buildings, floors, layers } = state;
    return(
      <DefaultPreferences
        buildings = {Object.values(buildings)}
        floors ={floors}
        layers = {Object.values(layers)}
        selectedBuildings = {state.defaultBuildings}
        selectedFloors = {state.defaultFloors}
        selectedLayers = {state.defaultLayers}
        reloadTheComponent = {dataLoad.bind()}
        closePreferenceModal = {closePreferenceModal.bind()}
      />
    );
  }, [state.buildings, state.floors, state.layers])

  function closePreferenceModal() {
    setState({ ...state, showPreferences : false })
  }

  useMemo(() => {
   let points = { ...state.inspectionPoints };
   let inspection = [];
   Object.values(points).forEach((value, i) => {
     Object.values(value).map(ip => {return inspection.push(ip) } )
   });
   setState({...state, allIps : inspection, searchAllIps : inspection })
   },[state.inspectionPoints])


   const checkBlockBoxlinking = (webformIds = []) => {
     let blockBoxExists = false;
     webformIds.map(id => {
       if(state.BlockBoxRefIds[id] && state.BlockBoxRefIds[id].length)
          blockBoxExists = true;
     })
     return blockBoxExists;
   }

   const editorStyle = {
     container : {
       padding : '0px', margin  : '0px'
     },tableView : {
       padding : '0px', margin  : '0px'
     },groundImage : {
       padding : '0px', margin  : '0 0 30px 0',
       display : 'inline-block',
     },iconStyle_data :{
       cursor:'pointer', display:'inline', margin:'5px'
     },iconStyle_prefer :{
       cursor:'pointer', float:'right', margin:'5px'
     }
   }

   const closeRemoveInpectionModal = () => {
     setState({ ...state, showRemoveIP : false })
   }

   useMemo(() =>{
     sessionStorage.setItem("groundplanOldData", JSON.stringify(dbResponse.tree_data));
     sessionStorage.setItem("groundplanCurrentData", JSON.stringify(state.saveDetails));
   },[dbResponse.tree_data,state.saveDetails])

   const getRenderContent = () => {
     return(
       <reactbootstrap className="px-0 col-md-12">
        {(CanPermissions("Access_groundplan,V_groundplan_editor,E_groundplan_editor", "") === true) &&
          overview !== 0 &&
         <div className = 'col-md-12 px-0  row'>
           <span className='col-md-6 '>
               <img src = 'https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/5f54c084754337.982154651599389828.png' style={editorStyle.iconStyle_data} onClick = {() => setState({...state, showTableView : state.showTableView === 'open' ? 'close' : 'open' })} title = {t('Ground area data')} />
           </span>
           {(state.selectedBuildings.length < 1 || state.showTableView === 'open') && <span className='col-md-6 pr-0'>
               <i style={editorStyle.iconStyle_prefer} onClick = {() => setState({...state, showPreferences:true})} title = {t('Default preferences')} class="webnew-sprite webnew-sprite-manageactionc"></i>
           </span>}
         </div>}
         {(CanPermissions("Access_groundplan,V_groundplan_editor,E_groundplan_editor", "") === true) &&
             <div className='col-md-12 pl-0 mt-2' style = {overview !==1 ? editorStyle.tableView : {}}>
               {(state.selectedFloors.length < 1 || state.showTableView === 'open') && constructTableView()}
             </div>
         }
         {(CanPermissions("Access_groundplan,V_groundplan_editor,E_groundplan_editor", "") === true) &&
           <div style={overview !==1 ? editorStyle.groundImage : {display : 'inline-block'}} className={overview !==1 ? 'col-md-8' : 'col-md-12 pl-0'}>
             {(state.defaultBuildings.length > 0 || state.selectedBuildings.length > 0 || state.showTableView === 'open') && showSelectedFloors()}
           </div>
         }
           {overview !== 1 ? <div className='col-md-4 mob-add-inspect-point' style={{paddingRight : '0px', position: "sticky", marginTop: '25px', top: "0px", float:'right'}}>
             <div>
               {state.showInspectionPoints &&
                 <reactbootstrap.Tabs style={{'font-size' : '15px'}} defaultActiveKey={state.tab} onSelect={(key) => setState({ ...state, tab: key })}>
                   {(CanPermissions("Access_groundplan,V_groundplan_editor", "") === true) &&
                     <reactbootstrap.Tab eventKey={1} title={t("Inspection elements")}>
                       {constructDndView()}
                     </reactbootstrap.Tab>
                   }
                   {(CanPermissions("Access_groundplan,V_groundplan_editor", "") === true) &&
                     <reactbootstrap.Tab eventKey={3} title={t("All inspection elements")}>
                       {constructDndView()}
                     </reactbootstrap.Tab>
                   }
                 </reactbootstrap.Tabs>
               }
               {(CanPermissions("Access_groundplan,V_groundplan_editor", "") === true && state.showInspectionPoints) &&
                 <div className = 'col-md-12 row p-0 m-0 '>
                   <div className='col-md-6 mob-drag-button' style={{ float: 'left', marginTop:'5%', padding : 0}}>
                     <reactbootstrap.Button
                       style={{height:'40px'}}
                       draggable
                       onClick = {() => {
                         setState({...state, showDndMsg : state.showDndMsg ? false : true})
                       }}
                       onDragStart={(e) => onDragStartAddInspection(e, 'add_inspection')}>
                       {t('Add inspection point')}
                     </reactbootstrap.Button>
                   </div>
                   <div style={{ 'text-align' : 'end', marginTop:'5%'}} className='organisation_list col-md-6 pr-0'>
                     <a type="submit" onClick={resetValues} name="cancel" > {t('Cancel')} </a>
                   &nbsp;&nbsp;&nbsp;
                   <reactbootstrap.Button type="submit"
                       name="save"
                       className="btn btn-primary"
                       onClick={getDataToPost}>{t('Save')}
                     </reactbootstrap.Button>
                   </div>
                   {state.showDndMsg && <small>{t('Note: drag and drop button on to floor to add inspection point.')}</small>}
                 </div>}
             </div>
           </div> : null}
           <reactbootstrap.Modal
             backdrop="static"
             keyboard={false}
             show={state.showPopup}
             onHide={() => {
               setState({ ...state, showPopup: false, viewInspection: 0 })
               CLICK_EVENT = false;
             }}
             dialogClassName = {overview !== 1 ? 'groundplan_custom_dialog_editor' : 'groundplan_custom_dialog_overview'}
             size = "xl" >
             <reactbootstrap.Modal.Header closeButton style = {{borderBottom : 'none', height: overview !== 1 ? '0px' : '50px'}}>
                {overview === 1 && <h4 style={{width:'100%', textAlign:'center'}}>{state.droppedInspection ? state.droppedInspection.label : ''}</h4>}
             </reactbootstrap.Modal.Header>
             <reactbootstrap.Container className="">
               <reactbootstrap.Modal.Body>
                 <InspectionPopup
                   flow={state.flow}
                   layers={Object.values(state.layers)}
                   selectedLayers={state.viewInspection !== 1 ? state.selectedLayers : state.linked_layerIds}
                   buildingObj={state.dropedBuilding}
                   floorObj={state.droppedFloor}
                   ipObj   ={state.droppedInspection}
                   inspectionId={state.droppedInspection ? state.droppedInspection.value : undefined}
                   selectedFloors={state.selectedFloors}
                   drop_id={state.droppedId}
                   mode={state.mode}
                   overview={overview}
                   closePopup={closeInspectionPopup.bind()}
                   updateInspectionsData={updateInspectionsData.bind()}
                   updateDroppedElementData={updateDroppedElementData.bind()}
                   slice = {state.slice}
                   task_ids = {state.task_ids}
                   webform_ids = {state.webform_ids}
                   layerObj = {state.layerObj}
                   gridItemId = {state.gridItemId}
                   blockboxRefIds = {state.BlockBoxRefIds}
                 />
               </reactbootstrap.Modal.Body>
             </reactbootstrap.Container>
           </reactbootstrap.Modal>
           {overview === 1 ? (
             <div>
             <reactbootstrap.Modal
               show={state.showPreferences}
               onHide={() => setState({ ...state, showPreferences : false })}
               aria-labelledby="example-custom-modal-styling-title"
               size={'lg'} >
              <reactbootstrap.Modal.Header closeButton>
                 <p className='common-color' style={{textAlign : 'center', width:'100%', fontSize : 'large' }}> {t('Default preferences')} </p>
              </reactbootstrap.Modal.Header>
               <reactbootstrap.Modal.Body>
                   {defaultPreferences}
               </reactbootstrap.Modal.Body>
             </reactbootstrap.Modal>
             </div>
           ) : null}
           <reactbootstrap.Modal
             show={state.showLinkedDetails}
             onHide={() => closeLinkedDetailsModal()}
             size = {state.ipLinkedBuildings.length > 0 ? 'lg' : ''}
             aria-labelledby="example-custom-modal-styling-title"
            >
               <reactbootstrap.Modal.Body>
                 <InspectionLinkingDetails
                   ipLinkedBuildings = {state.ipLinkedBuildings}
                   ipLinkedFloors = {state.ipLinkedFloors}
                   ipLinkedLayers = {state.ipLinkedLayers}
                   buildings = {Object.values(state.buildings)}
                   floors = {Object.values(state.floors)}
                   layers = {Object.values(state.layers)}
                   selectedInspection = {state.selectedInspection}
                   closeModal = {closeLinkedDetailsModal.bind()}
                   updateInspectionsData = {updateInspectionsData.bind()}
                 />
               </reactbootstrap.Modal.Body>
           </reactbootstrap.Modal>
           <div>
             <reactbootstrap.Modal
               show={state.showRemoveIP}
               onHide={() => closeRemoveInpectionModal()}
               aria-labelledby="example-custom-modal-styling-title"
              >
                 <reactbootstrap.Modal.Body>
                   <RemoveInspectionPoint
                     layers = {state.layers}
                     marker = {state.selectedMarker}
                     data   = {state.saveDetails}
                     close  = {closeRemoveInpectionModal.bind()}
                     remove = {removeInspectionPoint.bind()}
                   />
                 </reactbootstrap.Modal.Body>
             </reactbootstrap.Modal>
           </div>
           <div>
             <reactbootstrap.Modal
               show={state.showDescription}
               onHide={() => closeDescriptionModal()}
               dialogClassName='layer_desc_modal'
               size="xl"
             >
               <reactbootstrap.Modal.Header closeButton style={{ borderBottom: 'none', height: '0px' }} />
               <reactbootstrap.Modal.Body>
                 <LayerImageAndDescription
                   ip_id={state.clickedIP_id}
                   layer_id={state.clickedLayerId}
                   uniqueId={state.droppedId}
                 />
               </reactbootstrap.Modal.Body>
             </reactbootstrap.Modal>
           </div>
       </reactbootstrap>
     );
   }
  return (
    <Can
       perform = "Access_groundplan,E_groundplan_editor,V_groundplan_editor"
       yes = {() => (
       <React.Fragment>
        {overview !== 1 ?<reactbootstrap className="col-md-12" style={overview !==1 ? editorStyle.tableView : {marginBottom:'5%', marginTop :'2%'} }>
          {getRenderContent()}
        </reactbootstrap> :
        <div className='fluid pl-5'>
          <div className="container-fluid pl-5 py-5">
            {getRenderContent()}
          </div>
        </div>}
       </React.Fragment>
      )}
      no={() =>
          <AccessDeniedPage />
      }
    />
  );
}
export default translate(React.memo(GroundPlanEditor));

function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
