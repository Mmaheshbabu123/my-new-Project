import React, { useState, useEffect } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from "react-bootstrap";
import CheckBox from '../../CheckBox';

const RemoveInspectionPoint = (props) => {
  const t = props.t;
  const [state, setState] = useState({
    linkedLayerDetails : [],
    linkedLayerIds     : [],
    selectedLayer      : '',
    selectedInspection : '',
    removeFromLayers   : [],
  })

  useEffect(() => {
    linkedLayersOfSelectedInspection()
  }, [])

  const linkedLayersOfSelectedInspection = () => {
    let data = props.data;
    let floor = props.marker.floor_id;
    let inspection_id = props.marker.inspection_id;
    let linked_layerIds = [];
    let linked_layerDetails = [];
    // let layer_id = [];

    Object.values(data[floor]).map(outerObj => {
      return Object.values(outerObj).map(innerObj => {
        if (innerObj.inspection_id === inspection_id) {
          if(Object.keys(innerObj.layersData).length){
            linked_layerIds.push(innerObj.layer_id);
            return linked_layerDetails.push(innerObj.layersData);
          }
        }
      })
    })
    // layer_id.push(props.marker.layer_id);
    setState({
      ...state,
      linkedLayerDetails : Array.from(new Set(linked_layerDetails.map(JSON.stringify))).map(JSON.parse),
      linkedLayerIds     : Array.from(new Set(linked_layerIds)),
      selectedLayer      : props.marker.layersData,
      selectedInspection : props.marker.inspectionData,
      // removeFromLayers   : layer_id,
    })
  }
  const handleChange = (e, id) => {
    let temp = [...state.removeFromLayers];
    if (e.target.checked) {
      if(id === 0){ temp = state.linkedLayerIds }
      else{ temp.push(id) }
    } else{
      if(id == 0){ temp = [] }
      else{
        const index = temp.indexOf(id);
        if (index > -1) { temp.splice(index, 1); }
      }
    }
    setState({
      ...state,
      removeFromLayers: temp,
      removeAll: (temp.length === state.linkedLayerIds.length ? true : false)
    })
  }

  const handleRemove = () => {
    if(state.removeFromLayers.length < 1){
      props.close()
      return;
    }
    props.remove(props.marker, props.marker.floor_id, state.removeFromLayers);
  }
  return (
    <div className='container'>
     <p style={{width:'100%', textAlign:'center'}}>{t('Remove inspection point from linked layers')}</p>
      {state.linkedLayerIds.length > 1 &&
        <div>
          <CheckBox
            name = {t('All')}
            value={0}
            tick={state.removeAll}
            onCheck={(e) => handleChange(e, 0)}
           />
        </div>}
      {state.linkedLayerDetails.map(layer =>
          <div class="">
            <CheckBox
                name={layer.label}
                tick={state.removeFromLayers.includes(layer.value) ? true : false}
                onCheck= {(e) => handleChange(e, layer.value)}
                value={layer.value}
            />
          </div>
      )}
      <reactbootstrap.FormGroup style={{ marginTop: '20px' }}>
        <div style={{ float: 'right' }} className="organisation_list">
          <reactbootstrap.Button onClick={() => props.close()} variant="outline-dark">
            {t('Close')}
          </reactbootstrap.Button>
          <span style={{ paddingLeft: '15px' }}></span>
          <reactbootstrap.Button onClick={handleRemove} variant="outline-dark">
            {t('Remove')}
          </reactbootstrap.Button>
        </div>
      </reactbootstrap.FormGroup>
    </div>
  );
}

export default translate(React.memo(RemoveInspectionPoint));
