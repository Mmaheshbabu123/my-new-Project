import React, { useState, useEffect, useRef, useMemo } from 'react';
import L from 'leaflet';
import { Map, Marker, ImageOverlay, Popup } from "react-leaflet";
import Can from '../../_components/CanComponent/Can';
import AccessDeniedPage from '../../_components/Errorpages/AccessDenied';
import { CanPermissions } from '../../_components/CanComponent/CanPermissions';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../../language';
import { datasave } from '../../_services/db_services';
import * as reactbootstrap from "react-bootstrap";
import './GroundPlanEditor.css';
import map_marker from '../../images/marker-icon-2x-green.png';
import latest_marker from '../../images/marker-icon-2x-red.png';
import shadow_marker from '../../images/marker-shadow.png'
import CheckBox from '../../CheckBox';
var MAP_DEFAULT_BOUNDS = [];

const GroundPlanEditor = (props) => {
  const t = props.t;
  const inputRef  = useRef({});
  const overview  = 1;
  const [state, setState] = useState({
    buildings            : [],
    floors               : [],
    floorIcons           : [],
    selectedBuildings    : [], selectedFloors : [],
    saveDetails          : [],
    currentPin         : [], savedPins : [],
    showAllPins        : 0,
    pinRemoved : false,
  });
  useEffect(() => {
    if(props.building_id && props.floor_id){
      dataLoad({
         building_id : props.building_id,
         floor_id    : props.floor_id,
         rowId       : props.rowData ? props.rowData.id : 0
      });
    }else{
      OCAlert.alertError(t('Unable to fetch data.'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
  }, [])

  async function dataLoad(data) {
    await datasave.service(window.AR_GROUNDPLAN_DATA, 'POST', data)
    .then(async response => response.data)
    .then(async preFillData => {
      await setStateResponseValues(preFillData, data);
    });
  }

  const setStateResponseValues = (data, propsData) => {
    setState({
      ...state,
      buildings          : data.buildings !== undefined ? data.buildings : [],
      floors             : data.floors !== undefined ? data.floors : [],
      floorIcons         : data.floor_icons !== undefined ? data.floor_icons : [],
      selectedBuildings  : [...state.selectedBuildings, propsData.building_id],
      selectedFloors     : [...state.selectedFloors, propsData.floor_id],
      currentPin         : data.currentPin,
      savedPins          : data.savedPins,
    });
  }

  const onDragOver = (event) => {
    if (overview) { return false }
    event.preventDefault();
  }

  const updateCoordinates = (target, marker) => {
    let latlng     = target._latlng;
    let newCoordsX = latlng.lat;
    let newCoordsY = latlng.lng;
    marker = [{ ...marker, coordinate_x: newCoordsX, coordinate_y: newCoordsY, latest : 1 }];
    setState({ ...state, currentPin : marker });
  }

  /*------ADDING FLOORS IMAGES ONTO REACT-LEAFLET MAP CONATINER----*/
  const showSelectedFloors = () => {
    let selected = [];
    var southWest = overview !== 1 ? L.latLng(-110, -190) : L.latLng(-140, -275);
    var northEast = overview !== 1 ? L.latLng(110, 190)   : L.latLng(140, 275);
    MAP_DEFAULT_BOUNDS = L.latLngBounds(southWest, northEast);
    state.selectedBuildings.forEach((item) => {
      if (state.floors[item] !== undefined) {
        Object.values(state.floors[item]).map(val => {
          let source = state.floorIcons[val.value] !== undefined ? state.floorIcons[val.value].file_path : '';
          let marker = 1;//state.saveDetails[val.value] !== undefined ? 1 : 0;
          let buildingId = state.buildings[item].value;
          if (state.selectedFloors.indexOf(val.value) !== -1) {
            return (
              selected.push(
                <div>
                   <div className = 'col-md-12 row p-0 m-0'>
                     <reactbootstrap.Row className = 'col-md-10 row p-0 m-0'>
                        <reactbootstrap.Col className='col-md-9 mt-2'> <strong>{t('Building')}</strong> : {state.buildings[item].label}, <strong>{t('Floor')}</strong> : {val.label}</reactbootstrap.Col>
                        <reactbootstrap.Col className='col-md-3'>
                          <CheckBox
                            name     = {t('Show all pins')}
                            tick     = {state.showAllPins}
                            onCheck  = {(e) => { setState({...state, showAllPins : e.target.checked }) }}
                            disabled = {(CanPermissions("Access_groundplan,E_groundplan_editor", "") === true) ? '' : 'disabled'}
                            value    = {state.showAllPins}
                          />
                        </reactbootstrap.Col>
                     </reactbootstrap.Row>
                     <reactbootstrap.Row className='col-md-2 p-0 m-0'>
                       <div className='organisation_list p-0 m-0'>
                           <a type="submit"  onClick={(e) => props.showCloseGroundPlan()} name="cancel"> {t('Cancel')} </a>
                              &nbsp;&nbsp;&nbsp;
                           <reactbootstrap.Button type="submit"
                              name="save"
                              className="btn btn-primary"
                              onClick={(e)=> props.saveArImagePinlinking(state.currentPin, state.pinRemoved)}
                              >{t('Save')}
                           </reactbootstrap.Button>
                         </div>
                     </reactbootstrap.Row>
                  </div>
                  <div
                    onDragOver={(event) => onDragOver(event)}
                    className={overview !== 1? 'groundPlan_editror' : 'groundPlan_overview'} id={'floorId_' + val.value} parent_id={item} >
                    <Map ref = {map => inputRef.current[val.value] = map}
                      center = {[0, 0]}
                      zoom   = {1}
                      minZoom  = {1}
                      maxZoom  = {4}
                      dragging = {true}
                      onClick={(evt) => addPintoGroundPlan(evt)}
                      maxBoundsViscosity = {1.0}
                      maxBounds  = {MAP_DEFAULT_BOUNDS}
                      attributionControl = {false}
                      crs             = {L.CRS.Simple}
                      zoomControl     = {true}
                      touchZoom       = {true}
                      doubleClickZoom = {true}
                      scrollWheelZoom = {true}
                      >
                      <ImageOverlay
                        minZoom = {1}
                        maxZoom = {4}
                        bounds  = {MAP_DEFAULT_BOUNDS}
                        url     = {source}
                      />
                      {marker === 1 && markerJsx(val, buildingId)}
                    </Map>
                  </div>
                </div>
              ));
          }
        })}
    });
    return selected;
  }

  // const saveAndShowPinCheckBox = () => {}

  const addPintoGroundPlan = (evt) => {
    let latLng = evt.latlng;
    let newPin = [{
      coordinate_x : latLng.lat,
      coordinate_y : latLng.lng,
      latest       : 1,
    }];
    setState({...state, currentPin : newPin });
  }

 /*------CREATING CUSTOM MARKERS USING LEAFLET ICON OBJECT----*/
  const markerJsx = (val, buildingId) => {
   let markerObj = state.showAllPins ? [...state.currentPin, ...state.savedPins] : [...state.currentPin];
    const customMarkers = (
      markerObj.map((marker, index) => {
        let url = marker.latest === 1 ? latest_marker : map_marker;
        let editor = L.icon({
          iconUrl     : url,
          shadowUrl   : shadow_marker,
          iconSize    : [24, 41],
        	iconAnchor  : [12, 41],
        	popupAnchor : [1, -34],
        	shadowSize  : [41, 41],
          className   : marker.latest === 1 ? 'blinking' : '',
        })
          let coordsY = marker.coordinate_y;
          let coordsX = marker.coordinate_x;
          return (
            <Marker
              icon={editor}
              draggable={marker.latest !== 1 ? false: true}
              onDragend={e => updateCoordinates(e.target, marker)}
              key = {`marker-${index}`}
              position={[coordsX, coordsY]}
              onPopupOpen={e => handleOpenPopup(e.target, val.value)}
              onPopupClose={e => handleClosePopup(val.value)}
            >
            {marker.latest !== 0 &&<Popup
              autoPan={true} >
               <div style={{ width: 'auto', height: 'auto', textAlign: 'center' }}>
                  <h6> {t('Unlink pin from ground plan?')} </h6> <br />
                  <reactbootstrap.Button onClick={() => unLinkPinFromGroundPlan(marker, val.value)} variant="outline-dark" size="sm">{t('Unlink')}</reactbootstrap.Button>
               </div>
            </Popup>}
            </Marker>
          );
      })
    );
    return customMarkers;
  }

  const handleOpenPopup = (target, floorId) => {
    let mapRef = inputRef.current[floorId];
    if (mapRef) {
      const map = mapRef.leafletElement;
      map.setMaxBounds(null);
      target.openPopup();
    }
  }

  const handleClosePopup = async (floorId) => {
    let mapRef = inputRef.current[floorId];
    if (mapRef) {
      const map = mapRef.leafletElement;
      if(!MAP_DEFAULT_BOUNDS.contains(map.getBounds())){
        map.fitBounds(MAP_DEFAULT_BOUNDS);
      }
      map.setMaxBounds(MAP_DEFAULT_BOUNDS);
    }
  }

  const unLinkPinFromGroundPlan = (marker, floorId) => {
    let mapRef = inputRef.current[floorId];
    if (mapRef) {
      const map = mapRef.leafletElement;
      map.closePopup();
      if(marker.latest === 1){
        setState({...state, currentPin: [], pinRemoved: true })
      }else{
        let savedPins = [...state.savedPins];
        let updatedPins = savedPins.filter(pin => {
          return (JSON.stringify(pin) !== JSON.stringify(marker));
        })
        savedPins = updatedPins;
        setState({...state, savedPins: savedPins })
      }
    }

  }

  useMemo(() => {
   let points = { ...state.inspectionPoints };
   let inspection = [];
   Object.values(points).forEach((value, i) => {
     Object.values(value).map(ip => {return inspection.push(ip) } )
   });
   setState({...state, allIps : inspection, searchAllIps : inspection })
   },[state.inspectionPoints])

   const editorStyle = {
     container : {
       padding : '0px', margin  : '0px'
     },tableView : {
       padding : '0px', margin  : '0px'
     },groundImage : {
       padding : '0px', margin  : '0 0 30px 0',
       display : 'inline-block',
     },iconStyle_data :{
       cursor:'pointer', display:'inline', margin:'5px'
     },iconStyle_prefer :{
       cursor:'pointer', float:'right', margin:'5px'
     }
   }

   const getRenderContent = () => {
     return(
       <reactbootstrap className="px-0 col-md-12">
         {(CanPermissions("Access_groundplan,V_groundplan_editor,E_groundplan_editor", "") === true) &&
           <div style={overview !==1 ? editorStyle.groundImage : {display : 'inline-block'}} className={overview !==1 ? 'col-md-8' : 'col-md-12 pl-0'}>
             {showSelectedFloors()}
           </div>
         }
       </reactbootstrap>
     );
   }
  return (
    <Can
       perform = "Access_groundplan,E_groundplan_editor,V_groundplan_editor"
       yes = {() => (
       <React.Fragment>
        <reactbootstrap.Container className="" style={{marginBottom:'5%', marginTop :'2%'}}>
           {getRenderContent()}
        </reactbootstrap.Container>
       </React.Fragment>
      )}
      no={() =>
          <AccessDeniedPage />
      }
    />
  );
}
export default translate(React.memo(GroundPlanEditor));

function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
