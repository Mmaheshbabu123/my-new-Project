import React, { useState, useEffect, useRef } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from "react-bootstrap";
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';

const InspectionLinkingDetails = (props) => {
const t = props.t;
const [state, setState] = useState({
  buildings : [],
  floors : [],
  layers : [],
})

useEffect(() => {
  constructAndSetStateValues();
}, [])

const constructAndSetStateValues = () => {
  let buildings = [], floors = [], layers = [];
  buildings = filterDataAndGetLinkedDetails(props.buildings, props.ipLinkedBuildings);
  layers = filterDataAndGetLinkedDetails(props.layers, props.ipLinkedLayers);
  props.floors.map(obj => {
    Object.values(obj).map(floor => {
      if(props.ipLinkedFloors.includes(floor.value)){
        return floors.push(floor) }});
  })
  setState({...state,
    buildings : buildings,
    floors : floors,
    layers : layers,
  })
}

const filterDataAndGetLinkedDetails = (dataObj, linkedIds) => {
  let result = [];
  dataObj.map(data => {
    if(linkedIds.includes(data.value)){ return result.push(data)}
  })
  return result;
}
const getPostData = () => {
 let floorId = props.selectedInspection.parent_id;
 let floorCode = '';
 let buildingId = '';
 let buildingCode = '';
 props.floors.map(val => {
   Object.values(val).map(floor => {
     if(floor.value === floorId){
       floorCode  = floor.code;
       buildingId = floor.parent_id;
       return true;
     }})
   })
 props.buildings.map(building => {
   if(building.value === buildingId){
     buildingCode = building.code;
   }})
 return {...props.selectedInspection, parent_id : floorId, parentCode : `${buildingCode}.${floorCode}`}
}

const deleteInspectionPoint = () =>{
  datasave.service(window.DELETE_INSPECTION_POINT, 'POST', getPostData())
  .then(response => {
    if(response.status === 200){
      props.updateInspectionsData(response.data, 'delete');
      OCAlert.alertSuccess(t('Deleted successfully.!'), { timeOut: window.TIMEOUTNOTIFICATION });
    }else{
      OCAlert.alertError(t('Unable to delete inspection point.'), { timeOut: window.TIMEOUTNOTIFICATION });
    }
  })
}

const showLinkedData = (data, name) => {
  if(data.length){
    return(
      <div className='col-md-4' style={{padding : '0'}}>
        <reactbootstrap.Table striped bordered responsive hover variant="">
          <thead style={{position: 'sticky', top: '0', backgroundColor:'#EC661C', color:'white'}}>
             <tr style={{textAlign:'center'}}>
             <th>{name}</th>
           </tr>
          </thead>
          <tbody>
          {data.map((val,index) => {
            return <tr id = {val.value}>
                      <td> {val.label}</td>
                   </tr>
          })}
         </tbody>
       </reactbootstrap.Table>
      </div>
    );
  }
}

return (
      <reactbootstrap className=" row ">
        <reactbootstrap.Container>
        {props.ipLinkedBuildings.length > 0 ? (
          <h5 style={{textAlign:'center', fontSize : 'large'}}> {`${t('Linked details of')} ${props.selectedInspection.label}`} </h5>
        ):(
          <div>
            <h5 style={{textAlign:'center', fontSize : 'medium'}}> {`${t('No data is linked yet to')} ${props.selectedInspection.label}`} </h5>
            <div>
              <reactbootstrap.FormGroup style = {{marginTop :'20px'}}>
                 <div style={{ float: 'right' }} className="organisation_list">
                   <a type="submit" onClick = {() => props.closeModal()} name="cancel" > {t('Close')} </a>
                   &nbsp;&nbsp;&nbsp;
                   <reactbootstrap.Button type="submit"
                   name="save"
                   className="btn btn-primary"
                   onClick = {deleteInspectionPoint}
                   >{t('Delete')}
                 </reactbootstrap.Button>
                 </div>
              </reactbootstrap.FormGroup>
            </div>
          </div>
        )
        }
        <div className='col-md-12 row'>
            {showLinkedData(state.layers, t('Layers'))}
            {showLinkedData(state.buildings, t('Buildings'))}
            {showLinkedData(state.floors, t('Floors'))}
        </div>
       </reactbootstrap.Container>
      </reactbootstrap>
    );
}
export default translate(InspectionLinkingDetails);

function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
    ref.current = value;
	}, [value]);
	return ref.current;
}
