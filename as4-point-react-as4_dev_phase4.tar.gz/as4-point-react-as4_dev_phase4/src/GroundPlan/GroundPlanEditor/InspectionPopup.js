import React, { useState, useMemo } from 'react';
import { translate } from '../../language';
import * as reactbootstrap from "react-bootstrap";
import CreateIPSeditorForm from '../InspectionPoint/Details/CreateIPSeditorForm';
import InspectionOverview from '../InspectionPoint/Details/InspectionElementOverview'

var mainData = {};
const InspectionPopup = (props) => {
  const [state, setState] = useState({
    selectedLayer : undefined,
    data : {},
  });

 let defaultTabKey = 0;
 const showLayerWiseInspections = () => {
   let layers = [];
   props.layers.map(item => {
     if(props.selectedLayers.includes(item.value)){
       layers.push(item);
     }
   });
   defaultTabKey = layers.length > 0 ? layers[0].value : 0;
   if(layers.length > 0 && props.overview !== 1){
     return(
            <CreateIPSeditorForm
              action       = {0}
              buildingObj  = {props.buildingObj}
              floorObj     = {props.floorObj}
              ipid         = {props.inspectionId}
              current_type = 'inspectionpoint'
              flow         = {props.flow}
              fromEditor   = {1}
              drop_id      = {props.drop_id}
              updateInspectionsData   = {props.updateInspectionsData}
              closePopup   = {props.closePopup}
              layers       = {layers}
              task_ids     = {props.task_ids}
              webform_ids  = {props.webform_ids}
              layerObj     = {props.layerObj}
              blockboxRefIds = {props.blockboxRefIds}
              updateDroppedElementData = {props.updateDroppedElementData}
            />
     );
   }else if (props.overview === 1) {
     return(
       <reactbootstrap.Tabs
          onSelect = {(key) => setState({...state, selectedLayer : parseInt(key) })}
          defaultActiveKey = {defaultTabKey} >
        {layers.map(layer => <reactbootstrap.Tab  eventKey = {layer.value} title = {layer.label}> </reactbootstrap.Tab> )}
       </reactbootstrap.Tabs>
     );
   }
 }
  const renderOverviewPage = () => {
    let layerObject = props.layerObj[state.selectedLayer] ? props.layerObj[state.selectedLayer] : props.layerObj[defaultTabKey];
    return (
      <InspectionOverview
        action       = {0}
        buildingObj  = {props.buildingObj}
        floorObj     = {props.floorObj}
        ipid         = {props.inspectionId}
        current_type = 'inspectionpoint'
        flow         = {props.flow}
        fromEditor   = {1}
        drop_id      = {layerObject !== undefined ? layerObject.drop_id : props.drop_id}
        closePopup   = {props.closePopup}
        slice        = {props.slice}
        task_ids     = {layerObject ? (layerObject.task_ids.length > 0 ? layerObject.task_ids : 0) : 0}
        webform_ids  = {layerObject ? (layerObject.webform_ids.length > 0 ? layerObject.webform_ids : 0) : 0}
        layer_id     = {layerObject ? layerObject.layer_id : props.selectedLayers[0]}
        gridItemId = {props.gridItemId}
        blockboxRefIds = {props.blockboxRefIds}
      />
    );
  }
  return(
    <>
    {showLayerWiseInspections()}
    {props.overview === 1 && renderOverviewPage()}
    </>
  )
}

export default translate(React.memo(InspectionPopup));
