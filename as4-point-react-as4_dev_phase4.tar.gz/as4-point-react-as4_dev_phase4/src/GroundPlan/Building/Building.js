import React, { useState, useEffect} from 'react';
import { translate } from '../../language';
import * as reactbootstrap from "react-bootstrap";
import Details from './BuildingComponents/BuildingDetails';
import Layers from './BuildingComponents/BuildingLayers';
import Access from './BuildingComponents/BuildingAccess';
import { datasave } from '../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
export const BuildingContext = React.createContext();

const Building = (props) => {
  const t = props.t;
  const [tab, setTab] = useState(1);
  const [dbResponse, setResponse]           = useState([]);
  const [layerOverview, setLayerOverview]   = useState([]);
  const [accessOverview, setAccessOverview] = useState([]);

  const [buildingState, manageState]  = useState({
    buildingId      : props.buildingid.id,
    buildingName    : '',
    nameWarning     : false,
    buildingCode    : '',
    codeWarning     : false,
    codeExists      : '',
    description     : '',
    coordinate_x    : '',
    coordinate_y    : '',
    buildingAddress : '',
    file_name       : 'Choose image',
    file_id         : 0,
    file_path       : '',
    isDisable       : props.buildingid.action,
    formatWarning   : false,
    sizeWarning     : false,
    uploadMessage   : false,
  })
   //-- didMount() and didUpdate()--//
   useEffect(()=>{
     if(buildingState.buildingId){
       datasave.service(window.FETCH_BUILDING + '/' +buildingState.buildingId, 'GET').
       then(response => {
         if(response.status === 200){
           setLayerOverview(response.data.building_layers);
           setAccessOverview(response.data.building_access);
           setResponse(response.data.building_data);
           setStateValues(response.data.building_data);
         }
       })
     }else if (props.buildingid && props.buildingid.action_type === 2) {
       datasave.service(`${window.GET_GROUNDPLAN_NR}/1/-1`, 'GET')
      .then(response => {
        setToInitialState(buildingState.buildingId, response.data ? response.data.code : '');
      })
     }
     else{
       setToInitialState();
     }
   },[buildingState.buildingId])

   const setStateValues = (data) => {
     if(data !== null && data !== undefined && data !== ''){
       let file_details = data['file_details'] !== undefined ? data['file_details'] : [];
       manageState({...buildingState,
         buildingName    : data.name              !== null      ? data.name              : '',
         buildingCode    : data.code              !== null      ? data.code              : '',
         description     : data.description       !== null      ? data.description       : '',
         coordinate_x    : data.coordinate_x      !== null      ? data.coordinate_x      : '',
         coordinate_y    : data.coordinate_y      !== null      ? data.coordinate_y      : '',
         buildingAddress : data.address           !== null      ? data.address           : '',
         file_id         : file_details.id        !== undefined ? file_details.id        : 0,
         file_name       : file_details.file_name !== undefined ? file_details.file_name : 'Choose image',
         file_path       : file_details.file_path !== undefined ? file_details.file_path : '',
         uploadMessage   : false,
       }) }
       else{
         setToInitialState();
       }
   }

   useEffect(() => {
     manageState({...buildingState,
       buildingId   : props.buildingid.id,
       isDisable    : props.buildingid.action,
     })
	},[props.buildingid.action,props.buildingid.id])

   const getDataToPost = () => {
     let data = {
       id           : buildingState.buildingId,
       name         : buildingState.buildingName,
       code         : buildingState.buildingCode,
       description  : buildingState.description,
       coordinate_x : buildingState.coordinate_x,
       coordinate_y : buildingState.coordinate_y,
       address      : buildingState.buildingAddress,
       img_id       : buildingState.file_id,
       parentCode   : '',
       parent_id    : -1,
     }
     return data;
   }

  const saveBuildingData = () => {
   if(validateRequiredField()){
     let data = getDataToPost();
     let url = buildingState.buildingId ? window.UPDATE_BUILDING : window.CREATE_BUILDING;
     datasave.service(url,'POST',data)
     .then(response =>{
       if(response.status === 500){
         manageState({...buildingState, codeExists:response.error.code});
         return;
       }
       manageState({...buildingState, uploadMessage : false, })
       props.updateStructure(response.data,'','','building');
       response.status === 200 ?
       OCAlert.alertSuccess(t('Building data saved successfully'),{ timeOut: window.TIMEOUTNOTIFICATION }) :
       OCAlert.alertError(t('Not able to save building data'),{ timeOut: window.TIMEOUTNOTIFICATION });

     })
   }
 }
 const handleCancel = () => {
   if(!buildingState.isDisable){
     if(buildingState.buildingId !== 0){
       setStateValues(dbResponse);
     }else {
       setToInitialState();
     }
     props.handleCancel('building');
   }
 }
 const setToInitialState = (id = 0, code = '') => {
   manageState({...buildingState,
     buildingId      : id,
     buildingName    : '',
     buildingCode    : code,
     description     : '',
     coordinate_x    : '',
     coordinate_y    : '',
     buildingAddress : '',
     file_name       : 'Choose image',
     file_id         : 0,
     file_path       : '',
     isDisable       : 0,
     uploadMessage  : false,
   })
 }
const validateRequiredField = () => {
  let { buildingName, buildingCode } = buildingState;
  if(buildingName.length < 1 && buildingCode.length < 1){
    manageState({...buildingState, nameWarning : true, codeWarning : true})
    return false;
  }else if (buildingName.length < 1 && buildingCode.length > 1) {
    manageState({...buildingState, nameWarning : true, codeWarning : false})
    return false;
  }else if (buildingName.length > 1 && buildingCode.length < 1) {
    manageState({...buildingState, nameWarning : false, codeWarning : true})
    return false;
  }else{
    manageState({...buildingState, nameWarning : false, codeWarning : false})
    return true;
  }
}
  return (
    <reactbootstrap className=" row ">
      <div className="col-md-12" >
        <reactbootstrap.Container className=''>
          <div className='col-md-12'>
              <reactbootstrap.Tabs defaultActiveKey={tab} id = "uncontrolled-tab-example" onSelect = {(key) => setTab(key)}>
                <reactbootstrap.Tab eventKey={1} title={t("Details")}>
                   <Details state = {buildingState} handler = {manageState} />
                </reactbootstrap.Tab>
                <reactbootstrap.Tab eventKey={2} title={t("Layers")}>
                   <Layers layersData = {layerOverview}/>
                </reactbootstrap.Tab>
                <reactbootstrap.Tab eventKey={3} title={t("Access")}>
                   <Access accessData = {accessOverview} buildingId={props.buildingid.id}/>
                </reactbootstrap.Tab>
              </reactbootstrap.Tabs>
              {tab == 1 &&
              <reactbootstrap.FormGroup>
                <div style={{ float: 'right' }} className="organisation_list">
                  <a disabled = {buildingState.isDisable} type="submit" onClick = {handleCancel} name="cancel" > {t('Cancel')} </a>
                           &nbsp;&nbsp;&nbsp;
                  <reactbootstrap.Button type="submit"
                     name="save"
                     disabled = {buildingState.isDisable}
                     className="btn btn-primary"
                     onClick  = {saveBuildingData}
                     >{t('Save')}
                  </reactbootstrap.Button>
                </div>
              </reactbootstrap.FormGroup>}
          </div>
        </reactbootstrap.Container>
      </div>
    </reactbootstrap>
  );
}
export default translate(React.memo(Building));
