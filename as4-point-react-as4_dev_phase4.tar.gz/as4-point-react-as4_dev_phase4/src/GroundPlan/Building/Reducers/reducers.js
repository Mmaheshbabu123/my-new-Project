import axios from 'axios';
import { datasave } from '../../../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
export const reducers = {
  uploadImage,
  removeImage,
  downloadImage
};

async function uploadImage(e){
  var result = {};
  let files      = e.target.files;
  let size       = files[0]['size'] / window.GROUND_PLAN_FILE_MAX_SIZE;
  if(!window.GROUND_PLAN_FILE_FORMATS.includes(e.target.files[0]['name'].split('.').pop()) && size > window.GROUND_PLAN_FILE_MAX_SIZE) {
    result.status = 500;
    result.formatWarning = true;
    result.sizeWarning   = true;
    return result;
  }else if (!window.GROUND_PLAN_FILE_FORMATS.includes(e.target.files[0]['name'].split('.').pop()) && size < window.GROUND_PLAN_FILE_MAX_SIZE) {
    result.status = 500;
    result.formatWarning = true;
    result.sizeWarning   = false;
    return result;
  }else if (window.GROUND_PLAN_FILE_FORMATS.includes(e.target.files[0]['name'].split('.').pop()) && size > window.GROUND_PLAN_FILE_MAX_SIZE) {
    result.status = 500;
    result.formatWarning = false;
    result.sizeWarning   = true;
    return result;
  }
  const formData = new FormData();
  formData.append('file', e.target.files[0])
  const url = window.UPLOAD_FILE + '/' + window.GROUND_PLAN_FILES;
  document.getElementById("loding-icon").setAttribute("style", "display:block;");
  await axios.post(window.backendURL + url, formData, { headers: { "Authorization": "Bearer " + process.env.REACT_APP_key } })
      .then(response => {
          document.getElementById("loding-icon").setAttribute("style", "display:none;");
          result.status = 200;
          result.data = response.data;
      })
      .catch(error => {
          document.getElementById("loding-icon").setAttribute("style", "display:none;");
          OCAlert.alertError('Error occured while saving image', { timeOut: window.TIMEOUTNOTIFICATION });
      })
      return result;
}

 async function removeImage(id){
  var url = window.DELETE_UPLOADED_FILE + '/' + id;
  await datasave.service(url, "POST")
      .then(result => {
        return 1;
     })
     .catch(err => {
       return 0;
     })
}

function downloadImage(url, fileName = ''){
  if(!url) return;
  var xmlRequest = new XMLHttpRequest();
  xmlRequest.open("GET", url, true);
  xmlRequest.responseType = "blob";
  xmlRequest.onload = function(){
    var urlCreator = window.URL || window.webkitURL;
    var imageUrl = urlCreator.createObjectURL(this.response);
    var anchorTag = document.createElement('a');
    anchorTag.href = imageUrl;
    anchorTag.download = fileName ? fileName : Math.random().toString(16).slice(2);
    document.body.appendChild(anchorTag);
    anchorTag.click();
    document.body.removeChild(anchorTag);
  }
  xmlRequest.send();
}
