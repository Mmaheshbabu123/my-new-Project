import React from 'react';
import * as reactbootstrap from "react-bootstrap";
import { translate } from '../../../language';

const BuildingLayers = (props) => {
  const t = props.t;
  const layerOverview = props.layersData !== undefined ? props.layersData : [];
  return (
    <reactbootstrap className=" row ">
      <div className="col-md-12" >
        <reactbootstrap.Container className='col-md-12 mt-3'>
        {layerOverview.length > 0 ? (
          <reactbootstrap.Table striped bordered responsive hover variant="">
          <thead style={{ backgroundColor: '#EC661C', color: '#fff', position: 'sticky', top: '0' }}>
            <tr style={{textAlign:'center'}}>
              <th>{t('Sl.no')}</th>
              <th>{t('code')}</th>
              <th>{t('Layer name')}</th>
            </tr>
          </thead>
          <tbody>
            {layerOverview.map((layer,index) => {
              return <tr id = {layer.id}>
                        <td> {index+1} </td>
                        <td> {layer.code}</td>
                        <td> {layer.name}</td>
                     </tr>
            })}
          </tbody>
          </reactbootstrap.Table>
        ) : <p>{t('No layers linked yet.')}</p>    
        }
        </reactbootstrap.Container>
      </div>
    </reactbootstrap>
  );
}
export default translate(React.memo(BuildingLayers));
