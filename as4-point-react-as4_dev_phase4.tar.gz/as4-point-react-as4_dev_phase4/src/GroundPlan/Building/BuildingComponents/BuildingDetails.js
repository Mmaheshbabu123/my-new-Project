import React from 'react';
import * as reactbootstrap from "react-bootstrap";
import { translate } from '../../../language';
import { reducers } from '../Reducers/reducers';

const BuildingDetails = (props) => {
    const t = props.t;
    const { state, handler } = props;

    const handleFileChanges = async (e, type, url = '') => {
      if(type === 'upload'){
        let response = await reducers.uploadImage(e);
        if(response.status === 200){
          handler({...state,
            file_id: response.data.file_id[0],
            file_name : response.data.originalfname,
            file_path : response.data.filepath,
            formatWarning : false,
            sizeWarning : false,
            uploadMessage : true,
          })
        } else{
          handler({...state,
            formatWarning : response.formatWarning,
            sizeWarning   : response.sizeWarning,
            uploadMessage:false,
          })
        }
      } else if (type === 'download') {
         reducers.downloadImage(url, state.file_name);
      } else if (state.file_id !== 0) {
        // await reducers.removeImage(state.file_id);
        handler({...state,
          file_id   : 0,
          file_name : t('Choose image'),
          file_path : '',
        })
      }
    }
    return (
        <reactbootstrap className=" row ">
            <div className="col-md-12" >
                <reactbootstrap.Container className=" pb-4">
                    <reactbootstrap.Form >
                        <reactbootstrap.FormGroup>
                            <div className=" row input-overall-sec ">
                                <reactbootstrap.InputGroup className="  ">
                                    <div className="col-md-4 mobileLabel">
                                        <reactbootstrap.InputGroup.Prepend>
                                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Building code:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                        </reactbootstrap.InputGroup.Prepend>
                                    </div>
                                    <div class="col-md-8 input-padd">
                                        <reactbootstrap.FormControl
                                            name="buildingCode"
                                            value={state.buildingCode}
                                            onChange={(e) =>handler({...state, buildingCode: e.target.value, codeWarning : false,codeExists:''})}
                                            placeholder="Building code"
                                            disabled={state.isDisable}
                                            className="input_sw"
                                        />
                                        {state.codeWarning && <div style={{ color: 'red' }} className="error-block">{t('Building code is required')}</div>}
                                        {state.codeExists !== '' && <div style={{ color: 'red' }} className="error-block">{state.codeExists}</div>}
                                    </div>
                                </reactbootstrap.InputGroup>
                            </div>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                            <div className=" row input-overall-sec ">
                                <reactbootstrap.InputGroup className="  ">
                                    <div className="col-md-4 mobileLabel">
                                        <reactbootstrap.InputGroup.Prepend>
                                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Building name:")}<span style={{ color: "red", backgroundColor: 'none', border: '0px' }}>*</span></reactbootstrap.InputGroup>
                                        </reactbootstrap.InputGroup.Prepend>
                                    </div>
                                    <div class="col-md-8 input-padd">
                                        <reactbootstrap.FormControl
                                            name="buildingName"
                                            placeholder="Building name"
                                            onChange={(e) =>handler({...state, buildingName: e.target.value, nameWarning : false })}
                                            value={state.buildingName}
                                            disabled={state.isDisable}
                                            className="input_sw"
                                        />
                                        {state.nameWarning && <div style={{ color: 'red' }} className="error-block">{t('Name is required field')}</div>}
                                    </div>
                                </reactbootstrap.InputGroup>
                            </div>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                            <div className=" row input-overall-sec ">
                                <reactbootstrap.InputGroup className="  ">
                                    <div className="col-md-4 mobileLabel">
                                        <reactbootstrap.InputGroup.Prepend>
                                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Description:')}</reactbootstrap.InputGroup>
                                        </reactbootstrap.InputGroup.Prepend>
                                    </div>
                                    <div class="col-md-8 input-padd">
                                        <reactbootstrap.FormControl as="textarea"
                                            name="description"
                                            value={state.description}
                                            onChange={(e) =>handler({...state, description: e.target.value })}
                                            disabled={state.isDisable}
                                            className="input_sw"
                                        />
                                    </div>
                                </reactbootstrap.InputGroup>
                            </div>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                            <div className=" row input-overall-sec ">
                                <reactbootstrap.InputGroup className="  ">
                                    <div className="col-md-4 mobileLabel">
                                        <reactbootstrap.InputGroup.Prepend>
                                            <reactbootstrap.InputGroup c style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Coordinates')}</reactbootstrap.InputGroup>
                                        </reactbootstrap.InputGroup.Prepend>
                                    </div>
                                    <div class="col-md-8 input-padd row">
                                        <span class="col-md-3">
                                            <reactbootstrap.FormControl
                                                name="coordinate_x"
                                                value={state.coordinate_x}
                                                onChange={(e) =>handler({...state, coordinate_x: e.target.value })}
                                                disabled={state.isDisable}
                                                className="input_sw"
                                            />
                                        </span>
                                        <span class="col-md-3">
                                            <reactbootstrap.FormControl
                                                name="coordinate_y"
                                                value={state.coordinate_y}
                                                onChange={(e) =>handler({...state, coordinate_y: e.target.value })}
                                                disabled={state.isDisable}
                                                className="input_sw"
                                            />
                                        </span>
                                    </div>
                                </reactbootstrap.InputGroup>
                            </div>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                            <div className=" row input-overall-sec ">
                                <reactbootstrap.InputGroup className="  ">
                                    <div className="col-md-4 mobileLabel">
                                        <reactbootstrap.InputGroup.Prepend>
                                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t("Address of the site:")}</reactbootstrap.InputGroup>
                                        </reactbootstrap.InputGroup.Prepend>
                                    </div>
                                    <div class="col-md-8 input-padd">
                                        <reactbootstrap.FormControl
                                            name="buildingAddress"
                                            value={state.buildingAddress}
                                            onChange={(e) =>handler({...state, buildingAddress: e.target.value })}
                                            disabled={state.isDisable}
                                            className="input_sw"
                                        />
                                    </div>
                                </reactbootstrap.InputGroup>
                            </div>
                        </reactbootstrap.FormGroup>
                        <reactbootstrap.FormGroup>
                            <div className=" row input-overall-sec ">
                                <reactbootstrap.InputGroup className="  ">
                                    <div className="col-md-4 mobileLabel">
                                        <reactbootstrap.InputGroup.Prepend>
                                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Upload image:')}</reactbootstrap.InputGroup>
                                        </reactbootstrap.InputGroup.Prepend>
                                    </div>
                                    <div className="col-md-8 custom-file input_sw">
                                        <input
                                            type="file"
                                            className="custom-file-input"
                                            id="image"
                                            name='image'
                                            disabled = {state.isDisable}
                                            accept={window.DOC_TYPES['default']}
                                            onChange={(e) =>{handleFileChanges(e, 'upload')}}
                                            onClick={(event)=> event.target.value = null}
                                        />
                                        <label className="custom-file-label" htmlFor="inputGroupFile01">
                                            {state.file_name !== null && state.file_name }
                                        </label>
                                    </div>
                                </reactbootstrap.InputGroup>
                            </div>
                        </reactbootstrap.FormGroup>
                        <div style={{}} className="row col-md-12 mt-2">
                            <div style={{ visibility: 'hidden' }} className="col-md-4 mob-hide">
                                <h3>{t('Upload')}</h3>
                            </div>
                              <div className="col-md-8 mob-align">
                                {!state.formatWarning && !state.sizeWarning && state.file_name !== 'Choose image' &&
                                  <div>
                                      {state.uploadMessage && <span style={{ color: "green" }}>{window.FILE_UPLOAD_SUCCESS}</span>}
                                      <span style={{display:'inline-block', marginRight: '10px'}}>
                                          <i title="preview" style={{ 'cursor': 'pointer' }} class="webform-sprite webform-sprite-smallviewc" onClick={(e) => window.open(state.file_path, "_blank")}></i>
                                      </span>
                                      <span style={{display:'inline-block', marginRight: '10px'}}>
                                          <img src="https://as4-point.s3.eu-west-1.amazonaws.com/as4-point/profile/61726d5042ee88.300490011634889040.png" alt="Logo" title="Download" style={{cursor: 'pointer', marginTop: '-10px' }} onClick = {(e) => handleFileChanges(e, 'download', state.file_path)}></img>
                                      </span>
                                      {!state.isDisable && <span style={{display:'inline-block', marginRight: '10px'}}>
                                          <i title="Remove" style={{ 'cursor': 'pointer' }} class="overall-sprite overall-sprite-mtdeletec"  onClick={(e) => {handleFileChanges(e, 'remove')}}/>
                                      </span>}
                                  </div>}
                                {state.formatWarning && state.sizeWarning && <span style={{ color: "red" }}>{window.FILE_FORMAT_ERROR_MSG}{t( 'and size should be < 1MB')} </span>}
                                {state.formatWarning && !state.sizeWarning && <span style={{ color: "red" }}> {window.FILE_FORMAT_ERROR_MSG} </span>}
                                {!state.formatWarning && state.sizeWarning && <span style={{ color: "red" }}> {t('Size should be < 1MB')} </span>}
                            </div>
                        </div>
                    </reactbootstrap.Form>
                </reactbootstrap.Container>
            </div>
        </reactbootstrap>
    );
}
export default translate(React.memo(BuildingDetails));
