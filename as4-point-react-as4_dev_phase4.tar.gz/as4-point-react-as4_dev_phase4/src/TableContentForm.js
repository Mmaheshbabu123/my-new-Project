import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../src/_services/db_services';
import MultiSelect from '../src/_components/MultiSelect';
import {translate} from './language';

class TableContentForm extends Component {
    constructor(props) {
        super(props)
            this.state = {
                name: '',
                manual_options: [],
                selected_manuals: [],
                folder_options: [],
                selected_folders: [],
                space_options: [],
                selected_spaces: [],
                standards : [],
                t:props.t,
            }
        this.handleChange = this.handleChange.bind(this);
        this.handleChangeManual = this.handleChangeManual.bind(this);
        this.handleChangeFolder = this.handleChangeFolder.bind(this);
        this.handleChangeSpace = this.handleChangeSpace.bind(this);

    }

    handleChange(event) {
        const { name, value } = event.target;
        this.setState({
        [name]: value,
        name_error: '',
        });
    }

    handleChangeManual(event) {
        this.setState({
            selected_manuals: event,
        })
    }

    handleChangeFolder(event) {
        this.setState({
            selected_folders: event,
        })
    }

    handleChangeSpace(event) {
        this.setState({
            selected_spaces: event,
        })
    }

    componentDidMount() {
        datasave.service(window.MANUALOPTIONS, 'GET', this.state)
        .then(result => {
            this.setState({
                manual_options : result,
        })
        });
        datasave.service(window.FOLDEROPTIONS, 'GET', this.state)
        .then(result => {
            this.setState({
                folder_options : result,
        })
        });
        datasave.service(window.SPACEOPTIONS, 'GET', this.state)
        .then(result => {
            this.setState({
                space_options : result,
        })
        });
    }

    render() {
        const {name, loading ,t,standards} = this.state
        const {name, loading, standards} = this.state
        return(
            <div className='container py-4' >
                <div className='row justify-content-center' >
                    <div className='col-md-12' >
                        <div className='card' >
                            <div className='card-header' > {t('Create TableContent')} </div>
                            <div className='card-body' >
                                <reactbootstrap.Container className="p-5">
                                <reactbootstrap.Form onSubmit={this.handleSubmit}>
                                    <reactbootstrap.FormGroup>
                                    {/* <div className={'form-group' + (submitted && !name ? ' has-error' : '')}> */}
                                        <reactbootstrap.InputGroup className="mb-3">
                                        <reactbootstrap.InputGroup.Prepend>
                                            <reactbootstrap.InputGroup  id="basic-addon1">{t('Report name')}<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                                        </reactbootstrap.InputGroup.Prepend>
                                        <reactbootstrap.FormControl
                                            name="name"
                                            placeholder={t("Definition")}
                                            aria-label="Definition"
                                            aria-describedby="basic-addon1"
                                            value={name}
                                            onChange={this.handleChange}
                                        />
                                        </reactbootstrap.InputGroup>
                                        {/* <div style={{ color: 'red' }} className="error-block">{name_error}</div> */}
                                    {/* </div> */}
                                    {/* <reactbootstrap.InputGroup.Prepend>
                                        <reactbootstrap.InputGroup.Text id="basic-addon1">Manual </reactbootstrap.InputGroup.Text>
                                    </reactbootstrap.InputGroup.Prepend> */}
                                    <reactbootstrap.FormGroup>
                                    <reactbootstrap.FormCheck
                                        onChange={e => this.setState({ standards: !standards })}
                                        name='standard'
                                        checked={standards}
                                        label={t("Standard")}
                                    />
                                    </reactbootstrap.FormGroup>
                                    <MultiSelect
                                        options = {this.state.manual_options}
                                        standards = {this.state.selected_manuals}
                                        //disabled={details.disableFields}
                                        // name = 'tags'
                                        handleChange={(e) => this.handleChangeManual(e)}
                                    />
                                    <reactbootstrap.InputGroup.Prepend>
                                        <reactbootstrap.InputGroup  id="basic-addon1">{t('Folders')} </reactbootstrap.InputGroup >
                                    </reactbootstrap.InputGroup.Prepend>
                                    <MultiSelect
                                        options = {this.state.folder_options}
                                        standards = {this.state.selected_folders}
                                        //disabled={details.disableFields}
                                        // name = 'tags'
                                        handleChange={(e) => this.handleChangeFolder(e)}
                                    />
                                    <reactbootstrap.InputGroup.Prepend>
                                        <reactbootstrap.InputGroup  id="basic-addon1">{t('Spaces')} </reactbootstrap.InputGroup >
                                    </reactbootstrap.InputGroup.Prepend>
                                    <MultiSelect
                                        options = {this.state.space_options}
                                        standards = {this.state.selected_spaces}
                                        //disabled={details.disableFields}
                                        // name = 'tags'
                                        handleChange={(e) => this.handleChangeSpace(e)}
                                    />
                                    <div className="form-group">
                                        <reactbootstrap.Button type="submit" className="btn btn-primary" disabled={loading}>{t('Save')}</reactbootstrap.Button>
                                        &nbsp;&nbsp;&nbsp;
                                        <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.handleCancel} >{t('Cancel')}</reactbootstrap.Button>
                                        {/* {loading &&
                                        <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                                        } */}
                                    </div>
                                    </reactbootstrap.FormGroup>
                                </reactbootstrap.Form>
                                </reactbootstrap.Container>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default translate(TableContentForm)
