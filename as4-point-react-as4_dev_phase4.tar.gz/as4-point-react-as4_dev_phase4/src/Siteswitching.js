import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from './language';
import { datasave } from './_services/db_services';
import { Button, Form, FormGroup, InputGroup, FormControl } from 'react-bootstrap';
import { Input, Label } from 'reactstrap';
import MultiSelect from './_components/MultiSelect';

import { OCAlert } from '@opuscapita/react-alerts';





class Siteswitching extends Component {
    constructor(props) {
        super(props)
        this.state = {
            showpopup: false,
            selectedtype  : '',
            totalsites : [],
            no_of_sites: 0,
            activeorganisationsdata :[],
            selectedorg : '',
            sitetypes: [{
                "label": "Organisation",
                "value": 1,
            },
            {
                "label": "Site",
                "value": 2,
            },
            ],
        }
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.cancelPopup = this.cancelPopup.bind(this);
        this.showPopup = this.showPopup.bind(this);
        this.handleChangeType = this.handleChangeType.bind(this);



    }

    handleSubmit() {
      const data = {
        id: this.state.selectedsite,
      }
      if(this.state.selectedtype.value==2) {
       datasave.service(window.GET_NO_OF_LINKED_SITES, 'POST', data)
        .then(response => {
          this.setState({
            no_of_sites: response['no_of_sites'][0]['no_of_sites'],
            sitecount : response['sitecount'],
          })
          let remainingcount = response['no_of_sites'][0]['no_of_sites']-response['sitecount'];
          if (remainingcount>=1) {
            this.switchToOrganistion();
          }

        })
      }
      else{
        let sourceorg=this.state.activeorganisationsdata.filter((menu)=>menu.name==this.props.orgname);
        let destinationorg = this.state.activeorganisationsdata.filter((menu)=>menu.id==this.state.selectedorg);
        console.log(this.props.orgname);
        console.log(destinationorg[0]['id']);
        console.log(sourceorg[0]['id']);
        console.log(this.state.selectedorg);
        console.log(this.state.activeorganisationsdata);
        if(destinationorg[0]['id']==sourceorg[0]['id']) {
          console.log("same");
          this.switchToOrganistion(0);
        }
        else{
          console.log("different");
          console.log(destinationorg[0]['no_of_sites']);
          console.log(destinationorg[0]['site'].length);
          let remainingcount = destinationorg[0]['no_of_sites']-destinationorg[0]['site'].length;
          console.log(remainingcount);
          if (remainingcount>=1) {
            this.switchToOrganistion(1);
          }
          else {
            OCAlert.alertWarning(this.state.t('Number of sites are exceeded under this organisation, please contact the admin!'), { timeOut: window.TIMEOUTNOTIFICATION1});
          }
        }
      }
        this.cancelPopup();

    }
    switchToOrganistion (selectedorgtype) {
      console.log(this.props.switchingid);
      const data= {
        source_id : this.props.switchingid,
        sitestatus : 2,
        selectedtype :this.state.selectedtype.value,
        destination_id : this.state.selectedsite,
        selectedorgtype : selectedorgtype,
        selectedorg : this.state.selectedorg,
      }
      datasave.service(window.ORGANISATION_SWITCHING,'POST',data)
      .then(response => {
        if(response=='Sucess'){
          window.location.reload();
        }

      })
    }


    handleCancel(e) {
        this.cancelPopup();
    }
    handleChangeType(e) {
      this.setState({
        selectedtype : e,
        totalsites : this.props.site.filter((menu) =>menu.id!==this.props.switchingid),
      })

    }
    cancelPopup() {
        this.setState({ showpopup: false, eventcancel: true });
        this.props.changeStatus(false)
    }
    showPopup() {
        this.setState({ showpopup: true });
    }
    componentDidMount () {
      console.log(this.props.switchingid);
      this.setState({
        showpopup : this.props.status,
        switchingid : this.props.switchingid
      })
      var org = window.ORGANISATIONS;
      datasave.service(org, 'GET')
        .then(response => {
          console.log(response);
          this.setState({
            activeorganisationsdata: response,
          })
        })
    }




      render() {
        const { t,selectedtype,sitetypes,totalsites } = this.state;
        return (
            <reactbootstrap.Modal show={this.state.showpopup} onHide={this.cancelPopup}  aria-labelledby="example-custom-modal-styling-title" size='xl'>
                <reactbootstrap.Modal.Header closeButton  style={{height: "750px"}}>
                  <reactbootstrap.Modal.Title id="contained-modal-title-vcenter" />
                      <reactbootstrap.Modal.Body col-md-12 pr-0>
                      <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{'Select types'}:</InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <div className="input_sw">
                                <MultiSelect
                                  options={sitetypes}
                                  // disabled={details.disableFields}
                                  standards={selectedtype}
                                  handleChange={this.handleChangeType}
                                  isMulti = {false}

                                />
                              </div>
                            </div>
                          </InputGroup>
                        </div>
                      </FormGroup>
                         {selectedtype!='' && selectedtype.value == 2&&
                         <FormGroup>
                           <div className=" row input-overall-sec ">
                             <InputGroup className="">
                               <div className="col-md-4">
                                 <InputGroup.Prepend>
                                   <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{'Select parentsite'}:</InputGroup>
                                 </InputGroup.Prepend>
                               </div>
                               <div class="col-md-8 input-padd">
                                 <div className="input_sw">
                                 <Form.Control as="select" name="legal_form"
                                   className="input_sw"
                                   value={this.state.selectedsite}
                                   onChange={e => this.setState({ selectedsite: e.target.value})} >
                                   <option>{'Select'}</option>
                                  {this.state.totalsites.map((legal) => {
                                  return (<option id={legal.id} value={legal.id}>{legal.name}</option>)
                                  }
                                  )}
                                 </Form.Control>
                                 </div>
                               </div>
                             </InputGroup>
                           </div>
                         </FormGroup>
                       }
                        {selectedtype!='' && selectedtype.value == 1&&
                        <FormGroup>
                        <div className=" row input-overall-sec ">
                          <InputGroup className="">
                            <div className="col-md-4">
                              <InputGroup.Prepend>
                                <InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{'Select parentsite'}:</InputGroup>
                              </InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                              <div className="input_sw">
                              <Form.Control as="select" name="legal_form"
                                className="input_sw"
                                value={this.state.selectedorg}
                                onChange={e => this.setState({ selectedorg: e.target.value})} >
                                <option>{'Select'}</option>
                               {this.state.activeorganisationsdata.map((legal) => {
                               return (<option id={legal.id} value={legal.id}>{legal.name}</option>)
                               }
                               )}
                              </Form.Control>
                              </div>
                            </div>
                          </InputGroup>
                        </div>
                      </FormGroup>
                      }
                      </reactbootstrap.Modal.Body>
                    </reactbootstrap.Modal.Header >
                    <reactbootstrap.Modal.Footer>
                      <reactbootstrap.Button onClick={() => this.handleSubmit()}>{'Save'}</reactbootstrap.Button>
                        <reactbootstrap.Button onClick={() => this.handleCancel()}>{'Close'}</reactbootstrap.Button>
                    </reactbootstrap.Modal.Footer>
            </reactbootstrap.Modal>
        );
    }
}
export default translate(Siteswitching)
