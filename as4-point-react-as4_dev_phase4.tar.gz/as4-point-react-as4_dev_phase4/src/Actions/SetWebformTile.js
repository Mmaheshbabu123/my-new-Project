const SetWebformTile = (payload) => {
    return {
      type: payload.type,
      value: payload.value,
    }}
  export default SetWebformTile;
