const SetNavigationTile = (payload) => {
    console.log('payload');
    console.log(payload);
    let value = payload.value;
    return {
      type: payload.type,
      value: value,
    }}
  export default SetNavigationTile;
