const SetTileoptions = (payload) => {
  let valuetype = payload.value;
  return {
    type: "Tileoptions",
    value: payload,
  }}
export default SetTileoptions;
