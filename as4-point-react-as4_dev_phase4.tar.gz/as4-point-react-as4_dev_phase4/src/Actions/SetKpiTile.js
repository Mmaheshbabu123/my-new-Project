const SetKpiTile = (payload) => {
    return {
      type: payload.type,
      value: payload.value,
    }}
  export default SetKpiTile;
