const SetLang = (payload) => {
  return {
    type: "SetLang",
    payload
  }}
export default SetLang;
