const SetKpiTodoTile = (payload) => {
    return {
      type: payload.type,
      value: payload.value,
    }}
  export default SetKpiTodoTile;
