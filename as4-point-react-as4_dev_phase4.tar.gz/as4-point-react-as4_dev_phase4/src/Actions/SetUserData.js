const SetUserData = (payload) => {
    return {
      type: "UserData",
      payload
    }}
export default SetUserData;