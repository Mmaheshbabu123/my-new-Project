const SetKpiDashboardTile = (payload) => {
  return {
    type: payload.type,
    value: payload.value,
  }}
export default SetKpiDashboardTile;
