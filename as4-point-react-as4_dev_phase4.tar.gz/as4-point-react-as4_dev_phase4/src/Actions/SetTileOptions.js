const SetTileOptions = (payload) => {
    let value = payload.value;
    return {
      type: payload.type,
      value
    }}
export default SetTileOptions;