const SetWebformData = (payload) => {
    let value = payload.value;
    return {
      type: payload.type,
      value: payload,
    }}
  export default SetWebformData;
