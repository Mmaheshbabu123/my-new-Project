const SetTodoItemTile = (payload) => {
    let value = payload.value;
    return {
      type: payload.type,
      value: value,
    }}
  export default SetTodoItemTile;
