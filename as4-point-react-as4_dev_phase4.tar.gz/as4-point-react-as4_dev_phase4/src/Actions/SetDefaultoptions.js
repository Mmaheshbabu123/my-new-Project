const SetDefaultoptions = (payload) => {
  let valuetype = payload.value;
  return {
    type: "defaultOptions",
    value: payload,
  }}
export default SetDefaultoptions;
