const SetTocTile = (payload) => {
    let value = payload.value;
    return {
      type: payload.type,
      value: value,
    }}
  export default SetTocTile;
