const SetBlockBoxTile = (payload) => {
    return {
      type: payload.type,
      value: payload.value,
    }}
  export default SetBlockBoxTile;
