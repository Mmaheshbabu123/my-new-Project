import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from './_services/db_services';
import { persistor, store } from '../src/store';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import { Editors, Data, Filters } from "react-data-grid-addons";
// import Toolbar from './Toolbar';
import Pagination from 'react-bootstrap/Pagination'
import ReactDataGrid from "react-data-grid-defaultvalue";
const getRows = (rows, selectedPage, pageDivBy) =>{
	  let start = (parseInt(selectedPage) - 1) * parseInt(pageDivBy)
	  let end = parseInt(selectedPage) * parseInt(pageDivBy);
          return rows.filter((key, index)=>{  return index >= start && index < end });
	}
class PracticeFile_v1 extends Component {
     grid = {};
	constructor(props) {
    super(props);
    this.state = {
      selectedPage: 1,
      pageDivBy : 5,
      columns : [{ key: 'id', name: 'ID' },
  { key: 'title', name: 'Title' },
  { key: 'count', name: 'Count' } ],
     rows: [{id: 0, title: 'row1', count: 20}, 
	     {id: 1, title: 'row2', count: 40}, 
	     {id: 2, title: 'row3', count: 60},
             {id: 3, title: 'row4', count: 80}, 
	     {id: 4, title: 'row5', count: 100}, 
	     {id: 5, title: 'row6', count: 120},
             {id: 6, title: 'row7', count: 140}, 
	     {id: 7, title: 'row8', count: 160}, 
	     {id: 8, title: 'row9', count: 180},
             {id: 9, title: 'row10', count: 200}, 
	     {id: 10, title: 'row11', count: 220}, 
	     {id: 11, title: 'row12', count: 240},
	     {id: 12, title: 'row13', count: 260}, 
	     {id: 13, title: 'row14', count: 280}, 
	     {id: 14, title: 'row15', count: 300}, 
	     {id: 15, title: 'row16', count: 320}, 
	     {id: 16, title: 'row17', count: 340},
	     {id: 17, title: 'row18', count: 360}, 
	     {id: 18, title: 'row19', count: 380}]
  }
	  this.rowGetterFunc = this.rowGetterFunc.bind(this);
  }

  paginate = (number) =>{
   this.setState({selectedPage: number}); 
  }

  samplePageFunc = () =>{
	  let table = [];
	  let total = this.state.rows.length;
	  let resultNumbers = [];
	  for(let i = 1 ; i <= Math.ceil(total/this.state.pageDivBy); i++){
	   resultNumbers.push(i);
	  }
          resultNumbers.map(number => {
            table.push(
                <Pagination.Item key={number} id={number} onClick={(e) => this.paginate(number)}>{number}</Pagination.Item>
            );
          })
	  return table;

  }

  rowGetterFunc = (i, filteredRows) =>{
      return filteredRows[i];  
    }
  render(){
	  console.log('state');
	  console.log(this.state);
	  const {columns, rows, selectedPage, pageDivBy} = this.state;
	  const filteredRows =  getRows(rows, selectedPage, pageDivBy);
    return (
    <div className = "container py-10">
                     <ReactDataGrid
	                ref={(grid) => { this.grid = grid; }}
                        columns={columns}
	                rowGetter = { i => this.rowGetterFunc(i, filteredRows)}
                        rowsCount={filteredRows.length}
                        minHeight={480}
                      />
        <div>
          <Pagination style={{ width: '900px', overflow: 'auto',scrollbarWidth: 'thin'}} size="md">
	    {this.samplePageFunc()}
	  </Pagination>
</div>
	    </div>);
  }
}
export default PracticeFile_v1;
