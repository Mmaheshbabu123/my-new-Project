import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import CheckBox from '../CheckBox';
import { translate } from '../language'
class BlockBoxGeneral extends Component {
    constructor(props) {
            super(props)
            this.state = {
             t: props.t,
	    }
    }
       getOption() {
        let table = [];
        if (this.props.webform_data.length > 0) {
            this.props.webform_data.map(key => {
                let value = key['id'];
                let label = key['code'] +' - '+ key['name'] +' - '+ key['version'];
                table.push(<option value={value}>{label}</option>)
            })
        }
        return table;
    }

    generateCheckBox(name, tick, value) {
        return <reactbootstrap.Form.Group>
            <CheckBox
                disabled={parseInt(this.props.reportView) === 1 ? true : false}
                name={name}
                tick={tick == 1 ? true : false}
                style={{ paddingLeft: '0px' }}
                onCheck={this.props.handleGeneralCheckBox}
                value={value}
            />
        </reactbootstrap.Form.Group>;
    }

        displayForm = () =>{
	      const { t } = this.state;
        let disabled = this.props.report_id !== undefined && parseInt(this.props.report_id) !== 0 ? true : false;
              return (
            <reactbootstrap.Form>
                <reactbootstrap.Form.Group className="col-md-12 row">
                <div className="col-md-2">
                    <reactbootstrap.Form.Label><span>{t('Name:')}</span><span style={{color:'red'}}>{'*'}</span> </reactbootstrap.Form.Label>
                </div>
                <div className="col-md-10 ">
                    <reactbootstrap.Form.Control className="input_sw" name={'name'} type={'text'} placeholder={'Name'} value={this.props.name} onChange={this.props.handleGeneralText} disabled={parseInt(this.props.reportView) === 1 ? true : false}></reactbootstrap.Form.Control>
                </div>
                </reactbootstrap.Form.Group>
               <div className="col-md-12">
                {this.generateCheckBox('Sort', this.props.sort, 'sort')}
                {this.generateCheckBox('Filter', this.props.filter, 'filter')}
                {this.generateCheckBox('Export', this.props.export, 'export')}
                </div>
                <reactbootstrap.Form.Group className="col-md-12 row">
                    <div className="col-md-2">
                       <reactbootstrap.Form.Label><span>{t('Webform:')}</span><span style={{color:'red'}}>{'*'}</span> </reactbootstrap.Form.Label>
                    </div>
                    <div className="col-md-10">
                    <reactbootstrap.Form.Control className="input_sw" as={"select"} name={'webform_id'} class="col-md-12 p-2" value={this.props.webform_id} onChange={this.props.handleGeneralSelect} disabled={false} >
                        {this.props.webform_id !== undefined && parseInt(this.props.webform_id) !== 0 ? '' : <option value={0}>{'------ Select -----'}</option>}
                        {this.getOption()}
                    </reactbootstrap.Form.Control>
                    </div>
                </reactbootstrap.Form.Group>
              <div className="col-md-12">
                {this.generateCheckBox('Available in fields screen', this.props.field_screen, 'field_screen')}
                </div>
            </reactbootstrap.Form>
        )
	}

	render() {
        return (
            <div className="container py-3 general-tab-webform">
                <div style={{border: '1px solid lightgray', borderRadius: '5px'}} className="col-md-12 p-5">
                {this.displayForm()}
		            </div>
            </div>
        )
    }

}
export default translate(BlockBoxGeneral);
