import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import CheckBox from '../CheckBox';
import BlockBoxGeneral from './BlockBoxGeneral.js';
import BlockBoxField from './BlockBoxField.js';

const arrangeIds = (id, targetId, idsArray) =>{
    id = parseInt(id);
    targetId = parseInt(targetId);
    let idIndex = idsArray.indexOf(id);
    let targetIdIndex = idsArray.indexOf(targetId);
    idsArray.splice(idIndex, 1);
        if(targetIdIndex !== 0){
          idsArray.splice(targetIdIndex, 0, id);
        }else{
          idsArray.unshift(id);
        }
      return idsArray;
  }

class CreateBlockBoxReportWindow extends Component {
    mainDrop = 0;
    constructor(props) {
            super(props)
            this.state = {
	    activeTab: 1,
	    name: '',
            sort: 0,
            filter: 0,
            export: 0,
	    webform_id: this.props.match.params.webform_id !== undefined ?
            parseInt( this.props.match.params.webform_id): 0,
            field_screen: 0,
            webform_data: [],
	    reportView: 0,
            reportEdit: 1,
	    status: false,
	    responseText:'...Loading',
	    general_change: 0,
            field_change: 0,
	    report_id: 0,
            selectedWebElementsIds: [],
	    selectedWebElementsData: [],
	    webelement_id: undefined,
            stepDetails: [],
	    searchText:''
	    }
    }


 handleWebElement(elementObj) {
        let id = elementObj['id'];
        let name = elementObj['name'];
        let alias = elementObj['alias'];
        let type = parseInt(elementObj['type']);
        let typename = elementObj['typename'];
        let list = elementObj['json_data'] !== undefined && elementObj['json_data'] !== "null" ? JSON.parse(elementObj['json_data'])['list'] : undefined;
        let elementIds = this.state.selectedWebElementsIds;
        let elementData = this.state.selectedWebElementsData;
        let newObj = {
            [id]: {
                id: id,
                name: name,
                custom_name: name,
                alias:alias,
                typename: typename,
                sorting: 0,
                sort_order: 0,
                default_filter: this.defaultValueSwitch(type),
                lock_filter: 0,
                width: 200,
                type: type,
                list: list !== undefined && list !== '' ? parseInt(list) : 0,

            }
        }
        elementIds.push(parseInt(id));
        elementData = { ...elementData, ...newObj };
        this.setState({ selectedWebElementsIds: elementIds, selectedWebElementsData: elementData, field_change: 1 });
    }

    removeIdFromSelected(id, elementIds) {
        let tempArr = [];
        if (elementIds !== '' && elementIds.length > 0) {
            tempArr = elementIds.filter(function (value, index, arr) {
                return value !== parseInt(id)
            })
            return tempArr;
        }
        return tempArr;
    }

    handleWebElementRemove(id) {
     let elementData = this.state.selectedWebElementsData;
     let elementIds = this.removeIdFromSelected(id, this.state.selectedWebElementsIds);
     delete elementData[id];
     this.setState({ selectedWebElementsIds: elementIds, selectedWebElementsData: elementData, field_change: 1});
    }

    handleFieldElementCheckBox(id, name, value) {
        let selectedWebElementsData = this.state.selectedWebElementsData;
        selectedWebElementsData[id][name] = parseInt(value);
        this.setState({ selectedWebElementsData: selectedWebElementsData, field_change: 1 });
    }


    handleFieldElementTextField(id, name, value) {
        let selectedWebElementsData = this.state.selectedWebElementsData;
        selectedWebElementsData[id][name] = value;
        this.setState({ selectedWebElementsData: selectedWebElementsData, field_change: 1 });
    }

    handleFieldElementNumberField(id, name, value) {
        let selectedWebElementsData = this.state.selectedWebElementsData;
        selectedWebElementsData[id][name] = value !== '' ? parseInt(value) : 0;
        this.setState({ selectedWebElementsData: selectedWebElementsData, field_change: 1 });
    }

    handleFieldElementDropDown(id, name, value) {
        let selectedWebElementsData = this.state.selectedWebElementsData;
        selectedWebElementsData[id][name] = value;
        this.setState({ selectedWebElementsData: selectedWebElementsData, field_change: 1 });
    }

    handleFieldMultiCheckBox(id, name, value, checked) {
        let selectedWebElementsData = this.state.selectedWebElementsData;
        if (checked) {
            selectedWebElementsData[id][name].push(value);
        } else {
            selectedWebElementsData[id][name].splice(selectedWebElementsData[id][name].indexOf(value), 1);
        }
        this.setState({ selectedWebElementsData: selectedWebElementsData, field_change: 1 })
    }
    onDragStart = (e, elementObj) =>{
    e.dataTransfer.setData("elementObj", JSON.stringify(elementObj));
    this.mainDrop = 1;
    }

    onDragEnd = (e) =>{
    }

    onDrop = (e) =>{
    if(parseInt(this.mainDrop) === 1){
      this.handleWebElement(JSON.parse(e.dataTransfer.getData("elementObj")));
      this.mainDrop = 0;
    }
    }

    allowDrop = (e) =>{
    e.preventDefault();
    if(parseInt(this.mainDrop) === 1){
      return true;
    }else{
      return false;
    }
    }

    dragStartOrder = (e) =>{
    e.dataTransfer.setData("orderElementId", e.currentTarget.id);
    e.dataTransfer.dropEffect = "move";
    }
    
    dragOverOrder = (e) =>{
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
    }

    onDropOrder = (e) =>{
    if(parseInt(this.mainDrop) === 0){
    let orderLabelId = e.dataTransfer.getData("orderElementId");
    this.setState({selectedWebElementsIds: arrangeIds(orderLabelId, e.currentTarget.id, this.state.selectedWebElementsIds)});
    }
    }

    handleSearchText = (value) =>{
    this.setState({searchText: value});
    }
     getFieldReport = () =>{
     if (this.state.activeTab == 2) {
     return <BlockBoxField
	     webform_id = {this.state.webform_id}
	     webElementsData={this.state.webElementsData}
	     childList={this.state.childList}
             handleWebElement={this.handleWebElement.bind(this)}
             selectedWebElementsIds={this.state.selectedWebElementsIds}
             selectedWebElementsData={this.state.selectedWebElementsData}
             handleWebElementRemove={(e) => this.handleWebElementRemove(e.target.id)}
             handleFieldElementCheckBox={(e) => this.handleFieldElementCheckBox(e.target.id, e.target.value, 
		     e.target.checked == true ? 1 : 0)}
             handleFieldElementTextField={(e) => this.handleFieldElementTextField(e.target.id, e.target.name, e.target.value)}
             handleFieldElementNumberField={(e) => this.handleFieldElementNumberField(e.target.id, e.target.name, e.target.value)}
             handleFieldElementDropDown={(e) => this.handleFieldElementDropDown(e.target.id, e.target.name, e.target.value)}
             handleFieldMultiCheckBox={this.handleFieldMultiCheckBox.bind(this)}
             reportView={this.state.reportView}
             onDragStart = {this.onDragStart.bind(this)}
             onDragEnd = {this.onDragEnd.bind(this)}
             onDrop = {this.onDrop.bind(this)}
             allowDrop = {this.allowDrop.bind(this)}
             dragStartOrder = {this.dragStartOrder.bind(this)}
             dragOverOrder = {this.dragOverOrder.bind(this)}
             onDropOrder = {this.onDropOrder.bind(this)}
	     stepDetails = {this.state.stepDetails}
             searchText = {this.state.searchText}
	     handleSearchText = {this.handleSearchText.bind(this)}
		     />
     }
     }

    handleGeneralCheckBox(name, value) {
        this.setState({ [name]: parseInt(value)});
    }

    handleGeneralText(name, value) {
        this.setState({ [name]: value });
    }

    handleGeneralSelect(name, value) {
        //this.getWebElements(name, parseInt(value), [], [], {}, 1);
    }
    
     getGeneralReport = () => {
        if (this.state.activeTab === 1) {
            return (
		    <BlockBoxGeneral
                    name={this.state.name}
                    sort={this.state.sort}
                    filter={this.state.filter}
                    export={this.state.export}
                    webform_id={this.state.webform_id}
                    field_screen={this.state.field_screen}
                    webform_data={this.state.webform_data}
                    handleGeneralCheckBox={(e) => this.handleGeneralCheckBox(e.target.value, e.target.checked == true ? 1 : 0)}
                    handleGeneralText={(e) => this.handleGeneralText(e.target.name, e.target.value)}
                    handleGeneralSelect={(e) => this.handleGeneralSelect(e.target.name, e.target.value)}
                    reportView={this.state.reportView}
                    report_id={this.state.report_id}
                />
            )
        }
    }
    
    handleTab = (name, value) =>{
    this.setState({[name]: parseInt(value)});
    }

    getTabs() {
      return (
      <reactbootstrap.Tabs activeKey={this.state.activeTab} id="uncontrolled-tab-example" onSelect={(k) => this.handleTab('activeTab', k)}>
         <reactbootstrap.Tab eventKey={1} title="General">
                </reactbootstrap.Tab>
                <reactbootstrap.Tab eventKey={2} title="Field">
                </reactbootstrap.Tab>
          </reactbootstrap.Tabs >
        )
    }
	
	getCreateReport() {
        return (
            <div>
                {this.getTabs()}
                <div>
                      {this.state.activeTab == 1 ? this.getGeneralReport() : this.getFieldReport()}
                </div>
            </div>
        );
       }

	render(){
	const {status, responseText} = this.state;
	return (<div className={'container py-10'}> 
		<div className="row">
		{!status && <div>{responseText}</div>}
		{status && <div className="col-md-12"> {this.getCreateReport()}</div>} 
                </div>
               </div>);
	}

  defaultValueSwitch(type) {
        switch (type) {
            case window.DATEFIELD: case window.START_DATE: case window.CREATE_DATE: case window.SAVE_DATE:
                return 0;
                break;
            case window.DONE: case window.DIGITAL_SIGNATURE:
                return 0;
                break;
            case window.My_FORM:
                return 0;
                break;
            case window.INTIATOR:
                return 0
                break;
            case window.NUMERICFIELD: case window.ATTACHMENTS:
                return 0;
                break;
            case window.TEXTFIELD: case window.DECIMALFIELD: case window.TIMER: case window.FORMNUMBER: case window.LIST_ORGANISATIONAL_UNITS: case window.CURRENT_STEP:
                return '';
                break;
            case window.LIST: case window.RADIO_BUTTON:
                return 0;
                break;
            case window.CHECKBOX:
                return [];
                break;
            default:
                return 0;
                break;
          }
      }

    async intialSelectWebElements(data){
      let webElements = data;
      let selectedWebElementsData = {};
      let selectedWebElementsIds = [];
      selectedWebElementsIds = await webElements.map(key=>{
        let type = parseInt(key['type']);
        if(type === window.IDENTIFICATION_FIELDS || type === window.START_DATE
          || type === window.CURRENT_STEP || type === window.FORMNUMBER
          || type === window.INTIATOR){
            selectedWebElementsData[key['id']] = {
                  id: key['id'],
                  name: key['name'],
                  custom_name: key['custom_name'] !== undefined && key['custom_name'].length > 0 ? key['custom_name'] : key['name'],
                  typename: undefined,
                  sorting: 0,
                  sort_order: 0,
                  default_filter: this.defaultValueSwitch(key['type']),
                  lock_filter: 0,
                  width: 200,
                  type: key['type'],
                  list: 0,
                  change: 0,
              }
              return key['id'];
          } else{
            return 0;
          }
      })
      return {'selectedWebElementsIds': selectedWebElementsIds.filter(key=>{ return key !== 0 }), 
	      'selectedWebElementsData': selectedWebElementsData};
    }

    dynamicSort(property) {
    var sortOrder = 1;
    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a,b) {
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
    }

    async sortObjInAsc(data){
      return data;
      return  await  data.sort(this.dynamicSort("name"));
    }
  
    async getParentFromElement(webElementsData) {
        let parentIds = [];
        webElementsData.map(key => {
            let type = parseInt(key['type']);
            if (window.LIST === type || window.RADIO_BUTTON === type || window.CHECKBOX === type) {
                let list = (key['json_data'] !== undefined && key['json_data'] !== 'null') ? JSON.parse(key['json_data'])['list'] : undefined;
                if (list !== undefined && list !== '') {
                    parentIds.push(parseInt(list));
                }
            }
        })
        return parentIds;
    }
      
    handleChildSetState(childList, stepDetails, webElementsData, name, value, selectedWebElementsIds, selectedWebElementsData, obj) {
        let newObj = {
            childList: childList,
            webElementsData: webElementsData,
            selectedWebElementsIds: selectedWebElementsIds,
            selectedWebElementsData: selectedWebElementsData,
            [name]: value,
            stepDetails: stepDetails,
        };
        let setStateObj = { ...newObj, ...obj };
        this.setState(setStateObj);
    }

      async  getAllChild(webElementsData, name, value, selectedWebElementsIds, selectedWebElementsData, obj) {
        let parentIds = await this.getParentFromElement(webElementsData);
            datasave.service(window.GET_ALL_CHILD, 'POST', { parentIds: parentIds, webform_id : this.props.match.params.webform_id !== undefined ? parseInt(this.props.match.params.webform_id): 0 }).then(
                async response => {
                    if (response['status'] == 200) {
                        this.handleChildSetState(response['data']['childList'], response['data']['stepDetails'], webElementsData, name, value, selectedWebElementsIds, selectedWebElementsData, obj)
                    } else {
                        OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
                        this.handleChildSetState([], [], webElementsData, name, value, selectedWebElementsIds, selectedWebElementsData, obj)
                    }
                });
    }

      async getWebElements(name, value, selectedWebElementsIds, selectedWebElementsData, obj, newReport) {
        await  datasave.service(window.FETCH_ALL_WEBELEMENTS + '?webform_id=' + value, 'POST').then(
            async response => {
                if (response['status'] == 200) {
                    let webElementsData = response['data'] !== '' && response['data'].length > 0 ?
                    await this.sortObjInAsc(response['data'].concat(window.ADDITIONAL_ENTITIES)) : await this.sortObjInAsc(window.ADDITIONAL_ENTITIES);
                    if(newReport === 1){
                      let selectWebElements = await this.intialSelectWebElements(webElementsData);
                            this.getAllChild(webElementsData, name, value, selectWebElements['selectedWebElementsIds'], selectWebElements['selectedWebElementsData'], obj);
                    } else{
                      this.getAllChild(webElementsData, name, value, selectedWebElementsIds, selectedWebElementsData, obj);
                    }
                } else {
                    OCAlert.alertError(response['Msg'], { timeOut: window.TIMEOUTNOTIFICATION });
                }
            });
      }

        componentDidMount() {
        var webform = window.GET_ALL_WEBFORMS + '/' + window.ACTIVE_WEBFORM;
        datasave.service(webform, "GET")
            .then(async response => {
              if(response['status'] == 200){
              let setObj = {activeTab: 1, general_change: 0,
                   field_change: 0, status: true, responseText:''};
               if (this.state.report_id !== undefined && parseInt(this.state.report_id) !== 0) {
               
	       }else{
	          setObj['webform_data'] = response['data'];
                  setObj['status'] =  true;
                  setObj['name'] =  '';
                  setObj['sort'] = 0;
                  setObj['filter'] = 0;
                  setObj['export'] = 0;
                  setObj['field_screen'] = 0;
                  this.getWebElements('webform_id', this.state.webform_id, [], [], setObj, 1);
	       }

	      }else{
	      this.setState({responseText: 'Error please try again'});
	      }
	    })
       }
}
export default CreateBlockBoxReportWindow;
