import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { datasave } from '../_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';
import CheckBox from '../CheckBox';
import WebFormViewComponent from '../Webforms/WebFormViewComponent';
class BlockBoxField extends Component {
    constructor(props) {
            super(props)
            this.state = {
            t: props.t,
            webElementsData:[],
	    }
    }
    getSelectedWebElements() {
        let table = [];
        let data = (this.props.selectedWebElementsData === undefined) ? '' : this.props.selectedWebElementsData;
        let ids = (this.props.selectedWebElementsIds === undefined) ? '' : this.props.selectedWebElementsIds;
        //console.log(ids,data,this.props.handleFieldElementDropDown,this.props.handleWebElementRemove);

        if (ids.length > 0) {
            ids.map(key => {
                let type = data[key]['typename'] !== undefined ? '(' + data[key]['typename'] + ')' : '';
                let name = data[key]['name'];
                table.push(
                    <tr id = {key} draggable="true" onDrop = {(e)=>{this.props.onDropOrder(e, 0)}} onDragOver= {(e)=>this.props.dragOverOrder(e)}  onDragStart={(e)=>this.props.dragStartOrder(e)}>
                        <td style= {{'white-space': 'normal','word-break': 'break-all'}}>{this.getTextField(data[key], 'custom_name', key, this.props.handleFieldElementTextField)}</td>
                        {<td style= {{'white-space': 'normal','word-break': 'break-all'}}>{this.getNumberField(data[key], 'width', key, this.props.handleFieldElementNumberField)}</td>}
                        <td style= {{'white-space': 'normal', 'word-break': 'break-all'}}>{name + type}</td>
                        <td style= {{'white-space': 'normal', 'word-break': 'break-all'}} className="sorting-filter">{this.getSortingDropDown(data[key], 'sorting', key, this.props.handleFieldElementDropDown)}</td>
                        {/*this.props.customReport === 0 ? <td style= {{'white-space': 'normal', 'word-break': 'break-all'}}>{this.getNumberField(data[key], 'sort_order', key, this.props.handleFieldElementNumberField)}</td> : '' */}

                        <td style= {{'white-space': 'normal', 'word-break': 'break-all'}}>{this.getDefaultFilter(data[key], 'default_filter', key)}</td>
                        <td style= {{'white-space': 'normal', 'word-break': 'break-all'}} className="lock-filter">{this.getCheckBox(data[key], 'lock_filter', key, this.props.handleFieldElementCheckBox)}</td>
                        <td style= {{'white-space': 'normal', 'word-break': 'break-all'}}><reactbootstrap.Button> <i id={key} onClick={this.props.handleWebElementRemove} disabled={parseInt(this.props.reportView) === 1 ? true : false} class="overall-sprite overall-sprite-mtdeletec"></i></reactbootstrap.Button></td>
                    </tr>
                );
            })
        }
        return table;
    }

    getSortingDropDown(dataObj, name, id, dropDownMethod) {
        return (
            <reactbootstrap.Form.Control as={'select'} id={id} name={name} value={dataObj[name]} onChange={dropDownMethod} disabled={parseInt(this.props.reportView) === 1 ? true : false}>
                // <option value={0}>None</option>
                // <option value={1}>Ascending</option>
                // <option value={2}>Descending</option>
                {window.SORT_ORDER.map=(key)=>{
                  return (<option value={key['value']}>{key['name']}</option>)
                }}

            </reactbootstrap.Form.Control>
        )
    }

    getTextField(dataObj, name, id, textMethod) {
        let value = dataObj[name] !== undefined && dataObj[name] != null ? dataObj[name] : ''
        return (
            <reactbootstrap.Form.Group>
                <reactbootstrap.Form.Control id={id} name={name} type={'text'} placeholder={''} value={value} onChange={textMethod} disabled={parseInt(this.props.reportView) === 1 ? true : false}
                ></reactbootstrap.Form.Control>
            </reactbootstrap.Form.Group>
        )
    }

    getNumberField(dataObj, name, id, numberMethod) {
        let value = dataObj[name] !== undefined && dataObj[name] != null ? dataObj[name] : 0;
        return (
            <reactbootstrap.Form.Group>
                <reactbootstrap.Form.Control id={id} name={name} type={'text'} placeholder={''} value={value} onChange={numberMethod} disabled={parseInt(this.props.reportView) === 1 ? true : false}
                ></reactbootstrap.Form.Control>
            </reactbootstrap.Form.Group>
        )
    }

    getCheckBox(dataObj, name, id, checkBoxMethod) {
        return (<reactbootstrap.Form.Group>
            <CheckBox
                disabled={parseInt(this.props.reportView) === 1 ? true : false}
                id={id}
                tick={dataObj[name] == 1 ? true : false}
                style={{ paddingLeft: '0px' }}
                onCheck={checkBoxMethod}
                value={name}
            />
        </reactbootstrap.Form.Group>);
    }

    getDefaultFilter(dataObj, name, id) {

        let type = parseInt(dataObj['type']);
        let optionData = dataObj['list'] !== 0 ? this.props.childList[dataObj['list']] : [];
        switch (type) {
            case window.DATEFIELD: case window.START_DATE: case window.CREATE_DATE: case window.SAVE_DATE:
                return (<reactbootstrap.Form.Control id={id} name={name} as={'select'} value={dataObj[name]} onChange={this.props.handleFieldElementDropDown} disabled={parseInt(this.props.reportView) === 1 ? true : false}>
                    {this.getOptions(window.DATE_DEFAULT_FILTER_OPTION, 'label','value', 0)}
                </reactbootstrap.Form.Control>);
                break;
            case window.DONE: case window.DIGITAL_SIGNATURE:
                return (
                    <reactbootstrap.Form.Control id={id} name={name} as={'select'} value={dataObj[name]} onChange={this.props.handleFieldElementDropDown} disabled={parseInt(this.props.reportView) === 1 ? true : false}>
                        {this.getOptions(window.ALL_YES_NO,'name', 'value', 0)}
                    </reactbootstrap.Form.Control>);
                break;
            case window.My_FORM:
                return (
                    <reactbootstrap.Form.Control id={id} name={name} as={'select'} value={dataObj[name]} onChange={this.props.handleFieldElementDropDown} disabled={parseInt(this.props.reportView) === 1 ? true : false}>
                        {this.getOptions(window.FORM_OPTIONS,'name', 'value', 0)}
                    </reactbootstrap.Form.Control>);
                break;
case window.INTIATOR:
                return (
                    <reactbootstrap.Form.Control id={id} name={name} as={'select'} value={dataObj[name]} onChange={this.props.handleFieldElementDropDown} disabled={parseInt(this.props.reportView) === 1 ? true : false}>
                        {this.getOptions(window.INTIATOR_OPTIONS,'name', 'value', 0)}
                    </reactbootstrap.Form.Control>);
                break;
            case window.NUMERICFIELD: case window.ATTACHMENTS:
                return this.getNumberField(dataObj, name, id, this.props.handleFieldElementNumberField);
                break;
            case window.TEXTFIELD: case window.DECIMALFIELD: case window.TIMER: case window.FORMNUMBER: case window.LIST_ORGANISATIONAL_UNITS:
                return this.getTextField(dataObj, name, id, this.props.handleFieldElementTextField);
                break;
            case window.LIST: case window.RADIO_BUTTON:
                return (
                    <reactbootstrap.Form.Control id={id} name={name} as={'select'} value={dataObj[name]} onChange={this.props.handleFieldElementDropDown} disabled={parseInt(this.props.reportView) === 1 ? true : false}>
                        {this.getOptions(optionData,'name', 'id', 1)}
                    </reactbootstrap.Form.Control>);
                break;
            case window.CURRENT_STEP:
                return (
                    <reactbootstrap.Form.Control id={id} name={name} as={'select'} value={dataObj[name]} onChange={this.props.handleFieldElementDropDown} disabled={parseInt(this.props.reportView) === 1 ? true : false}>
                        {this.getOptions(this.props.stepDetails, 'label', 'value', 1)}
                    </reactbootstrap.Form.Control>);
                break;
            case window.CHECKBOX:
                return (
                    <reactbootstrap.Dropdown>
                        <reactbootstrap.Dropdown.Toggle variant="Primary" id="dropdown-basic" size="sm">
                            Customize
                        </reactbootstrap.Dropdown.Toggle>
                        <reactbootstrap.Dropdown.Menu>
                            <ul>
                                {this.getCheckBoxOptions(optionData, dataObj, id, name)}
                            </ul>
                        </reactbootstrap.Dropdown.Menu>
                    </reactbootstrap.Dropdown>
                );
                break;
        }

    }


    getOptions(data,nameName, valueName, needSelect) {
        let table = needSelect === 1 ? [<option value = {0}>{'------ select ------'}</option>] : [];
        if (data != '' && data.length > 0) {
            data.map(key => {
                table.push(<option value={key[valueName]}>{key[nameName]}</option>);
            })
        }
        return table;
    }
    getCheckBoxOptions(optionData, dataObj, id, name) {
        let table = [];
        if (optionData !== '' && optionData.length > 0) {
            optionData.map(key => {
                table.push(
                    <li style={{ listStyleType: 'none' }}>
                        <CheckBox
                            disabled={parseInt(this.props.reportView) === 1 ? true : false}
                            id={id}
                            tick={dataObj[name].indexOf(parseInt(key['id'])) !== -1 ? true : false}
                            style={{ paddingLeft: '0px' }}
                            onCheck={(e) => this.handleMultiCheckBox(id, name, key['id'], e.target.checked)}
                            value={key['id']}
                            name={key['name']}
                        />
                        {/* <CheckBox type="checkbox" id={id} value={dataObj['value']} name={key['name']} /> */}
                    </li>
                );
            });
        }
        return table;

    }
    handleMultiCheckBox(id, name, value, checked) {
        this.props.handleFieldMultiCheckBox(id, name, value, checked);
    }

  getSelectedElementDetailsTable = () =>{
    return (<reactbootstrap.Table className="table-bordered fields-table">
              <thead>
                <tr>
                 <td>{'Custom name'}</td>
                 <td>Width</td>
                 <td className="table-column2 table-icons name">Name</td>
                 <td className="table-column3 table-icons sorting">Sorting</td>
                 <td>Default filter</td>
                 <td className="table-column6 table-icons lock">Lock filter</td>
                 <td className="table-column7 table-icons delete">Delete</td>
                 </tr>
                 </thead>
                 <tbody >
	         {this.getSelectedWebElements()}
                 </tbody>
                 </reactbootstrap.Table>);

  }

render() {
        return (
            <div >
                <div class='row'>
                    <div class='col-md-10 pr-0'  droppable='true'  onDragOver={(e)=>this.props.allowDrop(e)} onDrop={(e)=>this.props.onDrop(e)}>
                      {this.getSelectedElementDetailsTable()}
                    </div>
                    <div class='col-md-2 column-width'>
                        <WebFormViewComponent
                            label={'Available column'}
                            webElementsData={this.props.webElementsData}
                            handleWebElement={this.props.handleWebElement}
                            selectedWebElementsIds={this.props.selectedWebElementsIds}
                            onDragStart={this.props.onDragStart}
                            onDragEnd = {this.props.onDragEnd}
                            disabled={parseInt(this.props.reportView) === 1 ? true : false}
                            searchText = {this.props.searchText}
                            handleSearchText = {this.props.handleSearchText}/>
                    </div>
                </div>
            </div>
        )
    }
}
export default BlockBoxField;

