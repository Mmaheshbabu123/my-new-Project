import React, { Component } from 'react';
import * as reactbootstrap from 'react-bootstrap';
// import axios from 'axios';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import { datasave } from './_services/db_services';
import { existsTypeAnnotation } from '@babel/types';
import {translate} from './language';
import { persistor, store } from './store';
import AccessDeniedPage from "./_components/Errorpages/AccessDenied";


const base64 = require('base-64');

class Useronetimelogin extends Component {
  constructor(props) {
    super(props)
    this.state = {
      token: '',
      email: '',
      password: '',
      confirmpassword: '',
      showError: '',
      submit: false,
      t:props.t,
      newpasswordError : '',
      confirmPasswordError : '',
      accessDenined: false,
      statusError: null
    }

    this.handleChange = this.handleChange.bind(this);

  }

   componentDidMount() {
    let urlArray = window.location.href.split('/');
    let tokenOfUrlPosition = urlArray.length;
    let token = urlArray[tokenOfUrlPosition-2];

    let URL = window.ONETIMELOGINRESTRICTION + '/' + token;
     datasave.service(URL, 'GET')
    .then(response => {
      if (response.status === 200) {
        if((response.data.pStatus === 0) && (response.data.uStatus === 0)) {
          this.setState({
            accessDenined: false,
          })
        } else {
          window.open(window.location.origin + '/loginscreen', '_self');
          // this.setState({
          //   accessDenined: true,
          // })
        }
      } else {
        this.setState({
          statusError: 201,
        })
      }
    })

    localStorage.removeItem('user');
  }
  componentWillMount() {
    localStorage.removeItem('user');
    // let path = window.location.search.split('?');
    // let visited = path[1];
    // if (visited === undefined) {
    //   window.location = window.location.pathname + '?added';
    // }
  }
  handleChange(event) {
    const {name, value} = event.target;
    const { t } = this.state;
    let pwdError = t('Password should be minimum length of 10 characters, atleast one upper case, one special character (#, ?, !, @, $, %, ^, &, *, -) and one numeric')
    let pwd = event.target.value;

    let newpasswordTest = true;
    let confirmpasswordTest = true;
    if(name === 'password') {
      if (event.target.value.length === pwd.trim().length) {
        const reg = new RegExp("^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{10,}$");
        newpasswordTest = reg.test(event.target.value);
      } else {
        this.setState({
          newpasswordError:t('Space is not allowed'),
        })
        return false;
      }

      if(event.target.value.match(/\s/g)) {
          newpasswordTest = false;
      }
    }
    if(name === 'confirmpassword') {
      if (event.target.value.length === pwd.trim().length) {
        const reg = new RegExp("^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{10,}$");
        confirmpasswordTest = reg.test(event.target.value);
      } else {
        this.setState({
          confirmPasswordError: t('Space is not allowed'),
        })
        return false;
      }

      // if(event.target.value.match(/\s/g)) {
      //     confirmpasswordTest = false;
      // }
    }

    this.setState({
      [name]: value,
      showError : '',
      submit : false,
      newpasswordError :  newpasswordTest ? '' : pwdError,
      confirmPasswordError : confirmpasswordTest ? '' : pwdError,
    });

  };

  handleSave() {
    const {t} = this.state;
    const { history } = this.props
    const url = window.location.href;
    const data = url.split('/');
    const details = {
      token: data[4],
      id: base64.decode(data[5]),
      password: this.state.password
    }

    this.setState({
      submit : true
    })

    if (this.state.password != '' && this.state.confirmpassword != '' && this.state.newpasswordError === '' && this.state.confirmPasswordError === '') {
        if (this.state.password == this.state.confirmpassword) {
          const url = window.ONE_TIME_LOGIN;
          datasave.service(url, 'PUT', details)
            .then(response => {
              if (response == 'Mail has been sent') {
                window.open(window.location.origin + '/loginscreen', '_self');
              }
              else if (response == 'mail not sent') {
                this.setState({
                  showError: response,
                })
              }
              else if (response == 'Unauthorised user') {
                this.setState({
                  showError: response,
                })
              }
            })
        }
        else {
          this.setState({
            showError: t('password not matched'),
          })
        }
    }
  }

  handleKeyPress = event => {
    if (event.key == 'Enter') {
      this.handleSave();
    }
  }

  render() {
    const { showError, t, newpasswordError, confirmPasswordError, accessDenined, statusError} = this.state

    if (!accessDenined) {
      return (
        <div className="container"  onKeyPress={e => this.handleKeyPress(e)}>
          <div className="row justify-content-center">
            <div className="col-md-8 mt-5">
              <div className="card">
                <div style={{textAlign: 'center'}} className="card-header">{t("Set password")}</div>
                  <span style={{margin:'10px'}}> **{t('This link is available till user activates account')}</span>
                <Container className="p-5">
                    <reactbootstrap.FormGroup>
                      <div class="col-md-12 row">
                          <div className="col-md-4">
                      <Label>{t('Password:')}<span style={{ color: 'red' }}>  *</span></Label>
                    </div>
                      <div className="col-md-8">
                      <Input
                        id="password"
                        type="password"
                        name="password"
                        placeholder={t("Password")}
                        value={this.state.password}
                        onChange ={this.handleChange}
                        autoComplete="off"
                      />

                    {this.state.submit && this.state.password === '' &&
                      <p style={{ color: 'red' }} className="error-block">{t('Password field is required')}</p>
                    }
                    {newpasswordError &&
                      <div style={{ color: 'red' }} className="error-block  mt-2">{newpasswordError}</div>
                    }
                  </div>
                  </div>
                    </reactbootstrap.FormGroup>
                    <reactbootstrap.FormGroup>
                          <div class="col-md-12 row">
                            <div className="col-md-4">
                      <Label>{t('Confirm password:')}<span style={{ color: 'red' }}>  *</span></Label>
                    </div>
                    <div  className="col-md-8">
                      <Input
                        id="confirmpassword"
                        type="password"
                        name="confirmpassword"
                        placeholder={t("Confirm password")}
                        value={this.state.confirmpassword}
                        onChange ={this.handleChange}
                        autoComplete="off"
                      />

                    {this.state.submit && this.state.confirmpassword === '' &&
                      <p style={{ color: 'red'}} className="error-block">{t('Confirmpassword field is required')}</p>
                    }
                    {confirmPasswordError &&
                      <div style={{ color: 'red' }} className="error-block  mt-2">{confirmPasswordError}</div>
                    }
                  </div>
                </div>
                      </reactbootstrap.FormGroup>
                      <div style={{textAlign: 'right'}} className="col-md-12 pr-5">
                    <reactbootstrap.Button onClick={() => this.handleSave()}>{t('Save')}</reactbootstrap.Button>
                  </div>
                    </Container>
                  </div>
                </div>
              </div>
              <div>
                {showError === "Mail has been sent" && <div className={'alert alert-success'}>
                 <p>{t('Mail sent')}</p>
                </div>}
                {showError === "mail not sent" && <div style={{margin: '0px auto',textAlign: 'center'}} className={'alert alert-danger col-md-8 mt-5 mb-3'}><p>{t('Mail not sent')}</p></div>}
                {showError === "Unauthorised user" && <div style={{margin: '0px auto',textAlign: 'center'}} className={'alert alert-danger col-md-8 mt-5 mb-3'}><p>{t('Not an Authorised User')}</p></div>}
                {showError === "password not matched" && <div style={{margin: '0px auto',textAlign: 'center'}} className={'alert alert-danger col-md-8 mt-5 mb-3'}><p>{t(' Password doesn’t match')}</p></div>}
                {statusError === 201 && <div style={{margin: '0px auto',textAlign: 'center'}} className={'alert alert-danger col-md-8 mt-5 mb-3'}><p>{t('Something went wrong')}</p></div>}
              </div>
          </div>
      )
    } else {
      return (
        <AccessDeniedPage />
      )
    }

  }
}
export default translate(Useronetimelogin);
