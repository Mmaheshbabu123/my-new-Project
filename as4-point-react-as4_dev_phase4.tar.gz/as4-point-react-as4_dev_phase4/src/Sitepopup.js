import React, { Component } from 'react';
import axios from 'axios';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from './language';
import { datasave } from './_services/db_services';
import { OCAlert } from '@opuscapita/react-alerts';




class Sitepopup extends Component {
    constructor(props) {
        super(props)
        this.state = {
            save: 'Save',
            credentials: this.props.credentials,
            file: '',
            file_details: '',
            show_sitepopup: this.props.show_sitepopup,
            t: props.t,
            eventcancel: false,
            thruprops: true,
            hostname: process.env.REACT_APP_baseURL,
            protocol: window.location.protocol,
        }
        this.handleChangeFile = this.handleChangeFile.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.cancelPopup = this.cancelPopup.bind(this);
        this.showPopup = this.showPopup.bind(this);
    }
    handleChangeFile(e) {
        //    e.preventDefault(e);
        this.setState({
            file_details: e.target.value,
            file: e.target.files[0],
        })
    }
    componentDidMount(){
        console.log(this.props.show_sitepopup);
    }
    handleSubmit() {
        if (this.state.description!=null){

            const details = {
                status: this.props.status,
                hostname: this.state.hostname,
                protocol: window.location.protocol,
                description : this.state.description,
            }
            const data = {
              status: this.props.status,
              siteid: this.props.id,
              website : this.props.website,
              hostname:this.state.hostname,
              protocol:this.state.protocol,
              description : this.state.description,
            }
            if (this.props.name=== "organisation") {
              const organisationId = this.props.id;
              var url = window.ORGANISATION_ACTIVITIES + '/' + organisationId;
              datasave.service(url, 'PUT', details)
              // axios.put(process.env.REACT_APP_serverURL + `/api/organisations/manageactivites/${organisationId}`, details)
              .then(response => {
                  if (response === 'Sucess') {
                  window.location.reload()
                  }

              })
              .catch(error => {
                  this.setState({
                  error: error.response.errors
                  })
              })
            }
            else {
              console.log(data)
              const {t} = this.state;
              datasave.service(window.CHANGE_SITE_STATUS, 'POST', data)
                  .then(response => {
                      if (response == 'Success') {
                          window.location.reload()
                      }
                      else{
                          OCAlert.alertError(t('Your organisation ')+response[0]['website'] + t('is in inactive state'), { timeOut: window.TIMEOUTNOTIFICATION1});

                          // alert("Your organisation "+response[0]['website'] +" is in inactive state")
                      }
                  })
            }

            this.cancelPopup();

        }
        else {
            this.setState({
                name_error:"Description is required"
            })
        }

    }
    handleCancel(e) {
        this.cancelPopup();
    }
    cancelPopup() {
        if(this.props.status == 0 ){
            this.props.handleCancel(0);
        }
        else if(this.props.status == 1 ){
            this.props.handleCancel(1);
        }
        // this.setState({ showpopup: false, eventcancel: true });
    }
    showPopup() {
        this.setState({ showpopup: true });
    }

    componentDidUpdate(prevProps, prevState) {

    }
    render() {
        const { t, description, loading, updateImageUpload, use_existing_file_edit_img, memo_data, error, id } = this.state;
        return (
            <reactbootstrap.Modal show={this.state.show_sitepopup} onHide={this.cancelPopup}>
                <reactbootstrap.Modal.Header closeButton>
                    <reactbootstrap.Modal.Title>{t('Description')}</reactbootstrap.Modal.Title>
                </reactbootstrap.Modal.Header >
                <reactbootstrap.Container className="">
                    {/* <reactbootstrap.Form onSubmit={this.handleSubmit}> */}
                    <reactbootstrap.Modal.Body>
                    <reactbootstrap.FormGroup>
                        <div className=" row input-overall-sec ">
                        <div className="col-md-4">
                            <reactbootstrap.InputGroup.Prepend>
                            <reactbootstrap.InputGroup style={{ padding: '8px', color: '#EC661C' }} id="basic-addon1">{t('Description')}:<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                            </reactbootstrap.InputGroup.Prepend>
                            </div>
                            <div class="col-md-8 input-padd">
                            <reactbootstrap.FormControl
                            style={{ height: '100px' }}
                            as="textarea" rows="3"
                            placeholder={t('Description')}
                            value={this.state.description}
                            onChange={e => this.setState({ description: e.target.value })}
                            className="input_sw"
                            />
                        </div>
                        </div>
                    </reactbootstrap.FormGroup>
                    <p style={{ color: 'red' }}>{this.state.name_error}</p>
                    </reactbootstrap.Modal.Body>
                    <div style={{ color: 'red' }} className="error-block">{error}</div>
                    <reactbootstrap.Modal.Footer style={{borderTop: '0px'}}>
                        <reactbootstrap.Modal.Footer style={{borderTop: '0px'}}></reactbootstrap.Modal.Footer>
                        <div style={{ float: 'right' }} className="organisation_list">
                        {/* <reactbootstrap.Button className="btn btn-primary" type="button" color="primary" onClick={this.handleCancel} >{t('Cancel')}</reactbootstrap.Button> */}
                        <a onClick={this.handleCancel} > {t('Cancel')} </a>
                        {loading &&
                            <img alt='' src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                        }
                        &nbsp;&nbsp;&nbsp;
                        <reactbootstrap.Button type="submit" disabled={loading} onClick={this.handleSubmit} color="primary">{t('Save')}</reactbootstrap.Button>

                   </div>
                    </reactbootstrap.Modal.Footer>
                    {/* </reactbootstrap.Form> */}
                </reactbootstrap.Container>
            </reactbootstrap.Modal>
        );
    }
}
export default translate(Sitepopup)
