import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services'
import { translate } from '../language';

 class CreateDocumentReports extends Component {
   constructor(props) {
     super(props);
     this.state = {

     }
   }
  render(){
    const { t } = this.state;
    return(
      <h1>document report constructor</h1>
    );
  }
 }

 export default translate(CreateDocumentReports);
