import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
import { OCAlert } from '@opuscapita/react-alerts';
class GrafiekOpenTodos extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            GrafiekOpenChartData: [],
            fromDate: '',
            toDate: '',
            progressShow: 'Loading',
            dropDownValue: 1,
            textVal: 30,
            radioVal: 2,
            t: props.t,
            FilterData: [],
            multiOption: [],
            multiSelection: [],
            maxValue: 0,
        }
    }

    handleOnChange(event, name) {
        this.setState({
            [name]: event.target.value
        })

    }

    handleDropDown(e) {

        this.setState({
            dropDownValue: parseInt(e.target.value),
            textVal: 0
        })
    }

    handleRadioChange(e, name) {
        this.setState({
            [name]: e.target.value,
            fromDate: '',
            toDate: ''
        })
    }

    handleTextChange(e, name) {
        var d = new Date();
        var d2 = new Date();
        var currentDay = '' + d.getDate();
        var currentMonth = d.getMonth() + 1 + '';
        var currentYear = d.getFullYear();

        var toDate = [currentYear, currentMonth.length < 2 ? '0' + currentMonth : currentMonth, currentDay.length < 2 ? '0' + currentDay : currentDay].join('-');

        if (e.target.value != '' || e.target.value != 0) {
            switch (this.state.dropDownValue) {
                case 1:
                    var date = d2.getDate() - e.target.value;
                    d2.setDate(date);
                    break;
                case 2:
                    var month = d2.getMonth() - e.target.value;
                    d2.setMonth(month);
                    break;
                case 3:
                    var year = d2.getFullYear() - e.target.value;

                    d2.setFullYear(year);
                    break;
                default:
                    break;
            }
        }
        var d2Date = '' + d2.getDate();
        var d2Month = d2.getMonth() + 1 + '';

        this.setState({
            [name]: e.target.value,
            toDate: toDate,
            fromDate: [d2.getFullYear(), d2Month.length < 2 ? '0' + d2Month : d2Month, d2Date.length < 2 ? '0' + d2Date : d2Date].join('-')
        })
    }


    handleSubmit() {
        const { t } = this.state;
        if (this.state.fromDate != '' && this.state.toDate != '') {
            if (new Date(this.state.fromDate) <= new Date(this.state.toDate)) {
                this.handleService(this.state.fromDate, this.state.toDate);
            } else {
                OCAlert.alertWarning(t('Please enter valid date'), { timeOut: window.TIMEOUTNOTIFICATION });
            }
        } else {
            console.log('Error');
        }
    }
    handleService(fromDate, toDate, name, value) {
        const { t } = this.state;
        datasave.service(window.GRAFIEK_OPEN_TODOS + '/' + fromDate + '/' + toDate, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {
                    this.setState({
                        GrafiekOpenChartData: result['GrafiekOpenChartData'],
                        FilterData: result['GrafiekOpenChartData'],
                        multiOption: this.getMultiSelectNames(result['GrafiekOpenChartData']),
                        fromDate: fromDate,
                        toDate: toDate,
                        [name]: value,
                        maxValue: result['maxValue'],
                        status: true,

                    })
                } else {
                    this.setState({
                        status: true,
                        progressShow: t('No Data')
                    })
                }
            })
    }


    getMultiSelectNames(data) {
        var length = data.length;
        var resultName = [];
        if (length > 1) {
            for (var i = 1; i < length; i++) {
                resultName.push({ label: data[i][0], value: data[i][0] })
            }
        }
        return resultName;
    }

    displayChart() {
        var table = [];
        var tempArr = [];
        var GrafieData = this.state.FilterData;
        if (GrafieData.length > 0) {
            if (GrafieData.length > 4) {
                tempArr.push(GrafieData[0]);
                for (var i = 0; i < GrafieData.length - 1; i++) {
                    tempArr.push(GrafieData[i + 1]);
                    if ((i + 1) % 3 == 0) {
                        table.push(this.getChart(tempArr));
                        tempArr = [GrafieData[0]]
                    }
                }
                if ((GrafieData.length - 1) % 3 != 0) {
                    var rem = parseInt((GrafieData.length - 1) % 3);
                    var startIndex = (GrafieData.length) - rem;
                    var remForScale = 3 - rem;
                    tempArr = [GrafieData[0]];
                    for (var j = startIndex; j < GrafieData.length + remForScale; j++) {
                        if (GrafieData[j] != undefined) {
                            tempArr.push(GrafieData[j]);
                        } else {
                            tempArr.push([' ', 0, 0, 0, 0, 0]);
                        }
                    }
                    table.push(this.getChart(tempArr));
                }
            } else {
                table.push(this.getChart(GrafieData));
            }
        }
        return table;

    }

    getChart(GrafiekOpenChartData) {
      const { maxValue ,t} = this.state;
        return (
            <div style={{ 'margin-top': '25px' }}>
                <Chart
                    chartType="Bar"
                    loader={<div>{t("Loading chart")}</div>}
                    data={GrafiekOpenChartData}
                    options={{
                        chart: {
                        },
                        width: '1045',
                        height: '210',
                        chartArea: {
                            height: "100%",
                            width: "100%",
                            left: 5,
                            top: 20
                        },
                        legend: {
                            maxLines: 1,
                            textStyle: {
                                fontSize: window.REPORT_FONT_SIZE
                            }
                        },
                        axes: {
                          y: {
                              all: {
                                  range: {
                                      max: maxValue,
                                      min: 0
                                  }
                              }
                          }
                      },
                    }}
                />
            </div>

        )
    }

    handleChangeMultiSelect(e) {
        var selectedData = e;
        var graphiekData = this.state.GrafiekOpenChartData;

        if (selectedData.length > 0) {
            var filterData = [graphiekData[0]];

            selectedData.map(key => {
                graphiekData.map(key1 => {
                    if (key1[0] == key['value']) {
                        filterData.push(key1)
                    }
                })
            })
            this.handleSetState('multiSelection', selectedData, 'FilterData', filterData);
        } else {
            this.handleSetState('multiSelection', e, 'FilterData', graphiekData);
        }
    }

    handleSetState(name1, value1, name2, value2) {
        this.setState({
            [name1]: value1,
            [name2]: value2
        })
    }

    render() {
        const { t } = this.state;
        return <div className="container p-5">
            <div className="mb-4"><h5>{t("To do's (person level)")}</h5></div>
            <div className="mb-3">
                <div>
                    <label style={{ display: 'inline-flex' }}>
                        <input type="radio" value={1} checked={(this.state.radioVal == 1) ? true : false} name="filter" label='a' onChange={(e) => this.handleRadioChange(e, 'radioVal')}></input>
                        {t('Sort by from date - to date')}
                    </label>
                </div>
                <div>
                    <label style={{ display: 'inline-flex' }}>
                        <input type="radio" value={2} checked={(this.state.radioVal == 2) ? true : false} name="filter" label='b' onChange={(e) => this.handleRadioChange(e, 'radioVal')}></input>
                        {t('Sort by number of days/months/years')}
                    </label>
                </div>
            </div>

            <div style={{ display: this.state.radioVal == 1 ? 'block' : 'none' }}>
                <label>
                    {t('From date')}
                    <input type="date" value={this.state.fromDate} onChange={(e) => { this.handleOnChange(e, 'fromDate') }}></input>
                </label>
                <label>
                    {t('To date')}
                    <input type="date" value={this.state.toDate} onChange={(e) => { this.handleOnChange(e, 'toDate') }}></input>
                </label>
                <reactbootstrap.Button onClick={(e) => this.handleSubmit()}>
                    {t('Submit')}
                </reactbootstrap.Button>
            </div>
            <div className="mb-3" style={{ display: this.state.radioVal == 2 ? 'block' : 'none' }}>

                <label className="mr-1" >

                    <input style={{ padding: '5px' }} className="input_sw" type={'text'} value={this.state.textVal} onChange={(e) => this.handleTextChange(e, 'textVal')} />

                </label>
                <select style={{ padding: '6px' }} className="input_sw mr-1" value={this.state.dropDownValue} onChange={(e) => this.handleDropDown(e)}>
                    <option value={1}>{t('Day')}</option>
                    <option value={2}>{t('Month')}</option>
                    <option value={3}>{t('Year')}</option>
                </select>
                <reactbootstrap.Button style={{ padding: '4px 10px' }} onClick={(e) => this.handleSubmit()}>
                    {t('Submit')}
                </reactbootstrap.Button>
            </div>
            <label>
                {'Persons'}
            </label>
            <MultiSelect
                options={this.state.multiOption}
                standards={this.state.multiSelection}
                handleChange={(e) => this.handleChangeMultiSelect(e, "selectedDocCode")}
            />
            {this.state.status && <div>{this.displayChart()}</div>}
        </div>
    }
    componentDidMount() {

        var fromDate = '';
        var toDate = '';

        datasave.service(window.GET_DEFAULT_REPNUM, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {
                    var textVal = parseInt(result['value']);
                    if (result['value'] == 0) {
                        textVal = 30
                    }
                    var d = new Date();
                    var d2 = new Date();
                    var currentDay = '' + d.getDate();
                    var currentMonth = d.getMonth() + 1 + '';
                    var currentYear = d.getFullYear();
                    var date = d2.getDate() - textVal;
                    d2.setDate(date);
                    var d2Date = '' + d2.getDate();
                    var d2Month = d2.getMonth() + 1 + '';
                    fromDate = [d2.getFullYear(), d2Month.length < 2 ? '0' + d2Month : d2Month, d2Date.length < 2 ? '0' + d2Date : d2Date].join('-');
                    toDate = [currentYear, currentMonth.length < 2 ? '0' + currentMonth : currentMonth, currentDay.length < 2 ? '0' + currentDay : currentDay].join('-');
                    this.handleService(fromDate, toDate, 'textVal', textVal);
                }

            })
    }

}
export default translate(GrafiekOpenTodos);
