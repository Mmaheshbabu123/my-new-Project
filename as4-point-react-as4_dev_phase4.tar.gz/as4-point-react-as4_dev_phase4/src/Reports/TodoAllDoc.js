import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
class TodoAllDoc extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,

            allTodoChartData: [],
            allTodoDetails: [],
            progressShow: 'Loading',
            t: props.t,
        }
    }

    handleOnClick(data) {
        const { t } = this.state;
        if (data.length > 0) {
            this.props.history.push({
                pathname: '/todoalleventview',
                data: data // your data array of objects
            })
        } else {
  OCAlert.alertWarning(t('no data'), { timeOut: window.TIMEOUTNOTIFICATION })
        }

    }
    render() {
        const { t } = this.state;
        if (this.state.status) {
            return <div className='container-fluid mt-3'>

                <Chart
                    // width={'1000px'}
                    // height={'500px'}
                    chartType="PieChart"
                    loader={<div>{t('Loading chart')}</div>}

                    data={
                        this.state.allTodoChartData
                    }
                    options={{
                        title: t("Open to do’s past dd"),
                        is3D: true,
                        sliceVisibilityThreshold: 0,
                        width: '100%',
                        height: '100%',
                        chartArea: {
                            height: "80%",
                            // left: "15%",
                            width: "100%"
                        },
                        legend: {
                            maxLines: 1,
                            textStyle: {
                                fontSize: window.REPORT_FONT_SIZE
                            }
                        },
                    }}
                    chartEvents={[
                        {
                            eventName: 'select',
                            callback: ({ chartWrapper }) => {
                                const chart = chartWrapper.getChart()
                                const selection = chart.getSelection();



                                if (selection.length === 1) {
                                    const [selectedItem] = selection
                                    const dataTable = chartWrapper.getDataTable()


                                    const { row} = selectedItem
                                    let value = dataTable.getValue(row, 0);
                                    let keyName = (value.substr(0, value.indexOf('('))).trim();

                                    this.handleOnClick(this.state.allTodoDetails[keyName]);
                                    // alert(
                                    //     'You selected : ' +
                                    //     JSON.stringify({
                                    //         // row,
                                    //         // column,
                                    //         value: keyName,
                                    //         // name: dataTable.getColumnLabel(row, column),


                                    //         // name: selection

                                    //     }),
                                    //     null,
                                    //     2,
                                    // )

                                }

                            },
                        },
                    ]}
                />
            </div>
        } else {
            return (<div>{t('Loading')}</div>)
        }
    }
    componentDidMount() {
      const {t} =this.state;
        datasave.service(window.GETALLTODODOC, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {
                    this.setState({
                        allTodoChartData: result['AllTodoChartData'],
                        allTodoDetails: result['AllTodoDetails'],
                        status: true,
                    })
                } else {
                    this.setState({
                        status: true,
                        progressShow: t('No Data')
                    })
                }

            })

    }
}
export default translate(TodoAllDoc);
