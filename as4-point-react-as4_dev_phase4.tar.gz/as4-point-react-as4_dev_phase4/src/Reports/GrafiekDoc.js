import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
import { OCAlert } from '@opuscapita/react-alerts';
class GrafiekDoc extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            grafiekDocChartData: [],
            grafiekDocDetails: [],
            copyGrafiekDocChartData : [],
            progressShow: 'Loading',
            t: props.t,
            multiSelection: [],
            multiOption: [],
            maxValue:0,
        }
    }

    handleOnClick(data) {
        console.log(data);
        const { t } = this.state;
        if (data.length > 0) {
            this.props.history.push({
                pathname: '/grafiekdoceventview',
                data: data // your data array of objects
            })
        } else {
                    OCAlert.alertWarning(t('no data'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
    }
    render() {
        const { t } = this.state;
        console.log(this.state);
        if (this.state.status) {
            return <reactbootstrap.Container>
                <reactbootstrap.Row style={{marginBottom:'12px'}}>
                <reactbootstrap.Col className='col-md-2'>
                <reactbootstrap.FormLabel >{t('Documents')}</reactbootstrap.FormLabel>
                </reactbootstrap.Col>
                <reactbootstrap.Col className='col-md-10'>
                <MultiSelect
                    options={Object.values(this.state.multiOption)}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.multiSelection}
                    handleChange={this.handleChangeMultiSelect}

                />
                </reactbootstrap.Col>
                </reactbootstrap.Row>
                <reactbootstrap.Row>
			{this.state.multiSelection.length > 0 && this.displayChart()}
                </reactbootstrap.Row>
            </reactbootstrap.Container>
        } else {
            return (<reactbootstrap.Container>{t('Loading')}</reactbootstrap.Container>)
        }
    }

    displayChart() {

        var table = [];
        var tempArr = [];
        var GrafieData = this.state.grafiekDocChartData;

        if (GrafieData.length > 0) {

            if (GrafieData.length > 6) {
                tempArr.push(GrafieData[0]);
                console.log(tempArr);

                for (var i = 0; i < GrafieData.length; i++) {
                    tempArr.push(GrafieData[i + 1]);
                    if ((i + 1) % 5 == 0) {
                        console.log(tempArr);
                        table.push(this.getChart(tempArr));
                        tempArr = [GrafieData[0]]
                    }
                }
                if ((GrafieData.length - 1) % 5 != 0) {
                    var rem = parseInt((GrafieData.length - 1) % 5);
                    var startIndex = (GrafieData.length) - rem;
                    tempArr = [GrafieData[0]];
                    var remForScale = 5 - rem;
                    for (var j = startIndex; j< GrafieData.length + remForScale; j++) {
                        if (GrafieData[j] != undefined) {
                            tempArr.push(GrafieData[j]);
                        } else {
                            tempArr.push([' ', 0, 0, 0]);
                        }

                    }
                    table.push(this.getChart(tempArr));
                }
            } else {
                table.push(this.getChart(GrafieData));
            }
        }
        return table;

    }
    handleChangeMultiSelect=(event)=> {
      this.setState({multiSelection:event},()=>this.generateFilterChart());
    }
    generateFilterChart = () =>{
      const {multiSelection, copyGrafiekDocChartData} = this.state;
      if(multiSelection.length>0){
        var filterData = [copyGrafiekDocChartData[0]];
        multiSelection.map(key => {
            copyGrafiekDocChartData.map(key1 => {
                if (key1[0] == key['value']) {
                    filterData.push(key1)
                }
            })
        })
        this.setState({grafiekDocChartData:filterData})
      }else{
        this.setState({grafiekDocChartData:copyGrafiekDocChartData})
      }
    }

    getChart(grafiekDocChartData) {
      const { maxValue ,t} = this.state;
      console.log(maxValue);
        return (
            <div style={{ 'margin-bottom': '20px' }}>
                <Chart
                    width={'1000px'}
                    height={'500px'}
                    chartType="BarChart"
                    loader={<div>{t("Loading chart")}</div>}
                    data={grafiekDocChartData}
                    options={{
                        hAxis: {
                            title: '',
                            minValue: 0,
			    format: '#,##0'
                        },
                        vAxis: {
                            title: 'documents',
                        },
                        legend: {
                            maxLines: 1,
                            textStyle: {
                                fontSize: window.REPORT_FONT_SIZE
                            }
                        },
                    }}
                    chartEvents={[
                        {
                            eventName: 'select',
                            callback: ({ chartWrapper }) => {
                                const chart = chartWrapper.getChart()
                                const selection = chart.getSelection();
                                if (selection.length === 1) {
                                    const [selectedItem] = selection
                                    const dataTable = chartWrapper.getDataTable()
                                    const { row, column } = selectedItem
                                    let columnName = dataTable.getColumnLabel(column).trim();
                                    let personName = dataTable.getValue(row, 0).trim();
                                     dataTable.getValue(row, column);
                                    this.handleOnClick(this.state.grafiekDocDetails[personName][columnName]);
                                }

                            },
                        },
                    ]}
                />
            </div>

        )
    }
  async  getMultiSelectNames(data) {
        if (Object.keys(data).length > 0) {
          let constructed =Object.keys(data).map(key=>{
            return ({'value':key,'label':key})
          });
          return await this.sort(constructed);
        }else{
          return [];
        }
    }
    sort(data){
      let t=data.sort(function(a,b){return (a.label).toLowerCase() < (b.label).toLowerCase() ? -1 : 1;});
      return t;
    }
    async componentDidMount() {
      const {t} =this.state;
        datasave.service(window.GRAFIEK_DOC_REPORTS, "GET")
            .then(async result => {
                if (result != '' && result.length != 0) {
                    this.setState({
                        grafiekDocChartData: result['GrafieDocChartData'],
                        grafiekDocDetails: result['GrafieDocDetails'],
                        copyGrafiekDocChartData: result['GrafieDocChartData'],
                        maxValue:result['maxValue'],
                        multiOption: result['documentOptions'],
                       // multiOption: await this.getMultiSelectNames(result['GrafieDocDetails']),
                        status: true,
                    })
                } else {
                    this.setState({
                        status: true,
                        progressShow: t('No Data')
                    })
                }

            })

    }
}
export default translate(GrafiekDoc);
