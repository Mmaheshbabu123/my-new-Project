import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';

class DocumentStatusAll extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            documentStatusDetails: [],
            documentChartData: [],
            progressShow: 'Loading',
            t: props.t,
        }
    }
    handleOnClick(data) {
      const {t} =this.state;
        if (data.length > 0) {
            this.props.history.push({
                pathname: '/docstatusalleventview',
                data: data // your data array of objects
            })
        } else {
                    OCAlert.alertWarning(t('no data'), { timeOut: window.TIMEOUTNOTIFICATION })
        }

    }

    render() {
        const { t } = this.state;
        if (this.state.status) {
            return <div className='container-fluid mt-3'>
                <Chart
                    // width={'1000px'}
                    // height={'500px'}
                    chartType="PieChart"
                    loader={<div>{t('Loading chart')}</div>}
                    data={
                        this.state.documentChartData
                    }
                    options={{
                        title: t('Document status - overview'),
                        is3D: true,
                        sliceVisibilityThreshold: 0,
                        width: '100%',
                        height: '100%',
                        chartArea: {
                            height: "80%",
                            // left: "15%",
                            width: "100%"
                        },
                        legend: {
                            maxLines: 1,
                            textStyle: {
                                fontSize: window.REPORT_FONT_SIZE
                            }
                        },
                        // colors: ['white', '#D3D3D3','#10A5F5', '#10A5F5', '#10A5F5', '#0000A0', '#FFDD3C','#FFDD3C', '#FFDD3C', '#7E7E7E', '#7E7E7E', '#3D3D3D', '#10A5F5', 'red', 'orange','red']
                        colors: ['#3366cc', '#212f3c','#10A5F5', '#873600', '#CCCCFF', '#00FFFF', '#d4ac0d','#FF7F50', '#117a65', '#2980b9', '#a569bd', '#000080', '#e74c3c', 'red', '#DE3163','#730202']

                    }}
                    chartEvents={[
                        {
                            eventName: 'select',
                            callback: ({ chartWrapper }) => {
                                const chart = chartWrapper.getChart()
                                const selection = chart.getSelection();
                                if (selection.length === 1) {
                                    const [selectedItem] = selection
                                    const dataTable = chartWrapper.getDataTable()
                                    const { row } = selectedItem
                                    let value = dataTable.getValue(row, 0);
                                    let keyName = (value.substr(0, value.indexOf('('))).trim();
                                    this.handleOnClick(this.state.documentStatusDetails['DocDetails'][keyName]);
                                }

                            },
                        },
                    ]} />
            </div>
        } else {
            return (<div>{t('Loading')}</div>)
        }
    }
    componentDidMount() {
      const {t} =this.state;
        datasave.service(window.GET_DOCSTATUS_DETAILS, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {

                    this.setState({
                        documentChartData: result['DocumentChartData'],
                        documentStatusDetails: result['DocumentStatusDetails'],
                        status: true,
                    })
                } else {
                    this.setState({
                        status: true,
                        progressShow: t('No Data')
                    })
                }

            })

    }
}
export default translate(DocumentStatusAll);
