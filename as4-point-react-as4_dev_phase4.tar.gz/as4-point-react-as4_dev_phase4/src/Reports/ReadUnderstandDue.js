import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
class ReadUnderstandDue extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            readUnDueDetails: [],
            readUnDueChartData: [],
            progressShow: 'Loading',
            t: props.t,
        }
    }
    handleOnClick(data) {

        if (data.length > 0) {
            this.props.history.push({
                pathname: '/readundueeventview',
                data: data // your data array of objects
            })
        } else {
            alert('no data');
        }
    }
    render() {
        const { t } = this.state;
        if (this.state.status) {
            return <div className='container-fluid mt-3'>
                <Chart
                    // height={'200px'}
                    // width={'1000px'}
                    chartType="PieChart"
                    loader={<div>{t('Loading chart')}</div>}
                    data={
                        this.state.readUnDueChartData
                    }
                    options={{
                        title: t('R&U - due date info'),
                        is3D: true,
                        sliceVisibilityThreshold: 0,
                        colors: ['orange', 'blue', 'red'],
                        width: '100%',
                        height: '100%',
                        chartArea: {
                            height: "80%",
                            // left: "15%",
                            width: "100%"
                        },
                        legend: {
                            maxLines: 1,
                            textStyle: {
                                fontSize: window.REPORT_FONT_SIZE
                            }
                        },

                    }}
                    chartEvents={[
                        {
                            eventName: 'select',
                            callback: ({ chartWrapper }) => {
                                const chart = chartWrapper.getChart()
                                const selection = chart.getSelection();



                                if (selection.length === 1) {
                                    const [selectedItem] = selection
                                    const dataTable = chartWrapper.getDataTable()


                                    const { row, column } = selectedItem
                                    let value = dataTable.getValue(row, 0);
                                    let keyName = (value.substr(0, value.indexOf('('))).trim();

                                    this.handleOnClick(this.state.readUnDueDetails['ReadDue'][keyName]);
                                    // alert(
                                    //     'You selected : ' +
                                    //     JSON.stringify({
                                    //         // row,
                                    //         // column,
                                    //         value: keyName,
                                    //         // name: dataTable.getColumnLabel(row, column),


                                    //         // name: selection

                                    //     }),
                                    //     null,
                                    //     2,
                                    // )

                                }

                            },
                        },
                    ]}

                />

            </div>
        } else {
            return (<div>{t('Loading')}</div>)
        }
    }
    componentDidMount() {
      const {t} =this.state;
        datasave.service(window.READ_UN_DUEREPORTVIEW, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {

                    this.setState({
                        readUnDueChartData: result['readUnDueChartData'],
                        readUnDueDetails: result['readUnDueDetails'],
                        status: true,
                    })
                } else {
                    this.setState({
                        status: true,
                        progressShow: t('No Data')
                    })
                }

            })

    }
}
export default translate(ReadUnderstandDue);
