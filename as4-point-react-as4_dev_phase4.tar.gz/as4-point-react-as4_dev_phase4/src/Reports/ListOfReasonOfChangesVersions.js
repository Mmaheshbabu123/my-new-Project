import React, { Component } from 'react';
import { datasave } from '../../src/_services/db_services';
import * as Reactbootstrap from 'react-bootstrap';
import { translate } from '../../src/language';
import { SearchFilter } from '../../src/SearchFilter';
import MultiSelect from '../_components/MultiSelect';
import * as moment from 'moment/moment';
import { OCAlert } from '@opuscapita/react-alerts';
import './ListOfReasonOfChangesVersions.css';
import Pagination from 'react-bootstrap/Pagination';

class ListOfReasonOfChangesVersions extends Component {
  constructor(props) {
    super(props)
    this.state = {
      manualOPtions: [],
      selectedManuals: [],
      folderOptions: [],
      docOptions: [],
      selectedDocs: [],
      selectedfolders: [],
      copyfolderOptions: [],
      final: [],
      number: '',
      display: props.t('days'),
      t: props.t,
      filteredData: [],
      doc: '',
      code: '',
      from: '',
      fromDate: '',
      toDate: '',
      to: '',
      person: '',
      comment: '',
      activation_date: '',
      type: [
        {
          value: 'Days',
          label: props.t('Day')
        },
        {
          value: 'Month',
          label: props.t('Month')
        },
        {
          value: 'Year',
          label: props.t('Year')
        }
      ],
      periodtype: {
        value: 'Days',
        label: props.t('Day')
      },
      swap: 1,
      page: 10,
      activePage: 1,
      fullFilteredData:[],
    }
  }

  componentDidMount() {
    datasave.service(window.GET_MANUALS_REPORTS, 'GET').then(result => {
      this.setState({
        manualOPtions: result
      });
    })
  }
  handleChangeOptions = async (e) => {
    let data = { value: e };
    if (e.length === 0) {
      this.setState({
        folderOptions: [],
        selectedfolders: [],
        selectedManuals: [],
        filteredData: [],
        code: '',
        doc: '',
        fromDate: '',
        toDate: '',
        person: '',
        comment: '',
        activation_date: '',
        fullFilteredData:[],
        final:[],
        filterTableData:[]
      });
      return;
    }
    await datasave.service(window.GET_FOLDER_REPORTS, 'put', data).then(async result => {
      this.setState({
        selectedManuals: e,
        folderOptions: await this.filterParentfolder(result, e),
      }, () => this.handleFilter(Object.values(this.state.folderOptions)));
    })

  }
  filterParentfolder = (data, e) => {
    var ids = e.map(obj => { return obj['value'] });
    return Object.values(data).filter(value => { return !ids.includes(value['value']) });
  }
  handleChangeFolders = (e) => {
    this.setState({
      selectedfolders: e,
    })
    this.handleFilter(e);
  }

  searchData = async (e) => {
    const { name, value } = e.target;
    if (e.key !== "Delete" || e.key !== "Backspace") {
      this.setState({ [name]: value },()=>this.synchrounusSearch());
    }
  }
  synchrounusSearch=async ()=>{
        const { doc, code, fromDate, toDate, person, final, comment, activation_date } = this.state;
        var docItems = [];
        var pageData = [];
        var pagecount = 0;
        var filledStates = await this.getStates(doc, code, fromDate, toDate, person, comment, activation_date);
        docItems = await SearchFilter.getData(filledStates, final);
        if(docItems.length>0){
            pageData = await this.getPageData(1, docItems);
            pagecount = await this.getCountPage(docItems);
            this.setState({
              fullFilteredData:docItems
            })
        }else{
          pageData = await this.getPageData(1, final);
          pagecount = await this.getCountPage(final);
          this.setState({
            code: '',
            doc: '',
            fromDate: '',
            toDate: '',
            person: '',
            comment: '',
            activation_date: '',
            fullFilteredData:final
          })
        }
        this.setState({
          filteredData:pageData,
          active: 1,
          count: pagecount,
        });
  }
  async getPageData(id, list) {
    const items = (list.length > 0) ? list : this.state.filteredData;
    return items.slice(this.state.page * (id - 1), this.state.page * id);
  }
  async getCountPage(items) {
    return (items.length > this.state.page) ? Math.ceil(items.length / this.state.page) : 0;
  }
  onKeyUp = async e => {
    const { doc, code, fromDate, toDate, person, final, comment, activation_date } = this.state;
    var docItems = [];
    if (e.key === "Delete" || e.key === "Backspace") {
      var filledStates = await this.getStates(doc, code, fromDate, toDate, person, comment, activation_date);
      docItems = await SearchFilter.getData(filledStates, final);
      let pageData1 = await this.getPageData(1, docItems);
      let pagecount = await this.getCountPage(docItems);
      this.setState({
        filteredData: pageData1,
        active: 1,
        count: pagecount,
        fullFilteredData:docItems

      });
    }
  }
  getStates = (col1, col2, col3, col4, col5, col6, col7) => {
    var arr = []
    if (col1 != '') {
      arr.push({ name: 'doc', value: col1 });
    }
    if (col2 != '') {
      arr.push({ name: 'code', value: col2 });
    }
    if (col3 != '') {
      arr.push({ name: 'fromDate', value: col3 });
    }
    if (col4 != '') {
      arr.push({ name: 'toDate', value: col4 });
    }
    if (col5 != '') {
      arr.push({ name: 'person', value: col5 });
    }
    if (col6 != '') {
      arr.push({ name: 'comment', value: col6 });
    }
    if (col7 != '') {
      arr.push({ name: 'activation_date', value: col7 });
    }
    return arr;
  }
  handlePeriodType = (e) => {
    this.setState({
      periodtype: e
    })
  }

  async handleFilter(selectedfolder) {
    const { t } = this.state;
    if ((this.state.selectedManuals).length < 1) {
      OCAlert.alertWarning(t('Please select minimum one manual'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (this.state.display !== 'days' && (this.state.from !== '' && this.state.to !== '' && new Date(this.state.from).getTime() > new Date(this.state.to).getTime())) {
      OCAlert.alertWarning(t('Please select correct From date and To Date'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (this.state.from !== '' && this.state.to == '') {
      OCAlert.alertWarning(t('Please select To Date'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    } else if (this.state.from === '' && this.state.to !== '') {
      OCAlert.alertWarning(t('Please select From Date'), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }
    console.log(
      this.state
    );
    let data = {
      docids: selectedfolder.length > 0 ? selectedfolder : this.state.folderOptions,
      type: (this.state.display!=='days' && this.state.from === '' || this.state.to === '') ? 'days' : this.state.display,
      number:this.state.periodtype.value=== 'Days' && this.state.number === '' ? 365 :this.state.periodtype.value=== 'Month' && this.state.number === ''?12:this.state.periodtype.value=== 'Year' && this.state.number === ''? 1:this.state.number,
      periodtype: this.state.periodtype.value,
      from: this.state.from,
      to: this.state.to
    };
    await datasave.service(window.PUT_FILTER_REPORTS, 'PUT', data).then(
      async result => {
        let pageData = [];
        let data = await this.reconstructData(result);
        data=this.sortData(data);
        pageData = await this.getPageData(1, data);
        let count = await this.getCountPage(data);
        this.setState({
          final: data,
          filteredData: result.length > 0 ? await this.sortData(pageData) : [],
          active: 1,
          count: count,
          fullFilteredData:data,
          code: '',
          doc: '',
          fromDate: '',
          toDate: '',
          person: '',
          comment: '',
          activation_date: '',
        })
      });
  }

  handleNumber(e) {
    if (!isNaN(e.target.value)) {
      this.setState({
        number: e.target.value
      })
    }
  }
  sortData = (data) => {
    return data.sort((a, b) => new Date(a.activation_date).getTime() < new Date(b.activation_date).getTime());
  }
  reconstructData = async (data) => {
    return data.map(item => {
      return {
        'code': item.code !== undefined && item.code !== null ? item.code.toString() : ' ',
        'doc': item.doc !== undefined && item.doc !== null ? item.doc.toString() : ' ',
        'fromDate': item.from !== undefined && item.from !== null ? item.from.toString() : ' ',
        'toDate': item.to !== undefined && item.to !== null ? item.to.toString() : ' ',
        'person': item.person !== undefined && item.person !== null ? item.person.toString() : ' ',
        'comment': item.comment !== undefined && item.comment !== null ? item.comment.toString() : ' ',
        'activation_date': item.activation_date !== undefined && item.activation_date !== null ? item.activation_date.toString() : ' ',
      }
    })
  }
  handleRadio(e) {
    this.setState({
      swap: !this.state.swap,
      from: "",
      to: "",
      number: '',
      display: e.target.value,
      periodtype: { value: 'Days', label: 'Day' },
    })
  }

  handleDate = (e) => {
    if (e.target.name === "fromDate") {
      this.setState({ from: e.target.value })
    } else {
      this.setState({ to: e.target.value })
    }
  }

  async changePage(e, id) {
    let pageData = await this.getPageData(id,  this.state.fullFilteredData);
    this.setState({
      filteredData: await this.sortData(pageData),
      active: id,
    })
  }
  render() {
    const { doc, code, person, number, comment, swap, active, activation_date, manualOPtions, selectedManuals, folderOptions, selectedfolders, t, type, periodtype, fromDate, toDate, filteredData } = this.state;
    let pages = [];
    if (this.state.count > 0) {
      for (let number = 1; number <= this.state.count; number++) {
        pages.push(
          <Pagination.Item key={number} active={number === active} id={number} onClick={(e) => this.changePage(e, number)}>
            {number}
          </Pagination.Item>,
        );
      }
    }
    console.log(this.state);
    return (
      <div className='p-4 mb-5 fluid'>
        <Reactbootstrap.Row className='mt-3'>
          <Reactbootstrap.Col className='col-md-6 d-flex'>
            <Reactbootstrap.Form.Label className='col-md-3 font-weight-bold'>{t('Select manuals')}</Reactbootstrap.Form.Label>
            <Reactbootstrap.Col className='col-md-9' style={{ zIndex: 999 }}>
              <MultiSelect
                options={manualOPtions}
                standards={selectedManuals}
                disabled={false}
                handleChange={(e) => this.handleChangeOptions(e)}
                isMulti={true}
                id="Manuals"
                placeholder={t('Select')}
              />
            </Reactbootstrap.Col>
          </Reactbootstrap.Col>
          <Reactbootstrap.Col className='col-md-6 d-flex'>
            <Reactbootstrap.Form.Label className='col-md-3 font-weight-bold'>{t('Select folders')}</Reactbootstrap.Form.Label>
            <Reactbootstrap.Col className='col-md-9' style={{ zIndex: 999 }}>
              <MultiSelect
                options={folderOptions}
                standards={selectedfolders}
                disabled={false}
                handleChange={(e) => this.handleChangeFolders(e)}
                isMulti={true}
                id="folders"
                placeholder={t('Select')}
              />
            </Reactbootstrap.Col>
          </Reactbootstrap.Col>
        </Reactbootstrap.Row >
        <Reactbootstrap.Row className='pl-4 mt-3'>
          <Reactbootstrap.Form.Check type='radio' value='days' checked={swap} className='mr-2' label={t('Sort by number of days/months/years')} onChange={this.handleRadio.bind(this)} />
          <Reactbootstrap.Form.Check type='radio' value='date' checked={!swap} label={t('Sort by date')} onChange={this.handleRadio.bind(this)} />
        </Reactbootstrap.Row>
        <Reactbootstrap.Row className='pl-2 mt-3 d-flex'>
          {swap && <Reactbootstrap.Col className="col-md-6 d-flex">
            <Reactbootstrap.FormControl
              className="col-md-4"
              type='text'
              onChange={(e) => this.handleNumber(e)}
              name='number'
              placeholder={t('Number')}
              value={number}
            />
            <Reactbootstrap.Col className="col-md-8">
              <MultiSelect
                options={type}
                standards={periodtype}
                disabled={false}
                handleChange={(e) => this.handlePeriodType(e)}
                isMulti={false}
                id="number"
                placeholder={t('Select')}
              />
            </Reactbootstrap.Col>
          </Reactbootstrap.Col>}
          {!swap && <Reactbootstrap.Col className="col-md-6 d-flex">
            <Reactbootstrap.Form.Label className='col-md-2 font-weight-bold'>{t('From :')}</Reactbootstrap.Form.Label>
            <Reactbootstrap.FormControl
              type='date'
              name="fromDate"
              className='col-md-4'
              onChange={(e) => this.handleDate(e)}
              max={moment().format("YYYY-MM-DD")}
            />
            <Reactbootstrap.Form.Label className='col-md-2 font-weight-bold'>{t('To :')}</Reactbootstrap.Form.Label>
            <Reactbootstrap.FormControl
              type='date'
              name="toDate"
              className='col-md-4'
              onChange={(e) => this.handleDate(e)}
              max={moment().format("YYYY-MM-DD")}
            />
          </Reactbootstrap.Col>}
          <button type="button" onClick={this.handleFilter.bind(this, this.state.selectedfolders)} class="btn btn-outline-success">{t('Filter')}</button>
        </Reactbootstrap.Row>
        <Reactbootstrap.Row className='row mt-3'>
          <Reactbootstrap.Table striped bordered hover variant="">
            <thead>
              <tr style={{ backgroundColor: '#EC661C', color: '#fff' }}>
                <td>{t('Document code')}</td>
                <td>{t('Document name')}</td>
                <td>{t('Version from')}</td>
                <td>{t('Version to')}</td>
                <td>{t('Person')}</td>
                <td>{t('Reason of change')}</td>
                <td>{t('Activation date of new version')}</td>
              </tr>
              <tr>
                <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='code' value={code} onChange={this.searchData} onKeyUp={this.onKeyUp} /></th>
                <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='doc' value={doc} onChange={this.searchData} onKeyUp={this.onKeyUp} /></th>
                <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='fromDate' value={fromDate} onChange={this.searchData} onKeyUp={this.onKeyUp} /></th>
                <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='toDate' value={toDate} onChange={this.searchData} onKeyUp={this.onKeyUp} /></th>
                <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='person' value={person} onChange={this.searchData} onKeyUp={this.onKeyUp} /></th>
                <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='comment' value={comment} onChange={this.searchData} onKeyUp={this.onKeyUp} /></th>
                <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='activation_date' value={activation_date} onChange={this.searchData} onKeyUp={this.onKeyUp} /></th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length < 1 && <tr><td colspan='7' style={{ color: 'grey', textAlign: 'center' }}>{t('No records found')}</td></tr>}
              {filteredData.length > 0 && this.state.filteredData.map(item => {
                return <tr>
                  <td>{item.code}</td>
                  <td>{item.doc}</td>
                  <td>{item.fromDate}</td>
                  <td>{item.toDate}</td>
                  <td>{item.person}</td>
                  <td>{item.comment}</td>
                  <td>{item.activation_date}</td>
                </tr>
              })}
            </tbody>
          </Reactbootstrap.Table>
        </Reactbootstrap.Row>
        {filteredData.length > 0 && <Reactbootstrap.Row className="d-flex justify-content-center">
          <Pagination style={{ width: '350px', overflow: 'auto', scrollbarWidth: 'thin' }} size="md">{pages}</Pagination>
        </Reactbootstrap.Row>}
      </div>

    )
  }

}
export default translate(ListOfReasonOfChangesVersions);
