import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services';
import CheckBox from '../CheckBox.js';
import MultiSelect from '../_components/MultiSelect';
import * as reactbootstrap from 'react-bootstrap';
import { OCAlert } from '@opuscapita/react-alerts';
import { translate } from '../language';
class RejectionReason extends Component {
    constructor(props) {
        super(props);
        this.state = {
            manualCheck: false,
            folderCheck: false,
            documentCheck: false,
            manualsList: [],
            manualSelection: [],
            folderList: [],
            folderSelection: [],
            documentList: [],
            documentSelection: [],
            cycleSelect: 1,
            fromDate: '',
            toDate: '',
            status: false,
            RejResChartData: [],
            t: props.t,

        }
    }

    handleCheckBox(e, name) {

        if (name == 'manualCheck') {
            this.handleManual(e, name);
        }
        if (name == 'folderCheck') {
            this.handleFolder(e, name);
        }
        if (name == 'documentCheck') {
            this.handleDocument(e, name);
        }


        // this.setState({
        //     [name]: e.target.checked
        // })



    }
    handleManual(e, name) {
        if (e.target.checked) {
            this.handleService(window.GET_REJ_MAN_DETAILS, 'GET', [], 'manualList', name, e.target.checked);
        } else {
            this.setState({
                manualCheck: false,
                folderCheck: false,
                documentCheck: false,
                manualList: [],
                folderList: [],
                documentList: [],
                manualSelection: [],
                folderSelection: [],
                documentSelection: []
            })

        }

    }
    handleFolder(e, name) {
        const { t } = this.state;
        if (e.target.checked) {
            if (this.state.manualCheck && this.state.manualSelection.length > 0) {
                var data = {
                    value: this.state.manualSelection
                }
                // this.handleService(window.GET_REJ_FOLD_DETAILS, 'POST', data, 'folderList', name, e.target.checked)
                this.handleService(window.GET_FOLDER_REPORTS, 'PUT', data, 'folderList', name, e.target.checked)
            } else {
              OCAlert.alertWarning(t('please select manuals'), { timeOut: window.TIMEOUTNOTIFICATION })
            }
        } else {
            this.setState({
                folderCheck: false,
                documentCheck: false,
                manualList: [],
                folderList: [],
                documentList: [],
                folderSelection: [],
                documentSelection: []
            })
        }
    }

    handleDocument(e, name) {
        const { t } = this.state;
        if (e.target.checked) {
            if (this.state.manualCheck && this.state.manualSelection.length > 0 &&
                this.state.folderCheck && this.state.folderSelection.length > 0) {
                var data = {
                    data: this.state.folderSelection
                }
                this.handleService(window.GET_REJ_DOC_DETAILS, 'POST', data, 'documentList', name, e.target.checked);
            } else {
                OCAlert.alertWarning(t('Please select respective manuals/folders'), { timeOut: window.TIMEOUTNOTIFICATION })
            }
        } else {
            this.setState({
                documentCheck: false,
                documentSelection: []
            })
        }
    }

  async  handleService(url, type, data, key, key1, value1) {
        if (data.length != 0) {
          await  datasave.service(url, type, data)
                .then(async result => {
                    if (result != '') {
                        this.setState({
                            // [key]: key==='folderList'?this.sort(result['data']):result['data'],
                            [key]: key==='folderList'?await this.filterParentfolder(Object.values(result),Object.values(data)):result['data'],
                            [key1]: value1
                        })
                    }
                });
        } else {
          await  datasave.service(url, type)
                .then(async result => {
                    if (result != '') {
                        this.setState({
                            // [key]: key==='folderList'?this.sort(result['data']):result['data'],
                            [key]: key==='folderList'?await this.filterParentfolder(Object.values(result)):result['data'],
                            [key1]: value1
                        })
                    }

                });
        }

    }
    filterParentfolder=(result)=>{
      const {manualSelection} =this.state;
      let ids = manualSelection.map(value=>{return value['value']});
      return result.filter(value=>{return !ids.includes(value['value'])});
    }
    // sort(data){
    //   return Object.values(data).sort((a,b)=>a.value - b.value);
    // }
    handleChangeMultiSelect(e, name) {

        if (name != 'documentSelection') {
            switch (name) {
                case 'manualSelection':
                    this.handleManualMultiSelect(e, name);
                    break;
                case 'folderSelection':
                    this.handleFolderMultiSelect(e, name);
                    break;
            }
        } else {
            this.setState({
                [name]: e
            })
        }

    }

    handleManualMultiSelect(e, name) {
        this.setState({
            folderCheck: false,
            folderSelection: [],
            folderList: [],
            documentCheck: false,
            documentSelection: [],
            documentList: [],
            [name]: e
        })
    }

    handleFolderMultiSelect(e, name) {
        this.setState({
            documentCheck: false,
            documentSelection: [],
            documentList: [],
            [name]: e
        })
    }

    handleCycleChange(e, name) {
        this.setState({
            [name]: parseInt(e.target.value)
        })
    }

    handleDateChange(e, name) {
        this.setState({
            [name]: e.target.value
        })
    }
    handleSubmit(e) {
        const { t } = this.state;
        if (this.state.fromDate != '' && this.state.toDate != '') {

            if (new Date(this.state.fromDate) <= new Date(this.state.toDate)) {
                this.handleSubmitService(this.state.fromDate, this.state.toDate);
            } else {
                OCAlert.alertWarning(t('Please enter valid date'), { timeOut: window.TIMEOUTNOTIFICATION })
            }
        } else {
            console.log('Error');
        }

    }

    handleSubmitService(fromDate, toDate) {



        //manual = 5, folder = 7, document = 9
        var ManFolDocCheck = (this.state.manualSelection.length > 0 ? 5 : 0) + (this.state.folderSelection.length > 0 ? 7 : 0) + (this.state.documentSelection.length > 0 ? 9 : 0);
        var data = {
            data: {
                ManFolDocCheck: ManFolDocCheck,
                Manual: this.state.manualSelection,
                Folder: this.state.folderSelection,
                Document: this.state.documentSelection,
                Cycle: this.state.cycleSelect,
                FromDate: fromDate,
                ToDate: toDate
            }
        }
        datasave.service(window.GET_REJRES_DETAILS, 'POST', data)
            .then(result => {
                console.log(result);
                if (result != '') {
                    this.setState({
                        RejResChartData: result['RejResChartData'],
                        status: true,
                        fromDate: fromDate,
                        toDate: toDate
                    })
                }

            })



    }

    displayChartData() {
        var table = [];
        const {t} =this.state;
        if (this.state.status) {
            table.push(<div>
                <Chart
                    // height={'200px'}
                    // width={'1000px'}
                    chartType="PieChart"
                    loader={<div>{t("Loading chart")}</div>}
                    data={
                        this.state.RejResChartData
                    }
                    options={{
                        // title: t('Rejection reasons'),
                        is3D: true,
                        sliceVisibilityThreshold: 0,
                        colors: ['blue', 'orange', 'grey'],
                        width: '100%',
                        height: '100%',
                        chartArea: {
                            height: "80%",
                            // left: "15%",
                            width: "100%"
                        },
                        legend: {
                            maxLines: 1,
                            textStyle: {
                                fontSize: window.REPORT_FONT_SIZE
                            }
                        },

                    }}

                />

            </div>)
        }
        return table;

    }
    render() {
        console.log(this.state);
        const { t } = this.state;
        return <div className="container p-5">
            <h5>{t("Rejection reasons – overview")}</h5>
            <div>
                <label className="col-md-1 pl-0" style={{ display: 'inline-flex' }} >
                    <CheckBox
                        // value={this.state.selectedFundamental}
                        tick={this.state.manualCheck}
                        style={{ paddingLeft: '0px' }}
                        onCheck={(e) => this.handleCheckBox(e, 'manualCheck')}


                    />
                    <span style={{ alignSelf: 'center', marginLeft: '-1rem' }}>{t('Manual')}</span>
                </label>
            </div>
            <div className="input_sw mb-3" style={{ display: (this.state.manualCheck == true) ? 'block' : 'none' }}>
                <MultiSelect
                    options={this.state.manualList}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.manualSelection}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "manualSelection")}
                />
            </div>
            <div>
                <label className="col-md-1 pl-0" style={{ display: 'inline-flex' }} >
                    <CheckBox
                        // value={this.state.selectedFundamental}
                        tick={this.state.folderCheck}
                        style={{ paddingLeft: '0px' }}
                        onCheck={(e) => this.handleCheckBox(e, 'folderCheck')}

                    />
                    <span style={{ alignSelf: 'center', marginLeft: '-1rem' }}>{t('Folder')} </span>
                </label>
            </div>
            <div className="input_sw mb-3" style={{ display: (this.state.folderCheck == true) ? 'block' : 'none' }}>
                <MultiSelect
                    options={this.state.folderList}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.folderSelection}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "folderSelection")}
                />
            </div>
            <div>
                <label className="col-md-1 pl-0" style={{ display: 'inline-flex' }} >
                    <CheckBox
                        // value={this.state.selectedFundamental}
                        tick={this.state.documentCheck}
                        style={{ paddingLeft: '0px' }}
                        onCheck={(e) => this.handleCheckBox(e, 'documentCheck')}

                    />
                    <span style={{ alignSelf: 'center', marginLeft: '-1rem' }}> {t('Document')} </span>
                </label>
            </div>
            <div className="input_sw mb-3" style={{ display: (this.state.documentCheck == true) ? 'block' : 'none' }}>
                <MultiSelect
                    options={this.state.documentList}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.documentSelection}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "documentSelection")}
                />
            </div>

            <div className="">
                <select style={{ padding: '6px' }} className="input_sw mr-3" value={this.state.cycleSelect} onChange={(e) => { this.handleCycleChange(e, 'cycleSelect') }}>
                    <option value={1}>{t('Activation cycle')}</option>
                    <option value={2}>{t('Review cycle')}</option>
                    <option value={3}>{t('Expiration cycle')}</option>
                </select>
                <label>
                    {t('From date:')}
                    <input style={{ padding: '5px', marginLeft: '5px' }} className="input_sw mr-3" type={'date'} value={this.state.fromDate} onChange={(e) => { this.handleDateChange(e, 'fromDate') }} />
                </label>
                <label>
                    {t('To date:')}
                    <input style={{ padding: '5px', marginLeft: '5px' }} className="input_sw " type={'date'} value={this.state.toDate} onChange={(e) => { this.handleDateChange(e, 'toDate') }} />
                </label>
            </div>

            <div className="mt-4 mb-4">
                <reactbootstrap.Button onClick={(e) => this.handleSubmit(e)}>{t('Submit')}</reactbootstrap.Button>
            </div>
            {this.displayChartData()}
        </div>
    }
    componentDidMount() {
        var fromDate = '';
        var toDate = '';

        datasave.service(window.GET_DEFAULT_REPNUM, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {
                    var textVal = parseInt(result['value']);
                    if (result['value'] == 0) {
                        textVal = 30
                    }
                    var d = new Date();
                    var d2 = new Date();
                    var currentDay = '' + d.getDate();
                    var currentMonth = d.getMonth() + 1 + '';
                    var currentYear = d.getFullYear();
                    var date = d2.getDate() - textVal;
                    d2.setDate(date);
                    var d2Date = '' + d2.getDate();
                    var d2Month = d2.getMonth() + 1 + '';
                    fromDate = [d2.getFullYear(), d2Month.length < 2 ? '0' + d2Month : d2Month, d2Date.length < 2 ? '0' + d2Date : d2Date].join('-');
                    toDate = [currentYear, currentMonth.length < 2 ? '0' + currentMonth : currentMonth, currentDay.length < 2 ? '0' + currentDay : currentDay].join('-');
                    this.handleSubmitService(fromDate, toDate);
                }

            })



    }
}
export default translate(RejectionReason);
