import React, { Component } from 'react';
import { datasave } from '../_services/db_services';
import MultiSelect from '../_components/MultiSelect';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
class DocumentMangeListEventView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            documentDetails: [],
            documentName: [],
            documentCode: [],
            documentVersion: [],
            manualName: [],
            personName: [],
            openDays: [],
            dueDays: [],
            selectedOpenDay: [],
            selectedDueDay: [],
            selectedDocName: [],
            selectedDocCode: [],
            selectedDocVer: [],
            selectedManName: [],
            selectedPerName: [],
            selectedDueDate: [],
            filterObj: [],
            currentDetails: [],
            progressShow: 'Loading.....',
            totalCount: 0,
            t:props.t
        }
    }

    handleChangeMultiSelect(event, name) {
        var filter1 = this.state.filterObj;
        let indexTemp = [];
        if (filter1.length > 0) {
            filter1.map((key, index) => {
                if (key['statename'] === name) {
                    indexTemp.push(index);
                }
            })
            filter1 = this.handleFilterAdd(filter1, indexTemp, event);
            this.handleFilter(filter1, name, event);
        } else {
            filter1 = filter1.concat(event);
            this.handleFilter(filter1, name, event);
        }
    }

    handleFilterAdd(filter, indexTemp, event) {
        let tempArr = [];
        for (var i = 0; i < filter.length; i++) {
            if (indexTemp.indexOf(i) === -1) {
                tempArr.push(filter[i]);
            }
        }
        return tempArr.concat(event);
    }

    handleFilter(filter1, name, event) {
        var filterdup = filter1;
        var filterResult = [];
        if (filter1.length === 1) {
            filter1.map((key, index) => {
                filterResult = filterResult.concat(this.filterForDetails(key['name'], key['value']));
            })
            let finalFilter = filterResult;
            this.handleSetState(name, event, 'filterObj', filterdup, 'currentDetails', finalFilter);
        } else if (filter1.length > 1) {
            filter1.map((key, index) => {
                filterResult = filterResult.concat(this.filterForDetails(key['name'], key['value']));
            })
            var reqLength = this.countDuplicates(filter1);
            var duplicateResult = this.searchForDuplicates(filterResult, reqLength);
            var unique = duplicateResult.filter(function (item, i, ar) { return ar.indexOf(item) === i; });
            let finalFilter = unique;
            this.handleSetState(name, event, 'filterObj', filterdup, 'currentDetails', finalFilter);
        } else {
            this.handleSetState(name, event, 'filterObj', filterdup, 'currentDetails', this.keyInsertion(this.state.documentDetails));
        }
    }

    handleSetState(name1, value1, name2, value2, name3, value3) {
        this.setState({
            [name1]: value1,
            [name2]: value2,
            [name3]: value3
        })
    }

    countDuplicates(filter) {
        var length = filter.length;
        var temp = [];
        for (var i = 0; i < length; i++) {
            temp.push(filter[i]['statename']);
        }
        temp = temp.filter(function (x, i, a) {
            return a.indexOf(x) == i;
        });
        return temp.length;
    }

    searchForDuplicates(data, reqLength) {
        var length = data.length;
        var temp = [];
        var count = 1;
        if (reqLength > 1) {
            for (var i = 0; i < length - 1; i++) {
                count = 1;
                for (var j = i + 1; j < length; j++) {
                    if (data[i] === data[j]) {
                        count++;
                    }
                }
                if (reqLength === count) {
                    temp.push(data[i]);
                }
            }
        } else {
            temp = data;
        }
        return temp;
    }

    filterForDetails(name, value) {
        var temp = [];
        var alldetails = this.state.documentDetails;
        Object.keys(alldetails).forEach(function (key) {
            if (name == 'open_days' || name == 'due_days') {
                if (alldetails[key][name] >= parseInt(value)) {
                    temp.push(key)
                }
            } else if (name == 'document_duedate') {
                var d1 = new Date(alldetails[key][name]);
                var d2 = new Date(value);
                if (d1.getTime() === d2.getTime()) {
                    temp.push(key)
                }
            } else if (name == 'person_name') {
                if (alldetails[key][name] != '') {
                    let persons = alldetails[key][name].split(',');
                    if (persons.includes(value)) {
                        temp.push(key)
                    }
                }
            } else {
                if (alldetails[key][name] === value) {
                    temp.push(key)
                }
            }
        });
        return temp;
    }


    handleOnChange(e, statename, name) {
        var filter1 = this.state.filterObj;
        var indexTemp = [];
        if (e.target.value !== '') {
            var checkObj = [{ value: e.target.value, label: "", name: name, statename: statename }];
            filter1.map((key, index) => {
                if (key['statename'] === statename) {
                    indexTemp.push(index);
                }
            })
            filter1 = this.handleFilterAdd(filter1, indexTemp, []);
            filter1 = filter1.concat(checkObj);
            this.handleFilter(filter1, statename, checkObj);
        } else {
            filter1.map((key, index) => {
                if (key['statename'] === statename) {
                    indexTemp.push(index);
                }
            })
            filter1 = this.handleFilterAdd(filter1, indexTemp, []);
            this.handleFilter(filter1, statename, []);
        }
    }

    keyInsertion(data) {
        let temp = [];
        Object.keys(data).forEach(function (key) {
            temp.push(key);
        })
        return temp;
    }


    displayDocView() {
        let table = [];
        let currentDetails = this.state.currentDetails
        if (this.state.status) {
            var alldetails = this.state.documentDetails;
            currentDetails.map(key => {
                table.push(
                    <div className='card read-listofdata input_sw'>
                        <div>{alldetails[key]['document_code']} - {alldetails[key]['document_name']} - {alldetails[key]['document_version']} - {alldetails[key]['manual_name']}</div>
                        <div>{alldetails[key]['person_name']}</div>
                        <div>Due date: {alldetails[key]['view_duedate']}</div>
                        <div>{alldetails[key]['open_days']} days open - {alldetails[key]['due_days'] > 0 ? alldetails[key]['due_days'] : 0} days passed</div>
                    </div>
                )
            })
        }
        return table;
    }


     constructExportData(currentDetails, alldetails) {
         var data = {};
         data.alldetails = alldetails;
         data.currentDetails = currentDetails;
	 data.keyAndValue = {document_code: 'Document code', document_name: 'Document name', document_version: 'Document version',
         manual_name: 'Manual name', person_name: 'Person name', view_duedate: 'Due date', open_days: 'Days open', due_days: 'Days passed'};
         data.onlyKeys = ['document_code', 'document_name', 'document_version', 'manual_name', 'person_name', 'view_duedate', 'open_days', 'due_days']

         datasave.service(window.EXPORT_DOCUMENT_CHART_DATA, "POST", data)
             .then(response => {
                 var a = document.createElement("a");
                 a.setAttribute("type", "file");
                 a.href = response.file;
                 a.download = response.name;
                 document.body.appendChild(a);
                 a.click();
                 a.remove();
             });

     }

	countOfCurrentVsActive() {
        var table = [];
        table.push(<div style={{ padding: '5px 0px' }}>
            {this.state.currentDetails.length}/{this.state.totalCount.length}
        </div>);
        return table;
    }

    render() {
      const {t}=this.state;
        if (this.state.status) {
            return (
                <div className='container-fluid  row col-md-12' >
                    <div style={{ visibility: 'hidden' }} className="col-md-1"><p>welcome</p></div>
                    <div className="col-md-11 mt-4 mb-5 pl-0">
                        <div className='row justify-content-center' >
                            <div style={{ height: '475px', overflowY: 'auto', scrollbarWidth: 'thin' }} className='col-md-4 mr-4 readunderstand-folder'>
                                <label>
                                    {t('Amount of days open:')}
                                </label>
                                <div >
                                    <input style={{ padding: '8px 10px', border: '1px solid lightgray' }} className="input_sw mb-3 col-md-12" type={'text'} value={this.state.selectedOpenDay.length > 0 ? this.state.selectedOpenDay['value'] : ''} onChange={(e) => this.handleOnChange(e, "selectedOpenDay", 'open_days')} >
                                    </input>
                                </div>
                                <label>
                                    {t('Amount of days passed due date:')}
                                </label>
                                <div >
                                    <input style={{ padding: '8px 10px', border: '1px solid lightgray' }} className="input_sw mb-3 col-md-12" type={'text'} value={this.state.selectedDueDay.length > 0 ? this.state.selectedDueDay['value'] : ''} onChange={(e) => this.handleOnChange(e, "selectedDueDay", 'due_days')} >
                                    </input>
                                </div>
                                <label>
                                    {t('Due date:')}
                                </label>
                                <div >
                                    <input style={{ padding: '8px 10px', border: '1px solid lightgray' }} className="input_sw mb-3 col-md-12" type={'date'} onChange={(e) => this.handleOnChange(e, "selectedDueDate", 'document_duedate')}>
                                    </input>
                                </div>
                                <label>
                                    {t('Document code:')}
                                </label>
                                <div className="input_sw mb-3">
                                    <MultiSelect
                                        options={this.state.documentCode}
                                        standards={this.state.selectedDocCode}
                                        handleChange={(e) => this.handleChangeMultiSelect(e, "selectedDocCode")}
                                    />
                                </div>
                                <label>
                                    {t('Document name:')}
                                </label>
                                <div className="input_sw mb-3">
                                    <MultiSelect
                                        options={this.state.documentName}
                                        standards={this.state.selectedDocName}
                                        handleChange={(e) => this.handleChangeMultiSelect(e, "selectedDocName")}
                                    />
                                </div>
                                <label>
                                    {t('Document version:')}
                                </label>
                                <div className="input_sw mb-3">

                                    <MultiSelect
                                        options={this.state.documentVersion}
                                        standards={this.state.selectedDocVer}
                                        handleChange={(e) => this.handleChangeMultiSelect(e, "selectedDocVer")}
                                    />
                                </div>
                                <label>
                                    {t('Person name:')}
                                </label>
                                <div className="input_sw mb-3">
                                    <MultiSelect
                                        options={this.state.personName}
                                        standards={this.state.selectedPerName}
                                        handleChange={(e) => this.handleChangeMultiSelect(e, "selectedPerName")}
                                    />
                                </div>
                                <label>
                                    {t('Manual name:')}
                                </label>
                                <div className="input_sw mb-3">
                                    <MultiSelect
                                        style={{ marginBottom: '20px' }}
                                        options={this.state.manualName}
                                        standards={this.state.selectedManName}
                                        handleChange={(e) => this.handleChangeMultiSelect(e, "selectedManName")}
                                    />
                                </div>

                            </div>
                            <div className='col-md-7 card-body readunderstand-folder pt-2 pb-2'>
                                {this.countOfCurrentVsActive()}
                                <div className="read-listof-data">
                                    {this.displayDocView()}
                                </div>
                                 <reactbootstrap.Button className="mt-2" onClick={() => this.constructExportData(this.state.currentDetails, this.state.documentDetails)}>{t("Export XLS")}</reactbootstrap.Button>
                            </div>
                        </div>
                    </div>
                </div >)
        } else {
            return (<div>
                <h5>t{t(this.state.progressShow)}</h5>
            </div>)
        }
    }



    componentDidMount() {
        datasave.service(window.GET_DRAFTDATE_DOC_DETAILS, "POST", { data: this.props.location.data })
            .then(result => {
                if (result['status'] == 200) {
                    this.setState({
                        documentDetails: result['data'],
                        currentDetails: this.keyInsertion(result['data']),
                        totalCount: this.keyInsertion(result['data']),
                        documentName: result['DocumentName'],
                        documentCode: result['DocumentCode'],
                        documentVersion: result['DocumentVersion'],
                        manualName: result['ManualName'],
                        personName: result['PersonName'],
                        status: true
                    })
                } else {
                    this.setState({
                        progressShow: 'No data'
                    })
                }
            })
    }
}
export default translate(DocumentMangeListEventView);
