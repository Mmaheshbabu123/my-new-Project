import React, { Component } from 'react';
import { datasave } from '../_services/db_services';
import DocumentManageList from '../Reports/DocumentMangeList';
import TodoDocStatus from '../Reports/TodoDocStatus';
import DocumentStatusAll from '../Reports/DocumentStatusAll';
import TodoStatusDueDate from '../Reports/TodoStatusDueDate';
import ReadUnderstandDue from '../Reports/ReadUnderstandDue';
import ReadUnderstandStatus from '../Reports/ReadUnderstandStatus';
import Grafiektitel from '../Reports/Grafiektitel';
import ReviewDueDate from '../Reports/ReviewDueDate';
import ReviewDoc from '../Reports/ReviewDoc';
import TodoAllDoc from '../Reports/TodoAllDoc'
import GrafiekDoc from '../Reports/GrafiekDoc';
import GrafiekReadUn from '../Reports/GrafiekReadUn';
import IntiatedTodo from '../Reports/IntiatedTodo';
import TotalAndRejTodo from '../Reports/TotalAndRejTodo';
import GrafiekOpenTodos from '../Reports/GrafiekOpenTodos';
import GrafiekAverageDue from '../Reports/GrafiekAverageDue';
import LayoutConBothRej from '../Reports/LayoutConBothRej';
import OpenTodoAmountDue from '../Reports/OpenTodoAmountDue';
import LeadTimeView from '../Reports/LeadTimeView';
import RejectionReason from '../Reports/RejectionReason';
import { OCAlert } from '@opuscapita/react-alerts';
import { store } from '../store';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from '../language';
import { CanPermissions } from '../_components/CanComponent/CanPermissions';

class ExistReportDisplay extends Component {
    constructor(props) {
        super(props);
        let reportStorageData1 = JSON.parse(localStorage.getItem('reportStorageData1'));
        this.state = {
            status: false,
            dueDateDetails: [],
            dueDateChartData: [],
            todoDetails: [],
            todoChartData: [],
            documentStatusDetails: [],
            documentChartData: [],
            todoRepDetails: [],
            todoRepChartData: [],
            readUnChartData: [],
            readUnDetails: [],
            readUnDueDetails: [],
            readUnDueChartData: [],
            progressShow: 'Loading.....',
            selectedReport: reportStorageData1&&reportStorageData1.selectedReport?reportStorageData1.selectedReport:1,
            favourites: [],
            t: props.t,

        }
        this.handleClick = this.handleClick.bind(this);
        this.handleInsert = this.handleInsert.bind(this);
        this.handleDelete = this.handleDelete.bind(this);


    }
    handleClick() {


    }
    handleOnChange(name, value) {
        this.setState({
            [name]: parseInt(value)
        })
        let reportStorageData1 = {
          [name]:parseInt(value),
        }
        localStorage.removeItem('reportStorageData1');
        localStorage.setItem('reportStorageData1', JSON.stringify(reportStorageData1));
    }
    displayReportNameList() {
      const {t} = this.state;
        var table = [];
        table.push(
          <select style={{padding: '5px'}} value={this.state.selectedReport} onChange={(e) => this.handleOnChange('selectedReport', e.target.value)}>
            {CanPermissions('DOC_all_reports,Overview_draft_docs', '') &&
              <option value={1}>{t("Draft documents - overview")}</option>
            }
            {CanPermissions('DOC_all_reports,Overview_docstatus_of_todos', '') &&
              <option value={2}>{t("To do’s document status - overview")}</option>
            }
            {CanPermissions('DOC_all_reports,Overview_docstatus_of_all', '') &&
              <option value={3}>{t("Document status - overview")}</option>
            }
            {CanPermissions('DOC_all_reports,Overview_docstatus_dd_passed', '') &&
              <option value={4}>{t("Average days past dd - document status")}</option>
            }
            {CanPermissions('DOC_all_reports,RU_ongoing_finished', '') &&
              <option value={5}>{t("R&U - due date info")}</option>
            }
            {CanPermissions('DOC_all_reports,R_n_U_in_reports', '') &&
              <option value={6}>{t("R&U - overview")}</option>
            }
            {CanPermissions('DOC_all_reports,Total_open_todos_person_level', '') &&
              <option value={7}>{t("Open to do’s - person level")}</option>
            }
            {CanPermissions('DOC_all_reports,Duedate_passed_in_nextmonth', '') &&
              <option value={8}>{t("Work load – documents to review past dd")}</option>
            }
            {CanPermissions('DOC_all_reports,Review_docs_in_next_12months', '') &&
              <option value={9}>{t("Upcoming work load - documents to review")}</option>
            }
            {CanPermissions('DOC_all_reports,All_oppen_tods', '') &&
              <option value={10}>{t("Open to do’s past dd")}</option>
            }
            {CanPermissions('DOC_all_reports,RU_doc_level', '') &&
              <option value={11}>{t("R&U – document level")}</option>
            }
            {CanPermissions('DOC_all_reports,RU_person_level', '') &&
              <option value={12}>{t("R&U - person level")}</option>
            }
            {CanPermissions('DOC_all_reports,Initiated_todos', '') &&
              <option value={13}>{t("Initiated to do's")}</option>
            }
            {CanPermissions('DOC_all_reports,Rejection_todos', '') &&
              <option value={14}>{t("Rejection to do’s – person level")}</option>
            }
            {CanPermissions('DOC_all_reports,Todos_person_level', '') &&
              <option value={15}>{t("To do’s – person level")}</option>
            }
            {CanPermissions('DOC_all_reports,Amount_of_todos', '') &&
              <option value={16}>{t("Average days past dd - person level")}</option>
            }
            {CanPermissions('DOC_all_reports,Layout_content_both_rejected', '') &&
              <option value={17}>{t("Rejection reasons – person level")}</option>
            }
            {CanPermissions('DOC_all_reports,Open_todos_passed_due_date', '') &&
              <option value={18}>{t("Amount of days past dd – document status")}</option>
            }
            {CanPermissions('DOC_all_reports,Cycle_leadtime', '') &&
              <option value={19}>{t("Cycle lead time")}</option>
            }
            {CanPermissions('DOC_all_reports,Rejection_resons', '') &&
              <option value={20}>{t("Rejection reasons – overview")}</option>
            }
        </select>);
        return table;

    }

    displayReport() {
        var table = [];
        const {t} =this.state;
        switch (this.state.selectedReport) {
            case 1:
                table.push(<DocumentManageList history={this.props.history} />);
                break;
            case 2:
                table.push(<TodoDocStatus history={this.props.history} />);
                break;
            case 3:
                table.push(<DocumentStatusAll history={this.props.history} />);
                break;
            case 4:
                table.push(<TodoStatusDueDate history={this.props.history} />);
                break;
            case 5:
                table.push(<ReadUnderstandDue history={this.props.history} />);
                break;
            case 6:
                table.push(<ReadUnderstandStatus history={this.props.history} />);
                break;
            case 7:
                table.push(<Grafiektitel history={this.props.history} />);
                break;
            case 8:
                table.push(<ReviewDueDate history={this.props.history} />);
                break;
            case 9:
                table.push(<ReviewDoc history={this.props.history} />);
                break;
            case 10:
                table.push(<TodoAllDoc history={this.props.history} />);
                break;
            case 11:
                table.push(<GrafiekDoc history={this.props.history} />);
                break;
            case 12:
                table.push(<GrafiekReadUn history={this.props.history} />);
                break;
            case 13:
                table.push(<IntiatedTodo />);
                break;
            case 14:
                table.push(<TotalAndRejTodo />);
                break;
            case 15:
                table.push(<GrafiekOpenTodos />);
                break;
            case 16:
                table.push(<GrafiekAverageDue />);
                break;
            case 17:
                table.push(<LayoutConBothRej history={this.props.history} />);
                break;
            case 18:
                table.push(<OpenTodoAmountDue />);
                break;
            case 19:
                table.push(<LeadTimeView />);
                break;
            case 20:
                table.push(<RejectionReason />);
                break;
            case 21:
                break;
            case 22:
                break;
            case 23:
                break;
            case 24:
                break;
            case 25:
                break;
            case 26:
                break;
            default:
            OCAlert.alertFailure(t('invalid selection'), { timeOut: window.TIMEOUTNOTIFICATION })
                break;

        }
        return table;
    }
    displayFavButton() {
        const {t} =this.state;
        var table = [];
        let favourites = this.state.favourites;
        if (favourites.indexOf(this.state.selectedReport) > -1) {
            table.push(
                <reactbootstrap.Button  style={{marginLeft: '10px'}} onClick={this.handleDelete}>{t("Remove from favorites")}</reactbootstrap.Button>
            )
        } else {
            table.push(
                <reactbootstrap.Button style={{marginLeft: '10px'}} onClick={this.handleInsert}>{t("Add to favorites")}</reactbootstrap.Button>
            )
        }

        return table;
    }

    handleInsert() {
        let Userdata = store.getState();
        const {t} =this.state;
        let person_id = Userdata.UserData.user_details.person_id
        datasave.service(window.INSERT_FAV_REPORT + '/' + person_id + '/' + this.state.selectedReport, "GET")
            .then(result => {
                if (result['status'] == 200) {
                    if (result['data'] != 0) {
                        this.handleGetReport();
                        // this.props.history.push('/practicefile');
                        console.log('Insertion Successfull');
                    } else {
                        // this.props.history.push('/reports');
                        console.log('Insertion Unsuccessfull');
                    }
                } else {
                  OCAlert.alertFailure(t('Error please try again'), { timeOut: window.TIMEOUTNOTIFICATION })
                }
            });

    }

    handleDelete() {
        let Userdata = store.getState();
        const {t} =this.state;
        let person_id = Userdata.UserData.user_details.person_id
        datasave.service(window.DELETE_FAV_REPORT + '/' + person_id + '/' + this.state.selectedReport, "GET")
            .then(result => {
                if (result['status'] == 200) {
                    if (result['data'] != 0) {
                        console.log('Deletion Successfull');
                        this.handleGetReport();
                    } else {
                        console.log('Deletion Unsuccessfull');
                    }
                } else {
                  OCAlert.alertFailure(t('Error please try again'), { timeOut: window.TIMEOUTNOTIFICATION })
                }
            });
    }

    render() {

        return (
            < div className="container p-5">
                {/* <input type='text' onChange={(e) => { this.handleOnChangeText(e.target.value) }}>
                </input> */}
                {this.displayReportNameList()}
                {this.displayFavButton()}
                {this.displayReport()}
            </div >)

    }


    handleGetReport() {
        let Userdata = store.getState();
        let person_id = Userdata.UserData.user_details.person_id
        datasave.service(window.GET_FAV_REPORT + '/' + person_id + '/' + this.state.selectedReport, "GET")
            .then(result => {
                if (result['status'] == 200) {
                    this.setState({
                        favourites: result['data']
                    })

                } else {
                    console.log('Error in getting favourites');
                    this.setState({
                        favourites: result['data']
                    })

                }
            });
    }

    componentDidMount() {
      console.log('did mount called');
        this.handleGetReport();

    }

}
export default translate(ExistReportDisplay);
