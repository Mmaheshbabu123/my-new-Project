import React, { Component } from 'react';
import Chart from 'react-google-charts';
import * as reactbootstrap from 'react-bootstrap'
import { datasave } from '../_services/db_services'
import { log } from 'util';
import { translate } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
class IntiatedTodo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            IntialChartData: [],
            fromDate: '',
            toDate: '',
            progressShow: 'Loading',
            dropDownValue: 1,
            textVal: 30,
            radioVal: 2,
            t: props.t,
        }
        this.handleOnChange = this.handleOnChange.bind(this);
    }
    handleOnChange(event, name) {
        this.setState({
            [name]: event.target.value
        })

    }

    handleDropDown(e) {
        console.log(e.target.value);
        this.setState({
            dropDownValue: parseInt(e.target.value),
            textVal: 0
        })
    }

    handleRadioChange(e, name) {
        this.setState({
            [name]: e.target.value,
            fromDate: '',
            toDate: ''
        })
    }

    handleTextChange(e, name) {
        var d = new Date();
        var d2 = new Date();
        var currentDay = '' + d.getDate();
        var currentMonth = d.getMonth() + 1 + '';
        var currentYear = d.getFullYear();

        var toDate = [currentYear, currentMonth.length < 2 ? '0' + currentMonth : currentMonth, currentDay.length < 2 ? '0' + currentDay : currentDay].join('-');

        if (e.target.value != '' || e.target.value != 0) {
            switch (this.state.dropDownValue) {
                case 1:
                    var date = d2.getDate() - e.target.value;
                    d2.setDate(date);
                    break;
                case 2:
                    var month = d2.getMonth() - e.target.value;
                    d2.setMonth(month);
                    break;
                case 3:
                    var year = d2.getFullYear() - e.target.value;
                    console.log(year);
                    d2.setFullYear(year);
                    break;
                default:
                    break;
            }
        }
        var d2Date = '' + d2.getDate();
        var d2Month = d2.getMonth() + 1 + '';

        this.setState({
            [name]: e.target.value,
            toDate: toDate,
            fromDate: [d2.getFullYear(), d2Month.length < 2 ? '0' + d2Month : d2Month, d2Date.length < 2 ? '0' + d2Date : d2Date].join('-')
        })
    }


    handleSubmit() {
        const { t } = this.state;
        if (this.state.fromDate != '' && this.state.toDate != '') {

            if (new Date(this.state.fromDate) <= new Date(this.state.toDate)) {
                this.handleService(this.state.fromDate, this.state.toDate);
            } else {
                  OCAlert.alertWarning(t('Please enter valid date'), { timeOut: window.TIMEOUTNOTIFICATION });
            }
        } else {
            console.log('Error');
        }
    }

    handleService(fromDate, toDate, name, value) {
        datasave.service(window.INTIATED_TODO + '/' + fromDate + '/' + toDate, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {

                    this.setState({

                        IntialChartData: result['IntialChartData'],
                        status: true,
                        fromDate: fromDate,
                        toDate: toDate,
                        [name]: value
                    })
                } else {
                    this.setState({
                        status: true,
                        progressShow: 'No Data'
                    })
                }

            })
    }

    render() {
        const { t } = this.state;
        return <div className="container p-5">
            <div className="mb-4"><h5>{t("Initiated todo's")}</h5></div>
            <div className="mb-3">
                <div>
                    <label style={{ display: 'inline-flex' }}>
                        <input type="radio" value={1} checked={(this.state.radioVal == 1) ? true : false} name="filter" label='a' onChange={(e) => this.handleRadioChange(e, 'radioVal')}></input>
                        {t('Sort by from date - to dat')}
                    </label>
                </div>
                <div>
                    <label style={{ display: 'inline-flex' }}>
                        <input type="radio" value={2} name="filter" checked={(this.state.radioVal == 2) ? true : false} label='b' onChange={(e) => this.handleRadioChange(e, 'radioVal')}></input>
                        {t('Sort by number of days/months/years')}
                    </label>
                </div>
            </div>

            <div style={{ display: this.state.radioVal == 1 ? 'block' : 'none' }}>
                <label >
                    {t('From date')}
                    <input type="date" value={this.state.fromDate} onChange={(e) => { this.handleOnChange(e, 'fromDate') }}></input>
                </label>
                <label >
                    {t('To date')}
                    <input type="date" value={this.state.toDate} onChange={(e) => { this.handleOnChange(e, 'toDate') }}></input>
                </label>
                <reactbootstrap.Button onClick={(e) => this.handleSubmit()}>
                    {t('Submit')}
                </reactbootstrap.Button>
            </div>

            <div className="mb-3" style={{ display: this.state.radioVal == 2 ? 'block' : 'none' }}>

                <label className="mr-1" >

                    <input style={{ padding: '5px' }} className="input_sw" type={'text'} value={this.state.textVal} onChange={(e) => this.handleTextChange(e, 'textVal')} />

                </label>
                <select style={{ padding: '6px' }} className="input_sw mr-1" value={this.state.dropDownValue} onChange={(e) => this.handleDropDown(e)}>
                    <option value={1}>{t('Day')}</option>
                    <option value={2}>{t('Month')}</option>
                    <option value={3}>{t('Year')}</option>
                </select>
                <reactbootstrap.Button style={{ padding: '4px 10px' }} onClick={(e) => this.handleSubmit()}>
                    {t('Submit')}
                </reactbootstrap.Button>
            </div>


            {this.state.status &&
                <Chart
                    // width={'1000px'}
                    // height={'500px'}
                    chartType="PieChart"
                    loader={<div>{t('Loading chart')}</div>}


                    data={
                        this.state.IntialChartData
                    }
                    options={{
                        // title: t('Initiated'),
                        is3D: true,
                        sliceVisibilityThreshold: 0,
                        width: '100%',
                        height: '100%',
                        chartArea: {
                            height: "80%",
                            // left: "15%",
                            width: "100%"
                        },
                        legend: {
                            maxLines: 1,
                            textStyle: {
                                fontSize: window.REPORT_FONT_SIZE
                            }
                        },
                    }} />}

        </div>

    }
    componentDidMount() {
        var fromDate = '';
        var toDate = '';

        datasave.service(window.GET_DEFAULT_REPNUM, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {
                    var textVal = parseInt(result['value']);
                    if (result['value'] == 0) {
                        textVal = 30
                    }
                    var d = new Date();
                    var d2 = new Date();
                    var currentDay = '' + d.getDate();
                    var currentMonth = d.getMonth() + 1 + '';
                    var currentYear = d.getFullYear();
                    var date = d2.getDate() - textVal;
                    d2.setDate(date);
                    var d2Date = '' + d2.getDate();
                    var d2Month = d2.getMonth() + 1 + '';
                    fromDate = [d2.getFullYear(), d2Month.length < 2 ? '0' + d2Month : d2Month, d2Date.length < 2 ? '0' + d2Date : d2Date].join('-');
                    toDate = [currentYear, currentMonth.length < 2 ? '0' + currentMonth : currentMonth, currentDay.length < 2 ? '0' + currentDay : currentDay].join('-');
                    this.handleService(fromDate, toDate, 'textVal', textVal);
                }

            })



    }

}
export default translate(IntiatedTodo);
