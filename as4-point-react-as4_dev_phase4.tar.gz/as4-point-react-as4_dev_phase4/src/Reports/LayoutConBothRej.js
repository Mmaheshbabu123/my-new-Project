import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
import { OCAlert } from '@opuscapita/react-alerts';
class LayoutConBothRej extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            lCBChartData: [],
            lCBDetails: [],
            progressShow: 'Loading',
            t: props.t,
            multiOption: [],
            multiSelection: [],
            FilterData: [],
        }
    }

    handleOnClick(data) {
      const {t} =this.state;

        if (data.length > 0) {
            this.props.history.push({
                pathname: '/lcb_rej_eventview',
                data: data // your data array of objects
            })
        } else {
                OCAlert.alertWarning(t('no data'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
    }

    getMultiSelectNames(data) {
        var resultName = [];
        data.map(key => {
            resultName.push({ label: key[0], value: key[0] })
        })

        return resultName;
    }

    handleChangeMultiSelect(e) {
        var selectedData = e;
        var graphiekData = this.state.lCBChartData;


        if (selectedData.length > 0) {
            // var filterData = [graphiekData[0]];
            var filterData = [];
            selectedData.map(key => {
                graphiekData.map(key1 => {
                    if (key1[0] == key['value']) {
                        filterData.push(key1)
                    }
                })
            })
            this.handleSetState('multiSelection', selectedData, 'FilterData', filterData);
        } else {
            this.handleSetState('multiSelection', e, 'FilterData', graphiekData);
        }
    }

    handleSetState(name1, value1, name2, value2) {
        this.setState({
            [name1]: value1,
            [name2]: value2
        })
    }


    displayChartData() {
        const { t } = this.state;
        let table = [];
        if (this.state.FilterData != '' && this.state.FilterData != []) {
            this.state.FilterData.map(key => {
                table.push(
                    <Chart
                        // width={'500px'}
                        // height={'250px'}
                        chartType="PieChart"
                        loader={<div>{t('Loading chart')}</div>}
                        data={
                            key[1]
                        }
                        options={{
                            title: key[0],
                            is3D: true,
                            sliceVisibilityThreshold: 0,
                            width: '100%',
                            height: '100%',
                            chartArea: {
                                height: "80%",
                                // left: "15%",
                                width: "100%"
                            },
                            legend: {
                                maxLines: 1,
                                textStyle: {
                                    fontSize: window.REPORT_FONT_SIZE
                                }
                            },
                            colors: ['rgb(184, 228, 249)', 'orange', 'grey']

                        }}
                        chartEvents={[
                            {
                                eventName: 'select',
                                callback: ({ chartWrapper }) => {
                                    const chart = chartWrapper.getChart()
                                    const selection = chart.getSelection();



                                    if (selection.length === 1) {
                                        const [selectedItem] = selection
                                        const dataTable = chartWrapper.getDataTable()


                                        const { row } = selectedItem
                                        let columnName = dataTable.getValue(row, 0);
                                        let personName = key[0].substr(key[0].indexOf(' ')).trim();

                                        // let keyName = (value.substr(0, value.indexOf('('))).trim();

                                        this.handleOnClick(this.state.lCBDetails[personName][columnName]);
                                        // alert(
                                        //     'You selected : ' +
                                        //     JSON.stringify({
                                        //         // row,
                                        //         // column,
                                        //         value: keyName,
                                        //         // name: dataTable.getColumnLabel(row, column),


                                        //         // name: selection

                                        //     }),
                                        //     null,
                                        //     2,
                                        // )

                                    }

                                },
                            },
                        ]}
                    />
                )
            })
        }
        return table;
    }


    render() {
        const { t } = this.state;
        if (this.state.status) {
            return <div>
                <h5>{t("Rejection reasons – person level")}</h5>
                <label>
                    {t('Persons')}
                </label>
                <MultiSelect
                    options={this.state.multiOption}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.multiSelection}
                    handleChange={(e) => this.handleChangeMultiSelect(e)}
                />
                {this.displayChartData()}
            </div>
        } else {
            return (<div>{t('Loading...')}'</div>)
        }
    }
    componentDidMount() {
        datasave.service(window.LCB_REJ_VIEW, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {

                    this.setState({
                        lCBChartData: result['LCBChartData'],
                        lCBDetails: result['LCBDetails'],
                        FilterData: result['LCBChartData'],
                        multiOption: this.getMultiSelectNames(result['LCBChartData']),
                        status: true,
                    })
                } else {
                    this.setState({
                        status: true,
                        progressShow: 'No Data'
                    })
                }

            })

    }
}
export default translate(LayoutConBothRej);
