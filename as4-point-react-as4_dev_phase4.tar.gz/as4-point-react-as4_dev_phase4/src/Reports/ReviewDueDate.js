import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services'
import { translate } from '../language';
import { OCAlert } from '@opuscapita/react-alerts';
class ReviewDueDate extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            reviewDueChartData: [],
            reviewDueDetails: [],
            progressShow: 'Loading',
            t: props.t,
        }
    }

    handleOnClick(data) {
      const {t} = this.state;
        if (data.length > 0) {
            this.props.history.push({
                pathname: '/reviewduedateeventview',
                data: data // your data array of objects
            })
        } else {
  OCAlert.alertWarning(t('no data'), { timeOut: window.TIMEOUTNOTIFICATION })
        }

    }

    render() {
        const { t } = this.state;
        if (this.state.status) {
     return (<div className='container-fluid mt-3'>
     <Chart
      width={1000}
      height={500}
      chartType="ColumnChart"
      loader={<div>Loading Chart</div>}
      data={this.state.reviewDueChartData}
      options={{
        chart: {
          title: t('Work load – documents to review past dd'),
        },
        is3D: true,
        legend: {
          position: 'right',
          alignment: 'center',
          width: '50px',
          floating: true,
        },
        width: '100%',
        height: '100%',
        chartArea: {
        // height: "100%",
        // width: "50%"
        },
        legend: {
         maxLines: 1,
         textStyle: {
          fontSize: window.REPORT_FONT_SIZE
         }
        },
        }}
        chartEvents={[
                      {
                        eventName: 'select',
                        callback: ({ chartWrapper }) => {
                        const chart = chartWrapper.getChart()
                        const selection = chart.getSelection();
                        if (selection.length === 1) {
                        const [selectedItem] = selection
                        const dataTable = chartWrapper.getDataTable()
                        const { row } = selectedItem
                        let value = dataTable.getValue(row, 0);
                        console.log('value');
                        console.log(value);
                       // let keyName = (value.substr(0, value.indexOf('('))).trim();
                      //  this.handleOnClick(this.state.reviewDueDetails[keyName]);
                        this.handleOnClick(this.state.reviewDueDetails[value]);
                        }
                       },
                     },
                    ]}
        />
        </div>);
        } else {
            return (<div>{t('Loading')}</div>)
        }
    }

    componentDidMount() {
        datasave.service(window.REVIEW_DUE_DATE, "GET")
            .then(result => {

                if (result != '' && result.length != 0) {
                    this.setState({
                        reviewDueChartData: result['ReviewDueChartData'],
                        reviewDueDetails: result['ReviewDueDetails'],
                        status: true,
                    })
                } else {
                    this.setState({
                        status: true,
                        progressShow: 'No Data'
                    })
                }

            })

    }
 
                /*<Chart
                    chartType="PieChart"
                    loader={<div>{t('Loading chart')}</div>}
                    data={
                        this.state.reviewDueChartData
                    }
                    options={{
                        title: t('Work load – documents to review past dd'),
                        is3D: true,
                        sliceVisibilityThreshold: 0,
                        width: '100%',
                        height: '100%',
                        chartArea: {
                            height: "80%",
                            width: "100%"
                        },
                        legend: {
                            maxLines: 1,
                            textStyle: {
                                fontSize: window.REPORT_FONT_SIZE
                            }
                        },
                    }}
                    chartEvents={[
                        {
                            eventName: 'select',
                            callback: ({ chartWrapper }) => {
                                const chart = chartWrapper.getChart()
                                const selection = chart.getSelection();
                                if (selection.length === 1) {
                                    const [selectedItem] = selection
                                    const dataTable = chartWrapper.getDataTable()
                                    const { row } = selectedItem
                                    let value = dataTable.getValue(row, 0);
                                    let keyName = (value.substr(0, value.indexOf('('))).trim();
                                    this.handleOnClick(this.state.reviewDueDetails[keyName]);
                                }
                            },
                        },
                    ]} />*/
}
export default translate(ReviewDueDate)
