import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
import { OCAlert } from '@opuscapita/react-alerts';

class GrafiekReadUn extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            grafReadUnChartData: [],
            grafReadUnDetails: [],
            progressShow: 'Loading',
            t: props.t,
            FilterData: [],
            multiOption: [],
            multiSelection: [],
        }
    }

    getMultiSelectNames(data) {

        var length = data.length;
        var resultName = [];
        if (length > 1) {
            for (var i = 1; i < length; i++) {
                resultName.push({ label: data[i][0], value: data[i][0] })

            }
        }
        return resultName;
    }

    handleChangeMultiSelect(e) {
        var selectedData = e;
        var graphiekData = this.state.grafReadUnChartData;

        if (selectedData.length > 0) {
            var filterData = [graphiekData[0]];

            selectedData.map(key => {
                graphiekData.map(key1 => {
                    if (key1[0] == key['value']) {
                        filterData.push(key1)
                    }
                })
            })
            this.handleSetState('multiSelection', selectedData, 'FilterData', filterData);
        } else {
            this.handleSetState('multiSelection', e, 'FilterData', graphiekData);
        }




        // this.setState({
        //     multiSelection: e,
        //     FilterData: filterData
        // })
    }

    handleSetState(name1, value1, name2, value2) {
        this.setState({
            [name1]: value1,
            [name2]: value2
        })
    }

    handleOnClick(data) {
        const { t } = this.state;
        if (data.length > 0) {
            this.props.history.push({
                pathname: '/grafreaduneventview',
                data: data // your data array of objects
            })
        } else {
                  OCAlert.alertWarning(t('no data'), { timeOut: window.TIMEOUTNOTIFICATION });
        }
    }
    displayChart() {

        var table = [];
        var tempArr = [];
        var GrafieData = this.state.FilterData;

        if (GrafieData.length > 0) {

            if (GrafieData.length > 6) {
                tempArr.push(GrafieData[0]);
                console.log(tempArr);

                for (var i = 0; i < GrafieData.length; i++) {
                    tempArr.push(GrafieData[i + 1]);
                    if ((i + 1) % 5 == 0) {
                        console.log(tempArr);
                        table.push(this.getChart(tempArr));
                        tempArr = [GrafieData[0]]
                    }
                }
                if ((GrafieData.length - 1) % 5 != 0) {
                    var rem = parseInt((GrafieData.length - 1) % 5);
                    var startIndex = (GrafieData.length) - rem;
                    tempArr = [GrafieData[0]];
                    var remForScale = 5 - rem;
                    for (var j = startIndex; j < GrafieData.length + remForScale; j++) {
                        if (GrafieData[j] != undefined) {
                            tempArr.push(GrafieData[j]);
                        } else {
                            tempArr.push([' ', 0, 0, 0, 0]);
                        }

                    }
                    table.push(this.getChart(tempArr));
                }
            } else {
                table.push(this.getChart(GrafieData));
            }
        }
        return table;

    }

    getChart(grafReadUnChartData) {
        const { t } = this.state;
        return (
            <Chart
                width={'1000px'}
                height={'500px'}
                chartType="BarChart"
                loader={<div>{t("Loading chart")}</div>}
                data={grafReadUnChartData}
                options={{
                    // title: t(''),
                    // width: '100%',
                    // height: '100%',
                    // chartArea: {
                    //     height: "100%",
                    //     width: "60%"
                    // },
                    isStacked: 'true',

                    colors: ['darkgreen', 'orange', 'lightblue', 'red'],
                    hAxis: {
                        title: '',
                        // minValue: 0,
                        // maxValue: 30,
                        // gridlines: { count: 30 / 2 },


                    },
                    vAxis: {
                        title: t('people'),


                    },
                    legend: {
                        maxLines: 1,
                        textStyle: {
                            fontSize: window.REPORT_FONT_SIZE
                        }
                    },

                }}
                chartEvents={[
                    {
                        eventName: 'select',
                        callback: ({ chartWrapper }) => {
                            const chart = chartWrapper.getChart()
                            const selection = chart.getSelection();



                            if (selection.length === 1) {
                                const [selectedItem] = selection
                                const dataTable = chartWrapper.getDataTable()


                                const { row, column } = selectedItem
                                let columnName = dataTable.getColumnLabel(column).trim();
                                let personName = dataTable.getValue(row, 0).trim();
                                   dataTable.getValue(row, column);

                                this.handleOnClick(this.state.grafReadUnDetails[personName][columnName]);

                                // console.log(dataTable.getColumnLabel(column));
                                // console.log(row);
                                // console.log(column);
                                // let value = dataTable.getValue(row, 0);
                                // console.log(value);
                                // let keyName = (value.substr(0, value.indexOf('('))).trim();

                                // this.handleOnClick(this.state.documentStatusDetails['DocDetails'][keyName]);
                                // alert(
                                //     'You selected : ' +
                                //     JSON.stringify({
                                //         // row,
                                //         // column,
                                //         value: keyName,
                                //         name: value,


                                //         // name: selection

                                //     }),
                                //     null,
                                //     2,
                                // )

                            }

                        },
                    },
                ]}
            />

        )
    }
    render() {
        const { t } = this.state;
        if (this.state.status) {
            return <div>
                <h5>{t("R&U - person level")}</h5>
                <label>
                    {t('Persons')}
                </label>
                <MultiSelect
                    options={this.state.multiOption}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.multiSelection}
                    handleChange={(e) => this.handleChangeMultiSelect(e, "selectedDocCode")}
                />
                {this.displayChart()}
            </div>
        } else {
            return (<div>{t('Loading')}</div>)
        }
    }

    componentDidMount() {
      const {t} =this.state;
        datasave.service(window.GRAFIEK_READUN, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {
                    this.setState({
                        grafReadUnChartData: result['GrafReadUnChartData'],
                        grafReadUnDetails: result['GrafReadUnDetails'],
                        FilterData: result['GrafReadUnChartData'],
                        multiOption: this.getMultiSelectNames(result['GrafReadUnChartData']),
                        status: true,
                    })
                } else {
                    this.setState({
                        status: true,
                        progressShow: t('No Data')
                    })
                }

            })

    }
}
export default translate(GrafiekReadUn);
