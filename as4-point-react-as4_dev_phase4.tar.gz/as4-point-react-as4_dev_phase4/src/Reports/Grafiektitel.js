import React, { Component } from 'react';
import Chart from 'react-google-charts';
import { datasave } from '../_services/db_services';
import { translate } from '../language';
import MultiSelect from '../_components/MultiSelect';
class Grafiektitel extends Component {
    constructor(props) {
        super(props);
        this.state = {
            status: false,
            grafiekChartData: [],
            grafiekDetails: [],
            progressShow: 'Loading',
            t: props.t,
            multiOption: [],
            multiSelection: [],
            FilterData: [],
            maxValue:0
        }
    }
    displayChart() {

        var table = [];
        var tempArr = [];
        var GrafieData = this.state.FilterData;

        if (GrafieData.length > 0) {

            if (GrafieData.length > 4) {
                tempArr.push(GrafieData[0]);
                console.log(tempArr);

                for (var i = 0; i < GrafieData.length; i++) {
                    tempArr.push(GrafieData[i + 1]);
                    if ((i + 1) % 3 == 0) {
                        console.log(tempArr);
                        table.push(this.getChart(tempArr));
                        tempArr = [GrafieData[0]]
                    }
                }
                if ((GrafieData.length - 1) % 3 != 0) {
                    var rem = parseInt((GrafieData.length - 1) % 3);
                    var startIndex = (GrafieData.length) - rem;
                    tempArr = [GrafieData[0]];
                    var remForScale = 3 - rem;
                    for (var i = startIndex; i < GrafieData.length + remForScale; i++) {
                        if (GrafieData[i] != undefined) {
                            tempArr.push(GrafieData[i]);
                        } else {
                            tempArr.push([' ', 0, 0, 0]);
                        }

                    }
                    table.push(this.getChart(tempArr));
                }
            } else {
                table.push(this.getChart(GrafieData));
            }
        }
        return table;

    }
    getMultiSelectNames(data) {

        var length = data.length;
        var resultName = [];
        if (length > 1) {
            for (var i = 1; i < length; i++) {
                resultName.push({ label: data[i][0], value: data[i][0] })

            }
        }
        return resultName;
    }

    handleOnClick(data) {
const {t} =this.state;

        if (data.length > 0) {
            this.props.history.push({
                pathname: '/grafiekeventview',
                data: data // your data array of objects
            })
        } else {
            alert(t('no data'));
        }
    }

    getChart(grafiekChartData) {
        const { t,  maxValue} = this.state;
        return (
            <Chart
                // width={'1000px'}
                // height={'500px'}
                chartType="Bar"
                loader={<div>{t("Loading chart")}</div>}
                data={grafiekChartData}
                options={{
                    chart: {
                        title: t("Open to do’s - person level"),
                    },
                    is3D: true,
                    legend: {
                        position: 'right',
                        alignment: 'center',
                        width: '50px',
                        floating: true,

                    },
                    width: '100%',
                    height: '100%',
                    chartArea: {
                        height: "100%",
                        width: "50%"
                    },
                    legend: {
                        maxLines: 1,
                        textStyle: {
                            fontSize: window.REPORT_FONT_SIZE
                        }
                    },
                    axes: {
                      y: {
                          all: {
                              range: {
                                  max: maxValue,
                                  min: 0
                              }
                          }
                      }
                  },
                }}
                chartEvents={[
                    {
                        eventName: 'select',
                        callback: ({ chartWrapper }) => {
                            const chart = chartWrapper.getChart()
                            const selection = chart.getSelection();
                            if (selection.length === 1) {
                                const [selectedItem] = selection
                                const dataTable = chartWrapper.getDataTable()
                                const { row, column } = selectedItem
                                let columnName = dataTable.getColumnLabel(column).trim();
                                let personName = dataTable.getValue(row, 0).trim();
                                this.handleOnClick(this.state.grafiekDetails[personName][columnName]);
                            }
                        },
                    },
                ]}

            />


        )
    }

    handleChangeMultiSelect(e) {
        var selectedData = e;
        var graphiekData = this.state.grafiekChartData;

        if (selectedData.length > 0) {
            var filterData = [graphiekData[0]];

            selectedData.map(key => {
                graphiekData.map(key1 => {
                    if (key1[0] == key['value']) {
                        filterData.push(key1)
                    }
                })
            })
            this.handleSetState('multiSelection', selectedData, 'FilterData', filterData);
        } else {
            this.handleSetState('multiSelection', e, 'FilterData', graphiekData);
        }




        // this.setState({
        //     multiSelection: e,
        //     FilterData: filterData
        // })
    }

    handleSetState(name1, value1, name2, value2) {
        this.setState({
            [name1]: value1,
            [name2]: value2
        })
    }

    render() {
        const { t } = this.state;
        if (this.state.status) {
            return <div>
                <h3>{t("Total open document to do's (person level)")}</h3>
                <label>
                    {t('Persons')}
                </label>
                <MultiSelect
                    options={this.state.multiOption}
                    // disabled={[{ label: 'jagadish', value: '1' }]}
                    standards={this.state.multiSelection}
                    handleChange={(e) => this.handleChangeMultiSelect(e)}
                />
                {this.displayChart()}
            </div>
        } else {
            return (<div>{t('Loading')}</div>)
        }
    }

    componentDidMount() {
        datasave.service(window.GRAFIEK_REPORTS, "GET")
            .then(result => {
                if (result != '' && result.length != 0) {
                    this.setState({
                        grafiekChartData: result['GrafiekChartData'],
                        grafiekDetails: result['GrafiekDetails'],
                        FilterData: result['GrafiekChartData'],
                        maxValue : result['maxValue'],
                        multiOption: this.getMultiSelectNames(result['GrafiekChartData']),
                        status: true,
                    })
                } else {
                    this.setState({
                        status: true,
                        progressShow: 'No Data'
                    })
                }

            })

    }
}
export default translate(Grafiektitel);
