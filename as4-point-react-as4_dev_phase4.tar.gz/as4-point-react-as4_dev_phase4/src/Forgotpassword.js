import React, { Component } from 'react';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import axios from 'axios';
import {translate} from './language';
const base64 = require('base-64');

class ForgotPassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      submitted: 'false',
      email: '',
      showError: '',
      messageFromServer: '',
      t:props.t,
    };
  }

  handleChange = name => (event) => {
    this.setState({
      [name]: event.target.value,
    });
  };

  sendEmail = (event) => {
    event.preventDefault();

    this.setState({
      submitted: 'true',
    })
    const encryptedEmail = base64.encode(this.state.email.toLowerCase());

    axios.get(window.backendURL + `/api/user/forgotpassword/${encryptedEmail}`, {headers: {"Authorization": "Bearer " + process.env.REACT_APP_key}})
    .then(response => {
      if (response.data === 'invalid email') {
        this.setState({
                showError: response.data,
                messageFromServer: '',
              });
      } else if (response.data === 'Error in sending mail') {
        this.setState({
          showError: response.data,
          messageFromServer: '',
        });
      } else if (response.data === 'Mail has been sent') {
        this.setState({
          showError: '',
          messageFromServer: response.data,
        });
        }
    })
  };


  handleKeyPress = event => {
    console.log(event.key)
    if (event.key == 'Enter') {
      this.sendEmail(event);
    }
  }

  render() {
    const { email, submitted, messageFromServer,showError,t } = this.state;
    return (
        <div className="container" className="container-fluid fulll-body" style={{ overflow: "auto" }} onKeyPress={e => this.handleKeyPress(e)}>
          <div className="row justify-content-center">
              <div className="col-md-7 mt-5">
                  <div className="card">
                      <div className="card-header">{t('Forgot password')}</div>
                      <Container className="">
                          <Form onSubmit = { this.sendEmail } >

                              <FormGroup>
                                  <div class="row col-md-12 pt-5">
                                  <div className="col-md-3">
                                  <Label style={{color: '#EC661C'}}>{t('Email')}<span style={{ color: 'red' }}>  *</span></Label>
                                 </div>
                                   <div className="col-md-9">
                                  <Input
                                    id="email"
                                    type="email"
                                    name="email"
                                    placeholder={t("email@email")}
                                    value={this.state.email}
                                    onChange={event => this.setState({ email: event.target.value })}
                                    autoComplete="off"
                                    // required="1"
                                  />
                                  {submitted === 'true' && !email &&
                                    <div style={{ color: 'red' }} className="help-block">{t('Email is required')}</div>
                                  }
                                </div>
                                  </div>
                              </FormGroup>

                              <FormGroup>
                              <div style={{textAlign: 'right'}} className="col-lg-12  pr-5">
                                <Button className="btn btn-primary" type="submit" color="primary">{t('Send')}</Button>
                              </div>
                              </FormGroup>
                          </Form>
                      </Container>
                  </div>
              </div>
          </div>
        {messageFromServer === 'Mail has been sent' && (
          <div style={{textAlign: 'center', margin: '0px auto'}} className={'alert alert-success col-md-7 mt-5 mb-3'}>
            <p>{t('Reset password mail has been sent successfully.!')}</p>
          </div>
        )}
        {showError === 'invalid email' && (
          <div style={{textAlign: 'center',margin: '0px auto'}} className={'alert alert-danger col-md-7 mt-5 mb-3'}>
            <p>
              {t('That email address is not recognized. Please try again.')}
            </p>
          </div>
        )}
        {showError === 'Error in sending mail' && (
          <div style={{textAlign: 'center',margin: '0px auto'}} className={'alert alert-danger col-md-7 mt-5 mb-3'}>
            <p>{t('Mail has not sent ,something went wrong')}</p>
          </div>
        )}
      </div>
    );
  }
}

export default translate(ForgotPassword);
