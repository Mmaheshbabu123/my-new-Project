import React, { Component } from 'react'
import { BrowserRouter, Switch, Route, Redirect } from 'react-router-dom'
import { createBrowserHistory } from 'history'
import './App.css'
import Header from './_components/MainContent/Header';
import Routes from './_components/Routes';
import { datasave } from './_services/db_services';
import { translate, setLanguage, setDefaultTranslations, setDefaultLanguage, setTranslations, Language } from './language';
import en from './langjson/en.json';
import ch from './langjson/ch.json';
import Main from './_components/MainContent/Main'
import './_components/ManualComponent/manual.css'
import { connect } from "react-redux";
import Sitenotaccess from './sitenotaccess';
import PageNotfound from './_components/Errorpages/Pagenotfound'
import Forgotpassword from './Forgotpassword'
import Resetpassword from './Resetpassword'
import LoginScreen from './LoginScreen';
import Ifo from './Ifo';
import { PrivateRoute } from './_components/PrivateRoute';
import Useronetimelogin from './Useronetimelogin';
import { OCAlertsProvider } from '@opuscapita/react-alerts';
import { OCAlert } from '@opuscapita/react-alerts';
import { persistor, store } from './store';
import SetUserData from './Actions/SetUserData';
import ARSceneComponent from './AugmentedReality/Frontend/ARSceneComponent';
import KpiReportTabView from './Views/KpiReportTabView';
import { userService } from './_services/user.services';
import Websocket from 'react-websocket';
import NeedHelp from './_components/NeedHelp/NeedHelp';
import * as allDevices from "react-device-detect";
import AccessDeniedPage from './_components/Errorpages/AccessDenied';
import $ from 'jquery';
// import './images/overall.png'
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedLanguage: 'en',
      updateLanguage: 0,
      language: '',
      sitenotfound: true,
      sitesUpdate: 0,
      current_site_key : '',
    }
    let url = window.location.href;
    this.outsideApp = url.includes('downloadkpireport');
  }

  async componentWillMount() {
    let sitekey = this.getTheSiteName();
    if(this.outsideApp){
      await datasave.serviceForSitesJSON(window.GET_SITES_JSON + '/' + sitekey, 'GET')
      .then(response => {
        let siteData = response['siteData'] ? response['siteData']: '';
        if(siteData[sitekey] && siteData[sitekey].backend)
           window.backendURL = siteData[sitekey].backend;
        else
           window.backendURL = siteData['default'].backend
      })
      this.setState({renderPage: 1});
      return;
    }
    let backendurl = null;
    const localUser = localStorage.getItem('user');
    let userData = store.getState();

    datasave.serviceForSitesJSON(window.GET_SITES_JSON + '/' + sitekey, 'GET')
      .then(response => {
        let result = [];
        let status = false;
        localStorage.setItem('toc_download',response.toc_download);
        localStorage.setItem('kpi_enable',response.kpi_enable);
        localStorage.setItem('groundplan_enable',response.groundplan_enable);
        localStorage.setItem('blockbox_enable',response.blockbox_enable);
        localStorage.setItem('ar_enable',response.ar_enable);
        localStorage.setItem('kpi_dashboard_enable',response.kpi_dashboard_enable);
        localStorage.setItem('open_active_webform_documents',response.open_active_webform_documents);
        localStorage.setItem('kpi_todo',response.kpi_todo);
        Object.keys(response).some(item => {
          Object.keys(response.siteData).some(item1 => {
            if (sitekey == item1) {
                result = response.siteData;
                status = true;
            }
          })
        });

        if(userData.UserData !== undefined) {
          if ((userData.UserData.package_id !== undefined) && (userData.UserData.package_id !== '') && (userData.UserData.package_id !== 0)) {
            if (parseInt(response.pacakgeId) !== parseInt(userData.UserData.package_id)) {
                  localStorage.clear();
                  window.location.reload();
            }
          }
        }

        if (status == true && result[sitekey].active == 1) {
            if (result[sitekey] !== undefined && result[sitekey] !== "" && result[sitekey] !== null) {
              backendurl = result[sitekey].backend;
              localStorage.setItem('data', JSON.stringify(result[sitekey]));
              window.siteDetials = result[sitekey];
              if(result[sitekey]['favicon']) {
                let favicon = document.getElementById("favicon_as4point");
                favicon.href = result[sitekey]['favicon'];
              }
	            if(result[sitekey]['titletext']) {
                let titleObj = document.getElementById("title_as4point");
                titleObj.innerText = result[sitekey]['titletext'];
              }
            } else {
              backendurl = result['default'].backend;
              localStorage.setItem('data', JSON.stringify(result['default']));
            }
        } else {
          this.setState({
            sitenotfound: false,
            current_site_key : sitekey,
          })
        }

        window.backendURL = backendurl;
          if (localStorage.getItem('App_language_data') === undefined || localStorage.getItem('App_language_data') === null  ) {
              datasave.service(window.GET_ALL_LANGUAGES, 'GET')
                .then(langresponse => {
                      localStorage.setItem('App_language_data', JSON.stringify(langresponse));
                });
        }

        // if (localUser !== null) {
        this.getJson();
        this.getAllTranslationStrings();
        // }
        // this.setState({
        //   sites: JSON.parse(localStorage.getItem('data')),
        //   sitesUpdate: 1,
        // });


        // if(userData.UserData !== undefined) {
        //   if(userData.UserData.user_details.person_status === 0) {
        //      userService.logout();
        //   }
        // }

        if(userData.UserData !== undefined) {

            const email = userData.UserData.user_details.user_email;
            const details_of_email = userData.UserData.user_details;
            const data = {
                email : email
            }
            //let active = 1;
            datasave.service(window.USERDATA, 'POST', data)
            .then(user => {
                this.props.SetUserData(user);
                // if(user.activeuser === 0) {
                //   userService.logout();
                //   window.location.reload();
                // }
              })



              datasave.service(window.GET_USER_SESSION_ACTIVE_DETAILS, 'GET')
                .then(userActive => {
                if(userActive === 0) {
                  userService.logout();
                  window.location.reload();
                }
                })
            if(details_of_email.length === 0) {
               userService.logout();
               window.location.reload();
            }
            if(userData.UserData.user_details.person_status === 0) {
               userService.logout();
               window.location.reload();
            }


        }

      });

  }

  getAllTranslationStrings() {
    datasave.service(window.FETCH_TRANSLATION_STRINGS,'GET')
    .then(result => {
       localStorage.setItem('translationStrings',JSON.stringify(result));
    })
  }

  getJson() {
    var lang = localStorage.getItem('Applang');
    setDefaultTranslations({ en, ch });
    let translations = {};
    if (lang) {
      setDefaultLanguage(lang);
    }
    else {
      setDefaultLanguage('en');
    }
    const data = {
      lang: Language()
    }
    datasave.service(window.GET_JSON, 'POST', data)
      .then(result => {
        let userTranslations = result;
        if (Object.keys(translations).length === 0) {
          setTranslations(userTranslations);
          this.setState({
            updateLanguage: 1,
            sites: JSON.parse(localStorage.getItem('data')),
            sitesUpdate: 1,
          })
          return;
        }
      });
  }
  checkIfDataAlreadyPresentInLocalStorage() {

  }
  getTheSiteName() {
    let sitekey = (window.location.hostname).replace(process.env.REACT_APP_baseURL, "");
    sitekey = sitekey.substr(0, sitekey.length - 1);//remove the last dot
    return (sitekey === '') ? 'default' : sitekey;
  }
  selectedLanguageFromHeader(
    selectedLanguage
  ) {
    this.setState({ selectedLanguage: selectedLanguage });
    setLanguage(selectedLanguage)
  }

  handleData() {
  }
  openWebsocket() {
  }
  render() {
    const history = createBrowserHistory();
    const styleMap = ({
      position: 'relative',
      height: '100vh',
      overflow: 'hidden',
    });



    const containerStyle= ({top: '10px', maxWidth: '650px', bottom: '0px', 'height': '0px'});
    const url = window.location.href;
    const url_included = url.includes(window.loginurl);
    const getHostname = (url_link) => {
      try{
        let url = url_link.location.href;
      const matches = url.match(/^https?\:\/\/([^\/?#]+)(?:[\/?#]|$)/i);
  // extract hostname (will be null if no match is found)
  return matches && matches[1];
}catch(e){
  return 'localFile';
}
      // use URL constructor and return hostname

    }

    let top_url = getHostname(window.top);
    let self_url = getHostname(window.self);

    var turl = (window.location != window.parent.location) ? document.referrer : document.location.href;

    if(window.top != window.self){
      console.log('not matched');
    }
    var parent = $(window.frameElement).parent();

    if(top_url != null && top_url !== self_url){
return (
<div className = "unauthorisedAccess">
<h1>ACCESS DENIED</h1>
<hr></hr>
<h3>You are not authorised to access this url within the iframe</h3>
</div>
);
}
    if (this.state.sitenotfound ==false) {
      return (
        <Sitenotaccess current_site_key={this.state.current_site_key}/>
      )
    }
    const localUser = localStorage.getItem('user');
    if(url.includes('downloadkpireport') && this.outsideApp && window.backendURL){
      return(
        <BrowserRouter>
            <Route path='/downloadkpireport/:gridid/:griditemid/:tileid/:personid' component={KpiReportTabView} />
        </BrowserRouter>
      );
    }
    if (localUser === null && this.state.sitesUpdate === 1) {
      const NotFoundRedirect = () => <Redirect to='/loginscreen' />
      let firstParam = window.location.href.split('/')[3];
      return (
        <BrowserRouter>
          <Switch>
            <Route exact path='/' component={LoginScreen} />
            <Route exact path='/loginscreen' component={LoginScreen} />
            <Route exact path="/needhelp" component={NeedHelp} />
            <Route path='/forgotpassword' component={Forgotpassword} />
            <Route path='/resetpassword/:token' component={Resetpassword} />
            <Route path ='/Useronetimelogin' component={Useronetimelogin}/>
            {(firstParam.includes('public') || firstParam.includes('.') || (firstParam.includes('app') && firstParam.length < 5)) ?
              <> <Route component={PageNotfound} /> <Route path="*" element={<PageNotfound/>} /> </> :
                 <Route component={NotFoundRedirect} />}
          </Switch>
        </BrowserRouter>
      )
    }
    else if (localUser !== undefined && localUser !== '') {
      return (
        this.state.updateLanguage === 1 &&
        <BrowserRouter>
          {!url.includes(window.AR_IFRAME_URL) ? <div className="main-page-container">
            {url.includes('loginscreen') === false && (allDevices.isBrowser && (!allDevices.isIPhone13 || !allDevices.isIPad13 || !allDevices.isIPod13)) &&
              <Header {...history} {...this.props} triggerSelectedLanguage={this.selectedLanguageFromHeader.bind(this)} sitedata={this.state.sites} />
            }
             <OCAlertsProvider containerStyle={containerStyle}/>
            <Main {...this.props} url_included={url_included} triggerSelectedLanguage={this.selectedLanguageFromHeader.bind(this)} sitedata={this.state.sites} />
          </div> : <Route exact path={'/'+window.AR_IFRAME_URL} component={ARSceneComponent} />
        }
        </BrowserRouter>
      )
    }

  }
}
const mapStateToProps = state => ({ ...state });
const mapDispatchToProps = dispatch => ({
    SetUserData: (payload) => dispatch(SetUserData(payload)),
  });
export default translate(connect(mapStateToProps,mapDispatchToProps)(App));
