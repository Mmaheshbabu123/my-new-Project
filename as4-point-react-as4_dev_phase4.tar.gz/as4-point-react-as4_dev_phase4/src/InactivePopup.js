import React, {useEffect,useState,useRef, useCallback} from 'react';
import * as reactbootstrap from 'react-bootstrap';
import { translate } from './language';
import MultiSelect from './_components/MultiSelect';
import { datasave } from './_services/db_services';
import { persistor, store } from './store';
import { userService } from './_services/user.services';
import { connect } from "react-redux";
import Pagination from "react-bootstrap/Pagination";
import {SearchFilter }from './SearchFilter';
import './InactivePopup.css';
import { OCAlert } from '@opuscapita/react-alerts';


const InactivePopup = (props) => {
  const t = props.t;
  const[state,setState] = useState({
    activeTab: 1,
    webData: [],
    docData: [],
    selectedDocTodo: [],
    selectedWebTodo: [],
    selectedWebformUser: [],
    userOption: [],
    webformUserDetails:[],
    documentUserDetails:[],
    todosPerPage: 10,
    currentPage: 0,
    currentTodos: [],
    webError: '',
    docError: '',
  });

  const [search,setSearch] = useState({
    webformversion: '',
    webformname: '',
    webformcode: '',
    webformformnum: '',
    webformstepname: '',
    docversion: '',
    docname: '',
    doccode: '',
    docstatus: '',
  })

  useEffect(() => {
    datasave.service(window.GET_TODO_PERSON_DETAILS+ '/' +props.id,'GET').then(result => {
      setState({
        ...state,
        webformUserDetails: result['webform'],
        webData: result['webform'],
        docData: result['document'],
        documentUserDetails: result['document'],
        userOption:result['userOption'],
        currentPage: 1,
      });

    })

  },[]);

  const handleTabSelect = (e) => {
    setState({
      ...state,
      activeTab:Number(e),
      currentTodos: [],
      currentPage: 1,
    })
    setSearch({
      ...search,
      webformversion: '',
      webformname: '',
      webformcode: '',
      webformformnum: '',
      webformstepname: '',
      docversion: '',
      docname: '',
      doccode: '',
      docstatus: '',
    })
  }
  const handleSelectUser = (e) => {
     if(state.activeTab === 1) {
        setState({
          ...state,
          selectedWebTodo:e,
        })
      }
      else {
        setState({
          ...state,
          selectedDocTodo:e,
        })
      }
  }

  const handleSave = () => {
    if(Object.keys(state.selectedWebTodo).length && Object.keys(state.selectedDocTodo).length) {
      let data = {
        selectedWebTodo: state.selectedWebTodo,
        selectedDocTodo: state.selectedDocTodo
      }
      const detail = window.UPDATE_TODO_OWNER+'/'+props.id;

      datasave.service(detail,'POST', data).then(result => {
          if(result.status === 200) {
            let userData = store.getState();
              var url = props.changePersonStatusUrl;
            const details = {
              id: props.id,
              table: window.persons_table,
              status: props.status ? 0 : 1
            };
              datasave .service(url, "PUT", details)
                .then(response => {
                  if (response === 1) {
                    if(details.status === 0 && userData.UserData.user_details.person_id == props.id) {
                       userService.logout(props.id);
                       window.location.href = '/loginscreen';
                    }
                    window.location.reload();
                    props.closePopUp();
                  }
                })
                .catch(error => {
                  setState({
                    errors: error.response.data.errors
                  });
          })
        }
      })
    } else {
      if(state.selectedWebTodo.length === 0 && state.selectedDocTodo.length === 0) {
        OCAlert.alertError(t('Please fill mandatory fields!'), { timeOut: window.TIMEOUTNOTIFICATION });
        setState({
          ...state,
          webError: 'This field is mandatory.',
          docError: 'This field is mandatory.'

        });
      } else {
          if(state.selectedWebTodo.length === 0)
            {
              OCAlert.alertError(t('Please fill mandatory fields'), { timeOut: window.TIMEOUTNOTIFICATION });
              setState({
                ...state,
                webError: 'This field is mandatory.'
              });
            }
            if(state.selectedDocTodo.length === 0)
              {
                OCAlert.alertError(t('Please fill mandatory fields'), { timeOut: window.TIMEOUTNOTIFICATION });
                setState({
                  ...state,
                  docError: 'This field is mandatory.'
                });
              }
        }
    }
  }

  const handlePageClick = (event) => {
    setState({...state,
      currentPage: Number(event.target.id)
    });
  }

  useEffect(() => {
    const {activeTab, selectedUser, todosPerPage, currentPage } = state;

    if(state.currentPage) {
      const indexOfLastTodo = currentPage * todosPerPage;
      const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
      const currentTodos = state[tabDataKey].slice(indexOfFirstTodo, indexOfLastTodo);
      setState({...state, currentTodos: currentTodos})
   }
  }, [state.currentPage, state.activeTab])


  const tabDataKey = state.activeTab == 1 ? 'webformUserDetails':'documentUserDetails';
  const tabDataKey1 = state.activeTab == 1 ? 'webData':'docData';
  async function searchData(e) {
    const targetName = e.target.name;
    const value = e.target.value;
    if (e.key !== "Delete" || e.key !== "Backspace") {
      var filledStates = state.activeTab == 1 ? await getStates('', '', '','','', targetName, value) : await getDocStates('', '', '','', targetName, value);
      var result = await SearchFilter.getData(filledStates, state[tabDataKey1]);
      let pageData1 = await SearchFilter.getPageData(1,state.todosPerPage,result,result);
      let pagecount = await SearchFilter.getCountPage(result,state.todosPerPage);

      await setSearch({
        ...search,
        [targetName]:value
      });
      if(state.activeTab == 1 ) {
        await setState({
          ...state,
          currentTodos: pageData1,
          currentPage: 1,
          webformUserDetails: result,
        })
      } else {
        await setState({
          ...state,
          currentTodos:pageData1,
          currentPage:1,
          documentUserDetails: result,
        })
      }
    }
  }

  const getStates = (col1, col2, col3,col4, col5, names, cols, type) => {
    if (names !== '') {
      col1 = names === 'code'?col1 + cols:search.webformcode;
      col2 = names === 'name'?col2 + cols:search.webformname;
      col3 = names === 'version'?col3 + cols:search.webformversion;
      col4 = names === 'form_number'?col4 + cols:search.webformformnum;
      col5 = names === 'step_name'?col4 + cols:search.webformstepname;
    }
    var arr = []
    if (col1 != '') {
      arr.push({ name: 'code', value: col1 });
    }
    if (col2 != '') {
      arr.push({ name: 'name', value: col2 });
    }
    if (col3 != '') {
      arr.push({ name: 'version', value: col3 });
    }
    if (col4 != '') {
      arr.push({ name: 'form_number', value: col4 });
    }
    if (col5 != '') {
      arr.push({ name: 'step_name', value: col5 });
    }

    return arr;
  }

  const getDocStates = (col1, col2, col3,col4, names, cols, type) => {
    if (names !== '') {
      col1 = names === 'code'?col1 + cols:search.doccode;
      col2 = names === 'name'?col2 + cols:search.docname;
      col3 = names === 'version'?col3 + cols:search.docversion;
      col4 = names === 'status'?col4 + cols:search.docstatus;
    }
    var arr = []
    if (col1 != '') {
      arr.push({ name: 'code', value: col1 });
    }
    if (col2 != '') {
      arr.push({ name: 'name', value: col2 });
    }
    if (col3 != '') {
      arr.push({ name: 'version', value: col3 });
    }
    if (col4 != '') {
      arr.push({ name: 'status', value: col4 });
    }

    return arr;
  }

  const {activeTab, selectedUser, todosPerPage, currentPage } = state;
  let pageNumbers = [];
  if (state[tabDataKey] && state[tabDataKey].length > 10) {
      for (
        let i = 1;
        i <= Math.ceil(state[tabDataKey].length / todosPerPage);
        i++
      ) {
        pageNumbers.push(
          <Pagination.Item
            id={i}
            onClick={e => handlePageClick(e, this)}
            key={i}
            active={i === currentPage}
          >
            {i}
          </Pagination.Item>
        );
      }
    }
  return(
    <reactbootstrap.Modal
      show={props.show}
      onHide={() => props.closePopUp()}
      dialogClassName="modal-90w inactivepop"
      size = "xl"
      aria-labelledby="example-custom-modal-styling-title"
    >
      <reactbootstrap.Modal.Header closeButton>
        <reactbootstrap.Modal.Title></reactbootstrap.Modal.Title>
        </reactbootstrap.Modal.Header >
        <reactbootstrap.Container className="">
          <reactbootstrap.Modal.Body>
              <reactbootstrap.Tabs activeKey={activeTab} onSelect={handleTabSelect}>
                  <reactbootstrap.Tab eventKey={1} title={t('Webform todo')}>
                  <reactbootstrap.Row style={{ scrollBarWidth: 'thin', marginLeft: '0px', marginRight: '0px' }} >
                    <reactbootstrap.Table striped bordered hover variant="" className="managelayerTables actionlayertables">
                      <thead style={{ backgroundColor: '#EC661C', color: '#fff', top: '0', textAlign: 'center' }}>
                        <tr style={{ textAlign: 'center' }}>
                          <th>{t('Version')}</th>
                          <th>{t('Name')}</th>
                          <th>{t('Code')}</th>
                          <th>{t('Form number')}</th>
                          <th>{t('Step name')}</th>
                        </tr>
                        <tr>
                        <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='version' value={state.webformversion} onChange={searchData}  /></th>
                        <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='name' value={state.webformname} onChange={searchData}  /></th>
                        <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='code' value={state.webformcode} onChange={searchData}  /></th>
                        <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='form_number' value={state.webformformnum} onChange={searchData}  /></th>
                        <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='step_name' value={state.webformstepname} onChange={searchData}  /></th>
                        </tr>

                      </thead>
                      <tbody>
                        {(state.currentTodos && state.currentTodos.length) ? state.currentTodos.map(doc => {
                          return (
                             <tr style={{backgroundColor: '#fafafa' }}>
                                <th>{doc.version}</th>
                                <th>{doc.name}</th>
                                <th>{doc.code}</th>
                                <th>{doc.form_number}</th>
                                <th>{doc.step_name}</th>
                              </tr>
                          )}) : null
                        }
                      </tbody>
                    </reactbootstrap.Table>
                    <Pagination size="sm" style={{width: '410px', overflow: 'auto'}} >{pageNumbers}</Pagination>

                    </reactbootstrap.Row>
                    <reactbootstrap.InputGroup className="">
                    <div className="col-md-2">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Change user')}:<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div className="col-md-10" style={{float: 'left'}}>
                    <MultiSelect
                      options={state.userOption}
                      standards={state.selectedWebTodo}
                      disabled={false}
                      handleChange={handleSelectUser}
                      isMulti={false}
                      placeholder={t('Change user')}
                    />
                    <div style={{ color: 'red' }} className="error-block">{state.webError}</div>
                    </div>
                    </reactbootstrap.InputGroup>
                  </reactbootstrap.Tab>
                  <reactbootstrap.Tab eventKey={2} title={t('Document todo')}>
                  <reactbootstrap.Row style={{ scrollBarWidth: 'thin', marginLeft: '0px', marginRight: '0px' }} >
                    <reactbootstrap.Table striped bordered hover variant="" className="managelayerTables actionlayertables">
                      <thead style={{ backgroundColor: '#EC661C', color: '#fff', top: '0', textAlign: 'center' }}>
                        <tr style={{ textAlign: 'center' }}>
                          <th>{t('Version')}</th>
                          <th>{t('Name')}</th>
                          <th>{t('Code')}</th>
                          <th>{t('Status')}</th>
                        </tr>
                        <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='version' value={state.docversion} onChange={searchData}  /></th>
                        <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='name' value={state.docname} onChange={searchData}  /></th>
                        <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='code' value={state.doccode} onChange={searchData}  /></th>
                        <th><input type="text" className="form-control search-box-border " placeholder={t('Search')} style={{ borderRadius: "5px", borderColor: "#EC661c" }} name='status' value={state.docstatus} onChange={searchData}  /></th>


                      </thead>
                      <tbody>
                      {(state.currentTodos && state.currentTodos.length) ? state.currentTodos.map(item => {
                        return (
                           <tr style={{backgroundColor: '#fafafa' }}>
                              <th>{item.version}</th>
                              <th>{item.name}</th>
                              <th>{item.code}</th>
                              <th>{item.status}</th>
                            </tr>
                          )
                        })
                      :null}

                      </tbody>
                    </reactbootstrap.Table>
                    <Pagination size="sm" style={{width: '410px', overflow: 'auto'}} >{pageNumbers}</Pagination>
                    </reactbootstrap.Row>

                    <reactbootstrap.InputGroup className="">
                    <div className="col-md-2">
                      <reactbootstrap.InputGroup.Prepend>
                        <reactbootstrap.InputGroup style={{ background: 'none', border: '0px', color: '#EC661C', padding: '8px' }} id="basic-addon1">{t('Change user')}:<span style={{ color: "red" }}>*</span></reactbootstrap.InputGroup>
                      </reactbootstrap.InputGroup.Prepend>
                    </div>
                    <div className="col-md-10" style={{float: 'left'}}>
                        <MultiSelect
                          options={state.userOption}
                          standards={state.selectedDocTodo}
                          disabled={false}
                          handleChange={handleSelectUser}
                          isMulti={false}
                          placeholder={t('Change user')}
                        />
                        <div style={{ color: 'red' }} className="error-block">{state.docError}</div>
                    </div>
                    </reactbootstrap.InputGroup>

                  </reactbootstrap.Tab>
              </reactbootstrap.Tabs>
          </reactbootstrap.Modal.Body>
          <reactbootstrap.Row className='mt-3' style={{float:'right'}}>
          <a style={{paddingTop:'15px'}} onClick={() => props.closePopUp()}>{t('Cancel')}</a>&nbsp;&nbsp;&nbsp;
          <reactbootstrap.Button className='m-2' onClick={handleSave}>{t('Save')}</reactbootstrap.Button>
          </reactbootstrap.Row>
        </reactbootstrap.Container>
      </reactbootstrap.Modal>

  )
}

export default translate(InactivePopup);
// const mapStateToProps = state => ({ ...state });
// export default translate(connect(mapStateToProps)(InactivePopup));
