import React, { Component } from 'react'
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd'
import * as reactbootstarp from 'react-bootstrap'
import SearchInput, { createFilter } from 'react-search-input'
import { datasave } from './_services/db_services';
import CheckBox from './CheckBox';
import TextField from '../src/_components/TextField'
// import PersonImg from './images/User_white.png';
// import JobImg from './images/Job_white.png';
// import DepartmentImg from './images/Department_white.png';
// import GroupImg from './images/Group_white.png';
// import DeleteImg from './images/Delete_white.png';
import PersonImg from './images/personc.png';
import JobImg from './images/jobc.png';
import DepartmentImg from './images/departmentsc.png';
import GroupImg from './images/groupc.png';
import DeleteImg from './images/delete1.png';
import { OCAlert } from '@opuscapita/react-alerts';
import './DragnDrop.css';
import wname from './wname.png';
import wview from './wview.png';
import wverify from './wverify.png';
import wabbrv from './abrv-w.png'
import wremove from './wremove.png';
import winitiate from './winitiate.png';
import wcrud from './wcrud.png';
import wauthorise from './wauthorise.png';
import wselectall from './selectall-w.png';



/**
 * Moves an item from one list to another list.
 */
const move = (source, destination, droppableSource, droppableDestination, draggableId) => {

    const sourceClone = Array.from(source);
    const destClone = Array.from(destination);
    const [removed] = sourceClone.filter(items => items.id === draggableId);
    destClone.splice(droppableDestination.index, 0, removed);
    const result = {};
    result[droppableSource.droppableId] = sourceClone.filter(items => items.id !== draggableId);
    result[droppableDestination.droppableId] = destClone;
    result['latestDropped'] = removed;
    result['type'] = (droppableDestination.droppableId === 'droppable') ? 'remove' : 'add';
    return result;
};
const grid = 8;
/*const getItemStyle = (isDragging, draggableStyle) => ({
    // some basic styles to make the items look a bit nicer
    userSelect: 'none',
    padding: grid * 2,
    margin: `0 0 ${grid}px 0`,

    // change background colour if dragging
    background: isDragging ? 'lightgreen' : 'grey',

    // styles we need to apply on draggables
    ...draggableStyle
});*/

const getListStyle = isDraggingOver => ({
    background: isDraggingOver ? 'lightblue' : '#fff',
    padding: grid,
    width: 1000,


});

const getFlexStyle = ({
    display: 'flex',
});

const imageStyle = ({
    width: 20,
    cursor: "default",
});
const TextCurser = ({
    cursor: "default",
});

const textinline = ({
    display: '-webkit-inline-flex',
});

/*const tooltipStyle = ({
    height: 150,
    width: 200,
    overflow: 'auto'
});*/

class PJDGdragndrop extends Component {

    constructor(props) {

        super(props);
        this.searchUpdated = this.searchUpdated.bind(this)

        this.state = {
            KEYS_TO_FILTERS: window.search_fields,
            items: [],
            selected: [],
            types: [],
            searchData: [],
            searchTerm: [],
            searchType: '',
            type: '',
            html: window.HTML_OBJECT,
            html_right: window.HTML_RIGHT,
            updated: 1,
            persons: [],
            curently_hovered_item: [],
            show: false,
            isTooltipActive: false,
            parent: "tooltip",
            disableFields:(this.props.itemlist === "Member of") ? true:false
          }
        this.handleCheck = this.handleCheck.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleChangeOrder = this.handleChangeOrder.bind(this);
        this.handleClicktr = this.handleClicktr.bind(this);
        this.handlePersons = this.handlePersons.bind(this);
        // this.showTooltip = this.showTooltip.bind(this);
        // this.hideTooltip = this.hideTooltip.bind(this);


    }

    handleClicktr(resultObj) {
        if (this.props.details.disableFields) {
            return;
        }
        // if(this.props.details.linked === 'true'){
        //   OCAlert.alertWarning('Linked with document cycle', { timeOut: window.TIMEOUTNOTIFICATION1});
        //   return;
        // }
        if(this.props.itemlist  !== "Member of"){
              var selected = this.state.selected;
              var remove = selected.filter(item => (item.name !== resultObj.name && item.id !== resultObj.id));
              const result = {};
              result['latestDropped'] = resultObj;
              result['type'] = 'remove';
              this.setState(prevState => ({
                  items: [...prevState.items, resultObj],
                  selected: remove,
              }), () => {
                  this.props.updateSelectedChild(result.latestDropped, result, this.props.tab, this.props.notify_id);
              });
        }
    }

    async componentDidMount() {
        if (this.props.items !== undefined) {
            this.setState({
                types: this.props.types,
                items: this.props.items,
                selected: this.props.selected,
                type: this.props.type,
            });
        }

    }

    /**
     * A semi-generic way to handle multiple lists. Matches
     * the IDs of the droppable container to the names of the
     * source arrays stored in the state.
     */
    id2List = {
        droppable: 'items',
        droppable2: 'selected'
    };

    handleDragSelectedChange = (result) => {
        this.setState({
            items: result.droppable,
            selected: result.droppable2
        }, () => {

            this.props.updateSelectedChild(result.latestDropped, result, this.props.tab, this.props.notify_id);
        });
    }
    getList = id => this.state[this.id2List[id]];

    onDragEnd = resultObj => {
        const { source, destination, draggableId } = resultObj;
        // dropped outside the list
        if (!destination) {
            return;
        }
        if (source.droppableId === destination.droppableId) {
            return;
            /*const items = reorder(
                this.getList(source.droppableId),
                source.index,
                destination.index
            );

            let state = { items };

            if (source.droppableId === 'droppable2') {
                state = { selected: items };
            }

            this.setState(state);*/
        } else {
            const result = move(
                this.getList(source.droppableId),
                this.getList(destination.droppableId),
                source,
                destination,
                draggableId
            );
            this.handleDragSelectedChange(result);
        }
    };
    searchUpdated(term, itemlist) {
        const items = { ...this.state.searchTerm };
        items[itemlist] = term;
        this.setState({
            searchTerm: items,
            searchType: itemlist,
        })
    }
    handleCheck = (id, checked, category) => {
        this.handleUpdateState(id, checked, "checkboxes", "checked", category, "flag")
    }
    handleUpdateState(id, value, type, action, pid, flag) {
        let selected = this.state.selected;
        this.state.selected.map(functions => {
            Object.values(functions[type]).map(function (item, index) {
                if (item.id === id && functions.id === pid) {
                    item[action] = value;
                    item[flag] = 1;
                    return;
                }
            })
        });
        this.setState({
            selected : selected,
        }, () => {
            this.props.updateSelectedRights(this.state.selected);

        })
    }
    handleChange(id, value, type_id, type) {
        const re = /^(?:[0-9]*)$/;
        if (value === '' || re.test(value)) {
            this.handleUpdateState(id, value, "textfield", type, type_id, "flag");
        }
    }
    handleChangeOrder(id, value, type_id, type) {
        const re = /^(?:[0-9])$/;
        if (value === '' || re.test(value)) {
            this.handleUpdateState(id, value, "textfield", type, type_id, "flag");
        }
    }
    handlePersons(item) {

        if (item.category_id != window.PERSON_ENTITY) {
            this.setState({ show: true });
            if (this.state.persons[item.id]) {
                this.setState({
                    curently_hovered_item: this.state.persons[item.id]
                })
            }
            else {
                const loaded_persons = this.state.persons;

                const url = window.GetAllLinkedPersons + '/' + item.id + '/' + item.entity_type_id
                datasave.service(url, "GET", '')
                    .then(result => {
                        const all_persons = {
                            ...loaded_persons,
                            ...result
                        }
                        this.setState({
                            persons: all_persons,
                            curently_hovered_item: result[item.id]
                        })
                    })
                    .catch(error => {

                    })
            }
        }

    }
    handleHide = () => {
        this.setState({ show: false });
    }
    componentDidUpdate(prevProps, prevState) {
        if (prevState.items !== this.props.tasks) {
            this.setState({
                items: this.props.tasks,
            })
        }
        if ( prevProps.uniqueId != this.props.uniqueId){
          this.setState({
              selected: [],
          })
        }
    }
    /*hideTooltip() {
        this.setState({isTooltipActive: false})
    }

    showTooltip() {
        this.setState({isTooltipActive: true})
    }*/


    // Normally you would want to split things out into separate components.
    // But in this example everything is just done in one place for simplicity
    render() {
      console.log('state', this.state);
        var Tab_selected;
       /*const popover = (
            <reactbootstarp.Popover style={tooltipStyle} id="popover-basic" title="Persons">
                <ul>
                    {this.state.curently_hovered_item.map(person =>
                        <li>{person.name}</li>
                    )}
                </ul>
            </reactbootstarp.Popover>
        );*/
        const popupContent = (
            <reactbootstarp.Modal
                show={this.state.show}
                onHide={this.handleHide}
                dialogClassName="modal-90w"
                aria-labelledby="example-custom-modal-styling-title"
            >
                <reactbootstarp.Modal.Header closeButton>
                    <reactbootstarp.Modal.Title id="contained-modal-title-vcenter">
                        Persons
                </reactbootstarp.Modal.Title>
                    <reactbootstarp.Modal.Body>
                        <ul>
                            {this.state.curently_hovered_item.length != 0 &&
                                this.state.curently_hovered_item.map(person =>
                                    <li>{person.name}</li>
                                )
                            }
                            {this.state.curently_hovered_item.length === 0 &&
                                'No persons are linked'
                            }
                        </ul>
                    </reactbootstarp.Modal.Body>
                </reactbootstarp.Modal.Header>
            </reactbootstarp.Modal>
        );
        if (this.props.types !== undefined && this.state.items !== undefined) {
            // const type = this.props.type;
            const types = this.props.types;

            /*if ((this.props.tasks !== undefined && this.props.tasks.length > 0) && this.state.items.length === 0) {
                this.setState({
                    items: this.props.tasks
                });
            }*/
            if (this.props.selected !== undefined && this.props.selected.length === 0 && this.props.updateProps === 1 && this.state.updated > 0) {
                this.setState({
                    selected: this.props.selected,
                    updated: 0,
                });
            }
            else if (this.props.selected !== undefined && this.props.selected.length > 0 && this.props.updateProps === 1 && this.state.selected.length === 0) {
                this.setState({
                    selected: this.props.selected,
                    updated: 2,
                });
            }
            if (this.props.itemlist === window.MEMBER_OF) {
              if (this.props.organisatioal_unit  === "Jobs") {
                Tab_selected = this.state.selected.filter(items => (items.category_id === window.job_memberof_one.toString() || items.category_id === window.job_memberof_two.toString()))
              } else if (this.props.organisatioal_unit === "Departments") {
                Tab_selected = this.state.selected.filter(items => (items.category_id === window.department_memberof_one.toString()))
              } else {
                Tab_selected = this.state.selected
              }
            }
            else if (this.props.itemlist === window.MEMBER) {
              if (this.props.organisatioal_unit  === "Jobs") {
                Tab_selected = this.state.selected.filter(items => (items.category_id === window.job_member_one.toString()))
              } else if (this.props.organisatioal_unit === "Departments") {
                Tab_selected = this.state.selected.filter(items => (items.category_id === window.department_member_one.toString() || items.category_id === window.department_member_two.toString()))
              } else {
                Tab_selected = this.state.selected
              }
            }

            var filteredNames = [];
            var dragObject = <reactbootstarp.Tabs activeKey={this.props.activeKey} onSelect={this.props.onSelect} id="controlled-tab-example">
                {Object.values(types).map(
                    function (itemlist, key) {
                        var search = '';
                        if (this.state.searchTerm && this.state.searchType) {
                            search = this.state.searchTerm[itemlist];
                            search = (search !== undefined) ? search : '';
                        }
                        filteredNames[itemlist] = this.state.items.filter(createFilter(search, this.state.KEYS_TO_FILTERS));
                        return (
                            <reactbootstarp.Tab className="dragndropavailable" eventKey={itemlist} title={itemlist.charAt(0).toUpperCase() + itemlist.slice(1)}>
                                <reactbootstarp.Table className="available-item-section" striped bordered responsive hover variant="dark">
                                    <thead style={{position: 'sticky',top: '0', backgroundColor: '#fff'}}>
                                        <tr>
                                            <td style={{padding: '10px 0px', border: 'none'}} colSpan="3">
                                                <SearchInput style={{color: '#EC661C', border: 'none'}} className="search-input" onChange={(e) => this.searchUpdated(e, itemlist)} />
                                            </td>
                                        </tr>
                                        <tr>
                                            {this.state.html_right[0][itemlist].map(rights =>
                                                <th style={{backgroundColor: '#EC661C', color: '#fff',border: 'none'}} title={rights.name}>{rights.name}</th>
                                            )}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {Object.values(filteredNames[itemlist]).map(

                                            function (item, index) {
                                                item.category_id = (item.entity_type_id !== undefined) ? item.entity_type_id : item.category_id;
                                                if (item !== undefined && item.id !== undefined && item.category === itemlist) {
                                                    return (
                                                        <Draggable
                                                            isDragDisabled={this.state.disableFields}
                                                            key={item.id}
                                                            draggableId={item.id}
                                                            type={item.category}
                                                            index={index}>
                                                            {(provided, snapshot) => (
                                                                <tr
                                                                    ref={provided.innerRef}
                                                                    {...provided.draggableProps}
                                                                    {...provided.dragHandleProps}
                                                                >
                                                                    <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6'}}>
                                                                        <div className="" style={textinline} onClick={(e) => this.handlePersons(item)}>
                                                                            <div>
                                                                                {/* <p onClick={(e) => this.handlePersons(item)}> */}
                                                                                    {item.category != 'spaces' &&
                                                                                        <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                                                                    }
                                                                                    &nbsp;
                                                                                {/* </p> */}
                                                                            </div>
                                                                            &nbsp;
                                                                            <div>
                                                                                {item.name}
                                                                            </div>
                                                                        </div>
                                                                        {popupContent}
                                                                        {/* { item.category != 'spaces' &&
                                                                            <img style = {imageStyle} src={ item.category === 'persons' ? PersonImg : (item.category ==='jobs'? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" onClick={(e) => this.handlePersons(item)} />
                                                                        }
                                                                        {popupContent}
                                                                        &nbsp; &nbsp;
                                                                        {item.name} */}
                                                                    </td>
                                                                    {item.category != 'persons' &&
                                                                        <td className="" style={{border: 'none',borderTop: '1px solid #dee2e6', textAlign:'center'}}>
                                                                            {item.abbrevation}
                                                                        </td>
                                                                    }
                                                                </tr>
                                                            )}
                                                        </Draggable>
                                                    )
                                                }

                                            }, this)}
                                    </tbody>
                                </reactbootstarp.Table>
                            </reactbootstarp.Tab>
                        )
                    }, this)}
            </reactbootstarp.Tabs>
        }
        return (
            <div style={getFlexStyle}>
                <DragDropContext onDragEnd={this.onDragEnd}>
                    <Droppable droppableId="droppable2">
                        {(provided, snapshot) => (
                            <div className="slected-available-border dragndropavailable mb-3"
                                ref={provided.innerRef}
                                style={getListStyle(snapshot.isDraggingOver)}>
                                <p>Selected items</p>
                                <reactbootstarp.Table striped bordered hover responsive variant="dark">
                                    <thead style={{backgroundColor: '#EC661C', position: 'sticky',top: '0',borderColor: '1px solid #EC661C'}}>
                                        <tr>
                                            {this.state.html[0][this.props.type].map(commons =>
                                                <th style={{paddingTop: '20px', border: 'none'}}  className ={commons.class} title={commons.name}></th>
                                            )}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {/* { this.props.itemlist === window.MEMBER_OF &&
                                            {
                                                Tab_selected = this.state.selected.filter(items => (items.category_id === window.job_memberof_one || items.category_id === window.job_memberof_two))
                                            }
                                        }
                                        { this.props.itemlist === window.MEMBER &&
                                            {
                                                Tab_selected = this.state.selected.filter(items => (items.category_id === window.job_member_one))
                                            }
                                        }
                                                */}
                                        {Tab_selected !== undefined && Tab_selected.map(
                                            function (item, index) {
                                                if (this.props.type === "common") {
                                                    return (
                                                        <tr style={{backgroundColor: '#fff', color: '#282c34', borderBottom: '1px solid lightgray'}} >
                                                            <td style={{ border: 'none'}}>
                                                                <div className="borde" style={textinline} onClick={(e) => this.handlePersons(item)}>
                                                                    <div>
                                                                        {item.category !== 'spaces' &&
                                                                            <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                                                        }
                                                                    </div>
                                                                    &nbsp;
                                                                    <div style={TextCurser}>
                                                                        {item.name}
                                                                    </div>
                                                                </div>
                                                                {popupContent}
                                                            </td>
                                                            <td style={{textAlign: 'center',  border: 'none'}}>
                                                                {item.abbrevation}
                                                            </td>
                                                            <td  style={{textAlign: 'center', border: 'none'}} disabled={this.props.details.disableFields}>
                                                                <img style={imageStyle} src={DeleteImg} alt="delete" disabled onClick={(e) => this.handleClicktr(item)}></img>
                                                            </td>
                                                        </tr>
                                                    )
                                                }
                                                else if (this.props.type == 'rights') {
                                                    return (
                                                        <tr>
                                                            <td>
                                                                <div style={textinline} onClick={(e) => this.handlePersons(item)}>
                                                                    <div>
                                                                        {item.category !== 'spaces' &&
                                                                            <img style={imageStyle} src={item.category === 'persons' ? PersonImg : (item.category === 'jobs' ? JobImg : (item.category === 'departments' ? DepartmentImg : GroupImg))} alt="persons" />
                                                                        }
                                                                    </div>
                                                                    &nbsp;
                                                                    <div style={TextCurser}>
                                                                        {item.name}
                                                                    </div>
                                                                </div>
                                                                {popupContent}
                                                            </td>
                                                            {item.checkboxes.map(function (check) {
                                                                return (
                                                                    <td>
                                                                        <CheckBox
                                                                            key={check.id}
                                                                            name={''}
                                                                            value={check.id}
                                                                            tick={check.checked}
                                                                            classification={check.name}
                                                                            onCheck={(e) => this.handleCheck(check.id, e.target.checked, item.id)}
                                                                            keyvalue={check.id}
                                                                        />
                                                                    </td>
                                                                )
                                                            }, this)}
                                                            {item.textfield.map(function (text) {
                                                                return (
                                                                    <td>
                                                                        <TextField
                                                                            name={text}
                                                                            order={text.order}
                                                                            count={text.count}
                                                                            category={item.category}
                                                                            handleChange={(e) => this.handleChange(text.id, e.target.value, item.id, "count")}
                                                                            handleChangeOrder={(e) => this.handleChangeOrder(text.id, e.target.value, item.id, "order")}
                                                                        />
                                                                    </td>
                                                                )
                                                            }, this)}
                                                            <td>
                                                                <img style={imageStyle} src={DeleteImg} alt="delete" onClick={(e) => this.handleClicktr(item)}></img>
                                                            </td>
                                                        </tr>
                                                    )
                                                }
                                            }, this)}
                                        {provided.placeholder}
                                    </tbody>
                                </reactbootstarp.Table>
                            </div>
                        )}
                    </Droppable>
                    {this.props.itemlist != 'Member of' &&
                    <Droppable droppableId="droppable">
                        {(provided, snapshot) => (

                            <div
                            className="slected-available-border1 mb-3"
                                ref={provided.innerRef}
                                style={getListStyle(snapshot.isDraggingOver)}
                            >
                                <p>Available items</p>
                                {provided.placeholder}
                                {dragObject}
                            </div>

                        )}
                    </Droppable>
                  }
                </DragDropContext>
            </div>
        );
    }
}
export default PJDGdragndrop
