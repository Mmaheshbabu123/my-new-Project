import React from 'react';
import Select from 'react-select';
import {t} from '../language';
  const customStyles = {
  option: (provided, state) => ({
    ...provided,
  backgroundColor: state.isFocused
        ? '#EC661C'
        : null,
    color:'black',
  }),
}
export default function MultiSelect({ handleChange, standards, options, disabled, isMulti = true, name = '' ,placeholder = t('Select')}) {
  const customFilter = (option, searchText) => {
      if (option.label !== undefined && option.label !== null && option.label.toLowerCase().includes(searchText.toLowerCase())){
        return true
      }
        return false;
    }
    return (
        <Select
          className="mySelect"
      classNamePrefix="mySelect"
            placeholder={placeholder}
            value={standards}
            onChange={handleChange}
            isDisabled={disabled}
            options={options}
            filterOption={customFilter}
            isMulti = {isMulti}
            styles={customStyles}
            name = {name}
            
            noOptionsMessage= {() => t('No option')}
        />
    );
}
