import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap'
import { datasave } from '../_services/db_services'
import PopUpFile from '../../src/PopUpFile'
import { OCAlert } from '@opuscapita/react-alerts';
import {translate} from '../language';


class TodosComponentOne extends Component {
    constructor(props) {
        super(props);
        this.state = {

            documentId: this.props.id,
            documentStatus: this.props.docStatus,
            todoId: this.props.todoId,
            show: false,
            comment: '',
            status: false,
            commentedPerName: '',
            t:props.t,
        }
        this.handleUnderstood = this.handleUnderstood.bind(this);
        this.handleNotUnderstood = this.handleNotUnderstood.bind(this);



    }
    handleUnderstood(e) {
        var data = {
            id: this.state.todoId,
            read_or_not: 1,
        }
        datasave.service(window.READUPDATE, "POST", data)
            .then(result => {
                OCAlert.alertSuccess(result['msg'], { timeOut: window.TIMEOUTNOTIFICATION });

                // alert(result['msg']);
                this.props.history.push(localStorage.getItem('prevLocation'));
            });


    }

    handleNotUnderstood(e) {
        e.preventDefault();
        this.setState({
            show: true,
        })
    }

    render() {
      const {t} = this.state;
        return (
            <div>
                {/* <p>
                    <h1>{this.state.documentId + ',' + this.state.documentStatus + ',' + this.state.todoId}</h1>
                </p> */}


                <reactbootstrap.Button style={{ marginRight: '1rem' }} onClick={this.handleUnderstood}>
                    {t('Read and understood')}
              </reactbootstrap.Button>


                <reactbootstrap.Button onClick={this.handleNotUnderstood}>
                    {t('Read and not understood')}
               </reactbootstrap.Button>
                {this.state.show && <PopUpFile webform = {this.props.webform} history={this.props.history} curd={1} title="Comment" comment_type={2}
                    placeholder={t("Type your comment")} current_status="Submit"
                    status_id={21} doc_id={this.state.documentId}
                    todoId={this.state.todoId}></PopUpFile>
                }
            </div>

        )
    }

    componentDidMount() {
        // datasave.service(window.GETCOMMENTS + '/' + this.state.todoId, "GET")
        //     .then(result => {
        //         if (result['status'] === 200) {
        //             if (result['data'].length > 0) {
        //                 result['data'].map((key) => {
        //                     this.setState({
        //                         comment: key['comment'],
        //                         commentedPerName: key['name'],
        //                         status: true,
        //                     })
        //                 })



        //             } else {
        //             }
        //         } else {
        //         }
        //     });
    }

}
export default translate(TodosComponentOne);
