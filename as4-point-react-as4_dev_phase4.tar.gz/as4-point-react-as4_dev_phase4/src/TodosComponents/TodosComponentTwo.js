import React, { Component } from 'react'
import * as reactbootstrap from 'react-bootstrap'
import { datasave } from '../_services/db_services'
import PopUpFile from '../../src/PopUpFile';
import {translate} from '../language';


class TodosComponentTwo extends Component {
    constructor(props) {
        super(props);
        this.state = {

            documentId: this.props.id,
            documentStatus: this.props.docStatus,

            show: false,
            todoId: this.props.todoId,
            comment: '',
            commentedPerName: '',
            status: false,
            t:props.t,


        }
        this.handleFeedback = this.handleFeedback.bind(this);




    }
    handleFeedback(e) {
        e.preventDefault();
        this.setState({
            show: true,
        })
    }






    render() {
      const {t} = this.state;
        return (
            <div>





                <div>
                    <reactbootstrap.Button onClick={this.handleFeedback}>
                        {t('Give feedback')}
                        </reactbootstrap.Button>
                </div>

                {
                    this.state.show && <PopUpFile history={this.props.history} curd={0} title={t("Feedback")} comment_type={3}
                        placeholder={t("Type your feedback")} current_status="Submit"
                        status_id={21} doc_id={this.state.documentId}
                        todoId={this.state.todoId}></PopUpFile>
                }
            </div >

        )


    }

    componentDidMount() {

        // datasave.service(window.GETCOMMENTS + '/' + this.state.todoId, "GET")
        //     .then(result => {
        //         if (result['status'] === 200) {
        //             if (result['data'].length > 0) {
        //                 result['data'].map((key) => {
        //                     this.setState({
        //                         comment: key['comment'],
        //                         commentedPerName: key['name'],
        //                         status: true,
        //                     })
        //                 })



        //             } else {
        //             }
        //         } else {
        //         }
        //     });
    }

}
export default translate(TodosComponentTwo);
