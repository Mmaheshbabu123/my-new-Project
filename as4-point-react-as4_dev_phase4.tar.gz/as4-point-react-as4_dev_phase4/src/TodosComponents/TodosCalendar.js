import React, { Component } from 'react';
import {translate} from '../language';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { datasave } from '../_services/db_services';
import * as reactbootstrap from 'react-bootstrap';
import withDragAndDrop from 'react-big-calendar/lib/addons/dragAndDrop';
import MultiSelect from './Multiselect';
import { OCAlert } from '@opuscapita/react-alerts';
import {store } from '../store';
import AccessDeniedPage from '../_components/Errorpages/AccessDenied';
import {CanPermissions} from '../_components/CanComponent/CanPermissions';
import './TodosCalendar.css';
const DragAndDropCalendar = withDragAndDrop(Calendar);

class TodosCalendar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      t:props.t,
      showPopUp: false,
      start: {},
      end: {},
      title: '',
      events: [],
      documents:{},
      persons : {},
      teams : {},
      selectedDocuments:[],
      selectedPersons:[],
      selectedTeams : [],
      allData:'',
      upcomingTodo:'',
      filterData:'',
      newDate:'',
      comments:'',
      oldDate:'',
      loginUser:'',
      allowUserDocuments:'true',
      duedatePassed:false,
      tableType:'',
      teamsData : {},
      dateChecked:1,
    }
    this.handleRadioSelect = this.handleRadioSelect.bind(this);
  }
  async componentDidMount(condtion='true'){
    let Userdata = store.getState();
    let loginPerson_Id =Userdata.UserData.user_details.person_id;
    datasave.service(window.GET_PJGD_NAME_ID,"GET")
    .then(async response=>{
      if(response['status']===200)
      {
        await this.getAllTodos(loginPerson_Id,condtion,response['data']);
        await this.getAllTeamsAndMembers(window.GETALLTEAMDATA);
      }
    })
  }
  getAllTeamsAndMembers =async()=>{
     datasave.service(window.GETALLTEAMDATA, 'GET')
    .then(async response=>{
      if(response['status']===200){
      let sortedValue = await this.sort(response['data']['teamObject'],[]);
        this.setState({teams:sortedValue,teamsData:response['data']['allData']})
      }
    })
  }
  async getChunkedTodos(url){
    var data = [];
   await  datasave.service(url, 'GET')
    .then(async response=>{
      if(response['status']===200){
        data = response['data'];
      }
    })
    return data;
  }
  async getAllTodos(loginPerson_Id,condtion,all_pjgd_name_id){
    let loginevents='';
    var upcomingData = [];
    var allData = [];
    var csvData = [];
    let chunkUpComingTodoLength = await this.chunkTodoLength(window.GET_UPCOMING_TODO_DATA_CHUNK_LENGTH);
    let chunkAllTodoLength = await this.chunkTodoLength(window.GET_ALL_TODOS_DATA_CHUNK_LENGTH);
    let chunkFileTodoLength = await this.chunkTodoLength(window.GET_TP_FILE_TODO_CHUNK_LENGTH);
    if(chunkUpComingTodoLength>0){
      for(var i=0;i<=chunkUpComingTodoLength-1;i++){
        let temporary = await this.getChunkedTodos(window.GET_UPCOMING_TODO_DATA+'/'+i);
        await  Object.values(temporary).map(async value=>{
          await  upcomingData.push(value);
        })
      }
    }
    if (chunkAllTodoLength>0) {
      for(let j=0;j<=chunkAllTodoLength-1;j++){
        let temporary1 = await this.getChunkedTodos(window.GET_ALL_TODOS_DATA+'/'+j);
        await  Object.values(temporary1).map(async value=>{
          await  allData.push(value);
        })
      }
    }
    if(chunkFileTodoLength>0){
      for(let k=0;k<=chunkFileTodoLength-1;k++){
        let temporary2 = await this.getChunkedTodos(window.GET_TP_FILE_TODOS_DATA+'/'+k);
        await  Object.values(temporary2).map(async value=>{
          await  csvData.push(value);
        })
      }
    }
    let mergedUpcomingAndAllTodos = allData.concat(upcomingData,csvData);
    let constructedmergedUpcomingAndAllTodosData = await this.constructionOfArray(mergedUpcomingAndAllTodos,all_pjgd_name_id);
    if(this.state.allowUserDocuments===condtion) { // getting login user Todos
      loginevents = await this.getUserIdTodos(constructedmergedUpcomingAndAllTodosData['todos'],loginPerson_Id);
      this.didMountSetState(constructedmergedUpcomingAndAllTodosData['documents'],constructedmergedUpcomingAndAllTodosData['persons'],constructedmergedUpcomingAndAllTodosData['todos'],loginevents);
    }
  }
  didMountSetState =async (sortedDoc,sortedPersons,personDetails,loginevents)=>{
    this.setState({
      documents:sortedDoc,persons:sortedPersons,
      allData:personDetails,selectedDocuments:this.state.selectedDocuments,
      showPopUp: false,newDate:'',events:loginevents.length>0?loginevents:this.state.events,
    })
  }
  constructionOfArray=async (data,all_pjgd_name_id)=>{
    const {t} =this.state;
    var documents = {};
    var persons = {};
    var todo = [];
    await data.map(async value=>{
      documents[value.webform_id]={'label':value.code+' '+value.name+' '+value.version,'value':value.webform_id};
      persons[value.userId]={'label':value.username,'value':value.userId};
    });
    await  Object.keys(persons).map(async pk=>{
      await  Object.keys(documents).map(async dk=>{
        let filterByDocPerson = data.filter(value=>value.userId===parseInt(pk) && value.webform_id===parseInt(dk));
        var currentConstruction = {};
        await filterByDocPerson.map(value=>{
          currentConstruction[value.userId+' '+value.todo_id]={
            'todo_id':value.todo_id,'task_name':value.task_name,
            'org_id':all_pjgd_name_id['codes'][parseInt(value.org_id)],'org_type_id':parseInt(value.org_id)==10?all_pjgd_name_id['codes'][parseInt(value.todoOrgType)]:t(all_pjgd_name_id['allData'][value.org_type_id]),
            'name':value.name,'code':value.code,'version':value.version,
            'due_date':value.due_date,'old_duedate':value.old_duedate,
            'type' :value.type,'task_id':value.task_id,'webform_id':value.webform_id,
            'comment':value.comment,'tableType':value.tableType,
            'started_at':(value.started_at !== undefined && value.started_at !== null)?value.started_at:null,
            'username':value.username,'userid':value.userid,'amount':parseInt(value.amount)<1?1:parseInt(value.amount)
          };
        });
        if (Object.keys(currentConstruction).length>0) {
            todo={...todo,[parseInt(pk)]:{...todo[parseInt(pk)],[parseInt(dk)]:{...currentConstruction}}};
        }
      });
    });
    let sortedPersons =await this.sort(persons,[]);
    let sortedDoc =await this.sort(documents,[]);
    return {'todos':todo,'persons':sortedPersons,'documents':sortedDoc};
  }
  chunkTodoLength=async(url)=>{
    var chunkLength = 0;
    await datasave.service(url, 'GET')
    .then(async response=>{
      if(response['status']===200){
        chunkLength = response['data'];
      }
    });
    return parseInt(chunkLength);
  }
  sort(data1,data2){
    let combinedObject ={...data1,...data2};
    let t=Object.values(combinedObject).sort(function(a,b){return (a.label).toLowerCase() < (b.label).toLowerCase() ? -1 : 1;});
    return Object.values(t);
  }

  getUserIdTodos =async (data,id) =>{
    if(id!==0 && id!==undefined && data[id]!==undefined && Object.values(data[id]).length>0){
      let doc =  Object.values(data[id]).map(value=>{
        return Object.values(value);
      })
      let filteredDoc = Array.prototype.concat.apply([],doc);
      let filterObj = Object.assign(filteredDoc);
      return await this.createDataByRow(filterObj);
    }else{
      return [];
    }
  }
  createDataByRow=(filterObj)=>{
    console.log(filterObj);
    return filterObj.map(value=>{
      return ({
        'id' : value['todo_id'],'title':value['task_name'],
        'start': (this.state.dateChecked === 1)?new Date(value['due_date']):(value['started_at'] !== undefined &&value['started_at'] !== null)?new Date(value['started_at']):new Date(null),
         'end': (this.state.dateChecked === 1)?new Date(value['due_date']):(value['started_at'] !== undefined &&value['started_at'] !== null)?new Date(value['started_at']):new Date(null),
        'comment':value['comment'],'tableType' : value['tableType'] ,
         'started_at':(value['started_at'] !== undefined &&value['started_at'] !== null)?moment(new Date(value['started_at'])).format('YYYY-MM-DD')+' '+new Date(value['started_at']).toLocaleTimeString():null,
         'due_date':moment(new Date(value['due_date']).toLocaleDateString()).format('YYYY-MM-DD')+' '+new Date(value['due_date']).toLocaleTimeString(),
         'ended_at':value['started_at'],
        'username' : value['username'],'document_code' :value['code'],'document_name':value['name'],'document_version':value['version'],
        'org_type_id' : value['org_id'],'org_id':value['org_type_id'],time:(this.state.dateChecked === 1)?new Date(value['due_date']).toLocaleTimeString():(value['started_at'] !== undefined &&value['started_at'] !== null)?new Date(value['started_at']).toLocaleTimeString():new Date(null),amount:value['amount']
      })
    })
  }
  handleChangeDocumentsOptions = (event) =>{
    this.setState({ selectedDocuments: event},()=>this.generateCalederData());
  }
  handleChangePersonsOptions = (event) => {
    this.setState({ selectedPersons: event},()=>this.generateCalederData());
  }
  handleChangeTeamsOptions = (event) =>{
    this.setState({ selectedTeams:event},()=>this.generateCalederData());
  }
  handleRadioSelect (type){
    const {allData} = this.state;
    var arr = [];
    Object.values(allData).map(value=>{if(value!==undefined){arr.push(Object.values(value))}});
    let af = Object.values(arr).map(value=>value);
    let  filteredObject = Object.assign({},...Object.values(af).flat());
    this.setState({dateChecked:type},()=>this.setStatesForEvents(filteredObject));
  }
  generateCalederData =async () =>{
    const {t,selectedDocuments,selectedPersons ,selectedTeams ,teamsData,allData} =this.state;
    if( selectedTeams.length<1 && selectedDocuments.length<1 && selectedPersons.length<1 ) {
        this.setState({events:[]});
      OCAlert.alertWarning(t('Please select teams or persons or documents '), { timeOut: window.TIMEOUTNOTIFICATION });
      return;
    }
    this.setState({events:[]});
    var filtering ={};
    var selectedDocumentsValues = selectedDocuments.map(value=>{return value['value']});
    var selectedPersonValues = selectedPersons.map(value=>{return value['value']});
    var selectedteamValues = selectedTeams.map(value=>{return value['value']});
    if(selectedTeams.length>0){
    filtering = await this.fiterAllDataAccordingToTeams(selectedDocumentsValues, selectedPersonValues ,selectedteamValues,teamsData,allData);
    }
    else{
    filtering = await this.checkforPersonAndDocumentValues(selectedDocumentsValues, selectedPersonValues ,allData);
    }
if(filtering!==undefined){
    var arr = [];
    Object.values(filtering).map(value=>{if(value!==undefined){arr.push(Object.values(value))}});
    let af = Object.values(arr).map(value=>value);
    let  filteredObject = Object.assign({},...Object.values(af).flat());
    await this.setStatesForEvents(filteredObject);
}
  }

fiterAllDataAccordingToTeams = async(selectedDocuments,selectedPersons ,selectedTeams, teamsData,allData)=>{
  let filterdValues = teamsData.filter(value=>selectedTeams.includes(value.id));
  let filterTeamPersons = filterdValues.map(value=>value.member_id);
  let filterdPersons =await this.filterByCategory(filterTeamPersons,allData);
  return await this.checkforPersonAndDocumentValues(selectedDocuments, selectedPersons ,filterdPersons);
}
checkforPersonAndDocumentValues=async (selectedDocuments, selectedPersons ,filtered)=>{
  if(selectedPersons.length<1 && selectedDocuments.length<1) {
    return filtered;
  }else if (selectedPersons.length>0 && selectedDocuments.length<1) {
    return await this.filterByPersons(selectedPersons,filtered);
  }else if (selectedPersons.length<1 && selectedDocuments.length>0) {
    await  await this.filterByDocument(selectedDocuments, filtered);
  }else{
    let filteredPersons =await this.filterByPersons(selectedPersons,filtered);
    await this.filterByDocument(selectedDocuments, filteredPersons);
  }
}
filterByPersons=async(selectedPersons,filtered)=>{
  return await this.filterByCategory(selectedPersons,filtered);
}
filterByDocument = async (selectedDocuments,filtered)=>{
  let ar = [];
  Object.values(filtered).map(value=>{
    return selectedDocuments.map(key=>{
      if(value!==undefined){
      ar.push(value[key]);}
    })});
    let result = Object.assign({},...ar.flat());
    console.log(result);
    await this.setStatesForEvents(result);
  }
 setStatesForEvents =async (filteredObject)=>{
   const { t } = this.state;
  if(Object.keys(filteredObject).length<1){
    OCAlert.alertWarning(t('There is no todos linked with this selected team or person or document '), { timeOut: window.TIMEOUTNOTIFICATION });
    return;
  }
let events = await this.createDataByRow(Object.values(filteredObject));
console.log(events);
   this.setState({
     events:events
   })
 }
 filterByCategory=(selected ,filtered)=>{
   console.log(selected);
   return selected
    .reduce((obj, key) => ({ ...obj, [key]: filtered[key] }), {});
 }
  eventStyleGetter = (event, start, end, isSelected) => {
    var backgroundColor ='';
    var time1 = moment().format('YYYY-MM-DD');
    var time2 = moment(event.start).format('YYYY-MM-DD');
    if(time1 > time2 && (event.tableType==1 || event.tableType==2 || event.tableType==3)){
            backgroundColor = 'red';
    }
    else if(time1 < time2 && event.tableType==1) {
            backgroundColor = 'green';
    }
    else if(time1 < time2 && event.tableType==2){
            backgroundColor = 'blue';
    }
    else if(time1 < time2 && event.tableType==3){
            backgroundColor = 'green';
    }
    else{
          backgroundColor = 'yellow';
    }
    var style = {
      backgroundColor: backgroundColor,opacity: 2.6,
      color: 'black',textAlign:'center'};
    return {
      style: style
    };
  }
  componentDidUpdate(prevProps, prevState){
    if(this.state.currentTodoId!==prevState.currentTodoId){
      this.setState({
        currentTodoId:this.state.currentTodoId,
      })
    }
  }
  handleSelect =async (e) => {
    var today = moment().format('YYYY-MM-DD');
    var todoDate = moment(e.start).format('YYYY-MM-DD');
    if(today > todoDate){
    await  this.setStateValues(e.id,e.start,today,e.tableType,true,true)
      }
      else{
    await  this.setStateValues(e.id,e.start,todoDate,e.tableType,false,true);
      }
    }
    setStateValues =(id, startDate, newDate, type, duedatePassed, showPopUp)=>{
      this.setState({
        showPopUp: showPopUp,
        currentTodoId: id,
        oldDate:startDate ,
        newDate:newDate,
        duedatePassed:duedatePassed,
        tableType:type
      })
    }
      handleEvenSelect(event) {
        this.handleSelect(event);
      }
      handleCancel() {
        this.setState({  showPopUp: false ,duedatePassed:false});
      }
      handleChangeDate(name,value) {
        this.setState({[name]:value})
      }
      async handleEdit () {
        let currentTime = moment.utc().format('hh:mm:ss');
        var today = moment().format('YYYY-MM-DD');
        let date =  moment(this.state.newDate).format('YYYY-MM-DD');
        this.setState({allowUserDocuments:false});
        const {newDate,comments,t} =this.state;
        if(newDate==='' || newDate ===undefined){
          OCAlert.alertWarning(t('Please enter new Duedate'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
        if(comments == undefined || comments.length<1) {
          OCAlert.alertWarning(t('Please enter reason to change duedate'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }
        if(today > date){
          OCAlert.alertWarning(t('Please select today or upcoming date'), { timeOut: window.TIMEOUTNOTIFICATION });
          return;
        }

        let data = {
          id :this.state.currentTodoId,
          newDate : this.state.newDate+' '+currentTime,
          comment : this.state.comments,
          oldDate : this.state.oldDate,
          tableType : this.state.tableType
        };
        this.state.events.map(value=>{
          if(value.id===this.state.currentTodoId){
            value.start = moment(this.state.newDate+' '+currentTime)._d;
            value.end = moment(this.state.newDate+' '+currentTime)._d;
            value.comment = this.state.comments;
          }
        })
        datasave.service(window.UPDATE_CALENDER_DUE_DATE,'POST',data)
        .then(async response=>{
          await  this.componentDidMount('false');
        })
      }
      handleEventHover = (event) => {
        // return ('Todo id: '+event.id+ '\n' + 'Person name: '+event.username+ '\n' + 'Document: '+event.document);
        let str = 'Task planner: '+event.title+ '\n' + 'Actor: '+event.org_type_id+ '\n' + 'Organisation unit: '+event.org_id+ '\n' + 'Amount: '+event.amount+'\n' + 'Document code: '+event.document_code+ '\n' + 'Document name: '+event.document_name;
        if(this.state.dateChecked === 1) {
            str+='\n'+'Started at: '+event.started_at;
            //+'\n' +'To do generated at: '+ new Date(event.ended_at).toLocaleTimeString();

        }else {
        str+='\n'+'Due date: '+event.due_date;
        //+'\n'+'To do generated at: '+ new Date(event.due_date).toLocaleTimeString();
        }
        return str;
       }

      displayCalendar() {
        const {t}=this.state;
        const localizer = momentLocalizer(moment);
        return (
          <reactbootstrap.Container className = 'mt-2' >
          <reactbootstrap.Row className = 'pt-2 m-0' style={{backgroundColor:'#EC661C',height:'70px',paddingBottom:'48px'}} >
          <reactbootstrap.Col className='col-md-4' style={{display:'flex',}}>
          <reactbootstrap.Col className='col-md-3'><reactbootstrap.Form.Label>{t('Select team')}</reactbootstrap.Form.Label></reactbootstrap.Col>
          <reactbootstrap.Col className='col-md-9' style={{zIndex:999}}>
          <MultiSelect
          options={Object.values(this.state.teams)}
          standards={this.state.selectedTeams}
          disabled={false}
          handleChange={this.handleChangeTeamsOptions}
          isMulti={true}
          name = {'selectedTeams'}
          />
          </reactbootstrap.Col>
          </reactbootstrap.Col>
          <reactbootstrap.Col className='col-md-4' style={{display:'flex'}}>
          <reactbootstrap.Col className='col-md-3'><reactbootstrap.Form.Label>{t('Select person')}</reactbootstrap.Form.Label></reactbootstrap.Col>
          <reactbootstrap.Col className='col-md-9 dropValue' style={{zIndex:999}}>
          <MultiSelect
          options={Object.values(this.state.persons)}
          standards={this.state.selectedPersons}
          disabled={false}
          handleChange={this.handleChangePersonsOptions}
          isMulti={true}
          name = {'selectedPersons'}
          />
          </reactbootstrap.Col>
          </reactbootstrap.Col>
          <reactbootstrap.Col className='col-md-4' style={{display:'flex'}}>
          <reactbootstrap.Col className='col-md-3'><reactbootstrap.Form.Label>{t('Select document')}</reactbootstrap.Form.Label></reactbootstrap.Col>
          <reactbootstrap.Col className='col-md-9' style={{zIndex:999}}>
          <MultiSelect
          options={Object.values(this.state.documents)}
          standards={this.state.selectedDocuments}
          disabled={false}
          handleChange={this.handleChangeDocumentsOptions}
          isMulti={true}
          name = {'selectedDocuments'}
          />
          </reactbootstrap.Col>
          </reactbootstrap.Col>
          </reactbootstrap.Row>

          <reactbootstrap.Row className='mt-1 pl-4' >

          <label><input type='radio'   name='radio'   checked = {this.state.dateChecked === 1} onChange = {(e)=>this.handleRadioSelect(1)} />&nbsp;{t('Due date')}</label>
          &nbsp;&nbsp;&nbsp;
          <label><input type='radio'   name='radio'   checked = {this.state.dateChecked === 2} onChange = {(e)=>this.handleRadioSelect(2)} />&nbsp;{t('Started at')}</label>

          </reactbootstrap.Row>

          <reactbootstrap.Row style={{ height: '380pt',paddingTop:'5px' }} >
          <reactbootstrap.Col className='col-md-12' >
          <DragAndDropCalendar
          // popup
          events={this.state.events}
          dayLayoutAlgorithm="no-overlap"
          startAccessor={"start"}
          endAccessor={"end"}
          defaultView='month'
          views={['week', 'day', 'work_week', 'agenda', 'month']}
          localizer={localizer}
          onSelectEvent={(event) => this.handleEvenSelect(event)}
          eventPropGetter={this.eventStyleGetter}
          tooltipAccessor={(event) => this.handleEventHover(event)}
          messages={{ showMore: (target) => <span className="ml-2" role="presentation" >+{target} more</span> }}
          />
          </reactbootstrap.Col>
          </reactbootstrap.Row>
          </reactbootstrap.Container>
        );


      }
      displayPopUp() {
        const { t } = this.state;
        return (
          <reactbootstrap.Modal show={this.state.showPopUp} onHide={(e) => this.setState({ showPopUp: false })}>
          <reactbootstrap.Modal.Header closeButton>
          <reactbootstrap.Modal.Title>{t('Edit todo')}</reactbootstrap.Modal.Title>
          </reactbootstrap.Modal.Header>
          <reactbootstrap.Modal.Body>
          {this.state.duedatePassed ===true && <span style={{color:'black',textAlign:'center'}}><h4 style={{backgroundColor:'red'}}>{t("Due date is Passed")}</h4></span>}
          <reactbootstrap.Form.Group
          controlId="formInfo"
          className="col-md-12 label-group"
          style={{display:'flex'}}>
          <reactbootstrap.Form.Label className="col-md-4 common-color">{t('New Duedate ')}:</reactbootstrap.Form.Label>
          <reactbootstrap.FormControl
          name="newDate"
          disabled = {false}
          type="date"
          value={this.state.newDate}
          onChange={(e)=> {this.handleChangeDate(e.target.name, e.target.value)}}
          className="col-md-8 input_sw"
          />
          </reactbootstrap.Form.Group>
          <reactbootstrap.Form.Group
          controlId="formInfo"
          className="col-md-12 label-group"
          style={{display:'flex'}}>
          <reactbootstrap.Form.Label className="col-md-4 common-color">
          {t('Reason ')}:
          </reactbootstrap.Form.Label>
          <reactbootstrap.FormControl
          as="textarea"
          className="col-md-8 textarea input_sw"
          placeholder={t('Reason to change Duedate')}
          rows='4' cols='40'
          onChange={(e) => this.setState({ comments: e.target.value })} />
          </reactbootstrap.Form.Group>
          </reactbootstrap.Modal.Body>
          <reactbootstrap.Modal.Footer>
          <reactbootstrap.Button variant="primary" onClick={this.handleCancel.bind(this)}>
          {t('Cancel')}
          </reactbootstrap.Button>
          <reactbootstrap.Button variant="primary" onClick = {this.handleEdit.bind(this)}>
          {t('Edit')}
          </reactbootstrap.Button>
          </reactbootstrap.Modal.Footer>
          </reactbootstrap.Modal>
        )
      }
      render() {
        return (<reactbootstrap.Container>
          {this.displayCalendar()}
          {this.displayPopUp()}
        </reactbootstrap.Container>)
        }
      }
      export default translate(TodosCalendar);
