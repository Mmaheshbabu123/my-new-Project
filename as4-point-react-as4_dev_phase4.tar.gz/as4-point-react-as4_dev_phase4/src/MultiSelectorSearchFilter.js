export const MultiSelectorSearchFilter = {
  getData,
}
function getData(filledStates, data) {
  switch (filledStates.length) {
    case 1:
    return filterItemBy1Column(filledStates,data);
    break;
    case 2:
    return filterItemBy2Column(filledStates,data);
    break;
    case 3:
    return filterItemBy3Column(filledStates,data);
    break;
    default:
    return data;
  }
}
/**
* [filterBy1Column description]
* @param  {[type]} states  [description]
* @param  {[type]} allData [description]
* @return {[type]}         [description]
*/
function filterItemBy1Column(states,allData){
  return allData.filter(item=>{
    return states[0]['value'].includes(item[states[0]['name']])
  })
}
/**
* [filterBy2Column description]
* @param  {[type]} states  [description]
* @param  {[type]} allData [description]
* @return {[type]}         [description]
*/
function filterItemBy2Column(states,allData){
  return allData.filter(item=>{
    return states[0]['value'].includes(item[states[0]['name']]) && states[1]['value'].includes(item[states[1]['name']])
  })
}
/**
* [filterBy3Column description]
* @param  {[type]} states  [description]
* @param  {[type]} allData [description]
* @return {[type]}         [description]
*/
function filterItemBy3Column(states,allData){
  return allData.filter(item=>{
    return states[0]['value'].includes(item[states[0]['name']]) && states[1]['value'].includes(item[states[1]['name']])
    && states[2]['value'].includes(item[states[2]['name']])
  })
}
