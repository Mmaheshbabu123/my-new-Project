 var load = setTimeout(function(){
 /*  $('#head').html($('.header').contents().find('#pf1 .pc').html());
   $('#foot').html($('.footer').contents().find('#pf1 .pc').html());
      $('.header').contents().find('#page-container').css({"overflow":"hidden","left":"250px",'background-color':'white','background-image':'none','width':'80%'});
      $('.content').contents().find('#page-container').css({'background-color':'white','background-image':'none'});
      $('.footer').contents().find('#page-container').css({"overflow":"hidden","left":"250px",'background-color':'white','background-image':'none','width':'80%'});
      $('.footer').contents().find('.h0').css({'height':'100px'});
*/
  }, 1000);
