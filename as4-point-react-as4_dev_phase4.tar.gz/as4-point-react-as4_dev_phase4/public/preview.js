setTimeout(function(){
   var hh = 1;

    }, 2000);
$.noConflict();
jQuery.noConflict();
jQuery(document).ready(function($){
        $.noConflict();
        $('.content').on('load', function(){
          $('.content').contents().find('.revisiondetails').each(function() { 
            let backend_url = $('#backendurl').attr('data-url');
            let front_url = $('#fronturl').attr('data-url');
            let watermark = $('#watermark').attr('data-url');
            let docStatus = $('#docStatus').attr('data-url');

            $(this).bind('click', function() {
            let entity_id = $(this).attr('data-entity-id');
            let entity_type = $(this).attr('data-entity-type');
            let entity_type_ref = $(this).attr('data-entity-type-ref');
            let doc_type_id = $(this).attr('data-doc-type-id');
            let entity_url = backend_url + '/api/get-doc-entities/'+ entity_type + '/' +  entity_id + '/' + entity_type_ref;
            let request_url_status =  backend_url + '/api/getstatus/' + entity_id;
            let document_status = -1;
            let type = 1;
            if (doc_type_id == 2) {
              type = 5;
            }
            else if (doc_type_id == 3) {
              type = 6;

            }
            else if (doc_type_id == 4 || doc_type_id == 5) {
               type = -999;
            }
            let entity_url_document = backend_url + '/api/get-document-data/' + type + '/' + entity_id + '/general/Dutch';
            let request_url = (entity_type == 3 && entity_type_ref != 'org') ? entity_url_document : entity_url;

            if (entity_type == 3 && entity_type_ref != 'org') {
            $("#loading-icon-show .loading").show();
              $.ajax({
               url: request_url_status,
               method: "GET",
               beforeSend: function (xhr) {
                 xhr.setRequestHeader('Authorization', 'Bearer ca3d15b6-3f82-4050-8267-3a8db89a4e20');
               },
               success: function(response) {
                 $("#loading-icon-show .loading").hide();
                 var result = response;
                 if (result.status == 200) {
                    document_status = result.active;
                    if (document_status == 0) {
                       nonActiveStatus($);

                    }
                    else {
                      if (type < 0) {
                        let entity_url_document_obj = front_url + '/common/' + entity_id;
                        window.open(entity_url_document_obj, '_blank');
                        return;

                       }
                       else {
                        let entity_url_document_obj = front_url + '/previewrevisionentities/' + entity_id;
                        window.open(entity_url_document_obj, '_blank');
                        return;

                       }
                       /*else {
                         ajaxcallpopup(request_url, entity_type, entity_type_ref, front_url, $, entity_id);

                       }*/
                    }
                 }
               },
               error: function(error) {
                 $("#loading-icon-show .loading").hide();
                 console.log(error);
               },
              });
            }
            if ((entity_type != 3 &&  entity_type_ref == 'documents') || entity_type_ref == 'org') {
              $("#loading-icon-show .loading").show();
              ajaxcallpopup(request_url, entity_type, entity_type_ref, front_url, $, entity_id);
            }
            });

          });
        });
        setTimeout(function(){
            $('.content').contents().find('#sidebar').each(function() {
               
               $(this).removeClass('opened');
            });
            let backend_url = $('#backendurl').attr('data-url');
            let front_url = $('#fronturl').attr('data-url');
            let watermark = $('#watermark').attr('data-url');
            let docStatus = $('#docStatus').attr('data-url');
            $('.content').contents().find('.revisiondetails1').each(function() {
            $(this).bind('click', function() {
            let entity_id = $(this).attr('data-entity-id');
            let entity_type = $(this).attr('data-entity-type');
            let entity_type_ref = $(this).attr('data-entity-type-ref');
            let doc_type_id = $(this).attr('data-doc-type-id');
            let entity_url = backend_url + '/api/get-doc-entities/'+ entity_type + '/' +  entity_id + '/' + entity_type_ref;
            let request_url_status =  backend_url + '/api/getstatus/' + entity_id;
            let document_status = -1;
            let type = 1;
            if (doc_type_id == 2) {
              type = 5;
            }
            else if (doc_type_id == 3) {
              type = 6;

            }
            else if (doc_type_id == 4 || doc_type_id == 5) {
               type = -999;
            }
            let entity_url_document = backend_url + '/api/get-document-data/' + type + '/' + entity_id + '/general/Dutch';
            let request_url = (entity_type == 3 && entity_type_ref != 'org') ? entity_url_document : entity_url;

            if (entity_type == 3 && entity_type_ref != 'org') {
            $("#loading-icon-show .loading").show();
              $.ajax({
               url: request_url_status,
               method: "GET",
               beforeSend: function (xhr) {
                 xhr.setRequestHeader('Authorization', 'Bearer ca3d15b6-3f82-4050-8267-3a8db89a4e20');
               },
               success: function(response) {
                 $("#loading-icon-show .loading").hide();
                 var result = response;
                 if (result.status == 200) {
                    document_status = result.active;
                    if (document_status == 0) {
                       nonActiveStatus($);

                    }
                    else {
                      if (type < 0) {
                        let entity_url_document_obj = front_url + '/common/' + entity_id;
                        window.open(entity_url_document_obj, '_blank');
                        return;

                       }
                       else {
                        let entity_url_document_obj = front_url + '/previewrevisionentities/' + entity_id;
                        window.open(entity_url_document_obj, '_blank');
                        return;

                       }
                       /*else {
                         ajaxcallpopup(request_url, entity_type, entity_type_ref, front_url, $, entity_id);

                       }*/
                    }
                 }
               },
               error: function(error) {
                 $("#loading-icon-show .loading").hide();
                 console.log(error);
               },
              });
            }
            if ((entity_type != 3 &&  entity_type_ref == 'documents') || entity_type_ref == 'org') {
              $("#loading-icon-show .loading").show();
              ajaxcallpopup(request_url, entity_type, entity_type_ref, front_url, $, entity_id);
            }
            });
        });
        var scriptLinks = '<script src="' + front_url + '/jquery-3.2.1.min.js?q=1" crossorigin="anonymous"></script><script src="' + front_url + '/popper.min.js?q=1" crossorigin="anonymous"></script><script src="' + front_url + '/bootstrap.min.js?q=1" crossorigin="anonymous"></script><style>.key-transform { text-transform: capitalize; } .revisiondetails { color: rgb(36,64,97); cursor: pointer; text-decoration: underline;} body > div, body > table {width: 10.37in !important;} body {max-width: 10.37in !important} .ff2 .revisiondetails { font-weight: bold;} </style>';
        $('#modal-content-show').append(getModalData('Jobs', 'Job description'));
        $('#loading-icon-show').append(getLoadingIcon());
        var footerCss = '<style>p[align="center"] { text-align:center; }</style>';
        $('.content').contents().find('head').append(scriptLinks);
        $('.footer').contents().find('head').append(footerCss);
        let headertxt = $('.header').contents().find('head').find('style').text().trim();
        let footertxt = $('.footer').contents().find('head').find('style').text().trim();
        let landscapeh = headertxt.search('11.69in 8.27in');
        let portraith = headertxt.search('8.27in 11.69in');
        let landscapef = footertxt.search('11.69in 8.27in');
        let portraitf = footertxt.search('8.27in 11.69in');
        let landscapehCM = headertxt.search('29.7cm 21cm');
        let portraithCM = headertxt.search('21cm 29.7cm');
        let landscapefCM = footertxt.search('29.7cm 21cm');
        let portraitfCM = footertxt.search('21cm 29.7cm');

        let stylePotrait = "<style>body { width: 8.27in; margin-left: 1in !important; margin-right: 1in !important;}</style>";
        let styleLandscape = "<style>body { width: 11.69in; margin-left: 0in !important; margin-right: 0in !important;padding: 0px 1px !important;}</style>";
        let bodyLandscape = "<style>body { width: 11.69in !important; margin-left: 0in !important; margin-right: 0in !important;padding: 0px 1px !important;} #page-container { width: 11.85in !important; margin-left: 0in !important; margin-right: 0in !important;} body > div, body > table { width: 11.69in !important;} .pf { transform: scale(1);} h { display: block; padding: 0px !important;} img { height: auto !important; }</style>";
        let bodyPotrait = "<style>body { width: 8.27in !important; margin-left: 1in !important; margin-right: 1in !important;} #page-container { width: 8.5in !important; margin-left: 1in !important; margin-right: 1in !important;} body > div, body > table { width: 8.27in !important;} .pf { transform: scale(1);} h { display: block; padding: 0px !important;} img { height: auto !important; } </style>";
        if (landscapeh > 1 || landscapehCM > 1) {
          $('.header').contents().find('head').append(styleLandscape);
          $('.content').contents().find('head').append(bodyLandscape);
        }
        if (landscapef != "-1" || landscapefCM != "-1") {
          $('.footer').contents().find('head').append(styleLandscape);
        }
        if (portraith > 1 || portraithCM > 1) {
          $('.header').contents().find('head').append(stylePotrait);
          $('.content').contents().find('head').append(bodyPotrait);
        }
        if (portraitf > 1 || portraitfCM > 1) {
          $('.footer').contents().find('head').append(stylePotrait);
        }

        $('.footer').contents().find('head').append('<base target="_blank" />');
        $('.header').contents().find('head').append('<base target="_blank" />');
        $('.content').contents().find('head').append('<base target="_blank" />');
        $('.header').contents().find('body').find('div[title="footer"]').css({'display': 'none'});
        $('.footer').contents().find('body').find('div[title="header"]').css({'display': 'none'});
        $('.header').contents().find('body').find('div[title="header"]').find('p').each(function() {
             if ($(this).html().trim().search('<br>\n<br>') == 0) {
               $(this).css({'display': 'none'});
             }
        });
        $('.footer').contents().find('body').find('div[title="footer"]').find('p').each(function() {
             if ($(this).html().trim().search('<br>\n<br>') == 0) {
               $(this).css({'display': 'none'});
             }
        });
        if(watermark == 1) {
          $('.content').contents().find('body')
          .prepend('<span id="background" style="position: absolute;z-index: -99;display: block;min-height: 50%;min-width: 50%;color: yellow;"><p id="bg-text" style="color: lightgrey;font-size: 250px;transform: rotate(300deg);-webkit-transform: rotate(300deg);margin-top: 50%;">' + docStatus + '</p</span>');
        }

        $('.content').contents().find('body').find('ol > li > p').each(function() {
             var margin;
             if ($(this).find('span') != undefined) {
               margin = $(this).css('margin-left');
               $(this).find('span:first').css({'margin-left': margin, 'font-size' : 'inherit'});
               $(this).css({'margin-left': '0px'});
             }
        });
        $('.content').contents().find('body').find('ol > li > ol > li > p').each(function() {
             var margin;
             if ($(this).find('span') != undefined) {
               margin = $(this).css('margin-left');
               $(this).find('span:first').css({'margin-left': margin, 'font-size' : 'inherit'});
               $(this).css({'margin-left': margin});
             }
        });
        $('.content').contents().find('body').find('ul > li > p').each(function() {
             var margin;
             if ($(this).find('span') != undefined) {
               margin = $(this).css('margin-left');
               $(this).find('span:first').css({'margin-left': margin, 'font-size' : 'inherit'});
               $(this).css({'margin-left': '0px'});
             }
        });
        $('.content').contents().find('body').find('ul > li > ul > li > p').each(function() {
             var margin;
             if ($(this).find('span') != undefined) {
               margin = $(this).css('margin-left');
               $(this).find('span:first').css({'margin-left': margin, 'font-size' : 'inherit'});
               $(this).css({'margin-left': margin});
             }
        });

        $('.content').contents().find('body').find('h1.Heading_20_1 a#a_2__Diensten__verpakking__R_O').parent().css({'border-top-style' : 'solid', 'border-bottom-style' : 'solid'});
        $('.content').contents().find('body').find('h1.P15 a#a_1__Grondstoffen').parent().css({'border-top-style' : 'solid', 'border-bottom-style' : 'solid'});

        $('#office_frame_preview').contents().find('.header').css({'max-height': '100px'});
        $('#office_frame_preview').contents().find('.footer').css({'max-height': '100px'});
        $('.content').contents().find('body').find('div[title="header"]').css({'display': 'none'});
        $('.content').contents().find('body').find('div[title="footer"]').css({'display': 'none'});
        $('.footer').contents().find('body > p').remove();
        $('.footer').contents().find('body').find('p').each(function() {
             if ($(this).attr('align') != undefined) {
               $(this).css({'text-align': $(this).attr('align')});
             }
        });
        var headerHeight = $('.header').contents().find('body > div').outerHeight();
        $('.header').css({'height' : headerHeight + 10 + 'px'});
        var footerHeight = $('.footer').contents().find('body > div').outerHeight();
        $('.footer').css({'height' : footerHeight + 30 + 'px'});

     }, 2000);

});
function getModalData(header, body) {
return "<div class='modal fade' id='entitymodal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'><div class='modal-dialog mw-100 w-50' role='document'><div class='modal-content'><div class='modal-header'><h5 class='modal-title' id='exampleModalLabel'>" + header + "</h5><button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div><div class='modal-body'>"+body+"</div><div class='modal-footer'><button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button></div></div></div></div>";
}
function getLoadingIcon() {
 return '<div class="loading" id="loading-icon" style="display: none;"><div><svg width="100" height="100" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient x1="8.042%" y1="0%" x2="65.682%" y2="23.865%" id="a"><stop stop-color="#00BFFF" stop-opacity="0" offset="0%"></stop><stop stop-color="#00BFFF" stop-opacity=".631" offset="63.146%"></stop><stop stop-color="#00BFFF" offset="100%"></stop></linearGradient></defs><g fill="none" fill-rule="evenodd"><g transform="translate(1 1)"><path d="M36 18c0-9.94-8.06-18-18-18" id="Oval-2" stroke="#00BFFF" stroke-width="2"><animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur="0.9s" repeatCount="indefinite"></animateTransform></path><circle fill="#fff" cx="36" cy="18" r="1"><animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur="0.9s" repeatCount="indefinite"></animateTransform></circle></g></g></svg></div></div>';
}
function ajaxcallpopup(request_url, entity_type, entity_type_ref, front_url, $, entity_id) {
$.ajax({
    url: request_url,
    method: "GET",
    beforeSend: function (xhr) {
      xhr.setRequestHeader('Authorization', 'Bearer ca3d15b6-3f82-4050-8267-3a8db89a4e20');
    },
    success: function(response) {
      $("#loading-icon-show .loading").hide();
      var result = response;
      if (entity_type == 3 && entity_type_ref != 'org') {
        result = JSON.parse(response);
        if (result.status == 200) {
             window.open(front_url + '/previewrevision/' + entity_id +'?content=' + result.content, '_blank');
         }
         else {
             alert(result.message);
         }
      }
      else if (entity_type == 8 && result.body.show_in_popup == 0) {
          let url = result.body.url;
          if (url != '') {
            if (!url.match(/^https?:\/\//i)) {
              url = 'https://' + url;
            }
            else if (!url.match(/^http?:\/\//i)) {
              url = 'http://' + url;
            }
          }
          else {
             alert('Url is not linked');
          }
          window.open(url, '_blank');

      }
      else {
          let atag;
          if (entity_type == 8 && result.body.show_in_popup == 1) {
             atag = '<a href=' + result.body.url + ' target = "_blank">' + result.body.url + '</a>';
          }
          if (entity_type == 4 && result.body.logo != null) {
             atag = '<img class="img-fluid" src="' + result.body.logo + '" alt="" />';
          }
          let body = '<div class="container">';
          $.each(result.body, function(key,value) {
            if (key != 'show_in_popup') {
              if (value == null) {
                value = '-';
              }
              body += '<div class="row"><div class="col-md-3 col-lg-3 key-transform">'+ key + ':' + '</div>';
              body += (key == 'url' || (key == 'logo' && value != null  && value != '-')) ? '<div class="col-md-9 col-lg-9">'+ atag +'</div></div>' : '<div class="col-md-9 col-lg-9">'+ value +'</div></div>';
            }
          });
          body += '</div>';
          $('#modal-content-show').html('');
          $('#modal-content-show').append(getModalData(result.header, body));
          $('#entitymodal').modal('show');
      }
    },
    error: function(error) {
      $("#loading-icon-show .loading").hide();
      console.log(error);
    },
 });

}
function nonActiveStatus ($) {
   let body = '<div class="container">';
   body += '<div class="row"><div class="col-md-12">Document not yet published</div></div></div>';
   $('#modal-content-show').html('');
   $('#modal-content-show').append(getModalData('Not published', body));
   $('#entitymodal').modal('show');
}
